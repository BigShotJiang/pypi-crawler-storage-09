"""Python package for access to online biomedical resources, usually via REST APIs."""
