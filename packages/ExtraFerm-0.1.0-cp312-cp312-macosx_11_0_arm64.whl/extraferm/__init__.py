"""Particle number conserving extended matchgate quantum circuit simulator."""

from .interface import outcome_probabilities

__all__ = [
    "outcome_probabilities",
]
