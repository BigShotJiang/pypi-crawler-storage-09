# OASYS1-ELETTRA-Extensions

OASYS extensions for the Elettra

Container of the Oasys Extensions developed at Elettra 

To install:
* Oasys GUI Menu tab -> Options -> Add-ons...
* Click "Add more" and enter "OASYS1-Elettra-Extensions". You will see a new entry "Elettra Extensions" in the add-on list. Check it and click "OK"
* Restart Oasys.

The repository can be found at:

https://github.com/oasys-elettra-kit/OASYS1-ELETTRA-Extensions
