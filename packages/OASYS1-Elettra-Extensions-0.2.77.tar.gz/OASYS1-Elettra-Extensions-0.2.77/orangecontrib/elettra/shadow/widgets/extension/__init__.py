# Category description for the widget registry

NAME = "ShadowOui Elettra Extension"

DESCRIPTION = "Widgets for ShadowOui Elettra Extension"

BACKGROUND = "#08B0E8"

ICON = "icons/LogoElettra_transparent.png"

PRIORITY = 130