from pycbc import distributions
# print all distribution names
print(distributions.distribs.keys())
