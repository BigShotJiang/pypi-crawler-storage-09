cd output

pycbc_submit_dax
