pycbc_inference \
--config-file `dirname "$0"`/single_simple.ini \
--nprocesses=1 \
--output-file single.hdf \
--seed 0 \
--force \
--verbose
