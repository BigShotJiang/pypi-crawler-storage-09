pycbc_make_skymap \
    --trig-time 1126259462.431 \
    --thresh-SNR 5.5 \
    --f-low 27 \
    --mass1 44.210617 \
    --mass2 32.163776 \
    --spin1z 0.782143 \
    --spin2z -0.861017 \
    --ifos H1 L1 \
    --ligolw-event-output coinc_GW150914.xml

