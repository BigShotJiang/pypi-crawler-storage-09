pycbc_submit_dax \
--local-dir ./ \
--no-query-db \
