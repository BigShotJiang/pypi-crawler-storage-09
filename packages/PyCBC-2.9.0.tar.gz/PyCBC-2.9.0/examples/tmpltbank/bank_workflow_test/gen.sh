pycbc_make_uberbank_workflow --workflow-name gw --output-dir output --config-files test_uberbank.ini --submit-now
