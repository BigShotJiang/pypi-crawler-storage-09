rm -rf output_banks
rm -rf split_banks
rm -rf logs
rm -f covariance_evecs.dat metric_evals.dat metric_evecs.dat testNonSpin.xml testStoch.xml testAligned.xml bank_generation.* *.sub cache/*
