python simple.py --multilevel --workflow-name test --config-files simple.ini --submit-now
