"""
This packages contains modules for clustering events
"""

from .eventmgr import *
from .veto import *
from .coinc import *

