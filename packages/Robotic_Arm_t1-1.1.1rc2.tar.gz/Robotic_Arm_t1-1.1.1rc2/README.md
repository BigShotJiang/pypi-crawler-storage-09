# Robotic_Arm_t1
  
二代睿尔曼机械臂Python版本二次开发包  
该版本库基于[Robotic-Arm 1.1.1](https://pypi.org/project/Robotic-Arm/#description)扩展，新增通过端口判别 UDP 数据来源的功能。

## 安装  
  
你可以通过pip来安装这个包：  
  
```bash  
pip install Robotic_Arm_t1