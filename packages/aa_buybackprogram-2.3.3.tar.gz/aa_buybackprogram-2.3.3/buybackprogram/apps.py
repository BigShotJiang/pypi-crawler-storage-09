from django.apps import AppConfig


class BuybackProgramConfig(AppConfig):
    name = "buybackprogram"
    label = "buybackprogram"
    verbose_name = "buybackprogram"
