"""Top-level package for aa-contacts."""

__author__ = """Matteo Ghia"""
__email__ = 'matteo.ghia@yahoo.it'
__version__ = '0.9.1'

__github_url__ = 'https://github.com/Maestro-Zacht/aa-contacts'
__app_name_ua__ = 'aa-contacts'
