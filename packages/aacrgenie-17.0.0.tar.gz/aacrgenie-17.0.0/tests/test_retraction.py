import pandas as pd
import pytest

from genie_registry.sampleRetraction import sampleRetraction
from genie_registry.patientRetraction import patientRetraction


@pytest.fixture
def sr(syn):
    return sampleRetraction(syn, "SAGE")


@pytest.fixture
def pr(syn):
    return patientRetraction(syn, "SAGE")


def test_processing(sr, pr):
    expectedsrDf = pd.DataFrame(
        dict(
            genieSampleId=[
                "GENIE-SAGE-ID1-1",
                "GENIE-SAGE-ID2-1",
                "GENIE-SAGE-ID3-1",
                "GENIE-SAGE-ID4-1",
                "GENIE-SAGE-ID5-1",
            ],
            retractionDate=[
                1523039400000,
                1523039400000,
                1523039400000,
                1523039400000,
                1523039400000,
            ],
            center=["SAGE", "SAGE", "SAGE", "SAGE", "SAGE"],
        )
    )

    srDf = pd.DataFrame(
        {
            0: [
                "GENIE-SAGE-ID1-1",
                "GENIE-SAGE-ID2-1",
                "GENIE-SAGE-ID3-1",
                "GENIE-SAGE-ID4-1",
                "GENIE-SAGE-ID5-1",
            ]
        }
    )
    # TODO: look into this test as when it's executed on local machine
    # the results are different. which means
    # the pandas to_datetime function is taking account into local vs GMT time now
    newsrDf = sr._process(srDf, "2018-04-06T18:30:00")
    assert expectedsrDf.equals(newsrDf[expectedsrDf.columns])

    expectedprDf = pd.DataFrame(
        dict(
            geniePatientId=[
                "GENIE-SAGE-ID1",
                "GENIE-SAGE-ID2",
                "GENIE-SAGE-ID3",
                "GENIE-SAGE-ID4",
                "GENIE-SAGE-ID5",
            ],
            retractionDate=[
                1523125800000,
                1523125800000,
                1523125800000,
                1523125800000,
                1523125800000,
            ],
            center=["SAGE", "SAGE", "SAGE", "SAGE", "SAGE"],
        )
    )

    prDf = pd.DataFrame(
        {
            0: [
                "GENIE-SAGE-ID1",
                "GENIE-SAGE-ID2",
                "GENIE-SAGE-ID3",
                "GENIE-SAGE-ID4",
                "GENIE-SAGE-ID5",
            ]
        }
    )

    newprDf = pr._process(prDf, "2018-04-07T18:30:00")
    assert expectedprDf.equals(newprDf[expectedprDf.columns])


def test_validate_filename(sr, pr):
    with pytest.raises(AssertionError):
        sr.validateFilename(["foo"])
    assert sr.validateFilename(["sampleRetraction.csv"]) == "sampleRetraction"

    with pytest.raises(AssertionError):
        pr.validateFilename(["foo"])
    assert pr.validateFilename(["patientRetraction.csv"]) == "patientRetraction"
