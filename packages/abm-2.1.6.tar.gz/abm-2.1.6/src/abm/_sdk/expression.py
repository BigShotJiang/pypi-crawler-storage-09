__all__ = ["Expression", "StaticExpression", "Unit"]

Unit = str
Expression = str | int | float | bool
StaticExpression = str | int | float | bool
