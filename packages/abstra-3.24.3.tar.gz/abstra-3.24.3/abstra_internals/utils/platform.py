import platform


def is_windows():
    return platform.system() == "Windows"
