from .functions import *
def initFuncs(self):
    self.emit = emit
    return self
