from PyQt6.QtWidgets import QApplication,QTextEdit
from PyQt6 import QtWidgets, QtGui, QtCore, QtGui, QtWidgets
from pathlib import Path
import traceback, sys, logging, os,threading
from logging.handlers import RotatingFileHandler
from PyQt6.QtCore import QObject,pyqtSignal,QTimer
