from abstract_hugpy.hugpy_console.hugpy_flasks.hugpy_zerosearch_flask_app import hugpy_zerosearch_app

app = hugpy_zerosearch_app()

