from abstract_hugpy.hugpy_console.hugpy_flasks import hugpy_all_app

app = hugpy_all_app()
