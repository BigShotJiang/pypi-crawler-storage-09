from .hugpy_deepzero_flask_app import *
from .hugpy_deepcoder_flask_app import *
from .hugpy_zerosearch_flask_app import *
from .hugpy_proxyvideo_flask_app import *
from .hugpy_video_flask_app import *
from .hugpy_all_flask_app import hugpy_all_app
