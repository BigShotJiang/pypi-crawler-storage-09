from abstract_utilities import *
call_for_all_tabs()
from .main import *
def startIdeConsole():
    startConsole(ideTab)
