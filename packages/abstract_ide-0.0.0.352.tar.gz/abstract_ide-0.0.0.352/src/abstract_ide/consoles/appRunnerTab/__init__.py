from .main import appRunnerTab
from ..imports import startConsole
def startAppRunnerConsole():
    startConsole(appRunnerTab)
