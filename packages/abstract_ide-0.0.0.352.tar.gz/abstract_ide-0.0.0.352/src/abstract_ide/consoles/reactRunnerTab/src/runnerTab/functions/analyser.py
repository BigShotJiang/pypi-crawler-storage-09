from abstract_react import *

path = "/var/www/thedailydialectics"
output = run_build_get_errors(path=path)
input(output)
