from consoles import *

from abstract_gui.QT6 import  *
  
