"""TTS module for voice synthesis with interrupt handling."""

from .tts_engine import TTSEngine

__all__ = ['TTSEngine'] 