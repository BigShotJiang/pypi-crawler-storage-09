#ifndef _ACCRQA_DEFINITIONS_DEF
#define _ACCRQA_DEFINITIONS_DEF

#include <stdio.h>


//#define MONITOR_PERFORMANCE
#define ACCRQA_DEBUG_MODE false

#endif