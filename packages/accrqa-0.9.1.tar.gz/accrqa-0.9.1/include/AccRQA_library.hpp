#ifndef _ACCRQA_LIBRARY_
#define _ACCRQA_LIBRARY_

#include "AccRQA_definitions.hpp"
#include "AccRQA_utilities_error.hpp"
#include "AccRQA_utilities_comp_platform.hpp"
#include "AccRQA_utilities_distance.hpp"
#include "AccRQA_functions.hpp"
#include "AccRQA_utilities_mem.hpp"


#endif