class TypeIDValidationError(ValueError):
    """
    Raised when a TypeID is invalid in some way
    """

    pass
