# IMPORTANT: This file is auto-generated. Do not edit directly.

from typing import Protocol, TypeVar, Any, Generic
import sqlmodel as sm
from sqlalchemy.sql.base import _NoArg
from typing import TYPE_CHECKING


class SQLAlchemyQueryMethods[T: sm.SQLModel](Protocol):
    pass
