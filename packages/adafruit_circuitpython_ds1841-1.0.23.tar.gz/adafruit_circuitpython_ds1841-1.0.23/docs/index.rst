.. include:: ../README.rst

Table of Contents
=================

.. toctree::
    :maxdepth: 4
    :hidden:

    self

.. toctree::
    :caption: Examples

    examples

.. toctree::
    :caption: API Reference
    :maxdepth: 3

    api

.. toctree::
    :caption: Tutorials

    Learn Guide <https://learn.adafruit.com/ds1841-i2c-potentiometer>

.. toctree::
    :caption: Related Products

    `Adafruit DS1841 <https://www.adafruit.com/product/4286>`_


.. toctree::
    :caption: Other Links

    Download from GitHub <https://github.com/adafruit/Adafruit_CircuitPython_DS1841/releases/latest>
    Download Library Bundle <https://circuitpython.org/libraries>
    CircuitPython Reference Documentation <https://docs.circuitpython.org>
    CircuitPython Support Forum <https://forums.adafruit.com/viewforum.php?f=60>
    Discord Chat <https://adafru.it/discord>
    Adafruit Learning System <https://learn.adafruit.com>
    Adafruit Blog <https://blog.adafruit.com>
    Adafruit Store <https://www.adafruit.com>

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
