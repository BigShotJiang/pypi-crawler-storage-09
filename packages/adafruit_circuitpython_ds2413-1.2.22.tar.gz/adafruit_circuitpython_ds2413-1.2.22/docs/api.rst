
.. If you created a package, create one automodule per module in the package.

API Reference
#############

.. automodule:: adafruit_ds2413
   :members:
