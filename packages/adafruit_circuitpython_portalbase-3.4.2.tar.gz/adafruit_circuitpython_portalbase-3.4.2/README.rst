Introduction
============

.. image:: https://readthedocs.org/projects/adafruit-circuitpython-portalbase/badge/?version=latest
    :target: https://docs.circuitpython.org/projects/portalbase/en/latest/
    :alt: Documentation Status

.. image:: https://raw.githubusercontent.com/adafruit/Adafruit_CircuitPython_Bundle/main/badges/adafruit_discord.svg
    :target: https://adafru.it/discord
    :alt: Discord

.. image:: https://github.com/adafruit/Adafruit_CircuitPython_PortalBase/workflows/Build%20CI/badge.svg
    :target: https://github.com/adafruit/Adafruit_CircuitPython_PortalBase/actions
    :alt: Build Status

.. image:: https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json
    :target: https://github.com/astral-sh/ruff
    :alt: Code Style: Ruff

Base Library for the Portal-style libraries. This library only contains base classes and is not
intended to be run on its own.


Dependencies
=============
This driver depends on:

* `Adafruit CircuitPython <https://github.com/adafruit/circuitpython>`_
* `Adafruit CircuitPython Bitmap Font <https://github.com/adafruit/Adafruit_CircuitPython_Bitmap_Font/>`_
* `Adafruit CircuitPython Connection Manager <https://github.com/adafruit/Adafruit_CircuitPython_ConnectionManager/>`_
* `Adafruit CircuitPython Display Text <https://github.com/adafruit/Adafruit_CircuitPython_Display_Text/>`_
* `Adafruit CircuitPython NeoPixel <https://github.com/adafruit/Adafruit_CircuitPython_NeoPixel/>`_
* `Adafruit CircuitPython Adafruit IO <https://github.com/adafruit/Adafruit_CircuitPython_AdafruitIO/>`_
* `Adafruit CircuitPython MiniQR <https://github.com/adafruit/Adafruit_CircuitPython_MiniQR/>`_
* `Adafruit CircuitPython Requests <https://github.com/adafruit/Adafruit_CircuitPython_Requests/>`_
* `Adafruit CircuitPython Fake Requests <https://github.com/adafruit/Adafruit_CircuitPython_FakeRequests/>`_
* `Adafruit CircuitPython SimpleIO <https://github.com/adafruit/Adafruit_CircuitPython_SimpleIO/>`_

Please ensure all dependencies are available on the CircuitPython filesystem.
This is easily achieved by downloading
`the Adafruit library and driver bundle <https://circuitpython.org/libraries>`_.

Installing from PyPI
=====================

On supported GNU/Linux systems like the Raspberry Pi, you can install the driver locally `from
PyPI <https://pypi.org/project/adafruit-circuitpython-portalbase/>`_. To install for current user:

.. code-block:: shell

    pip3 install adafruit-circuitpython-portalbase

To install system-wide (this may be required in some cases):

.. code-block:: shell

    sudo pip3 install adafruit-circuitpython-portalbase

To install in a virtual environment in your current project:

.. code-block:: shell

    mkdir project-name && cd project-name
    python3 -m venv .venv
    source .venv/bin/activate
    pip3 install adafruit-circuitpython-portalbase

Documentation
=============

API documentation for this library can be found on `Read the Docs <https://docs.circuitpython.org/projects/portalbase/en/latest/>`_.

For information on building library documentation, please check out `this guide <https://learn.adafruit.com/creating-and-sharing-a-circuitpython-library/sharing-our-docs-on-readthedocs#sphinx-5-1>`_.

Contributing
============

Contributions are welcome! Please read our `Code of Conduct
<https://github.com/adafruit/Adafruit_CircuitPython_PortalBase/blob/master/CODE_OF_CONDUCT.md>`_
before contributing to help this project stay welcoming.
