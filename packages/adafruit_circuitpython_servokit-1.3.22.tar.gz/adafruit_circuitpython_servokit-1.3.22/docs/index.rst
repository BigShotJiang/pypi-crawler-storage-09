.. include:: ../README.rst

Table of Contents
=================

.. toctree::
    :maxdepth: 4
    :hidden:

    self

.. toctree::
    :caption: Examples

    examples

.. toctree::
    :caption: API Reference
    :maxdepth: 3

    api

.. toctree::
    :caption: Tutorials

    Adafruit 8-channel PWM or Servo FeatherWing <https://learn.adafruit.com/adafruit-8-channel-pwm-or-servo-featherwing>
    Adafruit 16-Channel 12-bit PWM/Servo Shield <https://learn.adafruit.com/adafruit-16-channel-pwm-slash-servo-shield>
    Adafruit 16-Channel PWM/Servo HAT and Bonnet for Raspberry Pi <https://learn.adafruit.com/adafruit-16-channel-pwm-servo-hat-for-raspberry-pi>
    Adafruit PCA9685 16-Channel Servo Driver <https://learn.adafruit.com/16-channel-pwm-servo-driver>

.. toctree::
    :caption: Related Products

    8-Channel PWM or Servo FeatherWing <https://www.adafruit.com/product/2928>
    Adafruit 16-Channel 12-bit PWM/Servo Shield <https://www.adafruit.com/product/1411>
    Adafruit 16-Channel PWM/Servo HAT for Raspberry Pi <https://www.adafruit.com/product/2327>
    Adafruit 16-Channel PWM/Servo Bonnet for Raspberry Pi <https://www.adafruit.com/product/3416>

.. toctree::
    :caption: Other Links

    Download from GitHub <https://github.com/adafruit/Adafruit_CircuitPython_ServoKit/releases/latest>
    Download Library Bundle <https://circuitpython.org/libraries>
    CircuitPython Reference Documentation <https://docs.circuitpython.org>
    CircuitPython Support Forum <https://forums.adafruit.com/viewforum.php?f=60>
    Discord Chat <https://adafru.it/discord>
    Adafruit Learning System <https://learn.adafruit.com>
    Adafruit Blog <https://blog.adafruit.com>
    Adafruit Store <https://www.adafruit.com>

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
