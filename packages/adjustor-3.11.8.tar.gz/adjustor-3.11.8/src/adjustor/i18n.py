def _(arg: str):
    return arg
