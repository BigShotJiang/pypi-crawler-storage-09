# CHANGELOG

## v1.0.0 (2025-10-13)

- Initial Release
