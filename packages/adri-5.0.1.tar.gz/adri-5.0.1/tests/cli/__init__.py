"""Modern CLI tests package.

This package contains modernized CLI tests that use the command registry
pattern and proper path resolution, replacing the legacy test files.
"""
