"""Unit tests for dimension assessors."""
