"""ADRI standards package."""
