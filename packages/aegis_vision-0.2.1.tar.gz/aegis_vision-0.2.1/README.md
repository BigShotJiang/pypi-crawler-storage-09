# Aegis Vision

> Cloud-native computer vision model training toolkit for Aegis AI

[![PyPI version](https://badge.fury.io/py/aegis-vision.svg)](https://badge.fury.io/py/aegis-vision)
[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## Overview

**Aegis Vision** is a streamlined toolkit for training computer vision models in cloud environments (Kaggle, Colab, etc.) with built-in support for:

- 🎯 **YOLO Models** (v8, v9, v10, v11) - Object detection training
- 📊 **Wandb Integration** - Experiment tracking and visualization
- 🔄 **COCO Format** - Dataset conversion and handling
- ☁️ **Cloud-Optimized** - Designed for Kaggle/Colab workflows
- 📦 **Model Export** - ONNX, CoreML, OpenVINO, TensorRT, TFLite

## Installation

```bash
# Basic installation
pip install aegis-vision

# With Kaggle support
pip install aegis-vision[kaggle]

# Development installation
pip install aegis-vision[dev]

# All features
pip install aegis-vision[all]
```

## Quick Start

### Training a YOLO Model

```python
from aegis_vision import YOLOTrainer

# Initialize trainer
trainer = YOLOTrainer(
    model_variant="yolov11l",
    dataset_path="/kaggle/input/my-dataset",
    epochs=100,
    batch_size=16,
)

# Configure Wandb tracking (optional)
trainer.setup_wandb(
    project="my-project",
    entity="my-team",
    api_key="your-api-key"
)

# Train
results = trainer.train()

# Export to multiple formats
trainer.export(formats=["onnx", "coreml", "openvino"])
```

### Converting COCO to YOLO Format

```python
from aegis_vision import COCOConverter

# Convert dataset
converter = COCOConverter(
    annotations_file="annotations.json",
    images_dir="images/",
    output_dir="yolo_dataset/"
)

stats = converter.convert()
print(f"Converted {stats['total_annotations']} annotations")
```

### Command-Line Interface

```bash
# Train a model
aegis-train \
    --model yolov11l \
    --data /path/to/dataset \
    --epochs 100 \
    --batch 16 \
    --wandb-project my-project

# Convert COCO to YOLO
aegis-train convert-coco \
    --annotations annotations.json \
    --images images/ \
    --output yolo_dataset/
```

## Features

### 🎯 YOLO Training

- **Multi-version support**: YOLOv8, v9, v10, v11
- **Fine-tuning & from-scratch** training modes
- **Automatic augmentation** configuration
- **Early stopping** with patience
- **Validation metrics**: mAP50, mAP50-95, precision, recall

### 📊 Experiment Tracking

- **Wandb integration** for metrics, charts, and artifacts
- **Automatic logging** of hyperparameters, metrics, and model outputs
- **Run resumption** support

### 🔄 Dataset Handling

- **COCO format** support
- **Auto-conversion** to YOLO format
- **Label filtering** and validation
- **Dataset statistics** reporting

### 📦 Model Export

- **ONNX** - Cross-platform inference
- **CoreML** - iOS/macOS deployment
- **OpenVINO** - Intel hardware optimization
- **TensorRT** - NVIDIA GPU optimization
- **TFLite** - Mobile/edge deployment

### ☁️ Cloud Environment Support

- **Kaggle** - Kernel execution and dataset management
- **Google Colab** - Ready-to-use notebooks
- **Environment detection** - Auto-configuration for different platforms

## Configuration

### Training Configuration

```python
config = {
    # Model settings
    "model_variant": "yolov11l",
    "training_mode": "fine_tune",  # or "from_scratch"
    
    # Training hyperparameters
    "epochs": 100,
    "batch_size": 16,
    "img_size": 640,
    "learning_rate": 0.01,
    "momentum": 0.937,
    "weight_decay": 0.0005,
    
    # Augmentation
    "augmentation": {
        "hsv_h": 0.015,
        "hsv_s": 0.7,
        "hsv_v": 0.4,
        "degrees": 0.0,
        "translate": 0.1,
        "scale": 0.5,
        "shear": 0.0,
        "perspective": 0.0,
        "flipud": 0.0,
        "fliplr": 0.5,
        "mosaic": 1.0,
        "mixup": 0.0,
    },
    
    # Early stopping
    "early_stopping": {
        "enabled": True,
        "patience": 50,
        "min_delta": 0.0001
    },
    
    # Wandb
    "wandb_enabled": True,
    "wandb_project": "my-project",
    "wandb_entity": "my-team",
    
    # Export
    "output_formats": ["onnx", "coreml", "openvino"],
}

trainer = YOLOTrainer(**config)
```

## Examples

### Kaggle Kernel

```python
# In a Kaggle kernel
from aegis_vision import YOLOTrainer

trainer = YOLOTrainer(
    model_variant="yolov11l",
    dataset_path="/kaggle/input/my-dataset",
    epochs=100,
    wandb_api_key="/kaggle/input/secrets/wandb_api_key.txt"
)

results = trainer.train()
trainer.save_to_kaggle_output()
```

### Custom Dataset

```python
from aegis_vision import YOLOTrainer, COCOConverter

# 1. Convert your COCO dataset
converter = COCOConverter(
    annotations_file="my_annotations.json",
    images_dir="my_images/",
    output_dir="yolo_dataset/",
    labels_filter=["person", "car", "dog"]  # Optional filtering
)
converter.convert()

# 2. Train
trainer = YOLOTrainer(
    model_variant="yolov11m",
    dataset_path="yolo_dataset/",
    epochs=50,
)
results = trainer.train()
```

## API Reference

### YOLOTrainer

Main class for training YOLO models.

**Methods**:
- `train()` - Start training
- `setup_wandb()` - Configure Wandb tracking
- `export()` - Export trained model
- `validate()` - Run validation
- `get_metrics()` - Retrieve training metrics

### COCOConverter

Convert COCO format datasets to YOLO format.

**Methods**:
- `convert()` - Perform conversion
- `validate()` - Check dataset integrity
- `get_statistics()` - Dataset statistics

## Development

```bash
# Clone repository
git clone https://github.com/your-org/aegis-vision.git
cd aegis-vision

# Install in development mode
pip install -e ".[dev]"

# Run tests
pytest

# Format code
black src/

# Lint
ruff src/
```

## Contributing

Contributions are welcome! Please:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Roadmap

- [ ] Support for additional YOLO architectures
- [ ] Integration with Hugging Face Hub
- [ ] Distributed training support
- [ ] Auto-hyperparameter tuning
- [ ] Model quantization utilities
- [ ] Segmentation and pose estimation models
- [ ] Real-time inference utilities

## Citation

```bibtex
@software{aegis_vision,
  title = {Aegis Vision: Cloud-native Computer Vision Training Toolkit},
  author = {Aegis AI Team},
  year = {2025},
  url = {https://github.com/your-org/aegis-vision}
}
```

## Support

- 📧 Email: support@aegis-ai.com
- 💬 Discord: [Join our community](https://discord.gg/aegis-ai)
- 📚 Documentation: [https://aegis-vision.readthedocs.io](https://aegis-vision.readthedocs.io)
- 🐛 Issues: [GitHub Issues](https://github.com/your-org/aegis-vision/issues)


