# Copyright (c) Microsoft. All rights reserved.

"""Fanout workflow example."""
