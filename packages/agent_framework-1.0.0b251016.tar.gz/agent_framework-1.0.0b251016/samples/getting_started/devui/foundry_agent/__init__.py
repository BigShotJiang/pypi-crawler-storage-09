# Copyright (c) Microsoft. All rights reserved.

"""Weather agent sample for DevUI testing."""

from .agent import agent

__all__ = ["agent"]
