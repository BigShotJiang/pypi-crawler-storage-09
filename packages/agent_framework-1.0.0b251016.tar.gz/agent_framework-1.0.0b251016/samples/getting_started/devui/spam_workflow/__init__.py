# Copyright (c) Microsoft. All rights reserved.

"""Spam detection workflow sample for DevUI testing."""

from .workflow import workflow

__all__ = ["workflow"]
