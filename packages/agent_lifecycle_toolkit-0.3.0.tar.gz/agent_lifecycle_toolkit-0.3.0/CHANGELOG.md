# CHANGELOG

<!-- version list -->

## v0.2.0 (2025-10-16)


## v0.3.0 (2025-10-16)

- Reconciling package version with existing pypi releases

## v0.1.0 (2025-10-16)

### Features

- Adds direct litellm strings to ComponentConfig
  ([#12](https://github.com/AgentToolkit/agent-lifecycle-toolkit/pull/12),
  [`b38abe2`](https://github.com/AgentToolkit/agent-lifecycle-toolkit/commit/b38abe2636f17ff4776f43448b2db94d1a314c54))


## v0.0.0 (2025-10-15)

- Initial Release
