"""Tests for agentci-client-config package."""
