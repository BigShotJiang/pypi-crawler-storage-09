from enum import StrEnum


class ChunkingStrategy(StrEnum):
    AUTO = "auto"
    RECURSIVE_CHARACTER = "recursive_character"
