from typing import TypedDict


class ReasoningContentBlock(TypedDict):
    text: str
