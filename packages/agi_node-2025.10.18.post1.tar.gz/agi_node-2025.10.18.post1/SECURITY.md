# Security Policy

The AGI Node component is part of the AGILAB stack. For the latest security practices, supported
versions, and reporting guidance, refer to the root project policy located at:

```
../../../../SECURITY.md
```

Please follow those instructions when disclosing vulnerabilities or requesting hardening advice.
