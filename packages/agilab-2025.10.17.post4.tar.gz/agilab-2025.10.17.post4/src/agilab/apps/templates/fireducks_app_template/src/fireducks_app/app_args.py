"""Compatibility shim re-exporting :mod:`fireducks_app.fireducks_app_args`."""

from .fireducks_app_args import *  # noqa: F401,F403
