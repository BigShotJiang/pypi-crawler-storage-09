installation:

- Linux/MacOS:<br>
  chmod +x ./install.sh<br>
  ./install

- Python

uv run -_project ..\agilab\cluster python .\install.py <module>

Example with uv run -_project ../agilab/cluster python ./install.py flight<br>
uv run -_project ..\agilab\cluster python .\install.py agilab\cluster python .\install.py /uv
run
-_project ../agilab/cluster/manager python ./install.py flight