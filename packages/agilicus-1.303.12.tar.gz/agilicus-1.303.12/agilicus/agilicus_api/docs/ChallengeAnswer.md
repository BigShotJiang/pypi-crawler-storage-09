# ChallengeAnswer

An answer to a challenge. The meaning of the answer may vary based on the type of challenge issued. The user who was issued the challenge should response to the answer by posting an answer with proof of their ownership of the second factor to the answers endpoint of the Challenge. 

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**spec** | [**ChallengeAnswerSpec**](ChallengeAnswerSpec.md) |  | 
**any string name** | **bool, date, datetime, dict, float, int, list, str, none_type** | any string name can be used but the value must be the correct type | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


