# BulkDeleteLabelledObjectsResponse

Contains information about the result of deleting LabelledObjects in bulk. 

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number_objects_deleted** | **int** | The number of objects which were deleted | 
**number_labels_deleted** | **int** | The number of labels which were deleted because they were orphaned. | 
**any string name** | **bool, date, datetime, dict, float, int, list, str, none_type** | any string name can be used but the value must be the correct type | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


