"""
APIs for distributed communication, bookkeeping, and checkpointing.
"""
