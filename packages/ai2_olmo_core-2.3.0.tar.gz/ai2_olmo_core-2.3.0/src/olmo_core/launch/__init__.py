"""
An API for launching experiments on various platforms.
"""
