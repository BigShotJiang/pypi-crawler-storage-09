"""
Common :class:`torch.nn.Module` implementations.
"""
