"""Utilities for context generator."""
