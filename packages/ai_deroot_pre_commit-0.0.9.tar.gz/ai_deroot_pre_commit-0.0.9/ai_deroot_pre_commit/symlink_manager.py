
import argparse
import os
import sys
import shutil
from pathlib import Path

# --- Helper Functions ---

def get_symlink_configs(hidden_dir_name, file_list_str):
    """
    Generates a list of (source_path_rel, target_path_rel) tuples
    based on the hidden directory name and comma-separated file list.
    """
    hidden_dir = Path(hidden_dir_name)
    files = [Path(f.strip()) for f in file_list_str.split(',') if f.strip()]

    configs = []
    for file_name in files:
        source_rel = hidden_dir / file_name
        target_rel = file_name # Target is directly in the root
        configs.append((source_rel, target_rel))
    return configs

def print_message(level, message):
    """Prints messages to stderr with appropriate coloring."""
    if level == "ERROR":
        print(f"\033[91mERROR: {message}\033[0m", file=sys.stderr) # Red
    elif level == "WARNING":
        print(f"\033[93mWARNING: {message}\033[0m", file=sys.stderr) # Yellow
    else:
        print(f"\033[92mINFO: {message}\033[0m") # Green

# --- Main Hook Logic ---

def _create_symlink(source_path: Path, target_path: Path):
    """Create a symlink from target_path -> source_path (handles files and directories)."""
    try:
        # On Windows, target_is_directory must be set for directory symlinks
        os.symlink(
            str(source_path),
            str(target_path),
            target_is_directory=source_path.is_dir(),
        )
    except TypeError:
        # Older Python on some platforms doesn't support target_is_directory param
        target_path.symlink_to(source_path)


def setup_symlinks(hidden_dir_name, file_list_str, migrate: str | None = None):
    """
    Ensures symlinks are correctly set up from the hidden directory to the repo root.
    """
    print_message("INFO", "Running setup-managed-symlinks...")
    repo_root = Path(os.getcwd())
    symlink_configs = get_symlink_configs(hidden_dir_name, file_list_str)

    # Always ensure hidden directory exists (supports dot-prefixed like .ai, .llm, etc.)
    hidden_dir_path = repo_root / hidden_dir_name
    if not hidden_dir_path.exists():
        print_message("INFO", f"Hidden directory '{hidden_dir_name}' does not exist. Creating it.")
        hidden_dir_path.mkdir(parents=True, exist_ok=True)

    all_good = True
    for source_rel, target_rel in symlink_configs:
        source_path = repo_root / source_rel
        target_path = repo_root / target_rel

        # 1. If source does not exist, optionally migrate from target
        if not source_path.exists():
            if migrate and target_path.exists() and not target_path.is_symlink():
                # Prepare destination parent dirs
                source_path.parent.mkdir(parents=True, exist_ok=True)
                if migrate == "move":
                    print_message("INFO", f"Migrating (move) '{target_rel}' -> '{source_rel}'.")
                    shutil.move(str(target_path), str(source_path))
                elif migrate == "copy":
                    print_message("INFO", f"Migrating (copy) '{target_rel}' -> '{source_rel}'.")
                    if target_path.is_dir():
                        shutil.copytree(target_path, source_path)
                    else:
                        shutil.copy2(target_path, source_path)
                    # Remove original so we can create symlink in its place
                    if target_path.is_dir():
                        shutil.rmtree(target_path)
                    else:
                        target_path.unlink()
                else:
                    print_message("WARNING", f"Unknown migrate option '{migrate}'. Skipping migration for '{target_rel}'.")
                    continue

                # Create symlink at target pointing to source
                _create_symlink(source_path, target_path)
                continue
            else:
                print_message("INFO", f"Source file '{source_rel}' does not exist. Skipping symlink creation for '{target_rel}'.")
                continue

        # 3. Manage the target symlink in the root
        if target_path.is_symlink():
            # Already a symlink, check if it's correct
            if target_path.resolve() != source_path.resolve():
                print_message("WARNING", f"Symlink '{target_rel}' points to '{target_path.resolve()}', but expected '{source_path.resolve()}'. Recreating.")
                target_path.unlink() # Remove old symlink
                _create_symlink(source_path, target_path)
        elif target_path.exists():
            # A real file exists where a symlink should be
            if migrate in {"copy", "move"}:
                # If source exists and migrate is requested, do not overwrite source; require manual resolution
                print_message("WARNING", f"'{target_rel}' exists as a real file/dir and source '{source_rel}' also exists. Skipping automatic migration. Please resolve manually.")
                all_good = False
            else:
                print_message("WARNING", f"Real file '{target_rel}' exists where a symlink to '{source_rel}' is expected. Please remove '{target_rel}' manually if it's not needed, or ensure it's correctly ignored in .gitignore if it's a tracked file.")
                all_good = False
        else:
            # No file/symlink exists, create it
            print_message("INFO", f"Creating symlink: {target_rel} -> {source_rel}")
            _create_symlink(source_path, target_path)

    return 0 if all_good else 1


def check_symlinks_valid(hidden_dir_name, file_list_str):
    """
    Checks if the symlinks in the repo root are valid and point to the correct sources.
    """
    print_message("INFO", "Running check-managed-symlinks...")
    repo_root = Path(os.getcwd())
    symlink_configs = get_symlink_configs(hidden_dir_name, file_list_str)

    all_good = True
    for source_rel, target_rel in symlink_configs:
        source_path = repo_root / source_rel
        target_path = repo_root / target_rel

        # Skip validation if source file doesn't exist (same logic as setup)
        if not source_path.exists():
            continue

        # If target doesn't exist at all, that's fine - skip
        if not target_path.exists():
            continue

        # If target exists but is not a symlink, that's an error
        if not target_path.is_symlink():
            print_message("ERROR", f"'{target_rel}' exists but is not a symlink. Expected symlink to '{source_rel}'.")
            all_good = False
        elif target_path.resolve() != source_path.resolve():
            print_message("ERROR", f"Symlink '{target_rel}' points to '{target_path.resolve()}', but expected '{source_path.resolve()}'.")
            all_good = False

    if not all_good:
        print_message("ERROR", "\nPlease run 'pre-commit install --hook-type post-checkout' or 'pre-commit run --hook-stage post-checkout setup-managed-symlinks' to fix symlinks.")
        return 1
    return 0

def update_gitignore(hidden_dir_name, file_list_str):
    """
    Ensures the .gitignore file includes entries for the managed symlinks.
    """
    print_message("INFO", "Running update-gitignore-for-symlinks...")
    repo_root = Path(os.getcwd())
    gitignore_path = repo_root / ".gitignore"
    symlink_configs = get_symlink_configs(hidden_dir_name, file_list_str)

    # Get the target names (the symlinks in the root)
    symlink_targets = {str(target_rel) for _, target_rel in symlink_configs}

    # Read existing .gitignore content
    if gitignore_path.exists():
        with open(gitignore_path, 'r') as f:
            lines = [line.strip() for line in f]
    else:
        lines = []

    # Identify missing entries
    missing_entries = []
    for target in symlink_targets:
        if f"/{target}" not in lines:
            missing_entries.append(target)

    if missing_entries:
        print_message("INFO", f"Adding missing symlink entries to .gitignore: {', '.join(missing_entries)}")
        with open(gitignore_path, 'a') as f:
            f.write(
                "\n# Root-level symlinks managed by unroot-llm-files-pre-commit hook\n"
                f"# These are symlinks pointing to files in {hidden_dir_name}/ and should not be committed\n"
                f"# The actual files are stored in {hidden_dir_name}/ - commit changes there instead\n"
            )
            for entry in missing_entries:
                f.write(f"/{entry}\n")
        print_message("INFO", ".gitignore updated. Please stage and commit the changes to .gitignore.")
        return 1 # Indicate that .gitignore was modified
    else:
        print_message("INFO", "All managed symlinks are already in .gitignore.")
        return 0


# --- Main Entry Point ---

def main():
    parser = argparse.ArgumentParser(description="Manage symlinks for files in a hidden directory.")
    parser.add_argument(
        "action",
        choices=["setup", "check", "update-gitignore"],
        help="Action to perform: 'setup' symlinks, 'check' their validity, or 'update-gitignore'."
    )
    parser.add_argument(
        "--hidden-dir",
        required=True,
        help="The name of the directory where master files are stored (e.g., .claude)."
    )
    parser.add_argument(
        "--files",
        required=True,
        help="Comma-separated list of file names to manage (e.g., tool_config.json,another_tool_file.txt)."
    )
    parser.add_argument(
        "--migrate",
        choices=["copy", "move"],
        help="If set (for 'setup' only), migrate existing root files into the hidden directory before creating symlinks. 'copy' leaves originals; 'move' relocates them."
    )
    args = parser.parse_args()

    if args.action == "setup":
        sys.exit(setup_symlinks(args.hidden_dir, args.files, args.migrate))
    elif args.action == "check":
        sys.exit(check_symlinks_valid(args.hidden_dir, args.files))
    elif args.action == "update-gitignore":
        sys.exit(update_gitignore(args.hidden_dir, args.files))

if __name__ == "__main__":
    main()
