"""AI-powered Language Server with intelligent diagnostics."""

__version__ = "0.1.0"
