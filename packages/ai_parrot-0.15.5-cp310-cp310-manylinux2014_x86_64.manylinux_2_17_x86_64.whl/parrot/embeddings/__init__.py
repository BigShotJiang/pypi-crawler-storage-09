from .huggingface import SentenceTransformerModel

supported_embeddings = {
    'huggingface': 'SentenceTransformerModel',
}
