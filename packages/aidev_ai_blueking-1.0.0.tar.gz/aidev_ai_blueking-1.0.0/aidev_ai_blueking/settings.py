# -*- coding: utf-8 -*-

# 应用模块
INSTALLED_APPS = ("aidev_ai_blueking",)
