# This file makes the app/tasks directory a Python package
from .worker import celery_app