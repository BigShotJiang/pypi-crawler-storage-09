"""Budget management module for AII."""

from .budget_manager import BudgetManager

__all__ = ["BudgetManager"]
