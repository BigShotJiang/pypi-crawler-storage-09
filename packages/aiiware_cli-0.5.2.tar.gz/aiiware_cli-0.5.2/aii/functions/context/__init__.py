"""Context Functions - Fundamental data gathering functions for universal system"""
