from __future__ import annotations

version: str = '1.0.2'
