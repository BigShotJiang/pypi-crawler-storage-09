from aiogqlc.client import GraphQLClient

__all__ = ["GraphQLClient"]
