GRAPHQL_WS = "graphql-ws"
