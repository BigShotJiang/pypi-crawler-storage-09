# **Reporting Security Issues**

The project's team and community take security issues.

We appreciate your efforts to disclose your findings responsibly and will make every effort to acknowledge your contributions.

If your report could leak data or might expose how to gain access to a restricted area or break the system, please
send a message to my telegram - https://t.me/lores1337.

We'll endeavour to respond quickly and keep you updated throughout the process.
