# THIS CODE WAS AUTO-GENERATED VIA `butcher`

from datetime import datetime, timedelta
from typing import (
    TYPE_CHECKING,
    Any,
    Optional,
    Union,
)

from aiogram.client.default import Default
from aiogram.methods import (
    ForwardMessage,
)
from aiogram.types import (
    SuggestedPostParameters,
)

from .base import BaseContent


class FromChatForwardMessageContent(BaseContent):
    from_chat_id: Union[int, str]
    message_id: int
    video_start_timestamp: Optional[Union[datetime, timedelta, int]] = None
    disable_notification: Optional[bool] = None
    protect_content: Optional[Union[bool, Default]] = Default("protect_content")
    suggested_post_parameters: Optional[SuggestedPostParameters] = None

    async def __call__(self, chat_id: int) -> ForwardMessage:
        return ForwardMessage(
            chat_id=chat_id,
            from_chat_id=self.from_chat_id,
            message_id=self.message_id,
            video_start_timestamp=self.video_start_timestamp,
            disable_notification=self.disable_notification,
            protect_content=self.protect_content,
            suggested_post_parameters=self.suggested_post_parameters,
            **(self.model_extra or {}),
        )

    if TYPE_CHECKING:

        def __init__(
            self,
            *,
            from_chat_id: Union[int, str],
            message_id: int,
            video_start_timestamp: Optional[Union[datetime, timedelta, int]] = ...,
            disable_notification: Optional[bool] = ...,
            protect_content: Optional[Union[bool, Default]] = ...,
            suggested_post_parameters: Optional[SuggestedPostParameters] = ...,
            **kwargs: Any,
        ) -> None: ...
