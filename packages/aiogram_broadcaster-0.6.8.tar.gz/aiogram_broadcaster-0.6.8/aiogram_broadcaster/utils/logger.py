from logging import getLogger


logger = getLogger(name="aiogram_broadcaster")
