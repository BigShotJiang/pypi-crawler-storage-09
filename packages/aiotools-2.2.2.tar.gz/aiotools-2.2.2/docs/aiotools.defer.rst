Async Deferred Function Tools
=============================

.. automodule:: aiotools.defer

.. currentmodule:: aiotools.defer

.. autofunction:: aiotools.defer.defer

.. autofunction:: aiotools.defer.adefer
