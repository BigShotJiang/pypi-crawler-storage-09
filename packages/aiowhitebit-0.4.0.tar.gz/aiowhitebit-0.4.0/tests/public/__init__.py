"""Public API tests."""
