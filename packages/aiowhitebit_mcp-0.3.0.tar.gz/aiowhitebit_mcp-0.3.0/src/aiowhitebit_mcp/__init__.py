"""MCP server and client implementation for WhiteBit cryptocurrency exchange API.

Provides Message Control Protocol (MCP) server and client for WhiteBit exchange.
"""

__version__ = "0.2.8"
