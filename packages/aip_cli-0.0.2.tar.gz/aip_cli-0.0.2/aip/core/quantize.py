# aip-cli quantize service model
