# aip-cli train service model
