#
# Copyright (c) 2023 Airbyte, Inc., all rights reserved.
#

ENV_REQUEST_CACHE_PATH = "REQUEST_CACHE_PATH"
