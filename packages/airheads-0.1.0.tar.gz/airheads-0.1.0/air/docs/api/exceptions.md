# Exceptions

::: air.exceptions
