from __future__ import annotations
import os
from pathlib import Path
from typing import Dict, Iterable, Optional

def _parse_env_file(p: Path) -> Dict[str, str]:
    data: Dict[str, str] = {}
    try:
        for raw in p.read_text(encoding="utf-8").splitlines():
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if "=" not in line:
                continue
            k, v = line.split("=", 1)
            k = k.strip()
            v = v.strip().strip('"').strip("'")
            if k:
                data[k] = v
    except Exception:
        # ignore parse errors to keep CLI resilient
        pass
    return data


def _candidate_paths() -> Iterable[Path]:
    cwd = Path.cwd()
    home = Path.home()

    # Windows system drive root (e.g., C:\airoboEnv)
    sys_drive = os.environ.get("SystemDrive", "C:")
    root_env = Path(sys_drive + "\\") / "airoboEnv"

    # Windows roaming appdata fallback
    appdata = os.environ.get("APPDATA")
    appdata_env = Path(appdata) / "airobo" / ".env" if appdata else None

    # Explicit override takes precedence
    custom = os.environ.get("AIROBO_ENV_PATH")
    if custom:
        yield Path(custom)

    # Common names/locations (first found wins)
    for p in (
        cwd / ".env",
        cwd / "airoboEnv",
        home / ".env",
        home / "airoboEnv",
        root_env,
        appdata_env,
    ):
        if p:
            yield p


def load_env_from_known_locations(verbose: bool = False, keys: Optional[Iterable[str]] = None) -> None:
    """
    Load env vars from the first existing file among:
      - ./.env, ./airoboEnv
      - ~/.env, ~/airoboEnv
      - C:\airoboEnv (Windows)
      - %APPDATA%\airobo\.env (Windows)
    Does not override already-set environment variables.
    To force a path, set AIROBO_ENV_PATH to a specific file.
    Optionally pass `keys` to restrict which vars to import.
    """
    wanted = set(k.lower() for k in (keys or ()))
    for path in _candidate_paths():
        try:
            if not path or not path.exists():
                continue
            data = _parse_env_file(path)
            if not data:
                continue
            applied_any = False
            for k, v in data.items():
                if wanted and k.lower() not in wanted:
                    continue
                if k not in os.environ:
                    os.environ[k] = v
                    applied_any = True
            if applied_any and verbose:
                print(f"🔎 Loaded environment from: {path}")
            if applied_any:
                break  # stop at first file that provided values
        except Exception:
            # fail-quietly to avoid blocking CLI
            continue
