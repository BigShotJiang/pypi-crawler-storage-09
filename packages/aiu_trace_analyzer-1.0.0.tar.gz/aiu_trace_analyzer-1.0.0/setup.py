# Copyright 2024-2025 IBM Corporation

from setuptools import setup

setup()
