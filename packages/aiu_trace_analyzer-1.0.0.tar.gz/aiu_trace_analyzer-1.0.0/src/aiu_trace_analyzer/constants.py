# Copyright 2024-2025 IBM Corporation


# first entry None to make index 3 get TS3
TS_KEYS_LIST = [None, "TS1", "TS2", "TS3", "TS4", "TS5"]


# used for cycle-TS when computing power
TS_CYCLE_KEY = "TS_cycles"
