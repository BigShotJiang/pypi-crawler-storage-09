from pathlib import Path

dist_path = Path(__file__).parent / "dist"
