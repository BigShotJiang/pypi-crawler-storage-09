Copyright (c) 2025 The T&O Synergic Metaverse

All rights reserved.

This software is proprietary and confidential. Unauthorized copying, distribution, modification,
or use of this software, via any medium, is strictly prohibited without the express written
permission of the author.