from alas_ce0.common.client_base import EntityClientBase


class ResourceClient(EntityClientBase):
    entity_endpoint_base_url = '/management/resources/'
