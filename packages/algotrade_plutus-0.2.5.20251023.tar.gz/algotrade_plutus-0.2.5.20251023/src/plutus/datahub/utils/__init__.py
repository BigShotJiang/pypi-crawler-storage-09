"""Utility functions for datahub."""
