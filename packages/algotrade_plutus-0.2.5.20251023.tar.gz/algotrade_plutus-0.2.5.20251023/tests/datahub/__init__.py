"""Tests for datahub module."""
