# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from darabonba.model import DaraModel

class SubmitDocParserJobShrinkRequest(DaraModel):
    def __init__(
        self,
        custom_oss_config_shrink: str = None,
        enhancement_mode: str = None,
        file_name: str = None,
        file_name_extension: str = None,
        file_url: str = None,
        formula_enhancement: bool = None,
        llmparam_shrink: str = None,
        llm_enhancement: bool = None,
        multimedia_parameters_shrink: str = None,
        need_header_footer: bool = None,
        option: str = None,
        oss_bucket: str = None,
        oss_endpoint: str = None,
        output_html_table: bool = None,
        page_index: str = None,
    ):
        self.custom_oss_config_shrink = custom_oss_config_shrink
        self.enhancement_mode = enhancement_mode
        self.file_name = file_name
        self.file_name_extension = file_name_extension
        self.file_url = file_url
        self.formula_enhancement = formula_enhancement
        self.llmparam_shrink = llmparam_shrink
        self.llm_enhancement = llm_enhancement
        self.multimedia_parameters_shrink = multimedia_parameters_shrink
        self.need_header_footer = need_header_footer
        self.option = option
        self.oss_bucket = oss_bucket
        self.oss_endpoint = oss_endpoint
        self.output_html_table = output_html_table
        self.page_index = page_index

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.custom_oss_config_shrink is not None:
            result['CustomOssConfig'] = self.custom_oss_config_shrink

        if self.enhancement_mode is not None:
            result['EnhancementMode'] = self.enhancement_mode

        if self.file_name is not None:
            result['FileName'] = self.file_name

        if self.file_name_extension is not None:
            result['FileNameExtension'] = self.file_name_extension

        if self.file_url is not None:
            result['FileUrl'] = self.file_url

        if self.formula_enhancement is not None:
            result['FormulaEnhancement'] = self.formula_enhancement

        if self.llmparam_shrink is not None:
            result['LLMParam'] = self.llmparam_shrink

        if self.llm_enhancement is not None:
            result['LlmEnhancement'] = self.llm_enhancement

        if self.multimedia_parameters_shrink is not None:
            result['MultimediaParameters'] = self.multimedia_parameters_shrink

        if self.need_header_footer is not None:
            result['NeedHeaderFooter'] = self.need_header_footer

        if self.option is not None:
            result['Option'] = self.option

        if self.oss_bucket is not None:
            result['OssBucket'] = self.oss_bucket

        if self.oss_endpoint is not None:
            result['OssEndpoint'] = self.oss_endpoint

        if self.output_html_table is not None:
            result['OutputHtmlTable'] = self.output_html_table

        if self.page_index is not None:
            result['PageIndex'] = self.page_index

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('CustomOssConfig') is not None:
            self.custom_oss_config_shrink = m.get('CustomOssConfig')

        if m.get('EnhancementMode') is not None:
            self.enhancement_mode = m.get('EnhancementMode')

        if m.get('FileName') is not None:
            self.file_name = m.get('FileName')

        if m.get('FileNameExtension') is not None:
            self.file_name_extension = m.get('FileNameExtension')

        if m.get('FileUrl') is not None:
            self.file_url = m.get('FileUrl')

        if m.get('FormulaEnhancement') is not None:
            self.formula_enhancement = m.get('FormulaEnhancement')

        if m.get('LLMParam') is not None:
            self.llmparam_shrink = m.get('LLMParam')

        if m.get('LlmEnhancement') is not None:
            self.llm_enhancement = m.get('LlmEnhancement')

        if m.get('MultimediaParameters') is not None:
            self.multimedia_parameters_shrink = m.get('MultimediaParameters')

        if m.get('NeedHeaderFooter') is not None:
            self.need_header_footer = m.get('NeedHeaderFooter')

        if m.get('Option') is not None:
            self.option = m.get('Option')

        if m.get('OssBucket') is not None:
            self.oss_bucket = m.get('OssBucket')

        if m.get('OssEndpoint') is not None:
            self.oss_endpoint = m.get('OssEndpoint')

        if m.get('OutputHtmlTable') is not None:
            self.output_html_table = m.get('OutputHtmlTable')

        if m.get('PageIndex') is not None:
            self.page_index = m.get('PageIndex')

        return self

