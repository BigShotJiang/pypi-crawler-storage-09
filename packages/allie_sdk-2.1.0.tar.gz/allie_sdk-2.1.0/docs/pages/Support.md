---
title: Support
nav_order: 6
---

# Support
{:.no_toc}

## Getting support 
This is an **open source** project under the [APACHE 2.0 License](https://apache.org/licenses/LICENSE-2.0) and is maintained by everyone in the Alation community. If you encounter a problem or something is not working as expected, open a [GitHub issue](https://github.com/Alation/Allie-SDK/issues) on this repo. Please **DO NOT** create an Alation support case.