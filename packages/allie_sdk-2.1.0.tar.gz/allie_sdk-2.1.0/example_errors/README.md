# Info

This folder contains examples of "making the code fail" so that you better understand the error messages.

Some of these cases are covered by unit tests as well, however, the unit tests always fake the request call, so these examples here help to test the whole flow completely.