# Initial Setup

Rename config.ini.sample to config.ini and adjust the settings.

Adjust the config settings in each example file. Each file will list any prerequisites that are required for running the code - these are listed at the beginning of the file.





