# SPDX-FileCopyrightText: 2022 German Aerospace Center <amiris@dlr.de>
#
# SPDX-License-Identifier: CC0-1.0

"""Hosts all sources and scripts for AMIRIS-Py."""
