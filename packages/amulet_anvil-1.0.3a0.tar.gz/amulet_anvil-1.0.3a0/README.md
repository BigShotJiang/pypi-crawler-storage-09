# Amulet Anvil

A C++ library with Python wrapper for the Minecraft Anvil format.
