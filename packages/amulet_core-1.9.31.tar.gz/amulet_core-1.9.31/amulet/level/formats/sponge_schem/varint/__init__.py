from .varint import decode_stream, decode_bytes, decode_byte_array, encode_array
