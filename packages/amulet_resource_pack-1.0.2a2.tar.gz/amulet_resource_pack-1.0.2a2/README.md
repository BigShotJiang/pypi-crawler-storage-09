# Amulet Resource Pack

A Python and C++ library for interacting with Minecraft resource packs.
