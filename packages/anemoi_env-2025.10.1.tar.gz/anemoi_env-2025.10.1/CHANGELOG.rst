=========
Changelog
=========

Version 2025.10.1 (2025-10-17)
==============================

Anemoi Package Versions
------------------------

* **anemoi-datasets**: ``0.5.27``
* **anemoi-graphs**: ``0.7.0``
* **anemoi-inference**: ``0.8.0``
* **anemoi-models**: ``0.9.6``
* **anemoi-registry**: ``0.2.2``
* **anemoi-training**: ``0.6.6``
* **anemoi-transform**: ``0.1.17``
* **anemoi-utils**: ``0.4.37``

Version 2025.10 (2025-10-13)
============================

Anemoi Package Versions
------------------------

* **anemoi-datasets**: ``0.5.27``
* **anemoi-graphs**: ``0.7.0``
* **anemoi-inference**: ``0.7.3``
* **anemoi-models**: ``0.9.6``
* **anemoi-registry**: ``0.2.2``
* **anemoi-training**: ``0.6.6``
* **anemoi-transform**: ``0.1.17``
* **anemoi-utils**: ``0.4.37``
