# anipy-api
This is the api package for [anipy-cli](https://pypi.org/project/anipy-cli/).

Find documentation here: [https://sdaqo.github.io/anipy-cli/getting-started-api](https://sdaqo.github.io/anipy-cli/getting-started-api)
