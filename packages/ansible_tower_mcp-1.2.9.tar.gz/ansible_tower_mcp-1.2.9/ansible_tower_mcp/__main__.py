#!/usr/bin/python
# coding: utf-8
from ansible_tower_mcp.ansible_tower_mcp import ansible_tower_mcp

if __name__ == "__main__":
    ansible_tower_mcp()
