---
category: {{ scripting_info.category }}
plugin: {{ scripting_info.plugin }}
license: {{ scripting_info.license }}
---

# {{ operator_name }}

**Version: {{ scripting_info.version }}**

## Description

{{ operator_description }}

## Inputs

| Input | Name | Expected type(s) | Description |
|-------|-------|------------------|-------------|
{%- for input in inputs %}
| {% if not input.optional %}<strong>Pin {{ input.pin_number }}</strong> <br><span style="background-color:#d93025; color:white; padding:2px 6px; border-radius:3px; font-size:0.75em;">Required</span>{% else %}<strong>Pin {{ input.pin_number }}</strong>{% endif %}|  {{ input.name }} |
{%- for t in input.types -%}{% if "::" in t or t == "materials_container" or t == "materials" or t == "binary_operation_enum" or t == "umap<int32,int32>" or t == "stream" or t == "vector<shared_ptr<any_collection>>" or t == "vector<shared_ptr<field>>" or t == "umap<string,shared_ptr<abstract_field_support>>" or t == "vector<shared_ptr<abstract_meshed_region>>" or t == "vector<shared_ptr<materials>>" or t == "ans_dispatch_holder" or t == "struct IAnsDispatch" or t == "abstract_field_support" or t == "vector<shared_ptr<fields_container>>" or t == "vector<shared_ptr<data_tree>>" or t == "vector<shared_ptr<generic_data_container>>" or t == "vector<shared_ptr<time_freq_support>>" or t == "mesh_selection_manager" or t == "vector<shared_ptr<abstract_field_support>>" or t == "vector<shared_ptr<string_field>>" or t == "vector<shared_ptr<scopings_container>>" or t == "vector<shared_ptr<scoping>>" or t == "vector<shared_ptr<result_info>>" or t == "vector<shared_ptr<meshes_container>>" or t == "vector<shared_ptr<property_field>>" %}`{{ t }}`{% elif t == "int32" or t == "bool" or t == "char" or t == "double" or t == "string" or t == "uint32" or t == "uint64" or t == "vector<int32>" or t == "vector<bool>" or t == "vector<char>" or t == "vector<double>" or t == "vector<string>" or t == "vector<float>" %}[`{{ t }}`](../../core-concepts/dpf-types.md#standard-types){% elif t.startswith("abstract_") %}[`{{ t }}`](../../core-concepts/dpf-types.md#{{ t | replace("abstract_", "") | replace("_", "-") | replace (" ", "-") | lower}}){% else %}[`{{ t }}`](../../core-concepts/dpf-types.md#{{ t | replace("_", "-") | replace(" ", "-") | lower}}){% endif %}{% if not loop.last %}, {% endif %}{%- endfor %} | {{ input.document | replace("\n", "<br>") }} |
{%- endfor %}

## Outputs

| Output |  Name | Expected type(s) | Description |
|-------|------|------------------|-------------|
{%- for output in outputs %}
|  **Pin {{ output.pin_number }}**| {{ output.name }} |
{%- for t in output.types -%}{% if "::" in t or t == "materials_container" or t == "materials" or t == "binary_operation_enum" or t == "umap<int32,int32>" or t == "stream" or t == "vector<shared_ptr<any_collection>>" or t == "vector<shared_ptr<field>>" or t == "umap<string,shared_ptr<abstract_field_support>>" or t == "vector<shared_ptr<abstract_meshed_region>>" or t == "vector<shared_ptr<materials>>" or t == "ans_dispatch_holder" or t == "struct IAnsDispatch" or t == "abstract_field_support" or t == "vector<shared_ptr<fields_container>>" or t == "vector<shared_ptr<data_tree>>" or t == "vector<shared_ptr<generic_data_container>>" or t == "vector<shared_ptr<time_freq_support>>" or t == "mesh_selection_manager" or t == "vector<shared_ptr<abstract_field_support>>" or t == "vector<shared_ptr<string_field>>" or t == "vector<shared_ptr<scopings_container>>" or t == "vector<shared_ptr<scoping>>" or t == "vector<shared_ptr<result_info>>" or t == "vector<shared_ptr<meshes_container>>" or t == "vector<shared_ptr<property_field>>" %}`{{ t }}`{% elif t == "int32" or t == "bool" or t == "char" or t == "double" or t == "string" or t == "uint32" or t == "uint64" or t == "vector<int32>" or t == "vector<bool>" or t == "vector<char>" or t == "vector<double>" or t == "vector<string>" or t == "vector<float>" %}[`{{ t }}`](../../core-concepts/dpf-types.md#standard-types){% elif t.startswith("abstract_") %}[`{{ t }}`](../../core-concepts/dpf-types.md#{{ t | replace("abstract_", "") | replace("_", "-") | replace (" ", "-") | lower}}){% else %}[`{{ t }}`](../../core-concepts/dpf-types.md#{{ t | replace("_", "-") | replace(" ", "-") | lower}}){% endif %}{% if not loop.last %}, {% endif %}{%- endfor %} | {{ output.document }} |
{%- endfor %}

## Configurations

| Name| Expected type(s) | Default value | Description |
|-----|------|----------|-------------|
{%- for configuration in configurations %}
| **{{ configuration.name }}** |
{%- for t in configuration.types -%}{% if "::" in t or t == "materials_container" or t == "materials" or t == "binary_operation_enum" or t == "umap<int32,int32>" or t == "stream" or t == "vector<shared_ptr<any_collection>>" or t == "vector<shared_ptr<field>>" or t == "umap<string,shared_ptr<abstract_field_support>>" or t == "vector<shared_ptr<abstract_meshed_region>>" or t == "vector<shared_ptr<materials>>" or t == "ans_dispatch_holder" or t == "struct IAnsDispatch" or t == "abstract_field_support" or t == "vector<shared_ptr<fields_container>>" or t == "vector<shared_ptr<data_tree>>" or t == "vector<shared_ptr<generic_data_container>>" or t == "vector<shared_ptr<time_freq_support>>" or t == "mesh_selection_manager" or t == "vector<shared_ptr<abstract_field_support>>" or t == "vector<shared_ptr<string_field>>" or t == "vector<shared_ptr<scopings_container>>" or t == "vector<shared_ptr<scoping>>" or t == "vector<shared_ptr<result_info>>" or t == "vector<shared_ptr<meshes_container>>" or t == "vector<shared_ptr<property_field>>" %}`{{ t }}`{% elif t == "int32" or t == "bool" or t == "char" or t == "double" or t == "string" or t == "uint32" or t == "uint64" or t == "vector<int32>" or t == "vector<bool>" or t == "vector<char>" or t == "vector<double>" or t == "vector<string>" or t == "vector<float>" %}[`{{ t }}`](../../core-concepts/dpf-types.md#standard-types){% elif t.startswith("abstract_") %}[`{{ t }}`](../../core-concepts/dpf-types.md#{{ t | replace("abstract_", "") | replace("_", "-") | replace (" ", "-") | lower}}){% else %}[`{{ t }}`](../../core-concepts/dpf-types.md#{{ t | replace("_", "-") | replace(" ", "-") | lower}}){% endif %}{% if not loop.last %}, {% endif %}{%- endfor %} | {{ configuration.default_value }} | {{ configuration.document }} |
{%- endfor %}

## Scripting

 **Category**: {{ scripting_info.category }}

 **Plugin**: {{ scripting_info.plugin }}

 **Scripting name**: {{ scripting_info.scripting_name }}

 **Full name**: {{ scripting_info.full_name }}

 **Internal name**: {{ scripting_info.internal_name }}

 **License**: {{ scripting_info.license }}


## Changelog

{%- for entry in scripting_info.changelog %}

- {{ entry }}
{%- endfor %}
