Data types
==========

.. automodule:: ansys.simai.core.data.types
  :members:
