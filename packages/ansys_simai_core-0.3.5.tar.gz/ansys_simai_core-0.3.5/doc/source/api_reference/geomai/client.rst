.. _geomai_client:

Currently GeomAI is accessible through the nested GeomAI client inside SimAI.

.. warning::
    GeomAI is currently in beta testing and only available to select customers.
    Please contact your Ansys representative for additional information and access.

GeomAIClient
============

.. py:module:: ansys.simai.core.data.geomai.client

.. autoclass:: GeomAIClient()
    :members:
