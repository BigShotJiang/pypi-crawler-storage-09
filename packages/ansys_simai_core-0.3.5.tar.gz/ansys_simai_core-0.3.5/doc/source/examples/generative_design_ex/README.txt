

Generative Design feature examples
----------------------------------

This section provides a collection of practical script examples illustrating the Generative Design feature of SimAI.
They serve as a reference guide for users to implement similar solutions in their projects.
