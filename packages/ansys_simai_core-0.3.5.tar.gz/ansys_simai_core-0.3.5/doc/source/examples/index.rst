.. _ref_examples:

========
Examples
========


.. include:: ../_examples/pysimai_ex/index.rst
   :start-line: 2


.. include:: ../_examples/generative_design_ex/index.rst
   :start-line: 2