.. _ref_user_guide:

User guide
==========


.. toctree::
   :maxdepth: 2

   user_guide/installation
   user_guide/configuration
   user_guide/config_file
   user_guide/proxy
   user_guide/pysimai_ug/index
   user_guide/automorphing/index
   user_guide/generative_design_ug/index
