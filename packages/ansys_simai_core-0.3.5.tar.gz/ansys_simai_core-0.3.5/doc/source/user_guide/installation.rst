Installation
============

.. note::
    PySimAI requires Python 3.9 or later.


Install PySimAI with this command:

.. code-block:: bash

   pip install ansys-simai-core --upgrade

Use this same command every time you want to update PySimAI.