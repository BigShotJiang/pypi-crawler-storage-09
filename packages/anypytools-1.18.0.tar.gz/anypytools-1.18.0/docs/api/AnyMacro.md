# anypytools.AnyMacro

See {doc}`macro_commands` for a list of classes that generate macro commands.

```{eval-rst}
.. autoclass:: anypytools.AnyMacro
    :members:
    :noindex:







```
