# anypytools.datautils.anydatah5_generator

```{eval-rst}
.. autofunction:: anypytools.datautils.anydatah5_generator
    :noindex:
```
