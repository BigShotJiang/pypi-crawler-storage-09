# anypytools.datautils.anyoutputfile_generator

```{eval-rst}
.. autofunction:: anypytools.datautils.anyoutputfile_generator
    :noindex:
```
