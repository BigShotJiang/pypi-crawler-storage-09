# anypytools.datautils.read_anyoutputfile

```{eval-rst}
.. autofunction:: anypytools.datautils.read_anyoutputfile
    :noindex:
```
