# Dependencies

AnyPyTools currently has the following external dependencies,

*Run Time:*

> - [Python v3.6+](https://www.python.org/)
> - [Numpy](http://www.numpy.org/)
> - [SciPy\*](https://www.scipy.org/)
> - [PyDOE\*](https://pythonhosted.org/pyDOE/)
> - [h5py\*](http://www.h5py.org/)

:::{note}
Packages markerd with (\*) are partly optional and only used in specific parts of the library.
:::
