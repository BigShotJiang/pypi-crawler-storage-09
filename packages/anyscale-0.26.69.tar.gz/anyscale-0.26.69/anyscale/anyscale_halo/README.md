source code copied out from halo==0.0.31
