"""Tests for client module."""
