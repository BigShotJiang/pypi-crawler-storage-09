"""
api-mocker: The industry-standard, production-ready, free API mocking and development acceleration tool.
"""

__version__ = "0.1.3"

from .server import MockServer
