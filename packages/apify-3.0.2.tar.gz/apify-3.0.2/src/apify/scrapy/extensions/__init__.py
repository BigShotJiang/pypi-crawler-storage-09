from apify.scrapy.extensions._httpcache import ApifyCacheStorage

__all__ = ['ApifyCacheStorage']
