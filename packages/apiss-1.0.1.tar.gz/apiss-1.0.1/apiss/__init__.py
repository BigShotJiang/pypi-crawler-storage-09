# Simple alias so users can `from apiss import Client`
from apispreadsheets_lib import Client, APIError

__all__ = ["Client", "APIError"]

