"""Exception classes for the Shadowstep framework.

This module contains custom exception classes used throughout the Shadowstep
framework for handling various error conditions and providing meaningful error
messages to users.
"""
