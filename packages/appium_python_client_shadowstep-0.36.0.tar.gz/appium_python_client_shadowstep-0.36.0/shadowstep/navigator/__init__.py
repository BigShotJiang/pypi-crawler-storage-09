"""Navigation utilities for the Shadowstep framework.

This module provides navigation functionality for mobile applications,
including screen navigation, back button handling, and navigation state
management during automation testing.
"""
