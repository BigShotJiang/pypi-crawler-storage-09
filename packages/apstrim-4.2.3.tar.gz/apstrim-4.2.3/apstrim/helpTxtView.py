txt="""Shortcuts:
^m: Show statistics: mean, sigma, peak2peak of visible curves.
^s: Stop/Start
^u: Unzoom
"""
