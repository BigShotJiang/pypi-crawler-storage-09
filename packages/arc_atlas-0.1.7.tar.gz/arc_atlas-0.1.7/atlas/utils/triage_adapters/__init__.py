"""Starter triage adapters for common Atlas domains."""

from . import code, sre, support

__all__ = ["code", "sre", "support"]
