"""Integration tests for ArcadeActions compatibility with external libraries."""
