"""Web Services API module."""

from .client import WebServicesClient

__all__ = ["WebServicesClient"]