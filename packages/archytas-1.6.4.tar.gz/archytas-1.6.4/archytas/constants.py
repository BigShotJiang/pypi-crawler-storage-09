"""
Constants shared across the package.
"""

TAB = '    '