from .resource import Resource
from .ammo import Ammo