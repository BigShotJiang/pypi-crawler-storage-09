"""Gather game object imports"""
from .structure import Structure
from .structure_with_inventory import StructureWithInventory
