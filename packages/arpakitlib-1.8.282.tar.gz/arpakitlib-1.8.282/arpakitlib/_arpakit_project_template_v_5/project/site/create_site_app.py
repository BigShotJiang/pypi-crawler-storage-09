from project.core.setup_logging import setup_logging


def create_site_app():
    setup_logging()
