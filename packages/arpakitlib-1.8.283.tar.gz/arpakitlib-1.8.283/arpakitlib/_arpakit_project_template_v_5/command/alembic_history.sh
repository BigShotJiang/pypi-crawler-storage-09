cd ..
alembic history
