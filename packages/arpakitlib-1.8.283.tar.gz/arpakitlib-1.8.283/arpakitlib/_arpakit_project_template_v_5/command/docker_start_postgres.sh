cd ..
source .env
sudo docker start ${common_project_name}_postgres
