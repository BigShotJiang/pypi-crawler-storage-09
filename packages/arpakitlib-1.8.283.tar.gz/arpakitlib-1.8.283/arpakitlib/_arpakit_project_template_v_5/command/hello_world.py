def __command():
    print("Hello world")


if __name__ == '__main__':
    __command()
