from project.site.create_site_app import create_site_app

app = create_site_app()
