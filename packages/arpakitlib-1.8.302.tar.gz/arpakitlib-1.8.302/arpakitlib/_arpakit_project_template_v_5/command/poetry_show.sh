cd ..
poetry show --tree