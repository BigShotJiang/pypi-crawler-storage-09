---
name: "📚  Documentation"
about: Find errors or problems in the docs (https://arrow.readthedocs.io)?
title: ''
labels: 'documentation'
assignees: ''
---

<!--
Thanks for taking the time to submit documentation feedback.

Please provide us with a detailed description of the documentation issue.
-->

## Issue Description

<!-- Replace this comment block with a description of the documentation issue. -->
