---
name: "💡  Feature Request"
about: Have an idea for a new feature or improvement?
title: ''
labels: 'enhancement'
assignees: ''
---

<!--
Thanks for taking the time to submit this feature request.

Please provide us with a detailed description of the potential improvement.
-->

## Feature Request

<!-- Replace this comment block with a description of the potential improvement. -->
