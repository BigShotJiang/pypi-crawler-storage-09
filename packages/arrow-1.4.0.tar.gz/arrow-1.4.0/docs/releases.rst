***************************************
Release History
***************************************

.. _releases:

.. include:: ../CHANGELOG.rst
