from .arrowspace import *

__doc__ = arrowspace.__doc__
if hasattr(arrowspace, "__all__"):
    __all__ = arrowspace.__all__