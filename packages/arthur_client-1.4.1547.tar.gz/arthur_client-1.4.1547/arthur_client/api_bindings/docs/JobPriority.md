# JobPriority


## Enum

* `NUMBER_100` (value: `100`)

* `NUMBER_200` (value: `200`)

* `NUMBER_300` (value: `300`)

* `NUMBER_400` (value: `400`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


