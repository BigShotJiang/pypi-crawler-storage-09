"""Problem templates for AMN."""
