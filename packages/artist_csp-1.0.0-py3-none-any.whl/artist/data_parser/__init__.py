"""Bundle all functions related to parsing data in ``ARTIST``."""
