"""Top-level package for asantiya."""

# asantiya/__init__.py

__app_name__ = "asantiya"
__version__ = "0.1.5"
