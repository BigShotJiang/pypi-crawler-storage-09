"""Test package for Asantiya."""
