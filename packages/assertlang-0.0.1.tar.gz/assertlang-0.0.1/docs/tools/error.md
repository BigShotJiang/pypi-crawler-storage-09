# Error Tool

Report error state toggles.
