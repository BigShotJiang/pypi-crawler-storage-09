"""
ML module for CharCNN-based operation lookup.
"""
