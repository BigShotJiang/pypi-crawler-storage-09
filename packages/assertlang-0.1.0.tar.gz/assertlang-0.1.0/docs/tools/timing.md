# Timing Tool

Measure elapsed time for sleep operations.
