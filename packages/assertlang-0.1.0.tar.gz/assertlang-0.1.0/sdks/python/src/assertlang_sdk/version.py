"""AssertLang SDK version metadata."""

__version__ = "0.0.3"
__daemon_min_version__ = "0.0.3"