# API Auth Tool

Generate API auth headers (API key, bearer).
