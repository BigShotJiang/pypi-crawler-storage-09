# Encryption Tool

Provide basic hashing utilities.
