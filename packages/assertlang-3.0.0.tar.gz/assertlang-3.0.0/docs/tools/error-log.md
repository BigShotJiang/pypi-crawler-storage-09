# Error Log Tool

Collect error log summaries.
