# Input Tool

Read content from files.
