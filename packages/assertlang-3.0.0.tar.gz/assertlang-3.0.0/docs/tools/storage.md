# Storage Tool

Filesystem-oriented storage operations (put/get/list/delete).
