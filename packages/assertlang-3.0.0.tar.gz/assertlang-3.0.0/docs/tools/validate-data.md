# Validate Data Tool

Validate JSON documents against JSON Schema.
