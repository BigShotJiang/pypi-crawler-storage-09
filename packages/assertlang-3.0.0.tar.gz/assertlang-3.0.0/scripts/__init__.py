"""Utility scripts reused by CLI and daemon."""
