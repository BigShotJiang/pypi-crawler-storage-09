"""AssertLang SDK version metadata."""

__version__ = "3.0.0"
__daemon_min_version__ = "3.0.0"