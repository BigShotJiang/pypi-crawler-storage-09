
from astartool.exception import AstarToolException


class FileReleaseLockException(AstarToolException):
    pass

