"""Test suite for poliastro"""
