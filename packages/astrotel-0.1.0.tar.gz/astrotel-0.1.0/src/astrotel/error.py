class InvalidOtelModeError(ValueError):
    """Raised when an unsupported OTEL_MODE is provided."""

