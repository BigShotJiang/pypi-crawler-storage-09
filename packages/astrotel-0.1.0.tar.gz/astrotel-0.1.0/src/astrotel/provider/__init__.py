from astrotel.provider.fastapi import FastAPIOpentelemetryTracing


__all__ = ["FastAPIOpentelemetryTracing"]
