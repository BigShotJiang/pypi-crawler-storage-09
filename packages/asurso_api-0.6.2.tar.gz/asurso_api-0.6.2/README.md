# ASURSO-API

It is just a python API-wrapper for NetSchool
