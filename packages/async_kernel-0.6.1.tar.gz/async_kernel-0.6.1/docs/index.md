---
title: Reference
description: Readme.
icon: material/home
---

--8<-- "README.md"
