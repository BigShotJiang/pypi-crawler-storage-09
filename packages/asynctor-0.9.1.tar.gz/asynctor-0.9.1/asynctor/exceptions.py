class AsynctorError(Exception):
    pass


class ParamsError(AsynctorError):
    pass
