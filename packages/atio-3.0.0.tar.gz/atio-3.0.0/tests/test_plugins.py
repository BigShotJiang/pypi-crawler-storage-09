# Copyright 2025 Atio Developers
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pytest
from atio.plugins import register_writer, get_writer


def dummy_writer(obj, path, **kwargs):
    with open(path, "w") as f:
        f.write("dummy")


def test_register_and_get_writer():
    register_writer(str, "dummy", dummy_writer)
    writer = get_writer("test_string", "dummy")
    assert writer is dummy_writer


# polars 지원 예시 (실제 polars 설치 필요)
try:
    import polars as pl

    def polars_parquet(obj, path, **kwargs):
        obj.write_parquet(path, **kwargs)

    register_writer(pl.DataFrame, "parquet", polars_parquet)

    def test_polars_writer(tmp_path):
        df = pl.DataFrame({"a": [1, 2, 3]})
        out_path = tmp_path / "test_polars.parquet"
        writer = get_writer(df, "parquet")
        writer(df, str(out_path))
        assert out_path.exists()

except ImportError:
    pass
