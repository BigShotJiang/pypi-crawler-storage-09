"""Instrumentors for agent frameworks."""
