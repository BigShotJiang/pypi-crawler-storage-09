"""Atlo - Run Atlantis workflows locally."""

__version__ = "0.1.0"
__author__ = "Jon Savage"
__description__ = "Run Atlantis workflows locally"
