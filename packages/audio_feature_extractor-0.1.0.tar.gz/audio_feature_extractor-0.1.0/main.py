# Example usage
from audio_feature_extractor import FeatureExtractor

extractor = FeatureExtractor()
audio_path = "/mnt/users_home/cpii.local/drhan/code/audio_feature_extractor/data/NISQA_Corpus/NISQA_TEST_FOR/deg/c00001_for_cnv_f_0104_02.wav"
features = extractor.extract_features(audio_path)
print(features)
