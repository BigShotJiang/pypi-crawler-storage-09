This are model files to be used with FFmpeg arnndn filter.

std.rnnn is one originally bundled with Xiph RNNoise implementation.
others are created by Gregor Richards.
