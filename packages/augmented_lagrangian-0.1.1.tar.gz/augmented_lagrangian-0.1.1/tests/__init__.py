"""Tests for the Augmented Lagrangian package."""
