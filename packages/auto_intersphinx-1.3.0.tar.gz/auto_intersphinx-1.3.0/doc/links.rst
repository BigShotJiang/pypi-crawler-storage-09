.. SPDX-FileCopyrightText: Copyright © 2022 Idiap Research Institute <contact@idiap.ch>
..
.. SPDX-License-Identifier: BSD-3-Clause

.. _idiap: http://www.idiap.ch
.. _python: http://www.python.org
.. _pip: https://pip.pypa.io/en/stable/
.. _uv: https://github.com/astral-sh/uv
.. _rye: https://github.com/astral-sh/rye
.. _poetry: https://python-poetry.org
.. _pixi: https://pixi.sh
.. _mamba: https://mamba.readthedocs.io/en/latest/index.html
.. _sphinx: https://www.sphinx-doc.org/
.. _intersphinx: https://www.sphinx-doc.org/en/master/usage/extensions/intersphinx.html
.. _readthedocs: https://readthedocs.org
.. _pypi: https://pypi.org
.. _docker-py: https://docker-py.readthedocs.io/en/stable/
.. _docker: https://pypi.org/project/docker/
.. _pytorch: https://pytorch.org
.. _torch: https://pypi.org/project/torch/
