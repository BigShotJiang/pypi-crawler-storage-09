void nnpi_calculate_weights(nnpi* nn, point* p);
int nnpi_get_nvertices(nnpi* nn);
int* nnpi_get_vertices(nnpi* nn);
double* nnpi_get_weights(nnpi* nn);
//int test_add(int a, int b);
