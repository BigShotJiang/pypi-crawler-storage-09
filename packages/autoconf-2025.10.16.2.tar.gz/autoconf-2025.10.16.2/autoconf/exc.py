class ConfigException(Exception):
    pass


class PriorException(Exception):
    pass
