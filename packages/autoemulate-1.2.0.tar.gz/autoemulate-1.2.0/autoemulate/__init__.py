from .core.compare import AutoEmulate

__all__ = ["AutoEmulate"]
