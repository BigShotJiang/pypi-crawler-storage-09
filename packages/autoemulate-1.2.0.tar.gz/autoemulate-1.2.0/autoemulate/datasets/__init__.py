from .datasets import fetch_data

__all__ = ["fetch_data"]
