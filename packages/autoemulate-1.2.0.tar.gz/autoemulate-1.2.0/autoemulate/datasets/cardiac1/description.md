# cardiac1

* data: https://zenodo.org/records/7405335  
    * download `atrial_cell_model.tar.xz`
    * directory: `atrial_cell_model/ionic`
* details: https://journals.plos.org/ploscompbiol/article?id=10.1371/journal.pcbi.1011257
* contact: Marina Strocchi / Steven Niederer

### Description:
* TODO: add description
* sampled with LHS
