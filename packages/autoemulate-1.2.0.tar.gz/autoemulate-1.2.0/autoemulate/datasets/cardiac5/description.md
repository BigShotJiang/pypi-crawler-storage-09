# cardiac5

* data: https://zenodo.org/records/7405335  
    * download `passive_mechanics.tar.xz`
    * directory: `passive_mechanics`
* details: https://journals.plos.org/ploscompbiol/article?id=10.1371/journal.pcbi.1011257
* contact: Marina Strocchi / Steven Niederer

### Description:
* predict inflated volumes and mean atrial and ventricular fiber strains for a passive inflation.
* LHS sampled