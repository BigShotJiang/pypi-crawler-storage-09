# engineering1

* data: Zack Xuereb Conti
* details: 
* contact: Zack Xuereb Conti

### Description:
* This is a more intricate cantilever truss design example whose geometry is parameterised by a set of geometric variables. In this dataset, deflection and weight are the targets/outputs while the remaining variables are inputs, controlling the geometry. The folder contains simulated data of the same problem for multiple dataset sizes.