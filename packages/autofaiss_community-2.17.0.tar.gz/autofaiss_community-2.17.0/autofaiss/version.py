# pylint: disable=all

__version__ = "2.17.0"
__author__ = "Criteo"


MAJOR = __version__.split(".")[0]
MINOR = __version__.split(".")[1]
PATCH = __version__.split(".")[2]
