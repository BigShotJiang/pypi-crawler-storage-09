class StellarProfile:
    pass
