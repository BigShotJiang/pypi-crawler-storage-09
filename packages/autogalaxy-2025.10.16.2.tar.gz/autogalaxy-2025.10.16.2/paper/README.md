PyAutoGalaxy JOSS Paper
=====================

Paper accompanying [PyAutoGalaxy](https://github.com/Jammy2211/PyAutoGalaxy) for submission to the Journal of Open Source 
Software (JOSS).