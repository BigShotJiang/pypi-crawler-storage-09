"""Exposes version constant to avoid circular dependencies."""

VERSION = "3.21.0"
