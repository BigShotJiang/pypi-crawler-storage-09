__version__ = "0.1.3"
__author__ = "Daniel Bastos"
__email__ = "danielfloresbastos@gmail.com"
