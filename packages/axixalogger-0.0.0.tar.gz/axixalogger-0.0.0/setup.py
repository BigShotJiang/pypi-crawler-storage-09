from setuptools import setup, find_packages


setup(
    name="axixalogger",
    description="Simple logger just for demo purpose",
    author="Sunil Tiwari",
    author_email="hello@suniltiwari.dev",
    # packages=find_packages(),
    package=find_packages(),
    classifiers=["Programming Language :: Python :: 3"],

)

