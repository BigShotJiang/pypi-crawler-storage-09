"""Utility functions"""
