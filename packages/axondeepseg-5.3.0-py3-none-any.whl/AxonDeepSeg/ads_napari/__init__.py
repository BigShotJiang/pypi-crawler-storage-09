from ._widget import ADSplugin

__all__ = (
    "ADSplugin"
)
