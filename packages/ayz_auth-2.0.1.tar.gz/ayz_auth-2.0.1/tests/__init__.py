"""
Test package for ayz-auth.
"""
