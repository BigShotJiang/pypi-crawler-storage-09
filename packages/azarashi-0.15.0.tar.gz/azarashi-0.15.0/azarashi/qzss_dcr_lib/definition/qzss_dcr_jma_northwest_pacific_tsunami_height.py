from .qzss_dcr_definition import QzssDcrDefinition

qzss_dcr_jma_northwest_pacific_tsunami_height_en = QzssDcrDefinition(
    {
        1: "0.3m~1m",
        2: "1m~3m",
        3: "3m~5m",
        4: "5m~10m",
        508: "More than 10m",
        509: "Huge",
        510: "High",
        511: "Unknown",
    },
    undefined="Undefined Tsunami Height (Code: %d)"
)
