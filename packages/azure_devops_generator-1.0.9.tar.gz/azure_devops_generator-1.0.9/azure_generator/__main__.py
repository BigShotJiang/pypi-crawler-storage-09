#!/usr/bin/env python3
"""
Azure Generator - Main Entry Point
Clean, modular CLI tool for Azure DevOps work item management
"""

import sys
from .config import ConfigManager
from .config.constants import REQUIRED_CONFIG_FIELDS, REQUIRED_WORK_ITEM_FIELDS
from .api import AzureDevOpsAPIClient, WorkItemService
from .cli import CommandHandler, Display


def run_config_wizard() -> dict:
    """
    Interactive configuration wizard for first-time setup

    Returns:
        dict: Configuration dictionary
    """
    print("\n" + "="*60)
    print("Azure DevOps Generator - First Time Setup")
    print("="*60)
    print("\nConfig dosyası bulunamadı. Lütfen aşağıdaki bilgileri girin:\n")

    config = {}

    # Organization
    config['organization'] = input("Organization name (example: New-Mind): ").strip()

    # Project
    config['project'] = input("Project name (example: ML AR-GE): ").strip()

    # PAT Token with validation
    import getpass
    while True:
        pat_token = getpass.getpass("PAT token: ").strip()

        # Validate token length (Azure DevOps PAT tokens are typically 52+ characters)
        if len(pat_token) < 20:
            print("WARNING: PAT token cok kisa! En az 20 karakter olmali.")
            print("   Lutfen token'i tekrar kopyalayip yapistirin.\n")
            continue

        # Check for invalid characters (like control characters from Ctrl+V)
        if any(ord(c) < 32 for c in pat_token):
            print("WARNING: Token gecersiz karakterler iceriyor!")
            print("   Lutfen token'i duzgun sekilde kopyalayip yapistirin.\n")
            continue

        # Token valid
        config['pat_token'] = pat_token
        break

    # User email
    config['user_email'] = input("User email (example: abcigerim@newmind.ai): ").strip()

    # Area path
    area_path = input("Area path (example: ML AR-GE\\MLOps Team): ").strip()
    config['area_path'] = area_path if area_path else "ML AR-GE"

    # Tasks folder
    default_tasks_folder = r"C:\Users\Ahmet\Desktop\Claude\Tasks"
    tasks_folder = input(f"Tasks folder [{default_tasks_folder}]: ").strip()
    config['tasks_folder'] = tasks_folder if tasks_folder else default_tasks_folder

    # Optional fields with defaults
    config['iteration_cache_ttl_hours'] = 72
    config['max_filename_length'] = 50

    print("\n" + "="*60)
    print("SUCCESS: Yapilandirma tamamlandi!")
    print("="*60)

    return config


def main():
    """Main entry point for Azure DevOps Tool"""
    try:
        # Try to load configuration
        try:
            config_manager = ConfigManager()

            # Config exists - auto-sync Claude Code integration (silently update MD file if needed)
            try:
                from .setup_utils import setup_claude_integration
                setup_claude_integration(silent=True)
            except Exception:
                # Silently fail - not critical for main functionality
                pass

        except FileNotFoundError:
            # Config not found - run wizard
            config_dict = run_config_wizard()

            # Save config
            config_manager = ConfigManager.__new__(ConfigManager)
            config_manager.config = {}
            config_manager.config_path = None

            if config_manager.save_config(config_dict):
                from .setup_utils import get_config_path, setup_claude_integration
                config_path = get_config_path()
                print(f"\nSUCCESS: Config kaydedildi: {config_path}")

                # Setup Claude Code integration now that we have config
                setup_claude_integration(silent=False)

                print(f"\nArtik 'azure-generator' komutunu her yerden kullanabilirsiniz!")
                print(f"Kullanim: azure-generator --help\n")

                # Reload config
                config_manager = ConfigManager()
            else:
                print("\nERROR: Config kaydedilemedi. Lutfen tekrar deneyin.")
                sys.exit(1)

        # Validate basic configuration
        missing_basic = config_manager.validate_basic_config()
        if missing_basic:
            print("Error: Missing required configuration fields!")
            print(f"Missing fields: {', '.join(missing_basic)}")
            print("\nPlease run the configuration wizard again or check your config file.")
            sys.exit(1)

        # Warn about missing work item fields (not fatal, some commands don't need them)
        missing_work_item = config_manager.validate_work_item_config()
        if missing_work_item:
            print(f"Warning: Some fields missing in azure_config.json: {', '.join(missing_work_item)}")
            print("These are required for creating work items from JSON files.")
            Display.print_config_error(missing_work_item, REQUIRED_WORK_ITEM_FIELDS)
            print()

        # Initialize API client
        organization, project, pat_token = config_manager.get_auth_credentials()
        api_client = AzureDevOpsAPIClient(organization, project, pat_token)

        # Initialize work item service
        work_item_service = WorkItemService(api_client, config_manager.to_dict())

        # Initialize command handler
        command_handler = CommandHandler(work_item_service, config_manager)

        # Execute command
        command_handler.execute(sys.argv[1:])

    except KeyboardInterrupt:
        print("\n\nOperation cancelled by user")
        sys.exit(0)
    except Exception as e:
        print(f"\nError: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
