"""
Azure DevOps API Client
Low-level HTTP client for Azure DevOps REST API
"""

import base64
import requests
from typing import Dict, List, Optional
from ..config.constants import AZURE_API_VERSION


class AzureDevOpsAPIClient:
    """Low-level client for Azure DevOps REST API"""

    def __init__(self, organization: str, project: str, pat_token: str):
        """
        Initialize Azure DevOps API client

        Args:
            organization: Azure DevOps organization name
            project: Project name
            pat_token: Personal Access Token
        """
        self.organization = organization
        self.project = project
        self.base_url = f"https://dev.azure.com/{organization}/{project}/_apis"

        # Create authentication header
        auth_string = f":{pat_token}"
        auth_bytes = auth_string.encode('ascii')
        base64_auth = base64.b64encode(auth_bytes).decode('ascii')

        self.headers = {
            'Content-Type': 'application/json-patch+json',
            'Authorization': f'Basic {base64_auth}'
        }

    def get_work_item(self, work_item_id: int, expand_relations: bool = False) -> Optional[Dict]:
        """
        Get a work item from Azure DevOps

        Args:
            work_item_id: ID of the work item to retrieve
            expand_relations: If True, include relations in response

        Returns:
            Work item data or None on failure
        """
        expand_param = "&$expand=relations" if expand_relations else ""
        url = f"{self.base_url}/wit/workitems/{work_item_id}?api-version={AZURE_API_VERSION}{expand_param}"

        get_headers = self.headers.copy()
        get_headers['Content-Type'] = 'application/json'

        try:
            response = requests.get(url, headers=get_headers)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            print(f"Error fetching work item #{work_item_id}: {e}")
            if hasattr(e, 'response') and e.response and hasattr(e.response, 'text'):
                print(f"Response: {e.response.text}")
            return None

    def create_work_item(self, work_item_type: str, fields: Dict, parent_id: Optional[int] = None,
                        child_ids: Optional[List[int]] = None, related_ids: Optional[List[int]] = None) -> Optional[Dict]:
        """
        Create a work item in Azure DevOps

        Args:
            work_item_type: Type of work item (Task, Bug, User Story, etc.)
            fields: Dictionary of field values
            parent_id: Optional parent work item ID
            child_ids: Optional list of child work item IDs
            related_ids: Optional list of related work item IDs

        Returns:
            Created work item data or None on failure
        """
        url = f"{self.base_url}/wit/workitems/${work_item_type}?api-version={AZURE_API_VERSION}"

        # Build patch document (relations first, then fields)
        patch_document = []

        # Add parent link if specified
        if parent_id:
            patch_document.append({
                "op": "add",
                "path": "/relations/-",
                "value": {
                    "rel": "System.LinkTypes.Hierarchy-Reverse",
                    "url": f"https://dev.azure.com/{self.organization}/{self.project}/_apis/wit/workitems/{parent_id}",
                    "attributes": {
                        "name": "Parent"
                    }
                }
            })

        # Add child links if specified
        if child_ids:
            for child_id in child_ids:
                patch_document.append({
                    "op": "add",
                    "path": "/relations/-",
                    "value": {
                        "rel": "System.LinkTypes.Hierarchy-Forward",
                        "url": f"https://dev.azure.com/{self.organization}/{self.project}/_apis/wit/workitems/{child_id}",
                        "attributes": {
                            "name": "Child"
                        }
                    }
                })

        # Add related links if specified
        if related_ids:
            for related_id in related_ids:
                patch_document.append({
                    "op": "add",
                    "path": "/relations/-",
                    "value": {
                        "rel": "System.LinkTypes.Related",
                        "url": f"https://dev.azure.com/{self.organization}/{self.project}/_apis/wit/workitems/{related_id}"
                    }
                })

        # Add fields
        for field_name, field_value in fields.items():
            if field_name != "System.Parent":  # Skip parent field, handled by relation
                patch_document.append({
                    "op": "add",
                    "path": f"/fields/{field_name}",
                    "value": field_value
                })

        try:
            response = requests.post(url, headers=self.headers, json=patch_document)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            print(f"Error creating work item: {e}")
            if hasattr(e, 'response') and e.response and hasattr(e.response, 'text'):
                print(f"Response: {e.response.text}")
            return None

    def update_work_item(self, work_item_id: int, fields: Dict, parent_changes: Optional[Dict] = None,
                        child_changes: Optional[Dict] = None, related_changes: Optional[Dict] = None) -> Optional[Dict]:
        """
        Update a work item in Azure DevOps

        Args:
            work_item_id: ID of work item to update
            fields: Dictionary of field values to update
            parent_changes: Optional dict with parent relation changes
                           Format: {"action": "remove|add|replace", "old_parent_index": X, "new_parent_id": Y}
            child_changes: Optional dict with child relation changes
                          Format: {"add": [id1, id2], "remove": [{"index": X, "id": Y}]}
            related_changes: Optional dict with related relation changes
                            Format: {"add": [id1, id2], "remove": [{"index": X, "id": Y}]}

        Returns:
            Updated work item data or None on failure
        """
        url = f"{self.base_url}/wit/workitems/{work_item_id}?api-version={AZURE_API_VERSION}"

        # Build patch document (all relations first, then fields)
        patch_document = []

        # Handle parent relation changes (order matters: remove before add)
        if parent_changes:
            action = parent_changes.get("action")

            # Remove old parent if needed
            if action in ["remove", "replace"]:
                old_parent_index = parent_changes.get("old_parent_index")
                if old_parent_index is not None:
                    patch_document.append({
                        "op": "remove",
                        "path": f"/relations/{old_parent_index}"
                    })

            # Add new parent if needed
            if action in ["add", "replace"]:
                new_parent_id = parent_changes.get("new_parent_id")
                if new_parent_id:
                    patch_document.append({
                        "op": "add",
                        "path": "/relations/-",
                        "value": {
                            "rel": "System.LinkTypes.Hierarchy-Reverse",
                            "url": f"https://dev.azure.com/{self.organization}/{self.project}/_apis/wit/workitems/{new_parent_id}",
                            "attributes": {
                                "name": "Parent"
                            }
                        }
                    })

        # Handle child relation changes
        if child_changes:
            # Remove children first (in descending order to avoid index shifting issues)
            if "remove" in child_changes:
                sorted_removes = sorted(child_changes["remove"], key=lambda x: x['index'], reverse=True)
                for item in sorted_removes:
                    patch_document.append({
                        "op": "remove",
                        "path": f"/relations/{item['index']}"
                    })

            # Add new children
            if "add" in child_changes:
                for child_id in child_changes["add"]:
                    patch_document.append({
                        "op": "add",
                        "path": "/relations/-",
                        "value": {
                            "rel": "System.LinkTypes.Hierarchy-Forward",
                            "url": f"https://dev.azure.com/{self.organization}/{self.project}/_apis/wit/workitems/{child_id}",
                            "attributes": {
                                "name": "Child"
                            }
                        }
                    })

        # Handle related relation changes
        if related_changes:
            # Remove related first (in descending order to avoid index shifting issues)
            if "remove" in related_changes:
                sorted_removes = sorted(related_changes["remove"], key=lambda x: x['index'], reverse=True)
                for item in sorted_removes:
                    patch_document.append({
                        "op": "remove",
                        "path": f"/relations/{item['index']}"
                    })

            # Add new related
            if "add" in related_changes:
                for related_id in related_changes["add"]:
                    patch_document.append({
                        "op": "add",
                        "path": "/relations/-",
                        "value": {
                            "rel": "System.LinkTypes.Related",
                            "url": f"https://dev.azure.com/{self.organization}/{self.project}/_apis/wit/workitems/{related_id}"
                        }
                    })

        # Add field updates
        for field_name, field_value in fields.items():
            patch_document.append({
                "op": "add",
                "path": f"/fields/{field_name}",
                "value": field_value
            })

        try:
            response = requests.patch(url, headers=self.headers, json=patch_document)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            print(f"Error updating work item #{work_item_id}: {e}")
            if hasattr(e, 'response') and e.response and hasattr(e.response, 'text'):
                print(f"Response: {e.response.text}")
            return None

    def query_work_items(self, wiql_query: str) -> List[Dict]:
        """
        Query work items using WIQL

        Args:
            wiql_query: WIQL query string

        Returns:
            List of work item IDs from query results
        """
        url = f"{self.base_url}/wit/wiql?api-version={AZURE_API_VERSION}"

        post_headers = self.headers.copy()
        post_headers['Content-Type'] = 'application/json'

        try:
            response = requests.post(url, headers=post_headers, json={"query": wiql_query})
            response.raise_for_status()
            result = response.json()
            return result.get('workItems', [])
        except requests.exceptions.RequestException as e:
            print(f"Error querying work items: {e}")
            if hasattr(e, 'response') and e.response and hasattr(e.response, 'text'):
                print(f"Response: {e.response.text}")
            return []

    def get_work_items_batch(self, work_item_ids: List[int]) -> List[Dict]:
        """
        Get multiple work items in a single batch request (up to 200 per request)

        Args:
            work_item_ids: List of work item IDs to retrieve

        Returns:
            List of work item data
        """
        if not work_item_ids:
            return []

        all_work_items = []
        batch_size = 200  # Azure DevOps API limit

        # Process in batches of 200
        for i in range(0, len(work_item_ids), batch_size):
            batch_ids = work_item_ids[i:i + batch_size]
            ids_param = ','.join(map(str, batch_ids))

            url = f"{self.base_url}/wit/workitems?ids={ids_param}&$expand=links&api-version={AZURE_API_VERSION}"

            get_headers = self.headers.copy()
            get_headers['Content-Type'] = 'application/json'

            try:
                response = requests.get(url, headers=get_headers)
                response.raise_for_status()
                result = response.json()
                work_items = result.get('value', [])
                all_work_items.extend(work_items)
            except requests.exceptions.RequestException as e:
                print(f"Error fetching work items batch: {e}")
                if hasattr(e, 'response') and e.response and hasattr(e.response, 'text'):
                    print(f"Response: {e.response.text}")
                # Continue with next batch even if one fails
                continue

        return all_work_items

    def get_iterations(self, depth: int = 100) -> Optional[Dict]:
        """
        Get iteration classification nodes from Azure DevOps

        Args:
            depth: How many levels of nested iterations to retrieve (default: 100)

        Returns:
            Iteration tree dictionary or None on failure
        """
        url = f"{self.base_url}/wit/classificationnodes/Iterations?$depth={depth}&api-version={AZURE_API_VERSION}"

        get_headers = self.headers.copy()
        get_headers['Content-Type'] = 'application/json'

        try:
            response = requests.get(url, headers=get_headers)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            print(f"Error fetching iterations: {e}")
            if hasattr(e, 'response') and e.response and hasattr(e.response, 'text'):
                print(f"Response: {e.response.text}")
            return None
