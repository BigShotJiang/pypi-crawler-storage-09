"""
Work Item Service
High-level business logic for work item operations
"""

import json
import re
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional
from .azure_client import AzureDevOpsAPIClient
from ..mappers import JSONToAzureMapper, AzureToJSONMapper, JSONToAzureUpdateMapper
from ..services import IterationService
from ..utils import HTMLBuilder
from ..config.constants import (
    FIELD_TITLE, FIELD_DESCRIPTION, FIELD_STATE, FIELD_ASSIGNED_TO,
    FIELD_AREA_PATH, FIELD_ITERATION_PATH, FIELD_BUSINESS_VALUE, FIELD_ORIGINAL_ESTIMATE,
    FIELD_WORK_ITEM_TYPE, FIELD_PRIORITY, FIELD_BUG_SYSTEM_INFO,
    WORK_ITEM_TYPE_USER_STORY, WORK_ITEM_TYPE_BUG, WORK_ITEM_TYPE_TASK,
    BUG_STATES, TASK_STATES, USER_STORY_STATES, DEFAULT_INITIAL_STATE
)


class WorkItemService:
    """High-level service for work item operations"""

    def __init__(self, api_client: AzureDevOpsAPIClient, config: Dict):
        """
        Initialize work item service

        Args:
            api_client: Azure DevOps API client instance
            config: Configuration dictionary
        """
        self.api_client = api_client
        self.config = config

        # Initialize iteration service
        self.iteration_service = IterationService(api_client, config)

        # Initialize mappers
        self.json_to_azure = JSONToAzureMapper(config, self.iteration_service)
        self.azure_to_json = AzureToJSONMapper()
        self.json_to_azure_update = JSONToAzureUpdateMapper()
        self.html_builder = HTMLBuilder()

    def _is_valid_state(self, work_item_type: str, state: str) -> bool:
        """
        Validate state is valid for work item type

        Args:
            work_item_type: Type of work item (Task, Bug, User Story)
            state: State to validate

        Returns:
            True if state is valid for the work item type
        """
        if work_item_type == WORK_ITEM_TYPE_BUG:
            return state in BUG_STATES
        elif work_item_type == WORK_ITEM_TYPE_TASK:
            return state in TASK_STATES
        elif work_item_type == WORK_ITEM_TYPE_USER_STORY:
            return state in USER_STORY_STATES
        else:
            # Unknown work item type, only allow "New"
            return state == DEFAULT_INITIAL_STATE

    def _check_and_assign_user(self, work_item: Dict, work_item_id: int) -> None:
        """
        Check if work item has assigned user, and assign if not

        Args:
            work_item: Work item dictionary from Azure API
            work_item_id: ID of the work item
        """
        try:
            print("Checking assigned user...")
            assigned_to = work_item['fields'].get(FIELD_ASSIGNED_TO)

            if not assigned_to:
                # No user assigned, try to assign from config
                user_email = self.config.get('user_email')
                if user_email:
                    print(f"  No user assigned, attempting to assign to: {user_email}")
                    update_fields = {FIELD_ASSIGNED_TO: user_email}
                    updated = self.api_client.update_work_item(work_item_id, update_fields)

                    if updated:
                        print(f"  Successfully assigned to: {user_email}")
                    else:
                        print(f"  Failed to assign user")
                else:
                    print(f"  No user assigned and no user_email in config")
            else:
                # User already assigned
                assigned_name = assigned_to.get('displayName', assigned_to.get('uniqueName', 'Unknown'))
                print(f"  Already assigned to: {assigned_name}")
        except Exception as e:
            print(f"  Error checking/assigning user: {e}")

    def create_work_item_from_json(self, json_file_path: str, parent_id: Optional[int] = None,
                                   iteration_path: Optional[str] = None) -> Optional[Dict]:
        """
        Read JSON file and create work item in Azure DevOps

        Args:
            json_file_path: Path to JSON file
            parent_id: Optional parent work item ID
            iteration_path: Optional manual iteration path override

        Returns:
            Created work item or None
        """

        try:
            with open(json_file_path, 'r', encoding='utf-8') as f:
                work_item_data = json.load(f)

            # Read parent_id from JSON if not provided as parameter
            json_parent_id = work_item_data.get('parent_id')
            if not parent_id and json_parent_id:
                parent_id = json_parent_id

            # Read child_ids and related_ids from JSON
            child_ids = work_item_data.get('child_ids')
            related_ids = work_item_data.get('related_ids')

            # Determine work item type and desired state from JSON
            work_item_type = work_item_data.get('type', 'Task')
            json_status = work_item_data.get('status', 'New')

            # Map JSON to Azure DevOps fields based on work item type
            if work_item_type == WORK_ITEM_TYPE_USER_STORY:
                # Use User Story mapper
                fields = self._map_user_story_json(work_item_data, iteration_path)
            else:
                # Use existing Task/Bug mapper
                fields = self.json_to_azure.map_work_item(work_item_data, iteration_path)

            # Create work item with "New" state
            print(f"Creating {work_item_type}: {work_item_data.get('title', 'Untitled')}")
            work_item = self.api_client.create_work_item(work_item_type, fields, parent_id, child_ids, related_ids)

            if work_item:
                work_item_id = work_item['id']
                print(f"SUCCESS: Created work item #{work_item_id}: {work_item['fields'][FIELD_TITLE]}")
                if parent_id:
                    print(f"  Parent: #{parent_id}")
                if child_ids:
                    print(f"  Children: {', '.join([f'#{cid}' for cid in child_ids])}")
                if related_ids:
                    print(f"  Related: {', '.join([f'#{rid}' for rid in related_ids])}")

                # Check if we need to update state
                if json_status and json_status != DEFAULT_INITIAL_STATE:
                    # Validate state is valid for work item type
                    if self._is_valid_state(work_item_type, json_status):
                        print(f"  Updating state: {DEFAULT_INITIAL_STATE} -> {json_status}")

                        # Build update fields
                        update_fields = {FIELD_STATE: json_status}

                        # For "In Progress" state, Original Estimate is required
                        if json_status == "In Progress" and work_item_type == WORK_ITEM_TYPE_TASK:
                            # Get time_spent_hours from JSON, or use default
                            original_estimate = work_item_data.get('time_spent_hours', 1)
                            update_fields[FIELD_ORIGINAL_ESTIMATE] = original_estimate
                            print(f"  Setting Original Estimate: {original_estimate} hours")

                        updated = self.api_client.update_work_item(work_item_id, update_fields)
                        if updated:
                            print(f"  SUCCESS: State updated to {json_status}")
                        else:
                            print(f"  WARNING: Failed to update state to {json_status}")
                    else:
                        valid_states = []
                        if work_item_type == WORK_ITEM_TYPE_BUG:
                            valid_states = BUG_STATES
                        elif work_item_type == WORK_ITEM_TYPE_TASK:
                            valid_states = TASK_STATES
                        elif work_item_type == WORK_ITEM_TYPE_USER_STORY:
                            valid_states = USER_STORY_STATES
                        print(f"  WARNING: Invalid state '{json_status}' for {work_item_type}")
                        print(f"           Valid states: {', '.join(valid_states)}")

                print(f"  URL: {work_item['_links']['html']['href']}")
                return work_item
            else:
                print(f"FAILED: Failed to create work item from {json_file_path}")
                return None

        except Exception as e:
            print(f"Error processing {json_file_path}: {e}")
            return None

    def _map_user_story_json(self, work_item_data: Dict, iteration_path: Optional[str] = None) -> Dict:
        """
        Map User Story JSON data to Azure DevOps fields

        Args:
            work_item_data: User Story data from JSON file
            iteration_path: Optional manual iteration path override

        Returns:
            Dictionary of Azure DevOps fields for User Story

        Raises:
            ValueError: If required config fields are missing
        """

        # Get required config values
        area_path = self.config.get('area_path')
        if not area_path:
            raise ValueError("area_path is required in config to create user stories")

        # Build fields (always start with "New" state)
        fields = {
            FIELD_TITLE: work_item_data.get('title', 'Untitled User Story'),
            FIELD_AREA_PATH: area_path,
            FIELD_STATE: DEFAULT_INITIAL_STATE
        }

        # Set iteration path (manual override OR JSON field OR automatic)
        if iteration_path:
            # CLI parameter has highest priority - validate it
            self.iteration_service.validate_iteration_path(iteration_path)
            # Clean path: remove leading backslash and \Iteration\ part
            fields[FIELD_ITERATION_PATH] = iteration_path.lstrip('\\').replace('\\Iteration\\', '\\')
        elif 'iteration' in work_item_data and work_item_data['iteration']:
            # JSON field has second priority - validate it
            self.iteration_service.validate_iteration_path(work_item_data['iteration'])
            # Clean path: remove leading backslash and \Iteration\ part
            fields[FIELD_ITERATION_PATH] = work_item_data['iteration'].lstrip('\\').replace('\\Iteration\\', '\\')
        else:
            # Automatic selection
            current_iteration = self.iteration_service.get_current_iteration()
            # Clean path: remove leading backslash and \Iteration\ part
            fields[FIELD_ITERATION_PATH] = current_iteration.path.lstrip('\\').replace('\\Iteration\\', '\\')

        # Add description if provided
        if work_item_data.get('description'):
            fields[FIELD_DESCRIPTION] = self.html_builder.build_paragraph(work_item_data['description'])

        # Add business value if provided
        if work_item_data.get('business_value'):
            try:
                fields[FIELD_BUSINESS_VALUE] = int(work_item_data['business_value'])
            except ValueError:
                print(f"Warning: business_value '{work_item_data['business_value']}' is not numeric, skipping")

        # Add assigned to - use JSON value if specified, otherwise use config user_email
        if work_item_data.get('assigned_to'):
            fields[FIELD_ASSIGNED_TO] = work_item_data['assigned_to']
        else:
            user_email = self.config.get('user_email')
            if user_email:
                fields[FIELD_ASSIGNED_TO] = user_email

        # Add tags if provided
        if work_item_data.get('tags') and isinstance(work_item_data['tags'], list):
            fields[FIELD_TAGS] = '; '.join(work_item_data['tags'])

        return fields

    def process_directory(self, directory_path: str, pattern: str = "**/*.json",
                         parent_id: Optional[int] = None, iteration_path: Optional[str] = None) -> List[Dict]:
        """
        Process all JSON files in a directory

        Args:
            directory_path: Path to directory containing JSON files
            pattern: Glob pattern for finding JSON files
            parent_id: Optional parent work item ID for all tasks
            iteration_path: Optional manual iteration path override

        Returns:
            List of created work items
        """
        directory = Path(directory_path)
        json_files = list(directory.glob(pattern))

        print(f"Found {len(json_files)} JSON files to process")
        if parent_id:
            print(f"All tasks will be linked to parent work item #{parent_id}")
        if iteration_path:
            print(f"All tasks will use iteration: {iteration_path}")
        print("-" * 60)

        created_items = []
        for json_file in json_files:
            work_item = self.create_work_item_from_json(str(json_file), parent_id, iteration_path)
            if work_item:
                created_items.append(work_item)
            print("-" * 60)

        print(f"\nSummary: Created {len(created_items)} out of {len(json_files)} work items")
        return created_items

    def save_work_item_to_json(self, work_item_id: int, output_path: Optional[str] = None) -> bool:
        """
        Fetch work item and save to JSON file

        Args:
            work_item_id: ID of work item to fetch
            output_path: Optional path for output file. If None, auto-generates path

        Returns:
            True if successful, False otherwise
        """
        work_item = self.api_client.get_work_item(work_item_id)
        if not work_item:
            return False

        task_json = self.azure_to_json.map_work_item(work_item)

        # Auto-generate path if not provided
        if not output_path:
            date_str = task_json['created_date']
            if date_str:
                parts = date_str.split('-')
                if len(parts) == 3:
                    folder_date = f"{parts[2]}-{parts[1]}-{parts[0]}"
                else:
                    folder_date = date_str
            else:
                folder_date = datetime.now().strftime('%d-%m-%Y')

            # Create safe filename from title
            max_length = self.config.get('max_filename_length', 50)
            safe_title = "".join(c if c.isalnum() or c in (' ', '-', '_') else '_'
                                for c in task_json['title'].lower())
            safe_title = safe_title.replace(' ', '-')[:max_length]

            tasks_folder = self.config.get('tasks_folder', 'Tasks')

            # Check if tasks_folder is absolute or relative path
            tasks_path = Path(tasks_folder)
            if tasks_path.is_absolute():
                tasks_dir = tasks_path / folder_date
            else:
                tasks_dir = Path.cwd() / tasks_folder / folder_date

            tasks_dir.mkdir(parents=True, exist_ok=True)
            output_path = tasks_dir / f"{safe_title}-task.json"

        # Save to file
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(task_json, f, indent=2, ensure_ascii=False)

        print(f"SUCCESS: Saved work item #{work_item_id} to {output_path}")
        return True

    def get_user_stories(self, assigned_to: Optional[str] = None, include_all_states: bool = False) -> List[Dict]:
        """
        Get user stories from Azure DevOps

        Args:
            assigned_to: Optional email or display name to filter by assigned user
            include_all_states: If False, only returns New/Active/Holding states.
                              If True, returns all states including Closed/Removed.

        Returns:
            List of user story work items
        """
        # Build WIQL query
        wiql_query = """
        SELECT [System.Id], [System.Title], [System.State], [System.AssignedTo],
               [System.CreatedDate], [Microsoft.VSTS.Common.Priority], [System.Tags]
        FROM WorkItems
        WHERE [System.WorkItemType] = 'User Story'
        """

        if not include_all_states:
            wiql_query += " AND ([System.State] = 'New' OR [System.State] = 'Active' OR [System.State] = 'Holding')"

        if assigned_to:
            wiql_query += f" AND [System.AssignedTo] = '{assigned_to}'"

        wiql_query += " ORDER BY [Microsoft.VSTS.Common.Priority] ASC, [System.CreatedDate] DESC"

        # Execute query
        work_items = self.api_client.query_work_items(wiql_query)

        if not work_items:
            return []

        # Extract IDs and fetch all work items in batch
        work_item_ids = [item['id'] for item in work_items]
        detailed_items = self.api_client.get_work_items_batch(work_item_ids)

        return detailed_items

    def update_work_item_from_json(self, json_file_path: str, iteration_path: Optional[str] = None) -> Optional[Dict]:
        """
        Read JSON file and update work item in Azure DevOps

        Args:
            json_file_path: Path to JSON file containing update data
            iteration_path: Optional manual iteration path override

        Returns:
            Updated work item or None

        Raises:
            ValueError: If JSON is invalid or missing required fields
        """
        try:
            # Read JSON file
            with open(json_file_path, 'r', encoding='utf-8') as f:
                update_data = json.load(f)

            # Validate required field: id
            if 'id' not in update_data:
                raise ValueError("JSON file must contain 'id' field with work item ID")

            work_item_id = update_data['id']

            # Validate ID is integer
            try:
                work_item_id = int(work_item_id)
            except (ValueError, TypeError):
                raise ValueError(f"Work item ID must be numeric, got: {work_item_id}")

            # Fetch current work item (with relations to detect parent changes)
            print(f"Fetching work item #{work_item_id}...")
            current_work_item = self.api_client.get_work_item(work_item_id, expand_relations=True)

            if not current_work_item:
                raise ValueError(f"Work item #{work_item_id} not found")

            # Get work item type
            work_item_type = current_work_item['fields'].get('System.WorkItemType', 'Unknown')
            print(f"Work item type: {work_item_type}")

            # Map update fields (returns tuple: fields, parent_changes, child_changes, related_changes)
            print(f"Mapping update fields...")
            update_fields, parent_changes, child_changes, related_changes = \
                self.json_to_azure_update.map_update_fields(update_data, current_work_item, iteration_path, self.iteration_service)

            # Check if there are any changes
            if not update_fields and not parent_changes and not child_changes and not related_changes:
                print(f"SUCCESS: No changes detected for work item #{work_item_id}")
                print(f"  All provided fields already have the specified values")
                return current_work_item

            # Display fields being updated
            if update_fields:
                print(f"Updating {len(update_fields)} field(s):")
                for field_name in update_fields.keys():
                    print(f"  - {field_name}")

            # Display parent relation changes
            if parent_changes:
                action = parent_changes.get('action')
                if action == 'add':
                    print(f"Adding parent relation:")
                    print(f"  - New parent ID: {parent_changes.get('new_parent_id')}")
                elif action == 'remove':
                    print(f"Removing parent relation:")
                    print(f"  - Old parent ID: {parent_changes.get('old_parent_id')}")
                elif action == 'replace':
                    print(f"Replacing parent relation:")
                    print(f"  - Old parent ID: {parent_changes.get('old_parent_id')}")
                    print(f"  - New parent ID: {parent_changes.get('new_parent_id')}")

            # Display child relation changes
            if child_changes:
                if "remove" in child_changes:
                    removed_ids = [str(item['id']) for item in child_changes['remove']]
                    print(f"Removing {len(removed_ids)} child relation(s): {', '.join([f'#{cid}' for cid in removed_ids])}")
                if "add" in child_changes:
                    print(f"Adding {len(child_changes['add'])} child relation(s): {', '.join([f'#{cid}' for cid in child_changes['add']])}")

            # Display related relation changes
            if related_changes:
                if "remove" in related_changes:
                    removed_ids = [str(item['id']) for item in related_changes['remove']]
                    print(f"Removing {len(removed_ids)} related relation(s): {', '.join([f'#{rid}' for rid in removed_ids])}")
                if "add" in related_changes:
                    print(f"Adding {len(related_changes['add'])} related relation(s): {', '.join([f'#{rid}' for rid in related_changes['add']])}")

            # Perform update
            updated_work_item = self.api_client.update_work_item(work_item_id, update_fields, parent_changes, child_changes, related_changes)

            if updated_work_item:
                # Check and assign user if needed
                self._check_and_assign_user(updated_work_item, work_item_id)

                print(f"SUCCESS: Updated work item #{work_item_id}")
                print(f"  URL: {updated_work_item['_links']['html']['href']}")
                return updated_work_item
            else:
                print(f"FAILED: Failed to update work item #{work_item_id}")
                return None

        except FileNotFoundError:
            print(f"Error: JSON file not found: {json_file_path}")
            return None
        except json.JSONDecodeError as e:
            print(f"Error: Invalid JSON format in {json_file_path}: {e}")
            return None
        except ValueError as e:
            print(f"Error: {e}")
            return None
        except Exception as e:
            print(f"Error processing {json_file_path}: {e}")
            import traceback
            traceback.print_exc()
            return None

    def get_tasks(self, assigned_to: Optional[str] = None, include_all_states: bool = False) -> List[Dict]:
        """
        Get tasks from Azure DevOps

        Args:
            assigned_to: Optional email or display name to filter by assigned user
            include_all_states: If False, only returns New/In Progress/Holding states.
                              If True, returns all states including Completed/Removed.

        Returns:
            List of task work items
        """
        # Build WIQL query
        wiql_query = """
        SELECT [System.Id], [System.Title], [System.State], [System.AssignedTo],
               [System.CreatedDate], [Microsoft.VSTS.Common.Priority], [System.Tags]
        FROM WorkItems
        WHERE [System.WorkItemType] = 'Task'
        """

        if not include_all_states:
            wiql_query += " AND ([System.State] = 'New' OR [System.State] = 'In Progress' OR [System.State] = 'Holding')"

        if assigned_to:
            wiql_query += f" AND [System.AssignedTo] = '{assigned_to}'"

        wiql_query += " ORDER BY [Microsoft.VSTS.Common.Priority] ASC, [System.CreatedDate] DESC"

        # Execute query
        work_items = self.api_client.query_work_items(wiql_query)

        if not work_items:
            return []

        # Extract IDs and fetch all work items in batch
        work_item_ids = [item['id'] for item in work_items]
        detailed_items = self.api_client.get_work_items_batch(work_item_ids)

        return detailed_items

    def update_work_item_from_json(self, json_file_path: str, iteration_path: Optional[str] = None) -> Optional[Dict]:
        """
        Read JSON file and update work item in Azure DevOps

        Args:
            json_file_path: Path to JSON file containing update data
            iteration_path: Optional manual iteration path override

        Returns:
            Updated work item or None

        Raises:
            ValueError: If JSON is invalid or missing required fields
        """
        try:
            # Read JSON file
            with open(json_file_path, 'r', encoding='utf-8') as f:
                update_data = json.load(f)

            # Validate required field: id
            if 'id' not in update_data:
                raise ValueError("JSON file must contain 'id' field with work item ID")

            work_item_id = update_data['id']

            # Validate ID is integer
            try:
                work_item_id = int(work_item_id)
            except (ValueError, TypeError):
                raise ValueError(f"Work item ID must be numeric, got: {work_item_id}")

            # Fetch current work item (with relations to detect parent changes)
            print(f"Fetching work item #{work_item_id}...")
            current_work_item = self.api_client.get_work_item(work_item_id, expand_relations=True)

            if not current_work_item:
                raise ValueError(f"Work item #{work_item_id} not found")

            # Get work item type
            work_item_type = current_work_item['fields'].get('System.WorkItemType', 'Unknown')
            print(f"Work item type: {work_item_type}")

            # Map update fields (returns tuple: fields, parent_changes, child_changes, related_changes)
            print(f"Mapping update fields...")
            update_fields, parent_changes, child_changes, related_changes = \
                self.json_to_azure_update.map_update_fields(update_data, current_work_item, iteration_path, self.iteration_service)

            # Check if there are any changes
            if not update_fields and not parent_changes and not child_changes and not related_changes:
                print(f"SUCCESS: No changes detected for work item #{work_item_id}")
                print(f"  All provided fields already have the specified values")
                return current_work_item

            # Display fields being updated
            if update_fields:
                print(f"Updating {len(update_fields)} field(s):")
                for field_name in update_fields.keys():
                    print(f"  - {field_name}")

            # Display parent relation changes
            if parent_changes:
                action = parent_changes.get('action')
                if action == 'add':
                    print(f"Adding parent relation:")
                    print(f"  - New parent ID: {parent_changes.get('new_parent_id')}")
                elif action == 'remove':
                    print(f"Removing parent relation:")
                    print(f"  - Old parent ID: {parent_changes.get('old_parent_id')}")
                elif action == 'replace':
                    print(f"Replacing parent relation:")
                    print(f"  - Old parent ID: {parent_changes.get('old_parent_id')}")
                    print(f"  - New parent ID: {parent_changes.get('new_parent_id')}")

            # Display child relation changes
            if child_changes:
                if "remove" in child_changes:
                    removed_ids = [str(item['id']) for item in child_changes['remove']]
                    print(f"Removing {len(removed_ids)} child relation(s): {', '.join([f'#{cid}' for cid in removed_ids])}")
                if "add" in child_changes:
                    print(f"Adding {len(child_changes['add'])} child relation(s): {', '.join([f'#{cid}' for cid in child_changes['add']])}")

            # Display related relation changes
            if related_changes:
                if "remove" in related_changes:
                    removed_ids = [str(item['id']) for item in related_changes['remove']]
                    print(f"Removing {len(removed_ids)} related relation(s): {', '.join([f'#{rid}' for rid in removed_ids])}")
                if "add" in related_changes:
                    print(f"Adding {len(related_changes['add'])} related relation(s): {', '.join([f'#{rid}' for rid in related_changes['add']])}")

            # Perform update
            updated_work_item = self.api_client.update_work_item(work_item_id, update_fields, parent_changes, child_changes, related_changes)

            if updated_work_item:
                # Check and assign user if needed
                self._check_and_assign_user(updated_work_item, work_item_id)

                print(f"SUCCESS: Updated work item #{work_item_id}")
                print(f"  URL: {updated_work_item['_links']['html']['href']}")
                return updated_work_item
            else:
                print(f"FAILED: Failed to update work item #{work_item_id}")
                return None

        except FileNotFoundError:
            print(f"Error: JSON file not found: {json_file_path}")
            return None
        except json.JSONDecodeError as e:
            print(f"Error: Invalid JSON format in {json_file_path}: {e}")
            return None
        except ValueError as e:
            print(f"Error: {e}")
            return None
        except Exception as e:
            print(f"Error processing {json_file_path}: {e}")
            import traceback
            traceback.print_exc()
            return None

    def delete_work_item(self, work_item_id: int) -> Optional[Dict]:
        """
        Mark work item as Removed (soft delete)

        Args:
            work_item_id: ID of work item to delete

        Returns:
            Updated work item or None

        Raises:
            ValueError: If work item not found or invalid ID
        """
        try:
            # Validate ID is integer
            try:
                work_item_id = int(work_item_id)
            except (ValueError, TypeError):
                raise ValueError(f"Work item ID must be numeric, got: {work_item_id}")

            # Fetch current work item (with relations to detect parent changes)
            print(f"Fetching work item #{work_item_id}...")
            current_work_item = self.api_client.get_work_item(work_item_id, expand_relations=True)

            if not current_work_item:
                raise ValueError(f"Work item #{work_item_id} not found")

            # Get work item type and current state
            work_item_type = current_work_item['fields'].get('System.WorkItemType', 'Unknown')
            current_state = current_work_item['fields'].get(FIELD_STATE, 'Unknown')

            print(f"Work item type: {work_item_type}")
            print(f"Current state: {current_state}")

            # Check if already removed
            if current_state == "Removed":
                print(f"SUCCESS: Work item #{work_item_id} is already marked as Removed")
                return current_work_item

            # Update state to Removed
            print(f"Setting state to: Removed")
            update_fields = {FIELD_STATE: "Removed"}

            updated_work_item = self.api_client.update_work_item(work_item_id, update_fields)

            if updated_work_item:
                print(f"SUCCESS: Work item #{work_item_id} marked as Removed")
                print(f"  URL: {updated_work_item['_links']['html']['href']}")
                return updated_work_item
            else:
                print(f"FAILED: Failed to mark work item #{work_item_id} as Removed")
                return None

        except ValueError as e:
            print(f"Error: {e}")
            return None
        except Exception as e:
            print(f"Error deleting work item #{work_item_id}: {e}")
            import traceback
            traceback.print_exc()
            return None

    def update_work_item_status(self, work_item_id: int, new_state: str) -> Optional[Dict]:
        """
        Update only the status/state of a work item

        Args:
            work_item_id: ID of work item to update
            new_state: New state value

        Returns:
            Updated work item or None

        Raises:
            ValueError: If work item not found, invalid ID, or invalid state for work item type
        """
        try:
            # Validate ID is integer
            try:
                work_item_id = int(work_item_id)
            except (ValueError, TypeError):
                raise ValueError(f"Work item ID must be numeric, got: {work_item_id}")

            # Fetch current work item
            print(f"Fetching work item #{work_item_id}...")
            current_work_item = self.api_client.get_work_item(work_item_id)

            if not current_work_item:
                raise ValueError(f"Work item #{work_item_id} not found")

            # Get work item type and current state
            work_item_type = current_work_item['fields'].get('System.WorkItemType', 'Unknown')
            current_state = current_work_item['fields'].get(FIELD_STATE, 'Unknown')

            print(f"Work item type: {work_item_type}")
            print(f"Current state: {current_state}")

            # Validate new state based on work item type
            valid_states = []
            if work_item_type == WORK_ITEM_TYPE_BUG:
                valid_states = BUG_STATES
            elif work_item_type == WORK_ITEM_TYPE_TASK:
                valid_states = TASK_STATES
            elif work_item_type == WORK_ITEM_TYPE_USER_STORY:
                valid_states = USER_STORY_STATES
            else:
                raise ValueError(f"Unsupported work item type: {work_item_type}")

            if new_state not in valid_states:
                raise ValueError(
                    f"Invalid state '{new_state}' for {work_item_type}. "
                    f"Valid states: {', '.join(valid_states)}"
                )

            # Check if already in the requested state
            if current_state == new_state:
                print(f"SUCCESS: Work item #{work_item_id} is already in state '{new_state}'")
                return current_work_item

            # Update state
            print(f"Updating state: {current_state} -> {new_state}")
            update_fields = {FIELD_STATE: new_state}

            updated_work_item = self.api_client.update_work_item(work_item_id, update_fields)

            if updated_work_item:
                # Check and assign user if needed
                self._check_and_assign_user(updated_work_item, work_item_id)

                print(f"SUCCESS: Updated work item #{work_item_id} to state '{new_state}'")
                print(f"  URL: {updated_work_item['_links']['html']['href']}")
                return updated_work_item
            else:
                print(f"FAILED: Failed to update work item #{work_item_id}")
                return None

        except ValueError as e:
            print(f"Error: {e}")
            return None
        except Exception as e:
            print(f"Error updating work item #{work_item_id}: {e}")
            import traceback
            traceback.print_exc()
            return None

    def get_bugs(self, assigned_to: Optional[str] = None, include_all_states: bool = False) -> List[Dict]:
        """
        Get bugs from Azure DevOps

        Args:
            assigned_to: Optional email or display name to filter by assigned user
            include_all_states: If False, only returns New/Active states.
                              If True, returns all states including Closed/Removed.

        Returns:
            List of bug work items
        """
        # Build WIQL query
        wiql_query = """
        SELECT [System.Id], [System.Title], [System.State], [System.AssignedTo],
               [System.CreatedDate], [Microsoft.VSTS.Common.Priority], [System.Tags]
        FROM WorkItems
        WHERE [System.WorkItemType] = 'Bug'
        """

        if not include_all_states:
            wiql_query += " AND ([System.State] = 'New' OR [System.State] = 'Active')"

        if assigned_to:
            wiql_query += f" AND [System.AssignedTo] = '{assigned_to}'"

        wiql_query += " ORDER BY [Microsoft.VSTS.Common.Priority] ASC, [System.CreatedDate] DESC"

        # Execute query
        work_items = self.api_client.query_work_items(wiql_query)

        if not work_items:
            return []

        # Extract IDs and fetch all work items in batch
        work_item_ids = [item['id'] for item in work_items]
        detailed_items = self.api_client.get_work_items_batch(work_item_ids)

        return detailed_items

    def update_work_item_from_json(self, json_file_path: str, iteration_path: Optional[str] = None) -> Optional[Dict]:
        """
        Read JSON file and update work item in Azure DevOps

        Args:
            json_file_path: Path to JSON file containing update data
            iteration_path: Optional manual iteration path override

        Returns:
            Updated work item or None

        Raises:
            ValueError: If JSON is invalid or missing required fields
        """
        try:
            # Read JSON file
            with open(json_file_path, 'r', encoding='utf-8') as f:
                update_data = json.load(f)

            # Validate required field: id
            if 'id' not in update_data:
                raise ValueError("JSON file must contain 'id' field with work item ID")

            work_item_id = update_data['id']

            # Validate ID is integer
            try:
                work_item_id = int(work_item_id)
            except (ValueError, TypeError):
                raise ValueError(f"Work item ID must be numeric, got: {work_item_id}")

            # Fetch current work item (with relations to detect parent changes)
            print(f"Fetching work item #{work_item_id}...")
            current_work_item = self.api_client.get_work_item(work_item_id, expand_relations=True)

            if not current_work_item:
                raise ValueError(f"Work item #{work_item_id} not found")

            # Get work item type
            work_item_type = current_work_item['fields'].get('System.WorkItemType', 'Unknown')
            print(f"Work item type: {work_item_type}")

            # Map update fields (returns tuple: fields, parent_changes, child_changes, related_changes)
            print(f"Mapping update fields...")
            update_fields, parent_changes, child_changes, related_changes = \
                self.json_to_azure_update.map_update_fields(update_data, current_work_item, iteration_path, self.iteration_service)

            # Check if there are any changes
            if not update_fields and not parent_changes and not child_changes and not related_changes:
                print(f"SUCCESS: No changes detected for work item #{work_item_id}")
                print(f"  All provided fields already have the specified values")
                return current_work_item

            # Display fields being updated
            if update_fields:
                print(f"Updating {len(update_fields)} field(s):")
                for field_name in update_fields.keys():
                    print(f"  - {field_name}")

            # Display parent relation changes
            if parent_changes:
                action = parent_changes.get('action')
                if action == 'add':
                    print(f"Adding parent relation:")
                    print(f"  - New parent ID: {parent_changes.get('new_parent_id')}")
                elif action == 'remove':
                    print(f"Removing parent relation:")
                    print(f"  - Old parent ID: {parent_changes.get('old_parent_id')}")
                elif action == 'replace':
                    print(f"Replacing parent relation:")
                    print(f"  - Old parent ID: {parent_changes.get('old_parent_id')}")
                    print(f"  - New parent ID: {parent_changes.get('new_parent_id')}")

            # Display child relation changes
            if child_changes:
                if "remove" in child_changes:
                    removed_ids = [str(item['id']) for item in child_changes['remove']]
                    print(f"Removing {len(removed_ids)} child relation(s): {', '.join([f'#{cid}' for cid in removed_ids])}")
                if "add" in child_changes:
                    print(f"Adding {len(child_changes['add'])} child relation(s): {', '.join([f'#{cid}' for cid in child_changes['add']])}")

            # Display related relation changes
            if related_changes:
                if "remove" in related_changes:
                    removed_ids = [str(item['id']) for item in related_changes['remove']]
                    print(f"Removing {len(removed_ids)} related relation(s): {', '.join([f'#{rid}' for rid in removed_ids])}")
                if "add" in related_changes:
                    print(f"Adding {len(related_changes['add'])} related relation(s): {', '.join([f'#{rid}' for rid in related_changes['add']])}")

            # Perform update
            updated_work_item = self.api_client.update_work_item(work_item_id, update_fields, parent_changes, child_changes, related_changes)

            if updated_work_item:
                # Check and assign user if needed
                self._check_and_assign_user(updated_work_item, work_item_id)

                print(f"SUCCESS: Updated work item #{work_item_id}")
                print(f"  URL: {updated_work_item['_links']['html']['href']}")
                return updated_work_item
            else:
                print(f"FAILED: Failed to update work item #{work_item_id}")
                return None

        except FileNotFoundError:
            print(f"Error: JSON file not found: {json_file_path}")
            return None
        except json.JSONDecodeError as e:
            print(f"Error: Invalid JSON format in {json_file_path}: {e}")
            return None
        except ValueError as e:
            print(f"Error: {e}")
            return None
        except Exception as e:
            print(f"Error processing {json_file_path}: {e}")
            import traceback
            traceback.print_exc()
            return None

    def get_features(self, assigned_to: Optional[str] = None, include_all_states: bool = False) -> List[Dict]:
        """
        Get features from Azure DevOps

        Args:
            assigned_to: Optional email or display name to filter by assigned user
                        If None, returns ALL features without assigned_to filter
            include_all_states: If False, only returns New/In Progress states.
                              If True, returns all states including Completed/Removed.

        Returns:
            List of feature work items
        """
        # Build WIQL query
        wiql_query = """
        SELECT [System.Id], [System.Title], [System.State], [System.AssignedTo],
               [System.CreatedDate], [Microsoft.VSTS.Common.Priority], [System.Tags]
        FROM WorkItems
        WHERE [System.WorkItemType] = 'Feature'
        """

        if not include_all_states:
            wiql_query += " AND ([System.State] = 'New' OR [System.State] = 'In Progress')"

        # Only add assigned_to filter if provided (not None)
        if assigned_to:
            wiql_query += f" AND [System.AssignedTo] = '{assigned_to}'"

        wiql_query += " ORDER BY [Microsoft.VSTS.Common.Priority] ASC, [System.CreatedDate] DESC"

        # Execute query
        work_items = self.api_client.query_work_items(wiql_query)

        if not work_items:
            return []

        # Extract IDs and fetch all work items in batch
        work_item_ids = [item['id'] for item in work_items]
        detailed_items = self.api_client.get_work_items_batch(work_item_ids)

        return detailed_items

    def update_work_item_from_json(self, json_file_path: str, iteration_path: Optional[str] = None) -> Optional[Dict]:
        """
        Read JSON file and update work item in Azure DevOps

        Args:
            json_file_path: Path to JSON file containing update data
            iteration_path: Optional manual iteration path override

        Returns:
            Updated work item or None

        Raises:
            ValueError: If JSON is invalid or missing required fields
        """
        try:
            # Read JSON file
            with open(json_file_path, 'r', encoding='utf-8') as f:
                update_data = json.load(f)

            # Validate required field: id
            if 'id' not in update_data:
                raise ValueError("JSON file must contain 'id' field with work item ID")

            work_item_id = update_data['id']

            # Validate ID is integer
            try:
                work_item_id = int(work_item_id)
            except (ValueError, TypeError):
                raise ValueError(f"Work item ID must be numeric, got: {work_item_id}")

            # Fetch current work item (with relations to detect parent changes)
            print(f"Fetching work item #{work_item_id}...")
            current_work_item = self.api_client.get_work_item(work_item_id, expand_relations=True)

            if not current_work_item:
                raise ValueError(f"Work item #{work_item_id} not found")

            # Get work item type
            work_item_type = current_work_item['fields'].get('System.WorkItemType', 'Unknown')
            print(f"Work item type: {work_item_type}")

            # Map update fields (returns tuple: fields, parent_changes, child_changes, related_changes)
            print(f"Mapping update fields...")
            update_fields, parent_changes, child_changes, related_changes = \
                self.json_to_azure_update.map_update_fields(update_data, current_work_item, iteration_path, self.iteration_service)

            # Check if there are any changes
            if not update_fields and not parent_changes and not child_changes and not related_changes:
                print(f"SUCCESS: No changes detected for work item #{work_item_id}")
                print(f"  All provided fields already have the specified values")
                return current_work_item

            # Display fields being updated
            if update_fields:
                print(f"Updating {len(update_fields)} field(s):")
                for field_name in update_fields.keys():
                    print(f"  - {field_name}")

            # Display parent relation changes
            if parent_changes:
                action = parent_changes.get('action')
                if action == 'add':
                    print(f"Adding parent relation:")
                    print(f"  - New parent ID: {parent_changes.get('new_parent_id')}")
                elif action == 'remove':
                    print(f"Removing parent relation:")
                    print(f"  - Old parent ID: {parent_changes.get('old_parent_id')}")
                elif action == 'replace':
                    print(f"Replacing parent relation:")
                    print(f"  - Old parent ID: {parent_changes.get('old_parent_id')}")
                    print(f"  - New parent ID: {parent_changes.get('new_parent_id')}")

            # Display child relation changes
            if child_changes:
                if "remove" in child_changes:
                    removed_ids = [str(item['id']) for item in child_changes['remove']]
                    print(f"Removing {len(removed_ids)} child relation(s): {', '.join([f'#{cid}' for cid in removed_ids])}")
                if "add" in child_changes:
                    print(f"Adding {len(child_changes['add'])} child relation(s): {', '.join([f'#{cid}' for cid in child_changes['add']])}")

            # Display related relation changes
            if related_changes:
                if "remove" in related_changes:
                    removed_ids = [str(item['id']) for item in related_changes['remove']]
                    print(f"Removing {len(removed_ids)} related relation(s): {', '.join([f'#{rid}' for rid in removed_ids])}")
                if "add" in related_changes:
                    print(f"Adding {len(related_changes['add'])} related relation(s): {', '.join([f'#{rid}' for rid in related_changes['add']])}")

            # Perform update
            updated_work_item = self.api_client.update_work_item(work_item_id, update_fields, parent_changes, child_changes, related_changes)

            if updated_work_item:
                # Check and assign user if needed
                self._check_and_assign_user(updated_work_item, work_item_id)

                print(f"SUCCESS: Updated work item #{work_item_id}")
                print(f"  URL: {updated_work_item['_links']['html']['href']}")
                return updated_work_item
            else:
                print(f"FAILED: Failed to update work item #{work_item_id}")
                return None

        except FileNotFoundError:
            print(f"Error: JSON file not found: {json_file_path}")
            return None
        except json.JSONDecodeError as e:
            print(f"Error: Invalid JSON format in {json_file_path}: {e}")
            return None
        except ValueError as e:
            print(f"Error: {e}")
            return None
        except Exception as e:
            print(f"Error processing {json_file_path}: {e}")
            import traceback
            traceback.print_exc()
            return None

    def duplicate_work_item(self, work_item_id: int, iteration_path: Optional[str] = None) -> Optional[Dict]:
        """
        Duplicate a work item with incremented title and related link to original

        Args:
            work_item_id: ID of work item to duplicate
            iteration_path: Optional manual iteration path override

        Returns:
            Created work item or None on failure
        """
        # 1. Get original work item
        original = self.api_client.get_work_item(work_item_id)
        if not original:
            print(f"Error: Work item #{work_item_id} not found")
            return None

        original_fields = original.get('fields', {})
        work_item_type = original_fields.get(FIELD_WORK_ITEM_TYPE)

        print(f"Duplicating {work_item_type} #{work_item_id}: {original_fields.get(FIELD_TITLE)}")

        # 2. Generate new title
        original_title = original_fields.get(FIELD_TITLE, 'Untitled')
        new_title = self._get_next_title(original_title)

        # 3. Build fields for new work item
        fields = {
            FIELD_TITLE: new_title,
            FIELD_STATE: DEFAULT_INITIAL_STATE,  # Always start with "New"
            FIELD_AREA_PATH: original_fields.get(FIELD_AREA_PATH),
        }

        # Set iteration (manual override OR automatic)
        if iteration_path:
            self.iteration_service.validate_iteration_path(iteration_path)
            fields[FIELD_ITERATION_PATH] = iteration_path.lstrip('\\').replace('\\Iteration\\', '\\')
        else:
            # Automatic selection (current iteration)
            current_iteration = self.iteration_service.get_current_iteration()
            fields[FIELD_ITERATION_PATH] = current_iteration.path.lstrip('\\').replace('\\Iteration\\', '\\')

        # Copy optional fields if they exist
        if original_fields.get(FIELD_DESCRIPTION):
            fields[FIELD_DESCRIPTION] = original_fields[FIELD_DESCRIPTION]

        if original_fields.get(FIELD_PRIORITY):
            fields[FIELD_PRIORITY] = original_fields[FIELD_PRIORITY]

        if original_fields.get(FIELD_ASSIGNED_TO):
            fields[FIELD_ASSIGNED_TO] = original_fields[FIELD_ASSIGNED_TO]

        # Copy type-specific fields
        if work_item_type == WORK_ITEM_TYPE_BUG:
            if original_fields.get(FIELD_BUG_SYSTEM_INFO):
                fields[FIELD_BUG_SYSTEM_INFO] = original_fields[FIELD_BUG_SYSTEM_INFO]

        # 4. Create work item with related link to original
        related_ids = [work_item_id]  # Link back to original

        new_work_item = self.api_client.create_work_item(
            work_item_type=work_item_type,
            fields=fields,
            parent_id=None,
            child_ids=None,
            related_ids=related_ids
        )

        if new_work_item:
            new_id = new_work_item['id']
            print(f"SUCCESS: Created duplicate work item #{new_id}: {new_title}")
            print(f"  Original: #{work_item_id}")
            print(f"  Related link added: #{work_item_id} <-> #{new_id}")
            print(f"  Iteration: {fields[FIELD_ITERATION_PATH]}")
            print(f"  URL: {new_work_item['_links']['html']['href']}")
            return new_work_item
        else:
            print(f"FAILED: Could not duplicate work item #{work_item_id}")
            return None

    def _get_next_title(self, original_title: str) -> str:
        """
        Generate next title by incrementing -FX suffix or adding -F2

        Args:
            original_title: Original work item title

        Returns:
            New title with incremented suffix

        Examples:
            "My Task" → "My Task-F2"
            "My Task-F2" → "My Task-F3"
            "My Task-F9" → "My Task-F10"
        """
        # Check if title ends with -FX pattern (e.g., -F2, -F10)
        match = re.search(r'-F(\d+)$', original_title)

        if match:
            # Found pattern, increment the number
            current_num = int(match.group(1))
            next_num = current_num + 1
            new_title = re.sub(r'-F\d+$', f'-F{next_num}', original_title)
        else:
            # No pattern found, add -F2
            new_title = f"{original_title}-F2"

        return new_title
