"""
CLI Command Handler
Routes and handles command-line arguments
"""

import os
import sys
from pathlib import Path
from typing import List, Optional
from ..api import WorkItemService, AzureDevOpsAPIClient
from ..config import ConfigManager
from ..config.constants import FIELD_ASSIGNED_TO, FIELD_AREA_PATH, FIELD_ITERATION_PATH
from .display import Display


class CommandHandler:
    """Handles CLI command routing and execution"""

    def __init__(self, work_item_service: WorkItemService, config_manager: ConfigManager):
        """
        Initialize command handler

        Args:
            work_item_service: Work item service instance
            config_manager: Configuration manager instance
        """
        self.service = work_item_service
        self.config = config_manager
        self.display = Display()

    def handle_stories(self, args: List[str]):
        """Handle --stories command"""
        # Check for --simple flag
        simple_mode = '--simple' in args
        if simple_mode:
            args = [arg for arg in args if arg != '--simple']

        # Check for --all flag
        include_all_states = '--all' in args
        if include_all_states:
            args = [arg for arg in args if arg != '--all']

        # If email not provided as argument, use from config
        if len(args) > 0:
            assigned_to = args[0]
        else:
            assigned_to = self.config.get('user_email')

        # Show filter info
        if assigned_to:
            state_info = "all states" if include_all_states else "New/Active/Holding states"
            print(f"\nFiltering user stories assigned to: {assigned_to} ({state_info})")
        else:
            state_info = "all states" if include_all_states else "New/Active/Holding states"
            print(f"\nShowing all user stories ({state_info}, no assigned_to filter)")

        stories = self.service.get_user_stories(assigned_to, include_all_states)

        if simple_mode:
            self.display.print_user_stories_simple(stories)
        else:
            self.display.print_user_stories(stories)

    def handle_tasks(self, args: List[str]):
        """Handle --tasks command"""
        # Check for --simple flag
        simple_mode = '--simple' in args
        if simple_mode:
            args = [arg for arg in args if arg != '--simple']

        # Check for --all flag
        include_all_states = '--all' in args
        if include_all_states:
            args = [arg for arg in args if arg != '--all']

        # If email not provided as argument, use from config
        if len(args) > 0:
            assigned_to = args[0]
        else:
            assigned_to = self.config.get('user_email')

        # Show filter info
        if assigned_to:
            state_info = "all states" if include_all_states else "New/In Progress/Holding states"
            print(f"\nFiltering tasks assigned to: {assigned_to} ({state_info})")
        else:
            state_info = "all states" if include_all_states else "New/In Progress/Holding states"
            print(f"\nShowing all tasks ({state_info}, no assigned_to filter)")

        tasks = self.service.get_tasks(assigned_to, include_all_states)

        if simple_mode:
            self.display.print_tasks_simple(tasks)
        else:
            self.display.print_tasks(tasks)

    def handle_bugs(self, args: List[str]):
        """Handle --bugs command"""
        # Check for --simple flag
        simple_mode = '--simple' in args
        if simple_mode:
            args = [arg for arg in args if arg != '--simple']

        # Check for --all flag
        include_all_states = '--all' in args
        if include_all_states:
            args = [arg for arg in args if arg != '--all']

        # If email not provided as argument, use from config
        if len(args) > 0:
            assigned_to = args[0]
        else:
            assigned_to = self.config.get('user_email')

        # Show filter info
        if assigned_to:
            state_info = "all states" if include_all_states else "New/Active states"
            print(f"\nFiltering bugs assigned to: {assigned_to} ({state_info})")
        else:
            state_info = "all states" if include_all_states else "New/Active states"
            print(f"\nShowing all bugs ({state_info}, no assigned_to filter)")

        bugs = self.service.get_bugs(assigned_to, include_all_states)

        if simple_mode:
            self.display.print_bugs_simple(bugs)
        else:
            self.display.print_bugs(bugs)

    def handle_features(self, args: List[str]):
        """Handle --features command with flexible filtering"""
        # Check for --simple flag
        simple_mode = '--simple' in args
        if simple_mode:
            args = [arg for arg in args if arg != '--simple']

        # Check for --all flag
        include_all_states = '--all' in args
        if include_all_states:
            args = [arg for arg in args if arg != '--all']

        if len(args) == 0:
            # No argument: Show ALL features (no filter)
            assigned_to = None
            state_info = "all states" if include_all_states else "New/In Progress states"
            print(f"\nShowing all features ({state_info}, no assigned_to filter)")
        elif args[0] == "--me":
            # --me argument: Filter by config user_email
            assigned_to = self.config.get('user_email')
            state_info = "all states" if include_all_states else "New/In Progress states"
            print(f"\nFiltering features assigned to: {assigned_to} ({state_info})")
        else:
            # Email provided: Filter by that email
            assigned_to = args[0]
            state_info = "all states" if include_all_states else "New/In Progress states"
            print(f"\nFiltering features assigned to: {assigned_to} ({state_info})")

        features = self.service.get_features(assigned_to, include_all_states)

        if simple_mode:
            self.display.print_features_simple(features)
        else:
            self.display.print_features(features)

    def handle_update(self, args: List[str], iteration_path: Optional[str] = None):
        """Handle --update command with JSON file

        Args:
            args: Command arguments
            iteration_path: Optional manual iteration path override
        """
        if len(args) < 1:
            print("Error: JSON file path is required")
            print("Usage: python -m azure_generator --update <json_file_path> [--iteration <path>]")
            sys.exit(1)

        json_file_path = args[0]

        # Check file exists
        if not os.path.isfile(json_file_path):
            print(f"Error: File not found: {json_file_path}")
            sys.exit(1)

        # Perform update
        self.service.update_work_item_from_json(json_file_path, iteration_path)

    def handle_delete(self, args: List[str]):
        """Handle --delete command to mark work item as Removed"""
        if len(args) < 1:
            print("Error: Work item ID is required")
            print("Usage: python -m azure_generator --delete <work_item_id>")
            sys.exit(1)

        try:
            work_item_id = int(args[0])
        except ValueError:
            print(f"Error: Invalid work item ID: {args[0]}")
            print("Work item ID must be a number")
            sys.exit(1)

        # Perform delete (mark as Removed)
        self.service.delete_work_item(work_item_id)

    def handle_status(self, args: List[str]):
        """Handle --status command to update work item status"""
        if len(args) < 2:
            print("Error: Work item ID and new state are required")
            print("Usage: python -m azure_generator --status <work_item_id> <new_state>")
            print()
            print("Valid states by work item type:")
            print("  Bug: New, Active, Closed, Removed")
            print("  Task: New, Holding, In Progress, Completed, Removed")
            print("  User Story: New, Active, Holding, Closed, Removed")
            sys.exit(1)

        try:
            work_item_id = int(args[0])
        except ValueError:
            print(f"Error: Invalid work item ID: {args[0]}")
            print("Work item ID must be a number")
            sys.exit(1)

        new_state = args[1]

        # Perform status update
        self.service.update_work_item_status(work_item_id, new_state)

    def handle_save(self, args: List[str]):
        """Handle --save command"""
        if len(args) < 1:
            print("Error: Work item ID is required")
            sys.exit(1)

        work_item_id = int(args[0])
        output_path = args[1] if len(args) > 1 else None
        self.service.save_work_item_to_json(work_item_id, output_path)

    def handle_get(self, args: List[str]):
        """Handle --get command"""
        # Check for --simple flag
        simple_mode = '--simple' in args
        if simple_mode:
            args = [arg for arg in args if arg != '--simple']

        if len(args) < 1:
            print("Error: Work item ID is required")
            sys.exit(1)

        work_item_id = int(args[0])
        work_item = self.service.api_client.get_work_item(work_item_id)
        if work_item:
            if simple_mode:
                self.display.print_work_item_simple(work_item)
            else:
                self.display.print_work_item(work_item)

    def handle_duplicate(self, args: List[str], iteration_path: Optional[str] = None):
        """Handle --duplicate command to duplicate a work item

        Args:
            args: Command arguments
            iteration_path: Optional manual iteration path override
        """
        if len(args) < 1:
            print("Error: Work item ID is required")
            print("Usage: python -m azure_generator --duplicate <work_item_id> [--iteration <path>]")
            sys.exit(1)

        try:
            work_item_id = int(args[0])
        except ValueError:
            print(f"Error: Invalid work item ID: {args[0]}")
            print("Work item ID must be a number")
            sys.exit(1)

        # Duplicate the work item
        self.service.duplicate_work_item(work_item_id, iteration_path)

    def handle_file_or_directory(self, path: str, iteration_path: Optional[str] = None):
        """Handle file or directory path

        Args:
            path: File, directory or work item ID
            iteration_path: Optional manual iteration path override
        """
        if os.path.isfile(path):
            self.service.create_work_item_from_json(path, parent_id=None, iteration_path=iteration_path)
        elif os.path.isdir(path):
            self.service.process_directory(path, parent_id=None, iteration_path=iteration_path)
        else:
            # Try to parse as work item ID
            try:
                work_item_id = int(path)
                work_item = self.service.api_client.get_work_item(work_item_id)
                if work_item:
                    self.display.print_work_item(work_item)
            except ValueError:
                print(f"Error: {path} is not a valid file, directory, or work item ID")
                sys.exit(1)

    def handle_default(self):
        """Handle default behavior (no arguments) - Show usage"""
        self.display.print_usage()

    def handle_today(self, iteration_path: Optional[str] = None):
        """Handle --today command - Process today's date folder

        Args:
            iteration_path: Optional manual iteration path override
        """
        from datetime import datetime

        tasks_folder = self.config.get('tasks_folder', 'Tasks')

        # Check if tasks_folder is absolute or relative path
        tasks_path = Path(tasks_folder)
        if tasks_path.is_absolute():
            tasks_dir = tasks_path
        else:
            tasks_dir = Path.cwd() / tasks_folder

        if not tasks_dir.exists():
            print(f"Error: {tasks_folder} directory not found")
            print(f"Expected path: {tasks_dir}")
            sys.exit(1)

        # Get today's date folder (format: DD-MM-YYYY)
        today_folder = datetime.now().strftime('%d-%m-%Y')
        today_dir = tasks_dir / today_folder

        if today_dir.exists():
            print(f"Processing today's tasks: {today_folder}")
            self.service.process_directory(str(today_dir), parent_id=None, iteration_path=iteration_path)
        else:
            print(f"No tasks folder found for today: {today_folder}")
            print(f"Expected path: {today_dir}")
            print("\nTip: Create a folder with today's date (DD-MM-YYYY format) in Tasks/")
            print("     or specify a path manually: python -m azure_generator <path>")

    def execute(self, argv: List[str]):
        """
        Execute command based on arguments

        Args:
            argv: Command-line arguments (sys.argv[1:])
        """
        if len(argv) == 0:
            self.handle_default()
            return

        # Parse --iteration parameter (can appear anywhere in args)
        iteration_path = None
        if "--iteration" in argv:
            iteration_idx = argv.index("--iteration")
            if iteration_idx + 1 >= len(argv):
                print("Error: --iteration requires a path argument")
                print("Example: --iteration \"ML AR-GE\\2025\\October\\13.10.2025 - 24.10.2025\"")
                sys.exit(1)
            iteration_path = argv[iteration_idx + 1]
            # Remove --iteration and its value from argv
            argv = argv[:iteration_idx] + argv[iteration_idx + 2:]

        if len(argv) == 0:
            self.handle_default()
            return

        command = argv[0]
        args = argv[1:]

        # Route to appropriate handler (pass iteration_path where applicable)
        if command == "--help" or command == "-h":
            self.display.print_usage()
        elif command == "--today":
            self.handle_today(iteration_path)
        elif command == "--stories":
            self.handle_stories(args)
        elif command == "--tasks":
            self.handle_tasks(args)
        elif command == "--bugs":
            self.handle_bugs(args)
        elif command == "--features":
            self.handle_features(args)
        elif command == "--update":
            self.handle_update(args, iteration_path)
        elif command == "--delete":
            self.handle_delete(args)
        elif command == "--status":
            self.handle_status(args)
        elif command == "--save":
            self.handle_save(args)
        elif command == "--get":
            self.handle_get(args)
        elif command == "--duplicate":
            self.handle_duplicate(args, iteration_path)
        else:
            # Handle multiple file/directory paths
            # First argument is a path, process it and all remaining arguments as paths
            paths_to_process = [command] + args
            for path in paths_to_process:
                self.handle_file_or_directory(path, iteration_path)
