"""
Display Utilities
Handles formatted output to console
"""

from typing import Dict, List
from ..config.constants import *


class Display:
    """Handles console output formatting"""

    @staticmethod
    def print_work_item(work_item: Dict):
        """
        Print work item details in formatted way

        Args:
            work_item: Work item dictionary from Azure DevOps
        """
        fields = work_item.get('fields', {})

        print("\n" + "="*80)
        print(f"Work Item #{work_item['id']}")
        print("="*80)
        print(f"\nTitle: {fields.get(FIELD_TITLE, 'N/A')}")
        print(f"Type: {fields.get(FIELD_WORK_ITEM_TYPE, 'N/A')}")
        print(f"State: {fields.get(FIELD_STATE, 'N/A')}")
        print(f"Priority: {fields.get(FIELD_PRIORITY, 'N/A')}")

        assigned_to_field = fields.get(FIELD_ASSIGNED_TO, {})
        assigned_to = assigned_to_field.get('displayName', 'Unassigned') if isinstance(assigned_to_field, dict) else 'Unassigned'
        print(f"Assigned To: {assigned_to}")

        print(f"Created Date: {fields.get(FIELD_CREATED_DATE, 'N/A')}")
        print(f"Area Path: {fields.get(FIELD_AREA_PATH, 'N/A')}")
        print(f"Iteration Path: {fields.get(FIELD_ITERATION_PATH, 'N/A')}")
        print(f"Tags: {fields.get(FIELD_TAGS, 'N/A')}")

        if fields.get(FIELD_DESCRIPTION):
            print(f"\nDescription:")
            print("-"*80)
            print(fields.get(FIELD_DESCRIPTION))

        print("\n" + "="*80)
        print(f"URL: {work_item['_links']['html']['href']}")
        print("="*80 + "\n")

    @staticmethod
    def print_work_item_simple(work_item: Dict):
        """
        Print single work item in simple format (ID | Title | Type | State)

        Args:
            work_item: Work item dictionary from Azure DevOps
        """
        fields = work_item.get('fields', {})
        work_type = fields.get(FIELD_WORK_ITEM_TYPE, 'N/A')
        title = fields.get(FIELD_TITLE, 'N/A')
        state = fields.get(FIELD_STATE, 'N/A')

        print(f"\n#{work_item['id']} | {title} | {work_type} | {state}\n")

    @staticmethod
    def print_user_stories(stories: List[Dict]):
        """
        Print list of user stories in formatted way

        Args:
            stories: List of user story work items
        """
        if not stories:
            print("No user stories found (New/Active/Holding states).")
            return

        print("\n" + "="*80)
        print(f"User Stories - New/Active/Holding ({len(stories)} found)")
        print("="*80 + "\n")

        for story in stories:
            fields = story.get('fields', {})

            assigned_to_field = fields.get(FIELD_ASSIGNED_TO, {})
            assigned_to = assigned_to_field.get('displayName', 'Unassigned') if isinstance(assigned_to_field, dict) else 'Unassigned'

            print(f"ID: #{story['id']}")
            print(f"Title: {fields.get(FIELD_TITLE, 'N/A')}")
            print(f"State: {fields.get(FIELD_STATE, 'N/A')}")
            print(f"Priority: {fields.get(FIELD_PRIORITY, 'N/A')}")
            print(f"Assigned To: {assigned_to}")
            print(f"Created: {fields.get(FIELD_CREATED_DATE, 'N/A')}")
            print(f"Tags: {fields.get(FIELD_TAGS, 'None')}")
            print(f"URL: {story['_links']['html']['href']}")
            print("-"*80)

        print(f"\nTotal: {len(stories)} user stories\n")

    @staticmethod
    def print_tasks(tasks: List[Dict]):
        """
        Print list of tasks in formatted way

        Args:
            tasks: List of task work items
        """
        if not tasks:
            print("No tasks found (New/In Progress/Holding states).")
            return

        print("\n" + "="*80)
        print(f"Tasks - New/In Progress/Holding ({len(tasks)} found)")
        print("="*80 + "\n")

        for task in tasks:
            fields = task.get('fields', {})

            assigned_to_field = fields.get(FIELD_ASSIGNED_TO, {})
            assigned_to = assigned_to_field.get('displayName', 'Unassigned') if isinstance(assigned_to_field, dict) else 'Unassigned'

            print(f"ID: #{task['id']}")
            print(f"Title: {fields.get(FIELD_TITLE, 'N/A')}")
            print(f"State: {fields.get(FIELD_STATE, 'N/A')}")
            print(f"Priority: {fields.get(FIELD_PRIORITY, 'N/A')}")
            print(f"Assigned To: {assigned_to}")
            print(f"Created: {fields.get(FIELD_CREATED_DATE, 'N/A')}")
            print(f"Tags: {fields.get(FIELD_TAGS, 'None')}")
            print(f"URL: {task['_links']['html']['href']}")
            print("-"*80)

        print(f"\nTotal: {len(tasks)} tasks\n")

    @staticmethod
    def print_bugs(bugs: List[Dict]):
        """
        Print list of bugs in formatted way

        Args:
            bugs: List of bug work items
        """
        if not bugs:
            print("No bugs found (New/Active states).")
            return

        print("\n" + "="*80)
        print(f"Bugs - New/Active ({len(bugs)} found)")
        print("="*80 + "\n")

        for bug in bugs:
            fields = bug.get('fields', {})

            assigned_to_field = fields.get(FIELD_ASSIGNED_TO, {})
            assigned_to = assigned_to_field.get('displayName', 'Unassigned') if isinstance(assigned_to_field, dict) else 'Unassigned'

            print(f"ID: #{bug['id']}")
            print(f"Title: {fields.get(FIELD_TITLE, 'N/A')}")
            print(f"State: {fields.get(FIELD_STATE, 'N/A')}")
            print(f"Priority: {fields.get(FIELD_PRIORITY, 'N/A')}")
            print(f"Assigned To: {assigned_to}")
            print(f"Created: {fields.get(FIELD_CREATED_DATE, 'N/A')}")
            print(f"Tags: {fields.get(FIELD_TAGS, 'None')}")
            print(f"URL: {bug['_links']['html']['href']}")
            print("-"*80)

        print(f"\nTotal: {len(bugs)} bugs\n")

    @staticmethod
    def print_features(features: List[Dict]):
        """
        Print list of features in formatted way

        Args:
            features: List of feature work items
        """
        if not features:
            print("No features found (New/In Progress states).")
            return

        print("\n" + "="*80)
        print(f"Features - New/In Progress ({len(features)} found)")
        print("="*80 + "\n")

        for feature in features:
            fields = feature.get('fields', {})

            assigned_to_field = fields.get(FIELD_ASSIGNED_TO, {})
            assigned_to = assigned_to_field.get('displayName', 'Unassigned') if isinstance(assigned_to_field, dict) else 'Unassigned'

            print(f"ID: #{feature['id']}")
            print(f"Title: {fields.get(FIELD_TITLE, 'N/A')}")
            print(f"State: {fields.get(FIELD_STATE, 'N/A')}")
            print(f"Priority: {fields.get(FIELD_PRIORITY, 'N/A')}")
            print(f"Assigned To: {assigned_to}")
            print(f"Created: {fields.get(FIELD_CREATED_DATE, 'N/A')}")
            print(f"Tags: {fields.get(FIELD_TAGS, 'None')}")
            print(f"URL: {feature['_links']['html']['href']}")
            print("-"*80)

        print(f"\nTotal: {len(features)} features\n")

    @staticmethod
    def print_user_stories_simple(stories: List[Dict]):
        """Print list of user stories in simple format (ID | Title | State)"""
        if not stories:
            print("No user stories found (New/Active/Holding states).")
            return

        print("\n" + "="*80)
        print(f"User Stories - New/Active/Holding ({len(stories)} found)")
        print("="*80)
        for story in stories:
            fields = story.get('fields', {})
            print(f"#{story['id']} | {fields.get(FIELD_TITLE, 'N/A')} | {fields.get(FIELD_STATE, 'N/A')}")
        print(f"\nTotal: {len(stories)} user stories\n")

    @staticmethod
    def print_tasks_simple(tasks: List[Dict]):
        """Print list of tasks in simple format (ID | Title | State)"""
        if not tasks:
            print("No tasks found (New/In Progress/Holding states).")
            return

        print("\n" + "="*80)
        print(f"Tasks - New/In Progress/Holding ({len(tasks)} found)")
        print("="*80)
        for task in tasks:
            fields = task.get('fields', {})
            print(f"#{task['id']} | {fields.get(FIELD_TITLE, 'N/A')} | {fields.get(FIELD_STATE, 'N/A')}")
        print(f"\nTotal: {len(tasks)} tasks\n")

    @staticmethod
    def print_bugs_simple(bugs: List[Dict]):
        """Print list of bugs in simple format (ID | Title | State)"""
        if not bugs:
            print("No bugs found (New/Active states).")
            return

        print("\n" + "="*80)
        print(f"Bugs - New/Active ({len(bugs)} found)")
        print("="*80)
        for bug in bugs:
            fields = bug.get('fields', {})
            print(f"#{bug['id']} | {fields.get(FIELD_TITLE, 'N/A')} | {fields.get(FIELD_STATE, 'N/A')}")
        print(f"\nTotal: {len(bugs)} bugs\n")

    @staticmethod
    def print_features_simple(features: List[Dict]):
        """Print list of features in simple format (ID | Title | State)"""
        if not features:
            print("No features found (New/In Progress states).")
            return

        print("\n" + "="*80)
        print(f"Features - New/In Progress ({len(features)} found)")
        print("="*80)
        for feature in features:
            fields = feature.get('fields', {})
            print(f"#{feature['id']} | {fields.get(FIELD_TITLE, 'N/A')} | {fields.get(FIELD_STATE, 'N/A')}")
        print(f"\nTotal: {len(features)} features\n")

    @staticmethod
    def print_config_error(missing_fields: List[str], field_descriptions: Dict[str, str]):
        """
        Print error message about missing configuration fields

        Args:
            missing_fields: List of missing field names
            field_descriptions: Dictionary mapping field names to descriptions
        """
        print(f"Error: Required fields missing in azure_config.json: {', '.join(missing_fields)}")
        print("\nPlease add the following fields:")
        for field in missing_fields:
            description = field_descriptions.get(field, "No description available")
            print(f"  - {field}: {description}")

    @staticmethod
    def print_usage():
        """Print usage instructions"""
        print("\n" + "="*80)
        print("Azure DevOps Work Item Generator - Usage")
        print("="*80 + "\n")

        print("CREATE WORK ITEMS:")
        print("  python -m azure_generator <path/to/json/file>      Create work item from JSON file")
        print("  python -m azure_generator <path/to/directory>      Create work items from all JSON files in directory")
        print("  python -m azure_generator --today                  Process today's tasks from Tasks/DD-MM-YYYY folder")
        print()

        print("UPDATE WORK ITEMS:")
        print("  python -m azure_generator --update <json_file>     Update work item from JSON file")
        print("  python -m azure_generator --status <id> <state>    Update work item status/state")
        print("  python -m azure_generator --delete <id>            Mark work item as Removed")
        print()

        print("VIEW WORK ITEMS:")
        print("  python -m azure_generator --get <id>               Display work item details")
        print("  python -m azure_generator <id>                     Display work item details")
        print("  python -m azure_generator --stories [email]        List user stories (default: config user)")
        print("  python -m azure_generator --tasks [email]          List tasks (default: config user)")
        print("  python -m azure_generator --bugs [email]           List bugs (default: config user)")
        print("  python -m azure_generator --features [--me|email]  List features (default: all features)")
        print()

        print("SAVE WORK ITEMS:")
        print("  python -m azure_generator --save <id> [path]       Save work item to JSON file")
        print()

        print("DUPLICATE WORK ITEMS:")
        print("  python -m azure_generator --duplicate <id>         Duplicate work item to current iteration")
        print("  python -m azure_generator --duplicate <id> --iteration <path>  Duplicate to specific iteration")
        print()

        print("OPTIONS:")
        print("  --simple                                           Use simple output format")
        print("  --all                                              Include all states (including Completed/Closed/Removed)")
        print("  --iteration <path>                                 Manually override iteration (optional)")
        print()

        print("ITERATION (Auto-Selected):")
        print("  Iteration is automatically selected from Azure DevOps based on today's date")
        print("  Use --iteration to override: --iteration \"ML AR-GE\\2025\\October\\13.10.2025 - 24.10.2025\"")
        print("  Or add \"iteration\" field to JSON (optional)")
        print()

        print("EXAMPLES:")
        print("  python -m azure_generator task.json                                   Create work item")
        print("  python -m azure_generator --today                                     Process today's tasks")
        print("  python -m azure_generator task.json --iteration \"ML AR-GE\\2025\\October\\13.10.2025 - 24.10.2025\"")
        print("  python -m azure_generator --today --iteration \"ML AR-GE\\2025\\October\\13.10.2025 - 24.10.2025\"")
        print("  python -m azure_generator --tasks                                     List your tasks")
        print("  python -m azure_generator --status 85547 Completed                    Update task status")
        print("  python -m azure_generator --update update.json                        Update work item")
        print("  python -m azure_generator --get 85547                                 Display work item")
        print("  python -m azure_generator --duplicate 85547                           Duplicate work item")
        print()

        print("For detailed documentation, see:")
        print("  - azure_generator/available_usages.txt")
        print("  - azure_generator/generate_tasks_windows.md")
        print("="*80 + "\n")
