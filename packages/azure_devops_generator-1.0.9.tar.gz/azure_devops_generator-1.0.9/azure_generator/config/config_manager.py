"""
Configuration Manager for Azure DevOps Tool
Handles loading, validation, and access to configuration
"""

import json
import os
from pathlib import Path
from typing import Dict, Optional, List
from .constants import REQUIRED_CONFIG_FIELDS, REQUIRED_WORK_ITEM_FIELDS


class ConfigManager:
    """Manages configuration loading and validation"""

    def __init__(self, config_path: Optional[str] = None):
        """
        Initialize configuration manager

        Args:
            config_path: Optional path to config file. If None, looks for azure_config.json in parent directory
        """
        self.config: Dict = {}
        self.config_path = config_path or self._find_config_file()
        self.load_config()

    def _find_config_file(self) -> Optional[Path]:
        """
        Find azure_config.json in the following order:
        1. User's home directory: ~/.azure-generator/config.json
        2. Azure generator module directory (legacy support)
        3. Current working directory (legacy support)
        """
        # First: Check user's home directory (preferred location for pip-installed package)
        home = Path.home()
        home_config = home / ".azure-generator" / "config.json"
        if home_config.exists():
            return home_config

        # Second: Check azure_generator module directory (legacy)
        module_dir = Path(__file__).parent.parent
        module_config = module_dir / "azure_config.json"
        if module_config.exists():
            return module_config

        # Third: Check current working directory (legacy)
        cwd_config = Path.cwd() / "azure_config.json"
        if cwd_config.exists():
            return cwd_config

        return None

    def load_config(self) -> Dict:
        """
        Load configuration from file or environment variables

        Returns:
            Configuration dictionary

        Raises:
            FileNotFoundError: If config file not found and env vars not set
        """
        # Try loading from file
        if self.config_path and Path(self.config_path).exists():
            with open(self.config_path, 'r', encoding='utf-8') as f:
                self.config = json.load(f)
            return self.config

        # Try environment variables as fallback
        self.config = {
            'organization': os.environ.get('AZURE_DEVOPS_ORG'),
            'project': os.environ.get('AZURE_DEVOPS_PROJECT'),
            'pat_token': os.environ.get('AZURE_DEVOPS_PAT'),
            'user_email': os.environ.get('AZURE_USER_EMAIL'),
            'area_path': os.environ.get('AZURE_AREA_PATH'),
            'iteration_prefix': os.environ.get('AZURE_ITERATION_PREFIX'),
            'sprint_start_date': os.environ.get('AZURE_SPRINT_START_DATE')
        }

        # Filter out None values
        self.config = {k: v for k, v in self.config.items() if v is not None}

        if not self.config:
            raise FileNotFoundError(
                "Configuration not found. Please create azure_config.json or set environment variables."
            )

        return self.config

    def validate_basic_config(self) -> List[str]:
        """
        Validate that required basic fields are present

        Returns:
            List of missing field names (empty if all present)
        """
        missing = []
        for field in REQUIRED_CONFIG_FIELDS:
            if not self.config.get(field):
                missing.append(field)
        return missing

    def validate_work_item_config(self) -> List[str]:
        """
        Validate that fields required for work item creation are present

        Returns:
            List of missing field names (empty if all present)
        """
        missing = []
        for field in REQUIRED_WORK_ITEM_FIELDS:
            if not self.config.get(field):
                missing.append(field)
        return missing

    def get(self, key: str, default: Optional[any] = None) -> any:
        """Get configuration value"""
        return self.config.get(key, default)

    def get_required(self, key: str, error_message: Optional[str] = None) -> any:
        """
        Get required configuration value

        Args:
            key: Configuration key
            error_message: Optional custom error message

        Returns:
            Configuration value

        Raises:
            ValueError: If key not found in configuration
        """
        value = self.config.get(key)
        if not value:
            msg = error_message or f"Required configuration '{key}' not found in azure_config.json"
            raise ValueError(msg)
        return value

    def get_auth_credentials(self) -> tuple[str, str, str]:
        """
        Get authentication credentials

        Returns:
            Tuple of (organization, project, pat_token)

        Raises:
            ValueError: If any credential is missing
        """
        organization = self.get_required('organization', "organization is required in azure_config.json")
        project = self.get_required('project', "project is required in azure_config.json")
        pat_token = self.get_required('pat_token', "pat_token is required in azure_config.json")
        return organization, project, pat_token

    def print_missing_fields_help(self, missing_fields: List[str], field_descriptions: Dict[str, str]):
        """Print helpful error message about missing fields"""
        print(f"Error: Required fields missing in azure_config.json: {', '.join(missing_fields)}")
        print("\nPlease add the following fields:")
        for field in missing_fields:
            description = field_descriptions.get(field, "No description available")
            print(f"  - {field}: {description}")

    def to_dict(self) -> Dict:
        """Return configuration as dictionary"""
        return self.config.copy()

    def save_config(self, config_dict: Dict) -> bool:
        """
        Save configuration to file

        Args:
            config_dict: Configuration dictionary to save

        Returns:
            bool: True if successful, False otherwise
        """
        try:
            # Save to home directory
            from ..setup_utils import get_config_path
            config_path = get_config_path()

            # Ensure parent directory exists
            config_path.parent.mkdir(parents=True, exist_ok=True)

            # Write config
            with open(config_path, 'w', encoding='utf-8') as f:
                json.dump(config_dict, f, indent=2, ensure_ascii=False)

            # Update internal config
            self.config = config_dict
            self.config_path = config_path

            return True

        except Exception as e:
            print(f"Error saving config: {e}")
            return False
