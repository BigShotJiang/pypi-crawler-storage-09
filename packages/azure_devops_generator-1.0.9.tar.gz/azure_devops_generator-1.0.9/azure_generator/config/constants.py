"""
Constants and default values for Azure DevOps Tool
All configurable values are centralized here - no hardcoded values in business logic
"""

# Azure DevOps API Configuration
AZURE_API_VERSION = "7.0"

# Work Item Type Constants
WORK_ITEM_TYPE_TASK = "Task"
WORK_ITEM_TYPE_BUG = "Bug"
WORK_ITEM_TYPE_USER_STORY = "User Story"
WORK_ITEM_TYPE_FEATURE = "Feature"

# Azure DevOps Field Names
FIELD_TITLE = "System.Title"
FIELD_DESCRIPTION = "System.Description"
FIELD_STATE = "System.State"
FIELD_PRIORITY = "Microsoft.VSTS.Common.Priority"
FIELD_ASSIGNED_TO = "System.AssignedTo"
FIELD_AREA_PATH = "System.AreaPath"
FIELD_ITERATION_PATH = "System.IterationPath"
FIELD_ORIGINAL_ESTIMATE = "Microsoft.VSTS.Scheduling.OriginalEstimate"
FIELD_BUG_SYSTEM_INFO = "Microsoft.VSTS.TCM.SystemInfo"
FIELD_BUSINESS_VALUE = "Microsoft.VSTS.Common.BusinessValue"
FIELD_WORK_ITEM_TYPE = "System.WorkItemType"
FIELD_CREATED_DATE = "System.CreatedDate"
FIELD_TAGS = "System.Tags"

# Priority Mappings
IMPORTANCE_TO_PRIORITY = {
    "Critical": 1,
    "High": 2,
    "Medium": 3,
    "Low": 4
}

PRIORITY_TO_IMPORTANCE = {
    1: "Critical",
    2: "High",
    3: "Medium",
    4: "Low"
}

# Azure DevOps Work Item States (exact match with Azure)
# Bug States
BUG_STATES = ["New", "Active", "Closed", "Removed"]

# Task States
TASK_STATES = ["New", "Holding", "In Progress", "Completed", "Removed"]

# User Story States
USER_STORY_STATES = ["New", "Active", "Holding", "Closed", "Removed"]

# Feature States
FEATURE_STATES = ["New", "In Progress", "Done", "Removed"]

# Default initial state for creation (all work items start as "New")
DEFAULT_INITIAL_STATE = "New"

# State to Status Mappings (Azure DevOps State → JSON status)
# Maps Azure DevOps work item states to JSON status field values
STATE_TO_STATUS = {
    # Bug states
    "New": "New",
    "Active": "Active",
    "Closed": "Closed",

    # Task states
    "Holding": "Holding",
    "In Progress": "In Progress",
    "Completed": "Completed",

    # Common state for deletion
    "Removed": "Removed",
}

# Status to State Mappings (JSON status → Azure DevOps State)
# Maps JSON status field values to Azure DevOps work item states
# Note: Same mapping works for all work item types due to state name consistency
STATUS_TO_STATE = {
    # Bug & User Story states
    "New": "New",
    "Active": "Active",
    "Closed": "Closed",

    # Task states
    "Holding": "Holding",
    "In Progress": "In Progress",
    "Completed": "Completed",

    # Common state for deletion
    "Removed": "Removed",
}

# Required Config Fields
REQUIRED_CONFIG_FIELDS = {
    'organization': "Azure DevOps organization name",
    'project': "Project name",
    'pat_token': "Personal Access Token"
}

REQUIRED_WORK_ITEM_FIELDS = {
    'area_path': "Team/area classification (e.g., 'ML AR-GE\\MLOps Team')",
    'iteration_cache_ttl_hours': "Hours before iteration cache expires (e.g., 72)",
    'user_email': "Default user email for assignments",
    'tasks_folder': "Folder name for JSON tasks (e.g., 'Tasks')",
    'max_filename_length': "Maximum length for generated filenames (e.g., 50)"
}
