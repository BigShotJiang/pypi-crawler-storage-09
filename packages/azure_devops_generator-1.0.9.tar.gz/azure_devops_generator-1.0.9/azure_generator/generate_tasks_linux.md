---
description: Generate Azure Work Items from conversation history (Linux/Mac)
platform: Linux/Mac
version: 1.0.9
---

# Azure Work Items Generator - Linux/Mac

Bu konuşmayı analiz et ve Microsoft Azure DevOps Work Items formatında hierarchical task/bug'lar oluştur.

## ADIM 1: Kapsam Belirleme

Konuşmayı analiz et ve belirle:
- ✅ **YAPILMIŞ İŞLER:** Zaten tamamlanmış değişiklikler var mı?
- ✅ **PLANLANMIŞ İŞLER:** Yapılması planlanan/konuşulmuş değişiklikler var mı?

**EĞER HER İKİSİ DE VARSA:**
Kullanıcıya sor: "Hangi işler için task oluşturayım?"
- A) Sadece yapılmış işler için
- B) Sadece planlanmış işler için
- C) Her ikisi için de

**EĞER SADECE BİRİ VARSA:**
Direkt o kapsam için devam et, soru sorma.

**⚠️ ÖNEMLİ: BİRLEŞTİRME KURALI**
Konuşmayı analiz ederken küçük/minik işleri birleştir:
- Her küçük değişiklik için ayrı task/bug oluşturma
- Birbirleriyle ilgili küçük işleri tek bir task/bug altında topla
- Örnek: "Login butonuna stil eklendi" + "Login formuna validasyon eklendi" + "Login hatası düzeltildi" → Tek bir "Login Sistemi Geliştirmeleri" task'ı olarak birleştir
- Sadece büyük, bağımsız ve farklı amaçlara hizmet eden işleri ayır

## ADIM 2: Feature'ları Listele

**Tüm Feature'ları basit formatta listele:**

```bash
azure-generator --features --simple
```

**Çıktı formatı:**
```
#85610 | ML Model Training Pipeline | New
#85611 | Data Preprocessing System | In Progress
#85612 | API Gateway Enhancement | New
```

**KULLANICI BİLGİLENDİRME:**
Kullanıcıya feature'ları göster:
```
Feature'lar (New/In Progress):
- #85610: ML Model Training Pipeline (New)
- #85611: Data Preprocessing System (In Progress)
- #85612: API Gateway Enhancement (New)
...

Oluşturacağımız User Story ve Task/Bug'ları bu feature'larla ilişkilendirebiliriz.
```

## ADIM 3: User Story'leri Listele

**User story'leri basit formatta listele:**

```bash
azure-generator --stories --simple
```

**Çıktı formatı:**
```
#85620 | Implement Authentication System | Active
#85621 | Database Migration | New
#85622 | API Refactoring | Holding
```

**KULLANICI BİLGİLENDİRME:**
Kullanıcıya user story'leri göster:
```
User story'leriniz (New/Active/Holding):
- #85620: Implement Authentication System (Active)
- #85621: Database Migration (New)
- #85622: API Refactoring (Holding)
...

Oluşturacağımız task/bug'ları bu user story'lerle ilişkilendirebiliriz.
```

## ADIM 4: İş Tipini Belirle

Her iş için belirle:
- 🐛 **BUG:** Bir hata düzeltmesi mi?
- ✨ **TASK:** Yeni özellik/geliştirme mi?

## ADIM 5: Parent İlişkilerini Belirle

### 5.1: TASK İÇİN PARENT BELİRLEME

**Her task için:**

1. **Uygun User Story bul:**
   - Konuşma içeriğine göre hangi user story'le ilişkili?
   - Mevcut user story'lerden biriyle eşleşiyor mu?

2. **Kullanıcıya öner:**
   ```
   "[Task İsmi]" için user story:
   - Önerim: #85620 "Implement Authentication System" (konuyla alakalı görünüyor)
   - Veya yeni bir user story oluşturalım mı?
   - Veya kendiniz bir user story ID belirtin
   ```

3. **User Story seçildikten sonra - Iteration Kontrolü:**

   **User Story'nin detaylarını al (iteration bilgisi için):**
   ```bash
   python3 -m azure_generator --get 85620
   ```

   **Çıktıdan iteration bilgisini kontrol et:**
   ```
   Iteration Path: ML AR-GE\2025\September\15.09.2025 - 30.09.2025
   ```

   **Bugünün tarihini kontrol et (2025-10-21):**
   - Iteration tarihi: 15.09.2025 - 30.09.2025
   - Bugün: 21.10.2025
   - Sonuç: Iteration bugünü kapsamıyor! ❌

4. **Iteration bugünü kapsamıyorsa - User Story'yi Kopyala:**

   ```bash
   python3 -m azure_generator --duplicate 85620
   ```

   **Çıktı:**
   ```
   SUCCESS: Duplicated work item #85620
     Original: #85620 "Implement Authentication System"
     New: #85650 "Implement Authentication System-F2"
     State: New
     Iteration: ML AR-GE\2025\October\13.10.2025 - 24.10.2025
     Related to: #85620
     URL: https://dev.azure.com/...
   ```

5. **Kopyalanan User Story'nin durumunu ayarla (gerekirse):**

   Eğer orijinal User Story "Active" idiyse, kopyalananı da "Active" yap:
   ```bash
   python3 -m azure_generator --status 85650 "Active"
   ```

6. **YENİ User Story ID'yi parent olarak kullan:**
   - Task'ın parent_id'si: 85650 (kopyalanan User Story)
   - JSON'da kaydet

### 5.2: BUG İÇİN PARENT BELİRLEME

**Her bug için:**

1. **Önce uygun User Story ara:**
   - Konuşma içeriğine göre hangi user story'le ilişkili?
   - Mevcut user story'lerden biriyle eşleşiyor mu?

2. **User Story bulunduysa:**
   - Iteration kontrolü yap (TASK için olan adımları takip et)
   - Iteration bugünü kapsamıyorsa duplicate et
   - Yeni User Story ID'yi parent olarak kullan

3. **User Story bulunamadıysa - Feature ara:**

   **Uygun Feature var mı kontrol et:**
   - Konuşma içeriğine göre hangi feature'la ilişkili?
   - Mevcut feature'lardan biriyle eşleşiyor mu?

   **Kullanıcıya öner:**
   ```
   "[Bug İsmi]" için uygun user story bulunamadı.
   Feature parent önerim: #85610 "ML Model Training Pipeline"
   - Bu feature'ı kullan
   - Veya yeni bir user story oluşturalım mı?
   ```

4. **Parent olarak kaydet:**
   - Bulduğun User Story ID veya Feature ID'yi parent olarak kullan
   - JSON'da kaydet

### 5.3: YENİ USER STORY OLUŞTURMA (Gerekirse)

**EĞER yeni user story oluşturulması gerekiyorsa:**

1. **Feature Parent Belirle:**

   **Uygun Feature var mı kontrol et:**
   - Konuşma içeriğine göre hangi feature'la ilişkili?
   - Mevcut feature'lardan biriyle eşleşiyor mu?

   **Kullanıcıya öner:**
   ```
   "[User Story İsmi]" için feature:
   - Önerim: #85610 "ML Model Training Pipeline" (konuyla alakalı görünüyor)
   - Veya feature parent olmadan oluştur
   ```

2. **Kullanıcıdan bilgi al:**
   ```
   Yeni user story için:
   - Title: [Kullanıcıdan al veya öner]
   - Description: [Kullanıcıdan al veya öner - Yüksek seviye amaç ve hedef]
   - Status: New/Active/Holding/Closed [Kullanıcıdan al veya öner]
   - Parent Feature ID: [Varsa - önceki adımda belirlendi]
   - Business Value: [Sadece status="Closed" ise al, yoksa boş bırak]
   ```

3. **User Story Description Formatı:**

   ⚠️ **ÖNEMLİ:** User Story açıklaması yüksek seviye olmalı:
   - Ne yapılıyor ve neden yapılıyor?
   - Amaç ve hedef nedir?
   - Adım adım implementasyon detayları YAZMA
   - Böylece her task için user story güncellenmeyecek

   **İYİ ÖRNEK:**
   ```
   Bu user story, kullanıcı kimlik doğrulama sistemini JWT tabanlı modern bir yapıya
   geçirmeyi amaçlar. Mevcut session-based sistem güvenlik ve ölçeklenebilirlik
   açısından yetersiz kaldığı için yeni bir yapıya ihtiyaç duyuluyor.
   ```

   **KÖTÜ ÖRNEK (Yapmayın):**
   ```
   1. JWT service oluştur
   2. Login endpoint'i ekle
   3. Token validation middleware yaz
   4. Refresh token mekanizması ekle
   ```

4. **Business Value Belirleme:**

   **SADECE tamamlanmış (Closed) user story'ler için business value belirle:**

   ```
   Business Value değerleri:
   1  → Çok ufak (0.5-1 saat)
   2  → Yarım günlük (~4 saat)
   3  → Tam günlük (~8 saat)
   5  → İki güne yakın (~16 saat)
   8  → Bir hafta (~40 saat)
   13 → Bir haftadan fazla (~65 saat)
   21 → Tüm sprint (~100+ saat)

   "[User Story İsmi]" için tahmini süre nedir?
   Business Value önerim: [X]
   ```

   **EĞER user story henüz tamamlanmamışsa (New/Active/Holding):**
   - Business value boş bırak
   - Kullanıcıya bildir: "User story henüz tamamlanmadığı için business value belirtilmeyecek"

5. **User Story JSON dosyası oluştur:**

   ```json
   {
     "type": "User Story",
     "title": "Implement JWT Authentication",
     "description": "Bu user story, kullanıcı kimlik doğrulama sistemini JWT tabanlı modern bir yapıya geçirmeyi amaçlar. Mevcut session-based sistem güvenlik ve ölçeklenebilirlik açısından yetersiz kaldığı için yeni bir yapıya ihtiyaç duyuluyor.",
     "status": "Active",
     "business_value": "",
     "parent_id": 85610,
     "assigned_to": "user@example.com",
     "tags": ["feature", "auth"]
   }
   ```

6. **Komutu çalıştır:**
   ```bash
   azure-generator "user_story.json"
   ```

7. **Dönen User Story ID'yi kaydet:**
   - Komut çıktısından user story ID'sini al (örn: `#85655`)
   - Bu ID'yi ilgili task/bug'ların `parent_id` alanında kullan

## ADIM 6: Detayları Topla

### 🐛 BUG İÇİN:

```json
{
  "type": "Bug",
  "title": "",
  "summary": "",
  "impact": "",
  "importance": "",
  "discovery_method": "",
  "root_cause": "",
  "solution": "",
  "implementation_details": [],
  "alternative_solutions": [],
  "related_files": [],
  "time_spent_hours": null,
  "status": "",
  "parent_id": null,
  "created_date": "",
  "tags": []
}
```

**Alanların Açıklaması:**
- **title:** Özet bir isim (örn: "Kafka Consumer Timeout Hatası")
- **summary:** Bug'ın kısa açıklaması
- **impact:** Proje üzerindeki etkisi (örn: "Production'da mesaj kaybına sebep oluyor")
- **importance:** Critical/High/Medium/Low
- **discovery_method:** Nasıl keşfedildi (örn: "İki tablo karşılaştırıldı, farklılık gözlemlendi")
- **root_cause:** Sorunun kaynağı/sebepleri (eğer bulunduysa)
- **solution:** Nasıl çözüldü (eğer çözüldüyse)
- **implementation_details:** Çözüm adımları (sadece konuşulmuşsa)
- **alternative_solutions:** Konuşulan ama tercih edilmeyen çözümler (sadece konuşulmuşsa)
- **related_files:** İlgili dosya yolları
- **time_spent_hours:** Harcanan saat (kullanıcıdan alınacak)
- **status:** "New" / "Active" / "Closed"
- **parent_id:** Bağlı olduğu user story veya feature ID (integer, örn: 85620)
- **created_date:** Bugünün tarihi (ISO 8601: YYYY-MM-DD)
- **tags:** İlgili etiketler

**VALID BUG STATES:**
- **New:** Yeni oluşturulmuş, henüz başlanmamış
- **Active:** Üzerinde aktif olarak çalışılıyor
- **Closed:** Çözüldü, kapatıldı

### ✨ TASK İÇİN:

```json
{
  "type": "Task",
  "title": "",
  "summary": "",
  "reason": "",
  "impact": "",
  "importance": "",
  "implementation_steps": [],
  "alternative_approaches": [],
  "related_files": [],
  "time_spent_hours": null,
  "status": "",
  "parent_id": null,
  "created_date": "",
  "tags": []
}
```

**Alanların Açıklaması:**
- **title:** Özet bir isim (örn: "Kafka Consumer Reconnection Mekanizması")
- **summary:** Geliştirmenin kısa açıklaması
- **reason:** Geliştirmenin nedeni
- **impact:** Proje için önemi ve farkı
- **importance:** Critical/High/Medium/Low
- **implementation_steps:** Adımlar (yüksek seviye, kod satırı değil - örn: "Timeout handler eklendi ve error recovery mekanizması güncellendi")
- **alternative_approaches:** Konuşulan ama tercih edilmeyen yaklaşımlar (sadece konuşulmuşsa)
- **related_files:** İlgili dosya yolları
- **time_spent_hours:** Harcanan saat (kullanıcıdan alınacak)
- **status:** "New" / "Holding" / "In Progress" / "Completed"
- **parent_id:** Bağlı olduğu user story ID (integer, örn: 85650 - kopyalanan user story)
- **created_date:** Bugünün tarihi (ISO 8601: YYYY-MM-DD)
- **tags:** İlgili etiketler

**VALID TASK STATES:**
- **New:** Yeni oluşturulmuş, henüz başlanmamış
- **Holding:** Beklemede (engellenmiş veya ertelenmiş)
- **In Progress:** Üzerinde aktif olarak çalışılıyor
- **Completed:** Tamamlandı

## ADIM 7: Süre Hesaplama

Her iş için kullanıcıya sor:

```
"[Task/Bug İsmi]" için harcanan süreyi belirtin:
- Saat olarak (örn: 2.5)
- Veya başlangıç saati (örn: 14:30) - şimdiki saatle farkını hesaplarım
- Veya önerim: [X saat] (karmaşıklığa göre tahminim)
```

**Eğer kullanıcı başlangıç saati verirse:**
- Şimdiki saat ile farkını hesapla
- Sonucu `time_spent_hours` alanına yaz

## ADIM 8: JSON Dosyalarını Kaydet

### Klasör Yapısı:
```
{{TASKS_FOLDER}}/
  └── 21-10-2025/          # Bugünün tarihi (gün-ay-yıl)
      ├── kafka-consumer-timeout-bug.json
      ├── reconnection-mechanism-task.json
      ├── todays_tasks.txt
      └── ...
```

### Kurallar:
1. **Klasör:** `{{TASKS_FOLDER}}/[gün-ay-yıl]/`
2. **Eğer klasör varsa:** Yeni dosyalar ekle, klasörü yeniden oluşturma
3. **Dosya İsimleri:**
   - Küçük harf
   - İngilizce karakterler
   - Tire ile ayrılmış
   - Kısa ve açıklayıcı
   - `.json` uzantılı
4. **Format:** Her dosya tek bir iş için JSON
5. **Boş Alanlar:** Boş alanlar da JSON'da olmalı (null veya "" veya [] olarak)
6. **Parent ID:** Mutlaka integer olarak kaydet (string değil!)

### Dosya Kaydetme:

```json
{
  "type": "Task",
  "title": "Implement JWT Authentication",
  "summary": "Add JWT-based authentication to API",
  "reason": "Need secure user authentication",
  "impact": "All API endpoints will be protected",
  "importance": "High",
  "implementation_steps": [
    "Created JWT token generation service",
    "Implemented refresh token mechanism",
    "Added authentication middleware"
  ],
  "alternative_approaches": [],
  "related_files": [
    "src/auth/jwt_service.py",
    "src/middleware/auth.py"
  ],
  "time_spent_hours": 6,
  "status": "Completed",
  "parent_id": 85650,
  "created_date": "2025-10-21",
  "tags": ["auth", "security", "api"]
}
```

**KAYDETME ADIMLARI:**

1. Bugünün tarihini al (21-10-2025 formatında)
2. `{{TASKS_FOLDER}}/21-10-2025/` klasörünü oluştur (yoksa)
3. Her task/bug için JSON dosyası kaydet
4. Dosya isimlerini topla (sadece dosya isimleri, tam yol değil!)

**Kaydedilen dosyaları listele:**
```
Kaydedilen JSON dosyaları:
- kafka-consumer-timeout-bug.json
- reconnection-mechanism-task.json
- authentication-api-task.json
```

## ADIM 9: Azure DevOps Work Items Oluştur

**Kaydedilen JSON dosyalarını kullanarak Azure DevOps'ta work item'ları oluştur:**

### Birden Fazla Dosya İçin (ÖNERİLEN):
```bash
azure-generator "{{TASKS_FOLDER}}/21-10-2025/kafka-consumer-timeout-bug.json" "{{TASKS_FOLDER}}/21-10-2025/reconnection-mechanism-task.json" "{{TASKS_FOLDER}}/21-10-2025/authentication-api-task.json"
```

### Tüm Klasör İçin:
```bash
azure-generator "{{TASKS_FOLDER}}/21-10-2025/"
```

**ÖNEMLİ:**
- `azure-generator` komutu her yerden çalışır (pip ile global kurulu)
- Dosya yollarını tam yol olarak ver
- Unix path formatını kullan (forward slash `/`)
- Yolları çift tırnak içinde ver
- Parent user story ID otomatik olarak JSON'dan okunacak ve work item'a bağlanacak

**ÇIKTI KONTROLÜ:**
Her work item oluşturulduktan sonra:
- Work item ID'sini göster
- Parent user story/feature bağlantısını doğrula
- Azure DevOps URL'ini göster

**Örnek Çıktı:**
```
Creating Task: Implement JWT Authentication
SUCCESS: Created work item #85660: Implement JWT Authentication
  Parent: #85650
  URL: https://dev.azure.com/org/project/_workitems/edit/85660
```

## ADIM 10: TASK ID'leri todays_tasks.txt'ye Kaydet

**Oluşturulan/güncellenen TASK ID'lerini günlük klasörde sakla:**

1. **Dosya Yolu:** `{{TASKS_FOLDER}}/21-10-2025/todays_tasks.txt`

2. **Her oluşturulan TASK için:**
   - TASK ID'sini al (örn: 85660)
   - `todays_tasks.txt` dosyasını kontrol et
   - Eğer ID zaten dosyada yoksa, dosyaya ekle
   - Her satırda bir ID olmalı

3. **Format:**
   ```
   85660
   85661
   85662
   ```

4. **Kurallar:**
   - Sadece TASK tipindeki work item'ların ID'leri kaydedilecek
   - Bug ve User Story ID'leri kaydedilmeyecek
   - Zaten varsa tekrar ekleme (duplicate kontrolü)
   - Dosya yoksa oluştur
   - Dosya varsa append et

5. **Örnek İşlem:**
   ```
   Oluşturulan Tasklar:
   - #85660: Implement JWT Authentication
   - #85661: Add Refresh Token Mechanism

   todays_tasks.txt dosyasına kaydediliyor...
   ✓ #85660 eklendi
   ✓ #85661 eklendi
   ```

## ADIM 11: Özet Rapor

İşlem bitince göster:
```
✅ Azure Work Items Oluşturuldu

📊 Özet:
- Toplam: X iş
- Bug: Y adet
- Task: Z adet
- Yeni User Story: W adet (duplicate edilen: V adet)
- Durum: Completed (A), In Progress (B), Active (C), New (D)

📁 Konum: {{TASKS_FOLDER}}/21-10-2025/

📋 JSON Dosyaları:
- kafka-consumer-timeout-bug.json
- reconnection-mechanism-task.json
- authentication-api-task.json

🔗 Azure DevOps Work Items:
- Bug #85656: Kafka Consumer Timeout Hatası (Parent: #85650 User Story)
- Task #85660: JWT Authentication Implementation (Parent: #85650 User Story)
- Task #85661: Refresh Token Mechanism (Parent: #85650 User Story)

📈 Parent Hierarchy:
- Feature #85610: ML Model Training Pipeline
  └── User Story #85650: Implement Authentication System-F2 (duplicated from #85620)
      ├── Task #85660: JWT Authentication Implementation
      └── Task #85661: Refresh Token Mechanism

📝 Günlük Task Listesi: {{TASKS_FOLDER}}/21-10-2025/todays_tasks.txt
- #85660
- #85661
```

## ÖNEMLİ KURALLAR:

1. ❌ **YENİ FİKİR ÜRETME:** Sadece konuşulmuş şeyleri kullan
2. ✅ **DETAYLI OL:** Teknik detayları es geçme
3. ✅ **TAM OL:** Tüm JSON alanlarını doldur (boş da olsa)
4. ✅ **DOĞRU TARİH:** Bugünün tarihini kullan (ISO 8601: YYYY-MM-DD)
5. ✅ **KULLANICI İLETİŞİMİ:** Gerektiğinde kullanıcıya sor (kapsam, süre, user story)
6. ✅ **DOSYA İSİMLERİ:** İngilizce, küçük harf, tire ile ayrılmış
7. ✅ **HIERARCHY:** Feature → User Story → Task/Bug hiyerarşisini koru
8. ✅ **PARENT ID FORMAT:** `parent_id` mutlaka integer olmalı (string değil!)
9. ✅ **ITERATION KONTROLÜ:** User Story iteration'ı bugünü kapsamıyorsa duplicate et
10. ✅ **USER STORY DESCRIPTION:** Yüksek seviye amaç ve hedef, adım adım detay yok
11. ✅ **EFFICIENT COMMANDS:** Önce --simple, gerektiğinde --get ile detay
12. ✅ **BUSINESS VALUE:** Sadece tamamlanmış user story'ler için belirle
13. ✅ **STATUS KONTROLÜ:** Geçerli status değerlerini kullan
14. ✅ **AZURE GENERATOR KULLANIMI:** JSON dosyalarını oluşturduktan sonra azure_generator projesini kullanarak Azure DevOps'a kaydet
15. ✅ **TAM YOL KULLAN:** azure_generator komutlarında tam dosya yollarını kullan
16. ✅ **KÜÇÜK İŞLERİ BİRLEŞTİR:** Her minik değişiklik için ayrı task/bug oluşturma
17. ✅ **GLOBAL KOMUT:** `azure-generator` komutu her yerden çalışır (pip ile kurulu)
18. ✅ **TASK TRACKING:** Oluşturulan TASK ID'lerini todays_tasks.txt'ye kaydet

## GÜNCELLEME ve SİLME İŞLEMLERİ:

Kullanıcı bir work item'ı güncellemek veya silmek isterse:

**Örnek: "En son kullandığım user story'nin açıklamasına xyz ekle"**

1. En son kullanılan user story ID'sini bul
2. Güncelleme JSON dosyası oluştur:
   ```json
   {
     "id": 85650,
     "description": "Mevcut açıklama + xyz eklentisi"
   }
   ```
3. Güncelleme komutunu çalıştır:
   ```bash
   azure-generator --update "update-userstory.json"
   ```

**Status güncelleme:**
```bash
azure-generator --status 85650 "Active"
```

**Silme:**
```bash
azure-generator --delete 85650
```

Şimdi konuşmayı analiz et ve işlemi başlat!
