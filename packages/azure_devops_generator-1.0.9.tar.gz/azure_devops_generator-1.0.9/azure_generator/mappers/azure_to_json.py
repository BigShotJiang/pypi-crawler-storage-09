"""
Azure DevOps to JSON Mapper
Maps Azure DevOps work items to JSON task format
"""

from typing import Dict
from ..config.constants import *
from ..utils.html_builder import HTMLBuilder


class AzureToJSONMapper:
    """Maps Azure DevOps work items to JSON format"""

    def __init__(self):
        """Initialize mapper"""
        self.html_builder = HTMLBuilder()

    def map_work_item(self, work_item: Dict) -> Dict:
        """
        Map Azure DevOps work item to JSON task format

        Args:
            work_item: Work item data from Azure DevOps

        Returns:
            Dictionary in task JSON format
        """
        fields = work_item.get('fields', {})

        # Extract basic fields
        work_item_type = fields.get(FIELD_WORK_ITEM_TYPE, WORK_ITEM_TYPE_TASK)
        title = fields.get(FIELD_TITLE, 'Untitled')
        priority = fields.get(FIELD_PRIORITY, 3)
        state = fields.get(FIELD_STATE, 'New')

        # Parse description to extract sections
        description = fields.get(FIELD_DESCRIPTION, '')
        summary = ""
        reason = ""
        impact = ""
        implementation_steps = []
        alternative_approaches = []
        related_files = []

        # Basic extraction from description
        if description:
            text_description = self.html_builder.remove_html_tags(description)
            lines = [line.strip() for line in text_description.split('\n') if line.strip()]
            if lines:
                summary = lines[0] if lines else title

        # Parse tags
        tags_string = fields.get(FIELD_TAGS, '')
        tags = [tag.strip() for tag in tags_string.split(';') if tag.strip()] if tags_string else []

        # Get dates
        created_date = fields.get(FIELD_CREATED_DATE, '')
        if created_date:
            created_date = created_date.split('T')[0]  # Get just the date part

        # Get assigned user
        assigned_to_field = fields.get(FIELD_ASSIGNED_TO, {})
        assigned_to = assigned_to_field.get('displayName', 'Unassigned') if isinstance(assigned_to_field, dict) else str(assigned_to_field)

        # Build task JSON
        task_json = {
            "type": work_item_type,
            "azure_work_item_id": work_item['id'],
            "title": title,
            "summary": summary or title,
            "reason": reason or "Imported from Azure DevOps",
            "impact": impact or "To be determined",
            "importance": PRIORITY_TO_IMPORTANCE.get(priority, "Medium"),
            "implementation_steps": implementation_steps or ["To be defined"],
            "alternative_approaches": alternative_approaches,
            "related_files": related_files,
            "time_spent_hours": fields.get('Microsoft.VSTS.Scheduling.CompletedWork', 0),
            "status": STATE_TO_STATUS.get(state, 'Planned'),
            "created_date": created_date,
            "assigned_to": assigned_to,
            "azure_url": work_item['_links']['html']['href'],
            "tags": tags,
            "description": description
        }

        return task_json
