"""
JSON to Azure DevOps Mapper
Maps JSON work item format to Azure DevOps field structure
"""

from typing import Dict, Optional
from ..config.constants import *
from ..utils.html_builder import HTMLBuilder


class JSONToAzureMapper:
    """Maps JSON work item data to Azure DevOps fields"""

    def __init__(self, config: Dict, iteration_service):
        """
        Initialize mapper

        Args:
            config: Configuration dictionary
            iteration_service: IterationService instance for iteration paths
        """
        self.config = config
        self.iteration_service = iteration_service
        self.html_builder = HTMLBuilder()

    def _build_bug_system_info(self, bug_data: Dict) -> str:
        """
        Build System Info content for Bug work items

        Args:
            bug_data: Bug data from JSON file

        Returns:
            HTML formatted System Info content
        """
        sections = [
            self.html_builder.build_section("Summary", bug_data.get('summary', '')),
            self.html_builder.build_section("Impact", bug_data.get('impact', '')),
            self.html_builder.build_section("Discovery Method", bug_data.get('discovery_method', '')),
            self.html_builder.build_section("Root Cause", bug_data.get('root_cause', '')),
            self.html_builder.build_section("Solution", bug_data.get('solution', '')),
            self.html_builder.build_list("Implementation Details", bug_data.get('implementation_details', []), ordered=True),
            self.html_builder.build_list("Alternative Solutions", bug_data.get('alternative_solutions', []), ordered=False),
            self.html_builder.build_list("Related Files", bug_data.get('related_files', []), ordered=False)
        ]

        return self.html_builder.join_sections(*sections)

    def _build_task_description(self, task_data: Dict) -> str:
        """
        Build Description content for Task work items

        Args:
            task_data: Task data from JSON file

        Returns:
            HTML formatted Description content
        """
        sections = [
            self.html_builder.build_section("Summary", task_data.get('summary', '')),
            self.html_builder.build_section("Reason", task_data.get('reason', '')),
            self.html_builder.build_section("Impact", task_data.get('impact', '')),
            self.html_builder.build_list("Implementation Steps", task_data.get('implementation_steps', []), ordered=True),
            self.html_builder.build_list("Alternative Approaches", task_data.get('alternative_approaches', []), ordered=False),
            self.html_builder.build_list("Related Files", task_data.get('related_files', []), ordered=False)
        ]

        return self.html_builder.join_sections(*sections)

    def map_work_item(self, work_item_data: Dict, iteration_path: Optional[str] = None) -> Dict:
        """
        Map JSON work item data to Azure DevOps work item fields

        Args:
            work_item_data: Work item data from JSON file (Task or Bug)
            iteration_path: Optional manual iteration path override

        Returns:
            Dictionary of Azure DevOps fields

        Raises:
            ValueError: If required config fields are missing
        """
        # Determine work item type
        work_item_type = work_item_data.get('type', WORK_ITEM_TYPE_TASK)

        # Build type-specific content field
        if work_item_type == WORK_ITEM_TYPE_BUG:
            content_field = FIELD_BUG_SYSTEM_INFO
            content_value = self._build_bug_system_info(work_item_data)
        else:
            content_field = FIELD_DESCRIPTION
            content_value = self._build_task_description(work_item_data)

        # Build required fields
        # Note: Always use "New" for initial creation, actual state will be updated after creation if needed
        fields = {
            FIELD_TITLE: work_item_data.get('title', f'Untitled {work_item_type}'),
            content_field: content_value,
            FIELD_STATE: DEFAULT_INITIAL_STATE,  # Always start with "New"
            FIELD_PRIORITY: IMPORTANCE_TO_PRIORITY.get(work_item_data.get('importance', 'Medium'), 3)
        }

        # Add AreaPath (required from config)
        area_path = self.config.get('area_path')
        if not area_path:
            raise ValueError(
                "area_path is required in azure_config.json. "
                "Please add 'area_path' field to your config (e.g., 'ML AR-GE\\\\MLOps Team')"
            )
        fields[FIELD_AREA_PATH] = area_path

        # Set iteration path (manual override OR JSON field OR automatic)
        if iteration_path:
            # CLI parameter has highest priority - validate it
            self.iteration_service.validate_iteration_path(iteration_path)
            # Clean path: remove leading backslash and \Iteration\ part
            fields[FIELD_ITERATION_PATH] = iteration_path.lstrip('\\').replace('\\Iteration\\', '\\')
        elif 'iteration' in work_item_data and work_item_data['iteration']:
            # JSON field has second priority - validate it
            self.iteration_service.validate_iteration_path(work_item_data['iteration'])
            # Clean path: remove leading backslash and \Iteration\ part
            fields[FIELD_ITERATION_PATH] = work_item_data['iteration'].lstrip('\\').replace('\\Iteration\\', '\\')
        else:
            # Automatic selection
            current_iteration = self.iteration_service.get_current_iteration()
            # Clean path: remove leading backslash and \Iteration\ part
            # Old format: ML AR-GE\2025\October\13.10.2025 - 24.10.2025
            # Azure API returns: \ML AR-GE\Iteration\2025\October\13.10.2025 - 24.10.2025
            iteration_path_clean = current_iteration.path.lstrip('\\').replace('\\Iteration\\', '\\')
            fields[FIELD_ITERATION_PATH] = iteration_path_clean

        # Add assigned to - use JSON value if specified, otherwise use config user_email
        if work_item_data.get('assigned_to'):
            fields[FIELD_ASSIGNED_TO] = work_item_data.get('assigned_to')
        else:
            # Auto-assign to user_email from config
            user_email = self.config.get('user_email')
            if user_email:
                fields[FIELD_ASSIGNED_TO] = user_email

        # Add effort (time spent)
        if work_item_data.get('time_spent_hours'):
            fields[FIELD_ORIGINAL_ESTIMATE] = work_item_data['time_spent_hours']

        return fields
