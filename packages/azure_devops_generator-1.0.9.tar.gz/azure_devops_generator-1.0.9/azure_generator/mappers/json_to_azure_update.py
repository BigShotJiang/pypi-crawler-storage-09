"""
JSON to Azure DevOps Update Mapper
Maps JSON update data to Azure DevOps field update structure
Handles partial updates - only provided fields are updated
"""

from typing import Dict, Optional, Any, List, Tuple
from ..config.constants import (
    FIELD_TITLE, FIELD_DESCRIPTION, FIELD_STATE, FIELD_PRIORITY,
    FIELD_ASSIGNED_TO, FIELD_TAGS, FIELD_ORIGINAL_ESTIMATE, FIELD_BUSINESS_VALUE,
    FIELD_BUG_SYSTEM_INFO, FIELD_WORK_ITEM_TYPE, FIELD_ITERATION_PATH,
    WORK_ITEM_TYPE_TASK, WORK_ITEM_TYPE_BUG, WORK_ITEM_TYPE_USER_STORY,
    IMPORTANCE_TO_PRIORITY, STATUS_TO_STATE,
    BUG_STATES, TASK_STATES, USER_STORY_STATES
)
from ..utils.html_builder import HTMLBuilder


class JSONToAzureUpdateMapper:
    """Maps JSON update data to Azure DevOps update fields"""

    def __init__(self):
        """Initialize update mapper"""
        self.html_builder = HTMLBuilder()

    def _get_valid_states(self, work_item_type: str) -> List[str]:
        """
        Get valid states for a work item type

        Args:
            work_item_type: Type of work item

        Returns:
            List of valid states
        """
        if work_item_type == WORK_ITEM_TYPE_BUG:
            return BUG_STATES
        elif work_item_type == WORK_ITEM_TYPE_TASK:
            return TASK_STATES
        elif work_item_type == WORK_ITEM_TYPE_USER_STORY:
            return USER_STORY_STATES
        else:
            return []

    def _validate_status(self, status: str, work_item_type: str) -> Optional[str]:
        """
        Validate and convert JSON status to Azure State

        Args:
            status: JSON status value
            work_item_type: Type of work item

        Returns:
            Azure State value if valid, None otherwise
        """
        # Convert status to State using mapping
        state = STATUS_TO_STATE.get(status)
        if not state:
            return None

        # Validate state is valid for this work item type
        valid_states = self._get_valid_states(work_item_type)
        if state not in valid_states:
            return None

        return state

    def _build_bug_system_info(self, update_data: Dict, current_data: Dict) -> str:
        """
        Build System Info content for Bug work items from update data

        Args:
            update_data: Update data from JSON file
            current_data: Current work item data (used to extract existing values if not updating)

        Returns:
            HTML formatted System Info content
        """
        # Determine which fields are being updated vs kept from current
        summary = update_data.get('summary', '')
        impact = update_data.get('impact', '')
        discovery_method = update_data.get('discovery_method', '')
        root_cause = update_data.get('root_cause', '')
        solution = update_data.get('solution', '')
        implementation_details = update_data.get('implementation_details', [])
        alternative_solutions = update_data.get('alternative_solutions', [])
        related_files = update_data.get('related_files', [])

        sections = [
            self.html_builder.build_section("Summary", summary) if summary else "",
            self.html_builder.build_section("Impact", impact) if impact else "",
            self.html_builder.build_section("Discovery Method", discovery_method) if discovery_method else "",
            self.html_builder.build_section("Root Cause", root_cause) if root_cause else "",
            self.html_builder.build_section("Solution", solution) if solution else "",
            self.html_builder.build_list("Implementation Details", implementation_details, ordered=True) if implementation_details else "",
            self.html_builder.build_list("Alternative Solutions", alternative_solutions, ordered=False) if alternative_solutions else "",
            self.html_builder.build_list("Related Files", related_files, ordered=False) if related_files else ""
        ]

        # Filter out empty sections
        sections = [s for s in sections if s]

        return self.html_builder.join_sections(*sections) if sections else ""

    def _build_task_description(self, update_data: Dict, current_data: Dict) -> str:
        """
        Build Description content for Task work items from update data

        Args:
            update_data: Update data from JSON file
            current_data: Current work item data (used to extract existing values if not updating)

        Returns:
            HTML formatted Description content
        """
        summary = update_data.get('summary', '')
        reason = update_data.get('reason', '')
        impact = update_data.get('impact', '')
        implementation_steps = update_data.get('implementation_steps', [])
        alternative_approaches = update_data.get('alternative_approaches', [])
        related_files = update_data.get('related_files', [])

        sections = [
            self.html_builder.build_section("Summary", summary) if summary else "",
            self.html_builder.build_section("Reason", reason) if reason else "",
            self.html_builder.build_section("Impact", impact) if impact else "",
            self.html_builder.build_list("Implementation Steps", implementation_steps, ordered=True) if implementation_steps else "",
            self.html_builder.build_list("Alternative Approaches", alternative_approaches, ordered=False) if alternative_approaches else "",
            self.html_builder.build_list("Related Files", related_files, ordered=False) if related_files else ""
        ]

        # Filter out empty sections
        sections = [s for s in sections if s]

        return self.html_builder.join_sections(*sections) if sections else ""

    def _build_user_story_description(self, update_data: Dict, current_data: Dict) -> str:
        """
        Build Description content for User Story work items from update data

        Args:
            update_data: Update data from JSON file
            current_data: Current work item data (used to extract existing values if not updating)

        Returns:
            HTML formatted Description content
        """
        description = update_data.get('description', '')
        return self.html_builder.build_paragraph(description) if description else ""

    def _should_update_field(self, new_value: Any, current_value: Any) -> bool:
        """
        Determine if a field should be updated

        Args:
            new_value: New value from JSON
            current_value: Current value in Azure

        Returns:
            True if field should be updated
        """
        # Handle None/null - always update (means clearing the field)
        if new_value is None:
            return True

        # Handle empty strings and lists - update if explicitly provided
        if new_value == "" or new_value == []:
            return True

        # Handle string comparisons (case-sensitive)
        if isinstance(new_value, str) and isinstance(current_value, str):
            return new_value.strip() != current_value.strip()

        # Handle numeric comparisons
        if isinstance(new_value, (int, float)) and isinstance(current_value, (int, float)):
            return new_value != current_value

        # Handle list comparisons
        if isinstance(new_value, list) and isinstance(current_value, list):
            return new_value != current_value

        # Default: values are different
        return new_value != current_value

    def map_update_fields(self, update_data: Dict, current_work_item: Dict,
                         iteration_path: Optional[str] = None, iteration_service=None) -> Tuple[Dict, Optional[Dict], Optional[Dict], Optional[Dict]]:
        """
        Map JSON update data to Azure DevOps update fields

        Args:
            update_data: Update data from JSON file (must include 'id')
            current_work_item: Current work item data from Azure DevOps (must include relations if checking parent)
            iteration_path: Optional manual iteration path override
            iteration_service: IterationService instance for validation

        Returns:
            Tuple of (fields_dict, parent_changes_dict, child_changes_dict, related_changes_dict)
            - fields_dict: Dictionary of Azure DevOps fields to update (only changed fields)
            - parent_changes_dict: Dictionary describing parent relation changes or None
            - child_changes_dict: Dictionary describing child relation changes or None
            - related_changes_dict: Dictionary describing related relation changes or None

        Raises:
            ValueError: If required fields are missing or invalid
        """
        # Get current fields
        current_fields = current_work_item.get('fields', {})
        work_item_type = current_fields.get(FIELD_WORK_ITEM_TYPE)

        if not work_item_type:
            raise ValueError("Work item type not found in current work item")

        # Build update fields dictionary (only include fields that are being updated)
        update_fields = {}

        # Iteration update (manual override OR JSON field)
        if iteration_path:
            # CLI parameter has highest priority - validate it
            if iteration_service:
                iteration_service.validate_iteration_path(iteration_path)
            # Clean path: remove leading backslash and \Iteration\ part
            update_fields[FIELD_ITERATION_PATH] = iteration_path.lstrip('\\').replace('\\Iteration\\', '\\')
        elif 'iteration' in update_data:
            # JSON field
            new_iteration = update_data['iteration']
            if new_iteration:
                # Validate if iteration_service is available
                if iteration_service:
                    iteration_service.validate_iteration_path(new_iteration)
                current_iteration = current_fields.get(FIELD_ITERATION_PATH)
                # Clean path: remove leading backslash and \Iteration\ part
                new_iteration_clean = new_iteration.lstrip('\\').replace('\\Iteration\\', '\\')
                if self._should_update_field(new_iteration_clean, current_iteration):
                    update_fields[FIELD_ITERATION_PATH] = new_iteration_clean

        # Title
        if 'title' in update_data:
            new_title = update_data['title']
            current_title = current_fields.get(FIELD_TITLE, '')
            if new_title is None:
                # Null means clear - but title is required, so skip
                pass
            elif self._should_update_field(new_title, current_title):
                update_fields[FIELD_TITLE] = new_title

        # Status -> State
        if 'status' in update_data:
            new_status = update_data['status']
            if new_status is None:
                # Cannot clear state, skip
                pass
            else:
                new_state = self._validate_status(new_status, work_item_type)
                if not new_state:
                    valid_states = self._get_valid_states(work_item_type)
                    raise ValueError(
                        f"Invalid status '{new_status}' for {work_item_type}. "
                        f"Valid statuses: {', '.join(valid_states)}"
                    )

                current_state = current_fields.get(FIELD_STATE, '')
                if self._should_update_field(new_state, current_state):
                    update_fields[FIELD_STATE] = new_state

        # Importance -> Priority
        if 'importance' in update_data:
            new_importance = update_data['importance']
            if new_importance is None:
                # Use default priority
                update_fields[FIELD_PRIORITY] = 3
            else:
                new_priority = IMPORTANCE_TO_PRIORITY.get(new_importance, 3)
                current_priority = current_fields.get(FIELD_PRIORITY, 3)
                if self._should_update_field(new_priority, current_priority):
                    update_fields[FIELD_PRIORITY] = new_priority

        # Time Spent Hours -> Original Estimate
        if 'time_spent_hours' in update_data:
            new_time = update_data['time_spent_hours']
            current_time = current_fields.get(FIELD_ORIGINAL_ESTIMATE, 0)
            if new_time is None:
                update_fields[FIELD_ORIGINAL_ESTIMATE] = 0
            elif self._should_update_field(new_time, current_time):
                update_fields[FIELD_ORIGINAL_ESTIMATE] = new_time

        # Assigned To
        if 'assigned_to' in update_data:
            new_assigned = update_data['assigned_to']
            # Extract current assigned_to (may be dict or string)
            current_assigned_field = current_fields.get(FIELD_ASSIGNED_TO, {})
            if isinstance(current_assigned_field, dict):
                current_assigned = current_assigned_field.get('uniqueName', '')
            else:
                current_assigned = str(current_assigned_field) if current_assigned_field else ''

            if new_assigned is None:
                update_fields[FIELD_ASSIGNED_TO] = ""
            elif self._should_update_field(new_assigned, current_assigned):
                update_fields[FIELD_ASSIGNED_TO] = new_assigned

        # Tags - DISABLED: Azure DevOps project may not have tags enabled
        # Skip tags field to avoid 403 errors
        # if 'tags' in update_data:
        #     new_tags = update_data['tags']
        #     current_tags = current_fields.get(FIELD_TAGS, '')
        #
        #     if new_tags is None:
        #         update_fields[FIELD_TAGS] = ""
        #     elif isinstance(new_tags, list):
        #         new_tags_str = '; '.join(new_tags)
        #         if self._should_update_field(new_tags_str, current_tags):
        #             update_fields[FIELD_TAGS] = new_tags_str
        #     elif isinstance(new_tags, str):
        #         if self._should_update_field(new_tags, current_tags):
        #             update_fields[FIELD_TAGS] = new_tags

        # Business Value (User Story only)
        if work_item_type == WORK_ITEM_TYPE_USER_STORY and 'business_value' in update_data:
            new_bv = update_data['business_value']
            current_bv = current_fields.get(FIELD_BUSINESS_VALUE, 0)

            if new_bv is None:
                update_fields[FIELD_BUSINESS_VALUE] = 0
            else:
                try:
                    new_bv_int = int(new_bv)
                    if self._should_update_field(new_bv_int, current_bv):
                        update_fields[FIELD_BUSINESS_VALUE] = new_bv_int
                except ValueError:
                    raise ValueError(f"business_value must be numeric, got: {new_bv}")

        # Description / System Info (complex fields)
        # Check if any description-related fields are being updated
        description_fields = []
        if work_item_type == WORK_ITEM_TYPE_BUG:
            description_fields = ['summary', 'impact', 'discovery_method', 'root_cause',
                                'solution', 'implementation_details', 'alternative_solutions', 'related_files']
        elif work_item_type == WORK_ITEM_TYPE_TASK:
            description_fields = ['summary', 'reason', 'impact', 'implementation_steps',
                                'alternative_approaches', 'related_files']
        elif work_item_type == WORK_ITEM_TYPE_USER_STORY:
            description_fields = ['description']

        # Check if any description field is being updated
        has_description_update = any(field in update_data for field in description_fields)

        if has_description_update:
            # Build new description content
            if work_item_type == WORK_ITEM_TYPE_BUG:
                content_field = FIELD_BUG_SYSTEM_INFO
                new_content = self._build_bug_system_info(update_data, current_work_item)
            elif work_item_type == WORK_ITEM_TYPE_TASK:
                content_field = FIELD_DESCRIPTION
                new_content = self._build_task_description(update_data, current_work_item)
            elif work_item_type == WORK_ITEM_TYPE_USER_STORY:
                content_field = FIELD_DESCRIPTION
                new_content = self._build_user_story_description(update_data, current_work_item)
            else:
                content_field = None
                new_content = ""

            if content_field and new_content:
                current_content = current_fields.get(content_field, '')
                if self._should_update_field(new_content, current_content):
                    update_fields[content_field] = new_content

        # Parent ID (relation update)
        parent_changes = None
        if 'parent_id' in update_data:
            new_parent_id = update_data['parent_id']

            # Get current parent from relations
            current_relations = current_work_item.get('relations', [])
            current_parent_relation = None
            current_parent_index = None
            current_parent_id = None

            # Find parent relation (System.LinkTypes.Hierarchy-Reverse)
            for idx, relation in enumerate(current_relations):
                if relation.get('rel') == 'System.LinkTypes.Hierarchy-Reverse':
                    current_parent_relation = relation
                    current_parent_index = idx
                    # Extract parent ID from URL
                    url = relation.get('url', '')
                    if '/workitems/' in url or '/workItems/' in url:
                        try:
                            current_parent_id = int(url.split('/')[-1])
                        except (ValueError, IndexError):
                            pass
                    break

            # Determine action based on current and new parent
            if new_parent_id is None:
                # Remove parent if exists
                if current_parent_relation:
                    parent_changes = {
                        "action": "remove",
                        "old_parent_index": current_parent_index,
                        "old_parent_id": current_parent_id
                    }
            elif current_parent_id is None:
                # Add new parent (no current parent)
                parent_changes = {
                    "action": "add",
                    "new_parent_id": new_parent_id
                }
            elif current_parent_id == new_parent_id:
                # Same parent, no change needed
                parent_changes = None
            else:
                # Replace parent (remove old, add new)
                parent_changes = {
                    "action": "replace",
                    "old_parent_index": current_parent_index,
                    "old_parent_id": current_parent_id,
                    "new_parent_id": new_parent_id
                }

        # Child IDs (relation update)
        child_changes = None
        if 'child_ids' in update_data:
            new_child_ids = update_data['child_ids']
            if new_child_ids is None:
                new_child_ids = []

            # Get current children from relations
            current_relations = current_work_item.get('relations', [])
            current_children = []

            # Find child relations (System.LinkTypes.Hierarchy-Forward)
            for idx, relation in enumerate(current_relations):
                if relation.get('rel') == 'System.LinkTypes.Hierarchy-Forward':
                    url = relation.get('url', '')
                    if '/workitems/' in url or '/workItems/' in url:
                        try:
                            child_id = int(url.split('/')[-1])
                            current_children.append({"index": idx, "id": child_id})
                        except (ValueError, IndexError):
                            pass

            # Determine which children to add/remove
            current_child_ids = [c["id"] for c in current_children]
            to_add = [cid for cid in new_child_ids if cid not in current_child_ids]
            to_remove = [c for c in current_children if c["id"] not in new_child_ids]

            if to_add or to_remove:
                child_changes = {}
                if to_add:
                    child_changes["add"] = to_add
                if to_remove:
                    child_changes["remove"] = to_remove

        # Related IDs (relation update)
        related_changes = None
        if 'related_ids' in update_data:
            new_related_ids = update_data['related_ids']
            if new_related_ids is None:
                new_related_ids = []

            # Get current related from relations
            current_relations = current_work_item.get('relations', [])
            current_related = []

            # Find related relations (System.LinkTypes.Related)
            for idx, relation in enumerate(current_relations):
                if relation.get('rel') == 'System.LinkTypes.Related':
                    url = relation.get('url', '')
                    if '/workitems/' in url or '/workItems/' in url:
                        try:
                            related_id = int(url.split('/')[-1])
                            current_related.append({"index": idx, "id": related_id})
                        except (ValueError, IndexError):
                            pass

            # Determine which related to add/remove
            current_related_ids = [r["id"] for r in current_related]
            to_add = [rid for rid in new_related_ids if rid not in current_related_ids]
            to_remove = [r for r in current_related if r["id"] not in new_related_ids]

            if to_add or to_remove:
                related_changes = {}
                if to_add:
                    related_changes["add"] = to_add
                if to_remove:
                    related_changes["remove"] = to_remove

        return update_fields, parent_changes, child_changes, related_changes
