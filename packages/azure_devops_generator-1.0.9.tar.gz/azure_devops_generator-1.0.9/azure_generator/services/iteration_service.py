"""
Iteration Service
Manages Azure DevOps iterations with caching and automatic selection
"""

import json
from datetime import datetime, timedelta
from pathlib import Path
from typing import List, Optional, Dict, Tuple
from dataclasses import dataclass


@dataclass
class Iteration:
    """Represents an Azure DevOps iteration/sprint"""
    path: str
    start_date: datetime
    end_date: datetime
    name: str


class IterationService:
    """
    Service for managing Azure DevOps iterations

    Responsibilities:
    - Fetch iterations from Azure API
    - Cache iterations with TTL
    - Validate iteration dates
    - Select appropriate iteration for a given date
    """

    def __init__(self, api_client, config: Dict):
        """
        Initialize iteration service

        Args:
            api_client: AzureDevOpsAPIClient instance
            config: Configuration dictionary
        """
        self.api_client = api_client
        self.config = config
        self.cache_ttl_hours = config.get('iteration_cache_ttl_hours', 72)

        # Cache file path in project root
        project_root = Path(__file__).parent.parent
        self.cache_file = project_root / '.iteration_cache.json'

        self._cached_iterations: Optional[List[Iteration]] = None

    def get_valid_iterations(self) -> List[Iteration]:
        """
        Get all valid iterations (with proper start/end dates)

        Uses cache if available and not expired, otherwise fetches from Azure

        Returns:
            List of valid Iteration objects sorted by start_date

        Raises:
            ValueError: If no valid iterations found or API fails
        """
        # Check cache first
        if self._cached_iterations is None:
            cached_data = self._load_cache()
            if cached_data:
                self._cached_iterations = cached_data
            else:
                # Fetch from Azure and cache
                iterations = self.fetch_iterations_from_azure()
                self._cached_iterations = iterations
                self._save_cache(iterations)

        return sorted(self._cached_iterations, key=lambda x: x.start_date)

    def fetch_iterations_from_azure(self) -> List[Iteration]:
        """
        Fetch iterations from Azure DevOps API

        Returns:
            List of valid Iteration objects

        Raises:
            ValueError: If API call fails or no valid iterations found
        """
        # Call Azure API
        response = self.api_client.get_iterations(depth=100)
        if not response:
            raise ValueError("Failed to fetch iterations from Azure DevOps API")

        # Flatten nested iteration tree
        flattened = self._flatten_iterations(response)

        # Parse and validate iterations
        valid_iterations = []
        invalid_count = 0

        for iteration_node in flattened:
            parsed = self._parse_iteration_dates(iteration_node)
            if parsed:
                start_date, end_date = parsed
                iteration = Iteration(
                    path=iteration_node['path'],
                    start_date=start_date,
                    end_date=end_date,
                    name=iteration_node['name']
                )
                valid_iterations.append(iteration)
            else:
                invalid_count += 1

        if not valid_iterations:
            raise ValueError("No valid iterations found in Azure DevOps (all iterations have missing/invalid dates)")

        # Check for overlaps (only fail if today's date is affected)
        self._check_for_overlaps(valid_iterations, target_date=datetime.now())

        return valid_iterations

    def _flatten_iterations(self, node: Dict, result: Optional[List[Dict]] = None) -> List[Dict]:
        r"""
        Recursively flatten nested iteration tree

        Only includes leaf nodes (iterations without children) to avoid parent/child overlaps.
        Parent iterations like '\2025' or '\2025\October' are ignored.
        Only actual sprint iterations like '\2025\October\14.10.2024 - 25.10.2024' are included.

        Args:
            node: Iteration node from Azure API
            result: Accumulator list

        Returns:
            Flat list of leaf iteration nodes
        """
        if result is None:
            result = []

        # Check if this is a leaf node (no children)
        has_children = node.get('hasChildren', False)
        children = node.get('children', [])
        is_leaf = not has_children and not children

        # Only add leaf nodes (actual sprint iterations)
        if 'path' in node and node.get('path') and is_leaf:
            result.append(node)

        # Recursively process children
        if children:
            for child in children:
                self._flatten_iterations(child, result)

        return result

    def _parse_iteration_dates(self, iteration_node: Dict) -> Optional[Tuple[datetime, datetime]]:
        """
        Parse start and end dates from iteration node

        Args:
            iteration_node: Iteration node from Azure API

        Returns:
            Tuple of (start_date, end_date) or None if invalid
        """
        attributes = iteration_node.get('attributes', {})

        # Both startDate and finishDate are required
        start_str = attributes.get('startDate')
        end_str = attributes.get('finishDate')

        if not start_str or not end_str:
            return None

        try:
            # Parse ISO 8601 format: "2025-10-13T00:00:00Z"
            start_date = datetime.fromisoformat(start_str.replace('Z', '+00:00'))
            end_date = datetime.fromisoformat(end_str.replace('Z', '+00:00'))

            # Remove timezone info for comparison (work with naive datetimes)
            start_date = start_date.replace(tzinfo=None)
            end_date = end_date.replace(tzinfo=None)

            # Validate: start must be before end
            if start_date >= end_date:
                return None

            return start_date, end_date
        except (ValueError, AttributeError):
            return None

    def _check_for_overlaps(self, iterations: List[Iteration], target_date: Optional[datetime] = None) -> None:
        """
        Check for overlapping iterations

        Only raises error if target_date falls within overlapping iterations (ambiguous case).
        Otherwise, logs warning and continues (allows historical data issues).

        Args:
            iterations: List of Iteration objects
            target_date: Optional date to check for relevance (defaults to None)

        Raises:
            ValueError: If target_date falls within overlapping iterations
        """
        sorted_iterations = sorted(iterations, key=lambda x: x.start_date)

        for i in range(len(sorted_iterations)):
            for j in range(i + 1, len(sorted_iterations)):
                iter1 = sorted_iterations[i]
                iter2 = sorted_iterations[j]

                # Check overlap: (start1 <= end2) AND (start2 <= end1)
                if iter1.start_date <= iter2.end_date and iter2.start_date <= iter1.end_date:
                    # Overlap detected - check if it affects target_date
                    if target_date:
                        # Check if target_date falls within BOTH overlapping iterations
                        in_iter1 = iter1.start_date <= target_date <= iter1.end_date
                        in_iter2 = iter2.start_date <= target_date <= iter2.end_date

                        if in_iter1 and in_iter2:
                            # Target date is within BOTH overlaps - ambiguous!
                            raise ValueError(
                                f"Ambiguous iteration: {target_date.strftime('%d.%m.%Y')} falls within overlapping iterations:\n"
                                f"  - {iter1.path} ({iter1.start_date.strftime('%d.%m.%Y')} - {iter1.end_date.strftime('%d.%m.%Y')})\n"
                                f"  - {iter2.path} ({iter2.start_date.strftime('%d.%m.%Y')} - {iter2.end_date.strftime('%d.%m.%Y')})"
                            )
                    # Overlap exists but doesn't affect target_date - silently ignore

    def find_iteration_for_date(self, target_date: datetime) -> Iteration:
        """
        Find the appropriate iteration for a given date

        Logic:
        1. If date is within an iteration → return that iteration
        2. If date is before all iterations → error
        3. If date is after all iterations or in a gap → return last finished iteration

        Args:
            target_date: Date to find iteration for

        Returns:
            Iteration object

        Raises:
            ValueError: If date is before all iterations or no valid iteration found
        """
        valid_iterations = self.get_valid_iterations()

        if not valid_iterations:
            raise ValueError("No valid iterations available")

        # Check if date is within any iteration
        for iteration in valid_iterations:
            if iteration.start_date <= target_date <= iteration.end_date:
                return iteration

        # Date is not within any iteration
        # Check if before all iterations
        if target_date < valid_iterations[0].start_date:
            raise ValueError(
                f"No iteration found: {target_date.strftime('%d.%m.%Y')} is before all iterations.\n"
                f"First iteration starts on {valid_iterations[0].start_date.strftime('%d.%m.%Y')}"
            )

        # Date is after all iterations or in a gap between iterations
        # Return the last iteration that has ended before target_date
        past_iterations = [it for it in valid_iterations if it.end_date < target_date]
        if past_iterations:
            return past_iterations[-1]

        raise ValueError(f"No valid iteration found for date: {target_date.strftime('%d.%m.%Y')}")

    def get_current_iteration(self) -> Iteration:
        """
        Get iteration for today's date

        Returns:
            Iteration object for today

        Raises:
            ValueError: If no appropriate iteration found
        """
        try:
            return self.find_iteration_for_date(datetime.now())
        except ValueError as e:
            # Add helpful message about manual override
            raise ValueError(
                f"{str(e)}\n\n"
                "Tip: You can manually specify iteration using --iteration parameter\n"
                "Example: --iteration \"ML AR-GE\\2025\\October\\13.10.2025 - 24.10.2025\""
            )

    def validate_iteration_path(self, iteration_path: str) -> bool:
        """
        Validate if a manual iteration path exists in Azure

        Args:
            iteration_path: Iteration path to validate

        Returns:
            True if valid

        Raises:
            ValueError: If iteration path not found
        """
        valid_iterations = self.get_valid_iterations()

        # Check if path matches any iteration
        for iteration in valid_iterations:
            if iteration.path == iteration_path:
                return True

        # Not found - show available iterations
        print(f"\nError: Iteration not found: {iteration_path}")
        print("\nAvailable iterations:")
        for it in sorted(valid_iterations, key=lambda x: x.start_date):
            print(f"  - {it.path}")
            print(f"    ({it.start_date.strftime('%d.%m.%Y')} - {it.end_date.strftime('%d.%m.%Y')})")

        raise ValueError(f"Invalid iteration path: {iteration_path}")

    def _is_cache_valid(self) -> bool:
        """
        Check if cache file exists and is not expired

        Returns:
            True if cache is valid and not expired
        """
        if not self.cache_file.exists():
            return False

        try:
            with open(self.cache_file, 'r', encoding='utf-8') as f:
                cache_data = json.load(f)

            timestamp_str = cache_data.get('timestamp')
            if not timestamp_str:
                return False

            cache_time = datetime.fromisoformat(timestamp_str)
            now = datetime.now()

            # Check if cache has expired
            time_diff = now - cache_time
            if time_diff > timedelta(hours=self.cache_ttl_hours):
                return False

            return True
        except (json.JSONDecodeError, ValueError, KeyError):
            return False

    def _load_cache(self) -> Optional[List[Iteration]]:
        """
        Load iterations from cache if valid

        Returns:
            List of Iteration objects or None if cache invalid/expired
        """
        if not self._is_cache_valid():
            return None

        try:
            with open(self.cache_file, 'r', encoding='utf-8') as f:
                cache_data = json.load(f)

            iterations_data = cache_data.get('iterations', [])
            iterations = []

            for item in iterations_data:
                iteration = Iteration(
                    path=item['path'],
                    start_date=datetime.fromisoformat(item['start_date']),
                    end_date=datetime.fromisoformat(item['end_date']),
                    name=item['name']
                )
                iterations.append(iteration)

            return iterations
        except (json.JSONDecodeError, ValueError, KeyError):
            # Cache corrupted - delete and return None to trigger fresh fetch
            if self.cache_file.exists():
                self.cache_file.unlink()
            return None

    def _save_cache(self, iterations: List[Iteration]) -> None:
        """
        Save iterations to cache file

        Args:
            iterations: List of Iteration objects to cache
        """
        cache_data = {
            'timestamp': datetime.now().isoformat(),
            'iterations': [
                {
                    'path': it.path,
                    'start_date': it.start_date.isoformat(),
                    'end_date': it.end_date.isoformat(),
                    'name': it.name
                }
                for it in iterations
            ]
        }

        try:
            with open(self.cache_file, 'w', encoding='utf-8') as f:
                json.dump(cache_data, f, indent=2, ensure_ascii=False)
        except Exception:
            # Failed to save cache - silently continue (not critical)
            pass
