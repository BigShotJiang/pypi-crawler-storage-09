"""
Post-install/upgrade utilities for Claude Code integration
"""

import os
import shutil
import platform
import json
from pathlib import Path


def load_config_if_exists() -> dict:
    """
    Config dosyası varsa oku, yoksa None döndür.

    Returns:
        dict: Config dictionary or None
    """
    try:
        config_path = get_config_path()
        if config_path.exists():
            with open(config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
    except Exception:
        pass
    return None


def format_path_for_platform(path: str, is_windows: bool) -> str:
    """
    Path'i platform formatına çevir.

    Args:
        path: Path to format
        is_windows: True if Windows, False if Linux/Mac

    Returns:
        str: Formatted path
    """
    from pathlib import Path
    path_obj = Path(path)

    if is_windows:
        # Windows formatı - backslash
        return str(path_obj).replace('/', '\\')
    else:
        # Linux/Mac formatı - forward slash, home ile başlıyorsa ~ kullan
        home = Path.home()
        try:
            relative_to_home = path_obj.relative_to(home)
            return f"~/{relative_to_home}".replace('\\', '/')
        except ValueError:
            # Home dizininde değilse tam path
            return str(path_obj).replace('\\', '/')


def replace_placeholders(content: str, config: dict, is_windows: bool) -> str:
    """
    MD template'indeki placeholder'ları değiştir.

    Args:
        content: Template content
        config: Configuration dictionary
        is_windows: True if Windows, False if Linux/Mac

    Returns:
        str: Content with replaced placeholders
    """
    tasks_folder = config.get('tasks_folder')

    if not tasks_folder:
        # Default fallback
        from pathlib import Path
        home = Path.home()
        tasks_folder = str(home / "Desktop" / "Claude" / "Tasks")

    # Format path for platform
    tasks_folder_formatted = format_path_for_platform(tasks_folder, is_windows)

    # Replace placeholder
    replacements = {
        '{{TASKS_FOLDER}}': tasks_folder_formatted,
    }

    for placeholder, value in replacements.items():
        content = content.replace(placeholder, value)

    return content


def get_version_from_md(content: str) -> str:
    """
    Extract version from MD file frontmatter.

    Args:
        content: MD file content

    Returns:
        str: Version string or "0.0.0" if not found
    """
    import re
    match = re.search(r'^version:\s*([0-9.]+)', content, re.MULTILINE)
    return match.group(1) if match else "0.0.0"


def setup_claude_integration(silent: bool = False):
    """
    Kurulum veya güncelleme sonrası Claude Code entegrasyonu.
    İşletim sistemine göre uygun dosyayı ~/.claude/commands/ klasörüne kopyalar.
    Config'ten tasks_folder okur ve placeholder'ları değiştirir.
    Version kontrolü yapar - sadece gerektiğinde günceller.

    Args:
        silent: True ise sadece güncelleme varsa mesaj göster

    Returns:
        bool: True if successful, False otherwise
    """
    try:
        # İşletim sistemi tespiti
        is_windows = platform.system() == "Windows"

        # Kaynak dosya seç
        pkg_dir = Path(__file__).parent
        source_filename = "generate_tasks_windows.md" if is_windows else "generate_tasks_linux.md"
        source_file = pkg_dir / source_filename

        if not source_file.exists():
            if not silent:
                print(f"WARNING: Kaynak dosya bulunamadi: {source_file}")
                print(f"WARNING: Claude Code entegrasyonu atlandi.")
            return False

        # Hedef dizin ve dosya
        home = Path.home()
        target_dir = home / ".claude" / "commands"
        target_file = target_dir / "generate_tasks.md"

        # Kaynak dosyanın versiyonunu oku
        with open(source_file, 'r', encoding='utf-8') as f:
            source_content = f.read()
        source_version = get_version_from_md(source_content)

        # Mevcut dosya varsa versiyonunu kontrol et
        needs_update = True
        if target_file.exists():
            try:
                with open(target_file, 'r', encoding='utf-8') as f:
                    target_content = f.read()
                target_version = get_version_from_md(target_content)

                # Version aynıysa güncelleme yapma
                if source_version == target_version:
                    needs_update = False
            except Exception:
                # Okuma hatası varsa güncelle
                needs_update = True

        # Güncelleme gerekli değilse çık
        if not needs_update:
            return True

        # Config oku
        config = load_config_if_exists()
        if not config:
            # Default config
            config = {'tasks_folder': str(Path.home() / "Desktop" / "Claude" / "Tasks")}

        # Placeholder'ları değiştir
        content = replace_placeholders(source_content, config, is_windows)

        # Klasörü oluştur (yoksa)
        target_dir.mkdir(parents=True, exist_ok=True)

        # Mevcut dosyayı sil
        if target_file.exists():
            target_file.unlink()

        # Yeni dosyayı kaydet
        with open(target_file, 'w', encoding='utf-8') as f:
            f.write(content)

        # Bilgilendirme mesajı (silent mode değilse veya güncelleme varsa)
        if not silent or needs_update:
            print(f"\n{'=' * 60}")
            print(f"SUCCESS: Claude Code entegrasyonu tamamlandi!")
            print(f"SUCCESS: Slash komut: /generate_tasks")
            print(f"Konum: {target_file}")
            print(f"Tasks Folder: {config.get('tasks_folder')}")
            print(f"Version: {source_version}")
            print(f"{'=' * 60}\n")

        return True

    except Exception as e:
        if not silent:
            print(f"\nWARNING: Claude Code entegrasyonu basarisiz: {e}")
            print(f"WARNING: Manuel olarak kopyalayabilirsiniz:")
            print(f"     Kaynak: {pkg_dir / source_filename}")
            print(f"     Hedef: {home / '.claude' / 'commands' / 'generate_tasks.md'}\n")
        return False


def get_config_dir() -> Path:
    """
    Get the configuration directory for azure-generator.
    Creates it if it doesn't exist.

    Returns:
        Path: Configuration directory path
    """
    home = Path.home()
    config_dir = home / ".azure-generator"
    config_dir.mkdir(parents=True, exist_ok=True)
    return config_dir


def get_config_path() -> Path:
    """
    Get the configuration file path.

    Returns:
        Path: Configuration file path
    """
    return get_config_dir() / "config.json"


if __name__ == "__main__":
    # Test the integration
    print("Testing Claude Code integration...")
    success = setup_claude_integration()
    if success:
        print("SUCCESS: Test successful!")
    else:
        print("FAILED: Test failed!")
