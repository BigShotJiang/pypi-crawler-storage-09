"""
HTML Builder Utilities
Helper functions for building HTML content for Azure DevOps work items
"""

from typing import List


class HTMLBuilder:
    """Builds HTML formatted content for Azure DevOps fields"""

    @staticmethod
    def build_section(title: str, content: str) -> str:
        """
        Build an HTML section with title and paragraph content

        Args:
            title: Section title
            content: Section content (text or HTML)

        Returns:
            HTML string for the section, or empty string if no content
        """
        if not content:
            return ""
        return f"<h3>{title}</h3>\n<p>{content}</p>"

    @staticmethod
    def build_list(title: str, items: List[str], ordered: bool = False) -> str:
        """
        Build an HTML list section with title

        Args:
            title: Section title
            items: List of items to display
            ordered: If True, use <ol>, otherwise use <ul>

        Returns:
            HTML string for the list section, or empty string if no items
        """
        if not items:
            return ""

        list_tag = "ol" if ordered else "ul"
        items_html = "\n".join([f"<li>{item}</li>" for item in items])
        return f"<h3>{title}</h3>\n<{list_tag}>\n{items_html}\n</{list_tag}>"

    @staticmethod
    def build_paragraph(content: str) -> str:
        """
        Build a simple paragraph

        Args:
            content: Text content

        Returns:
            HTML paragraph string, or empty string if no content
        """
        if not content:
            return ""
        return f"<p>{content}</p>"

    @staticmethod
    def join_sections(*sections: str) -> str:
        """
        Join multiple HTML sections, filtering out empty ones

        Args:
            *sections: Variable number of HTML section strings

        Returns:
            Joined HTML string
        """
        return "\n".join([section for section in sections if section])

    @staticmethod
    def remove_html_tags(html_content: str) -> str:
        """
        Remove HTML tags from content (simple regex-based approach)

        Args:
            html_content: HTML string

        Returns:
            Plain text content
        """
        import re
        return re.sub('<[^<]+?>', '', html_content)
