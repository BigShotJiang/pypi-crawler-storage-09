"""
Path Utilities
Cross-platform path handling for Windows and Linux
"""

import os
from pathlib import Path
from typing import Union


class PathUtils:
    """Utility class for cross-platform path handling"""

    @staticmethod
    def normalize_path(path_str: Union[str, Path]) -> Path:
        """
        Normalize path for current platform

        Handles:
        - Windows paths (C:\\Users\\..., C:/Users/...)
        - Linux paths (/home/user/...)
        - Relative paths (./folder, ../folder)
        - Mixed separators (folder\\subfolder/file.txt)

        Args:
            path_str: Path string or Path object

        Returns:
            Normalized Path object for current platform

        Examples:
            normalize_path("C:\\Users\\Name\\file.txt")  # Windows
            normalize_path("C:/Users/Name/file.txt")     # Also works
            normalize_path("/home/user/file.txt")         # Linux
            normalize_path("./Tasks/file.json")          # Relative
        """
        if isinstance(path_str, Path):
            return path_str

        # Convert string to Path (automatically handles platform differences)
        return Path(path_str).expanduser().resolve()

    @staticmethod
    def ensure_directory(path: Union[str, Path], create_if_missing: bool = True) -> Path:
        """
        Ensure directory exists

        Args:
            path: Directory path
            create_if_missing: If True, creates directory if it doesn't exist

        Returns:
            Path object

        Raises:
            FileNotFoundError: If directory doesn't exist and create_if_missing is False
        """
        dir_path = PathUtils.normalize_path(path)

        if not dir_path.exists():
            if create_if_missing:
                dir_path.mkdir(parents=True, exist_ok=True)
            else:
                raise FileNotFoundError(f"Directory not found: {dir_path}")

        if not dir_path.is_dir():
            raise NotADirectoryError(f"Path is not a directory: {dir_path}")

        return dir_path

    @staticmethod
    def get_file_path(directory: Union[str, Path], filename: str) -> Path:
        """
        Get full file path by joining directory and filename

        Args:
            directory: Directory path
            filename: File name

        Returns:
            Full file path
        """
        dir_path = PathUtils.normalize_path(directory)
        return dir_path / filename

    @staticmethod
    def is_absolute(path: Union[str, Path]) -> bool:
        """Check if path is absolute"""
        return Path(path).is_absolute()

    @staticmethod
    def get_absolute_path(path: Union[str, Path], base_dir: Union[str, Path] = None) -> Path:
        """
        Get absolute path

        Args:
            path: Path to convert
            base_dir: Base directory for relative paths (default: current working directory)

        Returns:
            Absolute Path object
        """
        path_obj = Path(path)

        if path_obj.is_absolute():
            return path_obj.resolve()

        if base_dir:
            base = Path(base_dir).resolve()
            return (base / path_obj).resolve()

        return path_obj.resolve()

    @staticmethod
    def format_path_for_display(path: Union[str, Path]) -> str:
        """
        Format path for display (uses forward slashes for consistency)

        Args:
            path: Path to format

        Returns:
            Formatted path string
        """
        return str(Path(path)).replace('\\', '/')

    @staticmethod
    def validate_file_path(path: Union[str, Path]) -> Path:
        """
        Validate that file exists and is readable

        Args:
            path: File path

        Returns:
            Path object

        Raises:
            FileNotFoundError: If file doesn't exist
            IsADirectoryError: If path is a directory
        """
        file_path = PathUtils.normalize_path(path)

        if not file_path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")

        if file_path.is_dir():
            raise IsADirectoryError(f"Path is a directory, not a file: {file_path}")

        return file_path
