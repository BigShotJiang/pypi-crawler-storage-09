"""
Setup script for azure-devops-generator
Handles post-installation tasks including Claude Code integration
"""

from setuptools import setup, find_packages
from setuptools.command.install import install
from setuptools.command.develop import develop


class PostInstallCommand(install):
    """Post-installation for installation mode."""
    def run(self):
        install.run(self)
        # Run post-install script
        try:
            from azure_generator.setup_utils import setup_claude_integration
            setup_claude_integration()
        except Exception as e:
            print(f"WARNING: Post-install hook failed: {e}")


class PostDevelopCommand(develop):
    """Post-installation for development mode."""
    def run(self):
        develop.run(self)
        # Run post-install script
        try:
            from azure_generator.setup_utils import setup_claude_integration
            setup_claude_integration()
        except Exception as e:
            print(f"WARNING: Post-develop hook failed: {e}")


# Use setup() with minimal config since pyproject.toml has most settings
setup(
    cmdclass={
        'install': PostInstallCommand,
        'develop': PostDevelopCommand,
    },
)
