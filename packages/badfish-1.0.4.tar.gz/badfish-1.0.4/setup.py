import setuptools

setuptools.setup(
    version="1.0.4"
)
