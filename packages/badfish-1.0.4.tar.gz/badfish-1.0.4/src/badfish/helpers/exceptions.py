class BadfishException(Exception):
    pass
