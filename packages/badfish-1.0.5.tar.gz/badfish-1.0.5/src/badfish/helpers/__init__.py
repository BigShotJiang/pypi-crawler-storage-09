from datetime import datetime


def get_now():
    return datetime.now()
