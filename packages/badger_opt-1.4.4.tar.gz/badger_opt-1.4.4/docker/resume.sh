#!/bin/bash

docker start -ai badger-handson
