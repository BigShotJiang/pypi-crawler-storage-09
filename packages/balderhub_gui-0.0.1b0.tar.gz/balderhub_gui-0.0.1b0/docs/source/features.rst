Features
********


This section describes all features that are shipped with this package.


Scenario Features
=================

.. autoclass:: balderhub.gui.lib.scenario_features.PageFeature
    :members:

Setup Features
==============

.. note::
    This package does not provide any setup features.