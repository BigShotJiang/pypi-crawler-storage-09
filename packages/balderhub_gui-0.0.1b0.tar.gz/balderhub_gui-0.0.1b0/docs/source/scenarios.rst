Scenarios
*********

Scenarios describe **what you need**. They define the tests and the necessary devices for them. Here you can find all
scenarios that are implemented in this BalderHub package.

.. todo

.. important::
    Please note, that this section is not completed yet.
