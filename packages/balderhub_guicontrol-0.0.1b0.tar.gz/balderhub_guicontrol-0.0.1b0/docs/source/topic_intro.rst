Introduction into Controlling GUIs
**********************************

.. todo describe how this package implements the controlling of gui applications

.. note::
    This section is comming soon.