Features
********


This section describes all features that are shipped with this package.


Scenario Features
=================

.. autoclass:: balderhub.html.lib.scenario_features.HtmlPage
    :members:
