from .html_page import HtmlPage

__all__ = [
    'HtmlPage'
]
