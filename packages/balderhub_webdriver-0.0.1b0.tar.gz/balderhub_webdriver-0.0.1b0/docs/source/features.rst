Features
********

This section describes all features that are shipped with this package.

Scenario Features
=================

.. autoclass:: balderhub.webdriver.lib.scenario_features.WebdriverControlFeature
    :members:


Setup Features
==============

.. note::
    This BalderHub package does not provide any setup features. Please use an implementation package like
    `the balderhub-selenium package <https://hub.balder.dev/projects/selenium>`_.
