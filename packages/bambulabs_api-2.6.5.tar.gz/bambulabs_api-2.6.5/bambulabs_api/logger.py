import logging

logger = logging.getLogger("bambulabs_api")
