Filament
========
.. automodule:: bambulabs_api.Filament
  :members:
  :imported-members: