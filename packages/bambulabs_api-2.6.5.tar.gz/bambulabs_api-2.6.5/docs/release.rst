*************
Release Notes
*************

Release notes for each release here:

.. toctree::
  :maxdepth: 1

  2.6.5 <release/2.6.5-notes.rst>
  2.6.4 <release/2.6.4-notes.rst>
  2.6.3 <release/2.6.3-notes.rst>
  2.6.2 <release/2.6.2-notes.rst>
  2.6.1 <release/2.6.1-notes.rst>
  2.6.0 <release/2.6.0-notes.rst>
  2.5.12 <release/2.5.12-notes.rst>
  2.5.10 <release/2.5.10-notes.rst>
  2.5.9 <release/2.5.9-notes.rst>
  2.5.8 <release/2.5.8-notes.rst>
  2.5.7 <release/2.5.7-notes.rst>
