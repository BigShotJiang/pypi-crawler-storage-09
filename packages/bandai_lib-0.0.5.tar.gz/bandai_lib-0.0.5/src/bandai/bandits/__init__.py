from .ucb import DisjointLinUCB

__all__ = [
    "DisjointLinUCB",
]
