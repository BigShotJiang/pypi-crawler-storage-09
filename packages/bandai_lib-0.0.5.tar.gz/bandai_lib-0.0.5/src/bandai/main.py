def main():
    print("Hello from bandai!")
