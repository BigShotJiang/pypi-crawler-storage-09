""" Current git-based version """

__version__ = "0.9.5-release"
