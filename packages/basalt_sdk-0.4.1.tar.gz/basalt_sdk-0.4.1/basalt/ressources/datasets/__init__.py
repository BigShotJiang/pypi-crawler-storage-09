"""
Datasets resource module
"""
