"""Enable running the package with python -m basic_agent_chat_loop."""

from basic_agent_chat_loop.cli import main

if __name__ == "__main__":
    main()
