from .infer_fa import Wave2VecFAModel
