"""batplot package."""

# Skip version check to avoid OneDrive timeout issues
__version__ = "1.0.18"

__all__ = ["__version__"]
