<p align="center">
  <a href=""><img alt="logo" src="https://avatars.githubusercontent.com/u/64279108?s=200&v=4" width="30%"></a>
</p>

# BBOB Benchmark set for Jax

| [**GitHub**](https://github.com/mpvanderschelling/bbob-jax)
|

BBOB Benchmark function implemented in JAX

**First publication:** October 17, 2025

***

## Summary

<!-- Write here a longer description of the package, what it does, and why it is useful. -->

## Statement of need

<!-- Write here the statement of need for this package -->

## Authorship

**Authors**:
- Martin van der Schelling ([m.p.vanderschelling@tudelft.nl](mailto:m.p.vanderschelling@tudelft.nl))

**Authors afilliation:**
- Delft University of Technology (Bessa Research Group)

**Maintainer:**
- Martin van der Schelling ([m.p.vanderschelling@tudelft.nl](mailto:m.p.vanderschelling@tudelft.nl))

**Maintainer afilliation:**
- Delft University of Technology (Bessa Research Group)


## Getting started

<!-- Write here how users should get started with this package -->

## Community Support

If you find any **issues, bugs or problems** with this package, please use the [GitHub issue tracker](https://github.com/mpvanderschelling/bbob_jax/issues) to report them.

## License

Copyright (c) 2025, Martin van der Schelling

All rights reserved.

This project is licensed under the BSD 3-Clause License. See [LICENSE](https://github.com/mpvanderschelling/bbob_jax/blob/main/LICENSE) for the full license text.

