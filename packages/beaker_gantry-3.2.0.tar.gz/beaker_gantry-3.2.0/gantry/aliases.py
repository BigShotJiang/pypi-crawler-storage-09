from os import PathLike
from typing import Union

PathOrStr = Union[PathLike, str]
