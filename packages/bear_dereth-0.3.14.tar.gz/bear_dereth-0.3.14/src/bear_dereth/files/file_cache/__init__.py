"""A set of file cache management utilities."""
