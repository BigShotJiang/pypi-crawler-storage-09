"""Core logging models and utilities."""
