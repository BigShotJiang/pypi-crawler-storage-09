"""Testing for bearbase module."""
