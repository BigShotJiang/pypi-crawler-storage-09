"""A set of linked list data structures."""
