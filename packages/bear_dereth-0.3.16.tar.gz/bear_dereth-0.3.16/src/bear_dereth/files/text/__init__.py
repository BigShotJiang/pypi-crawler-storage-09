"""A text file handler and related utilities."""
