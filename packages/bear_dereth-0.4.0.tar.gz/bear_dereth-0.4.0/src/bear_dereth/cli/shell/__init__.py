"""Shell utilities for CLI."""
