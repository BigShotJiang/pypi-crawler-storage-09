"""Logger Tests."""
