"""Integration tests for Bedrock AgentCore Memory integrations."""
