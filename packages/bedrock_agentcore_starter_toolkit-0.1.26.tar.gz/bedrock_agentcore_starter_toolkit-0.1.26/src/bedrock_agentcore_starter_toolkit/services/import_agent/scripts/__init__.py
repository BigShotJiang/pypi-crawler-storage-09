"""Translation from Bedrock Agents to Langchain/Strands + AgentCore Agents."""
