# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

__title__ = "beeper_desktop_api"
__version__ = "4.1.295"  # x-release-please-version
