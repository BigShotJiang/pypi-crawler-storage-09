"""CLI helper functions."""
