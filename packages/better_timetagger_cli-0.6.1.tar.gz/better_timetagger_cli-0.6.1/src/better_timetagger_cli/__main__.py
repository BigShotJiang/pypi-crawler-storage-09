from better_timetagger_cli.cli import cli

if __name__ == "__main__":
    cli()
