# noqa: N999
from betterKickAPI.eventsub.webhook import KickWebhook

__all__ = ["KickWebhook"]
