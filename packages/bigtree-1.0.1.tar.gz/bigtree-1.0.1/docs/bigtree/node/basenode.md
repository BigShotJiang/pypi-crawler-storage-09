---
title: BaseNode
---

# 🌱 BaseNode

::: bigtree.node.basenode
