---
title: Benchmarks
hide:
    - toc
---

# ⏰ Benchmarks

<div>
  <iframe onload="resizeIframe(this)" scrolling="no" style="width:100vw; border:none" src="../../dev/bench/index.html"></iframe>
</div>
