|:blossom:| DAGNode
============================================

.. automodule:: bigtree.node.dagnode
   :members:
   :show-inheritance:
