from .bikram import *  # NOQA

__author__ = """keshaB Paudel"""
__email__ = "aerawatcorp+bikram_python@gmail.com"
__version__ = "2.1.4"
