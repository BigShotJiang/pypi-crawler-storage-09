=======
History
=======

2.1.3 to 2.1.4 (2025-10-17)
---------------------------
* Few changes have been made to make the date map accurate as reported by several contributors.
* 2082 and 2083 BS Date changes and confirmed as per the Nepal RajPatra
* 2.1.4 - Bump to push the change log

2.1.0 to 2.1.3 (2024-06-20)
---------------------------
* Few changes have been made to make the date map accurate as reported by several contributors.
* 2062 BS Date changes and confirmed as per the Nepal RajPatra
* 2081 BS Date changes and confirmed as per the calendar published in 2081
* out of bound checks as suggested by Dipendra Nath (dipee), FIRST_AD_YEAR, LAST_AD_YEAR constanst introduced.
* 2.1.3 - Bump to push the change log

1.0.0 (2018-03-15)
------------------

* Added usage guide and module docs.
* Added :code:`pipenv` support.
* Removed :code:`tox`.
* Removed support for python versions older than 3.6.


0.1.2 (2016-11-13)
------------------

* Minor test fixes.


0.1.0 (2016-11-13)
------------------

* First release on PyPI.
