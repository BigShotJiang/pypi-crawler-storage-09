Welcome to Python Bikram Samwat's documentation!
================================================

Contents:

.. toctree::
   :maxdepth: 2

   readme
   installation
   usage
   bikram
   contributing
   history

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
