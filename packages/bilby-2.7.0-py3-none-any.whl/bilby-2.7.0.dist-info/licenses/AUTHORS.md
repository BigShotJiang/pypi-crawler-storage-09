# Authors

This file lists all the authors in first-name alphabetical order who have
contributed (either by code contribution or indirectly). If your name is not
listed here, please contact anyone on this list and raise your concern.

Abhirup Ghosh
Aditya Vijaykumar
Andrew Kim
Andrew Miller
Antoni Ramos-Buades
Apratim Ganguly
Avi Vajpeyi
Ben Patterson
Bruce Edelman
Carl-Johan Haster
Cecilio Garcia-Quiros
Charlie Hoy
Cheng Foo
Chentao Yang
Christopher Philip Luke Berry
Christos Karathanasis
Colm Talbot
Daniel Williams
David Keitel
Duncan Macleod
Eric Thrane
Ethan Payne
Francisco Javier Hernandez
Gregory Ashton
Hank Hua
Hector Estelles
Ignacio Magaña Hernandez
Isaac McMahon
Isobel Marguarethe Romero-Shaw
Jack Heinzel
Jacob Golomb
Jade Powell
James A Clark
Jeremy G Baier
John Veitch
Joshua Brandt
Josh Willis
Karl Wette
Katerina Chatziioannou
Kaylee de Soto
Khun Sang Phukon
Kruthi Krishna
Kshipraa Athar
Kyle Wong
Leslie Wade
Liting Xiao
Maite Mateu-Lucena
Marc Arene
Marcus Edward Lower
Margaret Millhouse
Marta Colleoni
Matthew Carney
Matthew David Pitkin
Michael Puerrer
Michael Williams
Monica Rizzo
Moritz Huebner
Nico Gerardo Bers
Nicola De Lillo
Nikhil Sarin
Nirban Bose
Noah Wolfe
Olivia Wilk
Paul Easter
Paul Lasky
Philip Relton
Rhys Green
Rhiannon Udall
Rico Lo
Roberto Cotesta
Rory Smith
S. H. Oh
Sacha Husa
Sama Al-Shammari
Samson Leong
Scott Coughlin
Serguei Ossokine
Shanika Galaudage
Sharan Banagiri
Shichao Wu
Simon Stevenson
Soichiro Morisaki
Soumen Roy
Stephen R Green
Sumeet Kulkarni
Sylvia Biscoveanu
Tathagata Ghosh
Teagan Clarke
Tomasz Baka
Will M. Farr
Virginia d'Emilio
Vivien Raymond
Ka-Lok Lo
Isaac Legred
Marc Penuliar
Andrew Fowlie
Martin White
Peter Tsun-Ho Pang
Alexandre Sebastien Goettel
Ann-Kristin Malz
Lorenzo Pompili
Sean Hibbitt
