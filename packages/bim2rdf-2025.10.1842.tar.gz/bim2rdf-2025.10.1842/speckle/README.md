speckle data mgt.

you can get the speckle json with  `python -m speckle.objects`.
