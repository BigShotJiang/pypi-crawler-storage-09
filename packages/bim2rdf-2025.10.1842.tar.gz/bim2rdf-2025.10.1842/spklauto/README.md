Place as much speckle automate code here
so that there is as little code as possible
in the the repo that the speckle automate workflow wants to
[create](https://github.com/specklesystems/speckle_automate_python_example).


Copy/paste [this main.py](./src/bim2rdf/spklauto/main.py)
to the [automation repo's main.py](https://github.com/specklesystems/speckle_automate_python_example/blob/main/main.py)
and make a 'release'.

todo:
* parameterize ?
