"""
Library functions used by various refinery units.
"""
