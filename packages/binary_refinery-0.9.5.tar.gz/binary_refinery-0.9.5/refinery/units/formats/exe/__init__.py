"""
A package with units for generic executables. Usually, PE, ELF, and MachO formats are covered.
"""
