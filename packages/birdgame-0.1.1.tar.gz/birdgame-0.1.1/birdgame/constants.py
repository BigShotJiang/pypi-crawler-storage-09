"""
Constants used across the birdgame package.
(may be updated in future releases)
"""

# This constant defines the forecast horizon in seconds
HORIZON = 3