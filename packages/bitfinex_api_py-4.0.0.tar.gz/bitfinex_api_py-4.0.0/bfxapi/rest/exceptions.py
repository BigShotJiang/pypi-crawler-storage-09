from bfxapi.exceptions import BfxBaseException


class RequestParameterError(BfxBaseException):
    pass


class GenericError(BfxBaseException):
    pass
