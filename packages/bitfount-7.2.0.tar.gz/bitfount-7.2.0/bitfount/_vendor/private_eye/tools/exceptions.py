class DebugToolsException(Exception):
    pass
