# bitmicro

**bitmicro** — MicroBitcoin (MBC) Python library, Bitcash-style.

✅ P2PKH address generation  
✅ Uncompressed pubkeys (MicroBitcoin style)  
✅ Proper prefix (0x26 “B”)  
✅ WIF format compatible with explorer wallets  
✅ Supports balance, unspent, broadcast  
