class CacheDict(dict):
    pass
