from bitwarden_rest_client.cli.app import main

if __name__ == "__main__":
    main()
