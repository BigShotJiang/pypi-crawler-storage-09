-- This file should undo anything in `up.sql`
DROP TABLE bookmarks;
DROP TABLE bookmarks_fts;
