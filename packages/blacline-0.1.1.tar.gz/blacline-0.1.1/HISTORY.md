# History

## 0.1.0 (2025-09-15)

* First release on PyPI.
