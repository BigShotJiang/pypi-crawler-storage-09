"""ODA processors adapted to the Bliss demo session."""
