from blissoda.demo.tests.itest_all import all_demo  # noqa F401
from blissoda.demo.tests.itest_print import all_print  # noqa F401
