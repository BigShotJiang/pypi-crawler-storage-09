# fmt: off
from blissoda.demo.tests.itest_id12 import ID12_CONVERTER as id12_converter  # noqa F401
from blissoda.demo.tests.itest_id12 import id12_demo  # noqa F401

# fmt: on
