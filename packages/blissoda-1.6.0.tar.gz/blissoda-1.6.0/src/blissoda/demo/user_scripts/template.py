from blissoda.demo.tests.itest_template import template_demo  # noqa F401
