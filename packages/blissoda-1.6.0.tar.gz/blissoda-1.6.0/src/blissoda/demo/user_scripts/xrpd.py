# fmt: off
from blissoda.demo.tests.itest_xrpd import XRPD_PROCESSED as xrpd_processor  # noqa F401
from blissoda.demo.tests.itest_xrpd import pct  # noqa F401
from blissoda.demo.tests.itest_xrpd import xrpd_demo_1d  # noqa F401
from blissoda.demo.tests.itest_xrpd import xrpd_demo_2d  # noqa F401

# fmt: on
