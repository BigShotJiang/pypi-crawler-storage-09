# Changelog

## 1.0.0 (2025-10-17)

Full Changelog: [v0.0.1...v1.0.0](https://github.com/Blooio/blooio-python-sdk/compare/v0.0.1...v1.0.0)

### Chores

* configure new SDK language ([8f81881](https://github.com/Blooio/blooio-python-sdk/commit/8f8188186e7367438a7d5f311a21499384056275))
* update SDK settings ([3a67436](https://github.com/Blooio/blooio-python-sdk/commit/3a67436282797fe0406e4cbcf4ecce9d523d8b5e))
* update SDK settings ([c8fc4f6](https://github.com/Blooio/blooio-python-sdk/commit/c8fc4f61c3028509ea520a92b56246a29edd9b3e))
