from .functions_a import a, b  # noqa: F401


def c(): ...


def d(): ...
