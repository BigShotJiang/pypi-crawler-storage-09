dict_of_parts = {
    "charging-port": "",
    "dsn-vc288": "",
    "charger-socket": "",
}
