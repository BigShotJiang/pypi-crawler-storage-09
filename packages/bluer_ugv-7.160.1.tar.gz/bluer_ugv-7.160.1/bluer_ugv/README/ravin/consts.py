description = "remote control car kit for teenagers."
