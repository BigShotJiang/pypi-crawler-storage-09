from bluer_objects.README.items import ImageItems

from bluer_ugv.README.rangin.consts import rangin_assets2


items = ImageItems(
    {
        f"{rangin_assets2}/rangin.png": "",
    }
)
