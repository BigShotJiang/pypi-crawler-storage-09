dict_of_parts = {
    "40-inch-TV": "2 x",
    "power-station": "",
    "TV-bracket": "",
}
