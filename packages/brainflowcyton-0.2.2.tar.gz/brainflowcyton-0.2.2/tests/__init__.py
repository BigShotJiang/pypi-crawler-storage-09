"""Tests for BrainflowCyton library."""
