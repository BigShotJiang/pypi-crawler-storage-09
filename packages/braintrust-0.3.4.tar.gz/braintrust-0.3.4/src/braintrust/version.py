VERSION = "0.3.4"

# this will be templated during the build
GIT_COMMIT = "f11265286454e2059d0de2a82ee4356601552bd2"
