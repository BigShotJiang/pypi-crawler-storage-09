# https://stackoverflow.com/questions/1739924/python-reload-component-y-imported-with-from-x-import-y
# Não importar classes diretamente!

from brazilian_holidays.datas import Calendario, Holidays

#__version__ = '0.1.1'
#__author__ = 'Michel Metran'
