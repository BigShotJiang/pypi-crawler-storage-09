rm -rf docs/assets
rm -rf docs/theme
