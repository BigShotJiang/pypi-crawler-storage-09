.. automodule:: brille.plotting
  :members:
