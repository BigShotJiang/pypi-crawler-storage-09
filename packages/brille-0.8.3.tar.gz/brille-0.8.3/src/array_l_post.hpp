#ifndef BRILLE_ARRAY_L_POST_HPP_
#define BRILLE_ARRAY_L_POST_HPP_
// to be included *after* LVec<T> are fully defined
#include "array_l_attributes.hpp"
#include "array_lvec_methods.tpp"
#include "array_l_functions.hpp"

#endif