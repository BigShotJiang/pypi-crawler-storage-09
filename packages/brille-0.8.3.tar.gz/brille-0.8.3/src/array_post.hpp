#ifndef BRILLE_ARRAY_POST_HPP_
#define BRILLE_ARRAY_POST_HPP_
// to be included *after* Array<T> and Array2<T> are fully defined
#include "array_attributes.hpp"
#include "array_functions.hpp"

#endif