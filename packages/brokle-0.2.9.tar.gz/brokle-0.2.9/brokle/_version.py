"""Version information for Brokle SDK."""

__version__ = "0.2.9"
__version_info__ = (0, 2, 9)
