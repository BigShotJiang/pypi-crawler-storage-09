import time


def wait_seconds(seconds: float) -> None:
    time.sleep(seconds)
