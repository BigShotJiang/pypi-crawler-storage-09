BYPASS: float = 0
"""No timeout."""

VERY_SHORT: float = 1
"""Very short timeout: 1 second."""

SHORT: float = 2
"""Short timeout: 2 seconds."""

DEFAULT: float = 3
"""Default timeout: 3 seconds."""

LONG: float = 5
"""Long timeout: 5 seconds."""
