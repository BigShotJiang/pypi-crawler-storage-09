DEFAULT: float = 0.25
"""Default interval: 0.25 seconds."""

MEDIUM: float = 0.5
"""Medium long interval: 0.5 seconds."""

LONG: float = 1
"""Long interval: 1 second."""
