TEMP_DIR: str = "temp"

TEMP_FILE: str = "temp"
