BYPASS: float = 0
"""No timeout."""

VERY_SHORT: float = 1
"""Very short timeout: 1 second."""

SHORT: float = 3
"""Short timeout: 3 seconds."""

DEFAULT: float = 5
"""Default timeout: 5 seconds."""

LONG: float = 10
"""Long timeout: 10 seconds."""
