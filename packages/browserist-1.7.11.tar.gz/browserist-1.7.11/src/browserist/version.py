__version_info__ = (1, 7, 11)
__version__ = ".".join(map(str, __version_info__))
