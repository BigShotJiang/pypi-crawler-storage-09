from ._micro_benchmark import benchmark
from ._timer import Timer
