"""Various helpers for collections / iterables / generators."""

from ._zip_random import zip_random
