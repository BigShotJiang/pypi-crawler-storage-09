from ._deterministic import linspace, logspace
