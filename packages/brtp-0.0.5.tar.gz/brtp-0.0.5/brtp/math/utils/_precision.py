import math
import sys

EPS = sys.float_info.epsilon  # Machine epsilon for 64-bit float (float64)
HALF_EPS = math.sqrt(EPS)
