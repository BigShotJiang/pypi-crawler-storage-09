"""Tests for buildmcp package."""
