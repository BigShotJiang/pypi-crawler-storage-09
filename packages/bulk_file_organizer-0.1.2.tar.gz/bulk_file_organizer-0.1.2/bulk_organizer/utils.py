def normalize_extension(ext: str) -> str:
    return ext.lower().strip()
