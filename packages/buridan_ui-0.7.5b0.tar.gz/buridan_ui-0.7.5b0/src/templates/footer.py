import reflex as rx


def footer():
    return rx.el.div()
