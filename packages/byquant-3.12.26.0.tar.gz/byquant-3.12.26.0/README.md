ByQuant.com

Install:
pip install byquant==*

Windows:
ByQuant 3.12.x.0 for Python 3.12.n

For other versions, please contact us via email for information.
Support Windows, Linux, Mac

Professional Edition Upgrade Support: https://byquant.com/