ByQuant.com

安装:
pip install byquant==*

Windows:
ByQuant 3.12.x.0 仅支持 Python 3.12.n

对于其他系统或Python版本的库请联系获取！

专业版本功能支持请访问: https://byquant.com/