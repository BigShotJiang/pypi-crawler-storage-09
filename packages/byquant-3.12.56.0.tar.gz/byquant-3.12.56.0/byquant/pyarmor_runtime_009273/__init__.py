# Pyarmor 9.1.9 (basic), 009273, 2025-10-17T19:03:16.725377
from .pyarmor_runtime import __pyarmor__
