# coding=utf-8
ak = ''
sk = ''