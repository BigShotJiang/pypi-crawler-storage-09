"""
The scripts main functions.
"""
