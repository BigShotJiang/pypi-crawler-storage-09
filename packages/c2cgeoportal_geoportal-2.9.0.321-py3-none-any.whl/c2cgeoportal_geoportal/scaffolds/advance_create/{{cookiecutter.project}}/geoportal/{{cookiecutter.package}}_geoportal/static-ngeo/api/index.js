/* eslint-disable */
import Map from 'api/Map.js';
import {dynamicUrl} from 'api/constants.js';

// The URL to the dynamic constants service.
dynamicUrl.dynamicUrl = '{FULL_ENTRY_POINT}dynamic.json?interface=api';

const lib = {
  Map,
};

export default lib;
