RETRY_SIGNATURE = 8  # max retries, might be terminated earliers
