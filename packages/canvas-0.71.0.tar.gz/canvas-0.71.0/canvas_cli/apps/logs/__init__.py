from canvas_cli.apps.logs.logs import logs

__all__ = ("logs",)
