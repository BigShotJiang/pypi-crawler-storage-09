"""Test suite for captionflow."""
