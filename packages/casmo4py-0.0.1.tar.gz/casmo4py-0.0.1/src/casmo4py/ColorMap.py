#! /usr/bin/env python3

""" """


class ColorMap:
    def __init__(self):
        """
        Args:
            bla (test.type): does blub
        """

        print("hello cmap")


if __name__ == "__main__":
    m = ColorMap()
