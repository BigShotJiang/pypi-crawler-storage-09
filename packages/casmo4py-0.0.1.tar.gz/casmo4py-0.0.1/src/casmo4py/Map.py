#! /usr/bin/env python3

""" """


class Map:
    def __init__(self):
        """
        Args:
            bla (test.type): does blub
        """

        print("hello map")


if __name__ == "__main__":
    m = Map()
