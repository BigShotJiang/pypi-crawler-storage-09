#! /usr/bin/env python3

""" """


class Legend:
    def __init__(self):
        """
        Args:
            bla (test.type): does blub
        """

        print("hello Legend")


if __name__ == "__main__":
    m = Legend()
