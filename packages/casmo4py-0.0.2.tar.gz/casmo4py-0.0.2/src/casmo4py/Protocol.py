#! /usr/bin/env python3

""" """


class Protocol:
    def __init__(self):
        """
        Args:
            bla (test.type): does blub
        """

        print("hello protocol")


if __name__ == "__main__":
    m = Protocol()
