#! /usr/bin/env python3

""" """


class Utils:
    def __init__(self):
        """
        Args:
            bla (test.type): does blub
        """

        print("hello Utils")

    def land_vs_port(self, coordinates):
        return

    def map_width(self, orientation, coordinates):
        return


if __name__ == "__main__":
    m = Utils()
