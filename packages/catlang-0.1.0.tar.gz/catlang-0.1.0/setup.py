from setuptools import setup, find_packages

setup(
    name="catLang",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        "regex>=2025.10.16"  # your library depends on regex
    ],
    author="YourName",
    author_email="you@example.com",
    description="CatLang: your custom Python transpiler",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/yourname/catLang",  # optional
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License"
    ],
)
