__version__ = "3.0.24"
__cato_host__ = "https://api.catonetworks.com/api/v1/graphql2"