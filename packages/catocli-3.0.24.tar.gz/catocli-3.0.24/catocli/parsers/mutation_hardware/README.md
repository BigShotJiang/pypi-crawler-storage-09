
## CATO-CLI - mutation.hardware:
[Click here](https://api.catonetworks.com/documentation/#mutation-hardware) for documentation on this operation.

### Usage for mutation.hardware:

`catocli mutation hardware -h`
