
## CATO-CLI - mutation.policy:
[Click here](https://api.catonetworks.com/documentation/#mutation-policy) for documentation on this operation.

### Usage for mutation.policy:

`catocli mutation policy -h`
