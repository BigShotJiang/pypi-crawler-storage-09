
## CATO-CLI - query.groups:
[Click here](https://api.catonetworks.com/documentation/#query-groups) for documentation on this operation.

### Usage for query.groups:

`catocli query groups -h`
