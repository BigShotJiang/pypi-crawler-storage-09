
## CATO-CLI - query.groups.group:
[Click here](https://api.catonetworks.com/documentation/#query-group) for documentation on this operation.

### Usage for query.groups.group:

`catocli query groups group -h`
