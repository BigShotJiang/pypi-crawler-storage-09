
## CATO-CLI - query.policy.internetFirewall:
[Click here](https://api.catonetworks.com/documentation/#query-internetFirewall) for documentation on this operation.

### Usage for query.policy.internetFirewall:

`catocli query policy internetFirewall -h`
