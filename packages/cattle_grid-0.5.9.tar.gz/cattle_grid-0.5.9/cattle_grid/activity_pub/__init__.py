from .actor.requester import is_valid_requester_for_obj

__all__ = ["is_valid_requester_for_obj"]
