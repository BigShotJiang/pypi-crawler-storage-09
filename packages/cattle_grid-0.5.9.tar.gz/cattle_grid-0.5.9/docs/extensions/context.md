::: cattle_grid.extensions.examples.context
    options:
        heading_level: 1
        show_submodules: true
        filters:
            - '!testing*'
            - '!test_*'