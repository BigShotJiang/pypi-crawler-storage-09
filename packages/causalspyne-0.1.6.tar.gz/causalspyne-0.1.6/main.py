def main():
    print("Hello from causalspyne!")


if __name__ == "__main__":
    main()
