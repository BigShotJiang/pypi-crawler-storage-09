from setuptools import setup, find_packages

setup(
    name="causalspyne",
    version="0.1.6",
    packages=find_packages(),  # Ensure your package folder is inside the find_packages scope
)

