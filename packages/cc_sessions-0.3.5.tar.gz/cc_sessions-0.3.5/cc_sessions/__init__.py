"""cc-sessions: an opinionated approach to productive work in Claude Code."""

__version__ = "0.2.9"
