"""
Claude Code Sessions Framework
Enforced methodology for AI pair programming
"""

__version__ = "0.2.9"
__author__ = "toast"