> - Check git status first for uncommitted work
>   - Address EVERY file shown in `git status`, not just expected files
>   - Common missed files: CLAUDE.md, sessions/state files, test outputs
>   - Either commit ALL changes or explicitly discuss with user
> - Checkout the branch
> - Only pull from remote if the remote branch exists