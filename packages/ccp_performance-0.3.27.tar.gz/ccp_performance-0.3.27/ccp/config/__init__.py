POLYTROPIC_METHOD = "sandberg_colby"
EOS = "REFPROP"
