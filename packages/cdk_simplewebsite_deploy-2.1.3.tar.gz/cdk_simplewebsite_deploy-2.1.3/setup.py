import json
import setuptools

kwargs = json.loads(
    """
{
    "name": "cdk-simplewebsite-deploy",
    "version": "2.1.3",
    "description": "This is an AWS CDK v2 Construct to simplify deploying a single-page website use CloudFront distributions.",
    "license": "Apache-2.0",
    "url": "https://github.com/SnapPetal/cdk-simplewebsite-deploy",
    "long_description_content_type": "text/markdown",
    "author": "Thon Becker<thon.becker@gmail.com>",
    "bdist_wheel": {
        "universal": true
    },
    "project_urls": {
        "Source": "https://github.com/SnapPetal/cdk-simplewebsite-deploy"
    },
    "package_dir": {
        "": "src"
    },
    "packages": [
        "cdk_simplewebsite_deploy",
        "cdk_simplewebsite_deploy._jsii"
    ],
    "package_data": {
        "cdk_simplewebsite_deploy._jsii": [
            "cdk-simplewebsite-deploy@2.1.3.jsii.tgz"
        ],
        "cdk_simplewebsite_deploy": [
            "py.typed"
        ]
    },
    "python_requires": "~=3.9",
    "install_requires": [
        "aws-cdk-lib>=2.175.0, <3.0.0",
        "constructs>=10.0.5, <11.0.0",
        "jsii>=1.116.0, <2.0.0",
        "publication>=0.0.3",
        "typeguard>=2.13.3,<4.3.0"
    ],
    "classifiers": [
        "Intended Audience :: Developers",
        "Operating System :: OS Independent",
        "Programming Language :: JavaScript",
        "Programming Language :: Python :: 3 :: Only",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Typing :: Typed",
        "Development Status :: 5 - Production/Stable",
        "License :: OSI Approved"
    ],
    "scripts": []
}
"""
)

with open("README.md", encoding="utf8") as fp:
    kwargs["long_description"] = fp.read()


setuptools.setup(**kwargs)
