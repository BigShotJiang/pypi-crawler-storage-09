"""
CEL2CLI - Common Expression Language for Agent Control

⚠️ This is a placeholder package. Full implementation coming soon.

Visit https://github.com/cel2cli/cel2cli for updates.
"""

__version__ = "0.0.1"
__author__ = "CEL2CLI Team"
__email__ = "info@cel2cli.com"

def _placeholder():
    raise NotImplementedError(
        "CEL2CLI is under development. "
        "Visit https://github.com/cel2cli/cel2cli for updates."
    )
