r"""
Graphic module
"""
