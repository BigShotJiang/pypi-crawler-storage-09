# Cell Mechanics package

This package can be used for simulation of cell mecahncis

## Features

## Force calcuation from traction force microscopy
- upload image of substrate beads
- approximation of non-linear traction forces
- Demo can be found [here](https://github.com/utksara/cellmech/blob/main/demonstration.ipynb) 

# cellular modelling
- develop models of individual cells using
