# Magnetic flux and flux density (B field)

::: cfsem.flux_density_linear_filament

::: cfsem.flux_density_circular_filament

::: cfsem.flux_density_ideal_solenoid

::: cfsem.flux_density_circular_filament_cartesian

::: cfsem.flux_density_dipole