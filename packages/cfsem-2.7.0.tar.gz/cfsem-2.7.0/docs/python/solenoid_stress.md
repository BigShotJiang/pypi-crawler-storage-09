# Solenoid Stress & Strain

::: cfsem.solenoid_stress
    options:
      show_submodules: true
