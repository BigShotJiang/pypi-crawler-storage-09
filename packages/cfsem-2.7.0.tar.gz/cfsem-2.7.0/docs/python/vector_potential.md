# Vector Potential

::: cfsem.vector_potential_circular_filament

::: cfsem.vector_potential_linear_filament
