from .views import BLUEPRINT
