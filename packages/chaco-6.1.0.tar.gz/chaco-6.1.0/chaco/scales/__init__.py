"""
Generic code to create ticks and labels for data graphics axes.

The code in this package does not depend on any specific modules and should be
reusable in a variety of contexts.
"""
