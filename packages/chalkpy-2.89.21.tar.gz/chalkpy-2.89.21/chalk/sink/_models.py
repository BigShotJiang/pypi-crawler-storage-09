class SinkIntegrationProtocol:
    """Marker interface for Chalk objects that can be used for @sink() resolver integrations"""

    ...
