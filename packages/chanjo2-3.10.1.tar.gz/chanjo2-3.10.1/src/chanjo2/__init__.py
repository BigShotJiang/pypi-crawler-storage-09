from dotenv import load_dotenv

__version__ = "3.10.1"
load_dotenv()
