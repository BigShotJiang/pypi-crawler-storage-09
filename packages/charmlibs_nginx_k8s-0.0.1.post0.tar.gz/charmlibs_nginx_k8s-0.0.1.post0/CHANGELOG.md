# 0.0.1 - 9 October 2025

Initial library release.
