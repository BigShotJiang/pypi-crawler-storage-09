# chatgpt-hj3415

chatgpt-hj3415 is the program using chatgpt api.

## Installation

```bash
pip install chatgpt-hj3415
```

## 사전 준비
	1.	https://platform.openai.com/account/api-keys 에서 API 키를 발급받습니다.
	2.	아래 명령어로 라이브러리를 설치합니다:

`pip install openai`

