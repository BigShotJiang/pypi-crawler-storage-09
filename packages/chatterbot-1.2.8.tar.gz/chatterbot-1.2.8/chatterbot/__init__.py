"""
ChatterBot is a machine learning, conversational dialog engine.
"""
from .chatterbot import ChatBot


__version__ = '1.2.8'

__all__ = (
    'ChatBot',
)
