from .cheap_settings import CheapSettings as CheapSettings
