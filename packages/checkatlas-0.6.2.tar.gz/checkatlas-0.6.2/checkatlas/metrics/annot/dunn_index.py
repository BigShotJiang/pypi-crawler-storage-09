def run(annotation, ref_annotation):
    """
    `Dunn readthedocs
    <https://checkatlas.readthedocs.io/en/latest/metrics/clustering/dunn/>`__

    TO BE IMPLEMENTED

    :param annotation:
    :param ref_annotation:
    :return:
    """
    return 0
