def run(high_dim_counts, low_dim_counts):
    """
    TO BE IMPLEMENTED

    :param high_dim_counts:
    :param low_dim_counts:
    :return:
    """
    return 0
