#!/usr/bin/env python3

import sys

from . import main

if __name__ == "__main__":
    sys.exit(main.main())
