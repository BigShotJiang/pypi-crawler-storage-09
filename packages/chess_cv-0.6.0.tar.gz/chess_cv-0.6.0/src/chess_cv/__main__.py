"""Main entry point for chess_cv package."""

from chess_cv import main

if __name__ == "__main__":
    main()
