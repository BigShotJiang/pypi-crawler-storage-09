from __future__ import annotations

job_timeout = 60
