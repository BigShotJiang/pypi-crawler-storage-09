from __future__ import annotations

import sys

legacy_keyring_required = sys.platform == "linux"
