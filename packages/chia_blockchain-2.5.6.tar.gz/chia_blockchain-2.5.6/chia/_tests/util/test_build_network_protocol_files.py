from __future__ import annotations

from chia._tests.util.build_network_protocol_files import main


def test_build_network_protocol_files() -> None:
    main()
