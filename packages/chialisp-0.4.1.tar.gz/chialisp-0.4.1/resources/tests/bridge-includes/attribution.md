# Attribution

Source files from https://github.com/Chia-Network/bridge

Collected here as a standard compiler regression test
