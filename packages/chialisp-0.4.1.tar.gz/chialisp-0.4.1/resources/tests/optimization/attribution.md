# Attribution

Source files from https://github.com/Chia-Network/bridge

Collected here to be used for testing compiler optimizations
