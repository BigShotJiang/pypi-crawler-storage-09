#!/usr/bin/env python
# -*- coding: utf-8 -*-

from style_transfer.libs.transfer_factory import TransferFactory
