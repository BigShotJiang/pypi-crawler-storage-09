"""
ChronoMap package initialization.
"""

__version__ = "2.0.0"

from .chronomap import (
    ChronoMap,
    ChronoMapError,
    ChronoMapKeyError,
    ChronoMapTypeError,
    ChronoMapValueError,
)
