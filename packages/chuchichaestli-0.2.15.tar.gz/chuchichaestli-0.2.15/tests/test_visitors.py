# SPDX-FileCopyrightText: 2024-present Members of CAIIVS
# SPDX-FileNotice: Part of chuchichaestli
# SPDX-License-Identifier: GPL-3.0-or-later
"""Unit tests for the memory_usage module."""

import pytest
import torch
from chuchichaestli.debug.memory_usage import (
    CudaMemoryStatsVisitor,
    MPSMemoryAllocationVisitor,
)
from chuchichaestli.models.resnet import ResidualBlock


def test_cuda_memory_stats_visitor():
    """Test the CUDA memory stats visitor."""
    if not CudaMemoryStatsVisitor.has_cuda():
        print("No CUDA device found!")
        return
    visitor = CudaMemoryStatsVisitor()
    res_block = ResidualBlock(3, 64, 32, True, 64)
    visitor.visit(res_block)
    res_block(torch.randn(1, 64, 32, 32, 32), torch.randn(1, 64))
    assert (
        len(visitor.memory_stats) == 10 + 2 + 1
    )  # 10 layers + 2 for the Norm internals + resnet block itself


@pytest.fixture
def mps_visitor(request):
    """Initialize and cache fixture for a stripped MPS visitor."""
    v_dict = request.config.cache.get("mps_visitor", None)
    if not MPSMemoryAllocationVisitor.has_mps():
        print("No MPS device found!")
        return v_dict
    elif v_dict is None:
        torch.mps.empty_cache()
        mps_device = torch.device("mps")
        # init visitor
        visitor = MPSMemoryAllocationVisitor()
        # Conv3D is not supported on MPS
        res_block = ResidualBlock(2, 64, 32, True, 64)
        res_block.to(mps_device)
        visitor.visit(res_block)
        res_block(
            torch.randn(1, 64, 32, 32, device=mps_device),
            torch.randn(1, 64, device=mps_device),
        )
        # remove hook references for JSON caching
        visitor.unlink()
        request.config.cache.set("mps_visitor", visitor.__dict__)
    else:
        visitor = MPSMemoryAllocationVisitor(**v_dict)
    return visitor


def test_mps_memory_allocation(mps_visitor):
    """Test the MPS memory allocation visitor."""
    visitor = mps_visitor
    if visitor:
        assert len(visitor.memory_stats) == 10 + 1  # 10 layers + resnet block itself


def test_mps_memory_report(mps_visitor):
    """Test the MPS memory allocation visitor."""
    visitor = mps_visitor
    if visitor:
        print()
        rep = visitor.report()
        assert isinstance(rep, list)
        assert len(rep) == 10 + 1
        assert isinstance(rep[0], str)
