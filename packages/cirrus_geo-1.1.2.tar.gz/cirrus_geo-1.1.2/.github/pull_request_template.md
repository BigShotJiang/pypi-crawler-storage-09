**Related Issue(s):**

- #

**Proposed Changes:**

1. [Describe change]
2. [Describe change]

**PR Checklist:**

- [ ] I have added my changes to the [CHANGELOG](https://github.com/cirrus-geo/cirrus-geo/blob/main/CHANGELOG.md) **or** a CHANGELOG entry is not required.
