Pipeline Monitoring
===================

State Tracking
--------------

Tracking the state of workflow executions is essential for pipeline monitorig,
successes and failures.  This is facilitated by the :doc:`StateDB
<70_statedb>`, and AWS DynamoDB table where execution statuses are stored,
managed, and updated.

Cirrus API
----------

AWS Console
-----------

Step Functions
^^^^^^^^^^^^^^

Task logs in CloudWatch
^^^^^^^^^^^^^^^^^^^^^^^
