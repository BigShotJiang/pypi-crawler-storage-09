.. include:: index.include



.. toctree::
   :maxdepth: 2
   :glob:
   :caption: Cirrus documentation

   cirrus/*

.. toctree::
   :maxdepth: 2
   :glob:
   :titlesonly:
   :caption: Component READMEs

   components/*/index

.. toctree::
   :maxdepth: 2
   :glob:
   :titlesonly:
   :caption: Cirrus CLI READMEs

   cli/*
