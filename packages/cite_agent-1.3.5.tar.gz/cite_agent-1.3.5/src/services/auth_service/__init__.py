"""
Authentication service package
"""