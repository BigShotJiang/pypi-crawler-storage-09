"""LLM service package exposing the unified LLMManager."""

from .llm_manager import LLMManager

__all__ = ["LLMManager"]
