"""Project root package initializer."""
