"""Placeholder module retained after removing the legacy tool-framework tests.

These tests targeted an implementation that no longer exists in the maintained
codebase. Leaving an explanatory stub prevents pytest from reporting legacy
skips while preserving historical breadcrumbs for future archaeologists.
"""
