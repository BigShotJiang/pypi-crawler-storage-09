See the contributing guide in the [docs](https://citric.readthedocs.io/en/latest/contributing/code-of-conduct.html) for more information.
