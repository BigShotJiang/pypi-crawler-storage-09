# Docker

Moved to [/contributing/testing](/contributing/testing.md#integration-tests).
