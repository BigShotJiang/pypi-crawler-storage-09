# Updating dependencies

The easiest way to update dependencies is to use the the [`just`][just] command. This command will update all dependencies to the latest version.

Along with the `just` command line tool, you'll need to have [`uv`][uv] installed.

[just]: https://just.systems/man/en/prerequisites.html
[uv]: https://docs.astral.sh/uv/getting-started/installation/
