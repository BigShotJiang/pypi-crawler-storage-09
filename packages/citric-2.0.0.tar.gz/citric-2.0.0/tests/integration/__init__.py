"""RPC and REST integration tests."""
