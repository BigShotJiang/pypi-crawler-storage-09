"""The execution engine allows creating and evaluating computation graphs models.

Modules:
    frontend: Graph construction and manipulation frontend.
"""

# SPDX-License-Identifier: Apache-2.0
