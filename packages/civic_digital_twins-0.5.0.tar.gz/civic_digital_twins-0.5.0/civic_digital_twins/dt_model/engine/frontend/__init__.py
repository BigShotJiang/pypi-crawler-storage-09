"""The engine frontend allows expressing models as computation graphs.

Modules:
    graph: Graph construction and manipulation.
"""

# SPDX-License-Identifier: Apache-2.0
