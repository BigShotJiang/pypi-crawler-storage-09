"""Backward compatibility ensemble symbols."""

from ..simulation.ensemble import Ensemble

__all__ = ["Ensemble"]
