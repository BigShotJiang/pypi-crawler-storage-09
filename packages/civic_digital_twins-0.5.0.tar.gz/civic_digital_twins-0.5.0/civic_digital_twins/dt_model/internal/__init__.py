"""Internal Packages.

This package groups together internal packages. The semantics of internal
packages is that there is no API stability guarantee.
"""

# SPDX-License-Identifier: Apache-2.0
