"""
The example package contains examples.

We do not install examples, as they are not needed for the library
to work. Yet, we include them in the main package for testing.
"""

# SPDX-License-Identifier: Apache-2.0
