"""Symbols used by the civic digital twins model."""
