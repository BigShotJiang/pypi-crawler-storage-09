"""Tests for the civic_digital_twins.dt_model.reference_models.molveno package."""

# SPDX-License-Identifier: Apache-2.0
