# SPDX-FileCopyrightText: Copyright © 2022 Idiap Research Institute <contact@idiap.ch>
#
# SPDX-License-Identifier: BSD-3-Clause

integer = 1000
flag = True
choice = "blue"
str = "bar"  # noqa: A001
