.. SPDX-FileCopyrightText: Copyright © 2022 Idiap Research Institute <contact@idiap.ch>
..
.. SPDX-License-Identifier: BSD-3-Clause

.. _python: http://www.python.org
.. _pip: https://pip.pypa.io/en/stable/
.. _uv: https://github.com/astral-sh/uv
.. _rye: https://github.com/astral-sh/rye
.. _poetry: https://python-poetry.org
.. _pixi: https://pixi.sh
.. _mamba: https://mamba.readthedocs.io/en/latest/index.html
.. _toml: https://toml.io
.. _tomli: https://pypi.org/project/tomli/
.. _package entry-points: https://packaging.python.org/en/latest/specifications/entry-points/
.. _click: http://click.palletsprojects.com/
.. _click-plugins: https://github.com/click-contrib/click-plugins
.. _logging-tree module: https://pypi.org/project/logging_tree/
.. _xdg-defaults: https://specifications.freedesktop.org/basedir-spec/basedir-spec-latest.html
