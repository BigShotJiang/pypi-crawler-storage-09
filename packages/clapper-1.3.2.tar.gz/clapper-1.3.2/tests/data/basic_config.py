"""Example configuration module."""

a = 1
b = a + 2
