# the b variable from the last config file is available here
c = b + 1  # noqa: F821
b = b + 3  # noqa: F821
