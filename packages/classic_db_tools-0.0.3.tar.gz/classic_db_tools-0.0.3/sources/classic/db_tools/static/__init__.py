from .factory import StaticQueriesCache
