"""Claude Code hooks integration for claude-mpm."""

from .hook_handler import ClaudeHookHandler

__all__ = ["ClaudeHookHandler"]
