from .core import console_main_claude as main

