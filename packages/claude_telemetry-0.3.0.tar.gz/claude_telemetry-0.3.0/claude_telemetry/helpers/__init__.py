"""Helper utilities for claude_telemetry."""
