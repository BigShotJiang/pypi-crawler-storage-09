"""Examples for claude_telemetry usage."""
