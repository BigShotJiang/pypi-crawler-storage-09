# cleanote/__init__.py
"""CleanNote package."""

__version__ = "0.0.1"
