## [2.0.16] - 2025-10-16

### Added
- Add json attribute to api backend by @cmancone in [#30](https://github.com/clearskies-py/clearskies/pull/30)
- Add json attribute to api backend

### Fixed
- Reorder map_records_response
- Reorder mapping steps
- Use empty instead of empty_model

