from .number import Number


class Double(Number):
    _format = "double"
