class ModuleClass:
    pass
