## [2.0.5] - 2025-10-16

### Changed
- Missing-f by @tnijboer in [#2](https://github.com/clearskies-py/doc-builder/pull/2)
- Missing-f by @cmancone
- Update copier
- Update copier

