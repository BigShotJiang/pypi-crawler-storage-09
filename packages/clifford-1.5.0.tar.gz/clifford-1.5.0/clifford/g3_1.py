from . import Cl
layout, blades = Cl(3, 1)
locals().update(blades)
