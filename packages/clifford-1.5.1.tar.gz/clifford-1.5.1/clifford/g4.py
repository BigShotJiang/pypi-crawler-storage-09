from . import Cl
layout, blades = Cl(4)
locals().update(blades)
