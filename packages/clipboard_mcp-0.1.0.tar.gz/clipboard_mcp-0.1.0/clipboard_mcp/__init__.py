"""
Clipboard MCP Server

An MCP server that provides system clipboard read and write capabilities.
"""

__version__ = "0.1.0"
__author__ = "Gabi Teodoru"
__email__ = "gabiteodoru@gmail.com"
