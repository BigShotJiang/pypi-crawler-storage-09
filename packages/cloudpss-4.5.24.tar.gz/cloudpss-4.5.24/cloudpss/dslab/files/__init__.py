from .files import getCurveData
__all__ = ['getCurveData']