from .IESResult import IESResult


class IESLabSimulationResult(IESResult):
    pass