from setuptools import setup, find_packages

setup(
    name="cloudsss",
    version="0.1.0",
    author="Ranjeev Ramprasad",
    author_email="ranjeevramprasad@gmail.com",
    description="A simple example package",
    packages=find_packages(),
    install_requires=[],
    python_requires=">=3.7",
)
