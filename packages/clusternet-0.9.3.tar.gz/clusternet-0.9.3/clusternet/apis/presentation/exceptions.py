class BadRequestException(Exception):
    pass

class NotFoundException(Exception):
    pass

