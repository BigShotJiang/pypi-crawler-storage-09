---
sidebar_position: 5
---

# cscope info

`cscope info` shows Cluster Name and Slurm version.

```shell
$ cscope info
Cluster Name: <your-cluster-name>
Slurm Version: 24.11.5
```
