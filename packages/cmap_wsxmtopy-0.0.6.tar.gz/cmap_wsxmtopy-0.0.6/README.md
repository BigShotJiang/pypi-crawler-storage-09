# cmap_wsxmTopy
Small library to convert colormaps from .lut (wsxm) to python LinearSegmentedColormap

Always wanted to use your viridis cmap, but don't want to give up the handy functions of wsxm?
Check the example to see the how it works.

