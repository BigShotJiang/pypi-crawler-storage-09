"""cmem-plugin-irdi"""
