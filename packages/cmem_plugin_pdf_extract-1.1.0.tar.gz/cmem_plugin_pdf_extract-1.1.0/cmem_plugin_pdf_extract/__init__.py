"""cmem-plugin-pdf-extract"""
