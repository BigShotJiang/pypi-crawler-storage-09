"""cmem-plugin-project-resources"""
