"""
Cocina Package

A comprehensive collection of tools for building Python projects with
sophisticated configuration management and job execution capabilities.

License: BSd 3-clause
"""
