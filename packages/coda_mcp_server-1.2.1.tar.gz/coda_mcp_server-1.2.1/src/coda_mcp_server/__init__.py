"""A template for deploying FastMCP servers."""
