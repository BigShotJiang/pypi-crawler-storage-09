from __future__ import annotations

from typing import TYPE_CHECKING, List

import httpx

if TYPE_CHECKING:
    from . import AsyncClient
from codeapi.types import (
    CodeInfo,
    CodeType,
    CodeZip,
    DataZip,
    EnvVars,
    Job,
    JobStage,
    JobStatus,
    JobType,
    JsonData,
)


class AsyncStoredCliClient:
    def __init__(self, client: AsyncClient):
        self._client = client

    async def run(
        self,
        code_id: str,
        command: str,
        env_vars: EnvVars | dict | None = None,
        data_zip: DataZip | None = None,
        timeout: float | None = None,
    ) -> Job:
        """Runs stored code.

        Args:
            code_id (str): The code ID.
            command (str): The command to run.
            env_vars (EnvVars | dict | None): Optional environment variables.
            data_zip (DataZip | None): Optional data zip.
            timeout (float | None): The timeout for the job.

        Returns:
            Job: The created job.

        Raises:
            HTTPException: If the request fails.
        """
        url = f"{self._client.base_url}/jobs/code/{code_id}/run/cli"

        files = self._client._prepare_files(data_zip=data_zip)
        data = {"command": command}
        if env_vars:
            data["env_vars"] = EnvVars(env_vars).json_str
        params = {"timeout": timeout} if timeout else {}

        async with httpx.AsyncClient() as client:
            try:
                response = await client.post(
                    url,
                    headers=self._client.api_key_header,
                    files=files or None,
                    data=data,
                    params=params,
                )
                response.raise_for_status()
                return Job(**response.json())
            except httpx.HTTPStatusError as e:
                raise self._client._get_http_exception(httpx_error=e)

    async def list_info(self) -> list[CodeInfo]:
        """List all stored CLI code.

        Returns:
            list[CodeInfo]: List of CLI code info.
        """
        return await self._client.code.list_info(code_type=CodeType.CLI)

    async def delete(self, code_id: str) -> str:
        """Delete stored CLI code.

        Args:
            code_id (str): The code ID to delete.

        Returns:
            str: Deletion confirmation message.

        Raises:
            ValueError: If the code_id is not CLI code.
        """
        # Verify this is actually CLI code
        code_info = await self._client.code.get_info(code_id)
        if code_info.code_type != CodeType.CLI:
            raise ValueError(
                f"Code '{code_id}' is {code_info.code_type}, not CLI code. "
                "Cannot delete non-CLI code from CLI client."
            )

        return await self._client.code.delete(code_id)


class AsyncCliJobsClient:
    def __init__(self, client):
        self._client = client

    async def list(
        self,
        job_status: JobStatus | None = None,
        job_stage: JobStage | None = None,
    ) -> List[Job]:
        """List CLI jobs.

        Args:
            job_status (JobStatus | None): Filter by job status.
            job_stage (JobStage | None): Filter by job stage.

        Returns:
            list[Job]: List of CLI jobs.
        """
        return await self._client.jobs.list(
            job_type=JobType.RUN_CLI,
            job_status=job_status,
            job_stage=job_stage,
        )

    async def get_latest(self) -> Job | None:
        """Get the most recent CLI job.

        Returns:
            Job | None: The most recent CLI job, or None if no jobs exist.
        """
        jobs = await self.list()
        return jobs[0] if jobs else None

    async def list_queued(self) -> List[Job]:
        """Get all queued CLI jobs.

        Returns:
            List[Job]: List of queued CLI jobs.
        """
        return await self.list(job_status=JobStatus.QUEUED)

    async def list_scheduled(self) -> List[Job]:
        """Get all scheduled CLI jobs.

        Returns:
            List[Job]: List of scheduled CLI jobs.
        """
        return await self.list(job_status=JobStatus.SCHEDULED)

    async def list_started(self) -> List[Job]:
        """Get all started CLI jobs.

        Returns:
            list[Job]: List of started CLI jobs.
        """
        return await self.list(job_status=JobStatus.STARTED)

    async def list_deferred(self) -> List[Job]:
        """Get all deferred CLI jobs.

        Returns:
            List[Job]: List of deferred CLI jobs.
        """
        return await self.list(job_status=JobStatus.DEFERRED)

    async def list_canceled(self) -> List[Job]:
        """Get all canceled CLI jobs.

        Returns:
            List[Job]: List of canceled CLI jobs.
        """
        return await self.list(job_status=JobStatus.CANCELED)

    async def list_stopped(self) -> List[Job]:
        """Get all stopped CLI jobs.

        Returns:
            List[Job]: List of stopped CLI jobs.
        """
        return await self.list(job_status=JobStatus.STOPPED)

    async def list_failed(self) -> List[Job]:
        """Get all failed CLI jobs.

        Returns:
            list[Job]: List of failed CLI jobs.
        """
        return await self.list(job_status=JobStatus.FAILED)

    async def list_finished(self) -> List[Job]:
        """Get all finished CLI jobs.

        Returns:
            list[Job]: List of finished CLI jobs.
        """
        return await self.list(job_status=JobStatus.FINISHED)

    async def list_timed_out(self) -> List[Job]:
        """Get all timed out CLI jobs.

        Returns:
            List[Job]: List of timed out CLI jobs.
        """
        return await self.list(job_status=JobStatus.TIMEOUT)

    async def list_pre_running(self) -> List[Job]:
        """Get all pre-running CLI jobs.

        Returns:
            List[Job]: List of pre-running CLI jobs.
        """
        return await self.list(job_stage=JobStage.PRE_RUNNING)

    async def list_running(self) -> List[Job]:
        """Get all running CLI jobs.

        Returns:
            List[Job]: List of running CLI jobs.
        """
        return await self.list(job_stage=JobStage.RUNNING)

    async def list_post_running(self) -> List[Job]:
        """Get all post-running CLI jobs.

        Returns:
            List[Job]: List of post-running CLI jobs.
        """
        return await self.list(job_stage=JobStage.POST_RUNNING)


class AsyncCliClient:
    def __init__(self, client: AsyncClient):
        self._client = client
        self.stored = AsyncStoredCliClient(client)
        self.jobs = AsyncCliJobsClient(client)

    async def run(
        self,
        code_zip: CodeZip,
        command: str,
        env_vars: EnvVars | dict | None = None,
        data_zip: DataZip | None = None,
        timeout: float | None = None,
    ) -> Job:
        """Starts a CLI job from code zip.

        Args:
            code_zip (CodeZip): The code zip.
            command (str): The command to run.
            env_vars (EnvVars | dict | None): Optional environment variables.
            data_zip (DataZip | None): Optional data zip.
            timeout (float | None): The timeout for the job.

        Returns:
            Job: The created job.

        Raises:
            HTTPException: If the request fails.
        """
        url = f"{self._client.base_url}/jobs/code/run/cli"

        files = self._client._prepare_files(code_zip=code_zip, data_zip=data_zip)
        data = {"command": command}
        if env_vars:
            data["env_vars"] = EnvVars(env_vars).json_str
        params = {"timeout": timeout} if timeout else {}

        async with httpx.AsyncClient() as client:
            try:
                response = await client.post(
                    url,
                    headers=self._client.api_key_header,
                    files=files or None,
                    data=data,
                    params=params,
                )
                response.raise_for_status()
                return Job(**response.json())
            except httpx.HTTPStatusError as e:
                raise self._client._get_http_exception(httpx_error=e)

    async def upload(
        self,
        code_zip: CodeZip,
        code_name: str,
        metadata: JsonData | dict | None = None,
    ) -> str:
        """Upload CLI code.

        Args:
            code_zip (CodeZip): The code zip.
            code_name (str): The name of the code.
            metadata (JsonData | dict | None): The JSON metadata of the code.

        Returns:
            str: The code ID.
        """
        return await self._client.code.upload(
            code_zip=code_zip,
            code_name=code_name,
            code_type=CodeType.CLI,
            metadata=metadata,
        )

    async def ingest(
        self,
        code_zip: CodeZip,
        code_name: str,
        metadata: JsonData | dict | None = None,
        build_pexenv: bool = False,
        pexenv_python: str | None = None,
    ) -> Job:
        """Ingest CLI code.

        Args:
            code_zip (CodeZip): The code zip.
            code_name (str): The name of the code.
            metadata (JsonData | dict | None): The JSON metadata of the code.
            build_pexenv (bool): Whether to build the pex venv.
            pexenv_python: (str | None): Python interpreter for the pex venv.

        Returns:
            Job: The code ingestion job.
        """
        return await self._client.code.ingest(
            code_zip=code_zip,
            code_name=code_name,
            code_type=CodeType.CLI,
            metadata=metadata,
            build_pexenv=build_pexenv,
            pexenv_python=pexenv_python,
        )
