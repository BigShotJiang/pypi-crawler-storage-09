from __future__ import annotations

import json
import socket
from abc import ABC
from io import BytesIO
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import httpx
from fastapi import HTTPException

from codeapi.client._utils import write_bytes, write_bytes_async
from codeapi.types import API_KEY_HEADER, CodeAPIError, CodeAPIException, JsonData


class ClientBase(ABC):
    def __init__(self, base_url: str, api_key: str = ""):
        """Initializes the CodeAPI Client.

        Args:
            base_url (str): The base URL of the CodeAPI.
            api_key (str): The CodeAPI key.
        """
        parsed_url = urlparse(base_url)
        self.protocol = parsed_url.scheme
        if parsed_url.hostname == "0.0.0.0":
            self.host = "localhost"
        else:
            try:
                self.host = socket.gethostbyaddr(str(parsed_url.hostname))[0]
            except Exception:
                self.host = str(parsed_url.hostname)
        self.port = parsed_url.port
        self.base_url = f"{self.protocol}://{self.host}:{self.port}"
        self.api_key = api_key

    @property
    def api_key_header(self) -> dict[str, str]:
        return {API_KEY_HEADER: self.api_key}

    def _get_response_detail(self, response: httpx.Response) -> str | None:
        try:
            return response.json()["detail"]
        except Exception:
            return None

    def _get_http_exception(
        self, httpx_error: httpx.HTTPStatusError
    ) -> HTTPException | CodeAPIException:
        status_code = httpx_error.response.status_code
        detail = httpx_error.response.json()["detail"]
        if isinstance(detail, dict) and detail.keys() == set(["error", "message"]):
            return CodeAPIException(
                error=CodeAPIError(detail["error"]), message=detail["message"]
            )
        return HTTPException(status_code=status_code, detail=detail)

    def get_proxy_url(self, job_id: str):
        return f"{self.base_url}/{job_id}"

    def get_subdomain_proxy_url(self, job_id: str):
        return f"{self.protocol}://{job_id.lower()}.{self.host}:{self.port}"

    def _prepare_files(self, **kwargs: Any) -> dict[str, tuple[str, BytesIO, str]]:
        """Prepare files for multipart upload."""
        files = {}
        for key, value in kwargs.items():
            if value is not None:
                if key.endswith("_zip"):
                    name = f"{key.replace('_zip', '')}.zip"
                    files[f"{key}file"] = (name, value.to_bytesio(), "application/zip")
                elif key == "metadata":
                    files["metadata"] = (
                        "metadata.json",
                        JsonData(value).to_bytesio(),
                        "application/json",
                    )
        return files

    def _handle_stream_download(
        self, response: httpx.Response, zip_path: Path | str | None = None
    ) -> bytes:
        """Handle streaming download with optional file saving."""
        mem_bytes = BytesIO()
        try:
            for chunk in response.iter_bytes():
                mem_bytes.write(chunk)
            if response.is_error:
                error_content = mem_bytes.getvalue().decode()
                detail = json.loads(error_content)["detail"]
                raise HTTPException(status_code=response.status_code, detail=detail)
            zip_bytes = mem_bytes.getvalue()
            if zip_path:
                write_bytes(path=zip_path, data=zip_bytes)
            return zip_bytes
        finally:
            mem_bytes.close()

    async def _handle_stream_download_async(
        self, response: httpx.Response, zip_path: Path | str | None = None
    ) -> bytes:
        """Handle streaming download with optional file saving."""
        mem_bytes = BytesIO()
        try:
            async for chunk in response.aiter_bytes():
                mem_bytes.write(chunk)
            if response.is_error:
                error_content = mem_bytes.getvalue().decode()
                detail = json.loads(error_content)["detail"]
                raise HTTPException(status_code=response.status_code, detail=detail)
            zip_bytes = mem_bytes.getvalue()
            if zip_path:
                await write_bytes_async(path=zip_path, data=zip_bytes)
            return zip_bytes
        finally:
            mem_bytes.close()
