from __future__ import annotations

from typing import TYPE_CHECKING, Any, List

import httpx

from codeapi.types import (
    CodeInfo,
    CodeType,
    CodeZip,
    DataZip,
    EnvVars,
    Job,
    JobStage,
    JobStatus,
    JobType,
    JsonData,
)

if TYPE_CHECKING:
    from . import Client


class StoredAppClient:
    def __init__(self, client: Client):
        self._client = client

    def run(
        self,
        code_id: str,
        app_name: str,
        env_vars: EnvVars | dict | None = None,
        data_zip: DataZip | None = None,
    ) -> Job:
        """Runs a stored APP.

        Args:
            code_id (str): The code ID.
            app_name (str): The name of the APP.
            env_vars (EnvVars | dict | None): Optional environment variables.
            data_zip (DataZip | None): Optional data zip file.

        Returns:
            Job: The created job.

        Raises:
            HTTPException: If the request fails.
        """
        url = f"{self._client.base_url}/jobs/code/{code_id}/run/app"

        files = self._client._prepare_files(data_zip=data_zip)
        data: dict[str, Any] = {"app_name": app_name}
        if env_vars:
            data["env_vars"] = EnvVars(env_vars).json_str

        try:
            response = httpx.post(
                url,
                headers=self._client.api_key_header,
                files=files if files else None,
                data=data,
            )
            response.raise_for_status()
            return Job(**response.json())
        except httpx.HTTPStatusError as e:
            raise self._client._get_http_exception(httpx_error=e)

    def list_info(self) -> list[CodeInfo]:
        """List all stored APP code.

        Returns:
            list[CodeInfo]: List of APP code info.
        """
        return self._client.code.list_info(code_type=CodeType.APP)

    def delete(self, code_id: str) -> str:
        """Delete stored APP code.

        Args:
            code_id (str): The code ID to delete.

        Returns:
            str: Deletion confirmation message.

        Raises:
            ValueError: If the code_id is not APP code.
        """
        # Verify this is actually APP code
        code_info = self._client.code.get_info(code_id)
        if code_info.code_type != CodeType.APP:
            raise ValueError(
                f"Code '{code_id}' is {code_info.code_type}, not APP code. "
                "Cannot delete non-APP code from APP client."
            )

        return self._client.code.delete(code_id)


class AppJobsClient:
    def __init__(self, client):
        self._client = client

    def list(
        self,
        job_status: JobStatus | None = None,
        job_stage: JobStage | None = None,
    ) -> List[Job]:
        """List APP jobs.

        Args:
            job_status (JobStatus | None): Filter by job status.
            job_stage (JobStage | None): Filter by job stage.

        Returns:
            list[Job]: List of APP jobs.
        """
        return self._client.jobs.list(
            job_type=JobType.RUN_APP,
            job_status=job_status,
            job_stage=job_stage,
        )

    def get_latest(self) -> Job | None:
        """Get the most recent APP job.

        Returns:
            Job | None: The most recent APP job, or None if no jobs exist.
        """
        jobs = self.list()
        return jobs[0] if jobs else None

    def list_queued(self) -> List[Job]:
        """Get all queued APP jobs.

        Returns:
            List[Job]: List of queued APP jobs.
        """
        return self.list(job_status=JobStatus.QUEUED)

    def list_scheduled(self) -> List[Job]:
        """Get all scheduled APP jobs.

        Returns:
            List[Job]: List of scheduled APP jobs.
        """
        return self.list(job_status=JobStatus.SCHEDULED)

    def list_started(self) -> List[Job]:
        """Get all started APP jobs.

        Returns:
            list[Job]: List of started APP jobs.
        """
        return self.list(job_status=JobStatus.STARTED)

    def list_deferred(self) -> List[Job]:
        """Get all deferred APP jobs.

        Returns:
            List[Job]: List of deferred APP jobs.
        """
        return self.list(job_status=JobStatus.DEFERRED)

    def list_canceled(self) -> List[Job]:
        """Get all canceled APP jobs.

        Returns:
            List[Job]: List of canceled APP jobs.
        """
        return self.list(job_status=JobStatus.CANCELED)

    def list_stopped(self) -> List[Job]:
        """Get all stopped APP jobs.

        Returns:
            List[Job]: List of stopped APP jobs.
        """
        return self.list(job_status=JobStatus.STOPPED)

    def list_failed(self) -> List[Job]:
        """Get all failed APP jobs.

        Returns:
            list[Job]: List of failed APP jobs.
        """
        return self.list(job_status=JobStatus.FAILED)

    def list_finished(self) -> List[Job]:
        """Get all finished APP jobs.

        Returns:
            list[Job]: List of finished APP jobs.
        """
        return self.list(job_status=JobStatus.FINISHED)

    def list_timed_out(self) -> List[Job]:
        """Get all timed out APP jobs.

        Returns:
            List[Job]: List of timed out APP jobs.
        """
        return self.list(job_status=JobStatus.TIMEOUT)

    def list_pre_running(self) -> List[Job]:
        """Get all pre-running APP jobs.

        Returns:
            List[Job]: List of pre-running APP jobs.
        """
        return self.list(job_stage=JobStage.PRE_RUNNING)

    def list_running(self) -> List[Job]:
        """Get all running APP jobs.

        Returns:
            List[Job]: List of running APP jobs.
        """
        return self.list(job_stage=JobStage.RUNNING)

    def list_post_running(self) -> List[Job]:
        """Get all post-running APP jobs.

        Returns:
            List[Job]: List of post-running APP jobs.
        """
        return self.list(job_stage=JobStage.POST_RUNNING)


class AppClient:
    def __init__(self, client: Client):
        self._client = client
        self.stored = StoredAppClient(client)
        self.jobs = AppJobsClient(client)

    def run(
        self,
        code_zip: CodeZip,
        app_name: str,
        env_vars: EnvVars | dict | None = None,
        data_zip: DataZip | None = None,
    ) -> Job:
        """Runs an APP from code zip.

        Args:
            code_zip (CodeZip): The code zip.
            app_name (str): The name of the APP.
            env_vars (EnvVars | dict | None): Optional environment variables.
            data_zip (DataZip | None): Optional data zip file.

        Returns:
            Job: The created job.

        Raises:
            HTTPException: If the request fails.
        """
        url = f"{self._client.base_url}/jobs/code/run/app"

        files = self._client._prepare_files(code_zip=code_zip, data_zip=data_zip)
        data: dict[str, Any] = {"app_name": app_name}
        if env_vars:
            data["env_vars"] = EnvVars(env_vars).json_str

        try:
            response = httpx.post(
                url,
                headers=self._client.api_key_header,
                files=files,
                data=data,
            )
            response.raise_for_status()
            return Job(**response.json())
        except httpx.HTTPStatusError as e:
            raise self._client._get_http_exception(httpx_error=e)

    def is_healthy(self, job_id: str) -> bool:
        """Checks whether launched APP is healthy.

        Args:
            job_id (str): The ID of the APP launch job.

        Returns:
            bool: True if APP is healthy else False.

        Raises:
            HTTPException: If the request fails.
        """
        return self._client.jobs.is_healthy(job_id=job_id)

    def await_healthy(self, job_id: str, timeout: float | None = None) -> Job:
        """Waits for a custom APP to become healthy.

        Args:
            job_id (str): The ID of the custom APP run job.
            timeout (float | None): Maximum time to wait in seconds. If None, waits indefinitely.

        Returns:
            Job: The job object of the APP run job.

        Raises:
            HTTPException: If the request fails.
            APIException: If the job enters stage POST_RUNNING unexpectedly.
            TimeoutError: If the timeout is exceeded.
        """
        return self._client.jobs.await_healthy(job_id=job_id, timeout=timeout)

    def get_url(self, job_id: str) -> str:
        """Gets the URL for an APP.

        Args:
            job_id (str): The job ID.

        Returns:
            str: The APP URL.
        """
        return self._client.get_proxy_url(job_id)

    def upload(
        self,
        code_zip: CodeZip,
        code_name: str,
        metadata: JsonData | dict | None = None,
    ) -> str:
        """Upload APP code.

        Args:
            code_zip (CodeZip): The code zip.
            code_name (str): The name of the code.
            metadata (JsonData | dict | None): The JSON metadata of the code.

        Returns:
            str: The code ID.
        """
        return self._client.code.upload(
            code_zip=code_zip,
            code_name=code_name,
            code_type=CodeType.APP,
            metadata=metadata,
        )

    def ingest(
        self,
        code_zip: CodeZip,
        code_name: str,
        metadata: JsonData | dict | None = None,
        build_pexenv: bool = False,
        pexenv_python: str | None = None,
    ) -> Job:
        """Ingest APP code.

        Args:
            code_zip (CodeZip): The code zip.
            code_name (str): The name of the code.
            metadata (JsonData | dict | None): The JSON metadata of the code.
            build_pexenv (bool): Whether to build the pex venv.
            pexenv_python: (str | None): Python interpreter for the pex venv.

        Returns:
            Job: The code ingestion job.
        """
        return self._client.code.ingest(
            code_zip=code_zip,
            code_name=code_name,
            code_type=CodeType.APP,
            metadata=metadata,
            build_pexenv=build_pexenv,
            pexenv_python=pexenv_python,
        )
