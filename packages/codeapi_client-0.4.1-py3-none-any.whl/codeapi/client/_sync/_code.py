from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

import httpx

from codeapi.types import CodeInfo, CodeType, CodeZip, Job, JsonData

if TYPE_CHECKING:
    from . import Client


class CodeClient:
    def __init__(self, client: Client):
        self._client = client

    def upload(
        self,
        code_zip: CodeZip,
        code_name: str,
        code_type: CodeType,
        metadata: JsonData | dict | None = None,
    ) -> str:
        """Upload code.

        Args:
            code_zip (CodeZip): The code zip.
            code_name (str): The name of the code.
            code_type (CodeType): The type of the code.
            metadata (JsonData | dict | None): The JSON metadata of the code.

        Returns:
            str: The code ID.

        Raises:
            HTTPException: If the request fails.
        """
        url = f"{self._client.base_url}/code/upload"

        files = self._client._prepare_files(code_zip=code_zip, metadata=metadata)
        data = {"code_name": code_name, "code_type": code_type}

        try:
            response = httpx.post(
                url, headers=self._client.api_key_header, files=files, data=data
            )
            response.raise_for_status()
            return str(response.json()).strip()
        except httpx.HTTPStatusError as e:
            raise self._client._get_http_exception(httpx_error=e)

    def download(self, code_id: str, zip_path: Path | str | None = None) -> CodeZip:
        """Download code and optionally saves it to a file.

        Args:
            code_id (str): The code ID.
            zip_path (Path | str | None): The path to save the code zip file to.

        Returns:
            CodeZip: The downloaded code zip.

        Raises:
            HTTPException: If the request fails.
        """
        url = f"{self._client.base_url}/code/{code_id}/download"

        try:
            with httpx.stream(
                "GET", url, headers=self._client.api_key_header
            ) as response:
                zip_bytes = self._client._handle_stream_download(response, zip_path)
        except httpx.HTTPStatusError as e:
            raise self._client._get_http_exception(httpx_error=e)

        return CodeZip(zip_bytes=zip_bytes)

    def delete(self, code_id: str) -> str:
        """Deletes code by code_id.

        Args:
            code_id (str): The code ID.

        Returns:
            str: Confirmation message.

        Raises:
            HTTPException: If the request fails.
        """
        url = f"{self._client.base_url}/code/{code_id}"
        try:
            response = httpx.delete(url, headers=self._client.api_key_header)
            response.raise_for_status()
            return f"Code with id={code_id} deleted"
        except httpx.HTTPStatusError as e:
            raise self._client._get_http_exception(httpx_error=e)

    def get_info(self, code_id: str) -> CodeInfo:
        """Gets the code info.

        Args:
            code_id (str): The code ID.

        Returns:
            CodeInfo: The code info.

        Raises:
            HTTPException: If the request fails.
        """
        url = f"{self._client.base_url}/code/{code_id}/info"
        try:
            response = httpx.get(url, headers=self._client.api_key_header)
            response.raise_for_status()
            return CodeInfo(**response.json())
        except httpx.HTTPStatusError as e:
            raise self._client._get_http_exception(httpx_error=e)

    def list_info(self, code_type: CodeType | None = None) -> list[CodeInfo]:
        """Gets list of code infos.

        Args:
            code_type (CodeType | None): The type of code to list.

        Returns:
            list[CodeInfo]: The list of code infos.

        Raises:
            HTTPException: If the request fails.
        """
        url = f"{self._client.base_url}/code/info"
        try:
            params = {"code_type": code_type} if code_type else None
            response = httpx.get(
                url, headers=self._client.api_key_header, params=params
            )
            response.raise_for_status()
            return [CodeInfo(**item) for item in response.json()]
        except httpx.HTTPStatusError as e:
            raise self._client._get_http_exception(httpx_error=e)

    def get_metadata(self, code_id: str) -> JsonData:
        """Gets code metadata.

        Args:
            code_id (str): The ID of the code.

        Returns:
            JsonData: The metadata.

        Raises:
            HTTPException: If the request fails.
        """
        url = f"{self._client.base_url}/code/{code_id}/metadata"
        try:
            response = httpx.get(url, headers=self._client.api_key_header)
            response.raise_for_status()
            return JsonData(response.json())
        except httpx.HTTPStatusError as e:
            raise self._client._get_http_exception(httpx_error=e)

    def ingest(
        self,
        code_zip: CodeZip,
        code_name: str,
        code_type: CodeType,
        metadata: JsonData | dict | None = None,
        build_pexenv: bool = False,
        pexenv_python: str | None = None,
    ) -> Job:
        """Starts a code ingestion job.

        Args:
            code_zip (CodeZip): The code zip.
            code_name (str): The name of the code.
            code_type (CodeType): The type of the code.
            metadata (JsonData | dict | None): The JSON metadata of the code.
            build_pexenv (bool): Whether to build the pex venv.
            pexenv_python: (str | None): Python interpreter for the pex venv.

        Returns:
            Job: The code ingestion job.

        Raises:
            HTTPException: If the request fails.
        """
        url = f"{self._client.base_url}/jobs/code/ingest"

        files = self._client._prepare_files(code_zip=code_zip, metadata=metadata)
        data = {
            "code_name": code_name,
            "code_type": code_type,
            "build_pexenv": build_pexenv,
            "pexenv_python": pexenv_python,
        }

        try:
            response = httpx.post(
                url, headers=self._client.api_key_header, files=files, data=data
            )
            response.raise_for_status()
            return Job(**response.json())
        except httpx.HTTPStatusError as e:
            raise self._client._get_http_exception(httpx_error=e)
