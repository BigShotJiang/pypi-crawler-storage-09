from __future__ import annotations

from typing import TYPE_CHECKING, List

import httpx

if TYPE_CHECKING:
    from . import Client
from codeapi.types import (
    CodeInfo,
    CodeType,
    CodeZip,
    Job,
    JobStage,
    JobStatus,
    JobType,
    JsonData,
)


class StoredWebClient:
    def __init__(self, client: Client):
        self._client = client

    def run(
        self,
        code_id: str,
    ) -> Job:
        """Runs a stored Web page.

        Args:
            code_id (str): The code ID.

        Returns:
            Job: The created job.

        Raises:
            HTTPException: If the request fails.
        """
        url = f"{self._client.base_url}/jobs/code/{code_id}/run/web"

        try:
            response = httpx.post(
                url,
                headers=self._client.api_key_header,
            )
            response.raise_for_status()
            return Job(**response.json())
        except httpx.HTTPStatusError as e:
            raise self._client._get_http_exception(httpx_error=e)

    def list_info(self) -> list[CodeInfo]:
        """List all stored Web code.

        Returns:
            list[CodeInfo]: List of Web code info.
        """
        return self._client.code.list_info(code_type=CodeType.WEB)

    def delete(self, code_id: str) -> str:
        """Delete stored Web code.

        Args:
            code_id (str): The code ID to delete.

        Returns:
            str: Deletion confirmation message.

        Raises:
            ValueError: If the code_id is not Web code.
        """
        # Verify this is actually Web code
        code_info = self._client.code.get_info(code_id)
        if code_info.code_type != CodeType.WEB:
            raise ValueError(
                f"Code '{code_id}' is {code_info.code_type}, not Web code. "
                "Cannot delete non-Web code from Web client."
            )

        return self._client.code.delete(code_id)


class WebJobsClient:
    def __init__(self, client):
        self._client = client

    def list(
        self,
        job_status: JobStatus | None = None,
        job_stage: JobStage | None = None,
    ) -> List[Job]:
        """List Web jobs.

        Args:
            job_status (JobStatus | None): Filter by job status.
            job_stage (JobStage | None): Filter by job stage.

        Returns:
            list[Job]: List of Web jobs.
        """
        return self._client.jobs.list(
            job_type=JobType.RUN_WEB,
            job_status=job_status,
            job_stage=job_stage,
        )

    def get_latest(self) -> Job | None:
        """Get the most recent Web job.

        Returns:
            Job | None: The most recent Web job, or None if no jobs exist.
        """
        jobs = self.list()
        return jobs[0] if jobs else None

    def list_queued(self) -> List[Job]:
        """Get all queued Web jobs.

        Returns:
            List[Job]: List of queued Web jobs.
        """
        return self.list(job_status=JobStatus.QUEUED)

    def list_scheduled(self) -> List[Job]:
        """Get all scheduled Web jobs.

        Returns:
            List[Job]: List of scheduled Web jobs.
        """
        return self.list(job_status=JobStatus.SCHEDULED)

    def list_started(self) -> List[Job]:
        """Get all started Web jobs.

        Returns:
            list[Job]: List of started Web jobs.
        """
        return self.list(job_status=JobStatus.STARTED)

    def list_deferred(self) -> List[Job]:
        """Get all deferred Web jobs.

        Returns:
            List[Job]: List of deferred Web jobs.
        """
        return self.list(job_status=JobStatus.DEFERRED)

    def list_canceled(self) -> List[Job]:
        """Get all canceled Web jobs.

        Returns:
            List[Job]: List of canceled Web jobs.
        """
        return self.list(job_status=JobStatus.CANCELED)

    def list_stopped(self) -> List[Job]:
        """Get all stopped Web jobs.

        Returns:
            List[Job]: List of stopped Web jobs.
        """
        return self.list(job_status=JobStatus.STOPPED)

    def list_failed(self) -> List[Job]:
        """Get all failed Web jobs.

        Returns:
            list[Job]: List of failed Web jobs.
        """
        return self.list(job_status=JobStatus.FAILED)

    def list_finished(self) -> List[Job]:
        """Get all finished Web jobs.

        Returns:
            list[Job]: List of finished Web jobs.
        """
        return self.list(job_status=JobStatus.FINISHED)

    def list_timed_out(self) -> List[Job]:
        """Get all timed out Web jobs.

        Returns:
            List[Job]: List of timed out Web jobs.
        """
        return self.list(job_status=JobStatus.TIMEOUT)

    def list_pre_running(self) -> List[Job]:
        """Get all pre-running Web jobs.

        Returns:
            List[Job]: List of pre-running Web jobs.
        """
        return self.list(job_stage=JobStage.PRE_RUNNING)

    def list_running(self) -> List[Job]:
        """Get all running Web jobs.

        Returns:
            List[Job]: List of running Web jobs.
        """
        return self.list(job_stage=JobStage.RUNNING)

    def list_post_running(self) -> List[Job]:
        """Get all post-running Web jobs.

        Returns:
            List[Job]: List of post-running Web jobs.
        """
        return self.list(job_stage=JobStage.POST_RUNNING)


class WebClient:
    def __init__(self, client: Client):
        self._client = client
        self.stored = StoredWebClient(client)
        self.jobs = WebJobsClient(client)

    def run(
        self,
        code_zip: CodeZip,
    ) -> Job:
        """Runs a Web page from code zip.

        Args:
            code_zip (CodeZip): The code zip.

        Returns:
            Job: The created job.

        Raises:
            HTTPException: If the request fails.
        """
        url = f"{self._client.base_url}/jobs/code/run/web"

        files = self._client._prepare_files(code_zip=code_zip)

        try:
            response = httpx.post(
                url,
                headers=self._client.api_key_header,
                files=files,
            )
            response.raise_for_status()
            return Job(**response.json())
        except httpx.HTTPStatusError as e:
            raise self._client._get_http_exception(httpx_error=e)

    def get_url(self, job_id: str) -> str:
        """Gets the URL for a Web page.

        Args:
            job_id (str): The job ID.

        Returns:
            str: The Web page URL.
        """
        return self._client.get_subdomain_proxy_url(job_id)

    def upload(
        self,
        code_zip: CodeZip,
        code_name: str,
        metadata: JsonData | dict | None = None,
    ) -> str:
        """Upload Web code.

        Args:
            code_zip (CodeZip): The code zip.
            code_name (str): The name of the code.
            metadata (JsonData | dict | None): The JSON metadata of the code.

        Returns:
            str: The code ID.
        """
        return self._client.code.upload(
            code_zip=code_zip,
            code_name=code_name,
            code_type=CodeType.WEB,
            metadata=metadata,
        )

    def is_healthy(self, job_id: str) -> bool:
        """Checks whether launched Web page is healthy.

        Args:
            job_id (str): The ID of the Web page launch job.

        Returns:
            bool: True if Web page is healthy else False.

        Raises:
            HTTPException: If the request fails.
        """
        return self._client.jobs.is_healthy(job_id=job_id)

    def await_healthy(self, job_id: str, timeout: float | None = None) -> Job:
        """Waits for a Web page to become healthy.

        Args:
            job_id (str): The ID of the Web page run job.
            timeout (float | None): Maximum time to wait in seconds. If None, waits indefinitely.

        Returns:
            Job: The job object of the Web page run job.

        Raises:
            HTTPException: If the request fails.
            APIException: If the job enters stage POST_RUNNING unexpectedly.
            TimeoutError: If the timeout is exceeded.
        """
        return self._client.jobs.await_healthy(job_id=job_id, timeout=timeout)

    def ingest(
        self,
        code_zip: CodeZip,
        code_name: str,
        metadata: JsonData | dict | None = None,
        build_pexenv: bool = False,
        pexenv_python: str | None = None,
    ) -> Job:
        """Ingest Web code.

        Args:
            code_zip (CodeZip): The code zip.
            code_name (str): The name of the code.
            metadata (JsonData | dict | None): The JSON metadata of the code.
            build_pexenv (bool): Whether to build the pex venv.
            pexenv_python: (str | None): Python interpreter for the pex venv.

        Returns:
            Job: The code ingestion job.
        """
        return self._client.code.ingest(
            code_zip=code_zip,
            code_name=code_name,
            code_type=CodeType.WEB,
            metadata=metadata,
            build_pexenv=build_pexenv,
            pexenv_python=pexenv_python,
        )
