import os
from pathlib import Path

import aiofiles


def get_file_dir(filepath: Path | str) -> str:
    return str(Path(filepath).parent)


def get_filename(filepath: Path | str) -> str:
    return Path(filepath).name


def file_exists(path: Path | str) -> bool:
    return os.path.isfile(path)


def read_file(path: Path | str) -> str:
    return Path(path).read_text()


async def read_file_async(path: Path | str) -> str:
    async with aiofiles.open(path, mode="r") as f:
        return await f.read()


def read_bytes(path: Path | str) -> bytes:
    return Path(path).read_bytes()


async def read_bytes_async(path: Path | str) -> bytes:
    async with aiofiles.open(path, mode="rb") as f:
        return await f.read()


def read_lines(path: Path | str) -> list[str]:
    return read_file(path=path).splitlines()


async def read_lines_async(path: Path | str) -> list[str]:
    content = await read_file_async(path)
    return content.splitlines()


def write_file(path: Path | str, data: str) -> None:
    Path(path).write_text(data=data)


async def write_file_async(path: Path | str, data: str) -> None:
    async with aiofiles.open(path, "w") as f:
        await f.write(data)


def write_bytes(path: Path | str, data: bytes) -> None:
    Path(path).write_bytes(data=data)


async def write_bytes_async(path: Path | str, data: bytes) -> None:
    async with aiofiles.open(path, "wb") as f:
        await f.write(data)
