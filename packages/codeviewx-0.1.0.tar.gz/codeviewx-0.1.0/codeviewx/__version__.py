"""Version information"""

__version__ = "0.1.0"
__author__ = "CodeViewX Team"
__description__ = "AI-Driven Code Documentation Generator"

