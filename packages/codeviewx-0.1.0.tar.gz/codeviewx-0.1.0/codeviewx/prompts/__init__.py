"""CodeViewX prompts module

Prompts are stored as package resources and accessed via the load_prompt function.
"""

