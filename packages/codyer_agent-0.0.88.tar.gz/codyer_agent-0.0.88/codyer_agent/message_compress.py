
COMPRESS_PROMPT = f"""
对前面的内容进行详细总结。
"""