# Steps (pure, testable functions)
