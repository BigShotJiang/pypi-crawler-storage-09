"""Minimal Vigil starter application."""
