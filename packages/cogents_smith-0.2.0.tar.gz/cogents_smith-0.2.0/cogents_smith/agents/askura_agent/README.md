# Askura Agent

A dynamic agent to collect target semi-structured information via conversation. The agent adapts to user communication styles and maintains conversation purpose alignment.