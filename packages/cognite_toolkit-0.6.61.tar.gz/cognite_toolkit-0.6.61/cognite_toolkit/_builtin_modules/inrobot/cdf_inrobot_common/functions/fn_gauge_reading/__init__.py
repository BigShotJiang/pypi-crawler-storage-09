"""Gauge reader."""
