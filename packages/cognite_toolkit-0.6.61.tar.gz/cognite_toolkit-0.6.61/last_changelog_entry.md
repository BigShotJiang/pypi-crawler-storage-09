## cdf 

### Improved

- Optimized logging of flags and plugins

## templates

No changes.