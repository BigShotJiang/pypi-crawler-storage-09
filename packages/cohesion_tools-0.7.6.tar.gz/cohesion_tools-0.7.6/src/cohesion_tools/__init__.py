from importlib.metadata import version

__version__ = version("cohesion_tools")

__all__ = [
    "__version__",
]
