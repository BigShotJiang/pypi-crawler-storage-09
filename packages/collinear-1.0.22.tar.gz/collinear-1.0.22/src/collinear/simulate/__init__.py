"""Collinear SDK simulation package."""
