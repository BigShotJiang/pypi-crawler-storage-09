"""Simulation integration tests."""
