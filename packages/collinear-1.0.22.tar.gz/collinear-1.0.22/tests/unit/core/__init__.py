"""Core package smoke tests."""
