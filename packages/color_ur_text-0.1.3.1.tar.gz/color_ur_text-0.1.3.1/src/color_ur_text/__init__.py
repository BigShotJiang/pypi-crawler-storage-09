# colored_text/__init__.py

from .colored_text import ColoredText

__all__ = ['ColoredText']
