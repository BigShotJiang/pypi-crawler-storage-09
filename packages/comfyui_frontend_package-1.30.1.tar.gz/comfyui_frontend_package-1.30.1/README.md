# comfyui_frontend pypi package

This is the pypi package structure for the comfyui frontend.

During build process, the compiled assets are copied into the `${PROJECT_ROOT}/comfyui_frontend_package/comfyui_frontend_package/static` directory.

The package can be installed with the following command:

```bash
pip install comfyui-frontend-package
```

Ref: <https://pypi.org/project/comfyui-frontend-package/>
