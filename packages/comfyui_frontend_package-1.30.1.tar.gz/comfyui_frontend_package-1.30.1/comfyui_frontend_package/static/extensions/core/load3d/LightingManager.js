// Shim for extensions/core/load3d/LightingManager.ts
export const LightingManager = window.comfyAPI.LightingManager.LightingManager;
