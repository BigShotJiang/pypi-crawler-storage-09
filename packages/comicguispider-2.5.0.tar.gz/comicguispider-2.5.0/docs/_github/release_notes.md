
## 🎁 Feat

✨ 小改，配置窗口换图且高清化  
✅ 优化线程进程相关实例再利用，显著提升内置重启  
🚧 重构数据格式以支持后续筛选过滤功能  

## 🐞 Fix

✖️ jm 域名策略变化的关系，暂时关闭jm的读剪贴板/章节功能，等 [cloudscraper](https://github.com/VeNoMouS/cloudscraper/issues/285) 支持异步或找到解决方案后恢复..  
✅ 修复内置更新稳定性  
✅ 修复 jm 列表含5位数车号以下时报错  
