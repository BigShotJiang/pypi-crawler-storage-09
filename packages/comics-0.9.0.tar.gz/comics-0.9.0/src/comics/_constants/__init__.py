"""
comics/_constants
~~~~~~~~~~~~~~~~~
"""

from ._directory import directory
