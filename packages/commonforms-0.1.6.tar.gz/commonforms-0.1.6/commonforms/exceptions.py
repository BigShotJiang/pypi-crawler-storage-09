class EncryptedPdfError(Exception):
    pass
