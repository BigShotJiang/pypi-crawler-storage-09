from vng_api_common.scopes import Scope

SCOPE_AUDITTRAILS_LEZEN = Scope(
    "audittrails.lezen",
    description="""
**Laat toe om**:

* audittrails op te lijsten
* audittrail details op te vragen
""",
)
