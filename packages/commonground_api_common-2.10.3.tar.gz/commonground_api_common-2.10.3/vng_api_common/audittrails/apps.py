from django.apps import AppConfig


class AudittrailConfig(AppConfig):
    name = "vng_api_common.audittrails"
