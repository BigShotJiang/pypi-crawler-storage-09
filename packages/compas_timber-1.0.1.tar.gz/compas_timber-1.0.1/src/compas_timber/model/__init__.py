from .model import TimberModel

__all__ = ["TimberModel"]
