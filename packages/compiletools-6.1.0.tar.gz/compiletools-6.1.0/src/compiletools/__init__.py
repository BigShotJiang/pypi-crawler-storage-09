""" The compiletools module provides all the infrastructure 
    for tracing header dependencies and gathering together of files 
    to create an executable or library.
"""
from compiletools.version import __version__ as __version__
