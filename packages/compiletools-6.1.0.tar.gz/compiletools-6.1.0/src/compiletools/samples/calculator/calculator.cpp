#include "calculator.h"
#include "add.H"

// Simple calculator function implementation
int calculate(int a, int b)
{
    return add_numbers(a, b);
}