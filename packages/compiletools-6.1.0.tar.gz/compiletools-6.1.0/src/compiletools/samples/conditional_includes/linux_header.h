// Linux-specific header
void linux_function(void);