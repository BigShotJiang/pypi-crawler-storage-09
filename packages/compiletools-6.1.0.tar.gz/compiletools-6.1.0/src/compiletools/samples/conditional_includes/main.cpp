#ifdef __linux__
#include "linux_header.h"
#else  
#include "windows_header.h"
#endif

int main() {
    return 0;
}