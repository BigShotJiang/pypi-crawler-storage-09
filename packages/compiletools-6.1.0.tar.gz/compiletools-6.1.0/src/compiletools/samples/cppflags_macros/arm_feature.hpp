#ifndef ARM_FEATURE_HPP
#define ARM_FEATURE_HPP
// ARM 32-bit architecture-specific feature
#endif