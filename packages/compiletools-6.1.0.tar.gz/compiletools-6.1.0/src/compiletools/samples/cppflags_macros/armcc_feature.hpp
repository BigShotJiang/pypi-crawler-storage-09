#ifndef ARMCC_FEATURE_HPP
#define ARMCC_FEATURE_HPP
// ARM Compiler specific feature
#endif