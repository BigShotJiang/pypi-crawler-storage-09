// Basic feature implementation
#ifndef BASIC_FEATURE_HPP
#define BASIC_FEATURE_HPP
// Basic functionality
#endif