#ifndef COMBINED_FEATURES_HPP
#define COMBINED_FEATURES_HPP
// Feature requiring both FEATURE_A and FEATURE_B
#endif