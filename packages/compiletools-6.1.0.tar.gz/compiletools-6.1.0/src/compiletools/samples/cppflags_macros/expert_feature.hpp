#ifndef EXPERT_FEATURE_HPP
#define EXPERT_FEATURE_HPP
// Expert-level features for advanced users
class ExpertFeature {
public:
    void enable_expert_mode();
};
#endif