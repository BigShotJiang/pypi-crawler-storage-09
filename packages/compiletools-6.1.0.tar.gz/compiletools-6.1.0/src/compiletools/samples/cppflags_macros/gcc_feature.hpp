#ifndef GCC_FEATURE_HPP
#define GCC_FEATURE_HPP
// GCC-specific feature
#endif