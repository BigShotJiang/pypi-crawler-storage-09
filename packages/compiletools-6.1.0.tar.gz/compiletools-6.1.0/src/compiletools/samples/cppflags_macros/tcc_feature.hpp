#ifndef TCC_FEATURE_HPP
#define TCC_FEATURE_HPP
// TCC-specific feature
#endif