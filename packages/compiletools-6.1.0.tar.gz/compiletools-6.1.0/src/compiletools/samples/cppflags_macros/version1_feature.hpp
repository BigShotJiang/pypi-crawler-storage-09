#ifndef VERSION1_FEATURE_HPP
#define VERSION1_FEATURE_HPP
// Version 1 specific feature
#endif