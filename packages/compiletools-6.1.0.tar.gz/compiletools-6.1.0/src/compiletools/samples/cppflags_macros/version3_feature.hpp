#ifndef VERSION3_FEATURE_HPP
#define VERSION3_FEATURE_HPP
// Version 3 specific feature
#endif