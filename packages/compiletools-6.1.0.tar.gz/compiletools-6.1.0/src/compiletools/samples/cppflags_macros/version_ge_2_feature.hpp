#ifndef VERSION_GE_2_FEATURE_HPP
#define VERSION_GE_2_FEATURE_HPP
// Feature for VERSION >= 2
#endif