#ifndef X86_64_FEATURE_HPP
#define X86_64_FEATURE_HPP
// x86_64 architecture-specific feature
#endif