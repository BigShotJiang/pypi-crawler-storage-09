#pragma once
#include <string>

struct Cross_Platform
{
    std::string hello_world() const;
    std::string name() const;
};
