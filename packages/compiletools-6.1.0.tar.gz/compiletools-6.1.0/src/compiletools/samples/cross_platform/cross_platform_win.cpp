#include "cross_platform.hpp"
#include <string>

std::string Cross_Platform::name() const
{
    return "win";
}
