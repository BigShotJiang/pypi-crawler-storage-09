#pragma once
#include "cycle_c.hpp"
#include <iostream>
#include "cycle_b.hpp"
#include "cycle_c.hpp"
