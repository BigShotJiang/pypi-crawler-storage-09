#pragma once

void render_frame();
void draw_scene();
