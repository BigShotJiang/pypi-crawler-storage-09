#pragma once
int get_int(void);
