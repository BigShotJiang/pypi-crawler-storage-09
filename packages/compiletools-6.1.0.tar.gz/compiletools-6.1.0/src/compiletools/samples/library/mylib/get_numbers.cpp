/*
 * A file to get cake to put get_double and get_int into one static library
 */

#include "get_numbers.hpp"
