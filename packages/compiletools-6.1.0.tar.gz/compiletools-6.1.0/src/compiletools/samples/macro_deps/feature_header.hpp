#ifdef USE_FEATURE_X
//#PKG-CONFIG=zlib
//#SOURCE=feature_x_impl.cpp
#endif

#ifdef USE_FEATURE_Y
//#PKG-CONFIG=libcrypt
//#SOURCE=feature_y_impl.cpp
#endif