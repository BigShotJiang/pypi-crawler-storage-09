#ifdef FEATURE_A_ENABLED
#define FEATURE_B_ENABLED
#endif

// This header defines macros that affect later conditional compilation