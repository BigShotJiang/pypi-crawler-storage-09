#ifdef FEATURE_B_ENABLED
#include "module_b.h"
#endif

#ifdef FEATURE_C_ENABLED  
#include "module_c.h"
#endif

// This header's includes depend on macros that may be polluted from previous analysis