#define FEATURE_A_ENABLED
// This macro gets defined during preprocessing and affects subsequent analysis

#include "config.h"
#include "core.h"

int main() {
    return 0;
}