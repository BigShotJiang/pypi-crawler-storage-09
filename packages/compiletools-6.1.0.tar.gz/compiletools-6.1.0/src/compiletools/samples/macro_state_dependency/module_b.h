// Module B header - should only be included when FEATURE_B_ENABLED is defined
void module_b_function();