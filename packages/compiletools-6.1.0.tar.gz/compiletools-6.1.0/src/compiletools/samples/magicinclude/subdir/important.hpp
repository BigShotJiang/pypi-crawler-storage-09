#pragma once
// Some important file to include
//#CPPFLAGS=-DMYMACRO=1
//#CXXFLAGS=-DMYMACRO2=2

int f()
{
    return 42;
}

