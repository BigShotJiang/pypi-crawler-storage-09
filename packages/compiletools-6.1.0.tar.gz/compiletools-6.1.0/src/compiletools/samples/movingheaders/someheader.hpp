#pragma once

inline void somefunc(){}
