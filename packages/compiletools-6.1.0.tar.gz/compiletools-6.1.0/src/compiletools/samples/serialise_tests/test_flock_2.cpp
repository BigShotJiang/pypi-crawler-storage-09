#include "createfile.hpp"
#include "obtainlock.hpp"

int main(int argc, char* argv[])
{
    create_file();
    obtainlock();
}
