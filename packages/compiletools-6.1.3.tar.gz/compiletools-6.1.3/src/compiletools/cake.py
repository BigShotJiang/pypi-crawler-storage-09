import signal
import sys
import subprocess
import os
import compiletools.utils
import compiletools.apptools
import compiletools.configutils
import compiletools.headerdeps
import compiletools.magicflags
import compiletools.hunter
import compiletools.makefile
import compiletools.filelist
import compiletools.findtargets
import compiletools.jobs
import compiletools.wrappedos
import compiletools.compilation_database



class Cake(object):
    def __init__(self, args):
        self.args = args
        self.namer = None
        self.headerdeps = None
        self.magicparser = None
        self.hunter = None

    @staticmethod
    def _hide_makefilename(args):
        """ Change the args.makefilename to hide the Makefile in the executable_dir()
            This is a callback function for the compiletools.apptools.substitutions.
        """
        namer = compiletools.namer.Namer(args)
        if namer.executable_dir() not in args.makefilename:
            movedmakefile = os.path.join(namer.executable_dir(), args.makefilename)
            if args.verbose > 4:
                print(
                    "Makefile location is being altered.  New location is {}".format(
                        movedmakefile
                    )
                )
            args.makefilename = movedmakefile

    @staticmethod
    def registercallback():
        """ Must be called before object creation so that the args parse
            correctly
        """
        compiletools.apptools.registercallback(Cake._hide_makefilename)

    def _createctobjs(self):
        """ Has to be separate because --auto fiddles with the args """
        self.namer = compiletools.namer.Namer(self.args)
        self.headerdeps = compiletools.headerdeps.create(self.args)
        self.magicparser = compiletools.magicflags.create(self.args, self.headerdeps)
        self.hunter = compiletools.hunter.Hunter(self.args, self.headerdeps, self.magicparser)

    @staticmethod
    def add_arguments(cap):
        compiletools.makefile.MakefileCreator.add_arguments(cap)
        compiletools.jobs.add_arguments(cap)

        cap.add(
            "--file-list",
            "--filelist",
            dest="filelist",
            action="store_true",
            help="Print list of referenced files.",
        )
        compiletools.filelist.Filelist.add_arguments(cap)  # To get the style arguments

        cap.add(
            "--begintests",
            dest="tests",
            nargs="*",
            help="Starts a test block. The cpp files following this declaration will generate executables which are then run. Synonym for --tests",
        )
        cap.add(
            "--endtests",
            action="store_true",
            help="Ignored. For backwards compatibility only.",
        )

        compiletools.findtargets.add_arguments(cap)

        compiletools.utils.add_flag_argument(
            parser=cap,
            name="compilation-database",
            dest="compilation_database",
            default=True,
            help="Generate compile_commands.json for clang tooling.",
        )
        
        cap.add(
            "--compilation-database-output",
            dest="compilation_database_output",
            default=None,
            help="Output filename for compilation database (default: <gitroot>/compile_commands.json)"
        )
        
        cap.add(
            "--compilation-database-relative-paths",
            dest="compilation_database_relative",
            action="store_true", 
            help="Use relative paths instead of absolute paths in compilation database"
        )

        compiletools.utils.add_boolean_argument(
            parser=cap,
            name="preprocess",
            default=False,
            help="Set both --magic=cpp and --headerdeps=cpp. Defaults to false because it is slower.",
        )

        cap.add(
            "--CAKE_PREPROCESS",
            dest="preprocess",
            default=False,
            help="Deprecated. Synonym for preprocess",
        )

        cap.add("--clean", action="store_true", help="Agressively cleanup.")

        cap.add(
            "-o",
            "--output",
            help="When there is only a single build product, rename it to this name.",
        )

    def _callfilelist(self):
        filelist = compiletools.filelist.Filelist(self.args, self.hunter, style="flat")
        filelist.process()

    def _call_compilation_database(self):
        """Generate compilation database if requested"""
        if not getattr(self.args, 'compilation_database', True):
            return
        if self.args.clean:
            return  # Don't generate compilation database during clean
            
        # Reuse existing objects to avoid duplicating work
        creator = compiletools.compilation_database.CompilationDatabaseCreator(
            self.args,
            namer=self.namer,
            headerdeps=self.headerdeps,
            magicparser=self.magicparser,
            hunter=self.hunter
        )
        creator.write_compilation_database()

    def _copyexes(self):
        # Copy the executables into the "bin" dir (as per cake)
        # Unless the user has changed the bindir (or set --output)
        # in which case assume that they know what they are doing
        if self.args.output:
            if self.args.verbose > 0:
                print(self.args.output)
            if self.args.filename:
                compiletools.wrappedos.copy(
                    self.namer.executable_pathname(self.args.filename[0]),
                    self.args.output,
                )
            if self.args.static:
                compiletools.wrappedos.copy(self.namer.staticlibrary_pathname(), self.args.output)
            if self.args.dynamic:
                compiletools.wrappedos.copy(
                    self.namer.dynamiclibrary_pathname(), self.args.output
                )
        else:
            outputdir = self.namer.topbindir()
            filelist = self.namer.all_executable_pathnames()
            for srcexe in filelist:
                base = os.path.basename(srcexe)
                destexe = compiletools.wrappedos.realpath(os.path.join(outputdir, base))
                if compiletools.utils.is_executable(srcexe) and srcexe != destexe:
                    if self.args.verbose > 0:
                        print("".join([outputdir, base]))
                    compiletools.wrappedos.copy(srcexe, outputdir)

            if self.args.static:
                src = self.namer.staticlibrary_pathname()
                filename = self.namer.staticlibrary_name()
                dest = compiletools.wrappedos.realpath(os.path.join(outputdir, filename))
                if src != dest:
                    if self.args.verbose > 0:
                        print(os.path.join(outputdir, filename))
                    compiletools.wrappedos.copy(src, outputdir)

            if self.args.dynamic:
                src = self.namer.dynamiclibrary_pathname()
                filename = self.namer.dynamiclibrary_name()
                dest = compiletools.wrappedos.realpath(os.path.join(outputdir, filename))
                if src != dest:
                    if self.args.verbose > 0:
                        print(os.path.join(outputdir, filename))
                    compiletools.wrappedos.copy(src, outputdir)

    def _callmakefile(self):
        makefile_creator = compiletools.makefile.MakefileCreator(self.args, self.hunter)
        makefile_creator.create()
        
        # Generate compilation database after makefile creation but before build
        self._call_compilation_database()
        
        os.makedirs(self.namer.executable_dir(), exist_ok=True)
        cmd = ["make"]
        if self.args.verbose <= 1:
            cmd.append("-s")
        if self.args.verbose >= 4:
            # --trace first comes in GNU make 4.0
            make_version = (
                subprocess.check_output(["make", "--version"], universal_newlines=True)
                .splitlines()[0]
                .split(" ")[-1]
                .split(".")[0]
            )
            if int(make_version) >= 4:
                cmd.append("--trace")
        cmd.extend(["-j", str(self.args.parallel), "-f", self.args.makefilename])
        if self.args.clean:
            cmd.append("realclean")
        else:
            cmd.append("build")
        if self.args.verbose >= 1:
            print(" ".join(cmd))
            
        # Time the main build subprocess
        subprocess.check_call(cmd, universal_newlines=True)

        if self.args.tests and not self.args.clean:
            cmd = ["make"]
            cmd.extend(["-j", str(self.args.parallel)])
            if self.args.verbose < 2:
                cmd.append("-s")
            cmd.extend(["-f", self.args.makefilename, "runtests"])
            if self.args.verbose >= 2:
                print(" ".join(cmd))
                
            # Time the test execution subprocess
            subprocess.check_call(cmd, universal_newlines=True)

        if self.args.clean:
            # Remove the extra executables we copied
            if self.args.output:
                try:
                    os.remove(self.args.output)
                except OSError:
                    pass
            else:
                outputdir = self.namer.topbindir()
                filelist = os.listdir(outputdir)
                for ff in filelist:
                    filename = os.path.join(outputdir, ff)
                    try:
                        os.remove(filename)
                    except OSError:
                        pass
        else:
            self._copyexes()

    def process(self):
        """ Transform the arguments into suitable versions for ct-* tools
            and call the appropriate tool.
        """
        # If the user specified only a single file to be turned into a library, guess that
        # they mean for ct-cake to chase down all the implied files.
        if self.args.verbose > 4:
            print("Early scanning. Cake determining targets and implied files")

        self._createctobjs()
        recreateobjs = False
        if self.args.static and len(self.args.static) == 1:
            self.args.static.extend(
                self.hunter.required_source_files(self.args.static[0])
            )
            recreateobjs = True

        if self.args.dynamic and len(self.args.dynamic) == 1:
            self.args.dynamic.extend(
                self.hunter.required_source_files(self.args.dynamic[0])
            )
            recreateobjs = True

        if self.args.auto and not any([self.args.filename, self.args.static, self.args.dynamic, self.args.tests]):
            findtargets = compiletools.findtargets.FindTargets(self.args)
            findtargets.process(self.args)
            recreateobjs = True

        if recreateobjs:
            # Since we've fiddled with the args,
            # run the substitutions again
            # Primarily, this fixes the --includes for the git root of the
            # targets. And recreate the ct objects
            if self.args.verbose > 4:
                print("Cake recreating objects and reparsing for second stage processing")
            compiletools.apptools.substitutions(self.args, verbose=0)
            self._createctobjs()

        compiletools.apptools.verboseprintconfig(self.args)

        if self.args.filelist:
            self._callfilelist()
        else:
            self._callmakefile()

    def clear_cache(self):
        """ Only useful in test scenarios where you need to reset to a pristine state """
        compiletools.wrappedos.clear_cache()
        compiletools.utils.clear_cache()
        compiletools.git_utils.clear_cache()
        compiletools.configutils.clear_cache()
        self.namer.clear_cache()
        self.hunter.clear_cache()
        compiletools.magicflags.MagicFlagsBase.clear_cache()


def signal_handler(signal, frame):
    sys.exit(0)


def main(argv=None):
    cap = compiletools.apptools.create_parser(
        "A convenience tool to aid migration from cake to the ct-* tools", argv=argv
    )
    Cake.add_arguments(cap)
    Cake.registercallback()

    args = compiletools.apptools.parseargs(cap, argv)


    if not any([args.filename, args.static, args.dynamic, args.tests, args.auto]):
        print(
            "Nothing for cake to do.  Did you mean cake --auto? Use cake --help for help."
        )
        return 0

    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGPIPE, signal_handler)

    try:
        cake = Cake(args)
        cake.process()
        # For testing purposes, clear out the memcaches for the times when main is called more than once.
        cake.clear_cache()
    except IOError as ioe:
        if args.verbose < 2:
            print(f"Error processing {ioe.filename}: {ioe.strerror}")
            return 1
        else:
            raise
    except Exception as err:
        if args.verbose < 2:
            print(err)
            return 1
        else:
            raise
    return 0
