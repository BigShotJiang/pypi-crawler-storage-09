"""Tests for concurry.core module."""
