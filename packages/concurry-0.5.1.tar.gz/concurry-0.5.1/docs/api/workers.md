# Workers API Reference

::: concurry.core.worker.base_worker.Worker
    options:
      show_root_heading: true
      show_source: true

::: concurry.core.worker.task_worker.TaskWorker
    options:
      show_root_heading: true
      show_source: true

