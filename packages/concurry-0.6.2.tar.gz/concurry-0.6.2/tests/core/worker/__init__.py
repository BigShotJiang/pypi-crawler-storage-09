"""Tests for worker module."""
