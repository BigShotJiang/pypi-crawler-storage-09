All of the people who have made at least one contribution to conda-index.
Authors are sorted alphabetically.

* Andrew Vallette
* Carl Anderson
* Conda Bot
* Daniel Holth
* Jannis Leidel
* Jay Roebuck
* Ken Odegard
* Klaus Zimmermann
* Ryan Keith
* conda-bot
* jaimergp
