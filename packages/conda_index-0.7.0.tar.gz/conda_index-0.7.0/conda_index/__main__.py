import conda_index.cli

conda_index.cli.cli()
