"""
Errors module

This module holds Conjur SDK-specific errors for this project
"""

from conjur_api.errors import errors
from conjur_api.errors import ssl_errors
