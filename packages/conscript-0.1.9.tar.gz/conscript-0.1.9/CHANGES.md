# Conscript Release Notes

## 0.1.9

+ [d6969dd](https://github.com/jsirois/conscript/commit/d6969dd) Support Python 3.15. (#12)

## 0.1.8

+ [eab1a3a](https://github.com/jsirois/conscript/commit/eab1a3a) Add support for PI. (#10)

## 0.1.7

+ [271e589](https://github.com/jsirois/conscript/commit/271e589) Add support for Python 3.13. (#8)

## 0.1.6

+ [20ad68a](https://github.com/jsirois/conscript/commit/20ad68a) Add support for Python 3.12. (#7)

## 0.1.5

+ [2f55788](https://github.com/jsirois/conscript/commit/2f55788) Handle EntryPoints.get removal. (#5)

## 0.1.4

+ [019442d](https://github.com/jsirois/conscript/commit/019442d) add support for Python 3.10 & 3.11 (#2)

## 0.1.3

+ [305cf38](https://github.com/jsirois/conscript/commit/305cf38) Fixup changelog.

## 0.1.2

+ [2b9d5c7](https://github.com/jsirois/conscript/commit/2b9d5c7) Expand README.
+ [32678ee](https://github.com/jsirois/conscript/commit/32678ee) Unify main completion modes.

## 0.1.1

+ [0f7a388](https://github.com/jsirois/conscript/commit/0f7a388) Fixup release metadata.

## 0.1.0

Initial public release.



