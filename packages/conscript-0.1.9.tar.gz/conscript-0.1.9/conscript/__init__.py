from __future__ import absolute_import

__version__ = "0.1.9"  # N.B.: Setuptools is configured to use this as our distribution version.
