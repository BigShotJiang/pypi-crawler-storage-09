"""FastAPI router for Conbus operations."""

from fastapi import APIRouter

router = APIRouter(prefix="/api/conbus", tags=["conbus"])
