"""CLI interface for XP tool"""

from xp.cli.main import cli

__all__ = ["cli"]
