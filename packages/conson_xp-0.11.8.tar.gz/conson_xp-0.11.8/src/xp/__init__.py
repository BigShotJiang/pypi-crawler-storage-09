"""XP CLI tool for remote console bus operations"""

"""conson-xp"""

__version__ = "0.11.8"
__manufacturer__ = "salchichon"
__model__ = "xp.cli"
__serial__ = "2025.09.23.000"
