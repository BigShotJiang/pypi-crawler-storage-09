"""HomeKit integration models."""
