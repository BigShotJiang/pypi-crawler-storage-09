API_BASE_URL = "https://api.contact-digital-prod.net"
API_KEY = "kbIthASA7e1M3NmpMdGrn2Yqe0yHcCjL4QNPSUij" # this can be obtained from https://myaccount.contact.co.nz/main.<hash>.esm.js, I don't believe this to be secret
