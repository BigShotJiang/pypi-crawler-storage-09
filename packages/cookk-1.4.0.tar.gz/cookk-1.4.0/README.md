# cookk

Darkkkk

## Installation
pip install cookk

## Usage
from cookk import main
