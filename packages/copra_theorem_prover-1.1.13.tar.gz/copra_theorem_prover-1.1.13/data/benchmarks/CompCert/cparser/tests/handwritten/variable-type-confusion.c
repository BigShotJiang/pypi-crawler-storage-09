typedef int t;
typedef int u;
int f (void) {
  t = 3;
}

