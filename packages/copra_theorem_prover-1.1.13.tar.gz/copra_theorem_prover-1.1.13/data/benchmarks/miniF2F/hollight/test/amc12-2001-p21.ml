let amc12-2001-p21 = `!a b c d. a * b * c * d = FACT 8 /\ a * b + a + b = 524 /\ b * c + b + c = 146 /\ c * d + c + d = 104 ==> a - d = 10`;;
