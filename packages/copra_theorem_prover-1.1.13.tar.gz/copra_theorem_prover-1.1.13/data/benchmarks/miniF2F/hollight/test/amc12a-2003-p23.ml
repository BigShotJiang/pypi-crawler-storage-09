let amc12a-2003-p23 = `FINITE {k:num | k > 0 /\ (k * k) divides (nproduct (1..(10-1)) (\i. FACT i))} ==> CARD {k:num | k > 0 /\ (k * k) divides (nproduct (1..(10-1)) (\i. FACT i))} = 672`;;
