void render(struct point * amb,
            int numlights,
            struct light ** lights,
            struct object * scene,
            int depth,
            flt fov,
            int wid,
            int ht,
            char * filename);
