#include <stdio.h>

int main(void)
{
        unsigned short p_69 = (signed char) (-1);
        printf("%d\n", p_69);
        return 0;
}
