let algebra-2varlineareq-fp3zeq11-3tfm1m5zeqn68-feqn10-zeq7 = `!f:complex z:complex.
    (f + Cx(&3) * z = Cx(&11)) /\
    (Cx(&3) * (f - Cx(&1)) - Cx(&5) * z = Cx(-- &68))
==>
    (f = Cx(-- &10)) /\
    (z = Cx(&7))
`;;
