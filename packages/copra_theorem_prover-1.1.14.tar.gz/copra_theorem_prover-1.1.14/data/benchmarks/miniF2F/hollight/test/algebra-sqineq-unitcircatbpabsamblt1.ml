let algebra-sqineq-unitcircatbpabsamblt1 = `!a:real b:real.
    (a pow 2 + b pow 2 = &1)
==>
    (a * b + abs (a - b) <= &1)
`;;
