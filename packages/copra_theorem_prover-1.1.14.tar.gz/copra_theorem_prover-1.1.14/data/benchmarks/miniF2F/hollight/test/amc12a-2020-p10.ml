let amc12a-2020-p10 = `!n:num.
    (n > 0) /\
    (ln (ln (&n) / ln (&16)) / ln (&2) = ln (ln (&n) / ln (&4)) / ln (&4))
==>
    n = 256
`;;
