let amc12a-2021-p19 = `(FINITE {x:real | (&0 <= x) /\ (x <= pi) /\ (sin (pi / &2 * cos x) = cos (pi / &2 * sin x))})
==>
    (CARD {x:real | (&0 <= x) /\ (x <= pi) /\ (sin (pi / &2 * cos x) = cos (pi / &2 * sin x))} = 2)
`;;
