copul.schur\_order package
==========================

Submodules
----------

copul.schur\_order.bounds\_from\_xi module
------------------------------------------

.. automodule:: copul.schur_order.bounds_from_xi
   :members:
   :show-inheritance:
   :undoc-members:

copul.schur\_order.cis\_rearranger module
-----------------------------------------

.. automodule:: copul.schur_order.cis_rearranger
   :members:
   :show-inheritance:
   :undoc-members:

copul.schur\_order.cis\_verifier module
---------------------------------------

.. automodule:: copul.schur_order.cis_verifier
   :members:
   :show-inheritance:
   :undoc-members:

copul.schur\_order.ltd\_verifier module
---------------------------------------

.. automodule:: copul.schur_order.ltd_verifier
   :members:
   :show-inheritance:
   :undoc-members:

copul.schur\_order.plod\_verifier module
----------------------------------------

.. automodule:: copul.schur_order.plod_verifier
   :members:
   :show-inheritance:
   :undoc-members:

copul.schur\_order.schur\_order\_verifier module
------------------------------------------------

.. automodule:: copul.schur_order.schur_order_verifier
   :members:
   :show-inheritance:
   :undoc-members:

copul.schur\_order.schur\_visualizer module
-------------------------------------------

.. automodule:: copul.schur_order.schur_visualizer
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: copul.schur_order
   :members:
   :show-inheritance:
   :undoc-members:
