class PropertyUnavailableException(Exception):
    """A property is not available"""

    pass
