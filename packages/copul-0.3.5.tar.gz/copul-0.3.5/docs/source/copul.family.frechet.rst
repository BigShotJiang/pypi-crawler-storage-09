copul.family.frechet package
============================

Submodules
----------

copul.family.frechet.biv\_independence\_copula module
-----------------------------------------------------

.. automodule:: copul.family.frechet.biv_independence_copula
   :members:
   :show-inheritance:
   :undoc-members:

copul.family.frechet.frechet module
-----------------------------------

.. automodule:: copul.family.frechet.frechet
   :members:
   :show-inheritance:
   :undoc-members:

copul.family.frechet.frechet\_multi module
------------------------------------------

.. automodule:: copul.family.frechet.frechet_multi
   :members:
   :show-inheritance:
   :undoc-members:

copul.family.frechet.lower\_frechet module
------------------------------------------

.. automodule:: copul.family.frechet.lower_frechet
   :members:
   :show-inheritance:
   :undoc-members:

copul.family.frechet.mardia module
----------------------------------

.. automodule:: copul.family.frechet.mardia
   :members:
   :show-inheritance:
   :undoc-members:

copul.family.frechet.rho\_d\_lower\_boundary module
---------------------------------------------------

.. automodule:: copul.family.frechet.rho_d_lower_boundary
   :members:
   :show-inheritance:
   :undoc-members:

copul.family.frechet.rho\_d\_upper\_boundary module
---------------------------------------------------

.. automodule:: copul.family.frechet.rho_d_upper_boundary
   :members:
   :show-inheritance:
   :undoc-members:

copul.family.frechet.upper\_frechet module
------------------------------------------

.. automodule:: copul.family.frechet.upper_frechet
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: copul.family.frechet
   :members:
   :show-inheritance:
   :undoc-members:
