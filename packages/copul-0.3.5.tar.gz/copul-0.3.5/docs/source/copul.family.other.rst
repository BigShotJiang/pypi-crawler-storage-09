copul.family.other package
==========================

Submodules
----------

copul.family.other.asymmetric\_xi\_rho\_si\_copula module
---------------------------------------------------------

.. automodule:: copul.family.other.asymmetric_xi_rho_si_copula
   :members:
   :show-inheritance:
   :undoc-members:

copul.family.other.b11 module
-----------------------------

.. automodule:: copul.family.other.b11
   :members:
   :show-inheritance:
   :undoc-members:

copul.family.other.clamped\_parabola\_copula module
---------------------------------------------------

.. automodule:: copul.family.other.clamped_parabola_copula
   :members:
   :show-inheritance:
   :undoc-members:

copul.family.other.diagonal\_band\_copula module
------------------------------------------------

.. automodule:: copul.family.other.diagonal_band_copula
   :members:
   :show-inheritance:
   :undoc-members:

copul.family.other.diagonal\_strip\_copula module
-------------------------------------------------

.. automodule:: copul.family.other.diagonal_strip_copula
   :members:
   :show-inheritance:
   :undoc-members:

copul.family.other.end\_swap\_copula module
-------------------------------------------

.. automodule:: copul.family.other.end_swap_copula
   :members:
   :show-inheritance:
   :undoc-members:

copul.family.other.farlie\_gumbel\_morgenstern module
-----------------------------------------------------

.. automodule:: copul.family.other.farlie_gumbel_morgenstern
   :members:
   :show-inheritance:
   :undoc-members:

copul.family.other.independence\_copula module
----------------------------------------------

.. automodule:: copul.family.other.independence_copula
   :members:
   :show-inheritance:
   :undoc-members:

copul.family.other.median\_swap\_copula module
----------------------------------------------

.. automodule:: copul.family.other.median_swap_copula
   :members:
   :show-inheritance:
   :undoc-members:

copul.family.other.pi\_over\_sigma\_minus\_pi module
----------------------------------------------------

.. automodule:: copul.family.other.pi_over_sigma_minus_pi
   :members:
   :show-inheritance:
   :undoc-members:

copul.family.other.plackett module
----------------------------------

.. automodule:: copul.family.other.plackett
   :members:
   :show-inheritance:
   :undoc-members:

copul.family.other.raftery module
---------------------------------

.. automodule:: copul.family.other.raftery
   :members:
   :show-inheritance:
   :undoc-members:

copul.family.other.small\_footrule\_copula module
-------------------------------------------------

.. automodule:: copul.family.other.small_footrule_copula
   :members:
   :show-inheritance:
   :undoc-members:

copul.family.other.v\_threshold\_copula module
----------------------------------------------

.. automodule:: copul.family.other.v_threshold_copula
   :members:
   :show-inheritance:
   :undoc-members:

copul.family.other.xi\_psi\_lower\_jensen\_bound module
-------------------------------------------------------

.. automodule:: copul.family.other.xi_psi_lower_jensen_bound
   :members:
   :show-inheritance:
   :undoc-members:

copul.family.other.xi\_rho\_boundary\_copula module
---------------------------------------------------

.. automodule:: copul.family.other.xi_rho_boundary_copula
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: copul.family.other
   :members:
   :show-inheritance:
   :undoc-members:
