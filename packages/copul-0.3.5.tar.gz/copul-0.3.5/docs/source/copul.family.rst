copul.family package
====================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   copul.family.archimedean
   copul.family.core
   copul.family.elliptical
   copul.family.extreme_value
   copul.family.frechet
   copul.family.other

Submodules
----------

copul.family.copula\_builder module
-----------------------------------

.. automodule:: copul.family.copula_builder
   :members:
   :show-inheritance:
   :undoc-members:

copul.family.copula\_graphs module
----------------------------------

.. automodule:: copul.family.copula_graphs
   :members:
   :show-inheritance:
   :undoc-members:

copul.family.helpers module
---------------------------

.. automodule:: copul.family.helpers
   :members:
   :show-inheritance:
   :undoc-members:

copul.family.rank\_correlation\_plotter module
----------------------------------------------

.. automodule:: copul.family.rank_correlation_plotter
   :members:
   :show-inheritance:
   :undoc-members:

copul.family.tp2\_verifier module
---------------------------------

.. automodule:: copul.family.tp2_verifier
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: copul.family
   :members:
   :show-inheritance:
   :undoc-members:
