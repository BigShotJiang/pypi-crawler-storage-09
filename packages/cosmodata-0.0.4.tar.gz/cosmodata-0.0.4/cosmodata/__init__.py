"""A portal to access data sources"""

from cosmodata.base import acquire_data

