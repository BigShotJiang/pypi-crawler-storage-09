"""Tests for the cosmograph package."""

# from cosmograph.tests.datagen import TestData, MkTestData
