__version__ = "1.0.3"  # same as pyproject.toml
