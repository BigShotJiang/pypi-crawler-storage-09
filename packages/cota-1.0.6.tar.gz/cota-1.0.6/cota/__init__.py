__version__ = "1.0.6"  # same as pyproject.toml
