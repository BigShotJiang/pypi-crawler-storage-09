# 打招呼
UserUtter:你好
thought:我应该回复用户
BotUtter:你好，请问有什么可以帮您


# 复杂查天气
UserUtter:成都和重庆天气咋样哪个好，我要看下去哪个城市旅游
Weather:<text>
Weather:<text>
thought:我应该告诉用户两个城市的天气结果


