__version__ = "1.0.7"  # same as pyproject.toml
