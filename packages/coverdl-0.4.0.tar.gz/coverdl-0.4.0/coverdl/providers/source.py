from enum import Enum

class Source(Enum):
    APPLE_MUSIC = "applemusic"
    DEEZER = "deezer"
    DISCOGS = "discogs"
    ITUNES = "itunes" # not recommended
