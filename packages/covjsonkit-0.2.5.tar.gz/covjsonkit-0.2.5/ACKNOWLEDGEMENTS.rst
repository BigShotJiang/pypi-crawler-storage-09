Acknowledgements
================

Destination Earth
    This software is developed with co-funding by the European Union under the Destination Earth initiative.

ClimEmpower
    This software is developed with co-funding by the European Union under the ClimEmpower project.
