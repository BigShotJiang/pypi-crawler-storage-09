"""Stanza, build tune up sequences for quantum computers fast. Easy to code. Easy to run."""

__version__ = "0.1.1"
