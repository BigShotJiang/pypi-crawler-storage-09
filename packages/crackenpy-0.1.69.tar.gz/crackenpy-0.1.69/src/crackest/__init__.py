# -*- coding: utf-8 -*-
"""
Created on Fri Jan 12 10:58:38 2024

@author: dvorr
"""

# mypackage/__init__.py
CRACKCMAP=["#0027B9", "#0DC9E7", "#E8DD00","#D30101"]

# Define a package-level variable
__version__ = '0.1.1'