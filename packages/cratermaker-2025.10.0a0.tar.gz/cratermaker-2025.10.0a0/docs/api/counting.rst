.. _api-countin:

########
Counting
########

The ``Counting`` class contains methods for counting craters and tracking size-frequency distributions.


.. autoclass:: cratermaker.components.counting.Counting
    :members:
    :undoc-members:
    :no-index:
