*******************
Cratermaker license
*******************

.. include:: ../LICENSE
   :literal: