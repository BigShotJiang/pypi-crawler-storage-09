.. _gal-simulation:

Simuation Examples
==================

This section provides examples of how to use the :ref:`ug-simulation` component of Cratermaker.
