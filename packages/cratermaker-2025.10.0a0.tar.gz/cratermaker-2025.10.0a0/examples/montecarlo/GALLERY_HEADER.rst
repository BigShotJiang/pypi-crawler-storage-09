.. _gal-montecarlo:

Monte Carlo Utility Examples
============================

This section provides examples of how to use the :ref:`api-utils-montecarlo` component of Cratermaker.
