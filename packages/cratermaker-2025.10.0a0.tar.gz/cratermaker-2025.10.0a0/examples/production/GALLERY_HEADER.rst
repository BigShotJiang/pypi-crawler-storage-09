.. _gal-production:

Production Examples
===================

This section provides examples of how to use the :ref:`ug-production` component of Cratermaker.
