.. _gal-projectile:

Projectile Examples
===================

This section provides examples of how to use the :ref:`ug-projectile` component of Cratermaker.
