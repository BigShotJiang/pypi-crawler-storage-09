.. _gal-scaling:

Scaling Examples
================

This section provides examples of how to use the :ref:`ug-scaling` component of Cratermaker.
