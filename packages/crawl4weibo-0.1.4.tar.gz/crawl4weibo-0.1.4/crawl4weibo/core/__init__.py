#!/usr/bin/env python

"""
Core module for crawl4weibo
"""
