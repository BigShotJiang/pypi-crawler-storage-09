#!/usr/bin/env python

"""
Data models for crawl4weibo
"""
