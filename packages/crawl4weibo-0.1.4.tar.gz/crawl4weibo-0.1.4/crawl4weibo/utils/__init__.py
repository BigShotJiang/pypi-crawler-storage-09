#!/usr/bin/env python

"""
Utility functions for crawl4weibo
"""
