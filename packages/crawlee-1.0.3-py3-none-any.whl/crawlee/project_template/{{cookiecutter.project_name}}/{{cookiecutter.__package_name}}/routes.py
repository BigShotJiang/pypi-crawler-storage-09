# % include 'routes_%s.py' % cookiecutter.__crawler_type
