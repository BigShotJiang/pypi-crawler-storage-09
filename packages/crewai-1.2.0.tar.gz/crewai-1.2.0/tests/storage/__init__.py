"""Tests for storage."""
