import crisscross.core_functions.megastructure_composition as mcomp

print('test')