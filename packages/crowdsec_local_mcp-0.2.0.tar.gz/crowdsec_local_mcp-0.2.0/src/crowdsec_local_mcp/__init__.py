"""CrowdSec MCP package."""

from .mcp_core import main

__all__ = ["main"]
