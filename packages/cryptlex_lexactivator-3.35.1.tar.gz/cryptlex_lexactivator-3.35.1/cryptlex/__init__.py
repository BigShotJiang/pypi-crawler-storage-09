from cryptlex.lexactivator import *
