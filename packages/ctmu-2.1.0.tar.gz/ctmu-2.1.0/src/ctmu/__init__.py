"""CTMU - Custom Terminal QR Utility for macOS"""

__version__ = "1.0.0"
__author__ = ""