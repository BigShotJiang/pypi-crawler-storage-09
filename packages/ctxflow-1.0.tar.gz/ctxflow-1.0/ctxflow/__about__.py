"""
`ctx-container` version file.
"""

__author__ = "Wayne Cole"
__email__ = "hi@waynecole.info"
__application__ = "ctxflow"
__version__ = "1.0"
