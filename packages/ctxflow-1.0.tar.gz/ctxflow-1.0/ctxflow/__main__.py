"""
ctxflow __main__ hook
"""

from ctxflow.cli import ctx


def main() -> None:
    ctx()


if __name__ == "__main__":
    main()
