---
allowed-tools: Bash
description: system prompt in xml
---

!`bash ./.claude/templates/template-processor.sh prime.xml`
