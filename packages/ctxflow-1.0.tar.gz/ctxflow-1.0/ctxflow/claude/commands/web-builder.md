---
allowed-tools: Bash
description: web builder prompt
---

!`bash ./.claude/templates/template-processor.sh web-builder.xml`
