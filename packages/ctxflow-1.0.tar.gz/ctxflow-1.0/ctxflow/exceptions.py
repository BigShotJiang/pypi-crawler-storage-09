"""
browsr.exceptions
"""


class FileSizeError(Exception):
    """
    File Too Large Error
    """
