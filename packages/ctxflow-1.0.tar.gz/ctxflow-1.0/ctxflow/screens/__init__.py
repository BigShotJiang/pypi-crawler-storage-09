"""
Screens for browsr
"""

from ctxflow.screens.code_browser import CodeBrowserScreen

__all__ = ["CodeBrowserScreen"]
