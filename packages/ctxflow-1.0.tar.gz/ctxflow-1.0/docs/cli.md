# Command Line Interface

::: mkdocs-click
    :module: browsr.__main__
    :command: browsr
    :prog_name: browsr
    :style: table
    :list_subcommands: True
