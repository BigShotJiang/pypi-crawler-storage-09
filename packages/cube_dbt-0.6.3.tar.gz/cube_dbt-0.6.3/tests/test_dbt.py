import os 

from pytest import raises
from cube_dbt import Dbt

class TestDbt:
  def test_from_file(self):
    directory_path = os.path.dirname(os.path.realpath(__file__))
    dbt = Dbt.from_file(directory_path + '/manifest.json')
    model_names = list(model.name for model in dbt.models)
    assert model_names == [
      'users_copy',
      'orders_copy',
      'line_items_copy',
      'products_copy'
    ]

  def test_load_only_models(self):
    """
    Only load nodes with resource type 'model'
    """
    manifest = {
      'nodes': {
        'model.jaffle_shop.users_copy': {
          'name': 'users_copy',
          'resource_type': 'model',
          'config': {
            'materialized': 'table'
          },
          'path': 'example/users_copy.sql'
        },
        'snapshot.jaffle_shop.snapshot_1': {
          'name': 'snapshot_1',
          'resource_type': 'snapshot'
        }
      }
    }
    dbt = Dbt(manifest)
    model_names = list(model.name for model in dbt.models)
    assert model_names == ['users_copy']

  def test_do_not_load_ephemeral_models(self):
    """
    Don't load models that are not materialized to the database
    """
    manifest = {
      'nodes': {
        'model.jaffle_shop.users_copy': {
          'name': 'users_copy',
          'resource_type': 'model',
          'config': {
            'materialized': 'table'
          },
          'path': 'example/users_copy.sql'
        },
        'model.jaffle_shop.users_copy_2': {
          'name': 'users_copy_2',
          'resource_type': 'model',
          'config': {
            'materialized': 'view'
          },
          'path': 'example/users_copy_2.sql'
        },
        'model.jaffle_shop.users_copy_3': {
          'name': 'users_copy_3',
          'resource_type': 'model',
          'config': {
            'materialized': 'incremental'
          },
          'path': 'example/users_copy_3.sql'
        },
        'model.jaffle_shop.users_copy_4': {
          'name': 'users_copy_4',
          'resource_type': 'model',
          'config': {
            'materialized': 'ephemeral'
          },
          'path': 'example/users_copy_4.sql'
        }
      }
    }
    dbt = Dbt(manifest)
    model_names = list(model.name for model in dbt.models)
    assert model_names == [
      'users_copy',
      'users_copy_2',
      'users_copy_3'
    ]

  def test_load_models_by_path(self):
    manifest = {
      'nodes': {
        'model.jaffle_shop.users_copy': {
          'name': 'users_copy',
          'resource_type': 'model',
          'config': {
            'materialized': 'table'
          },
          'path': 'example/users_copy.sql'
        },
        'model.jaffle_shop.users_copy_2': {
          'name': 'users_copy_2',
          'resource_type': 'model',
          'config': {
            'materialized': 'view'
          },
          'path': 'marts/users_copy_2.sql'
        }
      }
    }
    dbt = Dbt(manifest).filter(paths=['marts/'])
    model_names = list(model.name for model in dbt.models)
    assert model_names == ['users_copy_2']

  def test_load_models_by_tag(self):
    manifest = {
      'nodes': {
        'model.jaffle_shop.users_copy': {
          'name': 'users_copy',
          'resource_type': 'model',
          'config': {
            'materialized': 'table',
            'tags': [
              'cube'
            ]
          },
          'path': 'example/users_copy.sql'
        },
        'model.jaffle_shop.users_copy_2': {
          'name': 'users_copy_2',
          'resource_type': 'model',
          'config': {
            'materialized': 'view',
            'tags': []
          },
          'path': 'marts/users_copy_2.sql'
        }
      }
    }
    dbt = Dbt(manifest).filter(tags=['cube'])
    model_names = list(model.name for model in dbt.models)
    assert model_names == ['users_copy']

  def test_load_models_by_name(self):
    manifest = {
      'nodes': {
        'model.jaffle_shop.users_copy': {
          'name': 'users_copy',
          'resource_type': 'model',
          'config': {
            'materialized': 'table'
          },
          'path': 'example/users_copy.sql'
        },
        'model.jaffle_shop.users_copy_2': {
          'name': 'users_copy_2',
          'resource_type': 'model',
          'config': {
            'materialized': 'view'
          },
          'path': 'marts/users_copy_2.sql'
        }
      }
    }
    dbt = Dbt(manifest).filter(names=['users_copy_2'])
    model_names = list(model.name for model in dbt.models)
    assert model_names == ['users_copy_2']

  def test_model(self):
    manifest = {
      'nodes': {
        'model.jaffle_shop.users_copy': {
          'name': 'users_copy',
          'resource_type': 'model',
          'config': {
            'materialized': 'table'
          },
          'path': 'example/users_copy.sql'
        },
        'model.jaffle_shop.users_copy_2': {
          'name': 'users_copy_2',
          'resource_type': 'model',
          'config': {
            'materialized': 'view'
          },
          'path': 'marts/users_copy_2.sql'
        }
      }
    }
    dbt = Dbt(manifest)
    assert dbt.model('users_copy_2').name == 'users_copy_2'

  def test_primary_key_detection_from_tests(self):
    """
    Integration test: Load manifest with test nodes and verify
    primary key detection from unique+not_null tests
    """
    directory_path = os.path.dirname(os.path.realpath(__file__))
    dbt = Dbt.from_file(directory_path + '/manifest.json')

    # orders_copy should have id as primary key (from unique+not_null tests)
    orders_model = dbt.model('orders_copy')
    assert len(orders_model.primary_key) == 1
    assert orders_model.primary_key[0].name == 'id'

  def test_primary_key_detection_from_constraints(self):
    """
    Integration test: Load manifest and verify primary key detection
    from model constraints
    """
    directory_path = os.path.dirname(os.path.realpath(__file__))
    dbt = Dbt.from_file(directory_path + '/manifest.json')

    # products_copy should have id as primary key (from constraints)
    products_model = dbt.model('products_copy')
    assert len(products_model.primary_key) == 1
    assert products_model.primary_key[0].name == 'id'