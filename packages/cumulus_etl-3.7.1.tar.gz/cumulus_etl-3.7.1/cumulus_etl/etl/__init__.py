"""Module that handles the main ETL work"""

from .cli import run_etl
