"""Subcommand to initialize basic tables"""

from .cli import run_init
