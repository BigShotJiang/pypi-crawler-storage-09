"""Inline attachments inside existing NDJSON"""

from .cli import run_inline
from .inliner import inliner
