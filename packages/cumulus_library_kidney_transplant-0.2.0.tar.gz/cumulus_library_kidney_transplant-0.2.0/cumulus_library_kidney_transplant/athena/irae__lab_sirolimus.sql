create or replace view irae__lab_sirolimus as select * from (values

('http://loinc.org','29247-4','Sirolimus, Blood'),
('http://loinc.org','49737-0','Sirolimus dose'),
('http://loinc.org','72676-0','Sirolimus trough, Blood'),
('http://loinc.org','80548-1','Sirolimus, Dried blood spot'),
('http://loinc.org','96462-7','Sirolimus, Blood')
) AS t (system,code,display) ;