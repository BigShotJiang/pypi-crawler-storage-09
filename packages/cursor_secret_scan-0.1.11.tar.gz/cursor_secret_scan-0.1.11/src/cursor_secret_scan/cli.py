from claude_secret_scan.core import console_main_cursor as main

