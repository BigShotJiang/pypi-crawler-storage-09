import json

from cve_driller.driller import CVEDriller


if __name__ == "__main__":
    driller = CVEDriller(verbose=True)
    cve_id = "CVE-2018-7187"

    input_path = f"data/inputs/CWE-78/comp_config_condition/{cve_id}.txt"
    #description = open(input_path, 'r').read()
    description = "SQL injection vulnerability in members.php in the Members CV (job) module 1.0 for PHP-Fusion, when magic_quotes_gpc is disabled, allows remote authenticated users to execute arbitrary SQL commands via the sortby parameter."
    detail_type, details = driller(description)

    print(details)

    #if details:
    #    output_path = f"data/outputs/{detail_type.value}/{cve_id}.json"

    #    with open(output_path, 'w') as f:
    #        json.dump(details, f, indent=4)
