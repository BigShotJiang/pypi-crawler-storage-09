# CVE Explorer CLI

A command-line interface tool to explore CVE (Common Vulnerabilities and Exposures) information.

## Features

- Look up CVE information from the FIRST EPSS API
- Beautiful CLI interface with spinners and colored output
- Fast and easy to use

<br />

![cvex](https://github.com/meddlin/cve-explorer-cli/raw/main/cvex.jpeg)

## Installation

```bash
pip install cve-explorer-cli
```

## Usage

After installation, you can use the `cvex` command:

### Look up a CVE

```bash
cvex lookup --id CVE-2022-27225
```

### Get help

```bash
cvex --help
```

## Requirements

- Python >= 3.11

## Development

To contribute or develop locally:

```bash
# Clone the repository
git clone https://github.com/meddlin/cve-explorer-cli.git
cd cve-explorer-cli

# Create a virtual environment
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
pip install -r requirements-dev.txt

# Run locally
python -m cve_explorer_cli.main lookup --id CVE-2022-27225
```
