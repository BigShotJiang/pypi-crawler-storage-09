"""CVE Explorer

"""

import time
import json
import argparse
from typing import Any

from cve_explorer_cli.models.cve import CVE

import requests
from yaspin import yaspin
from yaspin.spinners import Spinners
from rich import print_json

def __request_epss(cve_id: str) -> Any:
    res = requests.get(
        f'https://api.first.org/data/v1/epss?cve={cve_id}',
        timeout=10
    )
    return res.json()

def __request_cve(cve_id: str) -> Any:
    """Request CVE information from First (api.first.org)

    Args:
        cve_id (str): ID of CVE (ex: CVE-2022-27225)

    Returns:
        _type_: _description_
    """
    res = requests.get(
        f'https://services.nvd.nist.gov/rest/json/cves/2.0?cveId={cve_id}',
        timeout=10
    )
    response_json = res.json()
    return response_json

def get_severity(cve_metrics: Any) -> tuple[str, str, str, str]:
    res_v31, res_v31_base, res_v2, res_v2_base = '', '', '', ''

    if 'cvssMetricV31' in cve_metrics:
        res_v31 = cve_metrics['cvssMetricV31'][0]['impactScore']
        res_v31_base = cve_metrics['cvssMetricV31'][0]['cvssData']['baseSeverity']

    if 'cvssMetricV2' in cve_metrics:
        res_v2 = cve_metrics['cvssMetricV2'][0]['impactScore']
        res_v2_base = cve_metrics['cvssMetricV2'][0]['baseSeverity']
    
    return res_v31, res_v31_base, res_v2, res_v2_base

def main():
    print("Welcome to the CVE Explorer CLI!")

    parser = argparse.ArgumentParser(description="CVE Explorer CLI")
    subparsers = parser.add_subparsers(dest="command")

    # CVE Lookup
    cve_lookup = subparsers.add_parser("lookup", help="Request a single CVE")
    cve_lookup.add_argument("--id", type=str)

    epss_lookup = subparsers.add_parser("epss", help="Request EPSS info for CVE")
    epss_lookup.add_argument("--id", type=str)

    args = parser.parse_args()

    if args.command == "lookup":
        with yaspin(color="green") as sp:
            sp.spinner = Spinners.arc
            res = __request_cve(cve_id=args.id)
            # JSON pretty print is here
            # print_json(json.dumps(res))

            res_v31, res_v31_base, res_v2, res_v2_base = get_severity(res['vulnerabilities'][0]['cve']['metrics'])

            custom_cve = CVE(
                id=res['vulnerabilities'][0]['cve']['id'],
                source_identifier=res['vulnerabilities'][0]['cve']['sourceIdentifier'],
                published=res['vulnerabilities'][0]['cve']['published'],
                last_modified=res['vulnerabilities'][0]['cve']['lastModified'],
                vuln_status=res['vulnerabilities'][0]['cve']['vulnStatus'],
                description=res['vulnerabilities'][0]['cve']['descriptions'][0]['value'],
                weaknesses=res['vulnerabilities'][0]['cve']['weaknesses'],
                severity=f"CVSS 3.1: {res_v31} ({res_v31_base}), CVSS 2.0: {res_v2} ({res_v2_base})"
            )

            print("\n")
            custom_cve.display_cve()
    elif args.command == "epss":
        data = __request_epss(args.id)
        print_json(json.dumps(data))
    else:
        parser.print_help()

        # # Simple example with a spinner while something runs
        # with yaspin(text="Processing...", color="cyan") as spinner:
        #     try:
        #         # # Simulate a long-running task
        #         # time.sleep(3)
        #         # res = __request_cve(cve_id='CVE-2022-27225')
        #         res = __request_cve(cve_id=args.id)
        #         print(res)

        #         # If success
        #         spinner.ok("✅ ")
        #     except Exception as e:
        #         spinner.fail("💥 ")
        #         print(f"Error: {e}")

if __name__ == "__main__":
    main()
