"""Models for CVE Explorer CLI"""

