"""CVE Explorer CLI - A CLI tool to explore CVE information."""

__version__ = "0.1.0"

