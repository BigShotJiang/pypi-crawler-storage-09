"""CVE Explorer
"""

import json
import argparse
from typing import Any

from yaspin import yaspin
from yaspin.spinners import Spinners
from rich import print_json

from cve_explorer_cli.models.cve import CVE
from cve_explorer_cli.models.epss import EPSS
from cve_explorer_cli.utilities.ext_request import request_cve, request_epss


def get_severity(cve_metrics: Any) -> tuple[str, str, str, str]:
    res_v31, res_v31_base, res_v2, res_v2_base = '', '', '', ''

    if 'cvssMetricV31' in cve_metrics:
        res_v31 = cve_metrics['cvssMetricV31'][0]['impactScore']
        res_v31_base = cve_metrics['cvssMetricV31'][0]['cvssData']['baseSeverity']

    if 'cvssMetricV2' in cve_metrics:
        res_v2 = cve_metrics['cvssMetricV2'][0]['impactScore']
        res_v2_base = cve_metrics['cvssMetricV2'][0]['baseSeverity']
    
    return res_v31, res_v31_base, res_v2, res_v2_base

def main():
    print("Welcome to the CVE Explorer CLI!")

    parser = argparse.ArgumentParser(description="CVE Explorer CLI")
    subparsers = parser.add_subparsers(dest="command")

    # CVE Lookup
    cve_lookup = subparsers.add_parser("lookup", help="Request a single CVE")
    cve_lookup.add_argument("--id", type=str)

    epss_lookup = subparsers.add_parser("epss", help="Request EPSS info for CVE")
    epss_lookup.add_argument("--id", type=str)

    args = parser.parse_args()

    if args.command == "lookup":
        with yaspin(color="green") as sp:
            sp.spinner = Spinners.arc
            res = request_cve(cve_id=args.id)

            res_v31, res_v31_base, res_v2, res_v2_base = get_severity(res['vulnerabilities'][0]['cve']['metrics'])

            custom_cve = CVE(
                id=res['vulnerabilities'][0]['cve']['id'],
                source_identifier=res['vulnerabilities'][0]['cve']['sourceIdentifier'],
                published=res['vulnerabilities'][0]['cve']['published'],
                last_modified=res['vulnerabilities'][0]['cve']['lastModified'],
                vuln_status=res['vulnerabilities'][0]['cve']['vulnStatus'],
                description=res['vulnerabilities'][0]['cve']['descriptions'][0]['value'],
                weaknesses=res['vulnerabilities'][0]['cve']['weaknesses'],
                severity=f"CVSS 3.1: {res_v31} ({res_v31_base}), CVSS 2.0: {res_v2} ({res_v2_base})"
            )
            epss_resp = request_epss(args.id)
            if epss_resp != '':
                _epss = EPSS(
                    cve_id=epss_resp['data'][0]['cve'],
                    epss_value=epss_resp['data'][0]['epss'],
                    percentile=epss_resp['data'][0]['percentile'],
                    date=epss_resp['data'][0]['date']
                )
                custom_cve.epss_value = _epss.epss_value
                custom_cve.epss_percentile = _epss.percentile
                custom_cve.epss_date = _epss.date
            
            print("\n")
            custom_cve.display_cve()

            # TODO: Add a JSON pretty print for CVEs

    elif args.command == "epss":
        epss_resp = request_epss(args.id)
        _epss = EPSS(
            cve_id=epss_resp['data'][0]['cve'],
            epss_value=epss_resp['data'][0]['epss'],
            percentile=epss_resp['data'][0]['percentile'],
            date=epss_resp['data'][0]['date']
        )
        _epss.display()

        # TODO: Add a JSON pretty print in the future
        # print_json(json.dumps(epss_resp)) # JSON pretty print is here
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
