import json
from typing import Any

from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich import print_json

class CvssMetricsV31:
    source: str
    type: str
    cvss_data: Any
    exploitability_score: str
    impact_score: str

    def __init__(
        self,
        source,
        type,
        cvss_data,
        exploitability_score,
        impact_score
    ):
        self.source = source
        self.type = type
        self.cvss_data = cvss_data
        self.exploitability_score = exploitability_score
        self.impact_score = impact_score

class CvssMetricsV2:
    source: str
    type: str
    cvss_data: Any
    base_severity: str
    impact_score: str
    ac_insuf_info: str
    obtain_all_privilege: str
    obtain_user_privilege: str
    obtain_other_privilege: str
    user_interaction_required: str

    def __init__(
        self,
        type,
        cvss_data,
        base_severity,
        impact_score,
        ac_insuf_info,
        obtain_all_privilege,
        obtain_user_privilege,
        obtain_other_privilege,
        user_interaction_required
    ):
        self.type = type
        self.cvss_data = cvss_data
        self.base_severity = base_severity
        self.impact_score = impact_score
        self.ac_insuf_info = ac_insuf_info
        self.obtain_all_privilege = obtain_all_privilege
        self.obtain_user_privilege = obtain_user_privilege
        self.obtain_other_privilege = obtain_other_privilege
        self.user_interaction_required = user_interaction_required


class CVE:

    id: str
    source_identifier: str
    published: str
    last_modified: str
    vuln_status: str
    description: str
    weaknesses: Any
    severity: str

    epss_value: str
    epss_percentile: str
    epss_date: str

    def __init__(
        self,
        id,
        source_identifier,
        published,
        last_modified,
        vuln_status,
        description,
        weaknesses,
        severity
    ):
        self.id = id
        self.source_identifier = source_identifier
        self.published = published
        self.last_modified = last_modified
        self.vuln_status = vuln_status
        self.description = description
        self.weaknesses = weaknesses
        self.severity = severity

    def display_cve(self):
        table = Table(show_header=False, box=None)
        table.add_column("Field", style="bold cyan")
        table.add_column("Value", style="white")

        table.add_row("CVE", f"[bold]{self.id}[/]")
        table.add_row("Severity", f"{self.severity}")
        if self.epss_value != '':
            table.add_row("EPSS Value", f"{self.epss_value}")
        if self.epss_percentile != '':
            table.add_row("EPSS Percentile", f"{self.epss_percentile}")
        if self.epss_date != '':
            table.add_row("EPSS Date", f"{self.epss_date}")
        table.add_row("Status", f"[yellow]{self.vuln_status}[/]")
        table.add_row("Published", self.published)
        table.add_row("Source", self.source_identifier)

        panel = Panel.fit(
            table,
            title=f"[red]CVE DETAILS[/red]",
            border_style="red",
        )

        console = Console()
        console.print(panel)
        print_json(
            json.dumps({
                "description": self.description,
                "weaknesses": self.weaknesses
            },
            indent=2)
        )
