from typing import Any, List

from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich import print_json

class EPSSResponse:
    status: str
    status_code: str
    version: str
    access: str
    total: int
    offset: int
    limit: int
    data: List[Any] # TODO: Test changing this type declaration to EPSS

    def __init__(
        self,
        status,
        status_code,
        version,
        access,
        total,
        offset,
        limit,
        data
    ):
        self.status = status
        self.status_code = status_code
        self.version = version
        self.access = access
        self.total = total
        self.offset = offset
        self.limit = limit
        self.data = data

class EPSS:
    """Class to represent EPSS data
    """
    cve_id: str
    epss_value: str
    percentile: str
    date: str

    def __init__(self, cve_id, epss_value, percentile, date):
        self.cve_id = cve_id
        self.epss_value = epss_value
        self.percentile = percentile
        self.date = date
    
    def display(self):
        table = Table(show_header=False, box=None)
        table.add_column("Field", style="bold cyan")
        table.add_column("Value", style="white")

        table.add_row("EPSS", f"[bold]{self.cve_id}[/]")
        table.add_row("EPSS Value", f"{self.epss_value}")
        table.add_row("Percentile", f"[yellow]{self.percentile}[/]")
        table.add_row("Date", self.date)

        panel = Panel.fit(
            table,
            title=f"[red]EPSS DETAILS[/red]",
            border_style="red",
        )

        console = Console()
        console.print(panel)
