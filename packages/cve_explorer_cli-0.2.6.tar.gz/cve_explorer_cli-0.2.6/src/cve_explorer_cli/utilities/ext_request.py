"""Logic to request external information
"""

from typing import Any

import requests

def request_epss(cve_id: str) -> Any:
    """_summary_

    Args:
        cve_id (str): _description_

    Returns:
        Any: _description_
    """
    res = requests.get(
        f'https://api.first.org/data/v1/epss?cve={cve_id.upper()}',
        timeout=10
    )
    if res.status_code == 404:
        print(f'HTTP 404 - request_epss({cve_id}) not found.')
        return ''
    elif res.status_code == 200:
        return res.json()

def request_cve(cve_id: str) -> Any:
    """Request CVE information from First (api.first.org)

    Args:
        cve_id (str): ID of CVE (ex: CVE-2022-27225)

    Returns:
        _type_: _description_
    """
    res = requests.get(
        f'https://services.nvd.nist.gov/rest/json/cves/2.0?cveId={cve_id.upper()}',
        timeout=10
    )
    if res.status_code == 404:
        print(f'HTTP 404 - request_cve({cve_id}) not found.')
        return ''
    elif res.status_code == 200:
        response_json = res.json()
        return response_json
