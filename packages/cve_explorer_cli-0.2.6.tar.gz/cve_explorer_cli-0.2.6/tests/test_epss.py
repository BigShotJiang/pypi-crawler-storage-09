import pytest

from cve_explorer_cli.utilities.ext_request import request_epss

def test_display_epss():
    epss_resp = request_epss(args.id)
    _epss = EPSS(
        cve_id=epss_resp['data']['cve'],
        epss_value=epss_resp['data']['epss'],
        percentile=epss_resp['data']['percentile'],
        date=epss_resp['data']['date']
    )
    _epss.display()
