"""CVE Explorer
"""

import json
import argparse
from typing import Any

from yaspin import yaspin
from yaspin.spinners import Spinners
from rich import print_json

from cve_explorer_cli.models.cve import CVE
from cve_explorer_cli.models.epss import EPSS
from cve_explorer_cli.models.cwe import CWE
from cve_explorer_cli.utilities.ext_request import request_cve, request_epss, request_cwe


def get_severity(cve_metrics: Any) -> tuple[str, str, str, str]:
    res_v31, res_v31_base, res_v2, res_v2_base = '', '', '', ''

    if 'cvssMetricV31' in cve_metrics:
        res_v31 = cve_metrics['cvssMetricV31'][0]['impactScore']
        res_v31_base = cve_metrics['cvssMetricV31'][0]['cvssData']['baseSeverity']

    if 'cvssMetricV2' in cve_metrics:
        res_v2 = cve_metrics['cvssMetricV2'][0]['impactScore']
        res_v2_base = cve_metrics['cvssMetricV2'][0]['baseSeverity']
    
    return res_v31, res_v31_base, res_v2, res_v2_base

def handle_cwe(cwe_id: str):
    cwe_resp = request_cwe(cwe_id)
    # print(cwe_resp)
    cwe = CWE(
        cwe_id=cwe_resp['Weaknesses'][0]['ID'],
        name=cwe_resp['Weaknesses'][0]['Name'],
        abstraction=cwe_resp['Weaknesses'][0]['Abstraction'],
        structure=cwe_resp['Weaknesses'][0]['Structure'],
        status=cwe_resp['Weaknesses'][0]['Status'],
        description=cwe_resp['Weaknesses'][0]['Description'],
        extended_description=cwe_resp['Weaknesses'][0]['ExtendedDescription'],
        related_weaknesses=cwe_resp['Weaknesses'][0]['RelatedWeaknesses'],
        applicable_platforms=cwe_resp['Weaknesses'][0]['ApplicablePlatforms'],
        alternate_terms=cwe_resp['Weaknesses'][0]['AlternateTerms'],
        modes_of_introduction=cwe_resp['Weaknesses'][0]['ModesOfIntroduction'],
        common_consequences=cwe_resp['Weaknesses'][0]['CommonConsequences'],
        demonstrative_examples=cwe_resp['Weaknesses'][0]['DemonstrativeExamples'],
        observed_examples=cwe_resp['Weaknesses'][0]['ObservedExamples'],
        taxonomy_mappings=cwe_resp['Weaknesses'][0]['TaxonomyMappings'],
        references=cwe_resp['Weaknesses'][0]['References'],
        mapping_notes=cwe_resp['Weaknesses'][0]['MappingNotes'],
        notes=cwe_resp['Weaknesses'][0]['Notes'],
        content_history=cwe_resp['Weaknesses'][0]['ContentHistory']
    )
    cwe.display()

def main():
    print("Welcome to the CVE Explorer CLI!")

    parser = argparse.ArgumentParser(description="CVE Explorer CLI")
    subparsers = parser.add_subparsers(dest="command")

    # CVE Lookup
    cve_lookup = subparsers.add_parser("lookup", help="Request a single CVE")
    cve_lookup.add_argument("--id", type=str)

    epss_lookup = subparsers.add_parser("epss", help="Request EPSS info for CVE")
    epss_lookup.add_argument("--id", type=str)

    cwe_lookup = subparsers.add_parser("cwe", help="Request CWE info")
    cwe_lookup.add_argument("--id", type=str)

    args = parser.parse_args()

    if args.command == "lookup":
        with yaspin(color="green") as sp:
            sp.spinner = Spinners.arc
            res = request_cve(cve_id=args.id)

            res_v31, res_v31_base, res_v2, res_v2_base = get_severity(res['vulnerabilities'][0]['cve']['metrics'])

            custom_cve = CVE(
                id=res['vulnerabilities'][0]['cve']['id'],
                source_identifier=res['vulnerabilities'][0]['cve']['sourceIdentifier'],
                published=res['vulnerabilities'][0]['cve']['published'],
                last_modified=res['vulnerabilities'][0]['cve']['lastModified'],
                vuln_status=res['vulnerabilities'][0]['cve']['vulnStatus'],
                description=res['vulnerabilities'][0]['cve']['descriptions'][0]['value'],
                # weaknesses=res['vulnerabilities'][0]['cve']['weaknesses'],
                weaknesses=CVE.get_cwe_ids(res['vulnerabilities'][0]['cve']['weaknesses']),
                severity=f"CVSS 3.1: {res_v31} ({res_v31_base}), CVSS 2.0: {res_v2} ({res_v2_base})"
            )
            epss_resp = request_epss(args.id)
            if epss_resp != '':
                _epss = EPSS(
                    cve_id=epss_resp['data'][0]['cve'],
                    epss_value=epss_resp['data'][0]['epss'],
                    percentile=epss_resp['data'][0]['percentile'],
                    date=epss_resp['data'][0]['date']
                )
                custom_cve.epss_value = _epss.epss_value
                custom_cve.epss_percentile = _epss.percentile
                custom_cve.epss_date = _epss.date

            if len(custom_cve.weaknesses) > 0:
                cwe_data = request_cwe(custom_cve.weaknesses[0])
                # print(cwe_data)
                _cwe = CWE(
                    cwe_id=cwe_data['Weaknesses'][0]['ID'],
                    name=cwe_data['Weaknesses'][0]['Name'],
                    abstraction=cwe_data['Weaknesses'][0]['Abstraction'],
                    structure=cwe_data['Weaknesses'][0]['Structure'],
                    status=cwe_data['Weaknesses'][0]['Status'],
                    description=cwe_data['Weaknesses'][0]['Description'],
                    extended_description='',
                    # LikelihoodOfExploit
                    related_weaknesses=cwe_data['Weaknesses'][0]['RelatedWeaknesses'],
                    applicable_platforms=cwe_data['Weaknesses'][0]['ApplicablePlatforms'],
                    alternate_terms='',
                    modes_of_introduction=cwe_data['Weaknesses'][0]['ModesOfIntroduction'],
                    common_consequences=cwe_data['Weaknesses'][0]['CommonConsequences'],
                    demonstrative_examples=cwe_data['Weaknesses'][0]['DemonstrativeExamples'],
                    observed_examples=cwe_data['Weaknesses'][0]['ObservedExamples'],
                    taxonomy_mappings=cwe_data['Weaknesses'][0]['TaxonomyMappings'],
                    references=cwe_data['Weaknesses'][0]['References'],
                    mapping_notes=cwe_data['Weaknesses'][0]['MappingNotes'],
                    notes=cwe_data['Weaknesses'][0]['Notes'],
                    content_history=cwe_data['Weaknesses'][0]['ContentHistory']
                )

                custom_cve.cwe_collection = [{ "cwe_id": _cwe.cwe_id, "description": _cwe.description }]
            
            print("\n")
            custom_cve.display_cve()
            # _cwe.display()

            # TODO: Add a JSON pretty print for CVEs

    elif args.command == "epss":
        epss_resp = request_epss(args.id)
        _epss = EPSS(
            cve_id=epss_resp['data'][0]['cve'],
            epss_value=epss_resp['data'][0]['epss'],
            percentile=epss_resp['data'][0]['percentile'],
            date=epss_resp['data'][0]['date']
        )
        _epss.display()

        # TODO: Add a JSON pretty print in the future
        # print_json(json.dumps(epss_resp)) # JSON pretty print is here
    elif args.command == "cwe":
        handle_cwe(args.id)
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
