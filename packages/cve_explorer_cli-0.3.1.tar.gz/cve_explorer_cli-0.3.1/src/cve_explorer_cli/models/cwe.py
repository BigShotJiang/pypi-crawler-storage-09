from typing import Any

from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich import print_json

class CWE:
    cwe_id: str
    name: str
    abstraction: str
    structure: str
    status: str
    description: str
    extended_description: str
    related_weaknesses: Any
    applicable_platforms: Any
    alternate_terms: Any
    modes_of_introduction: Any
    common_consequences: Any
    demonstrative_examples: Any
    observed_examples: Any
    taxonomy_mappings: Any
    references: Any
    mapping_notes: Any
    notes: Any
    content_history: Any

    def __init__(
        self,
        cwe_id,
        name,
        abstraction,
        structure,
        status,
        description,
        extended_description,
        related_weaknesses,
        applicable_platforms,
        alternate_terms,
        modes_of_introduction,
        common_consequences,
        demonstrative_examples,
        observed_examples,
        taxonomy_mappings,
        references,
        mapping_notes,
        notes,
        content_history
    ):
        self.cwe_id = cwe_id
        self.name = name
        self.abstraction = abstraction
        self.structure = structure
        self.status = status
        self.description = description
        self.extended_description = extended_description
        self.related_weaknesses = related_weaknesses
        self.applicable_platforms = applicable_platforms
        self.alternate_terms = alternate_terms
        self.modes_of_introduction = modes_of_introduction
        self.common_consequences = common_consequences
        self.demonstrative_examples = demonstrative_examples
        self.observed_examples = observed_examples
        self.taxonomy_mappings = taxonomy_mappings
        self.references = references
        self.mapping_notes = mapping_notes
        self.notes = notes
        self.content_history = content_history
    
    def display(self):
        """Display a single CWE
        """
        table = Table(show_header=False, box=None)
        table.add_column("Field", style="bold cyan")
        table.add_column("Value", style="white")

        table.add_row("CWE", f"[bold]{self.cwe_id}[/]")
        table.add_row("Name", f"{self.name}")
        table.add_row("Status", f"{self.status}")
        table.add_row("Alternate Terms", f"{self.alternate_terms}")
        table.add_row("Description", f"{self.description}")

        panel = Panel.fit(
            table,
            title=f"[red]CWE Details[/red]",
            border_style="red"
        )
        console = Console()
        console.print(panel)

        # console.print(f"[green]Description[/green] -- {self.description}")