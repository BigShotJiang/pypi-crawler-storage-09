"""Test suite for CVE Report Aggregator."""
