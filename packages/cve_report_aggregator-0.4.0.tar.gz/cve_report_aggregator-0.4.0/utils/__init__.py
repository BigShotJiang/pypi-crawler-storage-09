"""Scripts package for cve_report_aggregator."""
