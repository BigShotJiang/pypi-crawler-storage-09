from .client import Cybercafe

__all__ = ["Cybercafe"]
