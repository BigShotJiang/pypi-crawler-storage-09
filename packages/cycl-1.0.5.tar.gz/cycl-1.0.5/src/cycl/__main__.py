if __name__ == '__main__':
    from cycl.cli import app

    app()
