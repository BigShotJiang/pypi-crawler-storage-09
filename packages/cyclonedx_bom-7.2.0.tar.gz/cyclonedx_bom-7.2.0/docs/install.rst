Installation
============

Install from pypi.org as you would any other Python module using your preferred package manager:

.. code-block:: sh

   python -m pip install cyclonedx-bom   # install via pip
   pipx install cyclonedx-bom            # install via pipx
   poetry add cyclonedx-bom              # install via poetry
   uv tool install cyclonedx-bom         # install via uv

   # ... you get the hang
