build via :
```shell
python -m build
```
