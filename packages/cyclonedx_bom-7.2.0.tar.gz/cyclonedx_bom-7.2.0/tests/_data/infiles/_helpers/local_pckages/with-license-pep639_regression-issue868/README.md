# PEP 639 - regression 868

see <https://github.com/CycloneDX/cyclonedx-python/issues/868>

PEP-630 expects license gfiles to be UTF8 encoded text.
some license files may not be text, some may not be UTF8 encoded, but still be added as license files.
