A dir that MUST NOT contain any (python (virtual) environment.
This is used in integration tests.
