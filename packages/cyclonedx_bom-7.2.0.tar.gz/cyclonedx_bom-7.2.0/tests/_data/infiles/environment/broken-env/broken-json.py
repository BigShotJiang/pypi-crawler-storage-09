#!/usr/bin/env python3

"""
print broken JSON.
"""

print(r'{"some unfinished json')
exit(0)
