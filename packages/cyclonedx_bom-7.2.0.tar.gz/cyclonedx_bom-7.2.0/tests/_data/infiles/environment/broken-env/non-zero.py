#!/usr/bin/env python3

"""
exit non-zero.
"""

print(r'[]')
exit(1337)
