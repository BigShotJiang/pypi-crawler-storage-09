"""Detection algorithms for various attack types."""

from .monkey_patch import MonkeyPatchDetector

__all__ = ['MonkeyPatchDetector']
