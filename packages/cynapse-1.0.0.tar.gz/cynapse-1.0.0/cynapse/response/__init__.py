"""Response handlers for tamper events."""
