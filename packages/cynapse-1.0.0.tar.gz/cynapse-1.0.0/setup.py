"""
Setup file for cynapse.

This file exists for compatibility with older pip versions.
All configuration is in pyproject.toml.
"""

from setuptools import setup

setup()
