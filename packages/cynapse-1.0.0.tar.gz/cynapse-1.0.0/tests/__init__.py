"""Tests for cynapse."""
