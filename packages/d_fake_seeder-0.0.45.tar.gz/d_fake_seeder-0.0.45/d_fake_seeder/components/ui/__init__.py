"""
User Interface modules for the DFakeSeeder application.

This package contains:
- UI component classes (components/)
- GTK4 XML UI definitions (definitions/)
"""
