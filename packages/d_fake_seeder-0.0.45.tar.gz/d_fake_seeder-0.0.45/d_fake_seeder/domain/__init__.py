"""
Model layer - Data management and business logic
"""
