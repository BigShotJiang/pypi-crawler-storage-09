# By default we diable `numba` caching as it causes problems for parallel execution.
NUMBA_CACHE_ENABLE = False
