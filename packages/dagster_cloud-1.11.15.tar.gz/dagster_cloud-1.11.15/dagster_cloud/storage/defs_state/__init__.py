from dagster_cloud.storage.defs_state.storage import (
    GraphQLDefsStateStorage as GraphQLDefsStateStorage,
)
