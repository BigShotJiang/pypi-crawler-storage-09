from typing import Optional

AgentQueue = Optional[str]
