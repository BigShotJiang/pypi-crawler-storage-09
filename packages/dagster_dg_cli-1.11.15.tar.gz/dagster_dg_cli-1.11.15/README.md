# dagster-dg-cli

Experimental API for scaffolding Dagster projects and components. Includes the `dg` CLI tool.
