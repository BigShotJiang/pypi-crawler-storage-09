from dagster_shared.version import __version__ as __version__
