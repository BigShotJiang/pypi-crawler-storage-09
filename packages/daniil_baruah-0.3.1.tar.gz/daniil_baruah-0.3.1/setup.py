from setuptools import setup, find_packages

setup(
    name='daniil-baruah',
    version='0.3.1',
    packages=find_packages(),
    install_requires=[],
    author='Daniil Baruah',
    author_email="daniilbaruah76@gmail.com",
    description='My first module',
    python_requires='>=3.10',
)
