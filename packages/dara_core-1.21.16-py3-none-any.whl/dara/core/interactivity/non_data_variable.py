from typing_extensions import TypeAlias

from .client_variable import *  # noqa: F403

NonDataVariable: TypeAlias = ClientVariable  # noqa: F405
"""
Deprecated alias for ClientVariable
"""
