﻿das.block_stratify
==================

.. automodule:: das.block_stratify
   :members: