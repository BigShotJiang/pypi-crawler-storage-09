﻿das.evaluate
============

.. automodule:: das.evaluate
   :members: