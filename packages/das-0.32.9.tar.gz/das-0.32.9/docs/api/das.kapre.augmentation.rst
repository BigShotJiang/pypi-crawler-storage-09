﻿das.kapre.augmentation
======================

.. automodule:: das.kapre.augmentation
   :members: