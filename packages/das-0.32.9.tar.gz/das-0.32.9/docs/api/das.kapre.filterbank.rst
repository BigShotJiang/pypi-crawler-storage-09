﻿das.kapre.filterbank
====================

.. automodule:: das.kapre.filterbank
   :members: