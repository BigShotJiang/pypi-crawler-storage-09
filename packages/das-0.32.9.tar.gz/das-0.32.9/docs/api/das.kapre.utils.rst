﻿das.kapre.utils
===============

.. automodule:: das.kapre.utils
   :members: