﻿das.npy_dir
===========

.. automodule:: das.npy_dir
   :members: