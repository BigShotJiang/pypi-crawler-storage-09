﻿das.predict
===========

.. automodule:: das.predict
   :members: