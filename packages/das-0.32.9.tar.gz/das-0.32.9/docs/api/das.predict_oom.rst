﻿das.predict_oom
===============

.. automodule:: das.predict_oom
   :members: