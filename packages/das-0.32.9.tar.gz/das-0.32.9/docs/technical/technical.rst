
.. _tec:

Technical details
=================

Contains technical information about the `command line
interfaces <cli.html>`__ and `data formats <data_formats.html>`__

.. toctree::
   :maxdepth: 1
   :hidden:

   :toctree: tec
   cli
   data_formats


