## _DAS_ tutorials and documentation

- change focal/other animal with `F`/`Z`.
- swap id of focal<->other animal with `X`.
- File/Save swapfile