# Generate segment labels
- why add gaps to training targets
- illustrate effect of "fill gaps" and "remove short"
- two modes
