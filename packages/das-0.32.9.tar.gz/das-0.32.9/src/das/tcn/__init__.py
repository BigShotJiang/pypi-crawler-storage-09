from .tcn import TCN
from .tcn_new import TCN as TCN_new

__version__ = "2.2.3"
