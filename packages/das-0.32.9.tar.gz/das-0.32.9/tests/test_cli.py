import os


def test_cli():
    os.system("das")
    os.system("das train")
    os.system("das predict")
    os.system("das version")
