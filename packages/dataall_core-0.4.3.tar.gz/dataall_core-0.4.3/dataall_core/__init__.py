"""Init Dataall Core."""
