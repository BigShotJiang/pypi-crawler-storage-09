#!//usr/bin/env python3
"""Package stub."""

from .dataclass_documenter import DataclassDocumenter

__all__ = ["DataclassDocumenter"]
