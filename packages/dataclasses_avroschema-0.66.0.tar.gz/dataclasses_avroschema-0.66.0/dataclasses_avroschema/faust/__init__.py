from .main import AvroRecord  # noqa: F401 I001
