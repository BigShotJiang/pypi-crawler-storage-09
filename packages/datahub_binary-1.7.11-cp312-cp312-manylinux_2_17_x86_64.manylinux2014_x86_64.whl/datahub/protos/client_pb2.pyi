from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class QuoteType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    MD_SNAPSHOT: _ClassVar[QuoteType]
    SIGNAL_SNAPSHOT: _ClassVar[QuoteType]
    TICK: _ClassVar[QuoteType]
    ETF_SNAPSHOT: _ClassVar[QuoteType]
    ETF_TICK: _ClassVar[QuoteType]
    PREDICTOR_MATRIX: _ClassVar[QuoteType]

class PosType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    kPosTypeUndefined: _ClassVar[PosType]
    kPosTypeSod: _ClassVar[PosType]
    kPosTypeEod: _ClassVar[PosType]
    kPosTypeFrozen: _ClassVar[PosType]
    kPosTypeBuyIn: _ClassVar[PosType]
    kPosTypeSellOut: _ClassVar[PosType]
    kPosTypeTransIn: _ClassVar[PosType]
    kPosTypeTransOut: _ClassVar[PosType]
    kPosTypeTransAvl: _ClassVar[PosType]
    kPosTypeApplyAvl: _ClassVar[PosType]
    kPosTypeIntraday: _ClassVar[PosType]

class PosReqType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    kReplace: _ClassVar[PosReqType]
    kInit: _ClassVar[PosReqType]
    kDelta: _ClassVar[PosReqType]
    kTransIn: _ClassVar[PosReqType]
    kTransOut: _ClassVar[PosReqType]
    kQuery: _ClassVar[PosReqType]

class PosAccountType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    kSec: _ClassVar[PosAccountType]
    kCash: _ClassVar[PosAccountType]
MD_SNAPSHOT: QuoteType
SIGNAL_SNAPSHOT: QuoteType
TICK: QuoteType
ETF_SNAPSHOT: QuoteType
ETF_TICK: QuoteType
PREDICTOR_MATRIX: QuoteType
kPosTypeUndefined: PosType
kPosTypeSod: PosType
kPosTypeEod: PosType
kPosTypeFrozen: PosType
kPosTypeBuyIn: PosType
kPosTypeSellOut: PosType
kPosTypeTransIn: PosType
kPosTypeTransOut: PosType
kPosTypeTransAvl: PosType
kPosTypeApplyAvl: PosType
kPosTypeIntraday: PosType
kReplace: PosReqType
kInit: PosReqType
kDelta: PosReqType
kTransIn: PosReqType
kTransOut: PosReqType
kQuery: PosReqType
kSec: PosAccountType
kCash: PosAccountType

class Ping(_message.Message):
    __slots__ = ("msg_type", "msg_sequence")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    MSG_SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    msg_sequence: int
    def __init__(self, msg_type: _Optional[int] = ..., msg_sequence: _Optional[int] = ...) -> None: ...

class Pong(_message.Message):
    __slots__ = ("msg_type", "msg_sequence")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    MSG_SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    msg_sequence: int
    def __init__(self, msg_type: _Optional[int] = ..., msg_sequence: _Optional[int] = ...) -> None: ...

class ManagerNotLogin(_message.Message):
    __slots__ = ("msg_type", "last_timestamp")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    last_timestamp: int
    def __init__(self, msg_type: _Optional[int] = ..., last_timestamp: _Optional[int] = ...) -> None: ...

class ManagerErrorMsg(_message.Message):
    __slots__ = ("msg_type", "error_msg", "last_timestamp", "request_id")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    ERROR_MSG_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    error_msg: str
    last_timestamp: int
    request_id: str
    def __init__(self, msg_type: _Optional[int] = ..., error_msg: _Optional[str] = ..., last_timestamp: _Optional[int] = ..., request_id: _Optional[str] = ...) -> None: ...

class ManagerSyncReq(_message.Message):
    __slots__ = ("msg_type", "request_id", "last_timestamp")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    request_id: str
    last_timestamp: int
    def __init__(self, msg_type: _Optional[int] = ..., request_id: _Optional[str] = ..., last_timestamp: _Optional[int] = ...) -> None: ...

class ManagerSyncRsp(_message.Message):
    __slots__ = ("msg_type", "request_id", "last_timestamp", "status", "error_msg")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    ERROR_MSG_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    request_id: str
    last_timestamp: int
    status: int
    error_msg: str
    def __init__(self, msg_type: _Optional[int] = ..., request_id: _Optional[str] = ..., last_timestamp: _Optional[int] = ..., status: _Optional[int] = ..., error_msg: _Optional[str] = ...) -> None: ...

class Order(_message.Message):
    __slots__ = ("order_id", "cl_order_id", "counter_order_id", "order_date", "order_time", "security_id", "market", "security_type", "instrument_id", "appl_id", "contract_unit", "strategy_id", "strategy_name", "account_id", "investor_id", "order_type", "side", "position_effect", "time_in_force", "purpose", "order_qty", "order_price", "order_amt", "order_status", "match_qty", "match_amt", "cancel_qty", "reject_qty", "is_pass", "owner_type", "reject_reason", "text", "is_pre_order", "trigger_time", "parent_order_id", "algo_type", "algo_params", "order_source", "attachment", "cancel_time", "user_id", "risk_info", "op_marks", "symbol", "basket_id")
    ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    CL_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    COUNTER_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    ORDER_DATE_FIELD_NUMBER: _ClassVar[int]
    ORDER_TIME_FIELD_NUMBER: _ClassVar[int]
    SECURITY_ID_FIELD_NUMBER: _ClassVar[int]
    MARKET_FIELD_NUMBER: _ClassVar[int]
    SECURITY_TYPE_FIELD_NUMBER: _ClassVar[int]
    INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    APPL_ID_FIELD_NUMBER: _ClassVar[int]
    CONTRACT_UNIT_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_NAME_FIELD_NUMBER: _ClassVar[int]
    ACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    INVESTOR_ID_FIELD_NUMBER: _ClassVar[int]
    ORDER_TYPE_FIELD_NUMBER: _ClassVar[int]
    SIDE_FIELD_NUMBER: _ClassVar[int]
    POSITION_EFFECT_FIELD_NUMBER: _ClassVar[int]
    TIME_IN_FORCE_FIELD_NUMBER: _ClassVar[int]
    PURPOSE_FIELD_NUMBER: _ClassVar[int]
    ORDER_QTY_FIELD_NUMBER: _ClassVar[int]
    ORDER_PRICE_FIELD_NUMBER: _ClassVar[int]
    ORDER_AMT_FIELD_NUMBER: _ClassVar[int]
    ORDER_STATUS_FIELD_NUMBER: _ClassVar[int]
    MATCH_QTY_FIELD_NUMBER: _ClassVar[int]
    MATCH_AMT_FIELD_NUMBER: _ClassVar[int]
    CANCEL_QTY_FIELD_NUMBER: _ClassVar[int]
    REJECT_QTY_FIELD_NUMBER: _ClassVar[int]
    IS_PASS_FIELD_NUMBER: _ClassVar[int]
    OWNER_TYPE_FIELD_NUMBER: _ClassVar[int]
    REJECT_REASON_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    IS_PRE_ORDER_FIELD_NUMBER: _ClassVar[int]
    TRIGGER_TIME_FIELD_NUMBER: _ClassVar[int]
    PARENT_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    ALGO_TYPE_FIELD_NUMBER: _ClassVar[int]
    ALGO_PARAMS_FIELD_NUMBER: _ClassVar[int]
    ORDER_SOURCE_FIELD_NUMBER: _ClassVar[int]
    ATTACHMENT_FIELD_NUMBER: _ClassVar[int]
    CANCEL_TIME_FIELD_NUMBER: _ClassVar[int]
    USER_ID_FIELD_NUMBER: _ClassVar[int]
    RISK_INFO_FIELD_NUMBER: _ClassVar[int]
    OP_MARKS_FIELD_NUMBER: _ClassVar[int]
    SYMBOL_FIELD_NUMBER: _ClassVar[int]
    BASKET_ID_FIELD_NUMBER: _ClassVar[int]
    order_id: str
    cl_order_id: str
    counter_order_id: str
    order_date: int
    order_time: int
    security_id: str
    market: str
    security_type: str
    instrument_id: str
    appl_id: str
    contract_unit: float
    strategy_id: int
    strategy_name: str
    account_id: str
    investor_id: str
    order_type: int
    side: int
    position_effect: int
    time_in_force: int
    purpose: int
    order_qty: int
    order_price: float
    order_amt: float
    order_status: int
    match_qty: int
    match_amt: float
    cancel_qty: int
    reject_qty: int
    is_pass: int
    owner_type: int
    reject_reason: int
    text: str
    is_pre_order: int
    trigger_time: int
    parent_order_id: str
    algo_type: int
    algo_params: AlgoParams
    order_source: str
    attachment: str
    cancel_time: int
    user_id: str
    risk_info: str
    op_marks: str
    symbol: str
    basket_id: str
    def __init__(self, order_id: _Optional[str] = ..., cl_order_id: _Optional[str] = ..., counter_order_id: _Optional[str] = ..., order_date: _Optional[int] = ..., order_time: _Optional[int] = ..., security_id: _Optional[str] = ..., market: _Optional[str] = ..., security_type: _Optional[str] = ..., instrument_id: _Optional[str] = ..., appl_id: _Optional[str] = ..., contract_unit: _Optional[float] = ..., strategy_id: _Optional[int] = ..., strategy_name: _Optional[str] = ..., account_id: _Optional[str] = ..., investor_id: _Optional[str] = ..., order_type: _Optional[int] = ..., side: _Optional[int] = ..., position_effect: _Optional[int] = ..., time_in_force: _Optional[int] = ..., purpose: _Optional[int] = ..., order_qty: _Optional[int] = ..., order_price: _Optional[float] = ..., order_amt: _Optional[float] = ..., order_status: _Optional[int] = ..., match_qty: _Optional[int] = ..., match_amt: _Optional[float] = ..., cancel_qty: _Optional[int] = ..., reject_qty: _Optional[int] = ..., is_pass: _Optional[int] = ..., owner_type: _Optional[int] = ..., reject_reason: _Optional[int] = ..., text: _Optional[str] = ..., is_pre_order: _Optional[int] = ..., trigger_time: _Optional[int] = ..., parent_order_id: _Optional[str] = ..., algo_type: _Optional[int] = ..., algo_params: _Optional[_Union[AlgoParams, _Mapping]] = ..., order_source: _Optional[str] = ..., attachment: _Optional[str] = ..., cancel_time: _Optional[int] = ..., user_id: _Optional[str] = ..., risk_info: _Optional[str] = ..., op_marks: _Optional[str] = ..., symbol: _Optional[str] = ..., basket_id: _Optional[str] = ...) -> None: ...

class Trade(_message.Message):
    __slots__ = ("order_id", "cl_order_id", "order_date", "order_time", "trade_id", "trade_time", "order_type", "side", "position_effect", "owner_type", "security_id", "market", "security_type", "instrument_id", "appl_id", "contract_unit", "strategy_id", "strategy_name", "account_id", "investor_id", "business_type", "last_qty", "last_px", "last_amt", "match_place", "algo_type", "order_source", "attachment", "user_id", "counter_cl_order_id", "counter_order_id", "symbol", "parent_order_id")
    ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    CL_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    ORDER_DATE_FIELD_NUMBER: _ClassVar[int]
    ORDER_TIME_FIELD_NUMBER: _ClassVar[int]
    TRADE_ID_FIELD_NUMBER: _ClassVar[int]
    TRADE_TIME_FIELD_NUMBER: _ClassVar[int]
    ORDER_TYPE_FIELD_NUMBER: _ClassVar[int]
    SIDE_FIELD_NUMBER: _ClassVar[int]
    POSITION_EFFECT_FIELD_NUMBER: _ClassVar[int]
    OWNER_TYPE_FIELD_NUMBER: _ClassVar[int]
    SECURITY_ID_FIELD_NUMBER: _ClassVar[int]
    MARKET_FIELD_NUMBER: _ClassVar[int]
    SECURITY_TYPE_FIELD_NUMBER: _ClassVar[int]
    INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    APPL_ID_FIELD_NUMBER: _ClassVar[int]
    CONTRACT_UNIT_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_NAME_FIELD_NUMBER: _ClassVar[int]
    ACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    INVESTOR_ID_FIELD_NUMBER: _ClassVar[int]
    BUSINESS_TYPE_FIELD_NUMBER: _ClassVar[int]
    LAST_QTY_FIELD_NUMBER: _ClassVar[int]
    LAST_PX_FIELD_NUMBER: _ClassVar[int]
    LAST_AMT_FIELD_NUMBER: _ClassVar[int]
    MATCH_PLACE_FIELD_NUMBER: _ClassVar[int]
    ALGO_TYPE_FIELD_NUMBER: _ClassVar[int]
    ORDER_SOURCE_FIELD_NUMBER: _ClassVar[int]
    ATTACHMENT_FIELD_NUMBER: _ClassVar[int]
    USER_ID_FIELD_NUMBER: _ClassVar[int]
    COUNTER_CL_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    COUNTER_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    SYMBOL_FIELD_NUMBER: _ClassVar[int]
    PARENT_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    order_id: str
    cl_order_id: str
    order_date: int
    order_time: int
    trade_id: str
    trade_time: int
    order_type: int
    side: int
    position_effect: int
    owner_type: int
    security_id: str
    market: str
    security_type: str
    instrument_id: str
    appl_id: str
    contract_unit: float
    strategy_id: int
    strategy_name: str
    account_id: str
    investor_id: str
    business_type: str
    last_qty: int
    last_px: float
    last_amt: float
    match_place: int
    algo_type: int
    order_source: str
    attachment: str
    user_id: str
    counter_cl_order_id: str
    counter_order_id: str
    symbol: str
    parent_order_id: str
    def __init__(self, order_id: _Optional[str] = ..., cl_order_id: _Optional[str] = ..., order_date: _Optional[int] = ..., order_time: _Optional[int] = ..., trade_id: _Optional[str] = ..., trade_time: _Optional[int] = ..., order_type: _Optional[int] = ..., side: _Optional[int] = ..., position_effect: _Optional[int] = ..., owner_type: _Optional[int] = ..., security_id: _Optional[str] = ..., market: _Optional[str] = ..., security_type: _Optional[str] = ..., instrument_id: _Optional[str] = ..., appl_id: _Optional[str] = ..., contract_unit: _Optional[float] = ..., strategy_id: _Optional[int] = ..., strategy_name: _Optional[str] = ..., account_id: _Optional[str] = ..., investor_id: _Optional[str] = ..., business_type: _Optional[str] = ..., last_qty: _Optional[int] = ..., last_px: _Optional[float] = ..., last_amt: _Optional[float] = ..., match_place: _Optional[int] = ..., algo_type: _Optional[int] = ..., order_source: _Optional[str] = ..., attachment: _Optional[str] = ..., user_id: _Optional[str] = ..., counter_cl_order_id: _Optional[str] = ..., counter_order_id: _Optional[str] = ..., symbol: _Optional[str] = ..., parent_order_id: _Optional[str] = ...) -> None: ...

class Fund(_message.Message):
    __slots__ = ("account_id", "investor_id", "currency_id", "sod", "balance", "frozen", "available", "intraday", "trans_in", "trans_out", "version")
    ACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    INVESTOR_ID_FIELD_NUMBER: _ClassVar[int]
    CURRENCY_ID_FIELD_NUMBER: _ClassVar[int]
    SOD_FIELD_NUMBER: _ClassVar[int]
    BALANCE_FIELD_NUMBER: _ClassVar[int]
    FROZEN_FIELD_NUMBER: _ClassVar[int]
    AVAILABLE_FIELD_NUMBER: _ClassVar[int]
    INTRADAY_FIELD_NUMBER: _ClassVar[int]
    TRANS_IN_FIELD_NUMBER: _ClassVar[int]
    TRANS_OUT_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    account_id: str
    investor_id: str
    currency_id: str
    sod: float
    balance: float
    frozen: float
    available: float
    intraday: float
    trans_in: float
    trans_out: float
    version: int
    def __init__(self, account_id: _Optional[str] = ..., investor_id: _Optional[str] = ..., currency_id: _Optional[str] = ..., sod: _Optional[float] = ..., balance: _Optional[float] = ..., frozen: _Optional[float] = ..., available: _Optional[float] = ..., intraday: _Optional[float] = ..., trans_in: _Optional[float] = ..., trans_out: _Optional[float] = ..., version: _Optional[int] = ...) -> None: ...

class LoginReq(_message.Message):
    __slots__ = ("msg_type", "user_id", "passwd", "last_timestamp", "request_id")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    USER_ID_FIELD_NUMBER: _ClassVar[int]
    PASSWD_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    user_id: str
    passwd: str
    last_timestamp: int
    request_id: str
    def __init__(self, msg_type: _Optional[int] = ..., user_id: _Optional[str] = ..., passwd: _Optional[str] = ..., last_timestamp: _Optional[int] = ..., request_id: _Optional[str] = ...) -> None: ...

class LoginRsp(_message.Message):
    __slots__ = ("msg_type", "is_succ", "error_msg", "last_timestamp", "request_id")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    IS_SUCC_FIELD_NUMBER: _ClassVar[int]
    ERROR_MSG_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    is_succ: bool
    error_msg: str
    last_timestamp: int
    request_id: str
    def __init__(self, msg_type: _Optional[int] = ..., is_succ: bool = ..., error_msg: _Optional[str] = ..., last_timestamp: _Optional[int] = ..., request_id: _Optional[str] = ...) -> None: ...

class SubscribeReq(_message.Message):
    __slots__ = ("msg_type", "sub_type", "quote_type", "instrument_id", "request_id", "last_timestamp")
    class SubscribeType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        SUBSCRIBE: _ClassVar[SubscribeReq.SubscribeType]
        UNSUBSCRIBE: _ClassVar[SubscribeReq.SubscribeType]
    SUBSCRIBE: SubscribeReq.SubscribeType
    UNSUBSCRIBE: SubscribeReq.SubscribeType
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    SUB_TYPE_FIELD_NUMBER: _ClassVar[int]
    QUOTE_TYPE_FIELD_NUMBER: _ClassVar[int]
    INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    sub_type: SubscribeReq.SubscribeType
    quote_type: QuoteType
    instrument_id: str
    request_id: str
    last_timestamp: int
    def __init__(self, msg_type: _Optional[int] = ..., sub_type: _Optional[_Union[SubscribeReq.SubscribeType, str]] = ..., quote_type: _Optional[_Union[QuoteType, str]] = ..., instrument_id: _Optional[str] = ..., request_id: _Optional[str] = ..., last_timestamp: _Optional[int] = ...) -> None: ...

class SubscribeRsp(_message.Message):
    __slots__ = ("msg_type", "is_succ", "error_msg", "last_timestamp", "request_id")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    IS_SUCC_FIELD_NUMBER: _ClassVar[int]
    ERROR_MSG_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    is_succ: bool
    error_msg: str
    last_timestamp: int
    request_id: str
    def __init__(self, msg_type: _Optional[int] = ..., is_succ: bool = ..., error_msg: _Optional[str] = ..., last_timestamp: _Optional[int] = ..., request_id: _Optional[str] = ...) -> None: ...

class QryQuoteReq(_message.Message):
    __slots__ = ("msg_type", "quote_type", "instrument_id", "request_id", "last_timestamp")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    QUOTE_TYPE_FIELD_NUMBER: _ClassVar[int]
    INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    quote_type: QuoteType
    instrument_id: str
    request_id: str
    last_timestamp: int
    def __init__(self, msg_type: _Optional[int] = ..., quote_type: _Optional[_Union[QuoteType, str]] = ..., instrument_id: _Optional[str] = ..., request_id: _Optional[str] = ..., last_timestamp: _Optional[int] = ...) -> None: ...

class QryQuoteRsp(_message.Message):
    __slots__ = ("msg_type", "is_succ", "error_msg", "last_timestamp", "request_id", "is_last", "md_snapshot", "signal_snapshot", "etf_snapshot", "etf_tick", "bar_matrix")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    IS_SUCC_FIELD_NUMBER: _ClassVar[int]
    ERROR_MSG_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    IS_LAST_FIELD_NUMBER: _ClassVar[int]
    MD_SNAPSHOT_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_SNAPSHOT_FIELD_NUMBER: _ClassVar[int]
    ETF_SNAPSHOT_FIELD_NUMBER: _ClassVar[int]
    ETF_TICK_FIELD_NUMBER: _ClassVar[int]
    BAR_MATRIX_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    is_succ: bool
    error_msg: str
    last_timestamp: int
    request_id: str
    is_last: bool
    md_snapshot: _containers.RepeatedCompositeFieldContainer[MDSnapshot]
    signal_snapshot: _containers.RepeatedCompositeFieldContainer[SignalSnapshot]
    etf_snapshot: _containers.RepeatedCompositeFieldContainer[ETFQuoteSnapshot]
    etf_tick: _containers.RepeatedCompositeFieldContainer[ETFQuoteTick]
    bar_matrix: _containers.RepeatedCompositeFieldContainer[BarMatrix]
    def __init__(self, msg_type: _Optional[int] = ..., is_succ: bool = ..., error_msg: _Optional[str] = ..., last_timestamp: _Optional[int] = ..., request_id: _Optional[str] = ..., is_last: bool = ..., md_snapshot: _Optional[_Iterable[_Union[MDSnapshot, _Mapping]]] = ..., signal_snapshot: _Optional[_Iterable[_Union[SignalSnapshot, _Mapping]]] = ..., etf_snapshot: _Optional[_Iterable[_Union[ETFQuoteSnapshot, _Mapping]]] = ..., etf_tick: _Optional[_Iterable[_Union[ETFQuoteTick, _Mapping]]] = ..., bar_matrix: _Optional[_Iterable[_Union[BarMatrix, _Mapping]]] = ...) -> None: ...

class StrategyControlReq(_message.Message):
    __slots__ = ("msg_type", "strategy_id", "strategy_name", "control_type", "operate_type", "last_timestamp", "request_id")
    class ControlType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        kInit: _ClassVar[StrategyControlReq.ControlType]
        kRunning: _ClassVar[StrategyControlReq.ControlType]
        kPause: _ClassVar[StrategyControlReq.ControlType]
        kStop: _ClassVar[StrategyControlReq.ControlType]
    kInit: StrategyControlReq.ControlType
    kRunning: StrategyControlReq.ControlType
    kPause: StrategyControlReq.ControlType
    kStop: StrategyControlReq.ControlType
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_NAME_FIELD_NUMBER: _ClassVar[int]
    CONTROL_TYPE_FIELD_NUMBER: _ClassVar[int]
    OPERATE_TYPE_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    strategy_id: int
    strategy_name: str
    control_type: StrategyControlReq.ControlType
    operate_type: int
    last_timestamp: int
    request_id: str
    def __init__(self, msg_type: _Optional[int] = ..., strategy_id: _Optional[int] = ..., strategy_name: _Optional[str] = ..., control_type: _Optional[_Union[StrategyControlReq.ControlType, str]] = ..., operate_type: _Optional[int] = ..., last_timestamp: _Optional[int] = ..., request_id: _Optional[str] = ...) -> None: ...

class StrategyControlRsp(_message.Message):
    __slots__ = ("msg_type", "strategy_id", "status", "last_timestamp", "text", "request_id")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    strategy_id: int
    status: int
    last_timestamp: int
    text: str
    request_id: str
    def __init__(self, msg_type: _Optional[int] = ..., strategy_id: _Optional[int] = ..., status: _Optional[int] = ..., last_timestamp: _Optional[int] = ..., text: _Optional[str] = ..., request_id: _Optional[str] = ...) -> None: ...

class UpdateStrategyParamsReq(_message.Message):
    __slots__ = ("msg_type", "strategy_name", "strategy_id", "text", "strategy_params", "monitor_params", "last_timestamp", "request_id", "strategy_instruments", "signal_id", "signal_name", "target_qty")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_NAME_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_ID_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_PARAMS_FIELD_NUMBER: _ClassVar[int]
    MONITOR_PARAMS_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_INSTRUMENTS_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_ID_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_NAME_FIELD_NUMBER: _ClassVar[int]
    TARGET_QTY_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    strategy_name: str
    strategy_id: int
    text: str
    strategy_params: str
    monitor_params: str
    last_timestamp: int
    request_id: str
    strategy_instruments: _containers.RepeatedCompositeFieldContainer[StrategyInstrument]
    signal_id: int
    signal_name: str
    target_qty: int
    def __init__(self, msg_type: _Optional[int] = ..., strategy_name: _Optional[str] = ..., strategy_id: _Optional[int] = ..., text: _Optional[str] = ..., strategy_params: _Optional[str] = ..., monitor_params: _Optional[str] = ..., last_timestamp: _Optional[int] = ..., request_id: _Optional[str] = ..., strategy_instruments: _Optional[_Iterable[_Union[StrategyInstrument, _Mapping]]] = ..., signal_id: _Optional[int] = ..., signal_name: _Optional[str] = ..., target_qty: _Optional[int] = ...) -> None: ...

class UpdateStrategyParamsRsp(_message.Message):
    __slots__ = ("msg_type", "strategy_name", "strategy_id", "status", "text", "last_timestamp", "request_id", "strategy_params", "monitor_params", "strategy_instruments", "signal_id", "signal_name", "target_qty")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_NAME_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_PARAMS_FIELD_NUMBER: _ClassVar[int]
    MONITOR_PARAMS_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_INSTRUMENTS_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_ID_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_NAME_FIELD_NUMBER: _ClassVar[int]
    TARGET_QTY_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    strategy_name: str
    strategy_id: int
    status: int
    text: str
    last_timestamp: int
    request_id: str
    strategy_params: str
    monitor_params: str
    strategy_instruments: _containers.RepeatedCompositeFieldContainer[StrategyInstrument]
    signal_id: int
    signal_name: str
    target_qty: int
    def __init__(self, msg_type: _Optional[int] = ..., strategy_name: _Optional[str] = ..., strategy_id: _Optional[int] = ..., status: _Optional[int] = ..., text: _Optional[str] = ..., last_timestamp: _Optional[int] = ..., request_id: _Optional[str] = ..., strategy_params: _Optional[str] = ..., monitor_params: _Optional[str] = ..., strategy_instruments: _Optional[_Iterable[_Union[StrategyInstrument, _Mapping]]] = ..., signal_id: _Optional[int] = ..., signal_name: _Optional[str] = ..., target_qty: _Optional[int] = ...) -> None: ...

class UpdateStrategyParamsEvent(_message.Message):
    __slots__ = ("msg_type", "strategy_name", "strategy_id", "strategy_params", "monitor_params", "text", "last_timestamp", "strategy_instruments", "signal_id", "signal_name", "target_qty")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_NAME_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_PARAMS_FIELD_NUMBER: _ClassVar[int]
    MONITOR_PARAMS_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_INSTRUMENTS_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_ID_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_NAME_FIELD_NUMBER: _ClassVar[int]
    TARGET_QTY_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    strategy_name: str
    strategy_id: int
    strategy_params: str
    monitor_params: str
    text: str
    last_timestamp: int
    strategy_instruments: _containers.RepeatedCompositeFieldContainer[StrategyInstrument]
    signal_id: int
    signal_name: str
    target_qty: int
    def __init__(self, msg_type: _Optional[int] = ..., strategy_name: _Optional[str] = ..., strategy_id: _Optional[int] = ..., strategy_params: _Optional[str] = ..., monitor_params: _Optional[str] = ..., text: _Optional[str] = ..., last_timestamp: _Optional[int] = ..., strategy_instruments: _Optional[_Iterable[_Union[StrategyInstrument, _Mapping]]] = ..., signal_id: _Optional[int] = ..., signal_name: _Optional[str] = ..., target_qty: _Optional[int] = ...) -> None: ...

class UpdateStrategyGlobalParamsReq(_message.Message):
    __slots__ = ("msg_type", "strategy_template_id", "text", "strategy_params", "monitor_params", "last_timestamp", "request_id")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_TEMPLATE_ID_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_PARAMS_FIELD_NUMBER: _ClassVar[int]
    MONITOR_PARAMS_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    strategy_template_id: str
    text: str
    strategy_params: str
    monitor_params: str
    last_timestamp: int
    request_id: str
    def __init__(self, msg_type: _Optional[int] = ..., strategy_template_id: _Optional[str] = ..., text: _Optional[str] = ..., strategy_params: _Optional[str] = ..., monitor_params: _Optional[str] = ..., last_timestamp: _Optional[int] = ..., request_id: _Optional[str] = ...) -> None: ...

class UpdateStrategyGlobalParamsRsp(_message.Message):
    __slots__ = ("msg_type", "strategy_template_id", "status", "text", "last_timestamp", "request_id", "strategy_params", "monitor_params")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_TEMPLATE_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_PARAMS_FIELD_NUMBER: _ClassVar[int]
    MONITOR_PARAMS_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    strategy_template_id: str
    status: int
    text: str
    last_timestamp: int
    request_id: str
    strategy_params: str
    monitor_params: str
    def __init__(self, msg_type: _Optional[int] = ..., strategy_template_id: _Optional[str] = ..., status: _Optional[int] = ..., text: _Optional[str] = ..., last_timestamp: _Optional[int] = ..., request_id: _Optional[str] = ..., strategy_params: _Optional[str] = ..., monitor_params: _Optional[str] = ...) -> None: ...

class UpdateStrategyGlobalParamsEvent(_message.Message):
    __slots__ = ("msg_type", "strategy_template_id", "strategy_params", "monitor_params", "text", "last_timestamp")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_TEMPLATE_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_PARAMS_FIELD_NUMBER: _ClassVar[int]
    MONITOR_PARAMS_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    strategy_template_id: str
    strategy_params: str
    monitor_params: str
    text: str
    last_timestamp: int
    def __init__(self, msg_type: _Optional[int] = ..., strategy_template_id: _Optional[str] = ..., strategy_params: _Optional[str] = ..., monitor_params: _Optional[str] = ..., text: _Optional[str] = ..., last_timestamp: _Optional[int] = ...) -> None: ...

class SaveStrategyParamsToDefaultReq(_message.Message):
    __slots__ = ("msg_type", "request_id", "strategy_id_list")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_ID_LIST_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    request_id: str
    strategy_id_list: _containers.RepeatedScalarFieldContainer[int]
    def __init__(self, msg_type: _Optional[int] = ..., request_id: _Optional[str] = ..., strategy_id_list: _Optional[_Iterable[int]] = ...) -> None: ...

class SaveStrategyParamsToDefaultRsp(_message.Message):
    __slots__ = ("msg_type", "request_id", "strategy_id_list", "status", "text", "last_timestamp")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_ID_LIST_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    request_id: str
    strategy_id_list: _containers.RepeatedScalarFieldContainer[int]
    status: int
    text: str
    last_timestamp: int
    def __init__(self, msg_type: _Optional[int] = ..., request_id: _Optional[str] = ..., strategy_id_list: _Optional[_Iterable[int]] = ..., status: _Optional[int] = ..., text: _Optional[str] = ..., last_timestamp: _Optional[int] = ...) -> None: ...

class ApplyDefaultStrategyParamsReq(_message.Message):
    __slots__ = ("msg_type", "request_id", "strategy_id_list")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_ID_LIST_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    request_id: str
    strategy_id_list: _containers.RepeatedScalarFieldContainer[int]
    def __init__(self, msg_type: _Optional[int] = ..., request_id: _Optional[str] = ..., strategy_id_list: _Optional[_Iterable[int]] = ...) -> None: ...

class ApplyDefaultStrategyParamsRsp(_message.Message):
    __slots__ = ("msg_type", "request_id", "strategy_id_list", "status", "text", "last_timestamp")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_ID_LIST_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    request_id: str
    strategy_id_list: _containers.RepeatedScalarFieldContainer[int]
    status: int
    text: str
    last_timestamp: int
    def __init__(self, msg_type: _Optional[int] = ..., request_id: _Optional[str] = ..., strategy_id_list: _Optional[_Iterable[int]] = ..., status: _Optional[int] = ..., text: _Optional[str] = ..., last_timestamp: _Optional[int] = ...) -> None: ...

class UpdateDefaultStrategyParamsEvent(_message.Message):
    __slots__ = ("msg_type", "strategy_name", "strategy_id", "default_params", "text", "last_timestamp")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_NAME_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_ID_FIELD_NUMBER: _ClassVar[int]
    DEFAULT_PARAMS_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    strategy_name: str
    strategy_id: int
    default_params: str
    text: str
    last_timestamp: int
    def __init__(self, msg_type: _Optional[int] = ..., strategy_name: _Optional[str] = ..., strategy_id: _Optional[int] = ..., default_params: _Optional[str] = ..., text: _Optional[str] = ..., last_timestamp: _Optional[int] = ...) -> None: ...

class QryStrategyStatReq(_message.Message):
    __slots__ = ("msg_type", "text", "last_timestamp", "request_id")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    text: str
    last_timestamp: int
    request_id: str
    def __init__(self, msg_type: _Optional[int] = ..., text: _Optional[str] = ..., last_timestamp: _Optional[int] = ..., request_id: _Optional[str] = ...) -> None: ...

class StrategyStatDetail(_message.Message):
    __slots__ = ("strategy_id", "strategy_name", "strategy_template_id", "status", "instrument_id", "symbol", "expo_qty", "sod_qty", "current_qty", "posi_amount", "last_px", "buy_amount", "sell_amount", "buy_qty", "sell_qty", "expo_amt", "active_order_nums", "text", "avail_qty", "net_change", "best_order_spread", "positon_rate", "trade_side_rate", "net_buy_amount", "total_trade_amount", "trade_rate", "diff2limit", "order_depth", "orders", "bid_premium_rate", "ask_premium_rate", "impact_factor", "theory_price", "original_price", "cost_price", "pre_close_price", "float_pnl", "contract_unit", "posi_adjust_rate", "active_buy_amt", "active_sell_amt", "max_spread_in_target_order_amt", "target_qty", "node_id", "node_name", "active_buy_price", "active_sell_price", "effective_active_amt", "stat_bid_price", "stat_ask_price", "stat_fields", "stat_status", "active_order_qty", "total_order_qty", "total_order_nums", "total_cancel_nums")
    class DepthItem(_message.Message):
        __slots__ = ("price", "volume", "side")
        PRICE_FIELD_NUMBER: _ClassVar[int]
        VOLUME_FIELD_NUMBER: _ClassVar[int]
        SIDE_FIELD_NUMBER: _ClassVar[int]
        price: float
        volume: int
        side: int
        def __init__(self, price: _Optional[float] = ..., volume: _Optional[int] = ..., side: _Optional[int] = ...) -> None: ...
    class OrderItem(_message.Message):
        __slots__ = ("price", "qty", "side", "ids")
        PRICE_FIELD_NUMBER: _ClassVar[int]
        QTY_FIELD_NUMBER: _ClassVar[int]
        SIDE_FIELD_NUMBER: _ClassVar[int]
        IDS_FIELD_NUMBER: _ClassVar[int]
        price: float
        qty: int
        side: int
        ids: _containers.RepeatedScalarFieldContainer[str]
        def __init__(self, price: _Optional[float] = ..., qty: _Optional[int] = ..., side: _Optional[int] = ..., ids: _Optional[_Iterable[str]] = ...) -> None: ...
    STRATEGY_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_NAME_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_TEMPLATE_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    SYMBOL_FIELD_NUMBER: _ClassVar[int]
    EXPO_QTY_FIELD_NUMBER: _ClassVar[int]
    SOD_QTY_FIELD_NUMBER: _ClassVar[int]
    CURRENT_QTY_FIELD_NUMBER: _ClassVar[int]
    POSI_AMOUNT_FIELD_NUMBER: _ClassVar[int]
    LAST_PX_FIELD_NUMBER: _ClassVar[int]
    BUY_AMOUNT_FIELD_NUMBER: _ClassVar[int]
    SELL_AMOUNT_FIELD_NUMBER: _ClassVar[int]
    BUY_QTY_FIELD_NUMBER: _ClassVar[int]
    SELL_QTY_FIELD_NUMBER: _ClassVar[int]
    EXPO_AMT_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_ORDER_NUMS_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    AVAIL_QTY_FIELD_NUMBER: _ClassVar[int]
    NET_CHANGE_FIELD_NUMBER: _ClassVar[int]
    BEST_ORDER_SPREAD_FIELD_NUMBER: _ClassVar[int]
    POSITON_RATE_FIELD_NUMBER: _ClassVar[int]
    TRADE_SIDE_RATE_FIELD_NUMBER: _ClassVar[int]
    NET_BUY_AMOUNT_FIELD_NUMBER: _ClassVar[int]
    TOTAL_TRADE_AMOUNT_FIELD_NUMBER: _ClassVar[int]
    TRADE_RATE_FIELD_NUMBER: _ClassVar[int]
    DIFF2LIMIT_FIELD_NUMBER: _ClassVar[int]
    ORDER_DEPTH_FIELD_NUMBER: _ClassVar[int]
    ORDERS_FIELD_NUMBER: _ClassVar[int]
    BID_PREMIUM_RATE_FIELD_NUMBER: _ClassVar[int]
    ASK_PREMIUM_RATE_FIELD_NUMBER: _ClassVar[int]
    IMPACT_FACTOR_FIELD_NUMBER: _ClassVar[int]
    THEORY_PRICE_FIELD_NUMBER: _ClassVar[int]
    ORIGINAL_PRICE_FIELD_NUMBER: _ClassVar[int]
    COST_PRICE_FIELD_NUMBER: _ClassVar[int]
    PRE_CLOSE_PRICE_FIELD_NUMBER: _ClassVar[int]
    FLOAT_PNL_FIELD_NUMBER: _ClassVar[int]
    CONTRACT_UNIT_FIELD_NUMBER: _ClassVar[int]
    POSI_ADJUST_RATE_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_BUY_AMT_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_SELL_AMT_FIELD_NUMBER: _ClassVar[int]
    MAX_SPREAD_IN_TARGET_ORDER_AMT_FIELD_NUMBER: _ClassVar[int]
    TARGET_QTY_FIELD_NUMBER: _ClassVar[int]
    NODE_ID_FIELD_NUMBER: _ClassVar[int]
    NODE_NAME_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_BUY_PRICE_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_SELL_PRICE_FIELD_NUMBER: _ClassVar[int]
    EFFECTIVE_ACTIVE_AMT_FIELD_NUMBER: _ClassVar[int]
    STAT_BID_PRICE_FIELD_NUMBER: _ClassVar[int]
    STAT_ASK_PRICE_FIELD_NUMBER: _ClassVar[int]
    STAT_FIELDS_FIELD_NUMBER: _ClassVar[int]
    STAT_STATUS_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_ORDER_QTY_FIELD_NUMBER: _ClassVar[int]
    TOTAL_ORDER_QTY_FIELD_NUMBER: _ClassVar[int]
    TOTAL_ORDER_NUMS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_CANCEL_NUMS_FIELD_NUMBER: _ClassVar[int]
    strategy_id: int
    strategy_name: str
    strategy_template_id: str
    status: str
    instrument_id: str
    symbol: str
    expo_qty: int
    sod_qty: int
    current_qty: int
    posi_amount: float
    last_px: float
    buy_amount: float
    sell_amount: float
    buy_qty: int
    sell_qty: int
    expo_amt: float
    active_order_nums: int
    text: str
    avail_qty: int
    net_change: float
    best_order_spread: int
    positon_rate: float
    trade_side_rate: float
    net_buy_amount: float
    total_trade_amount: float
    trade_rate: float
    diff2limit: float
    order_depth: _containers.RepeatedCompositeFieldContainer[StrategyStatDetail.DepthItem]
    orders: _containers.RepeatedCompositeFieldContainer[StrategyStatDetail.OrderItem]
    bid_premium_rate: float
    ask_premium_rate: float
    impact_factor: float
    theory_price: float
    original_price: float
    cost_price: float
    pre_close_price: float
    float_pnl: float
    contract_unit: float
    posi_adjust_rate: float
    active_buy_amt: float
    active_sell_amt: float
    max_spread_in_target_order_amt: int
    target_qty: int
    node_id: int
    node_name: str
    active_buy_price: float
    active_sell_price: float
    effective_active_amt: float
    stat_bid_price: float
    stat_ask_price: float
    stat_fields: str
    stat_status: int
    active_order_qty: int
    total_order_qty: int
    total_order_nums: int
    total_cancel_nums: int
    def __init__(self, strategy_id: _Optional[int] = ..., strategy_name: _Optional[str] = ..., strategy_template_id: _Optional[str] = ..., status: _Optional[str] = ..., instrument_id: _Optional[str] = ..., symbol: _Optional[str] = ..., expo_qty: _Optional[int] = ..., sod_qty: _Optional[int] = ..., current_qty: _Optional[int] = ..., posi_amount: _Optional[float] = ..., last_px: _Optional[float] = ..., buy_amount: _Optional[float] = ..., sell_amount: _Optional[float] = ..., buy_qty: _Optional[int] = ..., sell_qty: _Optional[int] = ..., expo_amt: _Optional[float] = ..., active_order_nums: _Optional[int] = ..., text: _Optional[str] = ..., avail_qty: _Optional[int] = ..., net_change: _Optional[float] = ..., best_order_spread: _Optional[int] = ..., positon_rate: _Optional[float] = ..., trade_side_rate: _Optional[float] = ..., net_buy_amount: _Optional[float] = ..., total_trade_amount: _Optional[float] = ..., trade_rate: _Optional[float] = ..., diff2limit: _Optional[float] = ..., order_depth: _Optional[_Iterable[_Union[StrategyStatDetail.DepthItem, _Mapping]]] = ..., orders: _Optional[_Iterable[_Union[StrategyStatDetail.OrderItem, _Mapping]]] = ..., bid_premium_rate: _Optional[float] = ..., ask_premium_rate: _Optional[float] = ..., impact_factor: _Optional[float] = ..., theory_price: _Optional[float] = ..., original_price: _Optional[float] = ..., cost_price: _Optional[float] = ..., pre_close_price: _Optional[float] = ..., float_pnl: _Optional[float] = ..., contract_unit: _Optional[float] = ..., posi_adjust_rate: _Optional[float] = ..., active_buy_amt: _Optional[float] = ..., active_sell_amt: _Optional[float] = ..., max_spread_in_target_order_amt: _Optional[int] = ..., target_qty: _Optional[int] = ..., node_id: _Optional[int] = ..., node_name: _Optional[str] = ..., active_buy_price: _Optional[float] = ..., active_sell_price: _Optional[float] = ..., effective_active_amt: _Optional[float] = ..., stat_bid_price: _Optional[float] = ..., stat_ask_price: _Optional[float] = ..., stat_fields: _Optional[str] = ..., stat_status: _Optional[int] = ..., active_order_qty: _Optional[int] = ..., total_order_qty: _Optional[int] = ..., total_order_nums: _Optional[int] = ..., total_cancel_nums: _Optional[int] = ...) -> None: ...

class QryStrategyStatRsp(_message.Message):
    __slots__ = ("msg_type", "last_timestamp", "request_id", "status", "text")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    last_timestamp: int
    request_id: str
    status: int
    text: str
    def __init__(self, msg_type: _Optional[int] = ..., last_timestamp: _Optional[int] = ..., request_id: _Optional[str] = ..., status: _Optional[int] = ..., text: _Optional[str] = ...) -> None: ...

class StrategyStatEvent(_message.Message):
    __slots__ = ("msg_type", "msg_sequence", "strategy_id", "strategy_name", "strategy_stat", "last_timestamp")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    MSG_SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_NAME_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_STAT_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    msg_sequence: int
    strategy_id: int
    strategy_name: str
    strategy_stat: StrategyStatDetail
    last_timestamp: int
    def __init__(self, msg_type: _Optional[int] = ..., msg_sequence: _Optional[int] = ..., strategy_id: _Optional[int] = ..., strategy_name: _Optional[str] = ..., strategy_stat: _Optional[_Union[StrategyStatDetail, _Mapping]] = ..., last_timestamp: _Optional[int] = ...) -> None: ...

class StrategyLogEvent(_message.Message):
    __slots__ = ("msg_type", "strategy_id", "strategy_name", "log_level", "occur_time", "file_name", "function_name", "line", "text", "last_timestamp", "node_name", "node_type")
    class LogLevel(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        TRACE: _ClassVar[StrategyLogEvent.LogLevel]
        DEBUG: _ClassVar[StrategyLogEvent.LogLevel]
        INFO: _ClassVar[StrategyLogEvent.LogLevel]
        WARN: _ClassVar[StrategyLogEvent.LogLevel]
        ERROR: _ClassVar[StrategyLogEvent.LogLevel]
        FATAL: _ClassVar[StrategyLogEvent.LogLevel]
    TRACE: StrategyLogEvent.LogLevel
    DEBUG: StrategyLogEvent.LogLevel
    INFO: StrategyLogEvent.LogLevel
    WARN: StrategyLogEvent.LogLevel
    ERROR: StrategyLogEvent.LogLevel
    FATAL: StrategyLogEvent.LogLevel
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_NAME_FIELD_NUMBER: _ClassVar[int]
    LOG_LEVEL_FIELD_NUMBER: _ClassVar[int]
    OCCUR_TIME_FIELD_NUMBER: _ClassVar[int]
    FILE_NAME_FIELD_NUMBER: _ClassVar[int]
    FUNCTION_NAME_FIELD_NUMBER: _ClassVar[int]
    LINE_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    NODE_NAME_FIELD_NUMBER: _ClassVar[int]
    NODE_TYPE_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    strategy_id: int
    strategy_name: str
    log_level: StrategyLogEvent.LogLevel
    occur_time: int
    file_name: str
    function_name: str
    line: int
    text: str
    last_timestamp: int
    node_name: str
    node_type: int
    def __init__(self, msg_type: _Optional[int] = ..., strategy_id: _Optional[int] = ..., strategy_name: _Optional[str] = ..., log_level: _Optional[_Union[StrategyLogEvent.LogLevel, str]] = ..., occur_time: _Optional[int] = ..., file_name: _Optional[str] = ..., function_name: _Optional[str] = ..., line: _Optional[int] = ..., text: _Optional[str] = ..., last_timestamp: _Optional[int] = ..., node_name: _Optional[str] = ..., node_type: _Optional[int] = ...) -> None: ...

class QryStrategyLogReq(_message.Message):
    __slots__ = ("msg_type", "request_id", "start_time")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    START_TIME_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    request_id: str
    start_time: int
    def __init__(self, msg_type: _Optional[int] = ..., request_id: _Optional[str] = ..., start_time: _Optional[int] = ...) -> None: ...

class QryStrategyLogRsp(_message.Message):
    __slots__ = ("msg_type", "request_id", "status", "text", "logs", "is_last")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    LOGS_FIELD_NUMBER: _ClassVar[int]
    IS_LAST_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    request_id: str
    status: int
    text: str
    logs: _containers.RepeatedCompositeFieldContainer[StrategyLogEvent]
    is_last: bool
    def __init__(self, msg_type: _Optional[int] = ..., request_id: _Optional[str] = ..., status: _Optional[int] = ..., text: _Optional[str] = ..., logs: _Optional[_Iterable[_Union[StrategyLogEvent, _Mapping]]] = ..., is_last: bool = ...) -> None: ...

class ArbitrageStrategyStatEvent(_message.Message):
    __slots__ = ("msg_type", "strategy_id", "strategy_name", "signal_id", "status", "reason", "last_timestamp")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_NAME_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    strategy_id: int
    strategy_name: str
    signal_id: int
    status: str
    reason: str
    last_timestamp: int
    def __init__(self, msg_type: _Optional[int] = ..., strategy_id: _Optional[int] = ..., strategy_name: _Optional[str] = ..., signal_id: _Optional[int] = ..., status: _Optional[str] = ..., reason: _Optional[str] = ..., last_timestamp: _Optional[int] = ...) -> None: ...

class StrategyInstrumentStat(_message.Message):
    __slots__ = ("strategy_name", "instrument_id", "book_id", "account_id", "strategy_id", "sod_qty", "trade_pnl", "total_pnl", "current_qty", "trade_qty", "trade_amount", "last_price", "fee", "buy_qty", "sell_qty", "buy_amount", "sell_amount", "buy_pnl", "sell_pnl", "buy_avg_price", "sell_avg_price", "prev_close", "sod_pnl", "symbol")
    STRATEGY_NAME_FIELD_NUMBER: _ClassVar[int]
    INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    BOOK_ID_FIELD_NUMBER: _ClassVar[int]
    ACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_ID_FIELD_NUMBER: _ClassVar[int]
    SOD_QTY_FIELD_NUMBER: _ClassVar[int]
    TRADE_PNL_FIELD_NUMBER: _ClassVar[int]
    TOTAL_PNL_FIELD_NUMBER: _ClassVar[int]
    CURRENT_QTY_FIELD_NUMBER: _ClassVar[int]
    TRADE_QTY_FIELD_NUMBER: _ClassVar[int]
    TRADE_AMOUNT_FIELD_NUMBER: _ClassVar[int]
    LAST_PRICE_FIELD_NUMBER: _ClassVar[int]
    FEE_FIELD_NUMBER: _ClassVar[int]
    BUY_QTY_FIELD_NUMBER: _ClassVar[int]
    SELL_QTY_FIELD_NUMBER: _ClassVar[int]
    BUY_AMOUNT_FIELD_NUMBER: _ClassVar[int]
    SELL_AMOUNT_FIELD_NUMBER: _ClassVar[int]
    BUY_PNL_FIELD_NUMBER: _ClassVar[int]
    SELL_PNL_FIELD_NUMBER: _ClassVar[int]
    BUY_AVG_PRICE_FIELD_NUMBER: _ClassVar[int]
    SELL_AVG_PRICE_FIELD_NUMBER: _ClassVar[int]
    PREV_CLOSE_FIELD_NUMBER: _ClassVar[int]
    SOD_PNL_FIELD_NUMBER: _ClassVar[int]
    SYMBOL_FIELD_NUMBER: _ClassVar[int]
    strategy_name: str
    instrument_id: str
    book_id: str
    account_id: str
    strategy_id: int
    sod_qty: int
    trade_pnl: float
    total_pnl: float
    current_qty: int
    trade_qty: int
    trade_amount: float
    last_price: float
    fee: float
    buy_qty: int
    sell_qty: int
    buy_amount: float
    sell_amount: float
    buy_pnl: float
    sell_pnl: float
    buy_avg_price: float
    sell_avg_price: float
    prev_close: float
    sod_pnl: float
    symbol: str
    def __init__(self, strategy_name: _Optional[str] = ..., instrument_id: _Optional[str] = ..., book_id: _Optional[str] = ..., account_id: _Optional[str] = ..., strategy_id: _Optional[int] = ..., sod_qty: _Optional[int] = ..., trade_pnl: _Optional[float] = ..., total_pnl: _Optional[float] = ..., current_qty: _Optional[int] = ..., trade_qty: _Optional[int] = ..., trade_amount: _Optional[float] = ..., last_price: _Optional[float] = ..., fee: _Optional[float] = ..., buy_qty: _Optional[int] = ..., sell_qty: _Optional[int] = ..., buy_amount: _Optional[float] = ..., sell_amount: _Optional[float] = ..., buy_pnl: _Optional[float] = ..., sell_pnl: _Optional[float] = ..., buy_avg_price: _Optional[float] = ..., sell_avg_price: _Optional[float] = ..., prev_close: _Optional[float] = ..., sod_pnl: _Optional[float] = ..., symbol: _Optional[str] = ...) -> None: ...

class StrategySummary(_message.Message):
    __slots__ = ("strategy_name", "book_id", "account_id", "strategy_id", "trade_pnl", "total_pnl", "trade_amount", "total_amount", "fee", "buy_amount", "sell_amount", "buy_pnl", "sell_pnl", "sod_pnl", "stats", "total_instruments")
    STRATEGY_NAME_FIELD_NUMBER: _ClassVar[int]
    BOOK_ID_FIELD_NUMBER: _ClassVar[int]
    ACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_ID_FIELD_NUMBER: _ClassVar[int]
    TRADE_PNL_FIELD_NUMBER: _ClassVar[int]
    TOTAL_PNL_FIELD_NUMBER: _ClassVar[int]
    TRADE_AMOUNT_FIELD_NUMBER: _ClassVar[int]
    TOTAL_AMOUNT_FIELD_NUMBER: _ClassVar[int]
    FEE_FIELD_NUMBER: _ClassVar[int]
    BUY_AMOUNT_FIELD_NUMBER: _ClassVar[int]
    SELL_AMOUNT_FIELD_NUMBER: _ClassVar[int]
    BUY_PNL_FIELD_NUMBER: _ClassVar[int]
    SELL_PNL_FIELD_NUMBER: _ClassVar[int]
    SOD_PNL_FIELD_NUMBER: _ClassVar[int]
    STATS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_INSTRUMENTS_FIELD_NUMBER: _ClassVar[int]
    strategy_name: str
    book_id: str
    account_id: str
    strategy_id: int
    trade_pnl: float
    total_pnl: float
    trade_amount: float
    total_amount: float
    fee: float
    buy_amount: float
    sell_amount: float
    buy_pnl: float
    sell_pnl: float
    sod_pnl: float
    stats: _containers.RepeatedCompositeFieldContainer[StrategyInstrumentStat]
    total_instruments: int
    def __init__(self, strategy_name: _Optional[str] = ..., book_id: _Optional[str] = ..., account_id: _Optional[str] = ..., strategy_id: _Optional[int] = ..., trade_pnl: _Optional[float] = ..., total_pnl: _Optional[float] = ..., trade_amount: _Optional[float] = ..., total_amount: _Optional[float] = ..., fee: _Optional[float] = ..., buy_amount: _Optional[float] = ..., sell_amount: _Optional[float] = ..., buy_pnl: _Optional[float] = ..., sell_pnl: _Optional[float] = ..., sod_pnl: _Optional[float] = ..., stats: _Optional[_Iterable[_Union[StrategyInstrumentStat, _Mapping]]] = ..., total_instruments: _Optional[int] = ...) -> None: ...

class Book(_message.Message):
    __slots__ = ("book_id", "comments", "settle_currency_id", "exposure", "trade_pnl", "total_pnl", "book_type", "is_auto_hedge", "auto_hedge_strategy_id", "auto_hedge_strategy_name", "strategy_summaries", "last_timestamp", "long_exposure", "short_exposure", "sod_pnl")
    BOOK_ID_FIELD_NUMBER: _ClassVar[int]
    COMMENTS_FIELD_NUMBER: _ClassVar[int]
    SETTLE_CURRENCY_ID_FIELD_NUMBER: _ClassVar[int]
    EXPOSURE_FIELD_NUMBER: _ClassVar[int]
    TRADE_PNL_FIELD_NUMBER: _ClassVar[int]
    TOTAL_PNL_FIELD_NUMBER: _ClassVar[int]
    BOOK_TYPE_FIELD_NUMBER: _ClassVar[int]
    IS_AUTO_HEDGE_FIELD_NUMBER: _ClassVar[int]
    AUTO_HEDGE_STRATEGY_ID_FIELD_NUMBER: _ClassVar[int]
    AUTO_HEDGE_STRATEGY_NAME_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_SUMMARIES_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    LONG_EXPOSURE_FIELD_NUMBER: _ClassVar[int]
    SHORT_EXPOSURE_FIELD_NUMBER: _ClassVar[int]
    SOD_PNL_FIELD_NUMBER: _ClassVar[int]
    book_id: str
    comments: str
    settle_currency_id: str
    exposure: float
    trade_pnl: float
    total_pnl: float
    book_type: str
    is_auto_hedge: int
    auto_hedge_strategy_id: int
    auto_hedge_strategy_name: str
    strategy_summaries: _containers.RepeatedCompositeFieldContainer[StrategySummary]
    last_timestamp: int
    long_exposure: float
    short_exposure: float
    sod_pnl: float
    def __init__(self, book_id: _Optional[str] = ..., comments: _Optional[str] = ..., settle_currency_id: _Optional[str] = ..., exposure: _Optional[float] = ..., trade_pnl: _Optional[float] = ..., total_pnl: _Optional[float] = ..., book_type: _Optional[str] = ..., is_auto_hedge: _Optional[int] = ..., auto_hedge_strategy_id: _Optional[int] = ..., auto_hedge_strategy_name: _Optional[str] = ..., strategy_summaries: _Optional[_Iterable[_Union[StrategySummary, _Mapping]]] = ..., last_timestamp: _Optional[int] = ..., long_exposure: _Optional[float] = ..., short_exposure: _Optional[float] = ..., sod_pnl: _Optional[float] = ...) -> None: ...

class BookStatEvent(_message.Message):
    __slots__ = ("msg_type", "book")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    BOOK_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    book: Book
    def __init__(self, msg_type: _Optional[int] = ..., book: _Optional[_Union[Book, _Mapping]] = ...) -> None: ...

class QryBookStatReq(_message.Message):
    __slots__ = ("msg_type", "book_id", "request_id")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    BOOK_ID_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    book_id: str
    request_id: str
    def __init__(self, msg_type: _Optional[int] = ..., book_id: _Optional[str] = ..., request_id: _Optional[str] = ...) -> None: ...

class QryBookStatRsp(_message.Message):
    __slots__ = ("msg_type", "books", "request_id", "status", "text")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    BOOKS_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    books: _containers.RepeatedCompositeFieldContainer[Book]
    request_id: str
    status: int
    text: str
    def __init__(self, msg_type: _Optional[int] = ..., books: _Optional[_Iterable[_Union[Book, _Mapping]]] = ..., request_id: _Optional[str] = ..., status: _Optional[int] = ..., text: _Optional[str] = ...) -> None: ...

class SignalControlReq(_message.Message):
    __slots__ = ("msg_type", "last_timestamp", "request_id", "operate_type", "signal_id", "signal_name", "control_type")
    class ControlType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        kInit: _ClassVar[SignalControlReq.ControlType]
        kRun: _ClassVar[SignalControlReq.ControlType]
        kPause: _ClassVar[SignalControlReq.ControlType]
        kStop: _ClassVar[SignalControlReq.ControlType]
        kClose: _ClassVar[SignalControlReq.ControlType]
    kInit: SignalControlReq.ControlType
    kRun: SignalControlReq.ControlType
    kPause: SignalControlReq.ControlType
    kStop: SignalControlReq.ControlType
    kClose: SignalControlReq.ControlType
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    OPERATE_TYPE_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_ID_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_NAME_FIELD_NUMBER: _ClassVar[int]
    CONTROL_TYPE_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    last_timestamp: int
    request_id: str
    operate_type: int
    signal_id: int
    signal_name: str
    control_type: SignalControlReq.ControlType
    def __init__(self, msg_type: _Optional[int] = ..., last_timestamp: _Optional[int] = ..., request_id: _Optional[str] = ..., operate_type: _Optional[int] = ..., signal_id: _Optional[int] = ..., signal_name: _Optional[str] = ..., control_type: _Optional[_Union[SignalControlReq.ControlType, str]] = ...) -> None: ...

class SignalControlRsp(_message.Message):
    __slots__ = ("msg_type", "node_name", "node_type", "last_timestamp", "request_id", "signal_name", "signal_id", "status", "text")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    NODE_NAME_FIELD_NUMBER: _ClassVar[int]
    NODE_TYPE_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_NAME_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    node_name: str
    node_type: int
    last_timestamp: int
    request_id: str
    signal_name: str
    signal_id: int
    status: int
    text: str
    def __init__(self, msg_type: _Optional[int] = ..., node_name: _Optional[str] = ..., node_type: _Optional[int] = ..., last_timestamp: _Optional[int] = ..., request_id: _Optional[str] = ..., signal_name: _Optional[str] = ..., signal_id: _Optional[int] = ..., status: _Optional[int] = ..., text: _Optional[str] = ...) -> None: ...

class QryFundReq(_message.Message):
    __slots__ = ("msg_type", "node_name", "node_type", "request_id", "start_row", "page_size")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    NODE_NAME_FIELD_NUMBER: _ClassVar[int]
    NODE_TYPE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    START_ROW_FIELD_NUMBER: _ClassVar[int]
    PAGE_SIZE_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    node_name: str
    node_type: int
    request_id: str
    start_row: int
    page_size: int
    def __init__(self, msg_type: _Optional[int] = ..., node_name: _Optional[str] = ..., node_type: _Optional[int] = ..., request_id: _Optional[str] = ..., start_row: _Optional[int] = ..., page_size: _Optional[int] = ...) -> None: ...

class QryFundRsp(_message.Message):
    __slots__ = ("msg_type", "request_id", "total_row", "start_row", "page_size", "is_last", "status", "reason", "fund")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    TOTAL_ROW_FIELD_NUMBER: _ClassVar[int]
    START_ROW_FIELD_NUMBER: _ClassVar[int]
    PAGE_SIZE_FIELD_NUMBER: _ClassVar[int]
    IS_LAST_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    FUND_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    request_id: str
    total_row: int
    start_row: int
    page_size: int
    is_last: bool
    status: int
    reason: str
    fund: _containers.RepeatedCompositeFieldContainer[Fund]
    def __init__(self, msg_type: _Optional[int] = ..., request_id: _Optional[str] = ..., total_row: _Optional[int] = ..., start_row: _Optional[int] = ..., page_size: _Optional[int] = ..., is_last: bool = ..., status: _Optional[int] = ..., reason: _Optional[str] = ..., fund: _Optional[_Iterable[_Union[Fund, _Mapping]]] = ...) -> None: ...

class QryPosiReq(_message.Message):
    __slots__ = ("msg_type", "request_id", "security_id", "market", "account_id", "node_name", "node_type")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    SECURITY_ID_FIELD_NUMBER: _ClassVar[int]
    MARKET_FIELD_NUMBER: _ClassVar[int]
    ACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    NODE_NAME_FIELD_NUMBER: _ClassVar[int]
    NODE_TYPE_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    request_id: str
    security_id: str
    market: str
    account_id: str
    node_name: str
    node_type: int
    def __init__(self, msg_type: _Optional[int] = ..., request_id: _Optional[str] = ..., security_id: _Optional[str] = ..., market: _Optional[str] = ..., account_id: _Optional[str] = ..., node_name: _Optional[str] = ..., node_type: _Optional[int] = ...) -> None: ...

class QryPosiRsp(_message.Message):
    __slots__ = ("msg_type", "msg_sequence", "request_id", "total_row", "start_row", "page_size", "is_last", "status", "reason", "position")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    MSG_SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    TOTAL_ROW_FIELD_NUMBER: _ClassVar[int]
    START_ROW_FIELD_NUMBER: _ClassVar[int]
    PAGE_SIZE_FIELD_NUMBER: _ClassVar[int]
    IS_LAST_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    POSITION_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    msg_sequence: int
    request_id: str
    total_row: int
    start_row: int
    page_size: int
    is_last: bool
    status: int
    reason: str
    position: _containers.RepeatedCompositeFieldContainer[Position]
    def __init__(self, msg_type: _Optional[int] = ..., msg_sequence: _Optional[int] = ..., request_id: _Optional[str] = ..., total_row: _Optional[int] = ..., start_row: _Optional[int] = ..., page_size: _Optional[int] = ..., is_last: bool = ..., status: _Optional[int] = ..., reason: _Optional[str] = ..., position: _Optional[_Iterable[_Union[Position, _Mapping]]] = ...) -> None: ...

class QryBrokerPosiReq(_message.Message):
    __slots__ = ("msg_type", "request_id", "account_id", "start_row", "page_size")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    ACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    START_ROW_FIELD_NUMBER: _ClassVar[int]
    PAGE_SIZE_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    request_id: str
    account_id: str
    start_row: int
    page_size: int
    def __init__(self, msg_type: _Optional[int] = ..., request_id: _Optional[str] = ..., account_id: _Optional[str] = ..., start_row: _Optional[int] = ..., page_size: _Optional[int] = ...) -> None: ...

class QryBrokerPosiRsp(_message.Message):
    __slots__ = ("msg_type", "node_name", "node_type", "msg_sequence", "request_id", "total_row", "start_row", "page_size", "is_last", "status", "reason", "position", "last_timestamp")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    NODE_NAME_FIELD_NUMBER: _ClassVar[int]
    NODE_TYPE_FIELD_NUMBER: _ClassVar[int]
    MSG_SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    TOTAL_ROW_FIELD_NUMBER: _ClassVar[int]
    START_ROW_FIELD_NUMBER: _ClassVar[int]
    PAGE_SIZE_FIELD_NUMBER: _ClassVar[int]
    IS_LAST_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    POSITION_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    node_name: str
    node_type: int
    msg_sequence: int
    request_id: str
    total_row: int
    start_row: int
    page_size: int
    is_last: bool
    status: int
    reason: str
    position: _containers.RepeatedCompositeFieldContainer[Position]
    last_timestamp: int
    def __init__(self, msg_type: _Optional[int] = ..., node_name: _Optional[str] = ..., node_type: _Optional[int] = ..., msg_sequence: _Optional[int] = ..., request_id: _Optional[str] = ..., total_row: _Optional[int] = ..., start_row: _Optional[int] = ..., page_size: _Optional[int] = ..., is_last: bool = ..., status: _Optional[int] = ..., reason: _Optional[str] = ..., position: _Optional[_Iterable[_Union[Position, _Mapping]]] = ..., last_timestamp: _Optional[int] = ...) -> None: ...

class QryBrokerFundReq(_message.Message):
    __slots__ = ("msg_type", "node_type", "node_name", "account_id", "request_id", "start_row", "page_size")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    NODE_TYPE_FIELD_NUMBER: _ClassVar[int]
    NODE_NAME_FIELD_NUMBER: _ClassVar[int]
    ACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    START_ROW_FIELD_NUMBER: _ClassVar[int]
    PAGE_SIZE_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    node_type: int
    node_name: str
    account_id: str
    request_id: str
    start_row: int
    page_size: int
    def __init__(self, msg_type: _Optional[int] = ..., node_type: _Optional[int] = ..., node_name: _Optional[str] = ..., account_id: _Optional[str] = ..., request_id: _Optional[str] = ..., start_row: _Optional[int] = ..., page_size: _Optional[int] = ...) -> None: ...

class QryBrokerFundRsp(_message.Message):
    __slots__ = ("msg_type", "node_name", "node_type", "msg_sequence", "request_id", "total_row", "start_row", "page_size", "is_last", "status", "reason", "fund", "last_timestamp")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    NODE_NAME_FIELD_NUMBER: _ClassVar[int]
    NODE_TYPE_FIELD_NUMBER: _ClassVar[int]
    MSG_SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    TOTAL_ROW_FIELD_NUMBER: _ClassVar[int]
    START_ROW_FIELD_NUMBER: _ClassVar[int]
    PAGE_SIZE_FIELD_NUMBER: _ClassVar[int]
    IS_LAST_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    FUND_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    node_name: str
    node_type: int
    msg_sequence: int
    request_id: str
    total_row: int
    start_row: int
    page_size: int
    is_last: bool
    status: int
    reason: str
    fund: _containers.RepeatedCompositeFieldContainer[Fund]
    last_timestamp: int
    def __init__(self, msg_type: _Optional[int] = ..., node_name: _Optional[str] = ..., node_type: _Optional[int] = ..., msg_sequence: _Optional[int] = ..., request_id: _Optional[str] = ..., total_row: _Optional[int] = ..., start_row: _Optional[int] = ..., page_size: _Optional[int] = ..., is_last: bool = ..., status: _Optional[int] = ..., reason: _Optional[str] = ..., fund: _Optional[_Iterable[_Union[Fund, _Mapping]]] = ..., last_timestamp: _Optional[int] = ...) -> None: ...

class StrategyPosition(_message.Message):
    __slots__ = ("strategy_id", "strategy_name", "instrument_id", "target_qty", "sod_qty", "current_qty", "posi_amount", "last_px", "buy_amount", "sell_amount", "buy_qty", "sell_qty", "avail_qty", "contract_unit", "sod_amount", "account_id", "book_id", "prev_close")
    STRATEGY_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_NAME_FIELD_NUMBER: _ClassVar[int]
    INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    TARGET_QTY_FIELD_NUMBER: _ClassVar[int]
    SOD_QTY_FIELD_NUMBER: _ClassVar[int]
    CURRENT_QTY_FIELD_NUMBER: _ClassVar[int]
    POSI_AMOUNT_FIELD_NUMBER: _ClassVar[int]
    LAST_PX_FIELD_NUMBER: _ClassVar[int]
    BUY_AMOUNT_FIELD_NUMBER: _ClassVar[int]
    SELL_AMOUNT_FIELD_NUMBER: _ClassVar[int]
    BUY_QTY_FIELD_NUMBER: _ClassVar[int]
    SELL_QTY_FIELD_NUMBER: _ClassVar[int]
    AVAIL_QTY_FIELD_NUMBER: _ClassVar[int]
    CONTRACT_UNIT_FIELD_NUMBER: _ClassVar[int]
    SOD_AMOUNT_FIELD_NUMBER: _ClassVar[int]
    ACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    BOOK_ID_FIELD_NUMBER: _ClassVar[int]
    PREV_CLOSE_FIELD_NUMBER: _ClassVar[int]
    strategy_id: int
    strategy_name: str
    instrument_id: str
    target_qty: int
    sod_qty: int
    current_qty: int
    posi_amount: float
    last_px: float
    buy_amount: float
    sell_amount: float
    buy_qty: int
    sell_qty: int
    avail_qty: int
    contract_unit: float
    sod_amount: float
    account_id: str
    book_id: str
    prev_close: float
    def __init__(self, strategy_id: _Optional[int] = ..., strategy_name: _Optional[str] = ..., instrument_id: _Optional[str] = ..., target_qty: _Optional[int] = ..., sod_qty: _Optional[int] = ..., current_qty: _Optional[int] = ..., posi_amount: _Optional[float] = ..., last_px: _Optional[float] = ..., buy_amount: _Optional[float] = ..., sell_amount: _Optional[float] = ..., buy_qty: _Optional[int] = ..., sell_qty: _Optional[int] = ..., avail_qty: _Optional[int] = ..., contract_unit: _Optional[float] = ..., sod_amount: _Optional[float] = ..., account_id: _Optional[str] = ..., book_id: _Optional[str] = ..., prev_close: _Optional[float] = ...) -> None: ...

class QryStrategyPositionReq(_message.Message):
    __slots__ = ("msg_type", "book_id", "request_id", "last_timestamp")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    BOOK_ID_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    book_id: str
    request_id: str
    last_timestamp: int
    def __init__(self, msg_type: _Optional[int] = ..., book_id: _Optional[str] = ..., request_id: _Optional[str] = ..., last_timestamp: _Optional[int] = ...) -> None: ...

class QryStrategyPositionRsp(_message.Message):
    __slots__ = ("msg_type", "strategy_positions", "request_id", "status", "reason", "last_timestamp")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_POSITIONS_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    strategy_positions: _containers.RepeatedCompositeFieldContainer[StrategyPosition]
    request_id: str
    status: int
    reason: str
    last_timestamp: int
    def __init__(self, msg_type: _Optional[int] = ..., strategy_positions: _Optional[_Iterable[_Union[StrategyPosition, _Mapping]]] = ..., request_id: _Optional[str] = ..., status: _Optional[int] = ..., reason: _Optional[str] = ..., last_timestamp: _Optional[int] = ...) -> None: ...

class QrySblListReq(_message.Message):
    __slots__ = ("msg_type", "strategy_id", "sbl_ids", "request_id", "last_timestamp")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_ID_FIELD_NUMBER: _ClassVar[int]
    SBL_IDS_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    strategy_id: int
    sbl_ids: _containers.RepeatedScalarFieldContainer[str]
    request_id: str
    last_timestamp: int
    def __init__(self, msg_type: _Optional[int] = ..., strategy_id: _Optional[int] = ..., sbl_ids: _Optional[_Iterable[str]] = ..., request_id: _Optional[str] = ..., last_timestamp: _Optional[int] = ...) -> None: ...

class SblList(_message.Message):
    __slots__ = ("sbl_id", "broker", "trade_date", "instrument_id", "intrate", "avail_sbl_qty")
    SBL_ID_FIELD_NUMBER: _ClassVar[int]
    BROKER_FIELD_NUMBER: _ClassVar[int]
    TRADE_DATE_FIELD_NUMBER: _ClassVar[int]
    INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    INTRATE_FIELD_NUMBER: _ClassVar[int]
    AVAIL_SBL_QTY_FIELD_NUMBER: _ClassVar[int]
    sbl_id: str
    broker: str
    trade_date: str
    instrument_id: str
    intrate: float
    avail_sbl_qty: int
    def __init__(self, sbl_id: _Optional[str] = ..., broker: _Optional[str] = ..., trade_date: _Optional[str] = ..., instrument_id: _Optional[str] = ..., intrate: _Optional[float] = ..., avail_sbl_qty: _Optional[int] = ...) -> None: ...

class QrySblListRsp(_message.Message):
    __slots__ = ("msg_type", "sbl_list", "request_id", "status", "reason", "last_timestamp")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    SBL_LIST_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    sbl_list: _containers.RepeatedCompositeFieldContainer[SblList]
    request_id: str
    status: int
    reason: str
    last_timestamp: int
    def __init__(self, msg_type: _Optional[int] = ..., sbl_list: _Optional[_Iterable[_Union[SblList, _Mapping]]] = ..., request_id: _Optional[str] = ..., status: _Optional[int] = ..., reason: _Optional[str] = ..., last_timestamp: _Optional[int] = ...) -> None: ...

class LockSblReq(_message.Message):
    __slots__ = ("msg_type", "strategy_id", "instrument_id", "lock_qty", "cl_order_id", "last_timestamp", "sbl_id")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_ID_FIELD_NUMBER: _ClassVar[int]
    INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    LOCK_QTY_FIELD_NUMBER: _ClassVar[int]
    CL_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    SBL_ID_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    strategy_id: int
    instrument_id: str
    lock_qty: int
    cl_order_id: str
    last_timestamp: int
    sbl_id: str
    def __init__(self, msg_type: _Optional[int] = ..., strategy_id: _Optional[int] = ..., instrument_id: _Optional[str] = ..., lock_qty: _Optional[int] = ..., cl_order_id: _Optional[str] = ..., last_timestamp: _Optional[int] = ..., sbl_id: _Optional[str] = ...) -> None: ...

class LockSblRsp(_message.Message):
    __slots__ = ("msg_type", "strategy_id", "account_id", "instrument_id", "locked_qty", "intrate", "status", "duration", "reason", "cl_order_id", "last_timestamp", "sbl_id")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_ID_FIELD_NUMBER: _ClassVar[int]
    ACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    LOCKED_QTY_FIELD_NUMBER: _ClassVar[int]
    INTRATE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    DURATION_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    CL_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    SBL_ID_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    strategy_id: int
    account_id: str
    instrument_id: str
    locked_qty: int
    intrate: float
    status: int
    duration: int
    reason: str
    cl_order_id: str
    last_timestamp: int
    sbl_id: str
    def __init__(self, msg_type: _Optional[int] = ..., strategy_id: _Optional[int] = ..., account_id: _Optional[str] = ..., instrument_id: _Optional[str] = ..., locked_qty: _Optional[int] = ..., intrate: _Optional[float] = ..., status: _Optional[int] = ..., duration: _Optional[int] = ..., reason: _Optional[str] = ..., cl_order_id: _Optional[str] = ..., last_timestamp: _Optional[int] = ..., sbl_id: _Optional[str] = ...) -> None: ...

class QryLockRecordReq(_message.Message):
    __slots__ = ("msg_type", "strategy_id", "instrument_id", "request_id", "last_timestamp")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_ID_FIELD_NUMBER: _ClassVar[int]
    INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    strategy_id: int
    instrument_id: str
    request_id: str
    last_timestamp: int
    def __init__(self, msg_type: _Optional[int] = ..., strategy_id: _Optional[int] = ..., instrument_id: _Optional[str] = ..., request_id: _Optional[str] = ..., last_timestamp: _Optional[int] = ...) -> None: ...

class LockRecord(_message.Message):
    __slots__ = ("sbl_id", "instrument_id", "locked_qty", "intrate", "status", "reason", "cl_order_id", "duration", "request_time", "response_time", "counter_order_id")
    SBL_ID_FIELD_NUMBER: _ClassVar[int]
    INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    LOCKED_QTY_FIELD_NUMBER: _ClassVar[int]
    INTRATE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    CL_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    DURATION_FIELD_NUMBER: _ClassVar[int]
    REQUEST_TIME_FIELD_NUMBER: _ClassVar[int]
    RESPONSE_TIME_FIELD_NUMBER: _ClassVar[int]
    COUNTER_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    sbl_id: str
    instrument_id: str
    locked_qty: int
    intrate: float
    status: int
    reason: str
    cl_order_id: str
    duration: int
    request_time: int
    response_time: int
    counter_order_id: int
    def __init__(self, sbl_id: _Optional[str] = ..., instrument_id: _Optional[str] = ..., locked_qty: _Optional[int] = ..., intrate: _Optional[float] = ..., status: _Optional[int] = ..., reason: _Optional[str] = ..., cl_order_id: _Optional[str] = ..., duration: _Optional[int] = ..., request_time: _Optional[int] = ..., response_time: _Optional[int] = ..., counter_order_id: _Optional[int] = ...) -> None: ...

class QryLockRecordRsp(_message.Message):
    __slots__ = ("msg_type", "account_id", "strategy_id", "lock_records", "request_id", "status", "reason", "last_timestamp")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    ACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_ID_FIELD_NUMBER: _ClassVar[int]
    LOCK_RECORDS_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    account_id: str
    strategy_id: int
    lock_records: _containers.RepeatedCompositeFieldContainer[LockRecord]
    request_id: str
    status: int
    reason: str
    last_timestamp: int
    def __init__(self, msg_type: _Optional[int] = ..., account_id: _Optional[str] = ..., strategy_id: _Optional[int] = ..., lock_records: _Optional[_Iterable[_Union[LockRecord, _Mapping]]] = ..., request_id: _Optional[str] = ..., status: _Optional[int] = ..., reason: _Optional[str] = ..., last_timestamp: _Optional[int] = ...) -> None: ...

class QryLockPositionReq(_message.Message):
    __slots__ = ("msg_type", "strategy_id", "instrument_id", "last_timestamp", "request_id")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_ID_FIELD_NUMBER: _ClassVar[int]
    INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    strategy_id: int
    instrument_id: str
    last_timestamp: int
    request_id: str
    def __init__(self, msg_type: _Optional[int] = ..., strategy_id: _Optional[int] = ..., instrument_id: _Optional[str] = ..., last_timestamp: _Optional[int] = ..., request_id: _Optional[str] = ...) -> None: ...

class LockPosition(_message.Message):
    __slots__ = ("trade_date", "instrument_id", "long_quota_limit_qty", "long_available_qty", "short_quota_limit_qty", "short_available_qty", "update_time")
    TRADE_DATE_FIELD_NUMBER: _ClassVar[int]
    INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    LONG_QUOTA_LIMIT_QTY_FIELD_NUMBER: _ClassVar[int]
    LONG_AVAILABLE_QTY_FIELD_NUMBER: _ClassVar[int]
    SHORT_QUOTA_LIMIT_QTY_FIELD_NUMBER: _ClassVar[int]
    SHORT_AVAILABLE_QTY_FIELD_NUMBER: _ClassVar[int]
    UPDATE_TIME_FIELD_NUMBER: _ClassVar[int]
    trade_date: str
    instrument_id: str
    long_quota_limit_qty: int
    long_available_qty: int
    short_quota_limit_qty: int
    short_available_qty: int
    update_time: int
    def __init__(self, trade_date: _Optional[str] = ..., instrument_id: _Optional[str] = ..., long_quota_limit_qty: _Optional[int] = ..., long_available_qty: _Optional[int] = ..., short_quota_limit_qty: _Optional[int] = ..., short_available_qty: _Optional[int] = ..., update_time: _Optional[int] = ...) -> None: ...

class QryLockPositionRsp(_message.Message):
    __slots__ = ("msg_type", "strategy_id", "account_id", "lock_positions", "status", "reason", "last_timestamp", "request_id")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_ID_FIELD_NUMBER: _ClassVar[int]
    ACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    LOCK_POSITIONS_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    strategy_id: int
    account_id: str
    lock_positions: _containers.RepeatedCompositeFieldContainer[LockPosition]
    status: int
    reason: str
    last_timestamp: int
    request_id: str
    def __init__(self, msg_type: _Optional[int] = ..., strategy_id: _Optional[int] = ..., account_id: _Optional[str] = ..., lock_positions: _Optional[_Iterable[_Union[LockPosition, _Mapping]]] = ..., status: _Optional[int] = ..., reason: _Optional[str] = ..., last_timestamp: _Optional[int] = ..., request_id: _Optional[str] = ...) -> None: ...

class Position(_message.Message):
    __slots__ = ("account_id", "investor_id", "market", "security_id", "security_type", "symbol", "posi_side", "instrument_id", "sod", "balance", "available", "frozen", "buy_in", "sell_out", "trans_in", "trans_out", "trans_avl", "apply_avl", "cost_price", "realized_pnl", "version", "last_price", "market_value")
    ACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    INVESTOR_ID_FIELD_NUMBER: _ClassVar[int]
    MARKET_FIELD_NUMBER: _ClassVar[int]
    SECURITY_ID_FIELD_NUMBER: _ClassVar[int]
    SECURITY_TYPE_FIELD_NUMBER: _ClassVar[int]
    SYMBOL_FIELD_NUMBER: _ClassVar[int]
    POSI_SIDE_FIELD_NUMBER: _ClassVar[int]
    INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    SOD_FIELD_NUMBER: _ClassVar[int]
    BALANCE_FIELD_NUMBER: _ClassVar[int]
    AVAILABLE_FIELD_NUMBER: _ClassVar[int]
    FROZEN_FIELD_NUMBER: _ClassVar[int]
    BUY_IN_FIELD_NUMBER: _ClassVar[int]
    SELL_OUT_FIELD_NUMBER: _ClassVar[int]
    TRANS_IN_FIELD_NUMBER: _ClassVar[int]
    TRANS_OUT_FIELD_NUMBER: _ClassVar[int]
    TRANS_AVL_FIELD_NUMBER: _ClassVar[int]
    APPLY_AVL_FIELD_NUMBER: _ClassVar[int]
    COST_PRICE_FIELD_NUMBER: _ClassVar[int]
    REALIZED_PNL_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    LAST_PRICE_FIELD_NUMBER: _ClassVar[int]
    MARKET_VALUE_FIELD_NUMBER: _ClassVar[int]
    account_id: str
    investor_id: str
    market: str
    security_id: str
    security_type: str
    symbol: str
    posi_side: int
    instrument_id: str
    sod: int
    balance: int
    available: int
    frozen: int
    buy_in: int
    sell_out: int
    trans_in: int
    trans_out: int
    trans_avl: int
    apply_avl: int
    cost_price: float
    realized_pnl: float
    version: int
    last_price: float
    market_value: float
    def __init__(self, account_id: _Optional[str] = ..., investor_id: _Optional[str] = ..., market: _Optional[str] = ..., security_id: _Optional[str] = ..., security_type: _Optional[str] = ..., symbol: _Optional[str] = ..., posi_side: _Optional[int] = ..., instrument_id: _Optional[str] = ..., sod: _Optional[int] = ..., balance: _Optional[int] = ..., available: _Optional[int] = ..., frozen: _Optional[int] = ..., buy_in: _Optional[int] = ..., sell_out: _Optional[int] = ..., trans_in: _Optional[int] = ..., trans_out: _Optional[int] = ..., trans_avl: _Optional[int] = ..., apply_avl: _Optional[int] = ..., cost_price: _Optional[float] = ..., realized_pnl: _Optional[float] = ..., version: _Optional[int] = ..., last_price: _Optional[float] = ..., market_value: _Optional[float] = ...) -> None: ...

class PositionQty(_message.Message):
    __slots__ = ("type", "qty")
    TYPE_FIELD_NUMBER: _ClassVar[int]
    QTY_FIELD_NUMBER: _ClassVar[int]
    type: PosType
    qty: int
    def __init__(self, type: _Optional[_Union[PosType, str]] = ..., qty: _Optional[int] = ...) -> None: ...

class RequestForPosition(_message.Message):
    __slots__ = ("msg_type", "request_id", "pos_req_type", "account_id", "investor_id", "node_name", "version", "market", "security_id", "posi_side", "pos_qty")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    POS_REQ_TYPE_FIELD_NUMBER: _ClassVar[int]
    ACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    INVESTOR_ID_FIELD_NUMBER: _ClassVar[int]
    NODE_NAME_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    MARKET_FIELD_NUMBER: _ClassVar[int]
    SECURITY_ID_FIELD_NUMBER: _ClassVar[int]
    POSI_SIDE_FIELD_NUMBER: _ClassVar[int]
    POS_QTY_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    request_id: str
    pos_req_type: PosReqType
    account_id: str
    investor_id: str
    node_name: str
    version: int
    market: str
    security_id: str
    posi_side: int
    pos_qty: _containers.RepeatedCompositeFieldContainer[PositionQty]
    def __init__(self, msg_type: _Optional[int] = ..., request_id: _Optional[str] = ..., pos_req_type: _Optional[_Union[PosReqType, str]] = ..., account_id: _Optional[str] = ..., investor_id: _Optional[str] = ..., node_name: _Optional[str] = ..., version: _Optional[int] = ..., market: _Optional[str] = ..., security_id: _Optional[str] = ..., posi_side: _Optional[int] = ..., pos_qty: _Optional[_Iterable[_Union[PositionQty, _Mapping]]] = ...) -> None: ...

class PositionReport(_message.Message):
    __slots__ = ("msg_type", "msg_sequence", "node_name", "request_id", "pos_req_type", "pos_account_type", "pos_rpt_id", "status", "text", "is_last", "version", "account_id", "investor_id", "market", "security_id", "balance", "available", "cost_price", "realized_pnl", "symbol", "security_type", "posi_side", "pos_qty")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    MSG_SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    NODE_NAME_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    POS_REQ_TYPE_FIELD_NUMBER: _ClassVar[int]
    POS_ACCOUNT_TYPE_FIELD_NUMBER: _ClassVar[int]
    POS_RPT_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    IS_LAST_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    ACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    INVESTOR_ID_FIELD_NUMBER: _ClassVar[int]
    MARKET_FIELD_NUMBER: _ClassVar[int]
    SECURITY_ID_FIELD_NUMBER: _ClassVar[int]
    BALANCE_FIELD_NUMBER: _ClassVar[int]
    AVAILABLE_FIELD_NUMBER: _ClassVar[int]
    COST_PRICE_FIELD_NUMBER: _ClassVar[int]
    REALIZED_PNL_FIELD_NUMBER: _ClassVar[int]
    SYMBOL_FIELD_NUMBER: _ClassVar[int]
    SECURITY_TYPE_FIELD_NUMBER: _ClassVar[int]
    POSI_SIDE_FIELD_NUMBER: _ClassVar[int]
    POS_QTY_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    msg_sequence: int
    node_name: str
    request_id: str
    pos_req_type: PosReqType
    pos_account_type: PosAccountType
    pos_rpt_id: str
    status: int
    text: str
    is_last: bool
    version: int
    account_id: str
    investor_id: str
    market: str
    security_id: str
    balance: int
    available: int
    cost_price: int
    realized_pnl: int
    symbol: str
    security_type: str
    posi_side: int
    pos_qty: _containers.RepeatedCompositeFieldContainer[PositionQty]
    def __init__(self, msg_type: _Optional[int] = ..., msg_sequence: _Optional[int] = ..., node_name: _Optional[str] = ..., request_id: _Optional[str] = ..., pos_req_type: _Optional[_Union[PosReqType, str]] = ..., pos_account_type: _Optional[_Union[PosAccountType, str]] = ..., pos_rpt_id: _Optional[str] = ..., status: _Optional[int] = ..., text: _Optional[str] = ..., is_last: bool = ..., version: _Optional[int] = ..., account_id: _Optional[str] = ..., investor_id: _Optional[str] = ..., market: _Optional[str] = ..., security_id: _Optional[str] = ..., balance: _Optional[int] = ..., available: _Optional[int] = ..., cost_price: _Optional[int] = ..., realized_pnl: _Optional[int] = ..., symbol: _Optional[str] = ..., security_type: _Optional[str] = ..., posi_side: _Optional[int] = ..., pos_qty: _Optional[_Iterable[_Union[PositionQty, _Mapping]]] = ...) -> None: ...

class AlgoParams(_message.Message):
    __slots__ = ("algo_name", "begin_time", "end_time", "duration_seconds", "interval_seconds", "order_price_level", "shift_price_tick", "price_limit", "max_active_order_nums", "price_cage", "custom_param", "expire_time")
    ALGO_NAME_FIELD_NUMBER: _ClassVar[int]
    BEGIN_TIME_FIELD_NUMBER: _ClassVar[int]
    END_TIME_FIELD_NUMBER: _ClassVar[int]
    DURATION_SECONDS_FIELD_NUMBER: _ClassVar[int]
    INTERVAL_SECONDS_FIELD_NUMBER: _ClassVar[int]
    ORDER_PRICE_LEVEL_FIELD_NUMBER: _ClassVar[int]
    SHIFT_PRICE_TICK_FIELD_NUMBER: _ClassVar[int]
    PRICE_LIMIT_FIELD_NUMBER: _ClassVar[int]
    MAX_ACTIVE_ORDER_NUMS_FIELD_NUMBER: _ClassVar[int]
    PRICE_CAGE_FIELD_NUMBER: _ClassVar[int]
    CUSTOM_PARAM_FIELD_NUMBER: _ClassVar[int]
    EXPIRE_TIME_FIELD_NUMBER: _ClassVar[int]
    algo_name: str
    begin_time: int
    end_time: int
    duration_seconds: int
    interval_seconds: int
    order_price_level: int
    shift_price_tick: int
    price_limit: float
    max_active_order_nums: int
    price_cage: float
    custom_param: str
    expire_time: int
    def __init__(self, algo_name: _Optional[str] = ..., begin_time: _Optional[int] = ..., end_time: _Optional[int] = ..., duration_seconds: _Optional[int] = ..., interval_seconds: _Optional[int] = ..., order_price_level: _Optional[int] = ..., shift_price_tick: _Optional[int] = ..., price_limit: _Optional[float] = ..., max_active_order_nums: _Optional[int] = ..., price_cage: _Optional[float] = ..., custom_param: _Optional[str] = ..., expire_time: _Optional[int] = ...) -> None: ...

class PlaceOrder(_message.Message):
    __slots__ = ("msg_type", "cl_order_id", "instrument_id", "strategy_id", "strategy_name", "account_id", "investor_id", "is_pre_order", "trigger_time", "order_type", "side", "position_effect", "time_in_force", "purpose", "stop_px", "order_price", "order_qty", "is_pass", "owner_type", "algo_type", "algo_params", "order_source", "attachment", "parent_order_id", "basket_id")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    CL_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_NAME_FIELD_NUMBER: _ClassVar[int]
    ACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    INVESTOR_ID_FIELD_NUMBER: _ClassVar[int]
    IS_PRE_ORDER_FIELD_NUMBER: _ClassVar[int]
    TRIGGER_TIME_FIELD_NUMBER: _ClassVar[int]
    ORDER_TYPE_FIELD_NUMBER: _ClassVar[int]
    SIDE_FIELD_NUMBER: _ClassVar[int]
    POSITION_EFFECT_FIELD_NUMBER: _ClassVar[int]
    TIME_IN_FORCE_FIELD_NUMBER: _ClassVar[int]
    PURPOSE_FIELD_NUMBER: _ClassVar[int]
    STOP_PX_FIELD_NUMBER: _ClassVar[int]
    ORDER_PRICE_FIELD_NUMBER: _ClassVar[int]
    ORDER_QTY_FIELD_NUMBER: _ClassVar[int]
    IS_PASS_FIELD_NUMBER: _ClassVar[int]
    OWNER_TYPE_FIELD_NUMBER: _ClassVar[int]
    ALGO_TYPE_FIELD_NUMBER: _ClassVar[int]
    ALGO_PARAMS_FIELD_NUMBER: _ClassVar[int]
    ORDER_SOURCE_FIELD_NUMBER: _ClassVar[int]
    ATTACHMENT_FIELD_NUMBER: _ClassVar[int]
    PARENT_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    BASKET_ID_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    cl_order_id: str
    instrument_id: str
    strategy_id: int
    strategy_name: str
    account_id: str
    investor_id: str
    is_pre_order: int
    trigger_time: int
    order_type: int
    side: int
    position_effect: int
    time_in_force: int
    purpose: int
    stop_px: float
    order_price: float
    order_qty: int
    is_pass: int
    owner_type: int
    algo_type: int
    algo_params: AlgoParams
    order_source: str
    attachment: str
    parent_order_id: str
    basket_id: str
    def __init__(self, msg_type: _Optional[int] = ..., cl_order_id: _Optional[str] = ..., instrument_id: _Optional[str] = ..., strategy_id: _Optional[int] = ..., strategy_name: _Optional[str] = ..., account_id: _Optional[str] = ..., investor_id: _Optional[str] = ..., is_pre_order: _Optional[int] = ..., trigger_time: _Optional[int] = ..., order_type: _Optional[int] = ..., side: _Optional[int] = ..., position_effect: _Optional[int] = ..., time_in_force: _Optional[int] = ..., purpose: _Optional[int] = ..., stop_px: _Optional[float] = ..., order_price: _Optional[float] = ..., order_qty: _Optional[int] = ..., is_pass: _Optional[int] = ..., owner_type: _Optional[int] = ..., algo_type: _Optional[int] = ..., algo_params: _Optional[_Union[AlgoParams, _Mapping]] = ..., order_source: _Optional[str] = ..., attachment: _Optional[str] = ..., parent_order_id: _Optional[str] = ..., basket_id: _Optional[str] = ...) -> None: ...

class BookTradeReq(_message.Message):
    __slots__ = ("msg_type", "operate_type", "cl_order_id", "instrument_id", "strategy_id", "strategy_name", "order_type", "position_effect", "purpose", "order_price", "order_qty", "order_source", "request_id", "business_type")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    OPERATE_TYPE_FIELD_NUMBER: _ClassVar[int]
    CL_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_NAME_FIELD_NUMBER: _ClassVar[int]
    ORDER_TYPE_FIELD_NUMBER: _ClassVar[int]
    POSITION_EFFECT_FIELD_NUMBER: _ClassVar[int]
    PURPOSE_FIELD_NUMBER: _ClassVar[int]
    ORDER_PRICE_FIELD_NUMBER: _ClassVar[int]
    ORDER_QTY_FIELD_NUMBER: _ClassVar[int]
    ORDER_SOURCE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    BUSINESS_TYPE_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    operate_type: str
    cl_order_id: str
    instrument_id: str
    strategy_id: int
    strategy_name: str
    order_type: int
    position_effect: int
    purpose: int
    order_price: float
    order_qty: int
    order_source: str
    request_id: str
    business_type: str
    def __init__(self, msg_type: _Optional[int] = ..., operate_type: _Optional[str] = ..., cl_order_id: _Optional[str] = ..., instrument_id: _Optional[str] = ..., strategy_id: _Optional[int] = ..., strategy_name: _Optional[str] = ..., order_type: _Optional[int] = ..., position_effect: _Optional[int] = ..., purpose: _Optional[int] = ..., order_price: _Optional[float] = ..., order_qty: _Optional[int] = ..., order_source: _Optional[str] = ..., request_id: _Optional[str] = ..., business_type: _Optional[str] = ...) -> None: ...

class BookTradeRsp(_message.Message):
    __slots__ = ("msg_type", "request_id", "status", "reason", "last_timestamp", "cl_order_id", "operate_type")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    CL_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    OPERATE_TYPE_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    request_id: str
    status: int
    reason: str
    last_timestamp: int
    cl_order_id: str
    operate_type: str
    def __init__(self, msg_type: _Optional[int] = ..., request_id: _Optional[str] = ..., status: _Optional[int] = ..., reason: _Optional[str] = ..., last_timestamp: _Optional[int] = ..., cl_order_id: _Optional[str] = ..., operate_type: _Optional[str] = ...) -> None: ...

class OrderPendingConfirm(_message.Message):
    __slots__ = ("msg_type", "msg_sequence", "cl_order_id", "order_id", "security_id", "market", "instrument_id", "appl_id", "strategy_id", "strategy_name", "account_id", "investor_id", "confirm_qty", "reject_qty", "is_pass")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    MSG_SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    CL_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    SECURITY_ID_FIELD_NUMBER: _ClassVar[int]
    MARKET_FIELD_NUMBER: _ClassVar[int]
    INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    APPL_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_NAME_FIELD_NUMBER: _ClassVar[int]
    ACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    INVESTOR_ID_FIELD_NUMBER: _ClassVar[int]
    CONFIRM_QTY_FIELD_NUMBER: _ClassVar[int]
    REJECT_QTY_FIELD_NUMBER: _ClassVar[int]
    IS_PASS_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    msg_sequence: int
    cl_order_id: str
    order_id: str
    security_id: str
    market: str
    instrument_id: str
    appl_id: str
    strategy_id: int
    strategy_name: str
    account_id: str
    investor_id: str
    confirm_qty: int
    reject_qty: int
    is_pass: int
    def __init__(self, msg_type: _Optional[int] = ..., msg_sequence: _Optional[int] = ..., cl_order_id: _Optional[str] = ..., order_id: _Optional[str] = ..., security_id: _Optional[str] = ..., market: _Optional[str] = ..., instrument_id: _Optional[str] = ..., appl_id: _Optional[str] = ..., strategy_id: _Optional[int] = ..., strategy_name: _Optional[str] = ..., account_id: _Optional[str] = ..., investor_id: _Optional[str] = ..., confirm_qty: _Optional[int] = ..., reject_qty: _Optional[int] = ..., is_pass: _Optional[int] = ...) -> None: ...

class OrderConfirm(_message.Message):
    __slots__ = ("msg_type", "msg_sequence", "cl_order_id", "order_id", "counter_order_id", "security_id", "market", "instrument_id", "appl_id", "strategy_id", "strategy_name", "account_id", "investor_id", "confirm_qty", "reject_qty", "is_pass", "order_price", "contract_unit")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    MSG_SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    CL_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    COUNTER_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    SECURITY_ID_FIELD_NUMBER: _ClassVar[int]
    MARKET_FIELD_NUMBER: _ClassVar[int]
    INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    APPL_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_NAME_FIELD_NUMBER: _ClassVar[int]
    ACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    INVESTOR_ID_FIELD_NUMBER: _ClassVar[int]
    CONFIRM_QTY_FIELD_NUMBER: _ClassVar[int]
    REJECT_QTY_FIELD_NUMBER: _ClassVar[int]
    IS_PASS_FIELD_NUMBER: _ClassVar[int]
    ORDER_PRICE_FIELD_NUMBER: _ClassVar[int]
    CONTRACT_UNIT_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    msg_sequence: int
    cl_order_id: str
    order_id: str
    counter_order_id: str
    security_id: str
    market: str
    instrument_id: str
    appl_id: str
    strategy_id: int
    strategy_name: str
    account_id: str
    investor_id: str
    confirm_qty: int
    reject_qty: int
    is_pass: int
    order_price: float
    contract_unit: float
    def __init__(self, msg_type: _Optional[int] = ..., msg_sequence: _Optional[int] = ..., cl_order_id: _Optional[str] = ..., order_id: _Optional[str] = ..., counter_order_id: _Optional[str] = ..., security_id: _Optional[str] = ..., market: _Optional[str] = ..., instrument_id: _Optional[str] = ..., appl_id: _Optional[str] = ..., strategy_id: _Optional[int] = ..., strategy_name: _Optional[str] = ..., account_id: _Optional[str] = ..., investor_id: _Optional[str] = ..., confirm_qty: _Optional[int] = ..., reject_qty: _Optional[int] = ..., is_pass: _Optional[int] = ..., order_price: _Optional[float] = ..., contract_unit: _Optional[float] = ...) -> None: ...

class OrderReject(_message.Message):
    __slots__ = ("msg_type", "msg_sequence", "cl_order_id", "order_id", "reject_reason", "text", "security_id", "market", "instrument_id", "appl_id", "strategy_id", "strategy_name", "account_id", "investor_id", "reject_qty", "is_pass", "order_price", "contract_unit")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    MSG_SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    CL_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    REJECT_REASON_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    SECURITY_ID_FIELD_NUMBER: _ClassVar[int]
    MARKET_FIELD_NUMBER: _ClassVar[int]
    INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    APPL_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_NAME_FIELD_NUMBER: _ClassVar[int]
    ACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    INVESTOR_ID_FIELD_NUMBER: _ClassVar[int]
    REJECT_QTY_FIELD_NUMBER: _ClassVar[int]
    IS_PASS_FIELD_NUMBER: _ClassVar[int]
    ORDER_PRICE_FIELD_NUMBER: _ClassVar[int]
    CONTRACT_UNIT_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    msg_sequence: int
    cl_order_id: str
    order_id: str
    reject_reason: int
    text: str
    security_id: str
    market: str
    instrument_id: str
    appl_id: str
    strategy_id: int
    strategy_name: str
    account_id: str
    investor_id: str
    reject_qty: int
    is_pass: int
    order_price: float
    contract_unit: float
    def __init__(self, msg_type: _Optional[int] = ..., msg_sequence: _Optional[int] = ..., cl_order_id: _Optional[str] = ..., order_id: _Optional[str] = ..., reject_reason: _Optional[int] = ..., text: _Optional[str] = ..., security_id: _Optional[str] = ..., market: _Optional[str] = ..., instrument_id: _Optional[str] = ..., appl_id: _Optional[str] = ..., strategy_id: _Optional[int] = ..., strategy_name: _Optional[str] = ..., account_id: _Optional[str] = ..., investor_id: _Optional[str] = ..., reject_qty: _Optional[int] = ..., is_pass: _Optional[int] = ..., order_price: _Optional[float] = ..., contract_unit: _Optional[float] = ...) -> None: ...

class TradeConfirm(_message.Message):
    __slots__ = ("msg_type", "msg_sequence", "cl_order_id", "order_id", "counter_order_id", "trade_id", "trade_time", "last_px", "last_qty", "security_id", "market", "instrument_id", "appl_id", "strategy_id", "strategy_name", "account_id", "investor_id", "match_place", "counterparty_id", "is_maker", "side", "position_effect", "trade_amt", "order_qty", "order_price", "contract_unit", "order_type", "order_source", "user_id", "counter_cl_order_id", "owner_type", "business_type", "symbol", "parent_order_id", "algo_type", "attachment", "basket_id")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    MSG_SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    CL_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    COUNTER_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    TRADE_ID_FIELD_NUMBER: _ClassVar[int]
    TRADE_TIME_FIELD_NUMBER: _ClassVar[int]
    LAST_PX_FIELD_NUMBER: _ClassVar[int]
    LAST_QTY_FIELD_NUMBER: _ClassVar[int]
    SECURITY_ID_FIELD_NUMBER: _ClassVar[int]
    MARKET_FIELD_NUMBER: _ClassVar[int]
    INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    APPL_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_NAME_FIELD_NUMBER: _ClassVar[int]
    ACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    INVESTOR_ID_FIELD_NUMBER: _ClassVar[int]
    MATCH_PLACE_FIELD_NUMBER: _ClassVar[int]
    COUNTERPARTY_ID_FIELD_NUMBER: _ClassVar[int]
    IS_MAKER_FIELD_NUMBER: _ClassVar[int]
    SIDE_FIELD_NUMBER: _ClassVar[int]
    POSITION_EFFECT_FIELD_NUMBER: _ClassVar[int]
    TRADE_AMT_FIELD_NUMBER: _ClassVar[int]
    ORDER_QTY_FIELD_NUMBER: _ClassVar[int]
    ORDER_PRICE_FIELD_NUMBER: _ClassVar[int]
    CONTRACT_UNIT_FIELD_NUMBER: _ClassVar[int]
    ORDER_TYPE_FIELD_NUMBER: _ClassVar[int]
    ORDER_SOURCE_FIELD_NUMBER: _ClassVar[int]
    USER_ID_FIELD_NUMBER: _ClassVar[int]
    COUNTER_CL_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    OWNER_TYPE_FIELD_NUMBER: _ClassVar[int]
    BUSINESS_TYPE_FIELD_NUMBER: _ClassVar[int]
    SYMBOL_FIELD_NUMBER: _ClassVar[int]
    PARENT_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    ALGO_TYPE_FIELD_NUMBER: _ClassVar[int]
    ATTACHMENT_FIELD_NUMBER: _ClassVar[int]
    BASKET_ID_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    msg_sequence: int
    cl_order_id: str
    order_id: str
    counter_order_id: str
    trade_id: str
    trade_time: int
    last_px: float
    last_qty: int
    security_id: str
    market: str
    instrument_id: str
    appl_id: str
    strategy_id: int
    strategy_name: str
    account_id: str
    investor_id: str
    match_place: int
    counterparty_id: str
    is_maker: int
    side: int
    position_effect: int
    trade_amt: float
    order_qty: int
    order_price: float
    contract_unit: float
    order_type: int
    order_source: str
    user_id: str
    counter_cl_order_id: str
    owner_type: int
    business_type: str
    symbol: str
    parent_order_id: str
    algo_type: int
    attachment: str
    basket_id: str
    def __init__(self, msg_type: _Optional[int] = ..., msg_sequence: _Optional[int] = ..., cl_order_id: _Optional[str] = ..., order_id: _Optional[str] = ..., counter_order_id: _Optional[str] = ..., trade_id: _Optional[str] = ..., trade_time: _Optional[int] = ..., last_px: _Optional[float] = ..., last_qty: _Optional[int] = ..., security_id: _Optional[str] = ..., market: _Optional[str] = ..., instrument_id: _Optional[str] = ..., appl_id: _Optional[str] = ..., strategy_id: _Optional[int] = ..., strategy_name: _Optional[str] = ..., account_id: _Optional[str] = ..., investor_id: _Optional[str] = ..., match_place: _Optional[int] = ..., counterparty_id: _Optional[str] = ..., is_maker: _Optional[int] = ..., side: _Optional[int] = ..., position_effect: _Optional[int] = ..., trade_amt: _Optional[float] = ..., order_qty: _Optional[int] = ..., order_price: _Optional[float] = ..., contract_unit: _Optional[float] = ..., order_type: _Optional[int] = ..., order_source: _Optional[str] = ..., user_id: _Optional[str] = ..., counter_cl_order_id: _Optional[str] = ..., owner_type: _Optional[int] = ..., business_type: _Optional[str] = ..., symbol: _Optional[str] = ..., parent_order_id: _Optional[str] = ..., algo_type: _Optional[int] = ..., attachment: _Optional[str] = ..., basket_id: _Optional[str] = ...) -> None: ...

class CancelOrder(_message.Message):
    __slots__ = ("msg_type", "msg_sequence", "account_id", "investor_id", "cl_order_id", "original_order_id", "original_cl_order_id", "security_id", "market", "instrument_id", "appl_id", "strategy_id", "strategy_name", "owner_type")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    MSG_SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    ACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    INVESTOR_ID_FIELD_NUMBER: _ClassVar[int]
    CL_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    ORIGINAL_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    ORIGINAL_CL_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    SECURITY_ID_FIELD_NUMBER: _ClassVar[int]
    MARKET_FIELD_NUMBER: _ClassVar[int]
    INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    APPL_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_NAME_FIELD_NUMBER: _ClassVar[int]
    OWNER_TYPE_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    msg_sequence: int
    account_id: str
    investor_id: str
    cl_order_id: str
    original_order_id: str
    original_cl_order_id: str
    security_id: str
    market: str
    instrument_id: str
    appl_id: str
    strategy_id: int
    strategy_name: str
    owner_type: int
    def __init__(self, msg_type: _Optional[int] = ..., msg_sequence: _Optional[int] = ..., account_id: _Optional[str] = ..., investor_id: _Optional[str] = ..., cl_order_id: _Optional[str] = ..., original_order_id: _Optional[str] = ..., original_cl_order_id: _Optional[str] = ..., security_id: _Optional[str] = ..., market: _Optional[str] = ..., instrument_id: _Optional[str] = ..., appl_id: _Optional[str] = ..., strategy_id: _Optional[int] = ..., strategy_name: _Optional[str] = ..., owner_type: _Optional[int] = ...) -> None: ...

class CancelAllOrder(_message.Message):
    __slots__ = ("msg_type", "msg_sequence", "cl_order_id", "account_id", "investor_id", "security_id", "market", "instrument_id", "strategy_id", "strategy_name", "owner_type")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    MSG_SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    CL_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    ACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    INVESTOR_ID_FIELD_NUMBER: _ClassVar[int]
    SECURITY_ID_FIELD_NUMBER: _ClassVar[int]
    MARKET_FIELD_NUMBER: _ClassVar[int]
    INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_NAME_FIELD_NUMBER: _ClassVar[int]
    OWNER_TYPE_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    msg_sequence: int
    cl_order_id: str
    account_id: str
    investor_id: str
    security_id: str
    market: str
    instrument_id: str
    strategy_id: int
    strategy_name: str
    owner_type: int
    def __init__(self, msg_type: _Optional[int] = ..., msg_sequence: _Optional[int] = ..., cl_order_id: _Optional[str] = ..., account_id: _Optional[str] = ..., investor_id: _Optional[str] = ..., security_id: _Optional[str] = ..., market: _Optional[str] = ..., instrument_id: _Optional[str] = ..., strategy_id: _Optional[int] = ..., strategy_name: _Optional[str] = ..., owner_type: _Optional[int] = ...) -> None: ...

class CancelPendingConfirm(_message.Message):
    __slots__ = ("msg_type", "msg_sequence", "cl_order_id", "original_order_id", "original_cl_order_id", "original_counter_order_id", "security_id", "market", "instrument_id", "appl_id", "strategy_id", "strategy_name", "account_id", "investor_id", "cancel_qty", "reason", "text")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    MSG_SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    CL_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    ORIGINAL_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    ORIGINAL_CL_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    ORIGINAL_COUNTER_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    SECURITY_ID_FIELD_NUMBER: _ClassVar[int]
    MARKET_FIELD_NUMBER: _ClassVar[int]
    INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    APPL_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_NAME_FIELD_NUMBER: _ClassVar[int]
    ACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    INVESTOR_ID_FIELD_NUMBER: _ClassVar[int]
    CANCEL_QTY_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    msg_sequence: int
    cl_order_id: str
    original_order_id: str
    original_cl_order_id: str
    original_counter_order_id: str
    security_id: str
    market: str
    instrument_id: str
    appl_id: str
    strategy_id: int
    strategy_name: str
    account_id: str
    investor_id: str
    cancel_qty: int
    reason: int
    text: str
    def __init__(self, msg_type: _Optional[int] = ..., msg_sequence: _Optional[int] = ..., cl_order_id: _Optional[str] = ..., original_order_id: _Optional[str] = ..., original_cl_order_id: _Optional[str] = ..., original_counter_order_id: _Optional[str] = ..., security_id: _Optional[str] = ..., market: _Optional[str] = ..., instrument_id: _Optional[str] = ..., appl_id: _Optional[str] = ..., strategy_id: _Optional[int] = ..., strategy_name: _Optional[str] = ..., account_id: _Optional[str] = ..., investor_id: _Optional[str] = ..., cancel_qty: _Optional[int] = ..., reason: _Optional[int] = ..., text: _Optional[str] = ...) -> None: ...

class CancelConfirm(_message.Message):
    __slots__ = ("msg_type", "msg_sequence", "cl_order_id", "original_order_id", "original_cl_order_id", "original_counter_order_id", "security_id", "market", "instrument_id", "appl_id", "strategy_id", "strategy_name", "account_id", "investor_id", "cancel_qty", "reason", "text")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    MSG_SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    CL_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    ORIGINAL_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    ORIGINAL_CL_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    ORIGINAL_COUNTER_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    SECURITY_ID_FIELD_NUMBER: _ClassVar[int]
    MARKET_FIELD_NUMBER: _ClassVar[int]
    INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    APPL_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_NAME_FIELD_NUMBER: _ClassVar[int]
    ACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    INVESTOR_ID_FIELD_NUMBER: _ClassVar[int]
    CANCEL_QTY_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    msg_sequence: int
    cl_order_id: str
    original_order_id: str
    original_cl_order_id: str
    original_counter_order_id: str
    security_id: str
    market: str
    instrument_id: str
    appl_id: str
    strategy_id: int
    strategy_name: str
    account_id: str
    investor_id: str
    cancel_qty: int
    reason: int
    text: str
    def __init__(self, msg_type: _Optional[int] = ..., msg_sequence: _Optional[int] = ..., cl_order_id: _Optional[str] = ..., original_order_id: _Optional[str] = ..., original_cl_order_id: _Optional[str] = ..., original_counter_order_id: _Optional[str] = ..., security_id: _Optional[str] = ..., market: _Optional[str] = ..., instrument_id: _Optional[str] = ..., appl_id: _Optional[str] = ..., strategy_id: _Optional[int] = ..., strategy_name: _Optional[str] = ..., account_id: _Optional[str] = ..., investor_id: _Optional[str] = ..., cancel_qty: _Optional[int] = ..., reason: _Optional[int] = ..., text: _Optional[str] = ...) -> None: ...

class CancelReject(_message.Message):
    __slots__ = ("msg_type", "msg_sequence", "cl_order_id", "original_order_id", "original_cl_order_id", "original_counter_order_id", "security_id", "market", "instrument_id", "appl_id", "strategy_id", "strategy_name", "account_id", "investor_id", "reject_reason", "text")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    MSG_SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    CL_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    ORIGINAL_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    ORIGINAL_CL_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    ORIGINAL_COUNTER_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    SECURITY_ID_FIELD_NUMBER: _ClassVar[int]
    MARKET_FIELD_NUMBER: _ClassVar[int]
    INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    APPL_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_NAME_FIELD_NUMBER: _ClassVar[int]
    ACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    INVESTOR_ID_FIELD_NUMBER: _ClassVar[int]
    REJECT_REASON_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    msg_sequence: int
    cl_order_id: str
    original_order_id: str
    original_cl_order_id: str
    original_counter_order_id: str
    security_id: str
    market: str
    instrument_id: str
    appl_id: str
    strategy_id: int
    strategy_name: str
    account_id: str
    investor_id: str
    reject_reason: int
    text: str
    def __init__(self, msg_type: _Optional[int] = ..., msg_sequence: _Optional[int] = ..., cl_order_id: _Optional[str] = ..., original_order_id: _Optional[str] = ..., original_cl_order_id: _Optional[str] = ..., original_counter_order_id: _Optional[str] = ..., security_id: _Optional[str] = ..., market: _Optional[str] = ..., instrument_id: _Optional[str] = ..., appl_id: _Optional[str] = ..., strategy_id: _Optional[int] = ..., strategy_name: _Optional[str] = ..., account_id: _Optional[str] = ..., investor_id: _Optional[str] = ..., reject_reason: _Optional[int] = ..., text: _Optional[str] = ...) -> None: ...

class UpdateRiskParamsReq(_message.Message):
    __slots__ = ("msg_type", "last_timestamp", "request_id", "operate_type", "risk_item", "account_id")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    OPERATE_TYPE_FIELD_NUMBER: _ClassVar[int]
    RISK_ITEM_FIELD_NUMBER: _ClassVar[int]
    ACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    last_timestamp: int
    request_id: str
    operate_type: str
    risk_item: _containers.RepeatedCompositeFieldContainer[RiskItem]
    account_id: str
    def __init__(self, msg_type: _Optional[int] = ..., last_timestamp: _Optional[int] = ..., request_id: _Optional[str] = ..., operate_type: _Optional[str] = ..., risk_item: _Optional[_Iterable[_Union[RiskItem, _Mapping]]] = ..., account_id: _Optional[str] = ...) -> None: ...

class UpdateRiskParamsRsp(_message.Message):
    __slots__ = ("msg_type", "last_timestamp", "request_id", "status", "text", "risk_item")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    RISK_ITEM_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    last_timestamp: int
    request_id: str
    status: int
    text: str
    risk_item: _containers.RepeatedCompositeFieldContainer[RiskItem]
    def __init__(self, msg_type: _Optional[int] = ..., last_timestamp: _Optional[int] = ..., request_id: _Optional[str] = ..., status: _Optional[int] = ..., text: _Optional[str] = ..., risk_item: _Optional[_Iterable[_Union[RiskItem, _Mapping]]] = ...) -> None: ...

class PlaceBasketOrder(_message.Message):
    __slots__ = ("msg_type", "basket_cl_order_id", "template_id", "strategy_id", "side", "purpose", "basket_qty", "algo_type", "algo_params", "order_source", "attachment")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    BASKET_CL_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    TEMPLATE_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_ID_FIELD_NUMBER: _ClassVar[int]
    SIDE_FIELD_NUMBER: _ClassVar[int]
    PURPOSE_FIELD_NUMBER: _ClassVar[int]
    BASKET_QTY_FIELD_NUMBER: _ClassVar[int]
    ALGO_TYPE_FIELD_NUMBER: _ClassVar[int]
    ALGO_PARAMS_FIELD_NUMBER: _ClassVar[int]
    ORDER_SOURCE_FIELD_NUMBER: _ClassVar[int]
    ATTACHMENT_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    basket_cl_order_id: str
    template_id: str
    strategy_id: int
    side: int
    purpose: int
    basket_qty: int
    algo_type: int
    algo_params: AlgoParams
    order_source: str
    attachment: str
    def __init__(self, msg_type: _Optional[int] = ..., basket_cl_order_id: _Optional[str] = ..., template_id: _Optional[str] = ..., strategy_id: _Optional[int] = ..., side: _Optional[int] = ..., purpose: _Optional[int] = ..., basket_qty: _Optional[int] = ..., algo_type: _Optional[int] = ..., algo_params: _Optional[_Union[AlgoParams, _Mapping]] = ..., order_source: _Optional[str] = ..., attachment: _Optional[str] = ...) -> None: ...

class PlaceBasketOrderRsp(_message.Message):
    __slots__ = ("msg_type", "basket_cl_order_id", "status", "reason", "basket_id", "template_id", "strategy_id", "strategy_name", "side", "basket_amt", "trade_amt", "basket_qty", "process_qty", "process_amt", "create_time", "algo_type", "algo_params", "order_source")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    BASKET_CL_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    BASKET_ID_FIELD_NUMBER: _ClassVar[int]
    TEMPLATE_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_NAME_FIELD_NUMBER: _ClassVar[int]
    SIDE_FIELD_NUMBER: _ClassVar[int]
    BASKET_AMT_FIELD_NUMBER: _ClassVar[int]
    TRADE_AMT_FIELD_NUMBER: _ClassVar[int]
    BASKET_QTY_FIELD_NUMBER: _ClassVar[int]
    PROCESS_QTY_FIELD_NUMBER: _ClassVar[int]
    PROCESS_AMT_FIELD_NUMBER: _ClassVar[int]
    CREATE_TIME_FIELD_NUMBER: _ClassVar[int]
    ALGO_TYPE_FIELD_NUMBER: _ClassVar[int]
    ALGO_PARAMS_FIELD_NUMBER: _ClassVar[int]
    ORDER_SOURCE_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    basket_cl_order_id: str
    status: int
    reason: str
    basket_id: str
    template_id: str
    strategy_id: int
    strategy_name: str
    side: int
    basket_amt: float
    trade_amt: float
    basket_qty: int
    process_qty: float
    process_amt: float
    create_time: int
    algo_type: int
    algo_params: AlgoParams
    order_source: str
    def __init__(self, msg_type: _Optional[int] = ..., basket_cl_order_id: _Optional[str] = ..., status: _Optional[int] = ..., reason: _Optional[str] = ..., basket_id: _Optional[str] = ..., template_id: _Optional[str] = ..., strategy_id: _Optional[int] = ..., strategy_name: _Optional[str] = ..., side: _Optional[int] = ..., basket_amt: _Optional[float] = ..., trade_amt: _Optional[float] = ..., basket_qty: _Optional[int] = ..., process_qty: _Optional[float] = ..., process_amt: _Optional[float] = ..., create_time: _Optional[int] = ..., algo_type: _Optional[int] = ..., algo_params: _Optional[_Union[AlgoParams, _Mapping]] = ..., order_source: _Optional[str] = ...) -> None: ...

class BasketOrderEvent(_message.Message):
    __slots__ = ("msg_type", "basket_cl_order_id", "basket_id", "template_id", "status", "strategy_id", "strategy_name", "side", "basket_amt", "trade_amt", "basket_qty", "process_qty", "process_amt", "create_time", "algo_type", "algo_params", "reason", "user_id", "order_qty", "trade_qty", "reject_qty", "cancel_qty")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    BASKET_CL_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    BASKET_ID_FIELD_NUMBER: _ClassVar[int]
    TEMPLATE_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_NAME_FIELD_NUMBER: _ClassVar[int]
    SIDE_FIELD_NUMBER: _ClassVar[int]
    BASKET_AMT_FIELD_NUMBER: _ClassVar[int]
    TRADE_AMT_FIELD_NUMBER: _ClassVar[int]
    BASKET_QTY_FIELD_NUMBER: _ClassVar[int]
    PROCESS_QTY_FIELD_NUMBER: _ClassVar[int]
    PROCESS_AMT_FIELD_NUMBER: _ClassVar[int]
    CREATE_TIME_FIELD_NUMBER: _ClassVar[int]
    ALGO_TYPE_FIELD_NUMBER: _ClassVar[int]
    ALGO_PARAMS_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    USER_ID_FIELD_NUMBER: _ClassVar[int]
    ORDER_QTY_FIELD_NUMBER: _ClassVar[int]
    TRADE_QTY_FIELD_NUMBER: _ClassVar[int]
    REJECT_QTY_FIELD_NUMBER: _ClassVar[int]
    CANCEL_QTY_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    basket_cl_order_id: str
    basket_id: str
    template_id: str
    status: int
    strategy_id: int
    strategy_name: str
    side: int
    basket_amt: float
    trade_amt: float
    basket_qty: int
    process_qty: float
    process_amt: float
    create_time: int
    algo_type: int
    algo_params: AlgoParams
    reason: str
    user_id: str
    order_qty: int
    trade_qty: int
    reject_qty: int
    cancel_qty: int
    def __init__(self, msg_type: _Optional[int] = ..., basket_cl_order_id: _Optional[str] = ..., basket_id: _Optional[str] = ..., template_id: _Optional[str] = ..., status: _Optional[int] = ..., strategy_id: _Optional[int] = ..., strategy_name: _Optional[str] = ..., side: _Optional[int] = ..., basket_amt: _Optional[float] = ..., trade_amt: _Optional[float] = ..., basket_qty: _Optional[int] = ..., process_qty: _Optional[float] = ..., process_amt: _Optional[float] = ..., create_time: _Optional[int] = ..., algo_type: _Optional[int] = ..., algo_params: _Optional[_Union[AlgoParams, _Mapping]] = ..., reason: _Optional[str] = ..., user_id: _Optional[str] = ..., order_qty: _Optional[int] = ..., trade_qty: _Optional[int] = ..., reject_qty: _Optional[int] = ..., cancel_qty: _Optional[int] = ...) -> None: ...

class QryBasketOrderReq(_message.Message):
    __slots__ = ("msg_type", "request_id")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    request_id: str
    def __init__(self, msg_type: _Optional[int] = ..., request_id: _Optional[str] = ...) -> None: ...

class QryBasketOrderRsp(_message.Message):
    __slots__ = ("msg_type", "status", "reason", "request_id")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    status: int
    reason: str
    request_id: str
    def __init__(self, msg_type: _Optional[int] = ..., status: _Optional[int] = ..., reason: _Optional[str] = ..., request_id: _Optional[str] = ...) -> None: ...

class QryBasketOrderStatReq(_message.Message):
    __slots__ = ("msg_type", "basket_cl_order_id", "request_id")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    BASKET_CL_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    basket_cl_order_id: str
    request_id: str
    def __init__(self, msg_type: _Optional[int] = ..., basket_cl_order_id: _Optional[str] = ..., request_id: _Optional[str] = ...) -> None: ...

class BasketOrderStatDetail(_message.Message):
    __slots__ = ("instrument_id", "order_qty", "fill_qty", "active_qty", "order_status", "order_msg", "cost_price", "fill_amt", "order_amt", "order_id", "reject_qty", "order_time", "side", "position_effect")
    INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    ORDER_QTY_FIELD_NUMBER: _ClassVar[int]
    FILL_QTY_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_QTY_FIELD_NUMBER: _ClassVar[int]
    ORDER_STATUS_FIELD_NUMBER: _ClassVar[int]
    ORDER_MSG_FIELD_NUMBER: _ClassVar[int]
    COST_PRICE_FIELD_NUMBER: _ClassVar[int]
    FILL_AMT_FIELD_NUMBER: _ClassVar[int]
    ORDER_AMT_FIELD_NUMBER: _ClassVar[int]
    ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    REJECT_QTY_FIELD_NUMBER: _ClassVar[int]
    ORDER_TIME_FIELD_NUMBER: _ClassVar[int]
    SIDE_FIELD_NUMBER: _ClassVar[int]
    POSITION_EFFECT_FIELD_NUMBER: _ClassVar[int]
    instrument_id: str
    order_qty: int
    fill_qty: int
    active_qty: int
    order_status: int
    order_msg: str
    cost_price: float
    fill_amt: float
    order_amt: float
    order_id: str
    reject_qty: int
    order_time: int
    side: int
    position_effect: int
    def __init__(self, instrument_id: _Optional[str] = ..., order_qty: _Optional[int] = ..., fill_qty: _Optional[int] = ..., active_qty: _Optional[int] = ..., order_status: _Optional[int] = ..., order_msg: _Optional[str] = ..., cost_price: _Optional[float] = ..., fill_amt: _Optional[float] = ..., order_amt: _Optional[float] = ..., order_id: _Optional[str] = ..., reject_qty: _Optional[int] = ..., order_time: _Optional[int] = ..., side: _Optional[int] = ..., position_effect: _Optional[int] = ...) -> None: ...

class BasketOrderStat(_message.Message):
    __slots__ = ("component_instrument_id", "order_qty", "fill_qty", "active_qty", "reject_qty", "cancel_qty", "order_status", "process_qty", "process_amt", "cost_price", "fill_amt", "order_amt", "order_stat_details", "side")
    COMPONENT_INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    ORDER_QTY_FIELD_NUMBER: _ClassVar[int]
    FILL_QTY_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_QTY_FIELD_NUMBER: _ClassVar[int]
    REJECT_QTY_FIELD_NUMBER: _ClassVar[int]
    CANCEL_QTY_FIELD_NUMBER: _ClassVar[int]
    ORDER_STATUS_FIELD_NUMBER: _ClassVar[int]
    PROCESS_QTY_FIELD_NUMBER: _ClassVar[int]
    PROCESS_AMT_FIELD_NUMBER: _ClassVar[int]
    COST_PRICE_FIELD_NUMBER: _ClassVar[int]
    FILL_AMT_FIELD_NUMBER: _ClassVar[int]
    ORDER_AMT_FIELD_NUMBER: _ClassVar[int]
    ORDER_STAT_DETAILS_FIELD_NUMBER: _ClassVar[int]
    SIDE_FIELD_NUMBER: _ClassVar[int]
    component_instrument_id: str
    order_qty: int
    fill_qty: int
    active_qty: int
    reject_qty: int
    cancel_qty: int
    order_status: int
    process_qty: float
    process_amt: float
    cost_price: float
    fill_amt: float
    order_amt: float
    order_stat_details: _containers.RepeatedCompositeFieldContainer[BasketOrderStatDetail]
    side: int
    def __init__(self, component_instrument_id: _Optional[str] = ..., order_qty: _Optional[int] = ..., fill_qty: _Optional[int] = ..., active_qty: _Optional[int] = ..., reject_qty: _Optional[int] = ..., cancel_qty: _Optional[int] = ..., order_status: _Optional[int] = ..., process_qty: _Optional[float] = ..., process_amt: _Optional[float] = ..., cost_price: _Optional[float] = ..., fill_amt: _Optional[float] = ..., order_amt: _Optional[float] = ..., order_stat_details: _Optional[_Iterable[_Union[BasketOrderStatDetail, _Mapping]]] = ..., side: _Optional[int] = ...) -> None: ...

class QryBasketOrderStatRsp(_message.Message):
    __slots__ = ("msg_type", "basket_cl_order_id", "basket_order_stats", "request_id", "status", "reason")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    BASKET_CL_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    BASKET_ORDER_STATS_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    basket_cl_order_id: str
    basket_order_stats: _containers.RepeatedCompositeFieldContainer[BasketOrderStat]
    request_id: str
    status: int
    reason: str
    def __init__(self, msg_type: _Optional[int] = ..., basket_cl_order_id: _Optional[str] = ..., basket_order_stats: _Optional[_Iterable[_Union[BasketOrderStat, _Mapping]]] = ..., request_id: _Optional[str] = ..., status: _Optional[int] = ..., reason: _Optional[str] = ...) -> None: ...

class QryBasketInfoReq(_message.Message):
    __slots__ = ("msg_type", "template_id", "request_id")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    TEMPLATE_ID_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    template_id: str
    request_id: str
    def __init__(self, msg_type: _Optional[int] = ..., template_id: _Optional[str] = ..., request_id: _Optional[str] = ...) -> None: ...

class BasketInfoDetail(_message.Message):
    __slots__ = ("component_instrument_id", "component_qty", "side", "comments", "position_effect")
    COMPONENT_INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    COMPONENT_QTY_FIELD_NUMBER: _ClassVar[int]
    SIDE_FIELD_NUMBER: _ClassVar[int]
    COMMENTS_FIELD_NUMBER: _ClassVar[int]
    POSITION_EFFECT_FIELD_NUMBER: _ClassVar[int]
    component_instrument_id: str
    component_qty: int
    side: int
    comments: str
    position_effect: int
    def __init__(self, component_instrument_id: _Optional[str] = ..., component_qty: _Optional[int] = ..., side: _Optional[int] = ..., comments: _Optional[str] = ..., position_effect: _Optional[int] = ...) -> None: ...

class BasketInfo(_message.Message):
    __slots__ = ("template_id", "basket_info_details", "strategy_id", "strategy_name", "etf_instrument_id", "etf_unit", "template_type", "comments")
    TEMPLATE_ID_FIELD_NUMBER: _ClassVar[int]
    BASKET_INFO_DETAILS_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_NAME_FIELD_NUMBER: _ClassVar[int]
    ETF_INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    ETF_UNIT_FIELD_NUMBER: _ClassVar[int]
    TEMPLATE_TYPE_FIELD_NUMBER: _ClassVar[int]
    COMMENTS_FIELD_NUMBER: _ClassVar[int]
    template_id: str
    basket_info_details: _containers.RepeatedCompositeFieldContainer[BasketInfoDetail]
    strategy_id: int
    strategy_name: str
    etf_instrument_id: str
    etf_unit: int
    template_type: str
    comments: str
    def __init__(self, template_id: _Optional[str] = ..., basket_info_details: _Optional[_Iterable[_Union[BasketInfoDetail, _Mapping]]] = ..., strategy_id: _Optional[int] = ..., strategy_name: _Optional[str] = ..., etf_instrument_id: _Optional[str] = ..., etf_unit: _Optional[int] = ..., template_type: _Optional[str] = ..., comments: _Optional[str] = ...) -> None: ...

class QryBasketInfoRsp(_message.Message):
    __slots__ = ("msg_type", "request_id", "basket_infos")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    BASKET_INFOS_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    request_id: str
    basket_infos: _containers.RepeatedCompositeFieldContainer[BasketInfo]
    def __init__(self, msg_type: _Optional[int] = ..., request_id: _Optional[str] = ..., basket_infos: _Optional[_Iterable[_Union[BasketInfo, _Mapping]]] = ...) -> None: ...

class CancelBasketOrder(_message.Message):
    __slots__ = ("msg_type", "basket_cl_order_id", "request_id")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    BASKET_CL_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    basket_cl_order_id: str
    request_id: str
    def __init__(self, msg_type: _Optional[int] = ..., basket_cl_order_id: _Optional[str] = ..., request_id: _Optional[str] = ...) -> None: ...

class CancelBasketOrderRsp(_message.Message):
    __slots__ = ("msg_type", "basket_cl_order_id", "status", "reason", "request_id")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    BASKET_CL_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    basket_cl_order_id: str
    status: int
    reason: str
    request_id: str
    def __init__(self, msg_type: _Optional[int] = ..., basket_cl_order_id: _Optional[str] = ..., status: _Optional[int] = ..., reason: _Optional[str] = ..., request_id: _Optional[str] = ...) -> None: ...

class AppendBasketOrder(_message.Message):
    __slots__ = ("msg_type", "basket_cl_order_id", "algo_type", "algo_params", "request_id")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    BASKET_CL_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    ALGO_TYPE_FIELD_NUMBER: _ClassVar[int]
    ALGO_PARAMS_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    basket_cl_order_id: str
    algo_type: int
    algo_params: AlgoParams
    request_id: str
    def __init__(self, msg_type: _Optional[int] = ..., basket_cl_order_id: _Optional[str] = ..., algo_type: _Optional[int] = ..., algo_params: _Optional[_Union[AlgoParams, _Mapping]] = ..., request_id: _Optional[str] = ...) -> None: ...

class AppendBasketOrderRsp(_message.Message):
    __slots__ = ("msg_type", "basket_cl_order_id", "status", "reason", "request_id")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    BASKET_CL_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    basket_cl_order_id: str
    status: int
    reason: str
    request_id: str
    def __init__(self, msg_type: _Optional[int] = ..., basket_cl_order_id: _Optional[str] = ..., status: _Optional[int] = ..., reason: _Optional[str] = ..., request_id: _Optional[str] = ...) -> None: ...

class NewBasketTemplateReq(_message.Message):
    __slots__ = ("msg_type", "template_id", "basket_info_details", "strategy_name", "request_id", "template_type")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    TEMPLATE_ID_FIELD_NUMBER: _ClassVar[int]
    BASKET_INFO_DETAILS_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_NAME_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    TEMPLATE_TYPE_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    template_id: str
    basket_info_details: _containers.RepeatedCompositeFieldContainer[BasketInfoDetail]
    strategy_name: str
    request_id: str
    template_type: str
    def __init__(self, msg_type: _Optional[int] = ..., template_id: _Optional[str] = ..., basket_info_details: _Optional[_Iterable[_Union[BasketInfoDetail, _Mapping]]] = ..., strategy_name: _Optional[str] = ..., request_id: _Optional[str] = ..., template_type: _Optional[str] = ...) -> None: ...

class NewBasketTemplateRsp(_message.Message):
    __slots__ = ("msg_type", "template_id", "status", "reason", "request_id", "template_type")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    TEMPLATE_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    TEMPLATE_TYPE_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    template_id: str
    status: int
    reason: str
    request_id: str
    template_type: str
    def __init__(self, msg_type: _Optional[int] = ..., template_id: _Optional[str] = ..., status: _Optional[int] = ..., reason: _Optional[str] = ..., request_id: _Optional[str] = ..., template_type: _Optional[str] = ...) -> None: ...

class UpdateBasketTemplateReq(_message.Message):
    __slots__ = ("msg_type", "template_id", "new_template_id", "basket_info_details", "strategy_name", "request_id", "template_type")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    TEMPLATE_ID_FIELD_NUMBER: _ClassVar[int]
    NEW_TEMPLATE_ID_FIELD_NUMBER: _ClassVar[int]
    BASKET_INFO_DETAILS_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_NAME_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    TEMPLATE_TYPE_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    template_id: str
    new_template_id: str
    basket_info_details: _containers.RepeatedCompositeFieldContainer[BasketInfoDetail]
    strategy_name: str
    request_id: str
    template_type: str
    def __init__(self, msg_type: _Optional[int] = ..., template_id: _Optional[str] = ..., new_template_id: _Optional[str] = ..., basket_info_details: _Optional[_Iterable[_Union[BasketInfoDetail, _Mapping]]] = ..., strategy_name: _Optional[str] = ..., request_id: _Optional[str] = ..., template_type: _Optional[str] = ...) -> None: ...

class UpdateBasketTemplateRsp(_message.Message):
    __slots__ = ("msg_type", "template_id", "status", "reason", "request_id", "template_type")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    TEMPLATE_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    TEMPLATE_TYPE_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    template_id: str
    status: int
    reason: str
    request_id: str
    template_type: str
    def __init__(self, msg_type: _Optional[int] = ..., template_id: _Optional[str] = ..., status: _Optional[int] = ..., reason: _Optional[str] = ..., request_id: _Optional[str] = ..., template_type: _Optional[str] = ...) -> None: ...

class ArbitrageOrder(_message.Message):
    __slots__ = ("arbitrage_order_id", "arbitrage_cl_order_id", "arbitrage_type", "order_source", "attachment", "process_qty", "process_amt", "status", "reason", "strategy_id", "leg_exec_seq", "user_id", "order_time", "strategy_name", "leg_id", "leg_type", "order_qty", "side", "leg_order_amt", "leg_cl_order_id", "algo_type", "algo_params")
    ARBITRAGE_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    ARBITRAGE_CL_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    ARBITRAGE_TYPE_FIELD_NUMBER: _ClassVar[int]
    ORDER_SOURCE_FIELD_NUMBER: _ClassVar[int]
    ATTACHMENT_FIELD_NUMBER: _ClassVar[int]
    PROCESS_QTY_FIELD_NUMBER: _ClassVar[int]
    PROCESS_AMT_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_ID_FIELD_NUMBER: _ClassVar[int]
    LEG_EXEC_SEQ_FIELD_NUMBER: _ClassVar[int]
    USER_ID_FIELD_NUMBER: _ClassVar[int]
    ORDER_TIME_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_NAME_FIELD_NUMBER: _ClassVar[int]
    LEG_ID_FIELD_NUMBER: _ClassVar[int]
    LEG_TYPE_FIELD_NUMBER: _ClassVar[int]
    ORDER_QTY_FIELD_NUMBER: _ClassVar[int]
    SIDE_FIELD_NUMBER: _ClassVar[int]
    LEG_ORDER_AMT_FIELD_NUMBER: _ClassVar[int]
    LEG_CL_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    ALGO_TYPE_FIELD_NUMBER: _ClassVar[int]
    ALGO_PARAMS_FIELD_NUMBER: _ClassVar[int]
    arbitrage_order_id: str
    arbitrage_cl_order_id: str
    arbitrage_type: str
    order_source: str
    attachment: str
    process_qty: float
    process_amt: float
    status: int
    reason: str
    strategy_id: int
    leg_exec_seq: str
    user_id: str
    order_time: int
    strategy_name: str
    leg_id: str
    leg_type: str
    order_qty: int
    side: int
    leg_order_amt: float
    leg_cl_order_id: str
    algo_type: int
    algo_params: AlgoParams
    def __init__(self, arbitrage_order_id: _Optional[str] = ..., arbitrage_cl_order_id: _Optional[str] = ..., arbitrage_type: _Optional[str] = ..., order_source: _Optional[str] = ..., attachment: _Optional[str] = ..., process_qty: _Optional[float] = ..., process_amt: _Optional[float] = ..., status: _Optional[int] = ..., reason: _Optional[str] = ..., strategy_id: _Optional[int] = ..., leg_exec_seq: _Optional[str] = ..., user_id: _Optional[str] = ..., order_time: _Optional[int] = ..., strategy_name: _Optional[str] = ..., leg_id: _Optional[str] = ..., leg_type: _Optional[str] = ..., order_qty: _Optional[int] = ..., side: _Optional[int] = ..., leg_order_amt: _Optional[float] = ..., leg_cl_order_id: _Optional[str] = ..., algo_type: _Optional[int] = ..., algo_params: _Optional[_Union[AlgoParams, _Mapping]] = ...) -> None: ...

class PlaceArbitrageOrder(_message.Message):
    __slots__ = ("msg_type", "arbitrage_cl_order_id", "arbitrage_type", "strategy_id", "strategy_name", "order_source", "leg_exec_seq", "legs")
    class Leg(_message.Message):
        __slots__ = ("leg_id", "leg_type", "order_qty", "side", "leg_cl_order_id", "algo_type", "algo_params", "order_type", "target_process", "order_price")
        LEG_ID_FIELD_NUMBER: _ClassVar[int]
        LEG_TYPE_FIELD_NUMBER: _ClassVar[int]
        ORDER_QTY_FIELD_NUMBER: _ClassVar[int]
        SIDE_FIELD_NUMBER: _ClassVar[int]
        LEG_CL_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
        ALGO_TYPE_FIELD_NUMBER: _ClassVar[int]
        ALGO_PARAMS_FIELD_NUMBER: _ClassVar[int]
        ORDER_TYPE_FIELD_NUMBER: _ClassVar[int]
        TARGET_PROCESS_FIELD_NUMBER: _ClassVar[int]
        ORDER_PRICE_FIELD_NUMBER: _ClassVar[int]
        leg_id: str
        leg_type: str
        order_qty: int
        side: int
        leg_cl_order_id: str
        algo_type: int
        algo_params: AlgoParams
        order_type: int
        target_process: float
        order_price: float
        def __init__(self, leg_id: _Optional[str] = ..., leg_type: _Optional[str] = ..., order_qty: _Optional[int] = ..., side: _Optional[int] = ..., leg_cl_order_id: _Optional[str] = ..., algo_type: _Optional[int] = ..., algo_params: _Optional[_Union[AlgoParams, _Mapping]] = ..., order_type: _Optional[int] = ..., target_process: _Optional[float] = ..., order_price: _Optional[float] = ...) -> None: ...
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    ARBITRAGE_CL_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    ARBITRAGE_TYPE_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_NAME_FIELD_NUMBER: _ClassVar[int]
    ORDER_SOURCE_FIELD_NUMBER: _ClassVar[int]
    LEG_EXEC_SEQ_FIELD_NUMBER: _ClassVar[int]
    LEGS_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    arbitrage_cl_order_id: str
    arbitrage_type: str
    strategy_id: int
    strategy_name: str
    order_source: str
    leg_exec_seq: str
    legs: _containers.RepeatedCompositeFieldContainer[PlaceArbitrageOrder.Leg]
    def __init__(self, msg_type: _Optional[int] = ..., arbitrage_cl_order_id: _Optional[str] = ..., arbitrage_type: _Optional[str] = ..., strategy_id: _Optional[int] = ..., strategy_name: _Optional[str] = ..., order_source: _Optional[str] = ..., leg_exec_seq: _Optional[str] = ..., legs: _Optional[_Iterable[_Union[PlaceArbitrageOrder.Leg, _Mapping]]] = ...) -> None: ...

class PlaceArbitrageOrderRsp(_message.Message):
    __slots__ = ("msg_type", "arbitrage_cl_order_id", "status", "reason", "order")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    ARBITRAGE_CL_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    ORDER_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    arbitrage_cl_order_id: str
    status: int
    reason: str
    order: ArbitrageOrder
    def __init__(self, msg_type: _Optional[int] = ..., arbitrage_cl_order_id: _Optional[str] = ..., status: _Optional[int] = ..., reason: _Optional[str] = ..., order: _Optional[_Union[ArbitrageOrder, _Mapping]] = ...) -> None: ...

class QryArbitrageOrderReq(_message.Message):
    __slots__ = ("msg_type", "request_id")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    request_id: str
    def __init__(self, msg_type: _Optional[int] = ..., request_id: _Optional[str] = ...) -> None: ...

class QryArbitrageOrderRsp(_message.Message):
    __slots__ = ("msg_type", "status", "reason", "request_id")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    status: int
    reason: str
    request_id: str
    def __init__(self, msg_type: _Optional[int] = ..., status: _Optional[int] = ..., reason: _Optional[str] = ..., request_id: _Optional[str] = ...) -> None: ...

class ArbitrageOrderEvent(_message.Message):
    __slots__ = ("msg_type", "order")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    ORDER_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    order: ArbitrageOrder
    def __init__(self, msg_type: _Optional[int] = ..., order: _Optional[_Union[ArbitrageOrder, _Mapping]] = ...) -> None: ...

class CancelArbitrageOrder(_message.Message):
    __slots__ = ("msg_type", "cl_order_id", "request_id")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    CL_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    cl_order_id: str
    request_id: str
    def __init__(self, msg_type: _Optional[int] = ..., cl_order_id: _Optional[str] = ..., request_id: _Optional[str] = ...) -> None: ...

class CancelArbitrageOrderRsp(_message.Message):
    __slots__ = ("msg_type", "cl_order_id", "status", "reason", "request_id")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    CL_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    cl_order_id: str
    status: int
    reason: str
    request_id: str
    def __init__(self, msg_type: _Optional[int] = ..., cl_order_id: _Optional[str] = ..., status: _Optional[int] = ..., reason: _Optional[str] = ..., request_id: _Optional[str] = ...) -> None: ...

class PlaceBatchOrder(_message.Message):
    __slots__ = ("msg_type", "basket_cl_order_id", "orders", "strategy_id", "account_id", "algo_type", "algo_params", "order_source", "attachment", "last_timestamp")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    BASKET_CL_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    ORDERS_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_ID_FIELD_NUMBER: _ClassVar[int]
    ACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    ALGO_TYPE_FIELD_NUMBER: _ClassVar[int]
    ALGO_PARAMS_FIELD_NUMBER: _ClassVar[int]
    ORDER_SOURCE_FIELD_NUMBER: _ClassVar[int]
    ATTACHMENT_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    basket_cl_order_id: str
    orders: _containers.RepeatedCompositeFieldContainer[BasketInfoDetail]
    strategy_id: int
    account_id: str
    algo_type: int
    algo_params: AlgoParams
    order_source: str
    attachment: str
    last_timestamp: int
    def __init__(self, msg_type: _Optional[int] = ..., basket_cl_order_id: _Optional[str] = ..., orders: _Optional[_Iterable[_Union[BasketInfoDetail, _Mapping]]] = ..., strategy_id: _Optional[int] = ..., account_id: _Optional[str] = ..., algo_type: _Optional[int] = ..., algo_params: _Optional[_Union[AlgoParams, _Mapping]] = ..., order_source: _Optional[str] = ..., attachment: _Optional[str] = ..., last_timestamp: _Optional[int] = ...) -> None: ...

class PlaceBatchOrderRsp(_message.Message):
    __slots__ = ("msg_type", "basket_cl_order_id", "status", "reason", "basket_id", "create_time")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    BASKET_CL_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    BASKET_ID_FIELD_NUMBER: _ClassVar[int]
    CREATE_TIME_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    basket_cl_order_id: str
    status: int
    reason: str
    basket_id: str
    create_time: int
    def __init__(self, msg_type: _Optional[int] = ..., basket_cl_order_id: _Optional[str] = ..., status: _Optional[int] = ..., reason: _Optional[str] = ..., basket_id: _Optional[str] = ..., create_time: _Optional[int] = ...) -> None: ...

class QryOrdersReq(_message.Message):
    __slots__ = ("msg_type", "msg_sequence", "token", "request_id", "instrument_id", "strategy_id", "account_id", "cl_order_id", "order_id", "is_active", "owner_type", "start_row", "page_size")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    MSG_SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    TOKEN_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_ID_FIELD_NUMBER: _ClassVar[int]
    ACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    CL_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    IS_ACTIVE_FIELD_NUMBER: _ClassVar[int]
    OWNER_TYPE_FIELD_NUMBER: _ClassVar[int]
    START_ROW_FIELD_NUMBER: _ClassVar[int]
    PAGE_SIZE_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    msg_sequence: int
    token: str
    request_id: str
    instrument_id: str
    strategy_id: int
    account_id: str
    cl_order_id: str
    order_id: str
    is_active: int
    owner_type: int
    start_row: int
    page_size: int
    def __init__(self, msg_type: _Optional[int] = ..., msg_sequence: _Optional[int] = ..., token: _Optional[str] = ..., request_id: _Optional[str] = ..., instrument_id: _Optional[str] = ..., strategy_id: _Optional[int] = ..., account_id: _Optional[str] = ..., cl_order_id: _Optional[str] = ..., order_id: _Optional[str] = ..., is_active: _Optional[int] = ..., owner_type: _Optional[int] = ..., start_row: _Optional[int] = ..., page_size: _Optional[int] = ...) -> None: ...

class QryOrdersRsp(_message.Message):
    __slots__ = ("msg_type", "msg_sequence", "request_id", "total_row", "start_row", "page_size", "is_last", "status", "reason", "order")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    MSG_SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    TOTAL_ROW_FIELD_NUMBER: _ClassVar[int]
    START_ROW_FIELD_NUMBER: _ClassVar[int]
    PAGE_SIZE_FIELD_NUMBER: _ClassVar[int]
    IS_LAST_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    ORDER_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    msg_sequence: int
    request_id: str
    total_row: int
    start_row: int
    page_size: int
    is_last: bool
    status: int
    reason: str
    order: _containers.RepeatedCompositeFieldContainer[Order]
    def __init__(self, msg_type: _Optional[int] = ..., msg_sequence: _Optional[int] = ..., request_id: _Optional[str] = ..., total_row: _Optional[int] = ..., start_row: _Optional[int] = ..., page_size: _Optional[int] = ..., is_last: bool = ..., status: _Optional[int] = ..., reason: _Optional[str] = ..., order: _Optional[_Iterable[_Union[Order, _Mapping]]] = ...) -> None: ...

class QryTradesReq(_message.Message):
    __slots__ = ("msg_type", "msg_sequence", "token", "request_id", "security_id", "market", "instrument_id", "appl_id", "strategy_id", "strategy_name", "account_id", "cl_order_id", "order_id", "is_active", "start_row", "page_size")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    MSG_SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    TOKEN_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    SECURITY_ID_FIELD_NUMBER: _ClassVar[int]
    MARKET_FIELD_NUMBER: _ClassVar[int]
    INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    APPL_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_NAME_FIELD_NUMBER: _ClassVar[int]
    ACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    CL_ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    IS_ACTIVE_FIELD_NUMBER: _ClassVar[int]
    START_ROW_FIELD_NUMBER: _ClassVar[int]
    PAGE_SIZE_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    msg_sequence: int
    token: str
    request_id: str
    security_id: str
    market: str
    instrument_id: str
    appl_id: str
    strategy_id: int
    strategy_name: str
    account_id: str
    cl_order_id: str
    order_id: str
    is_active: int
    start_row: int
    page_size: int
    def __init__(self, msg_type: _Optional[int] = ..., msg_sequence: _Optional[int] = ..., token: _Optional[str] = ..., request_id: _Optional[str] = ..., security_id: _Optional[str] = ..., market: _Optional[str] = ..., instrument_id: _Optional[str] = ..., appl_id: _Optional[str] = ..., strategy_id: _Optional[int] = ..., strategy_name: _Optional[str] = ..., account_id: _Optional[str] = ..., cl_order_id: _Optional[str] = ..., order_id: _Optional[str] = ..., is_active: _Optional[int] = ..., start_row: _Optional[int] = ..., page_size: _Optional[int] = ...) -> None: ...

class QryTradesRsp(_message.Message):
    __slots__ = ("msg_type", "msg_sequence", "request_id", "total_row", "start_row", "page_size", "is_last", "status", "reason", "trade")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    MSG_SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    TOTAL_ROW_FIELD_NUMBER: _ClassVar[int]
    START_ROW_FIELD_NUMBER: _ClassVar[int]
    PAGE_SIZE_FIELD_NUMBER: _ClassVar[int]
    IS_LAST_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    TRADE_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    msg_sequence: int
    request_id: str
    total_row: int
    start_row: int
    page_size: int
    is_last: bool
    status: int
    reason: str
    trade: _containers.RepeatedCompositeFieldContainer[Trade]
    def __init__(self, msg_type: _Optional[int] = ..., msg_sequence: _Optional[int] = ..., request_id: _Optional[str] = ..., total_row: _Optional[int] = ..., start_row: _Optional[int] = ..., page_size: _Optional[int] = ..., is_last: bool = ..., status: _Optional[int] = ..., reason: _Optional[str] = ..., trade: _Optional[_Iterable[_Union[Trade, _Mapping]]] = ...) -> None: ...

class OrderEvent(_message.Message):
    __slots__ = ("msg_type", "msg_sequence", "order")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    MSG_SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    ORDER_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    msg_sequence: int
    order: Order
    def __init__(self, msg_type: _Optional[int] = ..., msg_sequence: _Optional[int] = ..., order: _Optional[_Union[Order, _Mapping]] = ...) -> None: ...

class QuoteLevelData(_message.Message):
    __slots__ = ("bid_price", "bid_volume", "ask_price", "ask_volume")
    BID_PRICE_FIELD_NUMBER: _ClassVar[int]
    BID_VOLUME_FIELD_NUMBER: _ClassVar[int]
    ASK_PRICE_FIELD_NUMBER: _ClassVar[int]
    ASK_VOLUME_FIELD_NUMBER: _ClassVar[int]
    bid_price: int
    bid_volume: int
    ask_price: int
    ask_volume: int
    def __init__(self, bid_price: _Optional[int] = ..., bid_volume: _Optional[int] = ..., ask_price: _Optional[int] = ..., ask_volume: _Optional[int] = ...) -> None: ...

class MDSnapshot(_message.Message):
    __slots__ = ("msg_type", "msg_sequence", "last_timestamp", "instrument_id", "market", "security_id", "security_type", "md_date", "md_time", "md_type", "last_price", "volume", "turnover", "high_price", "low_price", "open_price", "close_price", "pre_close_price", "up_limit", "down_limit", "iopv", "trade_nums", "status", "phase_code", "signal_value", "signal_id", "signal_name", "depth_quote")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    MSG_SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    MARKET_FIELD_NUMBER: _ClassVar[int]
    SECURITY_ID_FIELD_NUMBER: _ClassVar[int]
    SECURITY_TYPE_FIELD_NUMBER: _ClassVar[int]
    MD_DATE_FIELD_NUMBER: _ClassVar[int]
    MD_TIME_FIELD_NUMBER: _ClassVar[int]
    MD_TYPE_FIELD_NUMBER: _ClassVar[int]
    LAST_PRICE_FIELD_NUMBER: _ClassVar[int]
    VOLUME_FIELD_NUMBER: _ClassVar[int]
    TURNOVER_FIELD_NUMBER: _ClassVar[int]
    HIGH_PRICE_FIELD_NUMBER: _ClassVar[int]
    LOW_PRICE_FIELD_NUMBER: _ClassVar[int]
    OPEN_PRICE_FIELD_NUMBER: _ClassVar[int]
    CLOSE_PRICE_FIELD_NUMBER: _ClassVar[int]
    PRE_CLOSE_PRICE_FIELD_NUMBER: _ClassVar[int]
    UP_LIMIT_FIELD_NUMBER: _ClassVar[int]
    DOWN_LIMIT_FIELD_NUMBER: _ClassVar[int]
    IOPV_FIELD_NUMBER: _ClassVar[int]
    TRADE_NUMS_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    PHASE_CODE_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_VALUE_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_ID_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_NAME_FIELD_NUMBER: _ClassVar[int]
    DEPTH_QUOTE_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    msg_sequence: int
    last_timestamp: int
    instrument_id: str
    market: str
    security_id: str
    security_type: str
    md_date: int
    md_time: int
    md_type: int
    last_price: int
    volume: int
    turnover: int
    high_price: int
    low_price: int
    open_price: int
    close_price: int
    pre_close_price: int
    up_limit: int
    down_limit: int
    iopv: int
    trade_nums: int
    status: int
    phase_code: int
    signal_value: int
    signal_id: int
    signal_name: str
    depth_quote: _containers.RepeatedCompositeFieldContainer[QuoteLevelData]
    def __init__(self, msg_type: _Optional[int] = ..., msg_sequence: _Optional[int] = ..., last_timestamp: _Optional[int] = ..., instrument_id: _Optional[str] = ..., market: _Optional[str] = ..., security_id: _Optional[str] = ..., security_type: _Optional[str] = ..., md_date: _Optional[int] = ..., md_time: _Optional[int] = ..., md_type: _Optional[int] = ..., last_price: _Optional[int] = ..., volume: _Optional[int] = ..., turnover: _Optional[int] = ..., high_price: _Optional[int] = ..., low_price: _Optional[int] = ..., open_price: _Optional[int] = ..., close_price: _Optional[int] = ..., pre_close_price: _Optional[int] = ..., up_limit: _Optional[int] = ..., down_limit: _Optional[int] = ..., iopv: _Optional[int] = ..., trade_nums: _Optional[int] = ..., status: _Optional[int] = ..., phase_code: _Optional[int] = ..., signal_value: _Optional[int] = ..., signal_id: _Optional[int] = ..., signal_name: _Optional[str] = ..., depth_quote: _Optional[_Iterable[_Union[QuoteLevelData, _Mapping]]] = ...) -> None: ...

class ETFQuoteSnapshot(_message.Message):
    __slots__ = ("msg_type", "msg_sequence", "last_timestamp", "instrument_id", "security_id", "market", "currency_id", "security_type", "symbol", "constituent_nums", "suspension_nums", "up_limit_nums", "down_limit_nums", "bid_iopv", "ask_iopv", "iopv", "pre_close_iopv", "iopv_pct_change", "etf_last_price", "etf_bid_price", "etf_ask_price", "etf_pre_close_price", "etf_pct_change", "index_last_price", "index_pre_close_price", "index_pct_change", "index_deviation", "etf_deviation", "etf_bid_premium_rate", "etf_ask_premium_rate", "etf_premium_rate", "md_date", "md_time")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    MSG_SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    SECURITY_ID_FIELD_NUMBER: _ClassVar[int]
    MARKET_FIELD_NUMBER: _ClassVar[int]
    CURRENCY_ID_FIELD_NUMBER: _ClassVar[int]
    SECURITY_TYPE_FIELD_NUMBER: _ClassVar[int]
    SYMBOL_FIELD_NUMBER: _ClassVar[int]
    CONSTITUENT_NUMS_FIELD_NUMBER: _ClassVar[int]
    SUSPENSION_NUMS_FIELD_NUMBER: _ClassVar[int]
    UP_LIMIT_NUMS_FIELD_NUMBER: _ClassVar[int]
    DOWN_LIMIT_NUMS_FIELD_NUMBER: _ClassVar[int]
    BID_IOPV_FIELD_NUMBER: _ClassVar[int]
    ASK_IOPV_FIELD_NUMBER: _ClassVar[int]
    IOPV_FIELD_NUMBER: _ClassVar[int]
    PRE_CLOSE_IOPV_FIELD_NUMBER: _ClassVar[int]
    IOPV_PCT_CHANGE_FIELD_NUMBER: _ClassVar[int]
    ETF_LAST_PRICE_FIELD_NUMBER: _ClassVar[int]
    ETF_BID_PRICE_FIELD_NUMBER: _ClassVar[int]
    ETF_ASK_PRICE_FIELD_NUMBER: _ClassVar[int]
    ETF_PRE_CLOSE_PRICE_FIELD_NUMBER: _ClassVar[int]
    ETF_PCT_CHANGE_FIELD_NUMBER: _ClassVar[int]
    INDEX_LAST_PRICE_FIELD_NUMBER: _ClassVar[int]
    INDEX_PRE_CLOSE_PRICE_FIELD_NUMBER: _ClassVar[int]
    INDEX_PCT_CHANGE_FIELD_NUMBER: _ClassVar[int]
    INDEX_DEVIATION_FIELD_NUMBER: _ClassVar[int]
    ETF_DEVIATION_FIELD_NUMBER: _ClassVar[int]
    ETF_BID_PREMIUM_RATE_FIELD_NUMBER: _ClassVar[int]
    ETF_ASK_PREMIUM_RATE_FIELD_NUMBER: _ClassVar[int]
    ETF_PREMIUM_RATE_FIELD_NUMBER: _ClassVar[int]
    MD_DATE_FIELD_NUMBER: _ClassVar[int]
    MD_TIME_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    msg_sequence: int
    last_timestamp: int
    instrument_id: str
    security_id: str
    market: str
    currency_id: str
    security_type: str
    symbol: str
    constituent_nums: int
    suspension_nums: int
    up_limit_nums: int
    down_limit_nums: int
    bid_iopv: int
    ask_iopv: int
    iopv: int
    pre_close_iopv: int
    iopv_pct_change: float
    etf_last_price: int
    etf_bid_price: int
    etf_ask_price: int
    etf_pre_close_price: int
    etf_pct_change: float
    index_last_price: int
    index_pre_close_price: int
    index_pct_change: float
    index_deviation: float
    etf_deviation: float
    etf_bid_premium_rate: float
    etf_ask_premium_rate: float
    etf_premium_rate: float
    md_date: int
    md_time: int
    def __init__(self, msg_type: _Optional[int] = ..., msg_sequence: _Optional[int] = ..., last_timestamp: _Optional[int] = ..., instrument_id: _Optional[str] = ..., security_id: _Optional[str] = ..., market: _Optional[str] = ..., currency_id: _Optional[str] = ..., security_type: _Optional[str] = ..., symbol: _Optional[str] = ..., constituent_nums: _Optional[int] = ..., suspension_nums: _Optional[int] = ..., up_limit_nums: _Optional[int] = ..., down_limit_nums: _Optional[int] = ..., bid_iopv: _Optional[int] = ..., ask_iopv: _Optional[int] = ..., iopv: _Optional[int] = ..., pre_close_iopv: _Optional[int] = ..., iopv_pct_change: _Optional[float] = ..., etf_last_price: _Optional[int] = ..., etf_bid_price: _Optional[int] = ..., etf_ask_price: _Optional[int] = ..., etf_pre_close_price: _Optional[int] = ..., etf_pct_change: _Optional[float] = ..., index_last_price: _Optional[int] = ..., index_pre_close_price: _Optional[int] = ..., index_pct_change: _Optional[float] = ..., index_deviation: _Optional[float] = ..., etf_deviation: _Optional[float] = ..., etf_bid_premium_rate: _Optional[float] = ..., etf_ask_premium_rate: _Optional[float] = ..., etf_premium_rate: _Optional[float] = ..., md_date: _Optional[int] = ..., md_time: _Optional[int] = ...) -> None: ...

class ETFQuoteTick(_message.Message):
    __slots__ = ("msg_type", "msg_sequence", "last_timestamp", "instrument_id", "security_id", "market", "security_type", "symbol", "constituent_nums", "suspension_nums", "up_limit_nums", "down_limit_nums", "iopv", "etf_premium_rate", "md_date", "md_time", "etf_last_price", "etf_bid_price", "etf_ask_price", "etf_pre_close_price", "etf_pct_change")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    MSG_SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    SECURITY_ID_FIELD_NUMBER: _ClassVar[int]
    MARKET_FIELD_NUMBER: _ClassVar[int]
    SECURITY_TYPE_FIELD_NUMBER: _ClassVar[int]
    SYMBOL_FIELD_NUMBER: _ClassVar[int]
    CONSTITUENT_NUMS_FIELD_NUMBER: _ClassVar[int]
    SUSPENSION_NUMS_FIELD_NUMBER: _ClassVar[int]
    UP_LIMIT_NUMS_FIELD_NUMBER: _ClassVar[int]
    DOWN_LIMIT_NUMS_FIELD_NUMBER: _ClassVar[int]
    IOPV_FIELD_NUMBER: _ClassVar[int]
    ETF_PREMIUM_RATE_FIELD_NUMBER: _ClassVar[int]
    MD_DATE_FIELD_NUMBER: _ClassVar[int]
    MD_TIME_FIELD_NUMBER: _ClassVar[int]
    ETF_LAST_PRICE_FIELD_NUMBER: _ClassVar[int]
    ETF_BID_PRICE_FIELD_NUMBER: _ClassVar[int]
    ETF_ASK_PRICE_FIELD_NUMBER: _ClassVar[int]
    ETF_PRE_CLOSE_PRICE_FIELD_NUMBER: _ClassVar[int]
    ETF_PCT_CHANGE_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    msg_sequence: int
    last_timestamp: int
    instrument_id: str
    security_id: str
    market: str
    security_type: str
    symbol: str
    constituent_nums: int
    suspension_nums: int
    up_limit_nums: int
    down_limit_nums: int
    iopv: int
    etf_premium_rate: float
    md_date: int
    md_time: int
    etf_last_price: int
    etf_bid_price: int
    etf_ask_price: int
    etf_pre_close_price: int
    etf_pct_change: float
    def __init__(self, msg_type: _Optional[int] = ..., msg_sequence: _Optional[int] = ..., last_timestamp: _Optional[int] = ..., instrument_id: _Optional[str] = ..., security_id: _Optional[str] = ..., market: _Optional[str] = ..., security_type: _Optional[str] = ..., symbol: _Optional[str] = ..., constituent_nums: _Optional[int] = ..., suspension_nums: _Optional[int] = ..., up_limit_nums: _Optional[int] = ..., down_limit_nums: _Optional[int] = ..., iopv: _Optional[int] = ..., etf_premium_rate: _Optional[float] = ..., md_date: _Optional[int] = ..., md_time: _Optional[int] = ..., etf_last_price: _Optional[int] = ..., etf_bid_price: _Optional[int] = ..., etf_ask_price: _Optional[int] = ..., etf_pre_close_price: _Optional[int] = ..., etf_pct_change: _Optional[float] = ...) -> None: ...

class BarMatrix(_message.Message):
    __slots__ = ("msg_type", "msg_sequence", "trade_time", "last_timestamp", "source", "instrument_ids", "cols", "data_matrix")
    class Source(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        INDICATOR: _ClassVar[BarMatrix.Source]
        PREDICTOR: _ClassVar[BarMatrix.Source]
        FACTOR: _ClassVar[BarMatrix.Source]
    INDICATOR: BarMatrix.Source
    PREDICTOR: BarMatrix.Source
    FACTOR: BarMatrix.Source
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    MSG_SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    TRADE_TIME_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    INSTRUMENT_IDS_FIELD_NUMBER: _ClassVar[int]
    COLS_FIELD_NUMBER: _ClassVar[int]
    DATA_MATRIX_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    msg_sequence: int
    trade_time: int
    last_timestamp: int
    source: BarMatrix.Source
    instrument_ids: _containers.RepeatedScalarFieldContainer[str]
    cols: _containers.RepeatedScalarFieldContainer[str]
    data_matrix: bytes
    def __init__(self, msg_type: _Optional[int] = ..., msg_sequence: _Optional[int] = ..., trade_time: _Optional[int] = ..., last_timestamp: _Optional[int] = ..., source: _Optional[_Union[BarMatrix.Source, str]] = ..., instrument_ids: _Optional[_Iterable[str]] = ..., cols: _Optional[_Iterable[str]] = ..., data_matrix: _Optional[bytes] = ...) -> None: ...

class QrySignalKlineReq(_message.Message):
    __slots__ = ("msg_type", "signal_id", "start_date", "request_id")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_ID_FIELD_NUMBER: _ClassVar[int]
    START_DATE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    signal_id: int
    start_date: str
    request_id: str
    def __init__(self, msg_type: _Optional[int] = ..., signal_id: _Optional[int] = ..., start_date: _Optional[str] = ..., request_id: _Optional[str] = ...) -> None: ...

class QrySignalKlineRsp(_message.Message):
    __slots__ = ("msg_type", "data", "request_id", "status", "reason", "is_last", "last_timestamp")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    IS_LAST_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    data: _containers.RepeatedCompositeFieldContainer[MDSnapshot]
    request_id: str
    status: int
    reason: str
    is_last: bool
    last_timestamp: int
    def __init__(self, msg_type: _Optional[int] = ..., data: _Optional[_Iterable[_Union[MDSnapshot, _Mapping]]] = ..., request_id: _Optional[str] = ..., status: _Optional[int] = ..., reason: _Optional[str] = ..., is_last: bool = ..., last_timestamp: _Optional[int] = ...) -> None: ...

class SignalInfoL2(_message.Message):
    __slots__ = ("l2_signal_id", "source_signal_id", "l2_signal_name", "comments", "weight", "source_signal_name")
    L2_SIGNAL_ID_FIELD_NUMBER: _ClassVar[int]
    SOURCE_SIGNAL_ID_FIELD_NUMBER: _ClassVar[int]
    L2_SIGNAL_NAME_FIELD_NUMBER: _ClassVar[int]
    COMMENTS_FIELD_NUMBER: _ClassVar[int]
    WEIGHT_FIELD_NUMBER: _ClassVar[int]
    SOURCE_SIGNAL_NAME_FIELD_NUMBER: _ClassVar[int]
    l2_signal_id: int
    source_signal_id: int
    l2_signal_name: str
    comments: str
    weight: float
    source_signal_name: str
    def __init__(self, l2_signal_id: _Optional[int] = ..., source_signal_id: _Optional[int] = ..., l2_signal_name: _Optional[str] = ..., comments: _Optional[str] = ..., weight: _Optional[float] = ..., source_signal_name: _Optional[str] = ...) -> None: ...

class UpdateSignalParamsReq(_message.Message):
    __slots__ = ("msg_type", "last_timestamp", "request_id", "signal_name", "signal_id", "text", "signal_params", "fund_etfpr_minnav", "fund_etfpr_estcash", "package_info", "signal_info_l2")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_NAME_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_ID_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_PARAMS_FIELD_NUMBER: _ClassVar[int]
    FUND_ETFPR_MINNAV_FIELD_NUMBER: _ClassVar[int]
    FUND_ETFPR_ESTCASH_FIELD_NUMBER: _ClassVar[int]
    PACKAGE_INFO_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_INFO_L2_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    last_timestamp: int
    request_id: str
    signal_name: str
    signal_id: int
    text: str
    signal_params: str
    fund_etfpr_minnav: float
    fund_etfpr_estcash: float
    package_info: _containers.RepeatedCompositeFieldContainer[PackageInfo]
    signal_info_l2: _containers.RepeatedCompositeFieldContainer[SignalInfoL2]
    def __init__(self, msg_type: _Optional[int] = ..., last_timestamp: _Optional[int] = ..., request_id: _Optional[str] = ..., signal_name: _Optional[str] = ..., signal_id: _Optional[int] = ..., text: _Optional[str] = ..., signal_params: _Optional[str] = ..., fund_etfpr_minnav: _Optional[float] = ..., fund_etfpr_estcash: _Optional[float] = ..., package_info: _Optional[_Iterable[_Union[PackageInfo, _Mapping]]] = ..., signal_info_l2: _Optional[_Iterable[_Union[SignalInfoL2, _Mapping]]] = ...) -> None: ...

class UpdateSignalParamsRsp(_message.Message):
    __slots__ = ("msg_type", "last_timestamp", "signal_name", "signal_id", "status", "request_id", "text", "package_info", "signal_info_l2")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_NAME_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    PACKAGE_INFO_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_INFO_L2_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    last_timestamp: int
    signal_name: str
    signal_id: int
    status: int
    request_id: str
    text: str
    package_info: _containers.RepeatedCompositeFieldContainer[PackageInfo]
    signal_info_l2: _containers.RepeatedCompositeFieldContainer[SignalInfoL2]
    def __init__(self, msg_type: _Optional[int] = ..., last_timestamp: _Optional[int] = ..., signal_name: _Optional[str] = ..., signal_id: _Optional[int] = ..., status: _Optional[int] = ..., request_id: _Optional[str] = ..., text: _Optional[str] = ..., package_info: _Optional[_Iterable[_Union[PackageInfo, _Mapping]]] = ..., signal_info_l2: _Optional[_Iterable[_Union[SignalInfoL2, _Mapping]]] = ...) -> None: ...

class UpdateSignalParamsEvent(_message.Message):
    __slots__ = ("msg_type", "last_timestamp", "signal_name", "signal_id", "status", "text", "package_info", "signal_info_l2")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_NAME_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    PACKAGE_INFO_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_INFO_L2_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    last_timestamp: int
    signal_name: str
    signal_id: int
    status: int
    text: str
    package_info: _containers.RepeatedCompositeFieldContainer[PackageInfo]
    signal_info_l2: _containers.RepeatedCompositeFieldContainer[SignalInfoL2]
    def __init__(self, msg_type: _Optional[int] = ..., last_timestamp: _Optional[int] = ..., signal_name: _Optional[str] = ..., signal_id: _Optional[int] = ..., status: _Optional[int] = ..., text: _Optional[str] = ..., package_info: _Optional[_Iterable[_Union[PackageInfo, _Mapping]]] = ..., signal_info_l2: _Optional[_Iterable[_Union[SignalInfoL2, _Mapping]]] = ...) -> None: ...

class NewSignalParamsReq(_message.Message):
    __slots__ = ("msg_type", "last_timestamp", "request_id", "instrument_id", "signal_name", "text", "signal_params", "signal_template_id", "package_info", "signal_info_l2", "node_name")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_NAME_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_PARAMS_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_TEMPLATE_ID_FIELD_NUMBER: _ClassVar[int]
    PACKAGE_INFO_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_INFO_L2_FIELD_NUMBER: _ClassVar[int]
    NODE_NAME_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    last_timestamp: int
    request_id: str
    instrument_id: str
    signal_name: str
    text: str
    signal_params: str
    signal_template_id: str
    package_info: _containers.RepeatedCompositeFieldContainer[PackageInfo]
    signal_info_l2: _containers.RepeatedCompositeFieldContainer[SignalInfoL2]
    node_name: str
    def __init__(self, msg_type: _Optional[int] = ..., last_timestamp: _Optional[int] = ..., request_id: _Optional[str] = ..., instrument_id: _Optional[str] = ..., signal_name: _Optional[str] = ..., text: _Optional[str] = ..., signal_params: _Optional[str] = ..., signal_template_id: _Optional[str] = ..., package_info: _Optional[_Iterable[_Union[PackageInfo, _Mapping]]] = ..., signal_info_l2: _Optional[_Iterable[_Union[SignalInfoL2, _Mapping]]] = ..., node_name: _Optional[str] = ...) -> None: ...

class NewSignalParamsRsp(_message.Message):
    __slots__ = ("msg_type", "last_timestamp", "request_id", "status", "text")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    last_timestamp: int
    request_id: str
    status: int
    text: str
    def __init__(self, msg_type: _Optional[int] = ..., last_timestamp: _Optional[int] = ..., request_id: _Optional[str] = ..., status: _Optional[int] = ..., text: _Optional[str] = ...) -> None: ...

class UpdateSignalGlobalParamsReq(_message.Message):
    __slots__ = ("msg_type", "last_timestamp", "request_id", "signal_template_id", "text", "signal_params")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_TEMPLATE_ID_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_PARAMS_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    last_timestamp: int
    request_id: str
    signal_template_id: str
    text: str
    signal_params: str
    def __init__(self, msg_type: _Optional[int] = ..., last_timestamp: _Optional[int] = ..., request_id: _Optional[str] = ..., signal_template_id: _Optional[str] = ..., text: _Optional[str] = ..., signal_params: _Optional[str] = ...) -> None: ...

class UpdateSignalGlobalParamsRsp(_message.Message):
    __slots__ = ("msg_type", "last_timestamp", "signal_template_id", "status", "request_id", "text", "signal_params")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_TEMPLATE_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_PARAMS_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    last_timestamp: int
    signal_template_id: str
    status: int
    request_id: str
    text: str
    signal_params: str
    def __init__(self, msg_type: _Optional[int] = ..., last_timestamp: _Optional[int] = ..., signal_template_id: _Optional[str] = ..., status: _Optional[int] = ..., request_id: _Optional[str] = ..., text: _Optional[str] = ..., signal_params: _Optional[str] = ...) -> None: ...

class UpdateSignalGlobalParamsEvent(_message.Message):
    __slots__ = ("msg_type", "last_timestamp", "signal_template_id", "status", "text", "signal_params")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_TEMPLATE_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_PARAMS_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    last_timestamp: int
    signal_template_id: str
    status: int
    text: str
    signal_params: str
    def __init__(self, msg_type: _Optional[int] = ..., last_timestamp: _Optional[int] = ..., signal_template_id: _Optional[str] = ..., status: _Optional[int] = ..., text: _Optional[str] = ..., signal_params: _Optional[str] = ...) -> None: ...

class UpdateCurrencyPriceReq(_message.Message):
    __slots__ = ("msg_type", "last_timestamp", "request_id", "currency_id", "currency_price", "text")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    CURRENCY_ID_FIELD_NUMBER: _ClassVar[int]
    CURRENCY_PRICE_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    last_timestamp: int
    request_id: str
    currency_id: str
    currency_price: int
    text: str
    def __init__(self, msg_type: _Optional[int] = ..., last_timestamp: _Optional[int] = ..., request_id: _Optional[str] = ..., currency_id: _Optional[str] = ..., currency_price: _Optional[int] = ..., text: _Optional[str] = ...) -> None: ...

class UpdateCurrencyPriceRsp(_message.Message):
    __slots__ = ("msg_type", "last_timestamp", "status", "request_id", "text")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    last_timestamp: int
    status: int
    request_id: str
    text: str
    def __init__(self, msg_type: _Optional[int] = ..., last_timestamp: _Optional[int] = ..., status: _Optional[int] = ..., request_id: _Optional[str] = ..., text: _Optional[str] = ...) -> None: ...

class Instrument(_message.Message):
    __slots__ = ("instrument_id", "market", "security_id", "symbol", "instrument_type", "security_type", "lot_size", "price_tick", "contract_unit", "intraday_trading", "is_sub", "is_withdraw", "fund_etfpr_minnav", "withdraw_basket_volume", "long_posi_limit", "short_posi_limit", "intraday_open_limit", "max_up", "max_down", "underlying_instrument_id", "chain_codes", "fund_etfpr_estcash", "wind_market", "comments", "is_replace_price", "replace_price", "quote_currency_id", "settle_currency_id", "instrument_sub_type", "min_size", "max_size", "list_date", "delist_date", "settle_date", "total_share", "trade_date", "external_info", "pre_close_price")
    INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    MARKET_FIELD_NUMBER: _ClassVar[int]
    SECURITY_ID_FIELD_NUMBER: _ClassVar[int]
    SYMBOL_FIELD_NUMBER: _ClassVar[int]
    INSTRUMENT_TYPE_FIELD_NUMBER: _ClassVar[int]
    SECURITY_TYPE_FIELD_NUMBER: _ClassVar[int]
    LOT_SIZE_FIELD_NUMBER: _ClassVar[int]
    PRICE_TICK_FIELD_NUMBER: _ClassVar[int]
    CONTRACT_UNIT_FIELD_NUMBER: _ClassVar[int]
    INTRADAY_TRADING_FIELD_NUMBER: _ClassVar[int]
    IS_SUB_FIELD_NUMBER: _ClassVar[int]
    IS_WITHDRAW_FIELD_NUMBER: _ClassVar[int]
    FUND_ETFPR_MINNAV_FIELD_NUMBER: _ClassVar[int]
    WITHDRAW_BASKET_VOLUME_FIELD_NUMBER: _ClassVar[int]
    LONG_POSI_LIMIT_FIELD_NUMBER: _ClassVar[int]
    SHORT_POSI_LIMIT_FIELD_NUMBER: _ClassVar[int]
    INTRADAY_OPEN_LIMIT_FIELD_NUMBER: _ClassVar[int]
    MAX_UP_FIELD_NUMBER: _ClassVar[int]
    MAX_DOWN_FIELD_NUMBER: _ClassVar[int]
    UNDERLYING_INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    CHAIN_CODES_FIELD_NUMBER: _ClassVar[int]
    FUND_ETFPR_ESTCASH_FIELD_NUMBER: _ClassVar[int]
    WIND_MARKET_FIELD_NUMBER: _ClassVar[int]
    COMMENTS_FIELD_NUMBER: _ClassVar[int]
    IS_REPLACE_PRICE_FIELD_NUMBER: _ClassVar[int]
    REPLACE_PRICE_FIELD_NUMBER: _ClassVar[int]
    QUOTE_CURRENCY_ID_FIELD_NUMBER: _ClassVar[int]
    SETTLE_CURRENCY_ID_FIELD_NUMBER: _ClassVar[int]
    INSTRUMENT_SUB_TYPE_FIELD_NUMBER: _ClassVar[int]
    MIN_SIZE_FIELD_NUMBER: _ClassVar[int]
    MAX_SIZE_FIELD_NUMBER: _ClassVar[int]
    LIST_DATE_FIELD_NUMBER: _ClassVar[int]
    DELIST_DATE_FIELD_NUMBER: _ClassVar[int]
    SETTLE_DATE_FIELD_NUMBER: _ClassVar[int]
    TOTAL_SHARE_FIELD_NUMBER: _ClassVar[int]
    TRADE_DATE_FIELD_NUMBER: _ClassVar[int]
    EXTERNAL_INFO_FIELD_NUMBER: _ClassVar[int]
    PRE_CLOSE_PRICE_FIELD_NUMBER: _ClassVar[int]
    instrument_id: str
    market: str
    security_id: str
    symbol: str
    instrument_type: str
    security_type: str
    lot_size: int
    price_tick: float
    contract_unit: float
    intraday_trading: int
    is_sub: int
    is_withdraw: int
    fund_etfpr_minnav: int
    withdraw_basket_volume: int
    long_posi_limit: int
    short_posi_limit: int
    intraday_open_limit: int
    max_up: float
    max_down: float
    underlying_instrument_id: str
    chain_codes: _containers.RepeatedScalarFieldContainer[str]
    fund_etfpr_estcash: float
    wind_market: str
    comments: str
    is_replace_price: int
    replace_price: float
    quote_currency_id: str
    settle_currency_id: str
    instrument_sub_type: str
    min_size: int
    max_size: int
    list_date: str
    delist_date: str
    settle_date: str
    total_share: int
    trade_date: str
    external_info: str
    pre_close_price: float
    def __init__(self, instrument_id: _Optional[str] = ..., market: _Optional[str] = ..., security_id: _Optional[str] = ..., symbol: _Optional[str] = ..., instrument_type: _Optional[str] = ..., security_type: _Optional[str] = ..., lot_size: _Optional[int] = ..., price_tick: _Optional[float] = ..., contract_unit: _Optional[float] = ..., intraday_trading: _Optional[int] = ..., is_sub: _Optional[int] = ..., is_withdraw: _Optional[int] = ..., fund_etfpr_minnav: _Optional[int] = ..., withdraw_basket_volume: _Optional[int] = ..., long_posi_limit: _Optional[int] = ..., short_posi_limit: _Optional[int] = ..., intraday_open_limit: _Optional[int] = ..., max_up: _Optional[float] = ..., max_down: _Optional[float] = ..., underlying_instrument_id: _Optional[str] = ..., chain_codes: _Optional[_Iterable[str]] = ..., fund_etfpr_estcash: _Optional[float] = ..., wind_market: _Optional[str] = ..., comments: _Optional[str] = ..., is_replace_price: _Optional[int] = ..., replace_price: _Optional[float] = ..., quote_currency_id: _Optional[str] = ..., settle_currency_id: _Optional[str] = ..., instrument_sub_type: _Optional[str] = ..., min_size: _Optional[int] = ..., max_size: _Optional[int] = ..., list_date: _Optional[str] = ..., delist_date: _Optional[str] = ..., settle_date: _Optional[str] = ..., total_share: _Optional[int] = ..., trade_date: _Optional[str] = ..., external_info: _Optional[str] = ..., pre_close_price: _Optional[float] = ...) -> None: ...

class QryInstrumentReq(_message.Message):
    __slots__ = ("msg_type", "request_id", "instrument_id", "basket_instrument_id", "market_list")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    BASKET_INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    MARKET_LIST_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    request_id: str
    instrument_id: str
    basket_instrument_id: str
    market_list: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, msg_type: _Optional[int] = ..., request_id: _Optional[str] = ..., instrument_id: _Optional[str] = ..., basket_instrument_id: _Optional[str] = ..., market_list: _Optional[_Iterable[str]] = ...) -> None: ...

class QryInstrumentRsp(_message.Message):
    __slots__ = ("msg_type", "request_id", "status", "reason", "is_last", "data")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    IS_LAST_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    request_id: str
    status: int
    reason: str
    is_last: bool
    data: _containers.RepeatedCompositeFieldContainer[Instrument]
    def __init__(self, msg_type: _Optional[int] = ..., request_id: _Optional[str] = ..., status: _Optional[int] = ..., reason: _Optional[str] = ..., is_last: bool = ..., data: _Optional[_Iterable[_Union[Instrument, _Mapping]]] = ...) -> None: ...

class StrategyInstrument(_message.Message):
    __slots__ = ("instrument_id", "market", "security_id", "sod_qty", "sod_amount")
    INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    MARKET_FIELD_NUMBER: _ClassVar[int]
    SECURITY_ID_FIELD_NUMBER: _ClassVar[int]
    SOD_QTY_FIELD_NUMBER: _ClassVar[int]
    SOD_AMOUNT_FIELD_NUMBER: _ClassVar[int]
    instrument_id: str
    market: str
    security_id: str
    sod_qty: int
    sod_amount: float
    def __init__(self, instrument_id: _Optional[str] = ..., market: _Optional[str] = ..., security_id: _Optional[str] = ..., sod_qty: _Optional[int] = ..., sod_amount: _Optional[float] = ...) -> None: ...

class StrategyInfo(_message.Message):
    __slots__ = ("strategy_id", "strategy_name", "book_id", "status", "comment", "node_id", "node_name", "account_id", "trade_date", "params", "monitor_params", "signal_id", "signal_name", "strategy_instruments", "target_qty", "counter_id", "counter_account_id", "default_params")
    STRATEGY_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_NAME_FIELD_NUMBER: _ClassVar[int]
    BOOK_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    COMMENT_FIELD_NUMBER: _ClassVar[int]
    NODE_ID_FIELD_NUMBER: _ClassVar[int]
    NODE_NAME_FIELD_NUMBER: _ClassVar[int]
    ACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    TRADE_DATE_FIELD_NUMBER: _ClassVar[int]
    PARAMS_FIELD_NUMBER: _ClassVar[int]
    MONITOR_PARAMS_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_ID_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_NAME_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_INSTRUMENTS_FIELD_NUMBER: _ClassVar[int]
    TARGET_QTY_FIELD_NUMBER: _ClassVar[int]
    COUNTER_ID_FIELD_NUMBER: _ClassVar[int]
    COUNTER_ACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    DEFAULT_PARAMS_FIELD_NUMBER: _ClassVar[int]
    strategy_id: int
    strategy_name: str
    book_id: str
    status: str
    comment: str
    node_id: int
    node_name: str
    account_id: str
    trade_date: str
    params: str
    monitor_params: str
    signal_id: int
    signal_name: str
    strategy_instruments: _containers.RepeatedCompositeFieldContainer[StrategyInstrument]
    target_qty: int
    counter_id: str
    counter_account_id: str
    default_params: str
    def __init__(self, strategy_id: _Optional[int] = ..., strategy_name: _Optional[str] = ..., book_id: _Optional[str] = ..., status: _Optional[str] = ..., comment: _Optional[str] = ..., node_id: _Optional[int] = ..., node_name: _Optional[str] = ..., account_id: _Optional[str] = ..., trade_date: _Optional[str] = ..., params: _Optional[str] = ..., monitor_params: _Optional[str] = ..., signal_id: _Optional[int] = ..., signal_name: _Optional[str] = ..., strategy_instruments: _Optional[_Iterable[_Union[StrategyInstrument, _Mapping]]] = ..., target_qty: _Optional[int] = ..., counter_id: _Optional[str] = ..., counter_account_id: _Optional[str] = ..., default_params: _Optional[str] = ...) -> None: ...

class QryStrategyInfoReq(_message.Message):
    __slots__ = ("msg_type", "node_name", "request_id", "strategy_id")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    NODE_NAME_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_ID_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    node_name: str
    request_id: str
    strategy_id: int
    def __init__(self, msg_type: _Optional[int] = ..., node_name: _Optional[str] = ..., request_id: _Optional[str] = ..., strategy_id: _Optional[int] = ...) -> None: ...

class QryStrategyInfoRsp(_message.Message):
    __slots__ = ("msg_type", "request_id", "status", "reason", "is_last", "data")
    class StrategyInfoData(_message.Message):
        __slots__ = ("strategy_template_id", "global_params", "strategy_list", "params_schema", "global_params_schema", "monitor_params_schema", "strategy_template_type")
        STRATEGY_TEMPLATE_ID_FIELD_NUMBER: _ClassVar[int]
        GLOBAL_PARAMS_FIELD_NUMBER: _ClassVar[int]
        STRATEGY_LIST_FIELD_NUMBER: _ClassVar[int]
        PARAMS_SCHEMA_FIELD_NUMBER: _ClassVar[int]
        GLOBAL_PARAMS_SCHEMA_FIELD_NUMBER: _ClassVar[int]
        MONITOR_PARAMS_SCHEMA_FIELD_NUMBER: _ClassVar[int]
        STRATEGY_TEMPLATE_TYPE_FIELD_NUMBER: _ClassVar[int]
        strategy_template_id: str
        global_params: str
        strategy_list: _containers.RepeatedCompositeFieldContainer[StrategyInfo]
        params_schema: str
        global_params_schema: str
        monitor_params_schema: str
        strategy_template_type: str
        def __init__(self, strategy_template_id: _Optional[str] = ..., global_params: _Optional[str] = ..., strategy_list: _Optional[_Iterable[_Union[StrategyInfo, _Mapping]]] = ..., params_schema: _Optional[str] = ..., global_params_schema: _Optional[str] = ..., monitor_params_schema: _Optional[str] = ..., strategy_template_type: _Optional[str] = ...) -> None: ...
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    IS_LAST_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    request_id: str
    status: int
    reason: str
    is_last: bool
    data: _containers.RepeatedCompositeFieldContainer[QryStrategyInfoRsp.StrategyInfoData]
    def __init__(self, msg_type: _Optional[int] = ..., request_id: _Optional[str] = ..., status: _Optional[int] = ..., reason: _Optional[str] = ..., is_last: bool = ..., data: _Optional[_Iterable[_Union[QryStrategyInfoRsp.StrategyInfoData, _Mapping]]] = ...) -> None: ...

class PackageInfo(_message.Message):
    __slots__ = ("instrument_id", "component_instrument_id", "component_qty", "is_sub_cash_replace", "is_sub_cash_replace_amount", "is_withdraw_cash", "is_withdraw_cash_replace_amount")
    INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    COMPONENT_INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    COMPONENT_QTY_FIELD_NUMBER: _ClassVar[int]
    IS_SUB_CASH_REPLACE_FIELD_NUMBER: _ClassVar[int]
    IS_SUB_CASH_REPLACE_AMOUNT_FIELD_NUMBER: _ClassVar[int]
    IS_WITHDRAW_CASH_FIELD_NUMBER: _ClassVar[int]
    IS_WITHDRAW_CASH_REPLACE_AMOUNT_FIELD_NUMBER: _ClassVar[int]
    instrument_id: str
    component_instrument_id: str
    component_qty: int
    is_sub_cash_replace: int
    is_sub_cash_replace_amount: float
    is_withdraw_cash: int
    is_withdraw_cash_replace_amount: float
    def __init__(self, instrument_id: _Optional[str] = ..., component_instrument_id: _Optional[str] = ..., component_qty: _Optional[int] = ..., is_sub_cash_replace: _Optional[int] = ..., is_sub_cash_replace_amount: _Optional[float] = ..., is_withdraw_cash: _Optional[int] = ..., is_withdraw_cash_replace_amount: _Optional[float] = ...) -> None: ...

class SignalInfo(_message.Message):
    __slots__ = ("signal_id", "signal_name", "instrument_id", "instrument_type", "market", "security_id", "status", "comment", "node_id", "node_name", "trade_date", "fund_etfpr_minnav", "fund_etfpr_estcash", "params", "package_info", "signal_info_l2")
    SIGNAL_ID_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_NAME_FIELD_NUMBER: _ClassVar[int]
    INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    INSTRUMENT_TYPE_FIELD_NUMBER: _ClassVar[int]
    MARKET_FIELD_NUMBER: _ClassVar[int]
    SECURITY_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    COMMENT_FIELD_NUMBER: _ClassVar[int]
    NODE_ID_FIELD_NUMBER: _ClassVar[int]
    NODE_NAME_FIELD_NUMBER: _ClassVar[int]
    TRADE_DATE_FIELD_NUMBER: _ClassVar[int]
    FUND_ETFPR_MINNAV_FIELD_NUMBER: _ClassVar[int]
    FUND_ETFPR_ESTCASH_FIELD_NUMBER: _ClassVar[int]
    PARAMS_FIELD_NUMBER: _ClassVar[int]
    PACKAGE_INFO_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_INFO_L2_FIELD_NUMBER: _ClassVar[int]
    signal_id: int
    signal_name: str
    instrument_id: str
    instrument_type: str
    market: str
    security_id: str
    status: str
    comment: str
    node_id: int
    node_name: str
    trade_date: str
    fund_etfpr_minnav: float
    fund_etfpr_estcash: float
    params: str
    package_info: _containers.RepeatedCompositeFieldContainer[PackageInfo]
    signal_info_l2: _containers.RepeatedCompositeFieldContainer[SignalInfoL2]
    def __init__(self, signal_id: _Optional[int] = ..., signal_name: _Optional[str] = ..., instrument_id: _Optional[str] = ..., instrument_type: _Optional[str] = ..., market: _Optional[str] = ..., security_id: _Optional[str] = ..., status: _Optional[str] = ..., comment: _Optional[str] = ..., node_id: _Optional[int] = ..., node_name: _Optional[str] = ..., trade_date: _Optional[str] = ..., fund_etfpr_minnav: _Optional[float] = ..., fund_etfpr_estcash: _Optional[float] = ..., params: _Optional[str] = ..., package_info: _Optional[_Iterable[_Union[PackageInfo, _Mapping]]] = ..., signal_info_l2: _Optional[_Iterable[_Union[SignalInfoL2, _Mapping]]] = ...) -> None: ...

class QrySignalInfoReq(_message.Message):
    __slots__ = ("msg_type", "request_id", "signal_id")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_ID_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    request_id: str
    signal_id: int
    def __init__(self, msg_type: _Optional[int] = ..., request_id: _Optional[str] = ..., signal_id: _Optional[int] = ...) -> None: ...

class QrySignalInfoRsp(_message.Message):
    __slots__ = ("msg_type", "request_id", "status", "reason", "is_last", "data")
    class SignalInfoData(_message.Message):
        __slots__ = ("signal_template_id", "global_params", "signal_list", "signal_template_type", "params_schema", "global_params_schema")
        SIGNAL_TEMPLATE_ID_FIELD_NUMBER: _ClassVar[int]
        GLOBAL_PARAMS_FIELD_NUMBER: _ClassVar[int]
        SIGNAL_LIST_FIELD_NUMBER: _ClassVar[int]
        SIGNAL_TEMPLATE_TYPE_FIELD_NUMBER: _ClassVar[int]
        PARAMS_SCHEMA_FIELD_NUMBER: _ClassVar[int]
        GLOBAL_PARAMS_SCHEMA_FIELD_NUMBER: _ClassVar[int]
        signal_template_id: str
        global_params: str
        signal_list: _containers.RepeatedCompositeFieldContainer[SignalInfo]
        signal_template_type: str
        params_schema: str
        global_params_schema: str
        def __init__(self, signal_template_id: _Optional[str] = ..., global_params: _Optional[str] = ..., signal_list: _Optional[_Iterable[_Union[SignalInfo, _Mapping]]] = ..., signal_template_type: _Optional[str] = ..., params_schema: _Optional[str] = ..., global_params_schema: _Optional[str] = ...) -> None: ...
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    IS_LAST_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    request_id: str
    status: int
    reason: str
    is_last: bool
    data: _containers.RepeatedCompositeFieldContainer[QrySignalInfoRsp.SignalInfoData]
    def __init__(self, msg_type: _Optional[int] = ..., request_id: _Optional[str] = ..., status: _Optional[int] = ..., reason: _Optional[str] = ..., is_last: bool = ..., data: _Optional[_Iterable[_Union[QrySignalInfoRsp.SignalInfoData, _Mapping]]] = ...) -> None: ...

class Currency(_message.Message):
    __slots__ = ("currency_id", "fx_rate_cny", "comments", "update_time")
    CURRENCY_ID_FIELD_NUMBER: _ClassVar[int]
    FX_RATE_CNY_FIELD_NUMBER: _ClassVar[int]
    COMMENTS_FIELD_NUMBER: _ClassVar[int]
    UPDATE_TIME_FIELD_NUMBER: _ClassVar[int]
    currency_id: str
    fx_rate_cny: float
    comments: str
    update_time: str
    def __init__(self, currency_id: _Optional[str] = ..., fx_rate_cny: _Optional[float] = ..., comments: _Optional[str] = ..., update_time: _Optional[str] = ...) -> None: ...

class QryCurrencyReq(_message.Message):
    __slots__ = ("msg_type", "request_id")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    request_id: str
    def __init__(self, msg_type: _Optional[int] = ..., request_id: _Optional[str] = ...) -> None: ...

class QryCurrencyRsp(_message.Message):
    __slots__ = ("msg_type", "request_id", "status", "reason", "is_last", "data")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    IS_LAST_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    request_id: str
    status: int
    reason: str
    is_last: bool
    data: _containers.RepeatedCompositeFieldContainer[Currency]
    def __init__(self, msg_type: _Optional[int] = ..., request_id: _Optional[str] = ..., status: _Optional[int] = ..., reason: _Optional[str] = ..., is_last: bool = ..., data: _Optional[_Iterable[_Union[Currency, _Mapping]]] = ...) -> None: ...

class Node(_message.Message):
    __slots__ = ("node_name", "data_center", "ip_address", "node_status", "comments", "network_delay", "quote_id", "node_id", "node_type")
    NODE_NAME_FIELD_NUMBER: _ClassVar[int]
    DATA_CENTER_FIELD_NUMBER: _ClassVar[int]
    IP_ADDRESS_FIELD_NUMBER: _ClassVar[int]
    NODE_STATUS_FIELD_NUMBER: _ClassVar[int]
    COMMENTS_FIELD_NUMBER: _ClassVar[int]
    NETWORK_DELAY_FIELD_NUMBER: _ClassVar[int]
    QUOTE_ID_FIELD_NUMBER: _ClassVar[int]
    NODE_ID_FIELD_NUMBER: _ClassVar[int]
    NODE_TYPE_FIELD_NUMBER: _ClassVar[int]
    node_name: str
    data_center: str
    ip_address: str
    node_status: str
    comments: str
    network_delay: int
    quote_id: str
    node_id: int
    node_type: int
    def __init__(self, node_name: _Optional[str] = ..., data_center: _Optional[str] = ..., ip_address: _Optional[str] = ..., node_status: _Optional[str] = ..., comments: _Optional[str] = ..., network_delay: _Optional[int] = ..., quote_id: _Optional[str] = ..., node_id: _Optional[int] = ..., node_type: _Optional[int] = ...) -> None: ...

class QryNodeReq(_message.Message):
    __slots__ = ("msg_type", "request_id")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    request_id: str
    def __init__(self, msg_type: _Optional[int] = ..., request_id: _Optional[str] = ...) -> None: ...

class QryNodeRsp(_message.Message):
    __slots__ = ("msg_type", "nodes", "status", "reason", "request_id")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    NODES_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    nodes: _containers.RepeatedCompositeFieldContainer[Node]
    status: int
    reason: str
    request_id: str
    def __init__(self, msg_type: _Optional[int] = ..., nodes: _Optional[_Iterable[_Union[Node, _Mapping]]] = ..., status: _Optional[int] = ..., reason: _Optional[str] = ..., request_id: _Optional[str] = ...) -> None: ...

class QuoteInstance(_message.Message):
    __slots__ = ("quote_id", "quote_type", "ip_address", "comments", "data_center", "node_status")
    QUOTE_ID_FIELD_NUMBER: _ClassVar[int]
    QUOTE_TYPE_FIELD_NUMBER: _ClassVar[int]
    IP_ADDRESS_FIELD_NUMBER: _ClassVar[int]
    COMMENTS_FIELD_NUMBER: _ClassVar[int]
    DATA_CENTER_FIELD_NUMBER: _ClassVar[int]
    NODE_STATUS_FIELD_NUMBER: _ClassVar[int]
    quote_id: str
    quote_type: str
    ip_address: str
    comments: str
    data_center: str
    node_status: str
    def __init__(self, quote_id: _Optional[str] = ..., quote_type: _Optional[str] = ..., ip_address: _Optional[str] = ..., comments: _Optional[str] = ..., data_center: _Optional[str] = ..., node_status: _Optional[str] = ...) -> None: ...

class RiskItem(_message.Message):
    __slots__ = ("account_id", "instrument_id", "status", "symbol", "single_order_qty", "long_posi_qty_up", "short_posi_qty_up", "prev_price_deviation", "last_price_deviation", "best_price_deviation", "posi_concentration", "fund_available", "total_buy_order_qty", "total_sell_order_qty", "total_buy_order_amt", "total_sell_order_amt", "total_buy_trade_qty", "total_sell_trade_qty", "total_buy_trade_amt", "total_sell_trade_amt", "total_buy_active_qty", "total_sell_active_qty", "total_buy_order_nums", "total_sell_order_nums", "warning_ratio")
    ACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    SYMBOL_FIELD_NUMBER: _ClassVar[int]
    SINGLE_ORDER_QTY_FIELD_NUMBER: _ClassVar[int]
    LONG_POSI_QTY_UP_FIELD_NUMBER: _ClassVar[int]
    SHORT_POSI_QTY_UP_FIELD_NUMBER: _ClassVar[int]
    PREV_PRICE_DEVIATION_FIELD_NUMBER: _ClassVar[int]
    LAST_PRICE_DEVIATION_FIELD_NUMBER: _ClassVar[int]
    BEST_PRICE_DEVIATION_FIELD_NUMBER: _ClassVar[int]
    POSI_CONCENTRATION_FIELD_NUMBER: _ClassVar[int]
    FUND_AVAILABLE_FIELD_NUMBER: _ClassVar[int]
    TOTAL_BUY_ORDER_QTY_FIELD_NUMBER: _ClassVar[int]
    TOTAL_SELL_ORDER_QTY_FIELD_NUMBER: _ClassVar[int]
    TOTAL_BUY_ORDER_AMT_FIELD_NUMBER: _ClassVar[int]
    TOTAL_SELL_ORDER_AMT_FIELD_NUMBER: _ClassVar[int]
    TOTAL_BUY_TRADE_QTY_FIELD_NUMBER: _ClassVar[int]
    TOTAL_SELL_TRADE_QTY_FIELD_NUMBER: _ClassVar[int]
    TOTAL_BUY_TRADE_AMT_FIELD_NUMBER: _ClassVar[int]
    TOTAL_SELL_TRADE_AMT_FIELD_NUMBER: _ClassVar[int]
    TOTAL_BUY_ACTIVE_QTY_FIELD_NUMBER: _ClassVar[int]
    TOTAL_SELL_ACTIVE_QTY_FIELD_NUMBER: _ClassVar[int]
    TOTAL_BUY_ORDER_NUMS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_SELL_ORDER_NUMS_FIELD_NUMBER: _ClassVar[int]
    WARNING_RATIO_FIELD_NUMBER: _ClassVar[int]
    account_id: str
    instrument_id: str
    status: int
    symbol: str
    single_order_qty: int
    long_posi_qty_up: int
    short_posi_qty_up: int
    prev_price_deviation: float
    last_price_deviation: float
    best_price_deviation: float
    posi_concentration: float
    fund_available: float
    total_buy_order_qty: int
    total_sell_order_qty: int
    total_buy_order_amt: float
    total_sell_order_amt: float
    total_buy_trade_qty: int
    total_sell_trade_qty: int
    total_buy_trade_amt: float
    total_sell_trade_amt: float
    total_buy_active_qty: int
    total_sell_active_qty: int
    total_buy_order_nums: int
    total_sell_order_nums: int
    warning_ratio: float
    def __init__(self, account_id: _Optional[str] = ..., instrument_id: _Optional[str] = ..., status: _Optional[int] = ..., symbol: _Optional[str] = ..., single_order_qty: _Optional[int] = ..., long_posi_qty_up: _Optional[int] = ..., short_posi_qty_up: _Optional[int] = ..., prev_price_deviation: _Optional[float] = ..., last_price_deviation: _Optional[float] = ..., best_price_deviation: _Optional[float] = ..., posi_concentration: _Optional[float] = ..., fund_available: _Optional[float] = ..., total_buy_order_qty: _Optional[int] = ..., total_sell_order_qty: _Optional[int] = ..., total_buy_order_amt: _Optional[float] = ..., total_sell_order_amt: _Optional[float] = ..., total_buy_trade_qty: _Optional[int] = ..., total_sell_trade_qty: _Optional[int] = ..., total_buy_trade_amt: _Optional[float] = ..., total_sell_trade_amt: _Optional[float] = ..., total_buy_active_qty: _Optional[int] = ..., total_sell_active_qty: _Optional[int] = ..., total_buy_order_nums: _Optional[int] = ..., total_sell_order_nums: _Optional[int] = ..., warning_ratio: _Optional[float] = ...) -> None: ...

class QryRiskItemReq(_message.Message):
    __slots__ = ("msg_type", "request_id", "account_id", "instrument_id")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    ACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    request_id: str
    account_id: _containers.RepeatedScalarFieldContainer[str]
    instrument_id: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, msg_type: _Optional[int] = ..., request_id: _Optional[str] = ..., account_id: _Optional[_Iterable[str]] = ..., instrument_id: _Optional[_Iterable[str]] = ...) -> None: ...

class QryRiskItemRsp(_message.Message):
    __slots__ = ("msg_type", "request_id", "status", "reason", "is_last", "data")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    IS_LAST_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    request_id: str
    status: int
    reason: str
    is_last: bool
    data: _containers.RepeatedCompositeFieldContainer[RiskItem]
    def __init__(self, msg_type: _Optional[int] = ..., request_id: _Optional[str] = ..., status: _Optional[int] = ..., reason: _Optional[str] = ..., is_last: bool = ..., data: _Optional[_Iterable[_Union[RiskItem, _Mapping]]] = ...) -> None: ...

class RiskMarketParams(_message.Message):
    __slots__ = ("account_id", "market", "risk_code", "risk_name", "control_type", "control_point", "status", "set_value", "params", "comments", "create_by", "update_by", "create_time", "update_time")
    ACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    MARKET_FIELD_NUMBER: _ClassVar[int]
    RISK_CODE_FIELD_NUMBER: _ClassVar[int]
    RISK_NAME_FIELD_NUMBER: _ClassVar[int]
    CONTROL_TYPE_FIELD_NUMBER: _ClassVar[int]
    CONTROL_POINT_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    SET_VALUE_FIELD_NUMBER: _ClassVar[int]
    PARAMS_FIELD_NUMBER: _ClassVar[int]
    COMMENTS_FIELD_NUMBER: _ClassVar[int]
    CREATE_BY_FIELD_NUMBER: _ClassVar[int]
    UPDATE_BY_FIELD_NUMBER: _ClassVar[int]
    CREATE_TIME_FIELD_NUMBER: _ClassVar[int]
    UPDATE_TIME_FIELD_NUMBER: _ClassVar[int]
    account_id: str
    market: str
    risk_code: str
    risk_name: str
    control_type: str
    control_point: str
    status: int
    set_value: float
    params: str
    comments: str
    create_by: str
    update_by: str
    create_time: str
    update_time: str
    def __init__(self, account_id: _Optional[str] = ..., market: _Optional[str] = ..., risk_code: _Optional[str] = ..., risk_name: _Optional[str] = ..., control_type: _Optional[str] = ..., control_point: _Optional[str] = ..., status: _Optional[int] = ..., set_value: _Optional[float] = ..., params: _Optional[str] = ..., comments: _Optional[str] = ..., create_by: _Optional[str] = ..., update_by: _Optional[str] = ..., create_time: _Optional[str] = ..., update_time: _Optional[str] = ...) -> None: ...

class QryRiskMarketParamsReq(_message.Message):
    __slots__ = ("msg_type", "request_id", "account_id", "market")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    ACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    MARKET_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    request_id: str
    account_id: _containers.RepeatedScalarFieldContainer[str]
    market: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, msg_type: _Optional[int] = ..., request_id: _Optional[str] = ..., account_id: _Optional[_Iterable[str]] = ..., market: _Optional[_Iterable[str]] = ...) -> None: ...

class QryRiskMarketParamsRsp(_message.Message):
    __slots__ = ("msg_type", "request_id", "status", "reason", "is_last", "data")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    IS_LAST_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    request_id: str
    status: int
    reason: str
    is_last: bool
    data: _containers.RepeatedCompositeFieldContainer[RiskMarketParams]
    def __init__(self, msg_type: _Optional[int] = ..., request_id: _Optional[str] = ..., status: _Optional[int] = ..., reason: _Optional[str] = ..., is_last: bool = ..., data: _Optional[_Iterable[_Union[RiskMarketParams, _Mapping]]] = ...) -> None: ...

class UpdateRiskMarketParamsReq(_message.Message):
    __slots__ = ("msg_type", "last_timestamp", "request_id", "operate_type", "risk_params", "account_id")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    OPERATE_TYPE_FIELD_NUMBER: _ClassVar[int]
    RISK_PARAMS_FIELD_NUMBER: _ClassVar[int]
    ACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    last_timestamp: int
    request_id: str
    operate_type: str
    risk_params: _containers.RepeatedCompositeFieldContainer[RiskMarketParams]
    account_id: str
    def __init__(self, msg_type: _Optional[int] = ..., last_timestamp: _Optional[int] = ..., request_id: _Optional[str] = ..., operate_type: _Optional[str] = ..., risk_params: _Optional[_Iterable[_Union[RiskMarketParams, _Mapping]]] = ..., account_id: _Optional[str] = ...) -> None: ...

class UpdateRiskMarketParamsRsp(_message.Message):
    __slots__ = ("msg_type", "last_timestamp", "request_id", "operate_type", "status", "text", "risk_params")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    OPERATE_TYPE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    RISK_PARAMS_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    last_timestamp: int
    request_id: str
    operate_type: str
    status: int
    text: str
    risk_params: _containers.RepeatedCompositeFieldContainer[RiskMarketParams]
    def __init__(self, msg_type: _Optional[int] = ..., last_timestamp: _Optional[int] = ..., request_id: _Optional[str] = ..., operate_type: _Optional[str] = ..., status: _Optional[int] = ..., text: _Optional[str] = ..., risk_params: _Optional[_Iterable[_Union[RiskMarketParams, _Mapping]]] = ...) -> None: ...

class QryQuoteInstanceReq(_message.Message):
    __slots__ = ("msg_type", "request_id")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    request_id: str
    def __init__(self, msg_type: _Optional[int] = ..., request_id: _Optional[str] = ...) -> None: ...

class QryQuoteInstanceRsp(_message.Message):
    __slots__ = ("msg_type", "quote_instances", "status", "reason", "request_id")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    QUOTE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    quote_instances: _containers.RepeatedCompositeFieldContainer[QuoteInstance]
    status: int
    reason: str
    request_id: str
    def __init__(self, msg_type: _Optional[int] = ..., quote_instances: _Optional[_Iterable[_Union[QuoteInstance, _Mapping]]] = ..., status: _Optional[int] = ..., reason: _Optional[str] = ..., request_id: _Optional[str] = ...) -> None: ...

class SignalStatDetail(_message.Message):
    __slots__ = ("signal_id", "signal_name", "status", "text", "instrument_id", "md_type", "md_time", "signal_value", "last_price")
    SIGNAL_ID_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_NAME_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    MD_TYPE_FIELD_NUMBER: _ClassVar[int]
    MD_TIME_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_VALUE_FIELD_NUMBER: _ClassVar[int]
    LAST_PRICE_FIELD_NUMBER: _ClassVar[int]
    signal_id: int
    signal_name: str
    status: str
    text: str
    instrument_id: str
    md_type: int
    md_time: int
    signal_value: int
    last_price: int
    def __init__(self, signal_id: _Optional[int] = ..., signal_name: _Optional[str] = ..., status: _Optional[str] = ..., text: _Optional[str] = ..., instrument_id: _Optional[str] = ..., md_type: _Optional[int] = ..., md_time: _Optional[int] = ..., signal_value: _Optional[int] = ..., last_price: _Optional[int] = ...) -> None: ...

class QrySignalStatReq(_message.Message):
    __slots__ = ("msg_type", "node_name", "node_type", "last_timestamp", "request_id", "signal_id")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    NODE_NAME_FIELD_NUMBER: _ClassVar[int]
    NODE_TYPE_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_ID_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    node_name: str
    node_type: int
    last_timestamp: int
    request_id: str
    signal_id: int
    def __init__(self, msg_type: _Optional[int] = ..., node_name: _Optional[str] = ..., node_type: _Optional[int] = ..., last_timestamp: _Optional[int] = ..., request_id: _Optional[str] = ..., signal_id: _Optional[int] = ...) -> None: ...

class QrySignalStatRsp(_message.Message):
    __slots__ = ("msg_type", "node_name", "node_type", "last_timestamp", "request_id", "signal_stat")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    NODE_NAME_FIELD_NUMBER: _ClassVar[int]
    NODE_TYPE_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_STAT_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    node_name: str
    node_type: int
    last_timestamp: int
    request_id: str
    signal_stat: _containers.RepeatedCompositeFieldContainer[SignalStatDetail]
    def __init__(self, msg_type: _Optional[int] = ..., node_name: _Optional[str] = ..., node_type: _Optional[int] = ..., last_timestamp: _Optional[int] = ..., request_id: _Optional[str] = ..., signal_stat: _Optional[_Iterable[_Union[SignalStatDetail, _Mapping]]] = ...) -> None: ...

class SignalStatEvent(_message.Message):
    __slots__ = ("msg_type", "node_name", "node_type", "last_timestamp", "msg_sequence", "signal_id", "signal_name", "signal_stat")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    NODE_NAME_FIELD_NUMBER: _ClassVar[int]
    NODE_TYPE_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    MSG_SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_ID_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_NAME_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_STAT_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    node_name: str
    node_type: int
    last_timestamp: int
    msg_sequence: int
    signal_id: int
    signal_name: str
    signal_stat: _containers.RepeatedCompositeFieldContainer[SignalStatDetail]
    def __init__(self, msg_type: _Optional[int] = ..., node_name: _Optional[str] = ..., node_type: _Optional[int] = ..., last_timestamp: _Optional[int] = ..., msg_sequence: _Optional[int] = ..., signal_id: _Optional[int] = ..., signal_name: _Optional[str] = ..., signal_stat: _Optional[_Iterable[_Union[SignalStatDetail, _Mapping]]] = ...) -> None: ...

class SignalQuoteData(_message.Message):
    __slots__ = ("id", "value")
    ID_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    id: str
    value: int
    def __init__(self, id: _Optional[str] = ..., value: _Optional[int] = ...) -> None: ...

class SignalSnapshot(_message.Message):
    __slots__ = ("msg_type", "msg_sequence", "last_timestamp", "instrument_id", "security_id", "market", "security_type", "symbol", "md_date", "md_time", "signal_type", "signal_id", "signal_name", "signal_value", "signal_quote", "depth_quote")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    MSG_SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    SECURITY_ID_FIELD_NUMBER: _ClassVar[int]
    MARKET_FIELD_NUMBER: _ClassVar[int]
    SECURITY_TYPE_FIELD_NUMBER: _ClassVar[int]
    SYMBOL_FIELD_NUMBER: _ClassVar[int]
    MD_DATE_FIELD_NUMBER: _ClassVar[int]
    MD_TIME_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_TYPE_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_ID_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_NAME_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_VALUE_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_QUOTE_FIELD_NUMBER: _ClassVar[int]
    DEPTH_QUOTE_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    msg_sequence: int
    last_timestamp: int
    instrument_id: str
    security_id: str
    market: str
    security_type: str
    symbol: str
    md_date: int
    md_time: int
    signal_type: int
    signal_id: int
    signal_name: str
    signal_value: int
    signal_quote: _containers.RepeatedCompositeFieldContainer[SignalQuoteData]
    depth_quote: _containers.RepeatedCompositeFieldContainer[QuoteLevelData]
    def __init__(self, msg_type: _Optional[int] = ..., msg_sequence: _Optional[int] = ..., last_timestamp: _Optional[int] = ..., instrument_id: _Optional[str] = ..., security_id: _Optional[str] = ..., market: _Optional[str] = ..., security_type: _Optional[str] = ..., symbol: _Optional[str] = ..., md_date: _Optional[int] = ..., md_time: _Optional[int] = ..., signal_type: _Optional[int] = ..., signal_id: _Optional[int] = ..., signal_name: _Optional[str] = ..., signal_value: _Optional[int] = ..., signal_quote: _Optional[_Iterable[_Union[SignalQuoteData, _Mapping]]] = ..., depth_quote: _Optional[_Iterable[_Union[QuoteLevelData, _Mapping]]] = ...) -> None: ...

class RCParam(_message.Message):
    __slots__ = ("msg_type", "msg_sequence", "last_timestamp", "account_id", "instrument_id", "market", "security_id", "buy_order_num", "sell_order_num", "buy_cancel_num", "sell_cancel_num", "buy_order_qty", "sell_order_qty", "buy_order_amt", "sell_order_amt", "buy_active_qty", "sell_active_qty", "buy_active_amt", "sell_active_amt", "buy_trade_qty", "sell_trade_qty", "buy_trade_amt", "sell_trade_amt")
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    MSG_SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    ACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    INSTRUMENT_ID_FIELD_NUMBER: _ClassVar[int]
    MARKET_FIELD_NUMBER: _ClassVar[int]
    SECURITY_ID_FIELD_NUMBER: _ClassVar[int]
    BUY_ORDER_NUM_FIELD_NUMBER: _ClassVar[int]
    SELL_ORDER_NUM_FIELD_NUMBER: _ClassVar[int]
    BUY_CANCEL_NUM_FIELD_NUMBER: _ClassVar[int]
    SELL_CANCEL_NUM_FIELD_NUMBER: _ClassVar[int]
    BUY_ORDER_QTY_FIELD_NUMBER: _ClassVar[int]
    SELL_ORDER_QTY_FIELD_NUMBER: _ClassVar[int]
    BUY_ORDER_AMT_FIELD_NUMBER: _ClassVar[int]
    SELL_ORDER_AMT_FIELD_NUMBER: _ClassVar[int]
    BUY_ACTIVE_QTY_FIELD_NUMBER: _ClassVar[int]
    SELL_ACTIVE_QTY_FIELD_NUMBER: _ClassVar[int]
    BUY_ACTIVE_AMT_FIELD_NUMBER: _ClassVar[int]
    SELL_ACTIVE_AMT_FIELD_NUMBER: _ClassVar[int]
    BUY_TRADE_QTY_FIELD_NUMBER: _ClassVar[int]
    SELL_TRADE_QTY_FIELD_NUMBER: _ClassVar[int]
    BUY_TRADE_AMT_FIELD_NUMBER: _ClassVar[int]
    SELL_TRADE_AMT_FIELD_NUMBER: _ClassVar[int]
    msg_type: int
    msg_sequence: int
    last_timestamp: int
    account_id: str
    instrument_id: str
    market: str
    security_id: str
    buy_order_num: int
    sell_order_num: int
    buy_cancel_num: int
    sell_cancel_num: int
    buy_order_qty: int
    sell_order_qty: int
    buy_order_amt: float
    sell_order_amt: float
    buy_active_qty: int
    sell_active_qty: int
    buy_active_amt: float
    sell_active_amt: float
    buy_trade_qty: int
    sell_trade_qty: int
    buy_trade_amt: float
    sell_trade_amt: float
    def __init__(self, msg_type: _Optional[int] = ..., msg_sequence: _Optional[int] = ..., last_timestamp: _Optional[int] = ..., account_id: _Optional[str] = ..., instrument_id: _Optional[str] = ..., market: _Optional[str] = ..., security_id: _Optional[str] = ..., buy_order_num: _Optional[int] = ..., sell_order_num: _Optional[int] = ..., buy_cancel_num: _Optional[int] = ..., sell_cancel_num: _Optional[int] = ..., buy_order_qty: _Optional[int] = ..., sell_order_qty: _Optional[int] = ..., buy_order_amt: _Optional[float] = ..., sell_order_amt: _Optional[float] = ..., buy_active_qty: _Optional[int] = ..., sell_active_qty: _Optional[int] = ..., buy_active_amt: _Optional[float] = ..., sell_active_amt: _Optional[float] = ..., buy_trade_qty: _Optional[int] = ..., sell_trade_qty: _Optional[int] = ..., buy_trade_amt: _Optional[float] = ..., sell_trade_amt: _Optional[float] = ...) -> None: ...
