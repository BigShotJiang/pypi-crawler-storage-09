"""
Version for Hatch
"""

__version__ = "0.0.8"
