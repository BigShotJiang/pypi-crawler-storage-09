# Data Manifest

A simple way to describe collections of RDF (or other) data to be loaded or ingested by tools.
