from .environments import Environment

environment = Environment()
