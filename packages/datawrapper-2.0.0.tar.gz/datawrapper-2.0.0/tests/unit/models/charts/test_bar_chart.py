import datawrapper
from tests.utils import _test_class


def test_bar_overlay():
    _test_class(datawrapper.BarOverlay)


def test_bar_chart():
    _test_class(datawrapper.BarChart)
