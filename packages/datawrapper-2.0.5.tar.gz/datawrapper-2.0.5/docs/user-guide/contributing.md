
```{include} ../../CONTRIBUTING.md
```
