"""Tests for MCP MetricFlow Server."""
