"""Version information for Davia."""

__version__ = "0.1.18"
