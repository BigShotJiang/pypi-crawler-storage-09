"""Exception tests package."""
