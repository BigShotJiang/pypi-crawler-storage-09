"""API handlers for dbbasic-accounts admin interface"""
