"""
dbbasic-web: A Unix-philosophy web framework
Filesystem routing, SSE/WS, background jobs, message bus, flat files
"""
__version__ = "0.1.10"
