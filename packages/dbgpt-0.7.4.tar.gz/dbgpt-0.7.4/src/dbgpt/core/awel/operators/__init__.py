"""The module of operator."""
