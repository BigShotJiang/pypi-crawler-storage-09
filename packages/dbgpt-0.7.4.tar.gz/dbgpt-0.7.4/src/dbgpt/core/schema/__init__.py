"""Module for common schemas."""
