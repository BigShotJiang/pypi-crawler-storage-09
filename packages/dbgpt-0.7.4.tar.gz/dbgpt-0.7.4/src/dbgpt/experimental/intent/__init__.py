"""Intent detection module."""
