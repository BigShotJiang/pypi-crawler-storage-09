"""Disk cache storage implementation."""
