"""Knowledge JSON."""
