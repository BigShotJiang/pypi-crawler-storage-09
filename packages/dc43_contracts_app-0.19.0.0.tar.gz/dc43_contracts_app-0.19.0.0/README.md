# dc43-contracts-app

A FastAPI demo application that surfaces the DC43 contracts and datasets
experience. It relies on the shared service clients to talk to any
configured backend implementation and bundles HTML templates, static
assets, and sample records for local demos.
