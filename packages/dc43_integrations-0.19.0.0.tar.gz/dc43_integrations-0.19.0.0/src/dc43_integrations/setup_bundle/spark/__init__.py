"""Spark pipeline stub provider registration."""

from . import pipeline_stub as _pipeline_stub  # noqa: F401

__all__: list[str] = []

