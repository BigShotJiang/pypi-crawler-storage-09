# dc43-service-clients

This package contains the shared service client contracts and default local implementations
used by dc43 integrations and backends. Install it independently when you need to author new
integrations or build your own service backends.
