
DEFAULT_DDC_HOST = 'https://api.cropom.com'

DEFAULT_AOI_BUCKET = "ddc-aoicube-data"

DEFAULT_DDC_BUCKET = "ddc-environmental-data"
