from uuid import UUID
from datetime import datetime
from pydantic import BaseModel, ConfigDict, Field, validator
from typing import Dict, List, Optional, Any