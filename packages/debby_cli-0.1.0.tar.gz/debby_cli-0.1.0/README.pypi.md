An extensible dbt linter.

## Install

```
pip install debby-cli
```

## Usage

Please see the documentation site for further instructions.

https://www.debbyapp.com/docs
