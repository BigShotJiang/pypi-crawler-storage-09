# Changelog

## 0.3.0
- Initial FastMCP client edition.
