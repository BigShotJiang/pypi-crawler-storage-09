"""Support executing the CLI by doing `python -m deepmcpagent`."""

from .cli import app

app(prog_name="deepmcpagent")
