"""Agent builders that use the FastMCP client and MCP-only tools."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any, cast

from langchain.chat_models import init_chat_model
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.runnables import Runnable
from langchain_core.tools import BaseTool
from langgraph.prebuilt import create_react_agent

from .clients import FastMCPMulti
from .config import ServerSpec
from .cross_agent import CrossAgent, make_cross_agent_tools  # NEW
from .prompt import DEFAULT_SYSTEM_PROMPT
from .tools import MCPClientError, MCPToolLoader

# Model can be a provider string (handled by LangChain), a chat model instance, or a Runnable.
ModelLike = str | BaseChatModel | Runnable[Any, Any]


def _normalize_model(model: ModelLike) -> Runnable[Any, Any]:
    """Normalize the supplied model into a Runnable."""
    if isinstance(model, str):
        # This supports many providers via lc init strings, not just OpenAI.
        return cast(Runnable[Any, Any], init_chat_model(model))
    # Already BaseChatModel or Runnable
    return cast(Runnable[Any, Any], model)


async def build_deep_agent(
    *,
    servers: Mapping[str, ServerSpec],
    model: ModelLike,
    instructions: str | None = None,
    trace_tools: bool = False,
    cross_agents: Mapping[str, CrossAgent] | None = None,  # NEW
) -> tuple[Runnable[Any, Any], MCPToolLoader]:
    """Build an MCP-first agent graph.

    This function discovers tools from the configured MCP servers, converts them into
    LangChain tools, and then builds an agent. If the optional `deepagents` package is
    installed, a Deep Agent loop is created. Otherwise, a LangGraph ReAct agent is used.

    Args:
        servers: Mapping of server name to spec (HTTP/SSE recommended for FastMCP).
        model: REQUIRED. Either a LangChain chat model instance, a provider id string
            accepted by `init_chat_model`, or a Runnable.
        instructions: Optional system prompt. If not provided, uses DEFAULT_SYSTEM_PROMPT.
        trace_tools: If True, print each tool invocation and result from inside the tool
            wrapper (works for both DeepAgents and LangGraph prebuilt).
        cross_agents: Optional mapping of peer name -> CrossAgent. When provided, each
            peer is exposed as a tool (e.g., `ask_agent_<name>`) and an optional
            `broadcast_to_agents` tool is added to consult multiple peers.

    Returns:
        Tuple of `(graph, loader)` where:
            - `graph` is a LangGraph or DeepAgents runnable with `.ainvoke`.
            - `loader` can be used to introspect tools.
    """
    if model is None:  # Defensive check; CLI/code must always pass a model now.
        raise ValueError("A model is required. Provide a model instance or a provider id string.")

    # Simple printing callbacks for tracing (kept dependency-free)
    def _before(name: str, kwargs: dict[str, Any]) -> None:
        if trace_tools:
            print(f"→ Invoking tool: {name} with {kwargs}")

    def _after(name: str, res: Any) -> None:
        if not trace_tools:
            return
        pretty = res
        for attr in ("data", "text", "content", "result"):
            try:
                val = getattr(res, attr, None)
                if val not in (None, ""):
                    pretty = val
                    break
            except Exception:
                continue
        print(f"✔ Tool result from {name}: {pretty}")

    def _error(name: str, exc: Exception) -> None:
        if trace_tools:
            print(f"✖ {name} error: {exc}")

    multi = FastMCPMulti(servers)
    loader = MCPToolLoader(
        multi,
        on_before=_before if trace_tools else None,
        on_after=_after if trace_tools else None,
        on_error=_error if trace_tools else None,
    )

    try:
        discovered = await loader.get_all_tools()
        tools: list[BaseTool] = list(discovered) if discovered else []
    except MCPClientError as exc:
        raise RuntimeError(
            f"Failed to initialize agent because tool discovery failed. Details: {exc}"
        ) from exc

    # Attach cross-agent tools if provided
    if cross_agents:
        tools.extend(make_cross_agent_tools(cross_agents))

    if not tools:
        print("[deepmcpagent] No tools discovered from MCP servers; agent will run without tools.")

    chat: Runnable[Any, Any] = _normalize_model(model)
    sys_prompt = instructions or DEFAULT_SYSTEM_PROMPT

    # ----------------------------------------------------------------------
    # Attempt DeepAgents first, then gracefully fall back to LangGraph.
    # ----------------------------------------------------------------------
    try:
        # Optional deep agent loop if installed.
        from deepagents import create_deep_agent  # type: ignore

        graph = cast(
            Runnable[Any, Any],
            create_deep_agent(tools=tools, instructions=sys_prompt, model=chat),
        )

    except ImportError:
        # Fallback to LangGraph’s ReAct agent, compatible with all versions.
        import inspect

        try:
            sig = inspect.signature(create_react_agent)
            params = set(sig.parameters.keys())

            # base kwargs always valid
            kwargs: dict[str, Any] = {"model": chat, "tools": tools}

            # Only pass prompt args if supported by this version
            if "system_prompt" in params:
                kwargs["system_prompt"] = sys_prompt
            elif "state_modifier" in params:
                kwargs["state_modifier"] = sys_prompt
            # Newer versions (>=0.6) have no prompt args → skip

            graph = cast(Runnable[Any, Any], create_react_agent(**kwargs))

        except TypeError:
            # Absolute fallback for latest versions: no prompt args allowed
            graph = cast(Runnable[Any, Any], create_react_agent(model=chat, tools=tools))

    return graph, loader
