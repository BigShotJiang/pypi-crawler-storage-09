import os

DEMO_DIR = os.path.join(os.path.abspath(os.path.dirname(os.path.dirname(__file__))), "demos")
