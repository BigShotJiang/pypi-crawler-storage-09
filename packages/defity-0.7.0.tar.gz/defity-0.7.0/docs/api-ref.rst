=============
API Reference
=============

.. module:: defity

.. autofunction:: from_file

.. autofunction:: from_bytes

.. autofunction:: is_file_of_type

.. autofunction:: is_bytes_of_type
