class GenException(Exception):
    pass


class RenderException(GenException):
    pass
