from . import app


def main():
    app()
