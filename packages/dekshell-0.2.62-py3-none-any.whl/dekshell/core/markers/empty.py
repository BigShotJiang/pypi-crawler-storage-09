from .base.shell import MarkerShell


class EmptyMarker(MarkerShell):
    pass
