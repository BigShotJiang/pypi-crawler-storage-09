from .command import app


def main():
    app()
