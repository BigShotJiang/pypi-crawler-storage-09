
class DeltaRunnerError(Exception):
    pass


class DeltaRunnerNotFound(DeltaRunnerError):
    pass
