# Constants
current_version = "1.4"
manifest_version = current_version
manifest_schema_filename = "manifest-schema.json"
