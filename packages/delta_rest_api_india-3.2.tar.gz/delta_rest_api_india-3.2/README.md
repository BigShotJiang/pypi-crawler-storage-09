# delta_rest_api_india

A simple Python wrapper for **Delta Exchange (India)** REST API — allows trading on both **Testnet** and **Production** environments.

---

## 🌐 Create an Account
👉 [Testnet (India)](https://testnet.delta.exchange)

---

## 📦 Installation
```bash
pip install delta_rest_api_india
```

---

## 🚀 Quick Start

```python
import delta_rest_api_india as delta_algo

# --- API Configuration ---
api_key = ""          # Your API key
api_secret = ""       # Your API secret
price = ""            # Needed for LIMIT orders (default is MARKET)
SL = ""               # Stop Loss (for bracket orders)
TP = ""               # Take Profit (for bracket orders)
LOT = ""              # Quantity
side = ""             # BUY / SELL
product_symbol = ""   # Example: BTCUSD / ETHUSD
product_id = ""       # Example: BTCUSD = 27, ETHUSD = 3136
base_url = ""         # Use either PROD or TESTNET URL
timeframe = ""        # Chart timeframe
symbol = ''           # For better performance we use binance exchange so please use symbol with UPPER CASE Like e.g FOR ETH ETH/USDT and BTC BTC/USDT 
lookback =            # [OPTIONAL] Number of candles to load, default 500 
ema_value =           # [OPTIONAL] EMA VALUE e.g 10 or 22, default 9
ma_value =            # [OPTIONAL] MA VALUE e.g 10 or 22, default 20
swing_lookback =      # [OPTIONAL] Candles to look back for swing detection, default 50
FVGlimit =            # [OPTIONAL] Number of candles to fetch for Fair Value Gaps, default 500
RSIlimit =            # [OPTIONAL] Number of candles to fetch for RSI loop back, default 500
rsi_period =          # [OPTIONAL] Number of candles to fetch for RSI, default 14
overbought =          # [OPTIONAL] Number of candles to fetch for RSI, default 70
oversold =            # [OPTIONAL] Number of candles to fetch for RSI, default 30 
timeframeT1 = ''      # [OPTIONAL] MENTION trading timeframe e.g 5m , default 15m
timeframeT2 = ''      # [OPTIONAL] Higher timeframe e.g 15m , default 1h
timeframeT3 = ''      # [OPTIONAL] Higher timeframe e.g 1h , default 4h
timeframeT4 = ''      # [OPTIONAL] Higher timeframe e.g 1h , default 1d
```

---

## 🌍 Base URLs

| Environment | URL |
|--------------|-----|
| **Production (India)** | `https://api.india.delta.exchange` |
| **Testnet (India)** | `https://cdn-ind.testnet.deltaex.org` |

---

## 🧩 API Methods

### ➕ Place a Bracket Order
```python
delta_algo.PLACE_BRACKET_ORDER(
    api_key, api_secret, price, SL, TP, LOT, side,
    product_symbol, product_id, base_url
)
```

### 💰 Place a Normal Order
```python
delta_algo.PLACE_ORDER(
    api_key, api_secret, price, LOT, side, product_id, base_url
)
```

### 💵 Check Balance
```python
delta_algo.BALANCE_CHECK(api_key, api_secret, base_url)
```

### 📈 Get Current Price
```python
delta_algo.CURRENT_PRICE(symbol)
```
### 📈 Get EMA Price
```python
delta_algo.EMA(symbol, lookback, timeframe, ema_value)
```
### 📈 Get MOVING AVERAGE Price
```python
delta_algo.MOVING_AVG(symbol, lookback, timeframe, ma_value)
```
### 📈 Get EMA AND MOVING AVERAGE CROSSOVER
```python
delta_algo.EMA_MA_CROSSOVER(symbol, lookback, timeframe, ma_value, ema_value)
```

### 📈 Get SUPPORT AND RESISTANCE 
```python
delta_algo.get_support_resistance(symbol, timeframe, lookback, swing_lookback)
```
### 📈 Get PIVOT BASE SUPPORT AND RESISTANCE 
```python
delta_algo.pivot_support_resistance(symbol, timeframe, swing_lookback)

```
### 📈 CANDLE PATTERNE Detection
```python
delta_algo.CANDLE_PATTERNE(symbol,timeframe)

```
### 📈 CANDLE PATTERNE Detection
```python
delta_algo.CANDLE_PATTERNE(symbol,timeframe)

```
### 📈 RSI Indicator
```python
delta_algo.RSI(symbol, timeframe, RSIlimit, rsi_period, overbought, oversold)

```
### 📈 FAIR VALUE GAP Detection
```python
delta_algo.FVG(symbol, timeframe)

```
### 📈 Multiple timeframe analysis (RSI, CANDLE PATTERNE, SIDEWAYS OR TRANDING, FAIR VALUE GAP)
```python
delta_algo.MARKET_MOOD(symbol, timeframeT1, timeframeT2, timeframeT3, timeframeT4)

```
---

## 🧠 Upcoming Features (Next Version)
-  PLAN TO DESING DASHBORAD LIKE ALL IN ONE PROOF WITH LIVE MARKET STATUS 

---

## 📬 For Feedback and Contact
📧 **shashankjoshi61@yahoo.com**
