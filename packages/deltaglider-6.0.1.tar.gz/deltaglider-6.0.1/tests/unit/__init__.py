"""Unit tests for DeltaGlider."""
