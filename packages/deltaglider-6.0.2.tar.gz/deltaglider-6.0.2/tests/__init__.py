"""Tests for DeltaGlider."""
