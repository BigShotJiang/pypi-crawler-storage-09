from .minute import AaveMinute
from .tick import AaveTick