from importlib.metadata import version

__name__ = 'denovonear'
__version__ = version(__name__)
