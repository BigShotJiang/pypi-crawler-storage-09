For usage help, simply run the script directly.
If the Scripts folder has been added to PATH, can be run
directly from console with "describealign" in any directory.
The github contains more usage information.

