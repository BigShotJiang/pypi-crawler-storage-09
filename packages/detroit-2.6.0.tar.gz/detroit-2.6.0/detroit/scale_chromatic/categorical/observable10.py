from ..colors import colors

SCHEME_OBSERVABLE_10 = colors(
    "4269d0efb118ff725c6cc5b03ca951ff8ab7a463f297bbf59c6b4e9498a0"
)
