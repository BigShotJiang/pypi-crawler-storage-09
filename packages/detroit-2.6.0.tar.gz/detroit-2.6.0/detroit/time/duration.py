duration_second = 1000
duration_minute = duration_second * 60
duration_hour = duration_minute * 60
duration_day = duration_hour * 24
duration_week = duration_day * 7
duration_month = duration_day * 30
duration_year = duration_day * 365
