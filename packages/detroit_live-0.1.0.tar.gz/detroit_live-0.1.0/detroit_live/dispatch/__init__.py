from .dispatch import Dispatch, dispatch, parse_typenames

__all__ = [
    "Dispatch",
    "dispatch",
    "parse_typenames",
]
