# OpenAI Without Pydantic

[![PyPI version](https://badge.fury.io/py/developeralex-openai-without-pydantic.svg)](https://badge.fury.io/py/developeralex-openai-without-pydantic)
[![Python Support](https://img.shields.io/badge/python-3.10%2B-blue)](https://pypi.org/project/developeralex-openai-without-pydantic/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)

A simple Python package for calling OpenAI's API without using Pydantic or the OpenAI SDK. Perfect for environments where Pydantic is unavailable or you want minimal dependencies.

## Features

- ✅ Simple, single-function API: `ask_ai_question(input_text, question_asked)`
- ✅ **Zero Pydantic dependency** - uses direct HTTP requests
- ✅ **No OpenAI SDK required** - bypasses all SDK dependencies
- ✅ Support for all OpenAI chat models (GPT-4, GPT-4o, GPT-3.5, etc.)
- ✅ Customizable parameters (temperature, max_tokens, model)
- ✅ Type hints for better IDE support
- ✅ Comprehensive error handling
- ✅ Only requires `requests` library

## Installation

Install from PyPI:

```bash
pip install openai-without-pydantic
```

That's it! Only `requests` is installed - no Pydantic, no OpenAI SDK!

## Quick Start

### Setting Your OpenAI API Key

The package needs your OpenAI API key to make requests. Set it as an environment variable:

**Linux/macOS (bash/zsh):**
```bash
export OPENAI_API_KEY='your-api-key-here'
```

**Windows (Command Prompt):**
```cmd
set OPENAI_API_KEY=your-api-key-here
```

**Windows (PowerShell):**
```powershell
$env:OPENAI_API_KEY='your-api-key-here'
```

**Or use a `.env` file (recommended for development):**
```bash
# Create a .env file in your project directory
OPENAI_API_KEY=your-api-key-here
```

Then load it in your Python code:
```python
from dotenv import load_dotenv
load_dotenv()  # This loads the .env file
```

> **Note:** Install `python-dotenv` for `.env` file support: `pip install python-dotenv`

## Usage

### Basic Example

```python
from openai_wrapper import ask_ai_question

input_text = """
Python is a high-level programming language created by Guido van Rossum 
and first released in 1991.
"""

question = "Who created Python?"

response = ask_ai_question(
    input_text=input_text,
    question_asked=question
)

print(response)  # Output: Python was created by Guido van Rossum.
```

### Advanced Usage

```python
from openai_wrapper import ask_ai_question

# Use custom parameters
response = ask_ai_question(
    input_text="Your context here...",
    question_asked="Your question here...",
    model="gpt-4o",              # Specify model
    temperature=0.3,              # Lower for more factual responses
    max_tokens=200,               # Limit response length
    api_key="your-key-here"       # Or use environment variable
)
```

## Function Parameters

- **input_text** (str, required): The context/text to use for answering the question
- **question_asked** (str, required): The question to ask about the input_text
- **api_key** (str, optional): OpenAI API key (defaults to OPENAI_API_KEY env var)
- **model** (str, optional): The OpenAI model to use (default: "gpt-4o-mini")
- **temperature** (float, optional): Sampling temperature 0-2 (default: 0.7)
- **max_tokens** (int, optional): Maximum tokens in response (default: None)

## Running the Examples

Check out the `examples/` directory for various usage examples:

```bash
# Basic usage
python examples/basic_usage.py

# Advanced features
python examples/advanced_usage.py

# Batch processing
python examples/batch_processing.py
```

**Or use the convenience scripts (automatically activates virtual environment):**

```bash
./run_examples.sh    # Interactive menu
./run_basic.sh       # Run basic example
./run_advanced.sh    # Run advanced example
./run_batch.sh       # Run batch example
```

See [examples/README.md](examples/README.md) for detailed information about each example, or [SCRIPTS.md](SCRIPTS.md) for more about the convenience scripts.

## Project Structure

```
.
├── openai_wrapper/          # Main package
│   ├── __init__.py          # Package initialization
│   ├── client.py            # Core implementation
│   └── py.typed             # Type hint marker
├── examples/                # Usage examples
│   ├── basic_usage.py       # Simple examples
│   ├── advanced_usage.py    # Advanced features
│   ├── batch_processing.py  # Batch operations
│   └── README.md            # Examples documentation
├── tests/                   # Unit tests
│   ├── __init__.py
│   └── test_client.py       # Test suite
├── .github/workflows/       # CI/CD pipelines
│   ├── test.yml             # Automated testing
│   └── publish.yml          # PyPI publishing
├── run_examples.sh          # Interactive example runner
├── run_basic.sh             # Quick run basic example
├── run_advanced.sh          # Quick run advanced example
├── run_batch.sh             # Quick run batch example
├── run_tests.sh             # Quick run tests
├── CHANGELOG.md             # Version history
├── CONTRIBUTING.md          # Contribution guidelines
├── SECURITY.md              # Security policy
├── PUBLISHING.md            # Publishing guide
├── SCRIPTS.md               # Convenience scripts docs
├── LICENSE                  # MIT License
├── README.md                # This file
├── pyproject.toml           # Modern Python packaging
├── setup.py                 # Package setup
└── requirements.txt         # Dependencies
```

## Error Handling

The package includes comprehensive error handling:

```python
try:
    response = ask_ai_question(input_text="...", question_asked="...")
except ValueError as e:
    print(f"Configuration error: {e}")
except Exception as e:
    print(f"API error: {e}")
```

## Why No Pydantic?

This package is specifically designed for environments where Pydantic is not available. 

**The Problem:** The official OpenAI Python SDK (`openai` package) has a hard dependency on `pydantic` and `pydantic-core`, which may be unavailable in some environments.

**Our Solution:** We bypass the OpenAI SDK entirely and call the OpenAI API directly using HTTP requests via the `requests` library. This eliminates all Pydantic dependencies while maintaining full functionality.

## Dependencies

- `requests>=2.25.0` - For making HTTP requests to OpenAI API
- **That's it!** No Pydantic, no OpenAI SDK, no hidden dependencies.

## Testing

Run the test suite:
```bash
pytest tests/ -v
```

With coverage:
```bash
pytest tests/ --cov=openai_wrapper --cov-report=term-missing
```

See [CONTRIBUTING.md](CONTRIBUTING.md) for development setup.

## Contributing

Contributions are welcome! Please see [CONTRIBUTING.md](CONTRIBUTING.md) for:
- Development setup
- Coding standards
- How to submit pull requests
- Running tests

## Security

For security concerns, please see [SECURITY.md](SECURITY.md) for:
- Reporting vulnerabilities
- Security best practices
- API key safety guidelines

## Publishing

To publish this package to PyPI, see [PUBLISHING.md](PUBLISHING.md) for step-by-step instructions.

## FAQ

Got questions? Check out the [FAQ.md](FAQ.md) for answers to common questions!

## Changelog

See [CHANGELOG.md](CHANGELOG.md) for version history and release notes.

## License

MIT License - see [LICENSE](LICENSE) for details.

## Code of Conduct

This project follows a Code of Conduct to ensure a welcoming environment. See [CODE_OF_CONDUCT.md](CODE_OF_CONDUCT.md).

## Links

- **PyPI**: https://pypi.org/project/developeralex-openai-without-pydantic/
- **GitHub**: https://github.com/DeveloperAlex/pypi_OpenAI_Without_Pydantic
- **Issues**: https://github.com/DeveloperAlex/pypi_OpenAI_Without_Pydantic/issues
- **Quick Start**: [QUICKSTART.md](QUICKSTART.md)
- **FAQ**: [FAQ.md](FAQ.md)
