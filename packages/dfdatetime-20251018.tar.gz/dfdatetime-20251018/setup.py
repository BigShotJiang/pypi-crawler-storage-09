#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Installation and deployment script."""

from setuptools import setup


setup()
