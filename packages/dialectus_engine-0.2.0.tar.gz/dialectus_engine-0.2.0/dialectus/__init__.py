"""Dialectus - AI Debate System"""

from pkgutil import extend_path

__path__ = extend_path(__path__, __name__)
__all__: list[str] = []
__version__ = "0.2.0"
