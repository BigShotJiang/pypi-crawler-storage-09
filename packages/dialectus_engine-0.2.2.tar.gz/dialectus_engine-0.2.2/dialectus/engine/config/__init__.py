"""Configuration management for the AI debate system."""
