"""Model management and Ollama integration."""
