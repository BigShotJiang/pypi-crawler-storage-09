from .diceware import diceware

__all__ = ["diceware"]
