from .lib import load_config

__version__ = "0.1.0"

__all__ = ["load_config"]