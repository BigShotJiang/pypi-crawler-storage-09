# dictforge

Forge Kindle-compatible dictionaries for every language


### Дополнительно

Чтобы увидеть все параметры, используйте:
```bash
dictforge --help
```
