"""Forge Kindle-compatible dictionaries for every language

The file is mandatory for build system to find the package.
"""

from dictforge.__about__ import __version__

__all__ = ["__version__"]
