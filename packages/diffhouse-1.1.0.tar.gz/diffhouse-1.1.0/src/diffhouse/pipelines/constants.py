# these characters were randomly selected from the Unicode Supplementary Private
# Use Area B to avoid collisions with any real text data
UNIT_SEPARATOR = '\U00100808'
RECORD_SEPARATOR = '\U001044f6'
