class ToolProviderCredentialValidationError(Exception):
    pass


class ToolProviderOAuthError(Exception):
    pass


class DatasourceCredentialValidationError(Exception):
    pass


class DatasourceOAuthError(Exception):
    pass
