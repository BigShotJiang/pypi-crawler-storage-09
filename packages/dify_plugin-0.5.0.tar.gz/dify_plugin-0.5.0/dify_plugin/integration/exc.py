class PluginStoppedError(Exception):
    """
    The plugin has stopped.
    """

    pass
