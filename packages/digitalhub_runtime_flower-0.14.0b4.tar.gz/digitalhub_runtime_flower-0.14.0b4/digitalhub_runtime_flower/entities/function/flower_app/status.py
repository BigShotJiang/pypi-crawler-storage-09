# SPDX-FileCopyrightText: © 2025 DSLab - Fondazione Bruno Kessler
#
# SPDX-License-Identifier: Apache-2.0

from __future__ import annotations

from digitalhub_runtime_flower.entities.function._base.status import FunctionStatusFlower


class FunctionStatusFlowerApp(FunctionStatusFlower):
    """
    FunctionStatusFlowerApp status.
    """
