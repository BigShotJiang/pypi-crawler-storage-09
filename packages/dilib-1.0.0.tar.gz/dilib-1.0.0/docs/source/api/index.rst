API
=================

..  toctree::
    :maxdepth: 2

.. automodule:: dilib.specs
    :members:

.. automodule:: dilib.config
    :members:

.. automodule:: dilib.container
    :members:

.. automodule:: dilib.errors
    :members:
