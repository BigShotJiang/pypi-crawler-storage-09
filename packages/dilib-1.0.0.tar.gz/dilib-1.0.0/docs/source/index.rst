dilib
===================

.. include:: ../../README.md
   :parser: myst_parser.sphinx_

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   intro_di
   overview
   design
   non_lib_alts
   lib_alts
   patterns
   Changelog <https://github.com/ansatzcapital/dilib/releases>
   api/index
