#!/bin/bash
set -e

pixi shell -e dev
