"""Version information for Dinnovos Agent"""

__version__ = "0.2.0"