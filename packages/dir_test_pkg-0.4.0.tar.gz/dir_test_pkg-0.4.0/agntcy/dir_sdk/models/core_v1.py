# Copyright AGNTCY Contributors (https://github.com/agntcy)
# SPDX-License-Identifier: Apache-2.0

from agntcy.dir.core.v1.record_pb2 import *
from agntcy.dir.core.v1.record_pb2_grpc import *
