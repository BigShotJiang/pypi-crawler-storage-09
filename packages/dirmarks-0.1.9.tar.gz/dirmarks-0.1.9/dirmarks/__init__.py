from importlib.resources import files
DATA_PATH = str(files("dirmarks") / "data")
