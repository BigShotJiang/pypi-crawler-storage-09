Please note that this project is a mirror of the following project:

<https://github.com/disposable-email-domains/disposable-email-domains>

If you feel a domain should or shouldn't be on the blocklist, you are
encouraged to make a pull request against the source repository, *NOT* this
repository.
