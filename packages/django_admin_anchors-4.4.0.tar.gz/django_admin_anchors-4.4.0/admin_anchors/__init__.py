from admin_anchors.decorators import admin_anchor

__all__ = ["admin_anchor"]
