from django.apps import AppConfig


class AdminNoticeConfig(AppConfig):
    name = "admin_notice"
