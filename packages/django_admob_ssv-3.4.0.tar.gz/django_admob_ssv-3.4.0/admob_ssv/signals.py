import django.dispatch

valid_admob_ssv = django.dispatch.Signal()
