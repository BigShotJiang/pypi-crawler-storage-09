---
name: "Issue"
about: "For cases clearly pointing to an issue in django-allauth"
title: ""
labels: ""
assignees: []

---