from django.apps import AppConfig


class AuthStyleConfig(AppConfig):
    name = "auth_style"
    verbose_name = "Auth Style"
