# Django Blog Package
# A reusable Django application for adding blog functionality to any Django project

default_app_config = "blog.apps.BlogConfig"
