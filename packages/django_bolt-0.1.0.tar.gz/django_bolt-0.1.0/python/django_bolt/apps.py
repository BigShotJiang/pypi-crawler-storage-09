from django.apps import AppConfig


class DjangoBoltConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'django_bolt'
    verbose_name = 'Django Bolt'
