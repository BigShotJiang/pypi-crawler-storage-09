"""
Pytest configuration for admin integration tests.

The parent conftest will auto-detect admin_tests in the path
and configure Django with admin apps enabled.
"""
