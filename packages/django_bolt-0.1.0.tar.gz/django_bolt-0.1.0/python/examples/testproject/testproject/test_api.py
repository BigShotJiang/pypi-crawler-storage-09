from django_bolt import BoltAPI


api = BoltAPI(prefix="/test")
