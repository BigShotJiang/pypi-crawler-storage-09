// This module contains JSON serialization utilities that are currently unused
// but kept for potential future optimizations