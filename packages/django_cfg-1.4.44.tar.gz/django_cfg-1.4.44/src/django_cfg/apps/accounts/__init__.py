"""
Accounts app for user management.
"""
default_app_config = 'apps.accounts.apps.AccountsConfig'
