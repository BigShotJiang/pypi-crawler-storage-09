"""
User Admin v2.0 - Hybrid Pydantic Approach

Enhanced user management with Material Icons and clean declarative config.
Note: Uses hybrid approach due to BaseUserAdmin requirement and standalone actions.
"""

from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.shortcuts import redirect
from django.urls import reverse
from unfold.forms import AdminPasswordChangeForm, UserChangeForm, UserCreationForm

from django_cfg.modules.django_admin import (
    AdminConfig,
    FieldConfig,
    FieldsetConfig,
    Icons,
    computed_field,
)
from django_cfg.modules.django_admin.base import PydanticAdmin
from django_cfg.modules.django_admin.utils.badges import StatusBadge
from django_cfg.modules.django_admin.models.badge_models import StatusBadgeConfig

# TODO: Migrate standalone actions to new ActionConfig system
# from django_cfg.modules.django_admin_old import (
#     ActionVariant,
#     StandaloneActionsMixin,
#     standalone_action,
# )

from django_cfg.modules.base import BaseCfgModule

from ..models import CustomUser
from .filters import UserStatusFilter
from .inlines import (
    UserActivityInline,
    UserEmailLogInline,
    UserRegistrationSourceInline,
    UserSupportTicketsInline,
)
from .resources import CustomUserResource


# ===== User Admin =====

customuser_config = AdminConfig(
    model=CustomUser,

    # Performance optimization
    prefetch_related=["groups", "user_permissions"],

    # Import/Export
    import_export_enabled=True,
    resource_class=CustomUserResource,

    # List display
    list_display=[
        "avatar",
        "email",
        "full_name",
        "status",
        "sources_count",
        "activity_count",
        "emails_count",
        "tickets_count",
        "last_login",
        "date_joined"
    ],

    # Display fields with UI widgets
    display_fields=[
        FieldConfig(
            name="avatar",
            title="Avatar",
            ui_widget="user_avatar",
            header=True
        ),
        FieldConfig(
            name="email",
            title="Email",
            ui_widget="badge",
            variant="info",
            icon=Icons.EMAIL
        ),
        FieldConfig(
            name="last_login",
            title="Last Login",
            ui_widget="datetime_relative",
            ordering="last_login"
        ),
        FieldConfig(
            name="date_joined",
            title="Joined",
            ui_widget="datetime_relative",
            ordering="date_joined"
        ),
    ],

    # Filters and search
    list_filter=[UserStatusFilter, "is_staff", "is_active", "date_joined"],
    search_fields=["email", "first_name", "last_name"],

    # Readonly fields
    readonly_fields=["date_joined", "last_login"],

    # Ordering
    ordering=["-date_joined"],
)


@admin.register(CustomUser)
class CustomUserAdmin(BaseUserAdmin, PydanticAdmin):
    """
    User admin using hybrid Pydantic approach.

    Note: Extends BaseUserAdmin for Django user management functionality.
    Uses PydanticAdmin for declarative config (import/export enabled via config).

    Features:
    - Clean declarative config
    - Import/Export functionality (via import_export_enabled in config)
    - Material Icons integration
    - Dynamic inlines based on enabled apps

    TODO: Migrate standalone actions to new ActionConfig system
    """
    config = customuser_config

    # Forms loaded from unfold.forms
    form = UserChangeForm
    add_form = UserCreationForm
    change_password_form = AdminPasswordChangeForm

    # Fieldsets (required by BaseUserAdmin)
    fieldsets = (
        (
            "Personal Information",
            {
                "fields": ("email", "first_name", "last_name", "avatar"),
            },
        ),
        (
            "Contact Information",
            {
                "fields": ("company", "phone", "position"),
            },
        ),
        (
            "Authentication",
            {
                "fields": ("password",),
                "classes": ("collapse",),
            },
        ),
        (
            "Permissions & Status",
            {
                "fields": (
                    ("is_active", "is_staff", "is_superuser"),
                    ("groups",),
                    ("user_permissions",),
                ),
            },
        ),
        (
            "Important Dates",
            {
                "fields": ("last_login", "date_joined"),
                "classes": ("collapse",),
            },
        ),
    )

    add_fieldsets = (
        (
            None,
            {
                "classes": ("wide",),
                "fields": ("email", "password1", "password2"),
            },
        ),
    )

    def get_inlines(self, request, obj):
        """Get inlines based on enabled apps."""
        inlines = [UserRegistrationSourceInline, UserActivityInline]

        # Add email log inline if newsletter app is enabled
        try:
            base_module = BaseCfgModule()
            if base_module.is_newsletter_enabled():
                inlines.append(UserEmailLogInline)
            if base_module.is_support_enabled():
                inlines.append(UserSupportTicketsInline)
        except Exception:
            pass

        return inlines

    # Custom display methods using decorators
    @computed_field("Avatar")
    def avatar(self, obj):
        """Enhanced avatar display with fallback initials."""
        from django_cfg.modules.django_admin.utils.displays import UserDisplay
        from django_cfg.modules.django_admin.models import UserDisplayConfig

        config = UserDisplayConfig(show_avatar=True, avatar_size=32)
        return UserDisplay.with_avatar(obj, config)

    @computed_field("Full Name")
    def full_name(self, obj):
        """Full name display."""
        full_name = obj.__class__.objects.get_full_name(obj)
        if not full_name:
            config = StatusBadgeConfig(show_icons=True, icon=Icons.PERSON)
            return StatusBadge.create(text="No name", variant="secondary", config=config)

        config = StatusBadgeConfig(show_icons=True, icon=Icons.PERSON)
        return StatusBadge.create(text=full_name, variant="primary", config=config)

    @computed_field("Status")
    def status(self, obj):
        """Enhanced status display with appropriate icons and colors."""
        if obj.is_superuser:
            status = "Superuser"
            icon = Icons.ADMIN_PANEL_SETTINGS
            variant = "danger"
        elif obj.is_staff:
            status = "Staff"
            icon = Icons.SETTINGS
            variant = "warning"
        elif obj.is_active:
            status = "Active"
            icon = Icons.CHECK_CIRCLE
            variant = "success"
        else:
            status = "Inactive"
            icon = Icons.CANCEL
            variant = "secondary"

        config = StatusBadgeConfig(
            show_icons=True,
            icon=icon,
            custom_mappings={status: variant}
        )
        return StatusBadge.create(
            text=status,
            variant=variant,
            config=config
        )

    @computed_field("Sources")
    def sources_count(self, obj):
        """Show count of registration sources for user."""
        count = obj.user_registration_sources.count()
        if count == 0:
            return None

        config = StatusBadgeConfig(show_icons=True, icon=Icons.SOURCE)
        return StatusBadge.create(
            text=f"{count} source{'s' if count != 1 else ''}",
            variant="info",
            config=config
        )

    @computed_field("Activities")
    def activity_count(self, obj):
        """Show count of user activities."""
        count = obj.activities.count()
        if count == 0:
            return None

        config = StatusBadgeConfig(show_icons=True, icon=Icons.HISTORY)
        return StatusBadge.create(
            text=f"{count} activit{'ies' if count != 1 else 'y'}",
            variant="info",
            config=config
        )

    @computed_field("Emails")
    def emails_count(self, obj):
        """Show count of emails sent to user (if newsletter app is enabled)."""
        try:
            base_module = BaseCfgModule()

            if not base_module.is_newsletter_enabled():
                return None

            from django_cfg.apps.newsletter.models import EmailLog
            count = EmailLog.objects.filter(user=obj).count()
            if count == 0:
                return None

            config = StatusBadgeConfig(show_icons=True, icon=Icons.EMAIL)
            return StatusBadge.create(
                text=f"{count} email{'s' if count != 1 else ''}",
                variant="success",
                config=config
            )
        except (ImportError, Exception):
            return None

    @computed_field("Tickets")
    def tickets_count(self, obj):
        """Show count of support tickets for user (if support app is enabled)."""
        try:
            base_module = BaseCfgModule()

            if not base_module.is_support_enabled():
                return None

            from django_cfg.apps.support.models import Ticket
            count = Ticket.objects.filter(user=obj).count()
            if count == 0:
                return None

            config = StatusBadgeConfig(show_icons=True, icon=Icons.SUPPORT_AGENT)
            return StatusBadge.create(
                text=f"{count} ticket{'s' if count != 1 else ''}",
                variant="warning",
                config=config
            )
        except (ImportError, Exception):
            return None

    # TODO: Migrate standalone actions to new ActionConfig system
    # Standalone actions (view_user_emails, view_user_tickets, export_user_data)
    # temporarily disabled during migration from django_admin_old
