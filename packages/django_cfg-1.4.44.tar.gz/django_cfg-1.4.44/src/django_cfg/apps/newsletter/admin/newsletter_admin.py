"""
Newsletter admin interfaces using Django Admin Utilities v2.0.

Enhanced newsletter management with Material Icons and optimized queries.
"""

from django import forms
from django.contrib import admin, messages
from django.db.models import Count, Q
from unfold.admin import ModelAdmin, TabularInline
from unfold.contrib.filters.admin import AutocompleteSelectFilter
from unfold.contrib.forms.widgets import WysiwygWidget

from django_cfg import ExportForm, ImportForm
from django_cfg.modules.django_admin import (
    AdminConfig,
    FieldConfig,
    FieldsetConfig,
    Icons,
    computed_field,
)
from django_cfg.modules.django_admin.base import PydanticAdmin
from django_cfg.modules.django_admin.models import StatusBadgeConfig, UserDisplayConfig, DateTimeDisplayConfig
from django_cfg.modules.django_admin.utils.badges import StatusBadge
from django_cfg.modules.django_admin.utils.displays import UserDisplay, DateTimeDisplay

from ..models import EmailLog, Newsletter, NewsletterCampaign, NewsletterSubscription
from .filters import (
    EmailClickedFilter,
    EmailOpenedFilter,
    HasUserFilter,
    UserEmailFilter,
    UserNameFilter,
)
from .resources import EmailLogResource, NewsletterResource, NewsletterSubscriptionResource


# ===== EmailLog Admin Config =====

emaillog_config = AdminConfig(
    model=EmailLog,

    # Performance optimization
    select_related=['user', 'newsletter'],

    # Import/Export
    import_export_enabled=True,
    resource_class=EmailLogResource,

    # List display
    list_display=[
        "user_display",
        "recipient_display",
        "subject_display",
        "newsletter_display",
        "status_display",
        "created_at_display",
        "sent_at_display",
        "tracking_display"
    ],

    # Display fields with UI widgets
    display_fields=[
        FieldConfig(
            name="user",
            title="User",
            ui_widget="user_simple"
        ),
        FieldConfig(
            name="recipient",
            title="Recipient",
            ui_widget="badge",
            variant="info",
            icon=Icons.EMAIL
        ),
        FieldConfig(
            name="subject",
            title="Subject",
            ui_widget="badge",
            variant="primary",
            icon=Icons.MAIL
        ),
        FieldConfig(
            name="newsletter",
            title="Newsletter",
            ui_widget="badge",
            variant="secondary",
            icon=Icons.CAMPAIGN
        ),
        FieldConfig(
            name="status",
            title="Status",
            ui_widget="status_badge"
        ),
        FieldConfig(
            name="created_at",
            title="Created",
            ui_widget="datetime_relative"
        ),
        FieldConfig(
            name="sent_at",
            title="Sent",
            ui_widget="datetime_relative"
        ),
    ],

    # Search and filters
    search_fields=[
        "recipient",
        "subject",
        "body",
        "error_message",
        "user__username",
        "user__email",
        "newsletter__subject"
    ],
    list_filter=["status", "created_at", "sent_at", "newsletter"],

    # Ordering
    ordering=["-created_at"],
)


@admin.register(EmailLog)
class EmailLogAdmin(PydanticAdmin):
    """Admin interface for EmailLog using Django Admin Utilities v2.0."""
    config = emaillog_config

    # Override list_display_links
    list_display_links = ['subject_display']

    # Override list_filter to add custom filters
    list_filter = [
        'status', 'created_at', 'sent_at', 'newsletter',
        EmailOpenedFilter, EmailClickedFilter, HasUserFilter, UserEmailFilter, UserNameFilter
    ]

    # Autocomplete
    autocomplete_fields = ['user']

    # Readonly fields
    readonly_fields = ['created_at', 'sent_at', 'newsletter']

    # Raw ID fields
    raw_id_fields = ['user', 'newsletter']

    # Fieldsets
    fieldsets = [
        FieldsetConfig(
            title="Email Information",
            fields=['recipient', 'subject', 'body']
        ),
        FieldsetConfig(
            title="User & Newsletter",
            fields=['user', 'newsletter']
        ),
        FieldsetConfig(
            title="Status & Tracking",
            fields=['status', 'is_opened', 'is_clicked']
        ),
        FieldsetConfig(
            title="Error Details",
            fields=['error_message'],
            collapsed=True
        ),
        FieldsetConfig(
            title="Timestamps",
            fields=['created_at', 'sent_at'],
            collapsed=True
        )
    ]

    # Custom display methods using @computed_field decorator
    @computed_field("User")
    def user_display(self, obj: EmailLog) -> str:
        """Display user."""
        if not obj.user:
            return "—"
        return UserDisplay.simple(obj.user)

    @computed_field("Recipient")
    def recipient_display(self, obj: EmailLog) -> str:
        """Display recipient email."""
        config = StatusBadgeConfig(show_icons=True, icon=Icons.EMAIL)
        return StatusBadge.create(
            text=obj.recipient,
            variant="info",
            config=config
        )

    @computed_field("Subject")
    def subject_display(self, obj: EmailLog) -> str:
        """Display email subject."""
        if not obj.subject:
            return "—"

        subject = obj.subject
        if len(subject) > 50:
            subject = subject[:47] + "..."

        config = StatusBadgeConfig(show_icons=True, icon=Icons.MAIL)
        return StatusBadge.create(
            text=subject,
            variant="primary",
            config=config
        )

    @computed_field("Newsletter")
    def newsletter_display(self, obj: EmailLog) -> str:
        """Display newsletter link."""
        if not obj.newsletter:
            return "—"

        config = StatusBadgeConfig(show_icons=True, icon=Icons.CAMPAIGN)
        return StatusBadge.create(
            text=obj.newsletter.title,
            variant="secondary",
            config=config
        )

    @computed_field("Status")
    def status_display(self, obj: EmailLog) -> str:
        """Display email status."""
        # Determine icon based on status
        icon_map = {
            'pending': Icons.SCHEDULE,
            'sent': Icons.CHECK_CIRCLE,
            'failed': Icons.ERROR,
            'bounced': Icons.BOUNCE_EMAIL
        }

        # Determine variant based on status
        variant_map = {
            'pending': 'warning',
            'sent': 'success',
            'failed': 'danger',
            'bounced': 'secondary'
        }

        icon = icon_map.get(obj.status, Icons.SCHEDULE)
        variant = variant_map.get(obj.status, 'warning')

        config = StatusBadgeConfig(show_icons=True, icon=icon)
        return StatusBadge.create(
            text=obj.get_status_display(),
            variant=variant,
            config=config
        )

    @computed_field("Created")
    def created_at_display(self, obj: EmailLog) -> str:
        """Created time with relative display."""
        config = DateTimeDisplayConfig(show_relative=True)
        return DateTimeDisplay.relative(obj.created_at, config)

    @computed_field("Sent")
    def sent_at_display(self, obj: EmailLog) -> str:
        """Sent time with relative display."""
        if not obj.sent_at:
            return "Not sent"
        config = DateTimeDisplayConfig(show_relative=True)
        return DateTimeDisplay.relative(obj.sent_at, config)

    @computed_field("Tracking")
    def tracking_display(self, obj: EmailLog) -> str:
        """Display tracking status with badges."""
        badges = []

        if obj.is_opened:
            config = StatusBadgeConfig(show_icons=True, icon=Icons.VISIBILITY)
            badges.append(StatusBadge.create(text="Opened", variant="success", config=config))
        else:
            config = StatusBadgeConfig(show_icons=True, icon=Icons.VISIBILITY_OFF)
            badges.append(StatusBadge.create(text="Not Opened", variant="secondary", config=config))

        if obj.is_clicked:
            config = StatusBadgeConfig(show_icons=True, icon=Icons.MOUSE)
            badges.append(StatusBadge.create(text="Clicked", variant="info", config=config))
        else:
            config = StatusBadgeConfig(show_icons=True, icon=Icons.TOUCH_APP)
            badges.append(StatusBadge.create(text="Not Clicked", variant="secondary", config=config))

        return " | ".join(badges)


# ===== Newsletter Admin Config =====

newsletter_config = AdminConfig(
    model=Newsletter,

    # Import/Export
    import_export_enabled=True,
    resource_class=NewsletterResource,

    # List display
    list_display=[
        "title_display",
        "description_display",
        "active_display",
        "auto_subscribe_display",
        "subscribers_count_display",
        "created_at_display"
    ],

    # Display fields with UI widgets
    display_fields=[
        FieldConfig(
            name="title",
            title="Title",
            ui_widget="badge",
            variant="primary",
            icon=Icons.CAMPAIGN
        ),
        FieldConfig(
            name="description",
            title="Description",
            ui_widget="text"
        ),
        FieldConfig(
            name="is_active",
            title="Active",
            ui_widget="status_badge"
        ),
        FieldConfig(
            name="auto_subscribe",
            title="Auto Subscribe",
            ui_widget="badge",
            variant="info",
            icon=Icons.AUTO_AWESOME
        ),
        FieldConfig(
            name="subscribers_count",
            title="Subscribers",
            ui_widget="text"
        ),
        FieldConfig(
            name="created_at",
            title="Created",
            ui_widget="datetime_relative"
        ),
    ],

    # Search and filters
    search_fields=["title", "description"],
    list_filter=["is_active", "auto_subscribe", "created_at"],

    # Ordering
    ordering=["-created_at"],
)


@admin.register(Newsletter)
class NewsletterAdmin(PydanticAdmin):
    """Admin interface for Newsletter using Django Admin Utilities v2.0."""
    config = newsletter_config

    # Override list_display_links
    list_display_links = ['title_display']

    # Required for autocomplete (used by NewsletterSubscriptionAdmin and NewsletterCampaignAdmin)
    search_fields = ['title', 'description']

    # Readonly fields
    readonly_fields = ['subscribers_count', 'created_at', 'updated_at']

    # Fieldsets
    fieldsets = [
        FieldsetConfig(
            title="Newsletter Information",
            fields=['title', 'description']
        ),
        FieldsetConfig(
            title="Settings",
            fields=['is_active', 'auto_subscribe']
        ),
        FieldsetConfig(
            title="Statistics",
            fields=['subscribers_count'],
            collapsed=True
        ),
        FieldsetConfig(
            title="Timestamps",
            fields=['created_at', 'updated_at'],
            collapsed=True
        )
    ]

    # Actions
    actions = ['activate_newsletters', 'deactivate_newsletters', 'enable_auto_subscribe']

    # Custom display methods using @computed_field decorator
    @computed_field("Title")
    def title_display(self, obj: Newsletter) -> str:
        """Display newsletter title."""
        config = StatusBadgeConfig(show_icons=True, icon=Icons.CAMPAIGN)
        return StatusBadge.create(
            text=obj.title,
            variant="primary",
            config=config
        )

    @computed_field("Description")
    def description_display(self, obj: Newsletter) -> str:
        """Display newsletter description."""
        if not obj.description:
            return "—"

        description = obj.description
        if len(description) > 100:
            description = description[:97] + "..."

        return description

    @computed_field("Active")
    def active_display(self, obj: Newsletter) -> str:
        """Display active status."""
        if obj.is_active:
            config = StatusBadgeConfig(show_icons=True, icon=Icons.CHECK_CIRCLE)
            return StatusBadge.create(text="Active", variant="success", config=config)
        else:
            config = StatusBadgeConfig(show_icons=True, icon=Icons.CANCEL)
            return StatusBadge.create(text="Inactive", variant="secondary", config=config)

    @computed_field("Auto Subscribe")
    def auto_subscribe_display(self, obj: Newsletter) -> str:
        """Display auto subscribe status."""
        if obj.auto_subscribe:
            config = StatusBadgeConfig(show_icons=True, icon=Icons.AUTO_AWESOME)
            return StatusBadge.create(text="Auto", variant="info", config=config)
        else:
            return "Manual"

    @computed_field("Subscribers")
    def subscribers_count_display(self, obj: Newsletter) -> str:
        """Display subscribers count."""
        count = obj.subscribers_count or 0
        if count == 0:
            return "No subscribers"
        elif count == 1:
            return "1 subscriber"
        else:
            return f"{count} subscribers"

    @computed_field("Created")
    def created_at_display(self, obj: Newsletter) -> str:
        """Created time with relative display."""
        config = DateTimeDisplayConfig(show_relative=True)
        return DateTimeDisplay.relative(obj.created_at, config)

    # Old-style actions (no @action decorator)
    def activate_newsletters(self, request, queryset):
        """Activate selected newsletters."""
        count = queryset.update(is_active=True)
        messages.success(request, f"Successfully activated {count} newsletters.")
    activate_newsletters.short_description = "Activate newsletters"

    def deactivate_newsletters(self, request, queryset):
        """Deactivate selected newsletters."""
        count = queryset.update(is_active=False)
        messages.warning(request, f"Successfully deactivated {count} newsletters.")
    deactivate_newsletters.short_description = "Deactivate newsletters"

    def enable_auto_subscribe(self, request, queryset):
        """Enable auto subscribe for selected newsletters."""
        count = queryset.update(auto_subscribe=True)
        messages.info(request, f"Enabled auto subscribe for {count} newsletters.")
    enable_auto_subscribe.short_description = "Enable auto subscribe"


# ===== NewsletterSubscription Inline (unchanged) =====

class NewsletterSubscriptionInline(TabularInline):
    """Inline for newsletter subscriptions."""

    model = NewsletterSubscription
    fields = ['email', 'user', 'is_active', 'subscribed_at']
    readonly_fields = ['subscribed_at']
    extra = 0


# ===== NewsletterSubscription Admin Config =====

newslettersubscription_config = AdminConfig(
    model=NewsletterSubscription,

    # Performance optimization
    select_related=['user', 'newsletter'],

    # Import/Export
    import_export_enabled=True,
    resource_class=NewsletterSubscriptionResource,

    # List display
    list_display=[
        "email_display",
        "newsletter_display",
        "user_display",
        "active_display",
        "subscribed_at_display",
        "unsubscribed_at_display"
    ],

    # Display fields with UI widgets
    display_fields=[
        FieldConfig(
            name="email",
            title="Email",
            ui_widget="badge",
            variant="info",
            icon=Icons.EMAIL
        ),
        FieldConfig(
            name="newsletter",
            title="Newsletter",
            ui_widget="badge",
            variant="primary",
            icon=Icons.CAMPAIGN
        ),
        FieldConfig(
            name="user",
            title="User",
            ui_widget="user_simple"
        ),
        FieldConfig(
            name="is_active",
            title="Active",
            ui_widget="status_badge"
        ),
        FieldConfig(
            name="subscribed_at",
            title="Subscribed",
            ui_widget="datetime_relative"
        ),
        FieldConfig(
            name="unsubscribed_at",
            title="Unsubscribed",
            ui_widget="datetime_relative"
        ),
    ],

    # Search and filters
    search_fields=["email", "user__email", "newsletter__title"],
    list_filter=["is_active", "newsletter", "subscribed_at"],

    # Ordering
    ordering=["-subscribed_at"],
)


@admin.register(NewsletterSubscription)
class NewsletterSubscriptionAdmin(PydanticAdmin):
    """Admin interface for NewsletterSubscription using Django Admin Utilities v2.0."""
    config = newslettersubscription_config

    # Override list_display_links
    list_display_links = ['email_display']

    # Readonly fields
    readonly_fields = ['subscribed_at', 'unsubscribed_at']

    # Autocomplete
    autocomplete_fields = ['user', 'newsletter']

    # Fieldsets
    fieldsets = [
        FieldsetConfig(
            title="Subscription Information",
            fields=['email', 'newsletter', 'user']
        ),
        FieldsetConfig(
            title="Status",
            fields=['is_active']
        ),
        FieldsetConfig(
            title="Timestamps",
            fields=['subscribed_at', 'unsubscribed_at']
        )
    ]

    # Actions
    actions = ['activate_subscriptions', 'deactivate_subscriptions']

    # Custom display methods using @computed_field decorator
    @computed_field("Email")
    def email_display(self, obj: NewsletterSubscription) -> str:
        """Display subscription email."""
        config = StatusBadgeConfig(show_icons=True, icon=Icons.EMAIL)
        return StatusBadge.create(
            text=obj.email,
            variant="info",
            config=config
        )

    @computed_field("Newsletter")
    def newsletter_display(self, obj: NewsletterSubscription) -> str:
        """Display newsletter."""
        if not obj.newsletter:
            return "—"

        config = StatusBadgeConfig(show_icons=True, icon=Icons.CAMPAIGN)
        return StatusBadge.create(
            text=obj.newsletter.title,
            variant="primary",
            config=config
        )

    @computed_field("User")
    def user_display(self, obj: NewsletterSubscription) -> str:
        """Display user."""
        if not obj.user:
            return "—"
        return UserDisplay.simple(obj.user)

    @computed_field("Active")
    def active_display(self, obj: NewsletterSubscription) -> str:
        """Display active status."""
        if obj.is_active:
            config = StatusBadgeConfig(show_icons=True, icon=Icons.CHECK_CIRCLE)
            return StatusBadge.create(text="Active", variant="success", config=config)
        else:
            config = StatusBadgeConfig(show_icons=True, icon=Icons.CANCEL)
            return StatusBadge.create(text="Inactive", variant="secondary", config=config)

    @computed_field("Subscribed")
    def subscribed_at_display(self, obj: NewsletterSubscription) -> str:
        """Subscribed time with relative display."""
        config = DateTimeDisplayConfig(show_relative=True)
        return DateTimeDisplay.relative(obj.subscribed_at, config)

    @computed_field("Unsubscribed")
    def unsubscribed_at_display(self, obj: NewsletterSubscription) -> str:
        """Unsubscribed time with relative display."""
        if not obj.unsubscribed_at:
            return "—"
        config = DateTimeDisplayConfig(show_relative=True)
        return DateTimeDisplay.relative(obj.unsubscribed_at, config)

    # Old-style actions (no @action decorator)
    def activate_subscriptions(self, request, queryset):
        """Activate selected subscriptions."""
        count = queryset.update(is_active=True)
        messages.success(request, f"Successfully activated {count} subscriptions.")
    activate_subscriptions.short_description = "Activate subscriptions"

    def deactivate_subscriptions(self, request, queryset):
        """Deactivate selected subscriptions."""
        count = queryset.update(is_active=False)
        messages.warning(request, f"Successfully deactivated {count} subscriptions.")
    deactivate_subscriptions.short_description = "Deactivate subscriptions"


# ===== NewsletterCampaign Form (unchanged) =====

class NewsletterCampaignAdminForm(forms.ModelForm):
    main_html_content = forms.CharField(widget=WysiwygWidget(), required=False)

    class Meta:
        model = NewsletterCampaign
        fields = '__all__'


# ===== NewsletterCampaign Admin Config =====

newslettercampaign_config = AdminConfig(
    model=NewsletterCampaign,

    # Performance optimization
    select_related=['newsletter'],

    # List display
    list_display=[
        "subject_display",
        "newsletter_display",
        "status_display",
        "sent_at_display",
        "recipient_count_display"
    ],

    # Display fields with UI widgets
    display_fields=[
        FieldConfig(
            name="subject",
            title="Subject",
            ui_widget="badge",
            variant="primary",
            icon=Icons.MAIL
        ),
        FieldConfig(
            name="newsletter",
            title="Newsletter",
            ui_widget="badge",
            variant="secondary",
            icon=Icons.CAMPAIGN
        ),
        FieldConfig(
            name="status",
            title="Status",
            ui_widget="status_badge"
        ),
        FieldConfig(
            name="sent_at",
            title="Sent",
            ui_widget="datetime_relative"
        ),
        FieldConfig(
            name="recipient_count",
            title="Recipients",
            ui_widget="text"
        ),
    ],

    # Search and filters
    search_fields=["subject", "newsletter__title", "main_html_content"],
    list_filter=["status", "newsletter", "sent_at"],

    # Ordering
    ordering=["-created_at"],
)


@admin.register(NewsletterCampaign)
class NewsletterCampaignAdmin(PydanticAdmin):
    """Admin interface for NewsletterCampaign using Django Admin Utilities v2.0."""
    config = newslettercampaign_config

    # Custom form
    form = NewsletterCampaignAdminForm

    # Override list_display_links
    list_display_links = ['subject_display']

    # Readonly fields
    readonly_fields = ['sent_at', 'recipient_count', 'created_at']

    # Autocomplete
    autocomplete_fields = ['newsletter']

    # Fieldsets
    fieldsets = [
        FieldsetConfig(
            title="Campaign Information",
            fields=['subject', 'newsletter']
        ),
        FieldsetConfig(
            title="Content",
            fields=['main_html_content']
        ),
        FieldsetConfig(
            title="Status & Stats",
            fields=['status', 'recipient_count']
        ),
        FieldsetConfig(
            title="Timestamps",
            fields=['sent_at', 'created_at'],
            collapsed=True
        )
    ]

    # Actions
    actions = ['send_campaigns', 'schedule_campaigns', 'cancel_campaigns']

    # Custom display methods using @computed_field decorator
    @computed_field("Subject")
    def subject_display(self, obj: NewsletterCampaign) -> str:
        """Display campaign subject."""
        config = StatusBadgeConfig(show_icons=True, icon=Icons.MAIL)
        return StatusBadge.create(
            text=obj.subject,
            variant="primary",
            config=config
        )

    @computed_field("Newsletter")
    def newsletter_display(self, obj: NewsletterCampaign) -> str:
        """Display newsletter."""
        if not obj.newsletter:
            return "—"

        config = StatusBadgeConfig(show_icons=True, icon=Icons.CAMPAIGN)
        return StatusBadge.create(
            text=obj.newsletter.title,
            variant="secondary",
            config=config
        )

    @computed_field("Status")
    def status_display(self, obj: NewsletterCampaign) -> str:
        """Display campaign status."""
        # Determine icon based on status
        icon_map = {
            'draft': Icons.EDIT,
            'scheduled': Icons.SCHEDULE,
            'sending': Icons.SEND,
            'sent': Icons.CHECK_CIRCLE,
            'failed': Icons.ERROR,
            'cancelled': Icons.CANCEL
        }

        # Determine variant based on status
        variant_map = {
            'draft': 'secondary',
            'scheduled': 'warning',
            'sending': 'info',
            'sent': 'success',
            'failed': 'danger',
            'cancelled': 'secondary'
        }

        icon = icon_map.get(obj.status, Icons.EDIT)
        variant = variant_map.get(obj.status, 'secondary')

        config = StatusBadgeConfig(show_icons=True, icon=icon)
        return StatusBadge.create(
            text=obj.get_status_display(),
            variant=variant,
            config=config
        )

    @computed_field("Sent")
    def sent_at_display(self, obj: NewsletterCampaign) -> str:
        """Sent time with relative display."""
        if not obj.sent_at:
            return "Not sent"
        config = DateTimeDisplayConfig(show_relative=True)
        return DateTimeDisplay.relative(obj.sent_at, config)

    @computed_field("Recipients")
    def recipient_count_display(self, obj: NewsletterCampaign) -> str:
        """Display recipients count."""
        count = obj.recipient_count or 0
        if count == 0:
            return "No recipients"
        elif count == 1:
            return "1 recipient"
        else:
            return f"{count} recipients"

    # Old-style actions (no @action decorator)
    def send_campaigns(self, request, queryset):
        """Send selected campaigns."""
        sendable_count = queryset.filter(status__in=['draft', 'scheduled']).count()
        if sendable_count == 0:
            messages.error(request, "No sendable campaigns selected.")
            return

        queryset.filter(status__in=['draft', 'scheduled']).update(status='sending')
        messages.success(request, f"Started sending {sendable_count} campaigns.")
    send_campaigns.short_description = "Send campaigns"

    def schedule_campaigns(self, request, queryset):
        """Schedule selected campaigns."""
        schedulable_count = queryset.filter(status='draft').count()
        if schedulable_count == 0:
            messages.error(request, "No draft campaigns selected.")
            return

        queryset.filter(status='draft').update(status='scheduled')
        messages.warning(request, f"Scheduled {schedulable_count} campaigns.")
    schedule_campaigns.short_description = "Schedule campaigns"

    def cancel_campaigns(self, request, queryset):
        """Cancel selected campaigns."""
        cancelable_count = queryset.filter(status__in=['draft', 'scheduled']).count()
        if cancelable_count == 0:
            messages.error(request, "No cancelable campaigns selected.")
            return

        queryset.filter(status__in=['draft', 'scheduled']).update(status='cancelled')
        messages.error(request, f"Cancelled {cancelable_count} campaigns.")
    cancel_campaigns.short_description = "Cancel campaigns"

    def changelist_view(self, request, extra_context=None):
        """Add campaign statistics to changelist."""
        extra_context = extra_context or {}

        queryset = self.get_queryset(request)
        stats = queryset.aggregate(
            total_campaigns=Count('id'),
            draft_campaigns=Count('id', filter=Q(status='draft')),
            scheduled_campaigns=Count('id', filter=Q(status='scheduled')),
            sent_campaigns=Count('id', filter=Q(status='sent')),
            failed_campaigns=Count('id', filter=Q(status='failed'))
        )

        extra_context['campaign_stats'] = {
            'total_campaigns': stats['total_campaigns'] or 0,
            'draft_campaigns': stats['draft_campaigns'] or 0,
            'scheduled_campaigns': stats['scheduled_campaigns'] or 0,
            'sent_campaigns': stats['sent_campaigns'] or 0,
            'failed_campaigns': stats['failed_campaigns'] or 0
        }

        return super().changelist_view(request, extra_context)
