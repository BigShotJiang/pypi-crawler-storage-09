"""
Examples for using the External Data system in django_cfg.apps.knowbase.
"""
