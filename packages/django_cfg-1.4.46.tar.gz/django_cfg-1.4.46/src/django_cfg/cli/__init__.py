"""
Django CFG CLI Module

Command-line interface for django-cfg operations including
project scaffolding, configuration management, and utilities.
"""
