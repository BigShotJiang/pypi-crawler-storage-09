"""
Django CFG API Module

Built-in API endpoints for django_cfg functionality.
"""
