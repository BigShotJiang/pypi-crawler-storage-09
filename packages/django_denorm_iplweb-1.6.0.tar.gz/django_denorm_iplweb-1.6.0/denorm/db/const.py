# Please set this ONCE when starting your project. If updated, one needs to
# rebuild the whole django_denorm app, renaming this after the tables have been
# initialized is NOT supported...

DENORM_QUEUE_NAME = "django_denorm_process"
