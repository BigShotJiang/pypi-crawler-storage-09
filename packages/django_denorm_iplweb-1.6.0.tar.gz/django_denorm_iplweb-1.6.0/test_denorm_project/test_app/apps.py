from django.apps import AppConfig


class TestApp(AppConfig):
    name = "test_app"
