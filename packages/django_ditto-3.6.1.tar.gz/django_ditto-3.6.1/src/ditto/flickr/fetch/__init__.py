class FetchError(Exception):
    pass
