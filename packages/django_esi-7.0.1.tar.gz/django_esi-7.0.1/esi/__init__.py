"""Django app for accessing the EVE Swagger Interface (ESI)."""

__version__ = '7.0.1'
__title__ = 'Django-ESI'
__url__ = 'https://gitlab.com/allianceauth/django-esi'
