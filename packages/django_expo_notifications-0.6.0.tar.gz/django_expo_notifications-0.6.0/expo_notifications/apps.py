from django.apps import AppConfig


class ExpoNotificationsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "expo_notifications"
    verbose_name = "Expo Notifications"
