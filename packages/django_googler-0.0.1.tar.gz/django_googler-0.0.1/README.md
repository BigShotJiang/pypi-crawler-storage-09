# Django Googler
Django Googler is a simple way to integrate Google Auth Platform with your Django project

## Installation

```bash
pip install django-googler
```

Depends on:

- [Python 3.12+](https://www.python.org/)
- [Django 5.2+](https://docs.djangoproject.com/)
