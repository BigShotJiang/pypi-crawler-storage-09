# Tests for django-googler
