# -*- coding: utf-8 -*-
import os
from io import open
from setuptools import setup
from setuptools import find_packages

here = os.path.abspath(os.path.dirname(__file__))

with open(os.path.join(here, "README.md"), "r", encoding="utf-8") as fobj:
    long_description = fobj.read()

with open(os.path.join(here, "requirements.txt"), "r", encoding="utf-8") as fobj:
    requires = requires = [x.strip() for x in fobj.readlines() if x.strip()]

setup(
    name="django-horizontal-list-filter",
    version="0.2.10",
    description="在Django管理站点中，将列表筛选器移动到变更列表上方，并且采用横向布局样式。",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="rRR0VrFP",
    maintainer="rRR0VrFP",
    license="MIT",
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3 :: Only",
    ],
    keywords=["django admin extentions", "django horizontal list filter"],
    install_requires=requires,
    packages=find_packages(
        ".",
        exclude=[
            "django_horizontal_list_filter_example",
            "django_horizontal_list_filter_example.migrations",
            "django_horizontal_list_filter_demo",
        ],
    ),
    zip_safe=False,
    include_package_data=True,
)
