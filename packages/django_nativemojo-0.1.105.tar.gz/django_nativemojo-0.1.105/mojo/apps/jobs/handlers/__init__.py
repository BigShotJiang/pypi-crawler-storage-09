"""
Job handlers for Django-MOJO Jobs System.

Specialized job functions for common tasks like webhooks, emails, etc.
"""
