# Release Notes

Follow and subscribe for new releases on GitHub:

<https://github.com/vitalik/django-ninja/releases>

