from ninja.openapi.schema import get_schema

__all__ = ["get_schema"]
