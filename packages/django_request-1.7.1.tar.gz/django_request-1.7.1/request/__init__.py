__version__ = "1.7.1"
__copyright__ = "Copyright (c) 2009-2025, Kyle Fuller, Mariusz Felisiak"
__author__ = [
    "Kyle Fuller <kyle@fuller.li>",
    "Jannis Leidel (jezdez)",
    "krisje8 <krisje8@gmail.com>",
    "Mariusz Felisiak <felisiak.mariusz@gmail.com>",
]
