from django.apps import AppConfig


class ResonantUtilsConfig(AppConfig):
    name = "resonant_utils"
