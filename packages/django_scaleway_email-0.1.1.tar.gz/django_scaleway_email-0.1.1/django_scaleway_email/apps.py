from django.apps import AppConfig


class ScalewayEmailConfig(AppConfig):
    name = "scaleway_email"
