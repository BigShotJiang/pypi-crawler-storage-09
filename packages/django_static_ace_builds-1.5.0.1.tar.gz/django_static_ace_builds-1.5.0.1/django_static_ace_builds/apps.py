from django.apps import AppConfig


class DjangoStaticAceBuildsConfig(AppConfig):
    name = 'django_static_ace_builds'
