"""django-templated-email-md."""
