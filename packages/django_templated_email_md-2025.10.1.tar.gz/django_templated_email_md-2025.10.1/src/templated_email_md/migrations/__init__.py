"""Initialize migrations."""
