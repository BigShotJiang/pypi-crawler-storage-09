"""
Django Discussions - Standalone threaded discussion app with HTMX support.
"""

__version__ = "0.1.0"

default_app_config = "django_discussions.apps.DiscussionsConfig"
