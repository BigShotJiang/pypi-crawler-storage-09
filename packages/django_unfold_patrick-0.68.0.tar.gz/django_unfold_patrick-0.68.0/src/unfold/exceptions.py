class UnfoldException(Exception):
    pass
