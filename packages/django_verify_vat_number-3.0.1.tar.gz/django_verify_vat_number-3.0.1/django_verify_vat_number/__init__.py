"""Module Django vertify VAT number."""
