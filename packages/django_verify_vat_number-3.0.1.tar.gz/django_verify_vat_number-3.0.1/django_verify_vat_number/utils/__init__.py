"""Utils for cache, response, country."""
