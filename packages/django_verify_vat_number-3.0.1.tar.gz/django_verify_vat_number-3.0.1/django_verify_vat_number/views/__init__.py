"""Views Django vertify VAT number."""
