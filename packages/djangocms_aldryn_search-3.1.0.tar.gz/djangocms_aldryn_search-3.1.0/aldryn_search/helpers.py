from django.contrib import admin
from django.contrib.auth.models import AnonymousUser
from django.template import Engine, RequestContext
from django.test import RequestFactory
from django.utils.encoding import force_str
from django.utils.text import smart_split

from cms.toolbar.toolbar import CMSToolbar

from .conf import settings
from .utils import _get_alias_from_language_func, _get_language_from_alias_func, get_field_value, strip_tags


EXCLUDED_PLUGINS = getattr(settings, 'ALDRYN_SEARCH_EXCLUDED_PLUGINS', [])


get_alias_from_language = _get_alias_from_language_func()
get_language_from_alias = _get_language_from_alias_func()


def _render_plugin(plugin, context, renderer=None):
    if renderer:
        content = renderer.render_plugin(
            instance=plugin,
            context=context,
            editable=False,
        )
    else:
        content = plugin.render_plugin(context)
    return content


def get_cleaned_bits(data):
    decoded = force_str(data)
    stripped = strip_tags(decoded)
    return smart_split(stripped)


def get_plugin_index_data(base_plugin, request):
    text_bits = []

    instance, plugin_type = base_plugin.get_plugin_instance()

    if instance is None or instance.plugin_type in EXCLUDED_PLUGINS:
        # this is an empty plugin or excluded from search
        return text_bits

    search_fields = getattr(instance, 'search_fields', [])
    if hasattr(instance, 'search_fulltext'):
        # check if the plugin instance has search enabled
        search_contents = instance.search_fulltext
    elif hasattr(base_plugin, 'search_fulltext'):
        # now check in the base plugin instance (CMSPlugin)
        search_contents = base_plugin.search_fulltext
    elif hasattr(plugin_type, 'search_fulltext'):
        # last check in the plugin class (CMSPluginBase)
        search_contents = plugin_type.search_fulltext
    else:
        # disabled if there's search fields defined,
        # otherwise it's enabled.
        search_contents = not bool(search_fields)

    if search_contents:
        context = RequestContext(request)
        updates = {}
        engine = Engine.get_default()

        for processor in engine.template_context_processors:
            updates.update(processor(context.request))
        context.dicts[context._processors_index] = updates

        try:
            # django-cms>=3.5
            renderer = request.toolbar.content_renderer
        except AttributeError:
            # django-cms>=3.4
            renderer = context.get('cms_content_renderer')

        # Fix AccordionItemRenderMixin.render in djangocms_frontend/contrib/accordion/frameworks/bootstrap5.py.
        # Fix TabItemRenderMixin.render in djangocms_frontend/contrib/tab/frameworks/bootstrap5.py.
        if instance.plugin_type in ('AccordionItemPlugin', 'TabItemPlugin'):
            context['parent'] = instance.parent.get_plugin_instance(admin=admin)[0]
        if instance.plugin_type == 'TabItemPlugin':
            context['parentloop'] = {'counter': 1}

        plugin_contents = _render_plugin(instance, context, renderer)

        if plugin_contents:
            text_bits = get_cleaned_bits(plugin_contents)
    else:
        values = (get_field_value(instance, field) for field in search_fields)

        for value in values:
            cleaned_bits = get_cleaned_bits(value or '')
            text_bits.extend(cleaned_bits)
    return text_bits


def get_request(language=None):
    """
    Returns a Request instance populated with cms specific attributes.
    """
    request_factory = RequestFactory(HTTP_HOST=settings.ALLOWED_HOSTS[0])
    request = request_factory.get("/")
    request.session = {}
    request.LANGUAGE_CODE = language or settings.LANGUAGE_CODE
    # Needed for plugin rendering.
    request.current_page = None
    request.user = AnonymousUser()
    request.toolbar = CMSToolbar(request)
    return request
