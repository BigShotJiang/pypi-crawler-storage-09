TRASH_BIN_PAGE_TITLES = {
    "en": "Trash bin for deleted pages",
    "de": "Papierkorb für gelöschte Seiten",  # Germany
    "fr": "Corbeille pour les pages supprimées",  # France
    "it": "Cestino per le pagine eliminate",  # Italy
    "nl": "Papirkurv til slettede sider",  # Dutch
    "es": "Papelera para páginas eliminadas",  # Spanish
    "cs": "Koš na smazané stránky",  # Czech
}
