"""
Django management commands for djaploy
"""