from . import collection, implementations as ic_impl, cosem_interface_class as ic
from .parameter import Parameter