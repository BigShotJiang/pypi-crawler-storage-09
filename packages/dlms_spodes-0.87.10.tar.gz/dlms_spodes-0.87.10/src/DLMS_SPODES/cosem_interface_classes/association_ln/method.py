from ...types import cdt


class ReplyToHLSAuthentication(cdt.OctetString):
    """"""  # todo: make validate by contents
