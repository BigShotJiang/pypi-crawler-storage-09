from .spectra1d import Spectra1D
