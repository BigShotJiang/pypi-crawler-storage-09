import do_relative

print("in test3")
do_relative.relative_import("from .. import test4")
