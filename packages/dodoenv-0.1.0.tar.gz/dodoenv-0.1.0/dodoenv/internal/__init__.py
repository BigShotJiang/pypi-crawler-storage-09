# Internal module for dodoenv
