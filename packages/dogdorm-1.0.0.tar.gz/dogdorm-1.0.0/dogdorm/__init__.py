
import sys

if not '-m' in sys.argv:
    from .main import *