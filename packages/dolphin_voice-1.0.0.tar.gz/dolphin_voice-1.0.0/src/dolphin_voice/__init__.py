
# from . import speech_rec
# from . import speech_syn

__version__ = "1.0.0"