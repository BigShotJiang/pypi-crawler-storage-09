"""Internal implementation details - not part of public API."""
