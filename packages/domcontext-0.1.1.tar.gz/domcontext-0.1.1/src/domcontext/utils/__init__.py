"""Utilities for DOM context extraction."""

from .playwright import capture_snapshot

__all__ = ['capture_snapshot']
