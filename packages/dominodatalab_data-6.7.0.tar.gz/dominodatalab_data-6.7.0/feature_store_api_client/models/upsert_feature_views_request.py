from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.feature_view_request import FeatureViewRequest


T = TypeVar("T", bound="UpsertFeatureViewsRequest")


@_attrs_define
class UpsertFeatureViewsRequest:
    """
    Attributes:
        feature_views (List['FeatureViewRequest']):
        git_commit_hash (str):
        project_id (str):
    """

    feature_views: List["FeatureViewRequest"]
    git_commit_hash: str
    project_id: str
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        feature_views = []
        for feature_views_item_data in self.feature_views:
            feature_views_item = feature_views_item_data.to_dict()
            feature_views.append(feature_views_item)

        git_commit_hash = self.git_commit_hash

        project_id = self.project_id

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "featureViews": feature_views,
                "gitCommitHash": git_commit_hash,
                "projectId": project_id,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.feature_view_request import FeatureViewRequest

        d = src_dict.copy()
        feature_views = []
        _feature_views = d.pop("featureViews")
        for feature_views_item_data in _feature_views:
            feature_views_item = FeatureViewRequest.from_dict(feature_views_item_data)

            feature_views.append(feature_views_item)

        git_commit_hash = d.pop("gitCommitHash")

        project_id = d.pop("projectId")

        upsert_feature_views_request = cls(
            feature_views=feature_views,
            git_commit_hash=git_commit_hash,
            project_id=project_id,
        )

        upsert_feature_views_request.additional_properties = d
        return upsert_feature_views_request

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
