# Copyright (c) 2025-Present API SERVICE S.A.C. (<https://www.apiservicesac.com/>)

"""
Backup module for dooservice-cli.

This module provides backup and restore functionality for Odoo instances.
"""
