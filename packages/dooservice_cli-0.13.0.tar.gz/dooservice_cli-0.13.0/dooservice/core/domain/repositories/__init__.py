# Copyright (c) 2025-Present API SERVICE S.A.C. (<https://www.apiservicesac.com/>)

from .configuration_repository import ConfigurationRepository

__all__ = ["ConfigurationRepository"]
