#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys

if sys.version_info < (3, 12):
    raise SystemError("dpn_pyutils requires Python version >= 3.12")
