"""dragonfly-comparison properties."""
