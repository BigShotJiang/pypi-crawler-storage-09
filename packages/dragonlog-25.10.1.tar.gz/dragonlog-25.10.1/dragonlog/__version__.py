__version__ = 'v25.10.1'
__version_str__ = 'v25.10.1'
__branch__ = 'master'
__unclean__ = False
