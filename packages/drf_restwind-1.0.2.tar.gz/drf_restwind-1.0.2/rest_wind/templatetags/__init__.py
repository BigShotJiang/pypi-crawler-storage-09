"""DRF RESTWind template tags"""
