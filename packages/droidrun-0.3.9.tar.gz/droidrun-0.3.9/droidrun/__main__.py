"""
DroidRun main entry point
"""
from droidrun.cli.main import cli

if __name__ == '__main__':
    cli()