"""File outputs for different drone types."""
