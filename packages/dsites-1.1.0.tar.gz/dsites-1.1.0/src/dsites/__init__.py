__version__ = "1.1.0"
from .predictor import run  # expose run for programmatic use
