from setuptools import setup

setup(
    name="dsnd_probability_necs_1",
    version="1.2",
    description="Gaussian and Binomial distributions",
    packages=["dsnd_probability_necs_1"],
    author="Necs Mobolaji",
    author_email="goognecs@gmail.com",
    zip_safe=False,
)
