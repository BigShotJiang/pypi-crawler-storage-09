from numpy import ndarray, str_
from numpy.typing import NDArray