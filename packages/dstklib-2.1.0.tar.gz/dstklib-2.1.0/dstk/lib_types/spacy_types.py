# spaCy types
from spacy.language import Language
from spacy.tokens import Doc, Token, Span


#__all__ = ['Language', 'Doc']
