from __future__ import annotations

__version__: str = "0.31.0"

__all__ = ["__version__"]
