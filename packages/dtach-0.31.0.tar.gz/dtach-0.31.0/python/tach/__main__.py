from __future__ import annotations

from tach.start import start

if __name__ == "__main__":
    start()
