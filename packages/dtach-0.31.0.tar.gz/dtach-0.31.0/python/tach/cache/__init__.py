from __future__ import annotations

from tach.cache.access import get_latest_version, get_uid

__all__ = ["get_uid", "get_latest_version"]
