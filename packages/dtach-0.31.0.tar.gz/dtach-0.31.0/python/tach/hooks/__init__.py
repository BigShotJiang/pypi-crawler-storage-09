from __future__ import annotations

from tach.hooks.pre_commit import build_pre_commit_hook_content

__all__ = ["build_pre_commit_hook_content"]
