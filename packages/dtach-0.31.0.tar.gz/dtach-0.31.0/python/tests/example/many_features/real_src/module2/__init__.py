import module3
import module4
import module1
import module1.submodule1

from module3.submodule3.closed import something

from module3.submodule3.lowest_open import something_else
