from django.conf import settings

# tach-ignore(ok)
from .submodule2 import (
    a,
    b,
    c,
    d,
    e,
    f,
    g,
)