# 0.5.6
- Live ndscope minute trends now backfill quickly
# 0.5.5
- Updated to ligo_hires_gps_time 0.5.4