from duckdi.modules.interface import Interface
from duckdi.modules.register import register
from duckdi.modules.get import Get

__all__ = [
    "Interface",
    "register",
    "Get",
]
