"""Example scripts demonstrating DuckPlus capabilities."""

__all__ = ["pi_demo", "sales_pipeline"]
