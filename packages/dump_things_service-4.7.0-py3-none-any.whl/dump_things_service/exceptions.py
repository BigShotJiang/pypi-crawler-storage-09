class ConfigError(Exception):
    pass


class CurieResolutionError(Exception):
    pass
