from duron.codec._base import Codec as Codec
