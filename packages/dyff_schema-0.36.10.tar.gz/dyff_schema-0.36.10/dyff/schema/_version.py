__version__ = version = "0.36.10"
__version_tuple__ = version_tuple = (0, 36, 10)
