__version__ = version = "0.26.4"
__version_tuple__ = version_tuple = (0, 26, 4)
