def f():
    print("b.utils.helper")
