class DyngleError(Exception):
    pass
