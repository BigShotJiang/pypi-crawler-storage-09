from .accumulate import flow_downstream, flow_upstream
from .flow import propagate
