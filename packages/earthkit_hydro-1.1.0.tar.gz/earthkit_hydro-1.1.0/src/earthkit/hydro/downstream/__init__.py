import earthkit.hydro.downstream.array as array

from ._toplevel import max, mean, min, std, sum, var

__all__ = ["array", "max", "mean", "min", "std", "sum", "var"]
