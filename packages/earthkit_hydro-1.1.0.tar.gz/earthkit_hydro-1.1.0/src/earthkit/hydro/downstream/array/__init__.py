from ._toplevel import max, mean, min, std, sum, var

__all__ = ["max", "mean", "min", "std", "sum", "var"]
