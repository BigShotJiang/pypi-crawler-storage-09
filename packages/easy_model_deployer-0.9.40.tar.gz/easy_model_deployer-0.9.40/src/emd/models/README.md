## Models

- `Model`: The main model that contains the logic for the model.
