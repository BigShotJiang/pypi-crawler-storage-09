print("appmaker loaded successfully!")

def about():
    return "AppMaker by Jay — your custom app toolkit 🚀"
