"""Benchmarks package for easybench."""
