# string

## Syntax:
`{value} is [not] string`

## Examples:
`if Value is string stop`

## Description:
Tests if the value is a text string.

Next: [boolean](boolean.md)  
Prev: [starts](starts.md)

[Back](../../README.md)
