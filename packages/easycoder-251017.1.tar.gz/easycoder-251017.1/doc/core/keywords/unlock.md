# unlock

## Syntax:
`unlock {variable}`

## Examples:
`lock Status`

## Description:
Unlocks a locked variable to allow it to be modified. See also [lock](lock.md).

Next: [use](use.md)  
Prev: [truncate](truncate.md)

[Back](../../README.md)
