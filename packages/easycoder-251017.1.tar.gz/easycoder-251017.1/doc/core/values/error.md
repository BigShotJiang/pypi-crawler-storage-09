# error

## Syntax:
`error code code/reason {code/reason}`

## Examples:
`print error code 45`  
``print error reason `Unexpected value` ``

## Description:
Sets up an error code or reason.

Next: [files](files.md)  
Prev: [encode](encode.md)

[Back](../../README.md)
