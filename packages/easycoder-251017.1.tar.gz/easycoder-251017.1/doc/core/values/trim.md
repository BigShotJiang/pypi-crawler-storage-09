# trim

## Syntax:
`trim {text}`

## Examples:
`print trim TextValue`

## Description:
Returns the text string with all leading and trailing whitespace removed.

Next: [type](type.md)  
Prev: [today](today.md)

[Back](../../README.md)
