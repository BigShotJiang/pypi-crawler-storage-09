#!/bin/python3

import os
from easycoder import Program

os.chdir('../..')
Program('testsql.ecs').start()
