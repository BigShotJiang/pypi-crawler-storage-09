# 🎉 EasyGUI Wrap 🖥️

**EasyGUI Wrap** is a playful, lightweight Python GUI library built on top of [DearPyGui](https://github.com/hoffstadt/DearPyGui). It simplifies GUI creation while giving you full control of DearPyGui under the hood. ✨

When installed, you can simply import it as `easygui` and start using the `EasyGUI` class immediately:

```python
import easygui

app = easygui.EasyGUI("My App", (800, 600))
```

Or explicitly:

```python
from easygui import EasyGUI
app = EasyGUI("My App", (800, 600))
```

---

## 🌟 Features

* Simplified API: `add_label`, `add_button`, `add_entry`.
* Supports **foreground/background colors**, **font size**, and **tags**. 🎨
* Full **dynamic resizing**: windows can automatically match the viewport. 📐
* Control **window decorations** separately:

  * `decorated` → window title bar.
  * `viewport_decorated` → OS-level decorations.
* Callbacks can use **normal arguments** and **tag-based arguments**. 🪄
* Full raw **DearPyGui access** for custom widgets. 🎨
* Two-way compatibility: EasyGUI and manual DPG widgets can interact.
* Fun emojis in labels, buttons, and widgets! 😎
* Dynamic fullscreen support for any window. 🖥️

---

## 🚀 Installation

```bash
pip install easygui_wrap
```

Dependencies `dearpygui` and `webcolors` are installed automatically.

---

## 🏁 Quick Start

```python
import easygui

def greet(name):
    print(f"Hello, {name}! 👋")

app = easygui.EasyGUI("Demo App 🎈", (800, 600), bg_color="lightblue", decorated=False, viewport_decorated=True)

# EasyGUI widgets
app.add_label("Enter your name: 📝", fg="black")
app.add_entry(tag="name")
app.add_button("Say Hello 👋", greet, args_tags=["name"], bg="green", fg="white", font_size=14)

# Manual DPG widgets
dpg = app.dpg_module
manual_text = dpg.add_text("Manual DPG Text ✨", parent=app.main_window_tag)
manual_input = dpg.add_input_text(label="Manual input 🔑", parent=app.main_window_tag)
app.register_widget("manual_input", manual_input)

# Fullscreen a window dynamically
win = app.add_window("Fullscreen Window")
app.fullscreen(win, True)

app.show()
```

---

## 🛠️ API

### Constructor

```python
EasyGUI(title="My App", size=(800,600), bg_color="gray",
        decorated=True, viewport_decorated=True)
```

* `title`: Window title.
* `size`: Tuple `(width, height)`.
* `bg_color`: Background color.
* `decorated`: Show window title bar.
* `viewport_decorated`: Show OS-level viewport decorations.

### Widgets

#### add_label

```python
add_label(text, tag=None, fg="white", font_size=None)
```

* `text`: Label text (emojis welcome! 😎)
* `tag`: Optional unique tag.
* `fg`: Foreground color.
* `font_size`: Optional font size.

#### add_entry

```python
add_entry(label="", default_value="", tag=None, width=200)
```

* `label`: Entry label.
* `default_value`: Initial text.
* `tag`: Optional unique tag.
* `width`: Entry width.

#### add_button

```python
add_button(text, callback=None, args=None, args_tags=None, fg="white", bg="gray", font_size=None, tag=None)
```

* `text`: Button label (emojis welcome! 🎉)
* `callback`: Function to call.
* `args`: List of normal arguments.
* `args_tags`: List of tags to pull values from.
* `fg`, `bg`: Colors.
* `font_size`: Optional font size.
* `tag`: Optional unique tag.

### Fullscreen

```python
fullscreen(window_tag=None, enable=True)
```

* `window_tag`: Target window tag, defaults to main window.
* `enable`: True to enable, False to disable.
* Automatically resizes window to viewport dynamically.

### Get/Set values

```python
value = app.get(tag)
app.set(tag, value)
```

### Register manual DPG widget

```python
app.register_widget(tag, dpg_id)
```

### Access raw DearPyGui

```python
dpg = app.dpg_module
main_window = app.main_window_tag
```

---

## 🎮 Example: Full Interoperability

```python
import easygui

def greet(name):
    print(f"Hello, {name}! 😎")

app = easygui.EasyGUI("Full Demo 🚀", (800,600), decorated=False, viewport_decorated=True)
app.add_label("Enter your name: 📝", fg="black")
app.add_entry(tag="name")
app.add_button("Say Hello 👋", greet, args_tags=["name"], bg="green", fg="white", font_size=14)

# Manual DPG widgets
manual_text = app.dpg_module.add_text("Manual DPG Text ✨", parent=app.main_window_tag)
manual_input = app.dpg_module.add_input_text(label="Manual input 🔑", parent=app.main_window_tag)
app.register_widget("manual_input", manual_input)

# Callback accessing manual widget
app.add_button("Print Manual 🔍", lambda: print(app.get("manual_input")))

# Fullscreen a specific window
win = app.add_window("Fullscreen Window")
app.fullscreen(win, True)

app.show()
```

---

## 📜 License

MIT License
