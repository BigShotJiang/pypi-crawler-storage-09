from enum import Enum


class CpuArch(Enum):
    X86_64 = "x86_64"
    ARM = "arm"
    NONE = "none"