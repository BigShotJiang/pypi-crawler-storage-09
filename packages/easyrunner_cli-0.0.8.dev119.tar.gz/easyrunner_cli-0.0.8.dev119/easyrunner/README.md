# EasyRunner

Application hosting platform that run on a single server.

Copyright (c) 2024 - 2025 Janaka Abeywardhana
