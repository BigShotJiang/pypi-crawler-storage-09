# EBAT Documentation

In this folder you may find markdown reference of all source files included in EBAT. 
These include class reference, as well as some practical usage examples. 
For a complete usage example, take a look at the sample_authenticator.py instead.