from setuptools import setup, find_packages

setup(name="ebat", packages=find_packages("src"), package_dir={"": "src"})
