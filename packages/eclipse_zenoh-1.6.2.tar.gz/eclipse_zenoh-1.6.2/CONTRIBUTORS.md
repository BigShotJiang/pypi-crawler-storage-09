# Contributors to Eclipse zenoh

These are the contributors to Eclipse zenoh (the initial contributors and the contributors listed in the Git log).


| GitHub username | Name                             |
| --------------- | ---------------------------------|
| kydos           | Angelo Corsaro (ZettaScale)      |
| JEnoch          | Julien Enoch (ZettaScale)        |
| OlivierHecart   | Olivier Hécart (ZettaScale)      |
| gabrik          | Gabriele Baldoni (ZettaScale)    |
| Mallets         | Luca Cominardi (ZettaScale)      |                 
| IvanPaez        | Ivan Paez (ZettaScale)           |            
