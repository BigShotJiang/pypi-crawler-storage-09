# SPDX-FileCopyrightText: 2022-present Dwight Gunning <dgunning@gmail.com>
# SPDX-FileCopyrightText: 2025-present Lucas Astorian <lucas@intellifin.ai>
#
# SPDX-License-Identifier: MIT
__version__ = '1.0.0'
