API
===

.. automodule:: edge_containers_cli

    ``edge_containers_cli``
    -----------------------------------

This is the internal API reference for edge_containers_cli

.. data:: edge_containers_cli.__version__
    :type: str

    Version number as calculated by https://github.com/pypa/setuptools_scm
