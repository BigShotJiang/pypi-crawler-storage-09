""" Django authentication backends.

 These package is designed to be used primarily with Open edX Django projects, but should be compatible with non-edX
 projects as well.
"""
__version__ = '4.6.2'  # pragma: no cover
