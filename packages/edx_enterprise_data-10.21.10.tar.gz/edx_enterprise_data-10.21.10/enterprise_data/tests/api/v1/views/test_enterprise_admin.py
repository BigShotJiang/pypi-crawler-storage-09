"""
Test cases for enterprise_admin views
"""
from datetime import datetime
from unittest import mock

import ddt
from mock import patch
from pytest import mark
from rest_framework import status
from rest_framework.reverse import reverse
from rest_framework.test import APITransactionTestCase

from enterprise_data.admin_analytics.database.filters import (
    FactEngagementAdminDashFilters,
    FactEnrollmentAdminDashFilters,
)
from enterprise_data.admin_analytics.database.queries import (
    FactEngagementAdminDashQueries,
    FactEnrollmentAdminDashQueries,
    SkillsDailyRollupAdminDashQueries,
)
from enterprise_data.admin_analytics.database.query_filters import ComparisonQueryFilter, QueryFilters
from enterprise_data.admin_analytics.database.tables import SkillsDailyRollupAdminDashTable
from enterprise_data.tests.admin_analytics.mock_analytics_data import (
    SKILLS_BY_LEARNING_HOURS,
    TOP_SKILLS,
    TOP_SKILLS_BY_COMPLETIONS,
    TOP_SKILLS_BY_ENROLLMENTS,
)
from enterprise_data.tests.mixins import JWTTestMixin
from enterprise_data.tests.test_utils import EnterpriseSubsidyBudgetFactory, UserFactory, get_dummy_enterprise_api_data
from enterprise_data_roles.constants import ENTERPRISE_DATA_ADMIN_ROLE
from enterprise_data_roles.models import EnterpriseDataFeatureRole, EnterpriseDataRoleAssignment


@ddt.ddt
@mark.django_db
class TestEnterpriseAdminAnalyticsAggregatesView(JWTTestMixin, APITransactionTestCase):
    """
    Tests for EnterpriseAdminAnalyticsAggregatesView.
    """

    def setUp(self):
        """
        Setup method.
        """
        super().setUp()
        self.user = UserFactory(is_staff=True)
        role, __ = EnterpriseDataFeatureRole.objects.get_or_create(name=ENTERPRISE_DATA_ADMIN_ROLE)
        self.role_assignment = EnterpriseDataRoleAssignment.objects.create(
            role=role,
            user=self.user
        )
        self.client.force_authenticate(user=self.user)

        mocked_get_enterprise_customer = mock.patch(
            'enterprise_data.filters.EnterpriseApiClient.get_enterprise_customer',
            return_value=get_dummy_enterprise_api_data()
        )

        self.mocked_get_enterprise_customer = mocked_get_enterprise_customer.start()
        self.addCleanup(mocked_get_enterprise_customer.stop)

        mock.patch.object(SkillsDailyRollupAdminDashTable, "is_group_uuid_field_present", return_value=False)

        mock_is_group_uuid_field_present = mock.patch.object(
            SkillsDailyRollupAdminDashTable,
            "is_group_uuid_field_present",
            return_value=False,
        )
        mock_is_group_uuid_field_present.start()
        self.addCleanup(mock_is_group_uuid_field_present.stop)

        self.enterprise_id = 'ee5e6b3a-069a-4947-bb8d-d2dbc323396c'
        self.set_jwt_cookie()
        self.enrollment_queries = FactEnrollmentAdminDashQueries()
        self.engagement_queries = FactEngagementAdminDashQueries()
        self.skills_queries = SkillsDailyRollupAdminDashQueries()
        self.skills_table = SkillsDailyRollupAdminDashTable()

        enrollment_filters = FactEnrollmentAdminDashFilters()
        self.enrollment_query_filters = QueryFilters([
            enrollment_filters.enterprise_customer_uuid_filter('enterprise_customer_uuid'),
            enrollment_filters.date_range_filter('enterprise_enrollment_date', 'start_date', 'end_date'),
        ])
        engagement_filters = FactEngagementAdminDashFilters()
        self.engagement_query_filters = QueryFilters([
            engagement_filters.enterprise_customer_uuid_filter('enterprise_customer_uuid'),
            engagement_filters.date_range_filter('activity_date', 'start_date', 'end_date'),
        ])

        self.skills_query_filters, __ = self.skills_table.build_query_filters(
            enterprise_customer_uuid=self.enterprise_id,
            start_date='2021-01-01',
            end_date='2021-12-31',
        )
        self.skills_query_filters.append(ComparisonQueryFilter(
            column='completions',
            operator='>',
            value=0
        ))

        self.skills_filters, __, self.enroll_filters, __ = self.skills_table.construct_upskill_learners_query_filters(
            enterprise_customer_uuid=self.enterprise_id,
            start_date='2021-01-01',
            end_date='2021-12-31',
        )

        self.current_filters, __, self.hist_filters, __ = self.skills_table.construct_new_skills_learned_query_filters(
            enterprise_customer_uuid=self.enterprise_id,
            start_date='2021-01-01',
            end_date='2021-12-31',
        )

    def _mock_run_query(self, query, *args, **kwargs):
        """
        mock implementation of run_query.
        """
        # Check if this is the completion_count_query being called with query_filters
        if hasattr(query, '__name__') and query.__name__ == 'get_completion_count_query':
            return [[50]]

        mock_responses = {
            self.enrollment_queries.get_enrollment_date_range_query(): [[
                datetime.strptime('2021-01-01', "%Y-%m-%d"),
                datetime.strptime('2021-12-31', "%Y-%m-%d"),
            ]],
            self.enrollment_queries.get_enrollment_and_course_count_query(self.enrollment_query_filters): [[
                100, 10
            ]],
            self.engagement_queries.get_learning_hours_and_daily_sessions_query(self.engagement_query_filters): [[
                100, 10
            ]],
            'SELECT MAX(created) FROM enterprise_learner_enrollment': [[datetime.strptime('2021-01-01', "%Y-%m-%d")]],
            self.skills_queries.get_unique_skills_gained(self.skills_query_filters): [[30]],
            self.skills_queries.get_upskilled_learners_count(self.skills_filters, self.enroll_filters): [[10]],
            self.skills_queries.get_new_skills_learned_count(self.hist_filters, self.current_filters): [[100]],
        }
        return mock_responses.get(query, [[]])

    def test_get_admin_analytics_aggregates(self):
        """
        Test to get admin analytics aggregates.
        """
        url = reverse('v1:enterprise-admin-analytics-aggregates', kwargs={'enterprise_id': self.enterprise_id})
        with patch('enterprise_data.admin_analytics.data_loaders.run_query', side_effect=self._mock_run_query):
            with patch(
                    'enterprise_data.admin_analytics.database.tables.fact_engagement_admin_dash.run_query',
                    side_effect=self._mock_run_query
            ):
                with patch(
                        'enterprise_data.admin_analytics.database.tables.fact_enrollment_admin_dash.run_query',
                        side_effect=self._mock_run_query
                ):
                    with patch(
                        'enterprise_data.admin_analytics.database.tables.skills_daily_rollup_admin_dash.run_query',
                        side_effect=self._mock_run_query
                    ):
                        response = self.client.get(url)
                        assert response.status_code == status.HTTP_200_OK
                        assert 'enrolls' in response.json()
                        assert 'courses' in response.json()
                        assert 'completions' in response.json()
                        assert 'hours' in response.json()
                        assert 'sessions' in response.json()
                        assert 'last_updated_at' in response.json()
                        assert 'min_enrollment_date' in response.json()
                        assert 'max_enrollment_date' in response.json()
                        assert 'unique_skills_gained' in response.json()
                        assert 'upskilled_learners' in response.json()
                        assert 'new_skills_learned' in response.json()


@ddt.ddt
class TestSkillsStatsAPI(JWTTestMixin, APITransactionTestCase):
    """Tests for EnterpriseAdminAnalyticsSkillsView."""

    def setUp(self):
        """
        Setup method.
        """
        super().setUp()
        self.user = UserFactory(is_staff=True)
        role, __ = EnterpriseDataFeatureRole.objects.get_or_create(
            name=ENTERPRISE_DATA_ADMIN_ROLE
        )
        self.role_assignment = EnterpriseDataRoleAssignment.objects.create(
            role=role, user=self.user
        )
        self.client.force_authenticate(user=self.user)

        self.enterprise_uuid = "ee5e6b3a069a4947bb8dd2dbc323396c"
        self.set_jwt_cookie()

        self.url = reverse(
            "v1:enterprise-admin-analytics-skills",
            kwargs={"enterprise_id": self.enterprise_uuid},
        )

    @patch('enterprise_data.api.v1.views.enterprise_admin.FactEnrollmentAdminDashTable.get_enrollment_date_range')
    @patch('enterprise_data.api.v1.views.enterprise_admin.SkillsDailyRollupAdminDashTable.get_top_skills')
    @patch('enterprise_data.api.v1.views.enterprise_admin.SkillsDailyRollupAdminDashTable.get_top_skills_by_enrollment')
    @patch('enterprise_data.api.v1.views.enterprise_admin.SkillsDailyRollupAdminDashTable.get_top_skills_by_completion')
    @patch('enterprise_data.api.v1.views.enterprise_admin.SkillsDailyRollupAdminDashTable.get_skills_by_learning_hours')
    def test_get(
        self,
        mock_get_skills_by_learning_hours,
        mock_get_top_skills_by_completion,
        mock_get_top_skills_by_enrollment,
        mock_get_top_skills,
        mock_get_enrollment_date_range
    ):
        """
        Test the GET method for the EnterpriseAdminAnalyticsSkillsView works.
        """
        mock_get_enrollment_date_range.return_value = ("2020-04-03", "2024-07-04")
        mock_get_top_skills.return_value = TOP_SKILLS
        mock_get_top_skills_by_enrollment.return_value = TOP_SKILLS_BY_ENROLLMENTS
        mock_get_top_skills_by_completion.return_value = TOP_SKILLS_BY_COMPLETIONS
        mock_get_skills_by_learning_hours.return_value = SKILLS_BY_LEARNING_HOURS

        response = self.client.get(self.url)
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data == {
            "top_skills": [
                {
                    "skill_name": "Python (Programming Language)",
                    "skill_type": "Specialized Skill",
                    "enrolls": 19027.0,
                    "completions": 3004.0,
                },
                {
                    "skill_name": "Data Science",
                    "skill_type": "Specialized Skill",
                    "enrolls": 13756.0,
                    "completions": 1517.0,
                },
                {
                    "skill_name": "Algorithms",
                    "skill_type": "Specialized Skill",
                    "enrolls": 12776.0,
                    "completions": 1640.0,
                },
            ],
            "top_skills_by_enrollments": [
                {
                    "skill_name": "Python (Programming Language)",
                    "subject_name": "business-management",
                    "count": 313.0,
                },
                {
                    "skill_name": "Machine Learning",
                    "subject_name": "business-management",
                    "count": 442.0,
                },
                {
                    "skill_name": "Computer Science",
                    "subject_name": "business-management",
                    "count": 39.0,
                },
            ],
            "top_skills_by_completions": [
                {
                    "skill_name": "Python (Programming Language)",
                    "subject_name": "business-management",
                    "count": 21.0,
                },
                {
                    "skill_name": "SQL (Programming Language)",
                    "subject_name": "business-management",
                    "count": 11.0,
                },
                {
                    "skill_name": "Algorithms",
                    "subject_name": "business-management",
                    "count": 15.0,
                },
            ],
            "skills_by_learning_hours": [
                {
                    "skill_name": "Python (Programming Language)",
                    "learning_hours": 100.0
                },
                {
                    "skill_name": "Data Science",
                    "learning_hours": 80.0
                },
                {
                    "skill_name": "Algorithms",
                    "learning_hours": 60.0
                },
            ]
        }

    @ddt.data(
        {
            "params": {"start_date": 1},
            "error": {
                "start_date": [
                    "Date has wrong format. Use one of these formats instead: YYYY-MM-DD."
                ]
            },
        },
        {
            "params": {"end_date": 2},
            "error": {
                "end_date": [
                    "Date has wrong format. Use one of these formats instead: YYYY-MM-DD."
                ]
            },
        },
        {
            "params": {"start_date": "2024-01-01", "end_date": "2023-01-01"},
            "error": {
                "non_field_errors": [
                    "start_date should be less than or equal to end_date."
                ]
            },
        },
    )
    @ddt.unpack
    def test_get_invalid_query_params(self, params, error):
        """
        Test the GET method return correct error if any query param value is incorrect.
        """
        response = self.client.get(self.url, params)
        assert response.status_code == status.HTTP_400_BAD_REQUEST
        assert response.json() == error


@ddt.ddt
class TestEnterpriseBudgetAPI(JWTTestMixin, APITransactionTestCase):
    """Tests for EnterpriseBudgetView."""

    def setUp(self):
        """
        Setup method.
        """
        super().setUp()
        self.user = UserFactory(is_staff=True)
        role, __ = EnterpriseDataFeatureRole.objects.get_or_create(
            name=ENTERPRISE_DATA_ADMIN_ROLE
        )
        self.role_assignment = EnterpriseDataRoleAssignment.objects.create(
            role=role, user=self.user
        )
        self.client.force_authenticate(user=self.user)

        self.enterprise_uuid = "ee5e6b3a069a4947bb8dd2dbc323396c"
        self.set_jwt_cookie()

        self.url = reverse(
            "v1:enterprise-budgets",
            kwargs={"enterprise_uuid": self.enterprise_uuid},
        )

        self.enterprise_subsidy_budget = EnterpriseSubsidyBudgetFactory(
            enterprise_customer_uuid=self.enterprise_uuid,
            subsidy_access_policy_uuid='8d6503dd-e40d-42b8-442b-37dd4c5450e3',
            subsidy_access_policy_display_name='test-budget'
        )

    def test_get(self):
        """
        Test the GET method for the EnterpriseBudgetView works.
        """
        response = self.client.get(self.url)
        assert response.status_code == status.HTTP_200_OK
        assert response.json() == [
            {
                'subsidy_access_policy_uuid': '8d6503dd-e40d-42b8-442b-37dd4c5450e3',
                'subsidy_access_policy_display_name': 'test-budget',
            }
        ]
