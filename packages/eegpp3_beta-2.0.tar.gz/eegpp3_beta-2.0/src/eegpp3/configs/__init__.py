import os

from .. import EEGPP_DIR

CONFIG_DIR = os.path.join(EEGPP_DIR, 'configs')

tmp = os.path.abspath(os.path.dirname(__file__))