//! Optimizers used internally to optimize the infill criterion

mod optimizer;

pub(crate) use optimizer::*;
