# Plots

```{eval-rst}
.. module:: ehrdata
    :no-index:
```

```{eval-rst}
.. autosummary::
    :toctree: io
    :nosignatures:

    pl.vitessce.gen_config

```
