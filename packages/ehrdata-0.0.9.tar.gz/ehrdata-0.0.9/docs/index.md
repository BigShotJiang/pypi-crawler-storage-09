```{include} ../README.md

```

```{toctree}
:caption: 'General'
:hidden: true
:maxdepth: 1

api.md
changelog.md
contributing.md
references.md

```

```{toctree}
:caption: 'Gallery'
:hidden: true
:maxdepth: 3

tutorials/index
```
