# Common

```{eval-rst}
.. automodule:: eip712.common
    :members:
    :show-inheritance:
```
