# Messages

```{eval-rst}
.. automodule:: eip712.messages
    :members:
    :show-inheritance:
```
