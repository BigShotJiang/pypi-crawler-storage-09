#include <iostream>
#include <jrl_cmakemodule/lib.hh>

int main() {
  std::cout << "JRL CMake module - unittest - cpp" << std::endl;
  lib_function();
}
