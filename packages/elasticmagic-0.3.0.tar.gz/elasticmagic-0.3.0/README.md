[![Test and build](https://github.com/anti-social/elasticmagic/actions/workflows/python.yaml/badge.svg)](https://github.com/anti-social/elasticmagic/actions/workflows/python.yaml)
[![codecov](https://codecov.io/gh/anti-social/elasticmagic/branch/master/graph/badge.svg)](https://codecov.io/gh/anti-social/elasticmagic)
[![docs](https://readthedocs.org/projects/elasticmagic/badge/?version=latest )](https://elasticmagic.readthedocs.io/en/latest/)

elasticmagic
============

Python DSL for Elasticsearch

Caution: do not use it, this is a very alpha
