.. _aggregations:

============
Aggregations
============

.. automodule:: elasticmagic.agg
   :member-order: bysource
   :members:
