.. elasticmagic documentation master file, created by
   sphinx-quickstart on Thu Nov  3 13:52:21 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Elasticmagic's documentation!
========================================

Contents:

.. toctree::
   :maxdepth: 2

   quick_start
   search_api
   aggregations


Indices and tables
==================

* :ref:`genindex`
