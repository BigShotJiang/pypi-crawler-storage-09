.. _search_api:

================
Search Query API
================

.. automodule:: elasticmagic.search

.. autoclass:: elasticmagic.search.SearchQuery
   :inherited-members:
   :members:
   :member-order: bysource

.. autoclass:: elasticmagic.ext.asyncio.search.AsyncSearchQuery
   :member-order: bysource
