import unittest


class QueryTestCase(unittest.TestCase):
    def test(self):
        pass
