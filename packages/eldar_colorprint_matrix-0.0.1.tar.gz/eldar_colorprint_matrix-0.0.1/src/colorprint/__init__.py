﻿"""ColorPrint kitabxanası — rəngli mətn çapı üçün sadə modul."""
from .core import print_color

__all__ = ["print_color"]
__version__ = "0.0.1"
