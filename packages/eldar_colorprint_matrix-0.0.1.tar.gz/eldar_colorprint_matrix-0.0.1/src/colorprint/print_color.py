def print_color():
    print("Salam Eldar!")
    print("Bu qirmizi r?ngd? olacaq")
    print("Bu mavi r?ngd? olacaq")
