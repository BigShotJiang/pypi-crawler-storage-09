# stringplus

Python string utility library.

## Functions

- everse(text)
- count_vowels(text)
- is_palindrome(text)
- eplace_numbers(text)
- only_letters(text)
"@

