# TextFormatter

TextFormatter is a simple Python library for formatting strings easily.

## Installation

```bash
python -m pip install -e .
