"""
Elevator simulation server components
"""
