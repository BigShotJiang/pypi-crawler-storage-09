"""
Traffic pattern generators
"""
