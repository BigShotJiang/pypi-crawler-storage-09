"""Setup script for elexon-bmrs package."""
from setuptools import setup

# Configuration is in pyproject.toml
setup()

