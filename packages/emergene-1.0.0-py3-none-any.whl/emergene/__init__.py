"""EMERGENE for individual cell-based differential transcriptomic analysis across conditions"""

### Setting short names
from . import tools as tl
from . import preprocessing as pp
from . import plotting as pl