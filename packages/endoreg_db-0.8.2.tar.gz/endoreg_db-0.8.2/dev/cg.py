# from endoreg_db.case_generator.utils import get_case_generator
# from endoreg_db.case_generator.lab_sample_factory import LabSampleFactory


# TEMPLATE_NAME = "pre_default_screening_colonoscopy"

# cg = get_case_generator(TEMPLATE_NAME)
# lab_factory = LabSampleFactory()

