# This file is likely obsolete after refactoring into the video_file_meta submodule.
# Its contents should have been moved to files like:
# - video_file_meta/text_meta.py
# - video_file_meta/video_meta.py
# - video_file_meta/initialize_video_specs.py
# - video_file_meta/get_fps.py
# - video_file_meta/get_endo_roi.py
# - video_file_meta/get_crop_template.py
#
# Please ensure all logic has been migrated and consider deleting this file.
pass
