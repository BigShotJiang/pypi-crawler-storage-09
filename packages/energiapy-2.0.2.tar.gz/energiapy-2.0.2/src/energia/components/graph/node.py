"""Node"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from ..._core._name import _Name

if TYPE_CHECKING:
    from ...represent.ations.graph import Graph


@dataclass
class Node(_Name):
    """
    Node of a Graph

    :param label: Label of the component, used for plotting. Defaults to None.
    :type label: str, optional
    :param graph: Graph to which the node belongs. Defaults to None.
    :type graph: Graph, optional
    :ivar name: name. Defaults to ''.
    :vartype name: str

    .. note::
        - name and Graph are set when made a Graph attribute.
    """

    def __post_init__(self):
        self.graph: Graph = None
        _Name.__post_init__(self)
