"""Configuration classes."""

from energy_fault_detector.config.config import Config
from energy_fault_detector.config.base_config import InvalidConfigFile
