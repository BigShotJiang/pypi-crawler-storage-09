"""Provider implementations for secret resolution."""
