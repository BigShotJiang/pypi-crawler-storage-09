# CHANGELOG

<!-- version list -->

## v1.34.0 (2025-10-16)


## v1.33.1 (2025-10-16)


## v1.33.0 (2025-10-16)


## v1.32.0 (2025-10-16)

### Bug Fixes

- Remove duplicate entries.
  ([`a04c1b4`](https://github.com/dmort27/epitran/commit/a04c1b4130c50e52f1a04877544a5b7677eabc61))

- Update test_pashto to match rules.
  ([`7d36489`](https://github.com/dmort27/epitran/commit/7d36489c7e65dd11d27970769848e41b28ab3c15))

- Use correct final yah
  ([`96c1ee6`](https://github.com/dmort27/epitran/commit/96c1ee66e9fac0f0c3efbf16cf119bfcae283d54))

- Use specific rules.
  ([`e648896`](https://github.com/dmort27/epitran/commit/e648896162e47d8db7e96eca6825f6dd721f02f6))

- Use vowel implicit vowels.
  ([`1dbb7c4`](https://github.com/dmort27/epitran/commit/1dbb7c48707e34fa5401e0a316555d96b1bd7bdf))

### Features

- Add Pashto Nothern dialect (pbt) support.
  ([`c19061a`](https://github.com/dmort27/epitran/commit/c19061a327d7d5feb72ea6a60ac05eea2391ad53))


## v1.31.0 (2025-10-16)


## v1.30.0 (2025-10-16)


## v1.29.0 (2025-10-16)


## v1.28.0 (2025-10-16)


## v1.27.0 (2025-10-16)


## v1.26.2 (2025-10-16)


## v1.26.1 (2025-10-15)


## v1.26.0 (2025-10-15)


## v1.25.2 (2025-10-14)

- Initial Release
