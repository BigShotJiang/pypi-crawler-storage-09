# -*- coding: utf-8 -*-


class MappingError(Exception):
    pass


class DatafileError(Exception):
    pass


class FeatureValueError(Exception):
    pass