"""
Conversions between ERC-7730 input and resolved form.
"""
