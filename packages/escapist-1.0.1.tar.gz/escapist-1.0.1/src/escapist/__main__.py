# SPDX-FileCopyrightText: 2025-present Jitesh Sahani (JD) <jitesh.sahani@outlook.com>
#
# SPDX-License-Identifier: MIT


if __name__ == "__main__":
    import sys

    from escapist.cli import escapist

    sys.exit(escapist())
