# API Reference

## Core API

::: escapist

## Exceptions

::: escapist.exceptions
