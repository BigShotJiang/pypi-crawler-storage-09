"""Cmorizer modules for Python."""
