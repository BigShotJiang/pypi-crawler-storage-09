"""ESMValTool diagnostic scripts."""
