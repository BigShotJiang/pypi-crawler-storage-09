Changelog
=========


0.1.1 (18-10-2025)
~~~~~~~~~~~~~~~~~~

Added
~~~~~

- ``RPCErrorCode.PARSE_ERROR`` and ``INTERNAL_ERROR`` constants. (PR_4_)


.. _PR_4: https://github.com/fjarri-eth/pons/pull/4


0.1.0 (unreleased)
------------------

Initial release.
