# EvilEye Multi-Camera Tracking Package

from .custom_object_tracking import ObjectMultiCameraTracking

__all__ = ["ObjectMultiCameraTracking"]

