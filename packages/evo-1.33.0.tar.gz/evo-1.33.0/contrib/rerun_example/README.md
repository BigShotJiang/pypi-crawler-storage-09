# rerun_example

Demo / proof-of-concept for logging evo data into the [rerun viewer](https://github.com/rerun-io/rerun)

***work in progress***, see also: https://github.com/MichaelGrupp/evo/issues/738

https://github.com/user-attachments/assets/e283c588-a075-4863-b2d7-713b09121064

---

Install the rerun SDK in the Python environment where you have also installed evo:
```
pip install rerun-sdk
```

Clone the evo repository and run the script contained in this directory:
```
python rerun_example.py
```
