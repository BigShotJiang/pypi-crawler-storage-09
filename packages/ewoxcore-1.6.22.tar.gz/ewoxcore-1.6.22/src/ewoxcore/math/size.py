
class Size:
    def __init__(self, width:float, height:float):
        self.width:float = width
        self.height:float = height


    