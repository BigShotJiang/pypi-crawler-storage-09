
class KeyValuePair:
    def __init__(self, key:str="", value:str=""):
        self.key:str = key
        self.value:str = value
