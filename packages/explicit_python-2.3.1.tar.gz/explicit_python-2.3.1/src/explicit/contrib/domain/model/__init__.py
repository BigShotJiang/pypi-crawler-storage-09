"""Дополнения для моделей предметной области."""
from .fields import identifier
from .fields import uuid_identifier


__all__ = [
    'identifier',
    'uuid_identifier',
]
