"""Абстракции шины сообщений."""

from .messagebus import MessageBus


__all__ = [
    'MessageBus',
]
