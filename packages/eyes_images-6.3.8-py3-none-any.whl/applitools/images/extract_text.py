from __future__ import absolute_import, division, print_function

from applitools.common.extract_text import ImageOCRRegion as OCRRegion
from applitools.common.extract_text import TextRegionSettings

__all__ = "OCRRegion", "TextRegionSettings"
