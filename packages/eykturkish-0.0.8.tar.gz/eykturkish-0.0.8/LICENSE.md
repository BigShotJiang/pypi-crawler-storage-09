Creative Commons Attribution-NoDerivatives 4.0 International Public License
(CC BY-ND 4.0)

Under this license, as the project owner, I provide you with the following conditions:

1.  Attribution (BY):
    You must give appropriate credit to me as the original author of this work (the project).

2.  NoDerivatives (ND):
    You may not modify, transform, or build upon this work.

Beyond these conditions, this license grants you the right to copy and redistribute the material in any medium or format, even for commercial purposes.

For more information about this license, visit:
https://creativecommons.org/licenses/by-nd/4.0/deed.en