from .eykturkish import *
from .unicodelib import *
from .matematik import *
__version__ = "0.0.8"
