"""Extract functionality tests."""
