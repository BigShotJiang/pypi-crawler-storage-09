"""Factory specification tests."""
