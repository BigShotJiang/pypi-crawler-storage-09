# rail_support.py

from draftsman.classes.entity import Entity
from draftsman.classes.mixins import DirectionalMixin
from draftsman.constants import Direction, SIXTEEN_WAY_DIRECTIONS

from draftsman.data.entities import rail_supports

import attrs


@attrs.define
class RailSupport(DirectionalMixin, Entity):
    """
    .. versionadded:: 3.0.0 (Factorio 2.0)

    An entity that permits the construction of elevated rails above it.
    """

    @property
    def similar_entities(self) -> list[str]:
        return rail_supports

    # =========================================================================

    @property
    def double_grid_aligned(self) -> bool:
        return True

    # =========================================================================

    @property
    def collision_set_rotated(self) -> bool:
        return False

    # =========================================================================

    @property
    def valid_directions(self) -> set[Direction]:
        return SIXTEEN_WAY_DIRECTIONS

    # =========================================================================

    __hash__ = Entity.__hash__
