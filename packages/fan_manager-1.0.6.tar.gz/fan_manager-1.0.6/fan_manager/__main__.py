#!/usr/bin/python
# coding: utf-8
from fan_manager.fan_manager import fan_manager
from fan_manager.fan_manager_mcp import fan_manager_mcp

if __name__ == "__main__":
    fan_manager()
    fan_manager_mcp()
