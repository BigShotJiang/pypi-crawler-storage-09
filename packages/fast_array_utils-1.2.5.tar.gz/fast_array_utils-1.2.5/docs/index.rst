``fast_array_utils``
====================

.. toctree::
   :hidden:

   fast-array-utils <self>
   conv
   stats
   typing
   testing

.. automodule:: fast_array_utils
   :members:

See also the test utilities in :mod:`testing.fast_array_utils`.

.. include:: ../README.rst
   :start-after: .. begin
