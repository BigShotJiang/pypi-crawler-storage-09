``fast_array_utils.stats``
==========================

.. automodule:: fast_array_utils.stats
   :members:
