``testing.fast_array_utils``
============================

.. automodule:: testing.fast_array_utils
   :members:

``testing.fast_array_utils.pytest``
-----------------------------------

.. automodule:: testing.fast_array_utils.pytest
   :members:
