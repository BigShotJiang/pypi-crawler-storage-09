typing
======

The two submodules differ depending on their runtime properties:

``fast_array_utils.types``
--------------------------

.. automodule:: fast_array_utils.types
   :members: CSBase, CSDataset

``fast_array_utils.typing``
---------------------------

.. automodule:: fast_array_utils.typing
   :members:
