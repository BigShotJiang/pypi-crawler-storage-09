from fastapi_rtk import g

g.config.from_pyfile("./app/config.py")
