"""Models package."""

from .config import ProjectConfig

__all__ = ["ProjectConfig"]
