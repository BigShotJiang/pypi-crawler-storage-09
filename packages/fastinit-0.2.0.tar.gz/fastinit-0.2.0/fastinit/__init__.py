"""FastInit - A CLI tool to bootstrap FastAPI applications."""

__version__ = "0.1.0"
