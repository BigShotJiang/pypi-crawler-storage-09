import numpy as np

_features_dtype = np.uint32
