<div  align="center" style="margin-top: 3%">
   <h1>
     Fastlib
   </h1>
   <h3>
    High performance, easy to use, fast to code, ready for production
   </h3>
</div>


## License

[MIT](https://opensource.org/licenses/MIT).
