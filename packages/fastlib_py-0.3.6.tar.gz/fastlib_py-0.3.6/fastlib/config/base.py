# SPDX-License-Identifier: MIT
"""Base configuration classes."""


class BaseConfig:
    """Base class for all configuration classes."""

    pass
