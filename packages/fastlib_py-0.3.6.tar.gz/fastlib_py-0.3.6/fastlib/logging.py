# SPDX-License-Identifier: MIT
"""
Logging module
"""

from ._logging.handlers import Logger

logger = Logger.initialize()
