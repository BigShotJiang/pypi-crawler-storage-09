"""Fastlife views."""
