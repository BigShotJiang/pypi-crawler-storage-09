"""Tests for openapi_new utilities."""
