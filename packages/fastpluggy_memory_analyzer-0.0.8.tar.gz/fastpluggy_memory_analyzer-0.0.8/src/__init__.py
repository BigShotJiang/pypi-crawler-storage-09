# Memory Analyzer Module for FastPluggy

from .plugin import MemoryAnalyzerPlugin