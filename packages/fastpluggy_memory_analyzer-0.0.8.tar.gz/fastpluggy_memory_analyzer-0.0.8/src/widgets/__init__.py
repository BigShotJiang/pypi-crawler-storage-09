from .psutil_analyzer import PsutilAnalyzerWidget

__all__ = ['PsutilAnalyzerWidget']