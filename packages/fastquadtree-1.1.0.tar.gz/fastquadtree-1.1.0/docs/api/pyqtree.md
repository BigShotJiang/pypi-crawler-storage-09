# fastquadtree.pyqtree
::: fastquadtree.pyqtree.Index
    options:
        inherited_members: true