# FastSD CPU (pip version)
