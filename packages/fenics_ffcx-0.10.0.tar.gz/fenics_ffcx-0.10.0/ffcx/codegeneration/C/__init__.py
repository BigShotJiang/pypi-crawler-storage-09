"""Generation of C code."""
