import fetter



def test_cli_a():
    assert hasattr(fetter, 'run')


