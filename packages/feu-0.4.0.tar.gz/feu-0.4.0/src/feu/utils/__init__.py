r"""Contain the utility functions."""
