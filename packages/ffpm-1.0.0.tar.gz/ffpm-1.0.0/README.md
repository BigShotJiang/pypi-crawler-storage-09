# FFPM - File Fusion Package Manager

A tool for packing multiple files into a single executable Python file.

## Authors 
EnderDragon

## Installation

```bash
pip install ffpm