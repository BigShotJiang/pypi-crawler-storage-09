# ffpm/__init__.py
from .ffpm import main