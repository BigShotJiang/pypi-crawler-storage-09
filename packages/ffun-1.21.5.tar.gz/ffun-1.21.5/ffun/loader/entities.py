import enum


class ProxyState(enum.IntEnum):
    available = 1
    suspended = 2
