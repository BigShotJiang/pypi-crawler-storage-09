from typing import Any

UserSettings = dict[int, Any]
