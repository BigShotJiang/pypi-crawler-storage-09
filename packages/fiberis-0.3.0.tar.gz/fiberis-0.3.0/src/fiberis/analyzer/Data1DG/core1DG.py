# Core 1D for geometric data structures
# Shenyao Jin, 09/17/2025

