TODO Please update the README of the package


#Versions
[pub] 0.0.1 Initial version (change the directories, files, setup.py, .github/workflows/*.yml)