"""Top-level package for fileforge."""

__author__ = """Mahmoud Lotfi"""
__email__ = 'mlotfic@gmail.com'
