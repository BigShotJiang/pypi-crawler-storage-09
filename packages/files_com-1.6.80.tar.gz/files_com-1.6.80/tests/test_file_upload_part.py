import unittest
import inspect
import files_sdk
from tests.base import TestBase
from files_sdk.models import FileUploadPart
from files_sdk import file_upload_part

class FileUploadPartTest(TestBase):
    pass 
    # Instance Methods

    # Static Methods
if __name__ == '__main__':
    unittest.main()