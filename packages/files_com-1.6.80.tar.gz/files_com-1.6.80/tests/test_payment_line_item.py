import unittest
import inspect
import files_sdk
from tests.base import TestBase
from files_sdk.models import PaymentLineItem
from files_sdk import payment_line_item

class PaymentLineItemTest(TestBase):
    pass 
    # Instance Methods

    # Static Methods
if __name__ == '__main__':
    unittest.main()