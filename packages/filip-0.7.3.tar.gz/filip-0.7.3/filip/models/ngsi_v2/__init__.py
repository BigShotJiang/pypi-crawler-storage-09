"""
This package contains models for FIWAREs NGSI-LD APIs
"""

from .context import ContextEntity
