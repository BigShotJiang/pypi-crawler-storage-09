"""
Implementation of geo query language
"""
