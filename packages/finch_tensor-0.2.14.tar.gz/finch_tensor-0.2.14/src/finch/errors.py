class PerformanceWarning(Warning):
    pass
