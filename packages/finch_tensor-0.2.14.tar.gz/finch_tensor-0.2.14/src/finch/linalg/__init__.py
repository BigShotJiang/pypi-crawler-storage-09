from ._linalg import vector_norm

__all__ = ["vector_norm"]
