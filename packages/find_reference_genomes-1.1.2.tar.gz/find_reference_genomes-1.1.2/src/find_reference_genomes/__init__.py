# the following import exposes all of the functions from the main.py file
# from the calling script, these will work:
#   import find_reference_genomes
#   find_reference_genomes.dummy_function(...)   <-- functions from main.py are available directly
from find_reference_genomes.main import *
