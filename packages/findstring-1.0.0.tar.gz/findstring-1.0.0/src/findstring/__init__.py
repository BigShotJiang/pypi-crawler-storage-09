"""init.py."""
from .entry import entry
from .findstring import findstring
