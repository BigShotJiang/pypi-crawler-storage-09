"""
FinR — Quantitative Finance Toolkit
-----------------------------------

This is the core package initialization file.
It exposes the main public interfaces for the FinR library.
"""

__version__ = "0.1.0"
from . import stoch, stats