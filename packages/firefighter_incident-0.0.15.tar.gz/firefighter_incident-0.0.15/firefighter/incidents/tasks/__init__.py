from __future__ import annotations

from firefighter.incidents.tasks import updateoncall
