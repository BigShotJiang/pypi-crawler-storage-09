[← Back to Installation index](index.md)

# Verify the installation
Confirm the installation by importing flarchitect and printing its version:
```
(.venv) $ python -c "import flarchitect; print(flarchitect.__version__)"
```
This quick check ensures Flarchitect is ready to use.

