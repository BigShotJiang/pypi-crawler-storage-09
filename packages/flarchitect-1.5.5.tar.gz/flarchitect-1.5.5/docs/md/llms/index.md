# llms.txt Manifest

The project ships an `llms.txt` manifest alongside the generated Markdown
chunks. This page exposes the raw manifest so tooling and curious developers
can inspect the canonical listing without leaving the documentation site. The
same content is generated into `docs/md/llms/index.md` for direct Markdown
access in the static docs build.
