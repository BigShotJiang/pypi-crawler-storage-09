[← Back to Auth Cookbook index](index.md)

# Further reading
- Reference guide: authentication
- Configuration: configuration
- Error handling: error_handling

