[← Back to Extensions index](index.md)

# Acceptable formats
Common `schema.format` values include:
- `date`
- `date-time`
- `password`
- `byte`
- `binary`
- `email`
- `phone`
- `postal_code`
- `uuid`
- `uri`
- `hostname`
- `ipv4`
- `ipv6`
- `int32`
- `int64`
- `float`
- `double`
For comprehensive configuration details see configuration.

