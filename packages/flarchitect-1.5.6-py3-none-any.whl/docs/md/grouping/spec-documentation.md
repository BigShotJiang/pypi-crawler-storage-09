[← Back to Grouping & Aggregation index](index.md)

# Spec documentation
When either flag is enabled `flarchitect` adds explanatory cards to the
OpenAPI/Redoc documentation and surfaces the parameters in the generated
schema so consumers see the available query options.
For a concise summary of the feature flags, refer back to
advanced_configuration and the full option table in
configuration.

