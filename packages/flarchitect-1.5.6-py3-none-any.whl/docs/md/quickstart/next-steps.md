[← Back to Quick Start index](index.md)

# Next steps
To secure the API and define user roles, see authentication and the
defining-roles section.

