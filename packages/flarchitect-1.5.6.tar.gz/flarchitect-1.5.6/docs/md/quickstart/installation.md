[← Back to Quick Start index](index.md)

# Installation
Install the package via pip.
```
pip install flarchitect
```

