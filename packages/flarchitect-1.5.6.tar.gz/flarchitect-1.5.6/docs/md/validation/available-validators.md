[← Back to Validation index](index.md)

# Available validators
`validate_by_type` supports the following names:
- `email`
- `url`
- `ipv4`
- `ipv6`
- `mac`
- `slug`
- `uuid`
- `card`
- `country_code`
- `domain`
- `md5`
- `sha1`
- `sha224`
- `sha256`
- `sha384`
- `sha512`
- `hostname`
- `iban`
- `cron`
- `base64`
- `currency`
- `phone`
- `postal_code`
- `date`
- `datetime`
- `time`
- `boolean`
- `decimal`

