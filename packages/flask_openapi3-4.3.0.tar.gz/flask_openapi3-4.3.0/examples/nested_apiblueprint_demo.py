from flask_openapi3 import APIBlueprint, OpenAPI

app = OpenAPI(__name__)

api = APIBlueprint("book", __name__, url_prefix="/api/book")
api_english = APIBlueprint("english", __name__)
api_chinese = APIBlueprint("chinese", __name__)


@api_english.post("/english")
def create_english_book():
    return {"message": "english"}


@api_chinese.post("/chinese")
def create_chinese_book():
    return {"message": "chinese"}


# register nested api
api.register_api(api_english)
api.register_api(api_chinese)
# register api
app.register_api(api)

if __name__ == "__main__":
    app.run(debug=True)
