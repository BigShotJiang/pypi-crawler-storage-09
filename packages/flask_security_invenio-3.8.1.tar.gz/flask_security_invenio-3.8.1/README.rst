Flask-Security-Invenio
======================

WARNING: This is a private fork of Flask-Security used for Invenio. Please use
`Flask-Security-Too <https://flask-security-too.readthedocs.io/>`_ instead.
