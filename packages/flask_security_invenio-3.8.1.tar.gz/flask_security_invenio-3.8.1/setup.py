# -*- coding: utf-8 -*-

"""Simple security for Flask apps."""

from setuptools import setup

setup()
