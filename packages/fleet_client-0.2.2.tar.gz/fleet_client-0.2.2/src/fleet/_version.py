# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

__title__ = "fleet"
__version__ = "0.2.2"  # x-release-please-version
