import os
import ast
import importlib.util
from typing import Dict, List, Any


def get_python_files(folder_path: str) -> List[str]:

    return [ os.path.join(root,file) for root, _ , files  in os.walk(folder_path) for file in files if file.endswith('.py') ]

def extract_functions_with_code(file_path: str) -> Dict[str, str]:
    with open(file_path, "r") as file:
        file_content = file.read()  # Read file content once

    tree = ast.parse(file_content)

    functions = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef):
            function_name = node.name
            function_code = ast.get_source_segment(file_content, node)
            functions[function_name] = function_code
    return functions

def analyze_dependencies(function_code: str) -> List[str]:
    try:
        tree = ast.parse(function_code)
    except SyntaxError as e:
        print(f"Syntax error in function code: {e}")
        return []

    dependencies = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name):
                dependencies.append(node.func.id)
            elif isinstance(node.func, ast.Attribute):
                dependencies.append(node.func.attr)

    return dependencies

def find_function_dependencies(file_path: str) -> Dict[str, List[str]]:
    functions_with_code = extract_functions_with_code(file_path)
    function_dependencies = {}

    for func_name, func_code in functions_with_code.items():
        dependencies = analyze_dependencies(func_code)
        function_dependencies[func_name] = dependencies

    return function_dependencies

def topological_sort(dependency_graph: Dict[str, List[str]]) -> List[str]:
    visited = set()
    stack = []

    def visit(node):
        if node not in visited:
            visited.add(node)
            for neighbor in dependency_graph.get(node, []):
                visit(neighbor)
            stack.append(node)

    for node in dependency_graph:
        visit(node)

    return stack[::-1]

def execute_function(file_path: str, function_name: str, attributes: Dict[str,Any]):
    dependencies = find_function_dependencies(file_path)
    sorted_functions = topological_sort(dependencies)

    if function_name not in sorted_functions:
        return

    module_name = os.path.splitext(os.path.basename(file_path))[0]
    spec = importlib.util.spec_from_file_location(module_name, file_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)   

    for func in sorted_functions:
        if hasattr(module, func):
            func_to_call = getattr(module, func)
            if callable(func_to_call):
                try:
                    args = attributes.get(func,())
                    if not isinstance(args,tuple):
                        args = (args,)
                    result = func_to_call(*args)  
                    if func == function_name:
                        return result
                except Exception as e:
                    print(f"Error executing {func}: {e}")

def main(folder_path: str, function_name: str, attributes: Dict[str,Any]):
    python_files = get_python_files(folder_path)

    for file_path in python_files:
        return execute_function(file_path, function_name,attributes)


def read_function_file(custom_path):    
    with open(custom_path,'r') as file:
        lines = file.readlines()
    return lines

def get_env_dir():
    current_path = os.getcwd()
    return os.path.abspath(os.path.join(current_path,'env/bin/activate'))

def install_requirements(requirements_path):
    env_dir = get_env_dir()
    command = f"source {env_dir}; pip3 install -r {requirements_path}"
    os.system(command)

def load_variable_from_file(file_path, variable_name="ARGS"):
    spec = importlib.util.spec_from_file_location("module_name", file_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return getattr(module, variable_name, None)

def execute_functions(folder_path,file_path):
    print(f"execute_functions called with folder_path={folder_path}, file_path={file_path}")
    functions = read_function_file(file_path)
    print(f"Functions read: {functions}")
    results = []
    
    for function_name in functions:
        function_name = function_name.strip()
        if not function_name:
            continue
            
        try:
            # Import the module directly
            import importlib.util
            import sys
            import os
            
            # Find the Python file in the folder
            python_files = get_python_files(folder_path)
            target_file = None
            for file_path in python_files:
                # Filter out test files, cache files, and other irrelevant files
                filename = os.path.basename(file_path)
                # Exclude specific test files but allow test_functions.py
                if (not any(part in file_path for part in ['__pycache__', 'site-packages', 'flexmetric_test_env', 'test_runner', 'test_polling']) and
                    not (filename.startswith('test_') and filename != 'test_functions.py')):
                    target_file = file_path
                    break
            
            if not target_file:
                print(f"No suitable Python file found in {folder_path}")
                continue
                
            print(f"Loading module from {target_file}")
            # Load the module
            module_name = os.path.splitext(os.path.basename(target_file))[0]
            spec = importlib.util.spec_from_file_location(module_name, target_file)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            
            print(f"Executing function {function_name}")
            # Execute the function
            if hasattr(module, function_name):
                func = getattr(module, function_name)
                if callable(func):
                    result = func()
                    print(f"Function {function_name} returned: {result}")
                    if result:
                        results.append(result)
                    else:
                        print(f"Function {function_name} returned None")
                else:
                    print(f"{function_name} is not callable")
            else:
                print(f"Function {function_name} not found in module")
                
        except Exception as e:
            print(f"Error executing function {function_name}: {e}")
            import traceback
            traceback.print_exc()
            continue
    
    return results