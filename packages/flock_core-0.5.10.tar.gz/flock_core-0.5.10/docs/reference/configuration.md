# Configuration Reference

*Coming soon: Configuration options*

For now, see:
- [Installation Guide](../getting-started/installation.md) for environment variables
- [.envtemplate](https://github.com/whiteducksoftware/flock/blob/main/.envtemplate) for all options
