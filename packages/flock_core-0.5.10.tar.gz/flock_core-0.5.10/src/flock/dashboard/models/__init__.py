"""Dashboard models for graph visualization and data structures."""
