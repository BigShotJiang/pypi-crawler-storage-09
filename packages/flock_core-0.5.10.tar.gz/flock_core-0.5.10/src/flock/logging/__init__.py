"""Flock logging system with Rich integration and structured logging support."""

# from flock.logging import configure_logging

# __all__ = ["configure_logging"]
