"""Default Stdio Server Implementation for flock."""
