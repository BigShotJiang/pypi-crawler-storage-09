import asyncio

from pydantic import BaseModel

from flock import Flock
from flock.registry import flock_type


@flock_type
class MyDreamPizza(BaseModel):
    pizza_idea: str


@flock_type
class Pizza(BaseModel):
    ingredients: list[str]
    size: str
    crust_type: str
    step_by_step_instructions: list[str]


flock = Flock()

pizza_master = (
    flock.agent("pizza_master").consumes(MyDreamPizza).publishes(Pizza, fan_out=3)
)


async def main():
    pizza_idea = MyDreamPizza(pizza_idea="pizza with pineapple")
    await flock.publish(pizza_idea)
    await flock.run_until_idle()


if __name__ == "__main__":
    asyncio.run(main(), debug=True)
