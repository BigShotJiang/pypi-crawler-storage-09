"""Tests for storage modules."""
