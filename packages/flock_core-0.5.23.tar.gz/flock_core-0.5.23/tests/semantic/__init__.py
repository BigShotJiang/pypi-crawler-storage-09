"""Semantic subscription tests."""
