"""Constants file
"""


# pylint: disable=invalid-name,too-few-public-methods
class NumericalConstants:
    """numerical constants"""

    epsilon = 1e-7
