import typer

app = typer.Typer(help="Config management commands")
