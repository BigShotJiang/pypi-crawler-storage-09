"""Sifts - Python package for code analysis."""

__version__ = "0.20"
