"""FlutterCraft: Automate your Flutter app setup like a pro."""

__version__ = "0.1.2"
