"""FlutterCraft configuration module."""
