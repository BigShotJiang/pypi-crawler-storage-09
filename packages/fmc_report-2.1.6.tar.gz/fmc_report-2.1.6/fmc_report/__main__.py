from fmc_report.app import app

if __name__ == '__main__':
    app.run()
