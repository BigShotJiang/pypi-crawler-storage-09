from collections import namedtuple

VariableMetadata = namedtuple("VariableMetadata", ["units", "long_name"])
