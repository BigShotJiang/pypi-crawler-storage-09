from .corrector import CorrectorSelector
from .module import ModuleSelector
from .registry import Registry
