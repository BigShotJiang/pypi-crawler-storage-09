# Changelog

## v1.0.0 (2025-10-18)

- Add support for and default to stable API version
- Add support for endpoints with historical prices

## v0.1.2 (2025-03-06)

- Add affiliate link to README
- Add `to_pandas` parameter to `fmp_get()`
- Add optional dependencies to allow installation via `pip install fmpapi[pandas]`

## v0.1.1 (2025-02-02)

- Move dev package dependencies to optional dependency groups
- Add types to function inputs and outputs
- Correct typos in README

## v0.1.0 (2024-12-22)

- First release of `fmpapi`
