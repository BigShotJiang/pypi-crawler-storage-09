import polars as pl
import pytest

from fmpapi import fmp_get
