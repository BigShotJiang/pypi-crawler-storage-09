"""Contains models used in this package.

Some models contained here may also be used outside this
package.
"""
