# FNTPL

The template engine for naming new files.
