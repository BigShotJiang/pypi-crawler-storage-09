"""Template files for folder2md4llms."""
