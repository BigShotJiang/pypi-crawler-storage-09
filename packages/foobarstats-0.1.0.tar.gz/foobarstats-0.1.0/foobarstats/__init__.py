from foobarstats.models import TrackStat
from foobarstats.parser import load