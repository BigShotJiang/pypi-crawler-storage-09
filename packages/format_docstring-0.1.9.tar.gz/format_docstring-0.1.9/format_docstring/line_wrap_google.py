def wrap_docstring_google(
        docstring: str,
        line_length: int,
        leading_indent: int | None = None,
        fix_rst_backticks: bool = True,
) -> str:
    """A placeholder for now."""  # noqa: D401
    return ''
