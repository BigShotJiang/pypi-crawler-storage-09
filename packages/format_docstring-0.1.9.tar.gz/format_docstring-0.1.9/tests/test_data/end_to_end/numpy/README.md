All the test cases in `tests/test_data/line_wrap/numpy` should be here, but not
all the test cases here are over there.
