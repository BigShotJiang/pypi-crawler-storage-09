All the test cases here should be in `tests/test_data/end_to_end/numpy`.
