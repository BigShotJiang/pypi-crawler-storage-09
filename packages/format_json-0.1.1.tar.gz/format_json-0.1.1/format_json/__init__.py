"""Public package surface for format-json."""

from __future__ import annotations

from .main import main

__all__ = ['main']
