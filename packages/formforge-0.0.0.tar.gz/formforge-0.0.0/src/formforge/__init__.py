print("Hello, placeholder world!")
