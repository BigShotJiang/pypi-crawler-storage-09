API Reference
======================

This section provides detailed documentation for Formulate's API.

.. toctree::
   :maxdepth: 1
   :caption: Modules

   modules/formulate
   modules/ast
   modules/identifiers
   modules/toast
   modules/exceptions
