Abstract Syntax Tree (AST)
===========================

This module provides the Abstract Syntax Tree (AST) for Formulate.

.. automodule:: formulate.AST
   :members:
   :undoc-members:
   :show-inheritance:
