Exceptions
=======================================

This module provides functions for handling exceptions.

.. automodule:: formulate.exceptions
   :members:
   :undoc-members:
   :show-inheritance:
