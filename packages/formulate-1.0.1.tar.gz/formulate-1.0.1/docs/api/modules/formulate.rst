formulate
======================

This module provides the main functions for Formulate.

.. automodule:: formulate
   :members:
   :undoc-members:
   :show-inheritance:
