Identifiers
=======================================

This module provides definitions for how constants and function translations.

.. automodule:: formulate.identifiers
   :members:
   :undoc-members:
   :show-inheritance:
