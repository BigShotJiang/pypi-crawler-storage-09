Performance Considerations
================================================

TODO
