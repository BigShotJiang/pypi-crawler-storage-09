Citing Formulate
======================

If you use Formulate in your research, please cite it appropriately. This page provides information on how to cite Formulate in academic work.

Citation Information
----------------------------------------------


TODO
