from __future__ import annotations

import formulate


def test_version():
    assert formulate.__version__
