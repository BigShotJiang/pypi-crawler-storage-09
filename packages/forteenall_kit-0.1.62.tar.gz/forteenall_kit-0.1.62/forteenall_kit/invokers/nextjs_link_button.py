class LinkData:
    
    pass

class Feture:
    
    pass