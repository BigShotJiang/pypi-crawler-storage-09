#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Copyright (c) 2020 LG Electronics Inc.
# SPDX-License-Identifier: Apache-2.0

import tlsh
import logging
import psycopg2
import pandas as pd
import socket
from urllib.parse import urlparse
from fosslight_binary._binary import TLSH_CHECKSUM_NULL
from fosslight_util.oss_item import OssItem
import fosslight_util.constant as constant

columns = ['filename', 'pathname', 'checksum', 'tlshchecksum', 'ossname',
           'ossversion', 'license', 'platformname',
           'platformversion']
conn = ""
cur = ""
logger = logging.getLogger(constant.LOGGER_NAME)
DB_URL_DEFAULT = "postgresql://bin_analysis_script_user:script_123@bat.lge.com:5432/bat"


def get_oss_info_from_db(bin_info_list, dburl=""):
    _cnt_auto_identified = 0
    conn_str, dbc = get_connection_string(dburl)
    # DB URL에서 host 추출
    try:
        db_host = dbc.hostname
    except Exception as ex:
        logger.warning(f"Failed to parse DB URL for host: {ex}")
        db_host = None

    is_internal = False
    if db_host:
        try:
            # DNS lookup 시도
            socket.gethostbyname(db_host)
            is_internal = True
        except Exception:
            is_internal = False

    if is_internal:
        connect_to_lge_bin_db(conn_str)
        if conn != "" and cur != "":
            for item in bin_info_list:
                bin_oss_items = []
                tlsh_value = item.tlsh
                checksum_value = item.checksum
                bin_file_name = item.binary_name_without_path

                df_result = get_oss_info_by_tlsh_and_filename(
                    bin_file_name, checksum_value, tlsh_value)
                if df_result is not None and len(df_result) > 0:
                    _cnt_auto_identified += 1
                    # Initialize the saved contents at .jar analyzing only once
                    if not item.found_in_owasp and item.oss_items:
                        item.oss_items = []

                    for idx, row in df_result.iterrows():
                        if not item.found_in_owasp:
                            oss_from_db = OssItem(row['ossname'], row['ossversion'], row['license'])

                            if bin_oss_items:
                                if not any(oss_item.name == oss_from_db.name
                                           and oss_item.version == oss_from_db.version
                                           and oss_item.license == oss_from_db.license
                                           for oss_item in bin_oss_items):
                                    bin_oss_items.append(oss_from_db)
                            else:
                                bin_oss_items.append(oss_from_db)

                    if bin_oss_items:
                        item.set_oss_items(bin_oss_items)
                        item.comment = "Binary DB result"
                        item.found_in_binary = True
        else:
            logger.warning(f"Internal network detected, but DB connection to '{db_host}' failed. Skipping DB query.")
        disconnect_lge_bin_db()
    else:
        logger.debug(f"Binary DB host '{db_host}' is not reachable. Skipping DB query.")
    return bin_info_list, _cnt_auto_identified


def get_connection_string(dburl):
    # dburl format : 'postgresql://username:password@host:port/database_name'
    connection_string = ""
    user_dburl = True
    dbc = ""
    if dburl == "" or dburl is None:
        user_dburl = False
        dburl = DB_URL_DEFAULT
    try:
        if user_dburl:
            logger.debug("DB URL:" + dburl)
        dbc = urlparse(dburl)
        connection_string = "dbname={dbname} user={user} host={host} password={password} port={port}" \
            .format(dbname=dbc.path.lstrip('/'),
                    user=dbc.username,
                    host=dbc.hostname,
                    password=dbc.password,
                    port=dbc.port)
    except Exception as ex:
        if user_dburl:
            logger.warning(f"(Minor) Failed to parsing db url : {ex}")

    return connection_string, dbc


def get_oss_info_by_tlsh_and_filename(file_name, checksum_value, tlsh_value):
    sql_statement = "SELECT filename,pathname,checksum,tlshchecksum,ossname,ossversion,\
                    license,platformname,platformversion FROM lgematching "
    sql_statement_checksum = " WHERE filename=%s AND checksum=%s;"  # Using parameterized query
    sql_statement_filename = "SELECT DISTINCT ON (tlshchecksum) tlshchecksum FROM lgematching WHERE filename=%s;"  # Using parameterized query

    final_result_item = ""

    df_result = get_list_by_using_query(
        sql_statement + sql_statement_checksum, columns, (file_name, checksum_value))
    # Found a file with the same checksum.
    if df_result is not None and len(df_result) > 0:
        final_result_item = df_result
    else:
        # Match tlsh and fileName
        df_result = get_list_by_using_query(
            sql_statement_filename, ['tlshchecksum'], (file_name,))
        if df_result is None or len(df_result) <= 0:
            final_result_item = ""
        elif tlsh_value == TLSH_CHECKSUM_NULL:  # Couldn't get the tlsh of a file.
            final_result_item = ""
        else:
            matched_tlsh = ""
            matched_tlsh_diff = -1
            for row in df_result.tlshchecksum:
                try:
                    if row != TLSH_CHECKSUM_NULL:
                        tlsh_diff = tlsh.diff(row, tlsh_value)
                        if tlsh_diff <= 120:  # MATCHED
                            if (matched_tlsh_diff < 0) or (tlsh_diff < matched_tlsh_diff):
                                matched_tlsh_diff = tlsh_diff
                                matched_tlsh = row
                except Exception as ex:
                    logger.warning(f"* (Minor) Error_tlsh_comparison: {ex}")
            if matched_tlsh != "":
                final_result_item = get_list_by_using_query(
                    sql_statement + " WHERE filename=%s AND tlshchecksum=%s;", columns, (file_name, matched_tlsh))

    return final_result_item


def get_list_by_using_query(sql_query, columns, params=None):
    result_rows = ""  # DataFrame
    try:
        if params:
            cur.execute(sql_query, params)
        else:
            cur.execute(sql_query)
        rows = cur.fetchall()

        if rows is not None and len(rows) > 0:
            result_rows = pd.DataFrame(data=rows, columns=columns)
    except Exception as ex:
        logger.error(f"Database query error: {ex}")
        result_rows = ""
    return result_rows


def disconnect_lge_bin_db():
    try:
        cur.close()
        conn.close()
    except:
        pass


def connect_to_lge_bin_db(connection_string):
    global conn, cur

    try:
        conn = psycopg2.connect(connection_string)
        cur = conn.cursor()
    except Exception as ex:
        logger.debug(f"(Minor) Can't connect to Binary DB. : {ex}")
        conn = ""
        cur = ""
