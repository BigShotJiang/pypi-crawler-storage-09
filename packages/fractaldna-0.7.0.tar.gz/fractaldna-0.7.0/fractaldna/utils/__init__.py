"""FractalDNA Utility Functions."""
