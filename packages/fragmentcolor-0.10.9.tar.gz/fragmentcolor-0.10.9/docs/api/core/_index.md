<!--
This file defines the canonical order for Core API pages.
Only used by the website exporter; it is not rendered as a page.
You can reference objects by their object name (e.g., Renderer) or directory name (e.g., renderer).
Items not listed here will appear after these, sorted alphabetically.
-->

- Renderer
- Shader
- Pass
- Frame
- Texture
