# Pass.set_compute_dispatch_py

Hidden Python wrapper for Pass::set_compute_dispatch.

Used for IDE hover via lsp_doc; not exported on the website.

```rust
// hidden wrapper doc; no public example
```
