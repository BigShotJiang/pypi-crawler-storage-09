# Renderer.create_depth_texture_js

JavaScript wrapper for Renderer::create_depth_texture.
Hidden from public website; used for IDE hover with lsp_doc.

## Example

```rust
// hidden draft; no public example
```
