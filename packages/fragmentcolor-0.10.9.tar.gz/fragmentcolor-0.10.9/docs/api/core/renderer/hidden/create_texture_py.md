# Renderer::create_texture (Python)

Hidden helper for Python binding documentation coverage.

## Example

```rust
use fragmentcolor::Renderer;
// Python binding: renderer.create_texture(input)
// See main create_texture docs for examples.
```
