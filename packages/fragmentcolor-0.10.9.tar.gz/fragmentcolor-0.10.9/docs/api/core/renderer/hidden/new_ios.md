# Renderer.new_ios

Platform-specific constructor for iOS.
Hidden from public website, available for IDE hover via lsp_doc.

## Example

```rust
// hidden file; no public example
```
