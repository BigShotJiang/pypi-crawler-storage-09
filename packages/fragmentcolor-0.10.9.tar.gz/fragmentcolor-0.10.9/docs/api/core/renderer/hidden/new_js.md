# Renderer.new_js

Platform-specific constructor for JavaScript.
Hidden from public website, available for IDE hover via lsp_doc.

## Example

```rust
// hidden file; no public example
```
