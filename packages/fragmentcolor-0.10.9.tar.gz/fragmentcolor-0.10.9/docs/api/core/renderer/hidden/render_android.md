# Renderer.render_android

Platform-specific method for Android.
Hidden from public website, available for IDE hover via lsp_doc.

## Example

```rust
// hidden file; no public example
```
