# Renderer.render_py

Platform-specific method for Python.
Hidden from public website, available for IDE hover via lsp_doc.

## Example

```rust
// hidden file; no public example
```
