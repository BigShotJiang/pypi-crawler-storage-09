# Mesh.add_instance_py

Python wrapper for Mesh::add_instance.
Hidden from public website; used for IDE hover with lsp_doc.

## Example

```rust
// hidden file; no public example
```
