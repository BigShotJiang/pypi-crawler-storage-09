# Mesh.add_vertices_js

Platform-specific method for JavaScript.
Hidden from public website, available for IDE hover via lsp_doc.

## Example

```rust
// hidden file; no public example
```
