# Mesh.add_vertices_py

Python wrapper for Mesh::add_vertices.
Hidden from public website; used for IDE hover with lsp_doc.

## Example

```rust
// hidden file; no public example
```
