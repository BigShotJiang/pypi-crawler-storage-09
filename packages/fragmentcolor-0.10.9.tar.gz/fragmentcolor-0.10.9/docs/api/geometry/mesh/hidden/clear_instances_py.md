# Mesh.clear_instances_py

Python wrapper for Mesh::clear_instances.
Hidden from public website; used for IDE hover with lsp_doc.

## Example

```rust
// hidden file; no public example
```
