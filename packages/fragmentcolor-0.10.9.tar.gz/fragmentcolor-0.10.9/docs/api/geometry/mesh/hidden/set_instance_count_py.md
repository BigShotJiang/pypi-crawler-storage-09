# Mesh.set_instance_count_py

Hidden Python wrapper for Mesh::set_instance_count.

Used for IDE hover via lsp_doc; not exported on the website.

```rust
// hidden wrapper doc; no public example
```