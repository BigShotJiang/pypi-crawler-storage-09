# Mesh::new

Create an empty mesh.

## Example

```rust
use fragmentcolor::mesh::Mesh;
let m = Mesh::new();
# _ = m;
```
