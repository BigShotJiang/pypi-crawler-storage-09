# Vertex.new_py

Python constructor wrapper for Vertex.
Hidden from public website; used for IDE hover with lsp_doc.

## Example

```rust
// hidden file; no public example
```
