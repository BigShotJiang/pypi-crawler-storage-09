# Vertex.set_py

Python wrapper for Vertex::set.
Hidden from public website; used for IDE hover with lsp_doc.

## Example

```rust
// hidden file; no public example
```
