# Vertex::new

Construct a Vertex from a position (2D or 3D).

## Example

```rust
use fragmentcolor::mesh::Vertex;
let v = Vertex::new([0.0, 0.0]);
```
