# PyTextureTarget::resize(size: [int, int])

Resizes the [PyTextureTarget](https://fragmentcolor.org/api/hidden/platforms/python/pytexturetarget) to the given `[width, height]` dimensions.

## Example

```rust
// Python-only wrapper API.
// No direct Rust example is applicable here.
```
