# PyTextureTarget::size() -> [int, int]

Returns the current size of the [PyTextureTarget](https://fragmentcolor.org/api/hidden/platforms/python/pytexturetarget) as a `[width, height]` pair.

## Example

```rust
// Python-only wrapper API.
// No direct Rust example is applicable here.
```
