# RenderCanvasTarget::canvas() -> RenderCanvas

Returns the underlying RenderCanvas object used to integrate with the windowing system.

## Example

```rust
// Python-only wrapper API.
// No direct Rust example is applicable here.
```
