# RenderCanvasTarget::resize(size: [u32, u32] | (u32, u32) | { width, height })

Resizes the underlying [WindowTarget](https://fragmentcolor.org/api/targets/windowtarget) to the given dimensions.

## Example

```rust
// Python-only wrapper API.
// No direct Rust example is applicable here.
```
