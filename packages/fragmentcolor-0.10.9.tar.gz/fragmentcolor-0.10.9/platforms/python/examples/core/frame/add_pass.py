from fragmentcolor import Frame, Pass

pass1 = Pass("first")
pass2 = Pass("second")

frame = Frame()
frame.add_pass(pass1)
frame.add_pass(pass2)