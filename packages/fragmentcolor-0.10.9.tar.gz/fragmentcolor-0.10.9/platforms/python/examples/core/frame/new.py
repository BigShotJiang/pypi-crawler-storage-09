from fragmentcolor import Frame

frame = Frame()