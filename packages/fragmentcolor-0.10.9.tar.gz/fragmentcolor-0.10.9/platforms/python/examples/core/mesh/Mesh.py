from fragmentcolor import Mesh, Vertex

mesh = Mesh()
mesh.add_vertex([0.0, 0.5, 0.0])
mesh.add_vertex([-0.5, -0.5, 0.0])
mesh.add_vertex([0.5, -0.5, 0.0])