from fragmentcolor import Mesh, Vertex
m = Mesh()
v = Vertex([0.0, 0.0])
m.add_instance(v)