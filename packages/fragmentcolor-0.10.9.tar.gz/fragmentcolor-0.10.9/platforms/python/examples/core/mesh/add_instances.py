from fragmentcolor import Mesh, Vertex
m = Mesh()
m.add_instances([
  Vertex([0.0, 0.0]),
  Vertex([1.0, 1.0]),
])