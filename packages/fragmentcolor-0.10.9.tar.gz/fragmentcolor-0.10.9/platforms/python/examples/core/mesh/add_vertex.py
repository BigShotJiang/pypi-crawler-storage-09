from fragmentcolor import Mesh
m = Mesh()
m.add_vertex([0.0, 0.0])