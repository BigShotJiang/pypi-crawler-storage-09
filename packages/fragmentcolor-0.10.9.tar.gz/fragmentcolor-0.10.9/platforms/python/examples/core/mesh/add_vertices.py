from fragmentcolor import Mesh
m = Mesh()
m.add_vertices([
  [0.0, 0.0],
  [1.0, 0.0],
])