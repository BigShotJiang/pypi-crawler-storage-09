from fragmentcolor import Mesh
m = Mesh()
m.clear_instance_count()