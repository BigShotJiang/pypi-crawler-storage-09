from fragmentcolor import Mesh

mesh = Mesh.from_vertices([
    [0.0, 0.0],
    [1.0, 0.0],
    [0.0, 1.0],
])