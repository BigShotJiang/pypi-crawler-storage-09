from fragmentcolor import Mesh
m = Mesh()