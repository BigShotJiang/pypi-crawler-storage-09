from fragmentcolor import Quad

quad = Quad([-0.5, -0.5], [0.5, 0.5])
