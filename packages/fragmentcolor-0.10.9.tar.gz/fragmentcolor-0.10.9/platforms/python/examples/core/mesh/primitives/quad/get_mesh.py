from fragmentcolor import Quad, Mesh

quad = Quad([-0.5, -0.5], [0.5, 0.5])
mesh = quad.get_mesh()
