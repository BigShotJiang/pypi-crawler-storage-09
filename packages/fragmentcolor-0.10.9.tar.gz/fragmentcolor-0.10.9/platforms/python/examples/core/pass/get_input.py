from fragmentcolor import Pass

rpass = Pass("example")
input = rpass.get_input()
