from fragmentcolor import Pass

rpass = Pass("first rpass")
