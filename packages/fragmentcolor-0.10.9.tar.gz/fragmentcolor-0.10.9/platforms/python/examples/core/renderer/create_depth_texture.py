from fragmentcolor import Renderer
r = Renderer()
depth = r.create_depth_texture([800, 600])