from fragmentcolor import Renderer, TextureFormat

r = Renderer()
tex = r.create_render_texture([256, 256], TextureFormat.Rgba8Unorm)