
from fragmentcolor import Renderer, TextureFormat

r = Renderer()
tex = r.create_storage_texture([64, 64], TextureFormat.Rgba, None)
