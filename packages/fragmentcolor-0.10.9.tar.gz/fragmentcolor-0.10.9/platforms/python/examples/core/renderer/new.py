
from fragmentcolor import Renderer

renderer = Renderer()
texture_target = renderer.create_texture_target([16, 16])
