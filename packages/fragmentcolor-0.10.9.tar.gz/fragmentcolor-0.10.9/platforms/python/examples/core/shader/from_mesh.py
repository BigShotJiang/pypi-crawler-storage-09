from fragmentcolor import Mesh, Shader

mesh = Mesh()
mesh.add_vertex([0.0, 0.0, 0.0])
shader = Shader.from_mesh(mesh)
