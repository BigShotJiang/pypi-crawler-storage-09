from fragmentcolor import Shader, Vertex

vertex = Vertex([0.0, 0.0, 0.0])
shader = Shader.from_vertex(vertex)
