from fragmentcolor import Shader

shader = Shader.default()
shader.set("resolution", [800.0, 600.0])
res = shader.get("resolution")
