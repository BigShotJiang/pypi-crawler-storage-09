
from fragmentcolor import Shader

shader = Shader.default()
keys = shader.list_keys()
