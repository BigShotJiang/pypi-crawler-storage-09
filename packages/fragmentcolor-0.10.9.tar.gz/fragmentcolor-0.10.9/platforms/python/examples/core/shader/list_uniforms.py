from fragmentcolor import Shader

shader = Shader.default()
list = shader.list_uniforms()
