from fragmentcolor import Vertex
v = Vertex([0.0, 0.0, 0.0]).set("uv", [0.5, 0.5])