from fragmentcolor import Vertex
v = Vertex([0.0, 0.0])