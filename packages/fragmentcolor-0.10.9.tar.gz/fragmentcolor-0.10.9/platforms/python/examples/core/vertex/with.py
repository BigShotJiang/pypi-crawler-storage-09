from fragmentcolor import Vertex
v = Vertex([0.0, 0.0, 0.0]).set("weight", 1.0).set("color", [1.0, 0.0, 0.0])
