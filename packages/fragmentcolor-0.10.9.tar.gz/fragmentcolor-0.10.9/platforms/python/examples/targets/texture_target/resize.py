
from fragmentcolor import Renderer

renderer = Renderer()
target = renderer.create_texture_target([64, 64])

target.resize([128, 32])
