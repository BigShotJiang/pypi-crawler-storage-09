
from fragmentcolor import Renderer

renderer = Renderer()
target = renderer.create_texture_target([64, 64])
size = target.size
width = size.width
height = size.height
depth = size.depth
