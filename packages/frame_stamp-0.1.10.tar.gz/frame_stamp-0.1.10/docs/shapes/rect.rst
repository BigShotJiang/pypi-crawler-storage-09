Rect
----

    `inherited (BaseShape)`

Фигура "Прямоугольник".

Параметры
=========

border_width
    Толщина обводки. По умолчанию 0

border_color
    Цвет обводки