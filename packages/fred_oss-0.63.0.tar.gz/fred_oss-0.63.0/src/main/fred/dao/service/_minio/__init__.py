from .service import MinioService
