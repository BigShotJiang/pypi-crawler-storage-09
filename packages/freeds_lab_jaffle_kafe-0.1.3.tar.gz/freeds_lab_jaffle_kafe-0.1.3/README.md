# freeds-lab-jaffle-kafe
jaffle shop kafka emitter
