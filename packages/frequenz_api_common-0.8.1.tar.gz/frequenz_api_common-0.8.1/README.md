# Frequenz Common API

[![Build Status](https://github.com/frequenz-floss/frequenz-api-common/actions/workflows/ci.yaml/badge.svg)](https://github.com/frequenz-floss/frequenz-api-common/actions/workflows/ci.yaml)
[![PyPI Package](https://img.shields.io/pypi/v/frequenz-api-common)](https://pypi.org/project/frequenz-api-common/)
[![Docs](https://img.shields.io/badge/docs-latest-informational)](https://frequenz-floss.github.io/frequenz-api-common/)

## Introduction

Frequenz common gRPC API and bindings

## Contributing

If you want to know how to build this project and contribute to it, please
check out the [Contributing Guide](CONTRIBUTING.md).
