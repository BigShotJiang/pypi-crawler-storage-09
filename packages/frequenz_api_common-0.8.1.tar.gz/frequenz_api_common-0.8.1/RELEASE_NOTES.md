# Frequenz Common API Release Notes

## Summary

## Features

- Add `gridpool.Gridpool` message type to `v1alpha8`, defining a gridpool as an assigned group of microgrids for the purpose of energy trading.
