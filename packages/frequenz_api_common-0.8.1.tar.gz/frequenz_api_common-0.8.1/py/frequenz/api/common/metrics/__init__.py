# License: MIT
# Copyright © 2023 Frequenz Energy-as-a-Service GmbH

"""Metrics bindings for Frequenz common gRPC API."""
