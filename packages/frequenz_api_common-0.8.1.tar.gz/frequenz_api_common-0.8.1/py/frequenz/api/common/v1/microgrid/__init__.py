# License: MIT
# Copyright © 2023 Frequenz Energy-as-a-Service GmbH

"""Microgrid bindings for Frequenz common gRPC API."""
