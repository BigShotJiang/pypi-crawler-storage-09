# License: MIT
# Copyright © 2023 Frequenz Energy-as-a-Service GmbH

"""Components bindings for Frequenz common gRPC API."""
