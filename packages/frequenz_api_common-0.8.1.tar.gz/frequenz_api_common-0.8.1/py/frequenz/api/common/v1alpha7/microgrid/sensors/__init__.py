# License: MIT
# Copyright © 2025 Frequenz Energy-as-a-Service GmbH

"""Sensors bindings for Frequenz common gRPC API."""
