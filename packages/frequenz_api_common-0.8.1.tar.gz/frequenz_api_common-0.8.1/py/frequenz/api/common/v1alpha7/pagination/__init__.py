# License: MIT
# Copyright © 2025 Frequenz Energy-as-a-Service GmbH

"""Pagination bindings for Frequenz common gRPC API."""
