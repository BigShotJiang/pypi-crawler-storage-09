# License: MIT
# Copyright © 2025 Frequenz Energy-as-a-Service GmbH

"""Type bindings for Frequenz common gRPC API."""
