# License: MIT
# Copyright © 2025 Frequenz Energy-as-a-Service GmbH

"""Gridpool bindings for Frequenz common gRPC API."""
