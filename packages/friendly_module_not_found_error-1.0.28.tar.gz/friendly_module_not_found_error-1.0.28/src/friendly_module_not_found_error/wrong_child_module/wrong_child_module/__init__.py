from .wrong_child_module import * #type: ignore
