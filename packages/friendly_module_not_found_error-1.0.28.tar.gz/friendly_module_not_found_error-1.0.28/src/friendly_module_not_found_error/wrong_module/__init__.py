from .wrong_module import * #type: ignore
