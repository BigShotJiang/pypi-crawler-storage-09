# FrogFast

---
ok so the fuck is frogfast well it si a software where you can compile python, c and c++ very poorly and i have no shame telling that shit

to run the frogfast repl just type frogfast in the terminal and to install frogfast pip install frogfast
---

## templetes

so to do templetes in frogfast first run this command:

    templete acid_project

and just like that you got yourself a templete to start off

## compileing (fucking vomits)

ok so to compile a project (coughs) you need to go to the config.frogfast file

there you can tweak the settings if you wnana compile c use gcc if c++ the change lang to g++ and to compile python use nuitka

and we are done now just compile using build config.frogfast and pow done on spot