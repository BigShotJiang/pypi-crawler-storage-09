ATTRACTION = {
    "rabbit adult": "carrot",
    "rabbit child": "carrot",
}
BREEDABLE = {
    "rabbit adult": {"kind": "rabbit child"}
}