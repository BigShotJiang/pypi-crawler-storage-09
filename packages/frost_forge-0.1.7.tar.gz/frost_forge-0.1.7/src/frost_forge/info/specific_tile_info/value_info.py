MACHINES = {
    "composter": "compost",
    "furnace": "fuel",
    "wood crucible": "fuel",
}
VALUES = {
    "compost": {
        "bluebell": 3,
        "carrot": 1,
        "mushroom": 2,
        "potato": 2,
        "sapling": 1,
        "spore": 1,
    },
    "fuel": {
        "coal": 8,
        "wood": 1,
    },
}
