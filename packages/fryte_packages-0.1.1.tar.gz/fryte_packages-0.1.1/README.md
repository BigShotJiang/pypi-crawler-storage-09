# fryte-packages
This repository hosts internal packages used across Fryte's systems and applications. All contents are proprietary and intended for internal use only.
