# Python Authentication Package

This is a reusable Python authentication package that supports multiple authentication methods: JWT, password-based, and API key authentication. It is designed to be easily integrated into various projects while adhering to SOLID principles.

## Features

- **JWT Authentication**:  Generate and verify JSON Web Tokens.
- **Password Authentication**: Hash and verify passwords securely.
- **API Key Authentication**: Generate HTTP API Auth header.
- **Basic Authentication**: Generate HTTP Basic Auth headers.
- **Customizable Auth Strategies**: Easily extend or swap authentication strategies.

## Installation

To install the package, clone the repository and run:

```bash
pip install .
```

## Usage

### JWT Authentication

```python
from src.utils.jwt_helper import JWTTokenHelper

jwt_helper = JWTTokenHelper(secret_key='your_secret_key')
token = jwt_helper.generate_token(user_id='user123')
user_id = jwt_helper.verify_token(token)
```

### Password Authentication

```python
from src.auth.password_auth import PasswordAuth

password_auth = PasswordAuth()
hashed_password = password_auth.hash_password('your_password')
is_valid = password_auth.verify_password('your_password', hashed_password)
```

### API Key Authentication

```python
from src.auth.api_key_auth import ApiKeyAuthService

api_key_auth = ApiKeyAuthService(api_key='your_api_key', schema='X-API-Key')
header = api_key_auth.authenticate()
```

### Basic Authentication

```python
from src.auth.basic_auth import BasicAuthService

basic_auth = BasicAuthService(username='your_username', password='your_password')
header = basic_auth.authenticate()
```

## Exception Handling

The package includes custom exceptions for handling authentication errors:

- `InvalidTokenError`: Raised when a JWT token is invalid.
- `InvalidCredentialsError`: Raised when credentials are invalid.
- `ApiKeyNotFoundError`: Raised when an API key is not found.

## Testing

Unit tests are included for each authentication method. To run the tests, use:


```bash
python -m unittest discover tests
```

## Contributing

Contributions are welcome! Please open an issue or submit a pull request for any enhancements or bug fixes.
