import asyncio

from exceptions.auth_exceptions import TokenRequestError
from core.auth_handler import authenticate


async def main():
        try:
            jwt_creds = {
                "url": "xx",
                "method":"POST",
                "headers": {"Content-Type": "application/x-www-form-urlencoded"},
                "client_id":"xx",
                "client_secret": "xx",
                "grant_type": "client_credentials",
                "data_format":"form"
            }

            jwttoken = await authenticate("jwt", jwt_creds)
            print("Access Token:", jwttoken.access_token)
            print("Expires In:", jwttoken.expires_in)
        except TokenRequestError as e:
            print("Token request failed:", e)
        except Exception as e:
            print("General error:", e)

        # Basic Auth Example
        basic_creds = {
            "username": "testuser",
            "password": "testpassword"
        }
        basictoken = await authenticate("basic", basic_creds)
        print("Basic Token:", basictoken) 

         # API Auth Example
        apikey_creds = {
            "api_key": "apikeytest",
            "schema": "Authorization",
            "prefix": "Bearer"
         }
        apitoken = await authenticate("api_key", apikey_creds)
        print("ApiKey Token:", apitoken)    


if __name__ == "__main__":
    asyncio.run(main())
