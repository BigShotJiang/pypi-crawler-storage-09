from setuptools import setup, find_packages

setup(
    name='fryte-auth',
    version='0.1.0',
    author='AL-Qiari Saif',
    author_email='your.email@example.com',
    description='A Python package for authentication using JWT, password, and API key methods.',
    packages=find_packages(where='src'),
    package_dir={'': 'src'},
    install_requires=[
        "httpx==0.28.1",
        "pydantic==2.12.0",
        "pyjwt==2.10.1",
        "requests==2.32.5",
        "werkzeug==3.1.3",
    ],
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',
)