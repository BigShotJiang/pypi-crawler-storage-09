from models.token_response import TokenResponse
from .auth_strategy import AuthStrategy

class ApiKeyAuthService(AuthStrategy):
    async def authenticate(self, credentials: dict) -> TokenResponse:
        required = ["api_key", "schema"]

        for key in required:
            if key not in credentials or credentials.get(key) is None:
                raise ValueError(f"Missing credential: {key}")
            
        api_key = credentials.get("api_key")
        api_schema = credentials.get("schema", credentials.get("schema")) or "api_key" # e.g., Authorization, X-API-Key, token, api_key.
        api_prefix = credentials.get("prefix", credentials.get("prefix")) or "" # e.g., "Bearer, "Token", etc.
        
        return  TokenResponse(
            token_type=api_schema,
            access_token=f"{api_prefix} {api_key}"
        )