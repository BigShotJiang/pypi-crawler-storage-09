from abc import ABC, abstractmethod
from models.token_response import TokenResponse

class AuthStrategy(ABC):
    @abstractmethod
    async def authenticate(self, credentials: dict) -> TokenResponse:
        pass