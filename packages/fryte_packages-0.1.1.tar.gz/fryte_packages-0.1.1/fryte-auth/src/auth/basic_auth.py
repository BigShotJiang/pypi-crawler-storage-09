import base64
from auth.auth_strategy import AuthStrategy
from models.token_response import TokenResponse

class BasicAuthService(AuthStrategy):
     async def authenticate(self, credentials: dict) -> TokenResponse:
        required = ["username", "password"]
    
        for key in required:
            if key not in credentials or credentials.get(key) is None:
                raise ValueError(f"Missing credential: {key}")
            
        creds = f"{credentials.get("username")}:{credentials.get("password")}"
        token = base64.b64encode(creds.encode()).decode()

        return TokenResponse(
            token_type="Basic",
            access_token=token 
        )