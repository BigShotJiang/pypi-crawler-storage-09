from datetime import datetime, timedelta
import logging
import httpx
from models.token_response import TokenResponse
from .auth_strategy import AuthStrategy
from exceptions.auth_exceptions import TokenRequestError

logger = logging.getLogger(__name__)

class JwtAuthService(AuthStrategy):
    async def authenticate(self, credentials: dict)-> TokenResponse:
        
        required = ["client_id", "client_secret", "url", "grant_type"]
        for key in required:
            if key not in credentials or credentials.get(key) is None:
                raise ValueError(f"Missing credential: {key}")
            
        headers = {}
        method = credentials.get("method") or "POST"
        method = method.upper()
        url = credentials.get("url") 
        data_format = credentials.get("data_format") or "form"

        payload = {
            "client_id": credentials.get("client_id"),
            "client_secret": credentials.get("client_secret"),
            "grant_type": credentials.get("grant_type") or "client_credentials",
        }

        if data_format == "form":
            headers.setdefault("Content-Type", "application/x-www-form-urlencoded")
            request_body = {"data": payload}
        elif data_format == "json":
            headers.setdefault("Content-Type", "application/json")
            request_body = {"json": payload}
        else:
            raise ValueError("data_format must be either 'json' or 'form'")
        

        try:
            async with httpx.AsyncClient() as client:
                response = await client.request(
                    url=url,
                    method=method,
                    headers=headers,
                    **request_body
                )
            if response.status_code != 200: 
                raise Exception(
                    f"Token request failed with status {response.status_code}"
                )

            data = response.json()
            return TokenResponse(**data)

        except httpx.HTTPStatusError as e:
            logger.error(f"HTTP request failed: {e}")
            raise TokenRequestError("Token request failed.") from e
        except ValueError as e:
            logger.error(f"Invalid response format (not JSON): {e}")
            raise TokenRequestError("Invalid JSON response.") from e
        
