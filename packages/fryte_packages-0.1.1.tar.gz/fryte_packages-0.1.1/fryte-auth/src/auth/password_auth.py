from models.token_response import TokenResponse
from .auth_strategy import AuthStrategy
from utils.password_helper import PasswordHasher

class PasswordAuthService(AuthStrategy):

    def authenticate(self, credentials: dict) -> TokenResponse:
        required = ["username", "password"]

        for key in required:
            if key not in credentials or credentials.get(key) is None:
                raise ValueError(f"Missing credential: {key}")

        username = credentials.get("username")
        password = credentials.get("password")

        # Here you would typically verify the username and password against a user store

        # If authentication is successful, return a token response (this is just a placeholder)
        return TokenResponse(
            token_type="Password",
            access_token="generated_access_token_for_"
        )