from auth.auth_strategy import AuthStrategy
from .factory import AuthStrategyFactory
from models.token_response import TokenResponse

async def authenticate(auth_type: str, credentials: dict) -> TokenResponse:
    strategy = AuthStrategyFactory.get_strategy(auth_type)
    return await strategy.authenticate(credentials)