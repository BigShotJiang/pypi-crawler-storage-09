from auth.auth_strategy import AuthStrategy
from auth.api_key_auth import ApiKeyAuthService 
from auth.jwt_auth import JwtAuthService
from auth.basic_auth import BasicAuthService

class AuthStrategyFactory:
    _strategies = {
        "api_key": ApiKeyAuthService(),
        "jwt": JwtAuthService(),
        "basic": BasicAuthService()
    }

    @classmethod
    def get_strategy(cls, auth_type: str) -> AuthStrategy:
        if auth_type not in cls._strategies:
            raise ValueError(f"Unsupported auth_type: {auth_type}")
        return cls._strategies[auth_type]
