class InvalidTokenError(Exception):
    """Exception raised for invalid JWT tokens."""
    pass

class InvalidCredentialsError(Exception):
    """Exception raised for invalid credentials during authentication."""
    pass

class ApiKeyNotFoundError(Exception):
    """Exception raised when an API key is not found."""
    pass
class TokenRequestError(Exception):
    """Exception raised when a token request fails."""
    pass
