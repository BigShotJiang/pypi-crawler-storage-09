
from typing import Optional
from datetime import datetime, timedelta, timezone
from pydantic import BaseModel, model_validator


class TokenResponse(BaseModel):
    access_token: str
    token_type: Optional[str] = None
    expires_in: Optional[int] = None
