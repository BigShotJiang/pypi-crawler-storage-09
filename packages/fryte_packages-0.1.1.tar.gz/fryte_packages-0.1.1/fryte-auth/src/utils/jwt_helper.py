from datetime import datetime, timedelta, timezone
import time
from exceptions.auth_exceptions import InvalidTokenError
import jwt

class JWTTokenHelper:
    def __init__(self, secret_key: str, algorithm: str = 'HS256', expiration_minutes: int = 30):
        self.secret_key = secret_key
        self.algorithm = algorithm
        self.expiration_minutes = expiration_minutes
    
    # Generate JWT token 
    def generate_token(self, user_id: str) -> str:
        expiration = datetime.now(timezone.utc) + timedelta(minutes=self.expiration_minutes)
        token = jwt.encode({'user_id': user_id, 'exp': expiration}, self.secret_key, algorithm=self.algorithm)
        return token
    
    # Verify JWT token
    def verify_token(self, token: str) -> str:
        try:
            payload = jwt.decode(token, self.secret_key, algorithms=[self.algorithm])
            return payload['user_id']
        except jwt.ExpiredSignatureError:
            raise jwt.InvalidTokenError("Token has expired.")
        except jwt.InvalidTokenError:
            raise InvalidTokenError("Invalid token.")
        
    # Decode JWT token without verification (useful for extracting info)
    def decode_token(self, token: str) -> dict:
        try:
            payload = jwt.decode(token, self.secret_key, algorithms=[self.algorithm], options={"verify_exp": False})
            return payload
        except jwt.InvalidTokenError:
            raise InvalidTokenError("Invalid token.")   
        
    # Check if token is expired
    @staticmethod    
    def is_token_expired(token: dict) -> bool:
        exp = token.get('exp')
        if exp is None:
            return True
        current_time = int(time.time())
        return current_time >= exp