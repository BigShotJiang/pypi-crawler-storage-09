import unittest
from auth.api_key_auth import ApiKeyAuthService 
from exceptions.auth_exceptions import ApiKeyNotFoundError

class TestApiKeyAuth(unittest.TestCase):

    def setUp(self):
        self.valid_api_key = "1111aaaa-bbbb-cccc-dddd-eeeeffff0000"
        self.schema = "ApiKey"
        self.prefix = "Bearer"
        


    # def test_authenticate_with_api_key_and_schema(self):
    #     service = ApiKeyAuthService(api_key="mykey", schema="X-API-Key")
    #     self.assertEqual(service.authenticate(), {"X-API-Key": "mykey"})

    # def test_authenticate_with_prefix(self):
    #     service = ApiKeyAuthService(api_key="mykey", schema="Authorization", prefix="Bearer")
    #     self.assertEqual(service.authenticate(), {"Authorization": "Bearer mykey"})

    # def test_authenticate_raises_when_no_api_key(self):
    #     service = ApiKeyAuthService(api_key="", schema="X-API-Key")
    #     with self.assertRaises(ApiKeyNotFoundError):
    #         service.authenticate()

if __name__ == '__main__':
    unittest.main()