import base64
import unittest
from auth.basic_auth import BasicAuthService
from exceptions.auth_exceptions import InvalidCredentialsError

class TestBasicAuth(unittest.TestCase):

    def setUp(self):
        self.username = "valid_username"
        self.password = "valid_password"
  

if __name__ == '__main__':
    unittest.main()