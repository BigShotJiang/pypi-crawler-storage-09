import unittest
from utils.jwt_helper import JWTTokenHelper as JwtAuth
from exceptions.auth_exceptions import InvalidTokenError

class TestJwtAuth(unittest.TestCase):

    def setUp(self):
      pass

if __name__ == '__main__':
    unittest.main()