import unittest
import time, datetime
from utils.jwt_helper import JWTTokenHelper
from exceptions.auth_exceptions import InvalidTokenError

class TestJWTTokenHelper(unittest.TestCase):
    def setUp(self):
        self.secret_key = "test_secret"
        self.algorithm = "HS256"
        self.expiration_minutes = 1/60  # 1 second for quick expiry
        self.helper = JWTTokenHelper(self.secret_key, self.algorithm, self.expiration_minutes)
        self.user_id = "user123"

    def test_generate_token(self):
        token = self.helper.generate_token(self.user_id)
        self.assertIsInstance(token, str)
        self.assertGreater(len(token), 0)

    def test_verify_token(self):
        token = self.helper.generate_token(self.user_id)
        result = self.helper.verify_token(token)
        self.assertEqual(result, self.user_id)

    def test_verify_token_invalid(self):
        with self.assertRaises(InvalidTokenError):
            self.helper.verify_token("invalid.token.string")

    def test_verify_token_expired(self):
        helper = JWTTokenHelper(self.secret_key, self.algorithm, expiration_minutes=1/3600)  # ~1 ms
        token = helper.generate_token(self.user_id)
        time.sleep(0.01)  # Wait for token to expire
        with self.assertRaises(Exception):
            helper.verify_token(token)

    def test_decode_token(self):
        token = self.helper.generate_token(self.user_id)
        payload = self.helper.decode_token(token)
        self.assertEqual(payload['user_id'], self.user_id)
        self.assertIn('exp', payload)

    def test_decode_token_invalid(self):
        with self.assertRaises(InvalidTokenError):
            self.helper.decode_token("invalid.token.string")

    def test_is_token_expired_true(self):
        past_exp = int(time.time()) - 10
        payload = {'exp': past_exp}
        self.assertTrue(JWTTokenHelper.is_token_expired(payload))

    def test_is_token_expired_false(self):
        future_exp = int(time.time()) + 1000
        payload = {'exp': future_exp}
        self.assertFalse(JWTTokenHelper.is_token_expired(payload))

    def test_is_token_expired_no_exp(self):
        payload = {}
        self.assertTrue(JWTTokenHelper.is_token_expired(payload))

if __name__ == '__main__':
    unittest.main()