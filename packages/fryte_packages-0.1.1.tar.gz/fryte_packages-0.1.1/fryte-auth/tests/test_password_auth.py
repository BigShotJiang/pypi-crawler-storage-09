import unittest
from auth.password_auth import PasswordAuthService as PasswordAuth


class TestPasswordAuth(unittest.TestCase):

    def setUp(self):
        self.auth = PasswordAuth()
        self.password = "securepassword"


if __name__ == '__main__':
    unittest.main()