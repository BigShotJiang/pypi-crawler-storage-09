export interface SerializedEdge {
  src_nid: string;
  src_ioid: string;
  trg_nid: string;
  trg_ioid: string;
}
