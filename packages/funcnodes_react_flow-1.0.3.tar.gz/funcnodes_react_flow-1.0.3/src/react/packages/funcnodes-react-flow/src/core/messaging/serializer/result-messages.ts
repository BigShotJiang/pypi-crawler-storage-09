export interface ResultMessage {
  type: "result";
  id?: string;
  result: any;
}
