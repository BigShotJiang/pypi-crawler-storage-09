export interface InLineRendererProps {}
export type InLineRendererType = ({}: InLineRendererProps) => string;
