export { GeneralTab } from "./GeneralTab";
export { InputTab } from "./InputTab";
export { OutputTab } from "./OutputTab";
