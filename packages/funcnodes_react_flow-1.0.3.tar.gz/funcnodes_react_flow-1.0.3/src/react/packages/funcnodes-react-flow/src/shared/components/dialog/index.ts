export { CustomDialog } from "./CustomDialog";
export type { DialogProps, DialogButtonConfig } from "./CustomDialog";
