# 说明
这是一个函数封装工具

## 安装
使用pip安装：
bash
pip install Functions_d
 
### 联系我们
如果你有任何问题或建议，请联系我649898871@qq.com