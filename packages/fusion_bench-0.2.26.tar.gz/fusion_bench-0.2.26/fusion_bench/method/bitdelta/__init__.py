"""
Adapted from https://github.com/FasterDecoding/BitDelta
"""

from .bitdelta import BitDeltaAlgorithm
