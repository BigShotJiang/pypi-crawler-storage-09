# flake8: noqa F401
from .dawe_for_clip import DataAdaptiveWeightEnsemblingForCLIP
