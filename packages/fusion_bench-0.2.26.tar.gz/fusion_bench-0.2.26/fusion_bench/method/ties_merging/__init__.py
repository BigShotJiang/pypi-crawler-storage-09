# flake8: noqa F401
from .ties_merging import TiesMergingAlgorithm
