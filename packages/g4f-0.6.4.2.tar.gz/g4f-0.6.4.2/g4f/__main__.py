from g4f.cli import main

if __name__ == "__main__":
    main()