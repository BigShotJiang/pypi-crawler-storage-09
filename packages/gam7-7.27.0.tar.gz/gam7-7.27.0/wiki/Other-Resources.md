# Other Resources

The following are links to contributions of others in support of GAM7.

Thank you.

* Amado Tejada - https://github.com/amadotejada/GAMpass
* Brecht Sannen - https://gcloud.devoteam.com/blog/what-is-google-apps-manager-gam/
* Gabriel Clifton - https://docs.google.com/document/d/1p32QOBTr89GaG7RfCafSbFuhlUQ9r3qBM_666E0xvQM/edit
* Goldy Arora - https://www.goldyarora.com/license-notifier/
* Iain Macleod - https://docs.google.com/document/d/1QxWAPdhROcx70OXLpSD9Trh3vs-nJKSMiaMZCTwOOTg/edit?pli=1#heading=h.2a2azzpy36k0
* James Seymour - https://sites.google.com/view/gam--commands/
* Kevin Melillo - https://github.com/KevinMelilloIEEE/gam-script
* Korey Rideout - https://chatgpt.com/g/g-PTxxnVPMG-gam-assist-now-turbocharged-with-gam7
* Paul Ogier (Taming.Tech) - GAM7 Course on Udemy https://taming.tech/GAMCourse
* Paul Ogier (Taming.Tech) - GAM7 Tutorials https://www.youtube.com/watch?v=g9LDeyXQNLI&list=PL_dLiK09pJVhKJxZHNk9CHK0q5hkZ856w
* Paul Ogier (Taming.Tech) - https://taming.tech/taming-gam-a-practical-guide-to-gam-and-gamadv-xtd3/
* Steve Larsen - https://docs.google.com/spreadsheets/d/1MzzA-u-cmoQcJnQOovCnZcEKMjvOyFhfkdFdf10X_GI/edit
