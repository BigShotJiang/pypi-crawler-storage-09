"""Crazy Eights card game module."""

from __future__ import annotations

from .game import CrazyEightsGame

__all__ = ["CrazyEightsGame"]
