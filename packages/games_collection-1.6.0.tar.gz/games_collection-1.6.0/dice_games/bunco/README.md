# Bunco

Party dice game with rounds and team scoring

## Running

```bash
python -m dice_games.bunco
```

## Features

- Interactive CLI interface
- Based on common game engine architecture
- Follows repository patterns
