"""Craps casino dice game implementation.

Casino dice game with pass/don't pass betting and various side bets.
"""

from __future__ import annotations

__all__ = ["CrapsGame"]

from .craps import CrapsGame
