# Release Checklist Archive

This folder contains release-specific runbooks that supplement the main deployment guides.

- [`v1.2.1.md`](v1.2.1.md) – Checklist for the coordinated v1.2.1 release that aligned PyPI publishing with executable builds.

Add future release notes here to keep the repository root uncluttered while maintaining easy access to historical release context.
