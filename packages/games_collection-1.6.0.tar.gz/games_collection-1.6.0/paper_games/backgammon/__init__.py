"""Dice-based race game with bearing off game implementation."""

from __future__ import annotations

from .backgammon import BackgammonGame

__all__ = ["BackgammonGame"]
