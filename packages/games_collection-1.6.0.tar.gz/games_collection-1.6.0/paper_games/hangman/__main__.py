"""Main entry point for the Hangman game."""

from . import play

# This script allows the game to be run directly from the command line.
if __name__ == "__main__":
    play()
