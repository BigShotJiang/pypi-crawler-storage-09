"""Scripts package for Games Collection.

This package contains utility scripts including the main game launcher.
"""

from __future__ import annotations

__version__ = "1.6.0"
