# Anagrams

Word rearrangement game with scoring system

## Running

```bash
python -m word_games.anagrams
```
