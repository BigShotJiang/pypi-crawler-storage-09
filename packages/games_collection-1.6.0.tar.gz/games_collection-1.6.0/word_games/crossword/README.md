# Crossword

Create and solve crossword puzzles with clue system

## Running

```bash
python -m word_games.crossword
```
