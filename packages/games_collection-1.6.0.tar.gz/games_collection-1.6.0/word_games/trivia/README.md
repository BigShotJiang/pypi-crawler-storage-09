# Trivia Quiz

Multiple choice trivia questions from various categories

## Running

```bash
python -m word_games.trivia
```
