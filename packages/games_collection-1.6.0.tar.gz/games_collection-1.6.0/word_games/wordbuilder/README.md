# WordBuilder

Tile-based word building game

## Running

```bash
python -m word_games.wordbuilder
```
