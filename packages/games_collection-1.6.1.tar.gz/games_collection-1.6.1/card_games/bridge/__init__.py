"""Bridge card game package."""

from .game import BridgeGame, BridgePlayer

__all__ = ["BridgeGame", "BridgePlayer"]
