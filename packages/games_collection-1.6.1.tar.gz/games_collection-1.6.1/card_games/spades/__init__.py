"""Spades card game package."""

from .game import SpadesGame, SpadesPlayer

__all__ = ["SpadesGame", "SpadesPlayer"]
