# Craps

Casino dice game with pass/don't pass betting.

## Running

```bash
python -m dice_games.craps
```

## Rules

- Roll two dice
- Pass line wins on 7/11 on come-out, loses on 2/3/12
- Other rolls establish a point
- Must roll point again before 7 to win
