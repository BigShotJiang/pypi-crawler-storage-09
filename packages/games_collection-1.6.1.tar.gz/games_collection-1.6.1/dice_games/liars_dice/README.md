# Liar's Dice

Bluffing dice game where players bid on dice combinations

## Running

```bash
python -m dice_games.liars_dice
```

## Features

- Interactive CLI interface
- Based on common game engine architecture
- Follows repository patterns
