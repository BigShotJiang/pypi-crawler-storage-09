# Sliding Puzzle

Number tile sliding game (15-puzzle)

## Running

```bash
python -m logic_games.sliding_puzzle
```
