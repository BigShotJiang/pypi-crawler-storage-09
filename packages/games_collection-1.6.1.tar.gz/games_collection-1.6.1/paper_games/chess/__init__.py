"""Chess with all standard rules game implementation."""

from __future__ import annotations

from .chess import ChessGame

__all__ = ["ChessGame"]
