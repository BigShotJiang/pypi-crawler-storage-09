"""Main entry point for the Nim game."""

from . import play

# This script allows the game to be run directly from the command line.
if __name__ == "__main__":
    play()
