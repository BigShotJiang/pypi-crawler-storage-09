"""20 Questions game implementation."""

from __future__ import annotations

from .twenty_questions import TwentyQuestionsGame

__all__ = ["TwentyQuestionsGame"]
