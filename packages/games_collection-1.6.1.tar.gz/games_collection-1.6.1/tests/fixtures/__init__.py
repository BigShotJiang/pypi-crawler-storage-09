"""Test fixtures for common game scenarios."""

from .card_fixtures import *
from .game_fixtures import *
