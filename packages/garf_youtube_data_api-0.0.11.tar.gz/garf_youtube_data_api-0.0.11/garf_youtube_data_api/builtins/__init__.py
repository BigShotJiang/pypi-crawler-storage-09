from garf_youtube_data_api.builtins import channel_videos

BUILTIN_QUERIES = {
  'channelVideos': channel_videos.get_youtube_channel_videos,
}
