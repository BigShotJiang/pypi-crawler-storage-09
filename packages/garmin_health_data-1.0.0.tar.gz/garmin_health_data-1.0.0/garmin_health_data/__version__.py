"""
Version information for garmin-health-data.
"""

__version__ = "1.0.0"
