from .PausingIndex import main
main()

