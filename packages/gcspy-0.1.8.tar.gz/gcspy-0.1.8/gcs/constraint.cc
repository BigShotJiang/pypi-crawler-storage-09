#include "gcs/constraint.hh"

using namespace gcs;

Constraint::~Constraint() = default;
