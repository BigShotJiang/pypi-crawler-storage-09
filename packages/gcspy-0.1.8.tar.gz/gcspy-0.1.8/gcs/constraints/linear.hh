#ifndef GLASGOW_CONSTRAINT_SOLVER_GUARD_GCS_CONSTRAINTS_LINEAR_HH
#define GLASGOW_CONSTRAINT_SOLVER_GUARD_GCS_CONSTRAINTS_LINEAR_HH

#include <gcs/constraints/linear/linear_equality.hh>
#include <gcs/constraints/linear/linear_greater_equal.hh>
#include <gcs/constraints/linear/linear_less_equal.hh>

#endif
