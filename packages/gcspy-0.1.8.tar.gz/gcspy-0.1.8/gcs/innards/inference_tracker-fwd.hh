#ifndef GLASGOW_CONSTRAINT_SOLVER_GUARD_GCS_INNARDS_INFERENCE_TRACKER_FWD_HH
#define GLASGOW_CONSTRAINT_SOLVER_GUARD_GCS_INNARDS_INFERENCE_TRACKER_FWD_HH

namespace gcs::innards
{
    class SimpleInferenceTracker;
    class EagerProofLoggingInferenceTracker;
}

#endif
