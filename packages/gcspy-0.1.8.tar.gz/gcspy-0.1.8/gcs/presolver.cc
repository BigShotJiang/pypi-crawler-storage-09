#include <gcs/presolver.hh>

using namespace gcs;

Presolver::~Presolver() = default;
