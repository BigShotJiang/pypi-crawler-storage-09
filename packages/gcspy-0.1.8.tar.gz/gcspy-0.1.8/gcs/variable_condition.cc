#include <gcs/variable_condition.hh>

using namespace gcs;
