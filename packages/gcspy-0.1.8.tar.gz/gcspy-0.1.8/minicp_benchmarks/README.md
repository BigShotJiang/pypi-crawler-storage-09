See Laurent D. Michel, Pierre Schaus, Pascal Van Hentenryck: "MiniCP: a
lightweight solver for constraint programming". Math. Program. Comput. 13(1):
133-184 (2021).
