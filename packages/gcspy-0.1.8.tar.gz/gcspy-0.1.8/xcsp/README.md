XCSP Support
============

The contents of the ``XCSP3-CPP-Parser/`` directory is a ``git subtree`` of
``https://github.com/xcsp3team/XCSP3-CPP-Parser``, which is separately
licenced.

<!-- vim: set tw=100 spell spelllang=en : -->
