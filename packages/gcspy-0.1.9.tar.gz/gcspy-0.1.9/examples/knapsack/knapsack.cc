#include <gcs/constraints/knapsack.hh>
#include <gcs/constraints/linear.hh>
#include <gcs/problem.hh>
#include <gcs/search_heuristics.hh>
#include <gcs/solve.hh>

#include <cstdlib>
#include <iostream>
#include <optional>
#include <vector>

#include <cxxopts.hpp>

#include <fmt/core.h>
#include <fmt/ostream.h>
#include <fmt/ranges.h>

using namespace gcs;

using std::cerr;
using std::cout;
using std::cref;
using std::make_optional;
using std::nullopt;
using std::vector;

using fmt::print;
using fmt::println;


auto main(int argc, char * argv[]) -> int
{
    cxxopts::Options options("Knapsack Example");
    cxxopts::ParseResult options_vars;

    try {
        options.add_options("Program options")
            ("help", "Display help information")
            ("prove", "Create a proof");

        options_vars = options.parse(argc, argv);
    }
    catch (const cxxopts::exceptions::exception & e) {
        println(cerr, "Error: {}", e.what());
        println(cerr, "Try {} --help", argv[0]);
        return EXIT_FAILURE;
    }

    if (options_vars.contains("help")) {
        println("Usage: {} [options]", argv[0]);
        println("");
        cout << options.help() << std::endl;
        return EXIT_SUCCESS;
    }

    Problem p;
    auto items = p.create_integer_variable_vector(6, 0_i, 1_i, "item");
    auto profit = p.create_integer_variable(6_i, 10_i, "profit");
    auto weight = p.create_integer_variable(5_i, 7_i, "weight");

    vector<Integer> weights = {2_i, 5_i, 2_i, 3_i, 2_i, 3_i};
    vector<Integer> profits = {2_i, 4_i, 2_i, 5_i, 4_i, 3_i};

    auto oddity = p.create_integer_variable(0_i, 20_i, "oddity");
    p.post(LinearEquality{WeightedSum{} + 1_i * profit + -2_i * oddity, 1_i, true});

    p.post(WeightedSum{} + 1_i * items[5] == 0_i);

    p.post(Knapsack{weights, profits, items, weight, profit});

    p.maximise(profit);

    auto stats = solve_with(p,
        SolveCallbacks{
            .solution = [&](const CurrentState & s) -> bool {
                println("solution: {} profit {} weight {}", items | std::ranges::views::transform(cref(s)), s(profit), s(weight));
                return true;
            },
            .branch = branch_with(variable_order::dom_then_deg(items), value_order::smallest_first())},
        options_vars.contains("prove") ? make_optional<ProofOptions>("knapsack") : nullopt);

    print("{}", stats);

    return EXIT_SUCCESS;
}
