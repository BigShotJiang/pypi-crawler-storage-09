"""
Payment handlers.

Geek Cafe, LLC
MIT License. See Project Root for the license information.
"""
