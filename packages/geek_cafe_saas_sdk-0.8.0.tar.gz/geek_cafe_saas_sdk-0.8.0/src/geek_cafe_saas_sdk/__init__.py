"""
Geek Cafe Services - Base Reusable Services for SaaS

Version 0.6.0 adds File System Service
"""
__version__ = "0.8.0"

# Import main modules for easier access
from . import services
