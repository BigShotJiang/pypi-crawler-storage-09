"""Legacy import package for tools."""
from . import _deprecated_imagecollection as imagecollection  # noqa: F401
