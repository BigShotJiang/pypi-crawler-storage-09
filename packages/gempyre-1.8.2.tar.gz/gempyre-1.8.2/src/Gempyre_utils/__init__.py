import warnings
warnings.warn("The Gempyre_utils is deprecated. Same functions are found now in Gempyre!")