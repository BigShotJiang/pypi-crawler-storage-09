# This __init__.py exposes the main schema submodules for convenient import.

from .gen3_template import *
from .input_schema import *
