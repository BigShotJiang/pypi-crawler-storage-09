from genlm.backend.tokenization.vocab import decode_vocab

__all__ = ["decode_vocab"]
