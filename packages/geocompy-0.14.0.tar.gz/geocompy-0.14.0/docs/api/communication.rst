:icon: material/serial-port

Communication
=============

.. automodule:: geocompy.communication

    Definitions
    -----------
