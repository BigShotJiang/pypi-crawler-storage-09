:icon: material/arrow-right-bottom

Automation
==========

.. automodule:: geocompy.geo.aut
    :inherited-members:

    Definitions
    -----------
