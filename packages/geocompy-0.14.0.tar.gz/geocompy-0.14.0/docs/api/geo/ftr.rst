:icon: material/arrow-right-bottom

File Transfer
=============

.. automodule:: geocompy.geo.ftr
    :inherited-members:

    Definitions
    -----------
