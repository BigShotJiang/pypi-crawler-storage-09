:icon: material/code-brackets

Data
====

.. automodule:: geocompy.geo.gcdata

    Definitions
    -----------
