:icon: material/code-braces

Types
=====

.. automodule:: geocompy.geo.gctypes
    :exclude-members: rpcnames

    Definitions
    -----------

.. autodata:: rpcnames
    :no-value:
