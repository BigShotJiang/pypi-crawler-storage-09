:icon: protocol_geocom

GeoCOM
======

.. automodule:: geocompy.geo
    :inherited-members:

    Definitions
    -----------

.. toctree::
    :maxdepth: 1
    :hidden:

    gctypes
    gcdata
    aus
    aut
    bap
    bmm
    cam
    com
    csv
    ctl
    dna
    edm
    ftr
    img
    kdm
    mot
    sup
    tmc
    wir
