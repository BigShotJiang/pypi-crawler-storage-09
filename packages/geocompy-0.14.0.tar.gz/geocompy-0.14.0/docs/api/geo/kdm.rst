:icon: material/arrow-right-bottom

Keyboard and Display Management
===============================

.. automodule:: geocompy.geo.kdm
    :inherited-members:

    Definitions
    -----------
