:icon: material/arrow-right-bottom

Settings
========

.. automodule:: geocompy.gsi.dna.settings

    Definitions
    -----------
