:icon: material/file-code-outline

Format
======

.. automodule:: geocompy.gsi.gsiformat
    :inherited-members:

    Definitions
    -----------
