from .circle import Circle
from .triangle import Triangle
from .base import Figure

__all__ = ["Circle", "Triangle", "Figure"]