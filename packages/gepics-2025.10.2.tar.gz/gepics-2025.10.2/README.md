# gEPICS - Python GObject Wrapper for EPICS Process Variables

gEPICS enables GObject/Gtk applications to access EPICS control
systems through the Channel Access protocol (CA). The core EPICS 
functionality is provided through the pyepics (http://pyepics.github.io/pyepics/) package.


