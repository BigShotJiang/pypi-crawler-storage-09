__version__ = "1.5.1"

from get_chrome_driver.get_driver import GetChromeDriver
