CHROMEDRIVER_STORAGE_URL = "https://chromedriver.storage.googleapis.com"
LAST_KNOWN_GOOD_VERSIONS_WITH_DOWNLOADS_URL = "https://googlechromelabs.github.io/chrome-for-testing/last-known-good-versions-with-downloads.json"
LAST_KNOWN_GOOD_VERSIONS_URL = "https://googlechromelabs.github.io/chrome-for-testing/last-known-good-versions.json"
KNOWN_GOOD_VERSIONS_WITH_DOWNLOADS_URL = "https://googlechromelabs.github.io/chrome-for-testing/known-good-versions-with-downloads.json"
KNOWN_GOOD_VERSIONS_URL = (
    "https://googlechromelabs.github.io/chrome-for-testing/known-good-versions.json"
)
CSS_SELECTOR_VERSIONS = "ul.n8H08c:nth-child(5)"
LATEST_STABLE_VERSION_STR = "Latest stable release"
LATEST_BETA_VERSION_STR = "Latest beta release"
