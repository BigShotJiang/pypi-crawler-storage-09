from enum import Enum


class OsPlatform(Enum):
    win = "win"
    linux = "linux"
    mac = "mac"
