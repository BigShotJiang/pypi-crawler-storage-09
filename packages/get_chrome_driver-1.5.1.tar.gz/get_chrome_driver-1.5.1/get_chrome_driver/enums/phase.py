from enum import Enum


class Phase(Enum):
    stable = "stable"
    beta = "beta"
