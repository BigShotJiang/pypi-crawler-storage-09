# getpybs

Fetch [python-build-standalone](https://github.com/astral-sh/python-build-standalone) binaries easily.

`getpybs` is a command-line tool that simplifies downloading pre-built Python binaries from the python-build-standalone project. These are self-contained, portable Python distributions that work across different platforms without system dependencies.

## Installation

### Use directly with `uvx`

Downloads latest build and python version for your OS

```bash
uvx getpybs
```

### Install from PyPI

```bash
pip install getpybs
```


## Usage

Download the latest Python build for your current platform:

```bash
getpybs
```

Download a specific Python version:

```bash
getpybs --python-version 3.12
```

Download for a specific architecture:

```bash
getpybs --architecture x86_64-apple-darwin
```

Download a specific release version:

```bash
getpybs --build-version 20250920
```

## Options

```
getpybs [options]
```

- `--build-version VERSION`: Release version - either `latest` or a specific release tag like `20250920` (default: `latest`)
- `--python-version VERSION`: Python version to download (default: latest stable)
- `--architecture ARCH`: Target architecture (default: auto-detected)
- `--build-config CONFIG`: Build configuration (default: `pgo+lto`)
- `--content-type TYPE`: Content type (default: `install_only_stripped`)
- `--windows-variant VARIANT`: Windows variant (`shared` or `static`)
- `--dest PATH`: Download destination directory (default: current directory)
- `--list-options`: Show all available options

## Examples

Download the fastest Python build (PGO+LTO optimized):

```bash
getpybs --build-config pgo+lto
```

Download a specific release for Linux ARM64:

```bash
getpybs --build-version 20250920 --architecture aarch64-unknown-linux-gnu
```

Download with full build artifacts:

```bash
getpybs --content-type full
```

List all available options:

```bash
getpybs --list-options
```

## Available Options

### Architectures

- `aarch64-apple-darwin` - macOS ARM CPU (M1, M2, M3, etc.)
- `x86_64-apple-darwin` - macOS Intel CPU
- `x86_64-pc-windows-msvc` - Windows 64-bit Intel/AMD CPU
- `i686-pc-windows-msvc` - Windows 32-bit Intel/AMD CPU
- `x86_64-unknown-linux-gnu` - Linux 64-bit Intel/AMD CPU (baseline), linked with GNU libc
- `x86_64_v2-unknown-linux-gnu` - Linux 64-bit with SSE4.2/SSSE3 (recommended, widely compatible, ~2011+ CPUs)
- `x86_64_v3-unknown-linux-gnu` - Linux 64-bit with AVX2/FMA3 (faster, ~2013+ CPUs like Haswell)
- `x86_64_v4-unknown-linux-gnu` - Linux 64-bit with AVX-512 (fastest, high-end CPUs only)
- `x86_64-unknown-linux-musl` - Linux 64-bit Intel/AMD CPU, linked with musl libc
- `aarch64-unknown-linux-gnu` - Linux ARM64 CPUs (AWS Graviton, etc.)
- And more... (see `--list-options` for complete list)

### Build Configurations

- `pgo+lto` - Profile guided optimization + Link-time optimization (fastest, recommended)
- `pgo` - Profile guided optimization only
- `lto` - Link-time optimization only
- `noopt` - Normal optimization
- `debug` - Debug build
- `freethreaded` - Free-threaded (PEP 703) build without GIL

### Content Types

- `install_only_stripped` - Lightweight version with debug symbols removed (recommended)
- `install_only` - Only files needed for post-build installation
- `full` - All files and artifacts used in build (distributed as .tar.zst)

## Why python-build-standalone?

The python-build-standalone project provides self-contained Python distributions that:

- Work without system dependencies
- Are reproducible and portable
- Include optimized builds (PGO, LTO)
- Support multiple platforms and architectures
- Are perfect for CI/CD, containers, and deployment

## License

MIT License - see [LICENSE](LICENSE) file for details.

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## Links

- [PyPI Package](https://pypi.org/project/getpybs/)
- [GitHub Repository](https://github.com/mliezun/getpybs)
- [python-build-standalone Project](https://github.com/astral-sh/python-build-standalone)

