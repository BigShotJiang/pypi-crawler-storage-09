
from .extractor import GGUFExtractorApp
import tkinter

root = tkinter.Tk()
app = GGUFExtractorApp(root)
root.mainloop()