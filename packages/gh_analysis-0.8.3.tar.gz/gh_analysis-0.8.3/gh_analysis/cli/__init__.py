"""CLI package."""
