# 🧭 gibr Roadmap

This roadmap outlines upcoming features and priorities for the gibr CLI.

## ✅ Completed
- [x] Support for GitHub and Jira issue trackers
- [x] Configurable `.gibrconfig` file
- [x] `gibr init` interactive setup
- [x] `gibr alias` git command integration
- [x] `gibr issues` and `gibr create` commands
- [x] Continuous Integration (GitHub Actions + Codecov)
- [x] PyPI packaging and release automation

## 🚧 Planned
- [ ] Add GitLab issue tracker integration
- [ ] Support for Linear issue tracker
- [ ] Support for Monday.com issue tracker
- [ ] CI/CD (Github Actions for building/publishing to PyPI)

## 🔮 Future
- [ ] Add support for integration with git repo hosts (GitHub, GitLab, Bitbucket, etc.)
- [ ] `gibr pr` / `gibr mr` command to create pull/merge requests
- [ ] `gibr config` command to manage settings interactively
- [ ] Autocomplete (preview)
- [ ] Refactor to support plugin style integration with each third party tool

## 💡 Ideas (Open for Discussion)
- [ ] Support dry run flag
- [ ] Support a no push to origin flag
- [ ] Community-contributed tracker plugins
- [ ] Allow multiple issue trackers for the same project
