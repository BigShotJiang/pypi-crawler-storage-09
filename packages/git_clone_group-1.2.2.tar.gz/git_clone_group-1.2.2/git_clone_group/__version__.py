VERSION = (1, 2, 2)

__version__ = ".".join(map(str, VERSION))
