# Pyarmor 9.1.9 (trial), 000000, 2025-10-16T19:44:18.162692
from .pyarmor_runtime import __pyarmor__
