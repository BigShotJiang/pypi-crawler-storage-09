"""Lightweight CLI utilities for git hotspot analysis."""

__all__ = [
    "__version__",
]

__version__ = "0.6.0"
