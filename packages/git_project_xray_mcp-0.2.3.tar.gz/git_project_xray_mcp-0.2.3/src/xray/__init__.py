"""XRAY: Fast code intelligence for AI assistants."""

__version__ = "0.1.0"