"""
Python wrapper package for the gitfluff commit message linter.
"""

__all__ = ["__version__"]
__version__ = "0.1.1"
