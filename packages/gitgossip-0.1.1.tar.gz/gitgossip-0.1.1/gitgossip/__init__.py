"""CLI entrypoint for GitGossip — initializes commands and handles user input."""
