"""GitGossip Configuration module."""
