"""Core logic for parsing Git repositories and extracting commit metadata."""
