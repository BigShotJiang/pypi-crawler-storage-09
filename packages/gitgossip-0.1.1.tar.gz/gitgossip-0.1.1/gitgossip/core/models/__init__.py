"""Data models for GitGossip entities (Commit, etc.)."""
