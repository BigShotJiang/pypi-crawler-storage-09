# GitHub Release Download Counter

Este script de Python te permite obtener el número total de descargas de todos los assets de los lanzamientos de un repositorio de GitHub.

## Características

- Obtiene el conteo de descargas por lanzamiento y por asset.
- Muestra el total de descargas de todos los lanzamientos.
- Manejo básico de errores para problemas de conexión o respuestas inesperadas de la API.

## Requisitos

- Python 3.x
- La librería `requests`

## Instalación

Puedes instalar este paquete directamente desde PyPI o desde el código fuente.

### Desde PyPI

```bash
pip install github-release-counter
```

### Desde el código fuente

1.  Clona este repositorio:
    ```bash
    git clone https://github.com/marcomolinaleija/github-release-counter.git
    cd github-release-counter
    ```
2.  Instala el paquete en modo editable (para desarrollo) o normal:
    ```bash
    pip install .
    ```

## Uso

Después de la instalación, puedes ejecutar el comando `github-release-counter` (o su alias `grc`) directamente en tu terminal.

### Argumentos

-   `<propietario/repositorio>` (obligatorio): La ruta del repositorio de GitHub en formato `propietario/repositorio`.
-   `--token` o `-t` (opcional): Tu Token de Acceso Personal (PAT) de GitHub para aumentar el límite de la API.
-   `--tags-only` (opcional): Muestra solo los nombres de los tags de los lanzamientos.
-   `--assets-only` (opcional): Muestra solo los assets de cada lanzamiento y su contador de descargas.

### Ejemplos

Para obtener las estadísticas completas de un repositorio:

```bash
grc marcomolinaleija/github-release-counter
```

Para obtener solo los tags:

```bash
grc marcomolinaleija/github-release-counter --tags-only
```

Para obtener solo la información de los assets:

```bash
grc marcomolinaleija/github-release-counter --assets-only
```

Para usar un token de GitHub:

```bash
grc marcomolinaleija/github-release-counter --token TU_GITHUB_TOKEN
```

### Obtener un Token Personal de Acceso (PAT) de GitHub

1.  Ve a [GitHub Settings](https://github.com/settings/tokens).
2.  Haz clic en "Generate new token" (o "Generate new token (classic)").
3.  Dale un nombre descriptivo (ej. "Release Counter Token").
4.  Selecciona los permisos necesarios. Para este script, no se necesitan permisos específicos, ya que solo lee información pública. Puedes dejarlo sin seleccionar ningún scope.
5.  Haz clic en "Generate token" y copia el token generado. ¡Guárdalo en un lugar seguro, ya que solo se muestra una vez!

## Uso como Librería

Con la nueva estructura modular, puedes importar la clase `GitHubAPI` para integrar fácilmente la obtención de datos de lanzamientos en tus propios scripts.

```python
from github_release_counter.github_api import GitHubAPI, RepoFormatError, GitHubAPIError
import os

# Repositorio de ejemplo
REPO = "marcomolinaleija/github-release-counter"
TOKEN = os.getenv("GITHUB_TOKEN") # Opcional, para aumentar el límite de la API

try:
    # 1. Crear una instancia de la API
    print(f"Creando instancia para {REPO}...")
    api = GitHubAPI(repo_path=REPO, github_token=TOKEN)

    # 2. Obtener los datos de los lanzamientos
    print("Obteniendo lanzamientos...")
    releases = api.get_releases()

    if releases:
        print(f"\nSe encontraron {len(releases)} lanzamientos para {api.owner}/{api.repo}.")
        
        total_downloads = 0
        for release in releases:
            total_downloads += release['total_release_downloads']
            print(f"- Tag: {release['tag_name']}, Descargas del lanzamiento: {release['total_release_downloads']}")

        print(f"\nDescargas totales de todos los lanzamientos: {total_downloads}")
    else:
        print(f"No se encontraron lanzamientos para {REPO}.")

except (RepoFormatError, GitHubAPIError) as e:
    print(f"Ocurrió un error: {e}")
except Exception as e:
    print(f"Ocurrió un error inesperado: {e}")
```

## Contribuciones

¡Las contribuciones son bienvenidas! Si encuentras un error o tienes una sugerencia de mejora, por favor abre un "issue" o envía un "pull request".

## Licencia

Este proyecto está bajo la licencia MIT. Consulta el archivo `LICENSE` para más detalles.