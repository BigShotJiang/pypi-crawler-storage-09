#!/usr/bin/python
# coding: utf-8

from gitlab_api.gitlab_api_mcp import gitlab_api_mcp

if __name__ == "__main__":
    gitlab_api_mcp()
