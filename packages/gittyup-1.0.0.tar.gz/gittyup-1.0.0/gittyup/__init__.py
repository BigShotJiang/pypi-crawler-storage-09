"""Gitty Up - Automatically discover and update all git repositories in a directory tree."""

__version__ = "1.0.0"
