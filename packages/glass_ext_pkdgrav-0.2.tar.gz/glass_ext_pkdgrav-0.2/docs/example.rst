
Example page
============

This is an example documentation page for the extension template.  A real
extension may or may not have multiple documentation pages.
