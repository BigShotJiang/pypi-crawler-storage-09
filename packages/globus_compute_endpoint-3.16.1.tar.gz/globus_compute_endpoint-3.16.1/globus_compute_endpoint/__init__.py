from globus_compute_endpoint.version import __version__ as _version

__author__ = "The Globus Compute Team"
__version__ = _version
