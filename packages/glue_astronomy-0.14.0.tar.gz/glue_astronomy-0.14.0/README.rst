Astronomy plugins for glue
--------------------------

.. image:: https://readthedocs.org/projects/glue-astronomy/badge/?version=latest
   :target: https://glue-astronomy.readthedocs.io/en/latest/?badge=latest
   :alt: Documentation Status

.. image:: https://github.com/glue-viz/glue-astronomy/actions/workflows/main.yml/badge.svg
   :target: https://github.com/glue-viz/glue-astronomy/actions/workflows/main.yml
   :alt: CI Status

.. image:: https://codecov.io/gh/glue-viz/glue-astronomy/branch/main/graph/badge.svg
   :target: https://codecov.io/gh/glue-viz/glue-astronomy
   :alt: Coverage Status

.. image:: https://img.shields.io/pypi/v/glue-astronomy.svg
   :target: https://pypi.org/project/glue-astronomy
   :alt: PyPI Status

The glue-astronomy plugin for glue provides a collection of astronomy-specific
functionality. It is currently under heavy development.
The documentation for this plugin can be found at
https://glue-astronomy.readthedocs.io.
