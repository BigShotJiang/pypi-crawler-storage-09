How to release a new version of Glue-Astronomy
==============================================

#. Follow the instructions in the `Glue documentation
   <http://docs.glueviz.org/en/stable/developer_guide/release.html>`_
   to create a release using the `GitHub menu
   <https://github.com/glue-viz/glue-astronomy/releases/new>`_.

#. Have a beverage of your choosing while you can check the build progress
   `here <https://github.com/glue-viz/glue-astronomy/actions/>`_.
   (The wheels may take a little while to build).
