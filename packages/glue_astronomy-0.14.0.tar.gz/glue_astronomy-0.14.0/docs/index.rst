glue-astronomy documentation
============================

The **glue-astronomy** plugin for `glue <http://glueviz.org>`_ provides
a collection of astronomy-specific functionality. It is currently under
heavy development and is not ready for general use at this point.

User guide
----------

.. toctree::
   :maxdepth: 1

   translators.rst
   data_loaders.rst
