from .version import version as __version__  # noqa


def setup():
    from glue_astronomy import translators  # noqa
