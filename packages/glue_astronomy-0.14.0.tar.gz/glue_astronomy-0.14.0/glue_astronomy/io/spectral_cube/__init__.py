def setup():
    from .spectral_cube import read_spectral_cube, parse_spectral_cube  # noqa
