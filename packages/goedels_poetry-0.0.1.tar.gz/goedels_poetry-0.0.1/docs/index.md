# goedels-poetry

[![Release](https://img.shields.io/github/v/release/KellyJDavis/goedels-poetry)](https://img.shields.io/github/v/release/KellyJDavis/goedels-poetry)
[![Build status](https://img.shields.io/github/actions/workflow/status/KellyJDavis/goedels-poetry/main.yml?branch=main)](https://github.com/KellyJDavis/goedels-poetry/actions/workflows/main.yml?query=branch%3Amain)
[![Commit activity](https://img.shields.io/github/commit-activity/m/KellyJDavis/goedels-poetry)](https://img.shields.io/github/commit-activity/m/KellyJDavis/goedels-poetry)
[![License](https://img.shields.io/github/license/KellyJDavis/goedels-poetry)](https://img.shields.io/github/license/KellyJDavis/goedels-poetry)

A recursive, reflective POETRY algorithm variant using Goedel-Prover-V2
