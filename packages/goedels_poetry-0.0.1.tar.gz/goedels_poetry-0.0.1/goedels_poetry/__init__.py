"""Gödel's Poetry - A recursive, reflective POETRY algorithm variant using Goedel-Prover-V2."""

__version__ = "0.0.1"
