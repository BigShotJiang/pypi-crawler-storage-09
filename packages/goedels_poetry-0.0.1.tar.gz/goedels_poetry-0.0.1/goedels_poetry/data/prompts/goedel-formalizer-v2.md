Please autoformalize the following natural language problem statement in Lean 4. Use the following theorem name: {{ formal_statement_name }}

The natural language statement is:

{{ informal_statement }}

Think before you provide the lean statement.
