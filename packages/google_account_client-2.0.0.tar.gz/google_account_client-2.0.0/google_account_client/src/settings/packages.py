class Packages:
    SCOPES = ['https://www.googleapis.com/auth/calendar']