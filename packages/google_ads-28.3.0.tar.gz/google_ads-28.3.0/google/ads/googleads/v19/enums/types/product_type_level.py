# -*- coding: utf-8 -*-
# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
from __future__ import annotations


import proto  # type: ignore


__protobuf__ = proto.module(
    package="google.ads.googleads.v19.enums",
    marshal="google.ads.googleads.v19",
    manifest={
        "ProductTypeLevelEnum",
    },
)


class ProductTypeLevelEnum(proto.Message):
    r"""Level of the type of a product offer."""

    class ProductTypeLevel(proto.Enum):
        r"""Enum describing the level of the type of a product offer.

        Values:
            UNSPECIFIED (0):
                Not specified.
            UNKNOWN (1):
                Used for return value only. Represents value
                unknown in this version.
            LEVEL1 (7):
                Level 1.
            LEVEL2 (8):
                Level 2.
            LEVEL3 (9):
                Level 3.
            LEVEL4 (10):
                Level 4.
            LEVEL5 (11):
                Level 5.
        """

        UNSPECIFIED = 0
        UNKNOWN = 1
        LEVEL1 = 7
        LEVEL2 = 8
        LEVEL3 = 9
        LEVEL4 = 10
        LEVEL5 = 11


__all__ = tuple(sorted(__protobuf__.manifest))
