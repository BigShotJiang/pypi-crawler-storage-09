"""API for interacting with the diagnostics library."""

from . import metrics
from . import mlrun


machinelearning_run = mlrun.machinelearning_run
