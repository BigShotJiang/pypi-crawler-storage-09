"""Core componments for interacting with the diagnostics library."""

from . import xprof
