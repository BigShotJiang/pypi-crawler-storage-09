"""Tests for governor."""
