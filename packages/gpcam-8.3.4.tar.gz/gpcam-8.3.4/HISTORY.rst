=======
History
=======

6.0.0 (2020-10-26)
------------------

* First release on PyPI.
