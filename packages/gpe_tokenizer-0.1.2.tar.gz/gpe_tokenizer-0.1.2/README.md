## Tokenizer Training Details
#### Corpus Size: 5 Million Sentences
#### Vocab Size: 16000
#### Training Time: 2H 43M