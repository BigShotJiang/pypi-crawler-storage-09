# LLM package: logic and adapters that are UI-agnostic.
