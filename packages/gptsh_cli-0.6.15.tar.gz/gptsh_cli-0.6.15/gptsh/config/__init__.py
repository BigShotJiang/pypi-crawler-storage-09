# Config package for gptsh
