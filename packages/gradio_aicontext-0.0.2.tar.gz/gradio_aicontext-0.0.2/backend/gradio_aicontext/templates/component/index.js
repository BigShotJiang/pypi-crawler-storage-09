var Gi = Object.defineProperty;
var mn = (r) => {
  throw TypeError(r);
};
var ji = (r, e, t) => e in r ? Gi(r, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : r[e] = t;
var O = (r, e, t) => ji(r, typeof e != "symbol" ? e + "" : e, t), Zi = (r, e, t) => e.has(r) || mn("Cannot " + t);
var gn = (r, e, t) => e.has(r) ? mn("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(r) : e.set(r, t);
var ct = (r, e, t) => (Zi(r, e, "access private method"), t);
const {
  SvelteComponent: Vi,
  append_hydration: Mt,
  assign: Yi,
  attr: G,
  binding_callbacks: Xi,
  children: We,
  claim_element: di,
  claim_space: pi,
  claim_svg_element: xt,
  create_slot: Wi,
  detach: $e,
  element: hi,
  empty: bn,
  get_all_dirty_from_scope: Ki,
  get_slot_changes: Qi,
  get_spread_update: Ji,
  init: ea,
  insert_hydration: lt,
  listen: ta,
  noop: na,
  safe_not_equal: ia,
  set_dynamic_element_data: vn,
  set_style: B,
  space: fi,
  svg_element: Bt,
  toggle_class: M,
  transition_in: mi,
  transition_out: gi,
  update_slot_base: aa
} = window.__gradio__svelte__internal;
function Dn(r) {
  let e, t, n, i, l;
  return {
    c() {
      e = Bt("svg"), t = Bt("line"), n = Bt("line"), this.h();
    },
    l(a) {
      e = xt(a, "svg", { class: !0, xmlns: !0, viewBox: !0 });
      var o = We(e);
      t = xt(o, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), We(t).forEach($e), n = xt(o, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), We(n).forEach($e), o.forEach($e), this.h();
    },
    h() {
      G(t, "x1", "1"), G(t, "y1", "9"), G(t, "x2", "9"), G(t, "y2", "1"), G(t, "stroke", "gray"), G(t, "stroke-width", "0.5"), G(n, "x1", "5"), G(n, "y1", "9"), G(n, "x2", "9"), G(n, "y2", "5"), G(n, "stroke", "gray"), G(n, "stroke-width", "0.5"), G(e, "class", "resize-handle svelte-239wnu"), G(e, "xmlns", "http://www.w3.org/2000/svg"), G(e, "viewBox", "0 0 10 10");
    },
    m(a, o) {
      lt(a, e, o), Mt(e, t), Mt(e, n), i || (l = ta(
        e,
        "mousedown",
        /*resize*/
        r[27]
      ), i = !0);
    },
    p: na,
    d(a) {
      a && $e(e), i = !1, l();
    }
  };
}
function ra(r) {
  var p;
  let e, t, n, i, l;
  const a = (
    /*#slots*/
    r[31].default
  ), o = Wi(
    a,
    r,
    /*$$scope*/
    r[30],
    null
  );
  let s = (
    /*resizable*/
    r[19] && Dn(r)
  ), _ = [
    { "data-testid": (
      /*test_id*/
      r[11]
    ) },
    { id: (
      /*elem_id*/
      r[6]
    ) },
    {
      class: n = "block " + /*elem_classes*/
      (((p = r[7]) == null ? void 0 : p.join(" ")) || "") + " svelte-239wnu"
    },
    {
      dir: i = /*rtl*/
      r[20] ? "rtl" : "ltr"
    }
  ], c = {};
  for (let d = 0; d < _.length; d += 1)
    c = Yi(c, _[d]);
  return {
    c() {
      e = hi(
        /*tag*/
        r[25]
      ), o && o.c(), t = fi(), s && s.c(), this.h();
    },
    l(d) {
      e = di(
        d,
        /*tag*/
        (r[25] || "null").toUpperCase(),
        {
          "data-testid": !0,
          id: !0,
          class: !0,
          dir: !0
        }
      );
      var m = We(e);
      o && o.l(m), t = pi(m), s && s.l(m), m.forEach($e), this.h();
    },
    h() {
      vn(
        /*tag*/
        r[25]
      )(e, c), M(
        e,
        "hidden",
        /*visible*/
        r[14] === !1 || /*visible*/
        r[14] === "hidden"
      ), M(
        e,
        "padded",
        /*padding*/
        r[10]
      ), M(
        e,
        "flex",
        /*flex*/
        r[1]
      ), M(
        e,
        "border_focus",
        /*border_mode*/
        r[9] === "focus"
      ), M(
        e,
        "border_contrast",
        /*border_mode*/
        r[9] === "contrast"
      ), M(e, "hide-container", !/*explicit_call*/
      r[12] && !/*container*/
      r[13]), M(
        e,
        "fullscreen",
        /*fullscreen*/
        r[0]
      ), M(
        e,
        "animating",
        /*fullscreen*/
        r[0] && /*preexpansionBoundingRect*/
        r[24] !== null
      ), M(
        e,
        "auto-margin",
        /*scale*/
        r[17] === null
      ), B(
        e,
        "height",
        /*fullscreen*/
        r[0] ? void 0 : (
          /*get_dimension*/
          r[26](
            /*height*/
            r[2]
          )
        )
      ), B(
        e,
        "min-height",
        /*fullscreen*/
        r[0] ? void 0 : (
          /*get_dimension*/
          r[26](
            /*min_height*/
            r[3]
          )
        )
      ), B(
        e,
        "max-height",
        /*fullscreen*/
        r[0] ? void 0 : (
          /*get_dimension*/
          r[26](
            /*max_height*/
            r[4]
          )
        )
      ), B(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        r[24] ? `${/*preexpansionBoundingRect*/
        r[24].top}px` : "0px"
      ), B(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        r[24] ? `${/*preexpansionBoundingRect*/
        r[24].left}px` : "0px"
      ), B(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        r[24] ? `${/*preexpansionBoundingRect*/
        r[24].width}px` : "0px"
      ), B(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        r[24] ? `${/*preexpansionBoundingRect*/
        r[24].height}px` : "0px"
      ), B(
        e,
        "width",
        /*fullscreen*/
        r[0] ? void 0 : typeof /*width*/
        r[5] == "number" ? `calc(min(${/*width*/
        r[5]}px, 100%))` : (
          /*get_dimension*/
          r[26](
            /*width*/
            r[5]
          )
        )
      ), B(
        e,
        "border-style",
        /*variant*/
        r[8]
      ), B(
        e,
        "overflow",
        /*allow_overflow*/
        r[15] ? (
          /*overflow_behavior*/
          r[16]
        ) : "hidden"
      ), B(
        e,
        "flex-grow",
        /*scale*/
        r[17]
      ), B(e, "min-width", `calc(min(${/*min_width*/
      r[18]}px, 100%))`), B(e, "border-width", "var(--block-border-width)");
    },
    m(d, m) {
      lt(d, e, m), o && o.m(e, null), Mt(e, t), s && s.m(e, null), r[32](e), l = !0;
    },
    p(d, m) {
      var g;
      o && o.p && (!l || m[0] & /*$$scope*/
      1073741824) && aa(
        o,
        a,
        d,
        /*$$scope*/
        d[30],
        l ? Qi(
          a,
          /*$$scope*/
          d[30],
          m,
          null
        ) : Ki(
          /*$$scope*/
          d[30]
        ),
        null
      ), /*resizable*/
      d[19] ? s ? s.p(d, m) : (s = Dn(d), s.c(), s.m(e, null)) : s && (s.d(1), s = null), vn(
        /*tag*/
        d[25]
      )(e, c = Ji(_, [
        (!l || m[0] & /*test_id*/
        2048) && { "data-testid": (
          /*test_id*/
          d[11]
        ) },
        (!l || m[0] & /*elem_id*/
        64) && { id: (
          /*elem_id*/
          d[6]
        ) },
        (!l || m[0] & /*elem_classes*/
        128 && n !== (n = "block " + /*elem_classes*/
        (((g = d[7]) == null ? void 0 : g.join(" ")) || "") + " svelte-239wnu")) && { class: n },
        (!l || m[0] & /*rtl*/
        1048576 && i !== (i = /*rtl*/
        d[20] ? "rtl" : "ltr")) && { dir: i }
      ])), M(
        e,
        "hidden",
        /*visible*/
        d[14] === !1 || /*visible*/
        d[14] === "hidden"
      ), M(
        e,
        "padded",
        /*padding*/
        d[10]
      ), M(
        e,
        "flex",
        /*flex*/
        d[1]
      ), M(
        e,
        "border_focus",
        /*border_mode*/
        d[9] === "focus"
      ), M(
        e,
        "border_contrast",
        /*border_mode*/
        d[9] === "contrast"
      ), M(e, "hide-container", !/*explicit_call*/
      d[12] && !/*container*/
      d[13]), M(
        e,
        "fullscreen",
        /*fullscreen*/
        d[0]
      ), M(
        e,
        "animating",
        /*fullscreen*/
        d[0] && /*preexpansionBoundingRect*/
        d[24] !== null
      ), M(
        e,
        "auto-margin",
        /*scale*/
        d[17] === null
      ), m[0] & /*fullscreen, height*/
      5 && B(
        e,
        "height",
        /*fullscreen*/
        d[0] ? void 0 : (
          /*get_dimension*/
          d[26](
            /*height*/
            d[2]
          )
        )
      ), m[0] & /*fullscreen, min_height*/
      9 && B(
        e,
        "min-height",
        /*fullscreen*/
        d[0] ? void 0 : (
          /*get_dimension*/
          d[26](
            /*min_height*/
            d[3]
          )
        )
      ), m[0] & /*fullscreen, max_height*/
      17 && B(
        e,
        "max-height",
        /*fullscreen*/
        d[0] ? void 0 : (
          /*get_dimension*/
          d[26](
            /*max_height*/
            d[4]
          )
        )
      ), m[0] & /*preexpansionBoundingRect*/
      16777216 && B(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].top}px` : "0px"
      ), m[0] & /*preexpansionBoundingRect*/
      16777216 && B(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].left}px` : "0px"
      ), m[0] & /*preexpansionBoundingRect*/
      16777216 && B(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].width}px` : "0px"
      ), m[0] & /*preexpansionBoundingRect*/
      16777216 && B(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].height}px` : "0px"
      ), m[0] & /*fullscreen, width*/
      33 && B(
        e,
        "width",
        /*fullscreen*/
        d[0] ? void 0 : typeof /*width*/
        d[5] == "number" ? `calc(min(${/*width*/
        d[5]}px, 100%))` : (
          /*get_dimension*/
          d[26](
            /*width*/
            d[5]
          )
        )
      ), m[0] & /*variant*/
      256 && B(
        e,
        "border-style",
        /*variant*/
        d[8]
      ), m[0] & /*allow_overflow, overflow_behavior*/
      98304 && B(
        e,
        "overflow",
        /*allow_overflow*/
        d[15] ? (
          /*overflow_behavior*/
          d[16]
        ) : "hidden"
      ), m[0] & /*scale*/
      131072 && B(
        e,
        "flex-grow",
        /*scale*/
        d[17]
      ), m[0] & /*min_width*/
      262144 && B(e, "min-width", `calc(min(${/*min_width*/
      d[18]}px, 100%))`);
    },
    i(d) {
      l || (mi(o, d), l = !0);
    },
    o(d) {
      gi(o, d), l = !1;
    },
    d(d) {
      d && $e(e), o && o.d(d), s && s.d(), r[32](null);
    }
  };
}
function yn(r) {
  let e;
  return {
    c() {
      e = hi("div"), this.h();
    },
    l(t) {
      e = di(t, "DIV", { class: !0 }), We(e).forEach($e), this.h();
    },
    h() {
      G(e, "class", "placeholder svelte-239wnu"), B(
        e,
        "height",
        /*placeholder_height*/
        r[22] + "px"
      ), B(
        e,
        "width",
        /*placeholder_width*/
        r[23] + "px"
      );
    },
    m(t, n) {
      lt(t, e, n);
    },
    p(t, n) {
      n[0] & /*placeholder_height*/
      4194304 && B(
        e,
        "height",
        /*placeholder_height*/
        t[22] + "px"
      ), n[0] & /*placeholder_width*/
      8388608 && B(
        e,
        "width",
        /*placeholder_width*/
        t[23] + "px"
      );
    },
    d(t) {
      t && $e(e);
    }
  };
}
function la(r) {
  let e, t, n, i = (
    /*tag*/
    r[25] && ra(r)
  ), l = (
    /*fullscreen*/
    r[0] && yn(r)
  );
  return {
    c() {
      i && i.c(), e = fi(), l && l.c(), t = bn();
    },
    l(a) {
      i && i.l(a), e = pi(a), l && l.l(a), t = bn();
    },
    m(a, o) {
      i && i.m(a, o), lt(a, e, o), l && l.m(a, o), lt(a, t, o), n = !0;
    },
    p(a, o) {
      /*tag*/
      a[25] && i.p(a, o), /*fullscreen*/
      a[0] ? l ? l.p(a, o) : (l = yn(a), l.c(), l.m(t.parentNode, t)) : l && (l.d(1), l = null);
    },
    i(a) {
      n || (mi(i, a), n = !0);
    },
    o(a) {
      gi(i, a), n = !1;
    },
    d(a) {
      a && ($e(e), $e(t)), i && i.d(a), l && l.d(a);
    }
  };
}
function oa(r, e, t) {
  let { $$slots: n = {}, $$scope: i } = e, { height: l = void 0 } = e, { min_height: a = void 0 } = e, { max_height: o = void 0 } = e, { width: s = void 0 } = e, { elem_id: _ = "" } = e, { elem_classes: c = [] } = e, { variant: p = "solid" } = e, { border_mode: d = "base" } = e, { padding: m = !0 } = e, { type: g = "normal" } = e, { test_id: v = void 0 } = e, { explicit_call: b = !1 } = e, { container: F = !0 } = e, { visible: h = !0 } = e, { allow_overflow: u = !0 } = e, { overflow_behavior: f = "auto" } = e, { scale: D = null } = e, { min_width: y = 0 } = e, { flex: $ = !1 } = e, { resizable: S = !1 } = e, { rtl: E = !1 } = e, { fullscreen: T = !1 } = e, N = T, L, ue = g === "fieldset" ? "fieldset" : "div", te = 0, Re = 0, X = null;
  function ce(w) {
    T && w.key === "Escape" && t(0, T = !1);
  }
  const q = (w) => {
    if (w !== void 0) {
      if (typeof w == "number")
        return w + "px";
      if (typeof w == "string")
        return w;
    }
  }, j = (w) => {
    let U = w.clientY;
    const Ee = (ve) => {
      const Ae = ve.clientY - U;
      U = ve.clientY, t(21, L.style.height = `${L.offsetHeight + Ae}px`, L);
    }, W = () => {
      window.removeEventListener("mousemove", Ee), window.removeEventListener("mouseup", W);
    };
    window.addEventListener("mousemove", Ee), window.addEventListener("mouseup", W);
  };
  function be(w) {
    Xi[w ? "unshift" : "push"](() => {
      L = w, t(21, L);
    });
  }
  return r.$$set = (w) => {
    "height" in w && t(2, l = w.height), "min_height" in w && t(3, a = w.min_height), "max_height" in w && t(4, o = w.max_height), "width" in w && t(5, s = w.width), "elem_id" in w && t(6, _ = w.elem_id), "elem_classes" in w && t(7, c = w.elem_classes), "variant" in w && t(8, p = w.variant), "border_mode" in w && t(9, d = w.border_mode), "padding" in w && t(10, m = w.padding), "type" in w && t(28, g = w.type), "test_id" in w && t(11, v = w.test_id), "explicit_call" in w && t(12, b = w.explicit_call), "container" in w && t(13, F = w.container), "visible" in w && t(14, h = w.visible), "allow_overflow" in w && t(15, u = w.allow_overflow), "overflow_behavior" in w && t(16, f = w.overflow_behavior), "scale" in w && t(17, D = w.scale), "min_width" in w && t(18, y = w.min_width), "flex" in w && t(1, $ = w.flex), "resizable" in w && t(19, S = w.resizable), "rtl" in w && t(20, E = w.rtl), "fullscreen" in w && t(0, T = w.fullscreen), "$$scope" in w && t(30, i = w.$$scope);
  }, r.$$.update = () => {
    r.$$.dirty[0] & /*fullscreen, old_fullscreen, element*/
    538968065 && T !== N && (t(29, N = T), T ? (t(24, X = L.getBoundingClientRect()), t(22, te = L.offsetHeight), t(23, Re = L.offsetWidth), window.addEventListener("keydown", ce)) : (t(24, X = null), window.removeEventListener("keydown", ce))), r.$$.dirty[0] & /*visible*/
    16384 && (h || t(1, $ = !1));
  }, [
    T,
    $,
    l,
    a,
    o,
    s,
    _,
    c,
    p,
    d,
    m,
    v,
    b,
    F,
    h,
    u,
    f,
    D,
    y,
    S,
    E,
    L,
    te,
    Re,
    X,
    ue,
    q,
    j,
    g,
    N,
    i,
    n,
    be
  ];
}
class sa extends Vi {
  constructor(e) {
    super(), ea(
      this,
      e,
      oa,
      la,
      ia,
      {
        height: 2,
        min_height: 3,
        max_height: 4,
        width: 5,
        elem_id: 6,
        elem_classes: 7,
        variant: 8,
        border_mode: 9,
        padding: 10,
        type: 28,
        test_id: 11,
        explicit_call: 12,
        container: 13,
        visible: 14,
        allow_overflow: 15,
        overflow_behavior: 16,
        scale: 17,
        min_width: 18,
        flex: 1,
        resizable: 19,
        rtl: 20,
        fullscreen: 0
      },
      null,
      [-1, -1]
    );
  }
}
function Kt() {
  return {
    async: !1,
    breaks: !1,
    extensions: null,
    gfm: !0,
    hooks: null,
    pedantic: !1,
    renderer: null,
    silent: !1,
    tokenizer: null,
    walkTokens: null
  };
}
let Pe = Kt();
function bi(r) {
  Pe = r;
}
const vi = /[&<>"']/, ua = new RegExp(vi.source, "g"), Di = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, ca = new RegExp(Di.source, "g"), _a = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, $n = (r) => _a[r];
function Q(r, e) {
  if (e) {
    if (vi.test(r))
      return r.replace(ua, $n);
  } else if (Di.test(r))
    return r.replace(ca, $n);
  return r;
}
const da = /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig;
function pa(r) {
  return r.replace(da, (e, t) => (t = t.toLowerCase(), t === "colon" ? ":" : t.charAt(0) === "#" ? t.charAt(1) === "x" ? String.fromCharCode(parseInt(t.substring(2), 16)) : String.fromCharCode(+t.substring(1)) : ""));
}
const ha = /(^|[^\[])\^/g;
function R(r, e) {
  let t = typeof r == "string" ? r : r.source;
  e = e || "";
  const n = {
    replace: (i, l) => {
      let a = typeof l == "string" ? l : l.source;
      return a = a.replace(ha, "$1"), t = t.replace(i, a), n;
    },
    getRegex: () => new RegExp(t, e)
  };
  return n;
}
function wn(r) {
  try {
    r = encodeURI(r).replace(/%25/g, "%");
  } catch {
    return null;
  }
  return r;
}
const Ke = { exec: () => null };
function Fn(r, e) {
  const t = r.replace(/\|/g, (l, a, o) => {
    let s = !1, _ = a;
    for (; --_ >= 0 && o[_] === "\\"; )
      s = !s;
    return s ? "|" : " |";
  }), n = t.split(/ \|/);
  let i = 0;
  if (n[0].trim() || n.shift(), n.length > 0 && !n[n.length - 1].trim() && n.pop(), e)
    if (n.length > e)
      n.splice(e);
    else
      for (; n.length < e; )
        n.push("");
  for (; i < n.length; i++)
    n[i] = n[i].trim().replace(/\\\|/g, "|");
  return n;
}
function _t(r, e, t) {
  const n = r.length;
  if (n === 0)
    return "";
  let i = 0;
  for (; i < n && r.charAt(n - i - 1) === e; )
    i++;
  return r.slice(0, n - i);
}
function fa(r, e) {
  if (r.indexOf(e[1]) === -1)
    return -1;
  let t = 0;
  for (let n = 0; n < r.length; n++)
    if (r[n] === "\\")
      n++;
    else if (r[n] === e[0])
      t++;
    else if (r[n] === e[1] && (t--, t < 0))
      return n;
  return -1;
}
function En(r, e, t, n) {
  const i = e.href, l = e.title ? Q(e.title) : null, a = r[1].replace(/\\([\[\]])/g, "$1");
  if (r[0].charAt(0) !== "!") {
    n.state.inLink = !0;
    const o = {
      type: "link",
      raw: t,
      href: i,
      title: l,
      text: a,
      tokens: n.inlineTokens(a)
    };
    return n.state.inLink = !1, o;
  }
  return {
    type: "image",
    raw: t,
    href: i,
    title: l,
    text: Q(a)
  };
}
function ma(r, e) {
  const t = r.match(/^(\s+)(?:```)/);
  if (t === null)
    return e;
  const n = t[1];
  return e.split(`
`).map((i) => {
    const l = i.match(/^\s+/);
    if (l === null)
      return i;
    const [a] = l;
    return a.length >= n.length ? i.slice(n.length) : i;
  }).join(`
`);
}
class $t {
  // set by the lexer
  constructor(e) {
    O(this, "options");
    O(this, "rules");
    // set by the lexer
    O(this, "lexer");
    this.options = e || Pe;
  }
  space(e) {
    const t = this.rules.block.newline.exec(e);
    if (t && t[0].length > 0)
      return {
        type: "space",
        raw: t[0]
      };
  }
  code(e) {
    const t = this.rules.block.code.exec(e);
    if (t) {
      const n = t[0].replace(/^ {1,4}/gm, "");
      return {
        type: "code",
        raw: t[0],
        codeBlockStyle: "indented",
        text: this.options.pedantic ? n : _t(n, `
`)
      };
    }
  }
  fences(e) {
    const t = this.rules.block.fences.exec(e);
    if (t) {
      const n = t[0], i = ma(n, t[3] || "");
      return {
        type: "code",
        raw: n,
        lang: t[2] ? t[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : t[2],
        text: i
      };
    }
  }
  heading(e) {
    const t = this.rules.block.heading.exec(e);
    if (t) {
      let n = t[2].trim();
      if (/#$/.test(n)) {
        const i = _t(n, "#");
        (this.options.pedantic || !i || / $/.test(i)) && (n = i.trim());
      }
      return {
        type: "heading",
        raw: t[0],
        depth: t[1].length,
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  hr(e) {
    const t = this.rules.block.hr.exec(e);
    if (t)
      return {
        type: "hr",
        raw: t[0]
      };
  }
  blockquote(e) {
    const t = this.rules.block.blockquote.exec(e);
    if (t) {
      let n = t[0].replace(/\n {0,3}((?:=+|-+) *)(?=\n|$)/g, `
    $1`);
      n = _t(n.replace(/^ *>[ \t]?/gm, ""), `
`);
      const i = this.lexer.state.top;
      this.lexer.state.top = !0;
      const l = this.lexer.blockTokens(n);
      return this.lexer.state.top = i, {
        type: "blockquote",
        raw: t[0],
        tokens: l,
        text: n
      };
    }
  }
  list(e) {
    let t = this.rules.block.list.exec(e);
    if (t) {
      let n = t[1].trim();
      const i = n.length > 1, l = {
        type: "list",
        raw: "",
        ordered: i,
        start: i ? +n.slice(0, -1) : "",
        loose: !1,
        items: []
      };
      n = i ? `\\d{1,9}\\${n.slice(-1)}` : `\\${n}`, this.options.pedantic && (n = i ? n : "[*+-]");
      const a = new RegExp(`^( {0,3}${n})((?:[	 ][^\\n]*)?(?:\\n|$))`);
      let o = "", s = "", _ = !1;
      for (; e; ) {
        let c = !1;
        if (!(t = a.exec(e)) || this.rules.block.hr.test(e))
          break;
        o = t[0], e = e.substring(o.length);
        let p = t[2].split(`
`, 1)[0].replace(/^\t+/, (F) => " ".repeat(3 * F.length)), d = e.split(`
`, 1)[0], m = 0;
        this.options.pedantic ? (m = 2, s = p.trimStart()) : (m = t[2].search(/[^ ]/), m = m > 4 ? 1 : m, s = p.slice(m), m += t[1].length);
        let g = !1;
        if (!p && /^ *$/.test(d) && (o += d + `
`, e = e.substring(d.length + 1), c = !0), !c) {
          const F = new RegExp(`^ {0,${Math.min(3, m - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`), h = new RegExp(`^ {0,${Math.min(3, m - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`), u = new RegExp(`^ {0,${Math.min(3, m - 1)}}(?:\`\`\`|~~~)`), f = new RegExp(`^ {0,${Math.min(3, m - 1)}}#`);
          for (; e; ) {
            const D = e.split(`
`, 1)[0];
            if (d = D, this.options.pedantic && (d = d.replace(/^ {1,4}(?=( {4})*[^ ])/g, "  ")), u.test(d) || f.test(d) || F.test(d) || h.test(e))
              break;
            if (d.search(/[^ ]/) >= m || !d.trim())
              s += `
` + d.slice(m);
            else {
              if (g || p.search(/[^ ]/) >= 4 || u.test(p) || f.test(p) || h.test(p))
                break;
              s += `
` + d;
            }
            !g && !d.trim() && (g = !0), o += D + `
`, e = e.substring(D.length + 1), p = d.slice(m);
          }
        }
        l.loose || (_ ? l.loose = !0 : /\n *\n *$/.test(o) && (_ = !0));
        let v = null, b;
        this.options.gfm && (v = /^\[[ xX]\] /.exec(s), v && (b = v[0] !== "[ ] ", s = s.replace(/^\[[ xX]\] +/, ""))), l.items.push({
          type: "list_item",
          raw: o,
          task: !!v,
          checked: b,
          loose: !1,
          text: s,
          tokens: []
        }), l.raw += o;
      }
      l.items[l.items.length - 1].raw = o.trimEnd(), l.items[l.items.length - 1].text = s.trimEnd(), l.raw = l.raw.trimEnd();
      for (let c = 0; c < l.items.length; c++)
        if (this.lexer.state.top = !1, l.items[c].tokens = this.lexer.blockTokens(l.items[c].text, []), !l.loose) {
          const p = l.items[c].tokens.filter((m) => m.type === "space"), d = p.length > 0 && p.some((m) => /\n.*\n/.test(m.raw));
          l.loose = d;
        }
      if (l.loose)
        for (let c = 0; c < l.items.length; c++)
          l.items[c].loose = !0;
      return l;
    }
  }
  html(e) {
    const t = this.rules.block.html.exec(e);
    if (t)
      return {
        type: "html",
        block: !0,
        raw: t[0],
        pre: t[1] === "pre" || t[1] === "script" || t[1] === "style",
        text: t[0]
      };
  }
  def(e) {
    const t = this.rules.block.def.exec(e);
    if (t) {
      const n = t[1].toLowerCase().replace(/\s+/g, " "), i = t[2] ? t[2].replace(/^<(.*)>$/, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", l = t[3] ? t[3].substring(1, t[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : t[3];
      return {
        type: "def",
        tag: n,
        raw: t[0],
        href: i,
        title: l
      };
    }
  }
  table(e) {
    const t = this.rules.block.table.exec(e);
    if (!t || !/[:|]/.test(t[2]))
      return;
    const n = Fn(t[1]), i = t[2].replace(/^\||\| *$/g, "").split("|"), l = t[3] && t[3].trim() ? t[3].replace(/\n[ \t]*$/, "").split(`
`) : [], a = {
      type: "table",
      raw: t[0],
      header: [],
      align: [],
      rows: []
    };
    if (n.length === i.length) {
      for (const o of i)
        /^ *-+: *$/.test(o) ? a.align.push("right") : /^ *:-+: *$/.test(o) ? a.align.push("center") : /^ *:-+ *$/.test(o) ? a.align.push("left") : a.align.push(null);
      for (const o of n)
        a.header.push({
          text: o,
          tokens: this.lexer.inline(o)
        });
      for (const o of l)
        a.rows.push(Fn(o, a.header.length).map((s) => ({
          text: s,
          tokens: this.lexer.inline(s)
        })));
      return a;
    }
  }
  lheading(e) {
    const t = this.rules.block.lheading.exec(e);
    if (t)
      return {
        type: "heading",
        raw: t[0],
        depth: t[2].charAt(0) === "=" ? 1 : 2,
        text: t[1],
        tokens: this.lexer.inline(t[1])
      };
  }
  paragraph(e) {
    const t = this.rules.block.paragraph.exec(e);
    if (t) {
      const n = t[1].charAt(t[1].length - 1) === `
` ? t[1].slice(0, -1) : t[1];
      return {
        type: "paragraph",
        raw: t[0],
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  text(e) {
    const t = this.rules.block.text.exec(e);
    if (t)
      return {
        type: "text",
        raw: t[0],
        text: t[0],
        tokens: this.lexer.inline(t[0])
      };
  }
  escape(e) {
    const t = this.rules.inline.escape.exec(e);
    if (t)
      return {
        type: "escape",
        raw: t[0],
        text: Q(t[1])
      };
  }
  tag(e) {
    const t = this.rules.inline.tag.exec(e);
    if (t)
      return !this.lexer.state.inLink && /^<a /i.test(t[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && /^<\/a>/i.test(t[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && /^<(pre|code|kbd|script)(\s|>)/i.test(t[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && /^<\/(pre|code|kbd|script)(\s|>)/i.test(t[0]) && (this.lexer.state.inRawBlock = !1), {
        type: "html",
        raw: t[0],
        inLink: this.lexer.state.inLink,
        inRawBlock: this.lexer.state.inRawBlock,
        block: !1,
        text: t[0]
      };
  }
  link(e) {
    const t = this.rules.inline.link.exec(e);
    if (t) {
      const n = t[2].trim();
      if (!this.options.pedantic && /^</.test(n)) {
        if (!/>$/.test(n))
          return;
        const a = _t(n.slice(0, -1), "\\");
        if ((n.length - a.length) % 2 === 0)
          return;
      } else {
        const a = fa(t[2], "()");
        if (a > -1) {
          const s = (t[0].indexOf("!") === 0 ? 5 : 4) + t[1].length + a;
          t[2] = t[2].substring(0, a), t[0] = t[0].substring(0, s).trim(), t[3] = "";
        }
      }
      let i = t[2], l = "";
      if (this.options.pedantic) {
        const a = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(i);
        a && (i = a[1], l = a[3]);
      } else
        l = t[3] ? t[3].slice(1, -1) : "";
      return i = i.trim(), /^</.test(i) && (this.options.pedantic && !/>$/.test(n) ? i = i.slice(1) : i = i.slice(1, -1)), En(t, {
        href: i && i.replace(this.rules.inline.anyPunctuation, "$1"),
        title: l && l.replace(this.rules.inline.anyPunctuation, "$1")
      }, t[0], this.lexer);
    }
  }
  reflink(e, t) {
    let n;
    if ((n = this.rules.inline.reflink.exec(e)) || (n = this.rules.inline.nolink.exec(e))) {
      const i = (n[2] || n[1]).replace(/\s+/g, " "), l = t[i.toLowerCase()];
      if (!l) {
        const a = n[0].charAt(0);
        return {
          type: "text",
          raw: a,
          text: a
        };
      }
      return En(n, l, n[0], this.lexer);
    }
  }
  emStrong(e, t, n = "") {
    let i = this.rules.inline.emStrongLDelim.exec(e);
    if (!i || i[3] && n.match(/[\p{L}\p{N}]/u))
      return;
    if (!(i[1] || i[2] || "") || !n || this.rules.inline.punctuation.exec(n)) {
      const a = [...i[0]].length - 1;
      let o, s, _ = a, c = 0;
      const p = i[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (p.lastIndex = 0, t = t.slice(-1 * e.length + a); (i = p.exec(t)) != null; ) {
        if (o = i[1] || i[2] || i[3] || i[4] || i[5] || i[6], !o)
          continue;
        if (s = [...o].length, i[3] || i[4]) {
          _ += s;
          continue;
        } else if ((i[5] || i[6]) && a % 3 && !((a + s) % 3)) {
          c += s;
          continue;
        }
        if (_ -= s, _ > 0)
          continue;
        s = Math.min(s, s + _ + c);
        const d = [...i[0]][0].length, m = e.slice(0, a + i.index + d + s);
        if (Math.min(a, s) % 2) {
          const v = m.slice(1, -1);
          return {
            type: "em",
            raw: m,
            text: v,
            tokens: this.lexer.inlineTokens(v)
          };
        }
        const g = m.slice(2, -2);
        return {
          type: "strong",
          raw: m,
          text: g,
          tokens: this.lexer.inlineTokens(g)
        };
      }
    }
  }
  codespan(e) {
    const t = this.rules.inline.code.exec(e);
    if (t) {
      let n = t[2].replace(/\n/g, " ");
      const i = /[^ ]/.test(n), l = /^ /.test(n) && / $/.test(n);
      return i && l && (n = n.substring(1, n.length - 1)), n = Q(n, !0), {
        type: "codespan",
        raw: t[0],
        text: n
      };
    }
  }
  br(e) {
    const t = this.rules.inline.br.exec(e);
    if (t)
      return {
        type: "br",
        raw: t[0]
      };
  }
  del(e) {
    const t = this.rules.inline.del.exec(e);
    if (t)
      return {
        type: "del",
        raw: t[0],
        text: t[2],
        tokens: this.lexer.inlineTokens(t[2])
      };
  }
  autolink(e) {
    const t = this.rules.inline.autolink.exec(e);
    if (t) {
      let n, i;
      return t[2] === "@" ? (n = Q(t[1]), i = "mailto:" + n) : (n = Q(t[1]), i = n), {
        type: "link",
        raw: t[0],
        text: n,
        href: i,
        tokens: [
          {
            type: "text",
            raw: n,
            text: n
          }
        ]
      };
    }
  }
  url(e) {
    var n;
    let t;
    if (t = this.rules.inline.url.exec(e)) {
      let i, l;
      if (t[2] === "@")
        i = Q(t[0]), l = "mailto:" + i;
      else {
        let a;
        do
          a = t[0], t[0] = ((n = this.rules.inline._backpedal.exec(t[0])) == null ? void 0 : n[0]) ?? "";
        while (a !== t[0]);
        i = Q(t[0]), t[1] === "www." ? l = "http://" + t[0] : l = t[0];
      }
      return {
        type: "link",
        raw: t[0],
        text: i,
        href: l,
        tokens: [
          {
            type: "text",
            raw: i,
            text: i
          }
        ]
      };
    }
  }
  inlineText(e) {
    const t = this.rules.inline.text.exec(e);
    if (t) {
      let n;
      return this.lexer.state.inRawBlock ? n = t[0] : n = Q(t[0]), {
        type: "text",
        raw: t[0],
        text: n
      };
    }
  }
}
const ga = /^(?: *(?:\n|$))+/, ba = /^( {4}[^\n]+(?:\n(?: *(?:\n|$))*)?)+/, va = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, ot = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, Da = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, yi = /(?:[*+-]|\d{1,9}[.)])/, $i = R(/^(?!bull |blockCode|fences|blockquote|heading|html)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html))+?)\n {0,3}(=+|-+) *(?:\n+|$)/).replace(/bull/g, yi).replace(/blockCode/g, / {4}/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).getRegex(), Qt = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, ya = /^[^\n]+/, Jt = /(?!\s*\])(?:\\.|[^\[\]\\])+/, $a = R(/^ {0,3}\[(label)\]: *(?:\n *)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n *)?| *\n *)(title))? *(?:\n+|$)/).replace("label", Jt).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), wa = R(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, yi).getRegex(), At = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", en = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, Fa = R("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n *)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$))", "i").replace("comment", en).replace("tag", At).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), wi = R(Qt).replace("hr", ot).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", At).getRegex(), Ea = R(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", wi).getRegex(), tn = {
  blockquote: Ea,
  code: ba,
  def: $a,
  fences: va,
  heading: Da,
  hr: ot,
  html: Fa,
  lheading: $i,
  list: wa,
  newline: ga,
  paragraph: wi,
  table: Ke,
  text: ya
}, kn = R("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", ot).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", At).getRegex(), ka = {
  ...tn,
  table: kn,
  paragraph: R(Qt).replace("hr", ot).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", kn).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", At).getRegex()
}, Ca = {
  ...tn,
  html: R(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", en).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: Ke,
  // fences not supported
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: R(Qt).replace("hr", ot).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", $i).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
}, Fi = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, Aa = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, Ei = /^( {2,}|\\)\n(?!\s*$)/, Sa = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, st = "\\p{P}\\p{S}", Ta = R(/^((?![*_])[\spunctuation])/, "u").replace(/punctuation/g, st).getRegex(), xa = /\[[^[\]]*?\]\([^\(\)]*?\)|`[^`]*?`|<[^<>]*?>/g, Ba = R(/^(?:\*+(?:((?!\*)[punct])|[^\s*]))|^_+(?:((?!_)[punct])|([^\s_]))/, "u").replace(/punct/g, st).getRegex(), Ia = R("^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)[punct](\\*+)(?=[\\s]|$)|[^punct\\s](\\*+)(?!\\*)(?=[punct\\s]|$)|(?!\\*)[punct\\s](\\*+)(?=[^punct\\s])|[\\s](\\*+)(?!\\*)(?=[punct])|(?!\\*)[punct](\\*+)(?!\\*)(?=[punct])|[^punct\\s](\\*+)(?=[^punct\\s])", "gu").replace(/punct/g, st).getRegex(), Ra = R("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)[punct](_+)(?=[\\s]|$)|[^punct\\s](_+)(?!_)(?=[punct\\s]|$)|(?!_)[punct\\s](_+)(?=[^punct\\s])|[\\s](_+)(?!_)(?=[punct])|(?!_)[punct](_+)(?!_)(?=[punct])", "gu").replace(/punct/g, st).getRegex(), qa = R(/\\([punct])/, "gu").replace(/punct/g, st).getRegex(), La = R(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), Na = R(en).replace("(?:-->|$)", "-->").getRegex(), Oa = R("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", Na).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), wt = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, za = R(/^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/).replace("label", wt).replace("href", /<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), ki = R(/^!?\[(label)\]\[(ref)\]/).replace("label", wt).replace("ref", Jt).getRegex(), Ci = R(/^!?\[(ref)\](?:\[\])?/).replace("ref", Jt).getRegex(), Pa = R("reflink|nolink(?!\\()", "g").replace("reflink", ki).replace("nolink", Ci).getRegex(), nn = {
  _backpedal: Ke,
  // only used for GFM url
  anyPunctuation: qa,
  autolink: La,
  blockSkip: xa,
  br: Ei,
  code: Aa,
  del: Ke,
  emStrongLDelim: Ba,
  emStrongRDelimAst: Ia,
  emStrongRDelimUnd: Ra,
  escape: Fi,
  link: za,
  nolink: Ci,
  punctuation: Ta,
  reflink: ki,
  reflinkSearch: Pa,
  tag: Oa,
  text: Sa,
  url: Ke
}, Ma = {
  ...nn,
  link: R(/^!?\[(label)\]\((.*?)\)/).replace("label", wt).getRegex(),
  reflink: R(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", wt).getRegex()
}, Ut = {
  ...nn,
  escape: R(Fi).replace("])", "~|])").getRegex(),
  url: R(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])([\s\S]*?[^\s~])\1(?=[^~]|$)/,
  text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
}, Ua = {
  ...Ut,
  br: R(Ei).replace("{2,}", "*").getRegex(),
  text: R(Ut.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
}, dt = {
  normal: tn,
  gfm: ka,
  pedantic: Ca
}, Ve = {
  normal: nn,
  gfm: Ut,
  breaks: Ua,
  pedantic: Ma
};
class we {
  constructor(e) {
    O(this, "tokens");
    O(this, "options");
    O(this, "state");
    O(this, "tokenizer");
    O(this, "inlineQueue");
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = e || Pe, this.options.tokenizer = this.options.tokenizer || new $t(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
      inLink: !1,
      inRawBlock: !1,
      top: !0
    };
    const t = {
      block: dt.normal,
      inline: Ve.normal
    };
    this.options.pedantic ? (t.block = dt.pedantic, t.inline = Ve.pedantic) : this.options.gfm && (t.block = dt.gfm, this.options.breaks ? t.inline = Ve.breaks : t.inline = Ve.gfm), this.tokenizer.rules = t;
  }
  /**
   * Expose Rules
   */
  static get rules() {
    return {
      block: dt,
      inline: Ve
    };
  }
  /**
   * Static Lex Method
   */
  static lex(e, t) {
    return new we(t).lex(e);
  }
  /**
   * Static Lex Inline Method
   */
  static lexInline(e, t) {
    return new we(t).inlineTokens(e);
  }
  /**
   * Preprocessing
   */
  lex(e) {
    e = e.replace(/\r\n|\r/g, `
`), this.blockTokens(e, this.tokens);
    for (let t = 0; t < this.inlineQueue.length; t++) {
      const n = this.inlineQueue[t];
      this.inlineTokens(n.src, n.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(e, t = []) {
    this.options.pedantic ? e = e.replace(/\t/g, "    ").replace(/^ +$/gm, "") : e = e.replace(/^( *)(\t+)/gm, (o, s, _) => s + "    ".repeat(_.length));
    let n, i, l, a;
    for (; e; )
      if (!(this.options.extensions && this.options.extensions.block && this.options.extensions.block.some((o) => (n = o.call({ lexer: this }, e, t)) ? (e = e.substring(n.raw.length), t.push(n), !0) : !1))) {
        if (n = this.tokenizer.space(e)) {
          e = e.substring(n.raw.length), n.raw.length === 1 && t.length > 0 ? t[t.length - 1].raw += `
` : t.push(n);
          continue;
        }
        if (n = this.tokenizer.code(e)) {
          e = e.substring(n.raw.length), i = t[t.length - 1], i && (i.type === "paragraph" || i.type === "text") ? (i.raw += `
` + n.raw, i.text += `
` + n.text, this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.fences(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.heading(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.hr(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.blockquote(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.list(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.html(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.def(e)) {
          e = e.substring(n.raw.length), i = t[t.length - 1], i && (i.type === "paragraph" || i.type === "text") ? (i.raw += `
` + n.raw, i.text += `
` + n.raw, this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : this.tokens.links[n.tag] || (this.tokens.links[n.tag] = {
            href: n.href,
            title: n.title
          });
          continue;
        }
        if (n = this.tokenizer.table(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.lheading(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (l = e, this.options.extensions && this.options.extensions.startBlock) {
          let o = 1 / 0;
          const s = e.slice(1);
          let _;
          this.options.extensions.startBlock.forEach((c) => {
            _ = c.call({ lexer: this }, s), typeof _ == "number" && _ >= 0 && (o = Math.min(o, _));
          }), o < 1 / 0 && o >= 0 && (l = e.substring(0, o + 1));
        }
        if (this.state.top && (n = this.tokenizer.paragraph(l))) {
          i = t[t.length - 1], a && i.type === "paragraph" ? (i.raw += `
` + n.raw, i.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : t.push(n), a = l.length !== e.length, e = e.substring(n.raw.length);
          continue;
        }
        if (n = this.tokenizer.text(e)) {
          e = e.substring(n.raw.length), i = t[t.length - 1], i && i.type === "text" ? (i.raw += `
` + n.raw, i.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : t.push(n);
          continue;
        }
        if (e) {
          const o = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(o);
            break;
          } else
            throw new Error(o);
        }
      }
    return this.state.top = !0, t;
  }
  inline(e, t = []) {
    return this.inlineQueue.push({ src: e, tokens: t }), t;
  }
  /**
   * Lexing/Compiling
   */
  inlineTokens(e, t = []) {
    let n, i, l, a = e, o, s, _;
    if (this.tokens.links) {
      const c = Object.keys(this.tokens.links);
      if (c.length > 0)
        for (; (o = this.tokenizer.rules.inline.reflinkSearch.exec(a)) != null; )
          c.includes(o[0].slice(o[0].lastIndexOf("[") + 1, -1)) && (a = a.slice(0, o.index) + "[" + "a".repeat(o[0].length - 2) + "]" + a.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (o = this.tokenizer.rules.inline.blockSkip.exec(a)) != null; )
      a = a.slice(0, o.index) + "[" + "a".repeat(o[0].length - 2) + "]" + a.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    for (; (o = this.tokenizer.rules.inline.anyPunctuation.exec(a)) != null; )
      a = a.slice(0, o.index) + "++" + a.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    for (; e; )
      if (s || (_ = ""), s = !1, !(this.options.extensions && this.options.extensions.inline && this.options.extensions.inline.some((c) => (n = c.call({ lexer: this }, e, t)) ? (e = e.substring(n.raw.length), t.push(n), !0) : !1))) {
        if (n = this.tokenizer.escape(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.tag(e)) {
          e = e.substring(n.raw.length), i = t[t.length - 1], i && n.type === "text" && i.type === "text" ? (i.raw += n.raw, i.text += n.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.link(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.reflink(e, this.tokens.links)) {
          e = e.substring(n.raw.length), i = t[t.length - 1], i && n.type === "text" && i.type === "text" ? (i.raw += n.raw, i.text += n.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.emStrong(e, a, _)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.codespan(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.br(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.del(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.autolink(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (!this.state.inLink && (n = this.tokenizer.url(e))) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (l = e, this.options.extensions && this.options.extensions.startInline) {
          let c = 1 / 0;
          const p = e.slice(1);
          let d;
          this.options.extensions.startInline.forEach((m) => {
            d = m.call({ lexer: this }, p), typeof d == "number" && d >= 0 && (c = Math.min(c, d));
          }), c < 1 / 0 && c >= 0 && (l = e.substring(0, c + 1));
        }
        if (n = this.tokenizer.inlineText(l)) {
          e = e.substring(n.raw.length), n.raw.slice(-1) !== "_" && (_ = n.raw.slice(-1)), s = !0, i = t[t.length - 1], i && i.type === "text" ? (i.raw += n.raw, i.text += n.text) : t.push(n);
          continue;
        }
        if (e) {
          const c = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(c);
            break;
          } else
            throw new Error(c);
        }
      }
    return t;
  }
}
class Ft {
  constructor(e) {
    O(this, "options");
    this.options = e || Pe;
  }
  code(e, t, n) {
    var l;
    const i = (l = (t || "").match(/^\S*/)) == null ? void 0 : l[0];
    return e = e.replace(/\n$/, "") + `
`, i ? '<pre><code class="language-' + Q(i) + '">' + (n ? e : Q(e, !0)) + `</code></pre>
` : "<pre><code>" + (n ? e : Q(e, !0)) + `</code></pre>
`;
  }
  blockquote(e) {
    return `<blockquote>
${e}</blockquote>
`;
  }
  html(e, t) {
    return e;
  }
  heading(e, t, n) {
    return `<h${t}>${e}</h${t}>
`;
  }
  hr() {
    return `<hr>
`;
  }
  list(e, t, n) {
    const i = t ? "ol" : "ul", l = t && n !== 1 ? ' start="' + n + '"' : "";
    return "<" + i + l + `>
` + e + "</" + i + `>
`;
  }
  listitem(e, t, n) {
    return `<li>${e}</li>
`;
  }
  checkbox(e) {
    return "<input " + (e ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph(e) {
    return `<p>${e}</p>
`;
  }
  table(e, t) {
    return t && (t = `<tbody>${t}</tbody>`), `<table>
<thead>
` + e + `</thead>
` + t + `</table>
`;
  }
  tablerow(e) {
    return `<tr>
${e}</tr>
`;
  }
  tablecell(e, t) {
    const n = t.header ? "th" : "td";
    return (t.align ? `<${n} align="${t.align}">` : `<${n}>`) + e + `</${n}>
`;
  }
  /**
   * span level renderer
   */
  strong(e) {
    return `<strong>${e}</strong>`;
  }
  em(e) {
    return `<em>${e}</em>`;
  }
  codespan(e) {
    return `<code>${e}</code>`;
  }
  br() {
    return "<br>";
  }
  del(e) {
    return `<del>${e}</del>`;
  }
  link(e, t, n) {
    const i = wn(e);
    if (i === null)
      return n;
    e = i;
    let l = '<a href="' + e + '"';
    return t && (l += ' title="' + t + '"'), l += ">" + n + "</a>", l;
  }
  image(e, t, n) {
    const i = wn(e);
    if (i === null)
      return n;
    e = i;
    let l = `<img src="${e}" alt="${n}"`;
    return t && (l += ` title="${t}"`), l += ">", l;
  }
  text(e) {
    return e;
  }
}
class an {
  // no need for block level renderers
  strong(e) {
    return e;
  }
  em(e) {
    return e;
  }
  codespan(e) {
    return e;
  }
  del(e) {
    return e;
  }
  html(e) {
    return e;
  }
  text(e) {
    return e;
  }
  link(e, t, n) {
    return "" + n;
  }
  image(e, t, n) {
    return "" + n;
  }
  br() {
    return "";
  }
}
class Fe {
  constructor(e) {
    O(this, "options");
    O(this, "renderer");
    O(this, "textRenderer");
    this.options = e || Pe, this.options.renderer = this.options.renderer || new Ft(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.textRenderer = new an();
  }
  /**
   * Static Parse Method
   */
  static parse(e, t) {
    return new Fe(t).parse(e);
  }
  /**
   * Static Parse Inline Method
   */
  static parseInline(e, t) {
    return new Fe(t).parseInline(e);
  }
  /**
   * Parse Loop
   */
  parse(e, t = !0) {
    let n = "";
    for (let i = 0; i < e.length; i++) {
      const l = e[i];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[l.type]) {
        const a = l, o = this.options.extensions.renderers[a.type].call({ parser: this }, a);
        if (o !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(a.type)) {
          n += o || "";
          continue;
        }
      }
      switch (l.type) {
        case "space":
          continue;
        case "hr": {
          n += this.renderer.hr();
          continue;
        }
        case "heading": {
          const a = l;
          n += this.renderer.heading(this.parseInline(a.tokens), a.depth, pa(this.parseInline(a.tokens, this.textRenderer)));
          continue;
        }
        case "code": {
          const a = l;
          n += this.renderer.code(a.text, a.lang, !!a.escaped);
          continue;
        }
        case "table": {
          const a = l;
          let o = "", s = "";
          for (let c = 0; c < a.header.length; c++)
            s += this.renderer.tablecell(this.parseInline(a.header[c].tokens), { header: !0, align: a.align[c] });
          o += this.renderer.tablerow(s);
          let _ = "";
          for (let c = 0; c < a.rows.length; c++) {
            const p = a.rows[c];
            s = "";
            for (let d = 0; d < p.length; d++)
              s += this.renderer.tablecell(this.parseInline(p[d].tokens), { header: !1, align: a.align[d] });
            _ += this.renderer.tablerow(s);
          }
          n += this.renderer.table(o, _);
          continue;
        }
        case "blockquote": {
          const a = l, o = this.parse(a.tokens);
          n += this.renderer.blockquote(o);
          continue;
        }
        case "list": {
          const a = l, o = a.ordered, s = a.start, _ = a.loose;
          let c = "";
          for (let p = 0; p < a.items.length; p++) {
            const d = a.items[p], m = d.checked, g = d.task;
            let v = "";
            if (d.task) {
              const b = this.renderer.checkbox(!!m);
              _ ? d.tokens.length > 0 && d.tokens[0].type === "paragraph" ? (d.tokens[0].text = b + " " + d.tokens[0].text, d.tokens[0].tokens && d.tokens[0].tokens.length > 0 && d.tokens[0].tokens[0].type === "text" && (d.tokens[0].tokens[0].text = b + " " + d.tokens[0].tokens[0].text)) : d.tokens.unshift({
                type: "text",
                text: b + " "
              }) : v += b + " ";
            }
            v += this.parse(d.tokens, _), c += this.renderer.listitem(v, g, !!m);
          }
          n += this.renderer.list(c, o, s);
          continue;
        }
        case "html": {
          const a = l;
          n += this.renderer.html(a.text, a.block);
          continue;
        }
        case "paragraph": {
          const a = l;
          n += this.renderer.paragraph(this.parseInline(a.tokens));
          continue;
        }
        case "text": {
          let a = l, o = a.tokens ? this.parseInline(a.tokens) : a.text;
          for (; i + 1 < e.length && e[i + 1].type === "text"; )
            a = e[++i], o += `
` + (a.tokens ? this.parseInline(a.tokens) : a.text);
          n += t ? this.renderer.paragraph(o) : o;
          continue;
        }
        default: {
          const a = 'Token with "' + l.type + '" type was not found.';
          if (this.options.silent)
            return console.error(a), "";
          throw new Error(a);
        }
      }
    }
    return n;
  }
  /**
   * Parse Inline Tokens
   */
  parseInline(e, t) {
    t = t || this.renderer;
    let n = "";
    for (let i = 0; i < e.length; i++) {
      const l = e[i];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[l.type]) {
        const a = this.options.extensions.renderers[l.type].call({ parser: this }, l);
        if (a !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(l.type)) {
          n += a || "";
          continue;
        }
      }
      switch (l.type) {
        case "escape": {
          const a = l;
          n += t.text(a.text);
          break;
        }
        case "html": {
          const a = l;
          n += t.html(a.text);
          break;
        }
        case "link": {
          const a = l;
          n += t.link(a.href, a.title, this.parseInline(a.tokens, t));
          break;
        }
        case "image": {
          const a = l;
          n += t.image(a.href, a.title, a.text);
          break;
        }
        case "strong": {
          const a = l;
          n += t.strong(this.parseInline(a.tokens, t));
          break;
        }
        case "em": {
          const a = l;
          n += t.em(this.parseInline(a.tokens, t));
          break;
        }
        case "codespan": {
          const a = l;
          n += t.codespan(a.text);
          break;
        }
        case "br": {
          n += t.br();
          break;
        }
        case "del": {
          const a = l;
          n += t.del(this.parseInline(a.tokens, t));
          break;
        }
        case "text": {
          const a = l;
          n += t.text(a.text);
          break;
        }
        default: {
          const a = 'Token with "' + l.type + '" type was not found.';
          if (this.options.silent)
            return console.error(a), "";
          throw new Error(a);
        }
      }
    }
    return n;
  }
}
class Qe {
  constructor(e) {
    O(this, "options");
    this.options = e || Pe;
  }
  /**
   * Process markdown before marked
   */
  preprocess(e) {
    return e;
  }
  /**
   * Process HTML after marked is finished
   */
  postprocess(e) {
    return e;
  }
  /**
   * Process all tokens before walk tokens
   */
  processAllTokens(e) {
    return e;
  }
}
O(Qe, "passThroughHooks", /* @__PURE__ */ new Set([
  "preprocess",
  "postprocess",
  "processAllTokens"
]));
var ze, Ht, Ai;
class Ha {
  constructor(...e) {
    gn(this, ze);
    O(this, "defaults", Kt());
    O(this, "options", this.setOptions);
    O(this, "parse", ct(this, ze, Ht).call(this, we.lex, Fe.parse));
    O(this, "parseInline", ct(this, ze, Ht).call(this, we.lexInline, Fe.parseInline));
    O(this, "Parser", Fe);
    O(this, "Renderer", Ft);
    O(this, "TextRenderer", an);
    O(this, "Lexer", we);
    O(this, "Tokenizer", $t);
    O(this, "Hooks", Qe);
    this.use(...e);
  }
  /**
   * Run callback for every token
   */
  walkTokens(e, t) {
    var i, l;
    let n = [];
    for (const a of e)
      switch (n = n.concat(t.call(this, a)), a.type) {
        case "table": {
          const o = a;
          for (const s of o.header)
            n = n.concat(this.walkTokens(s.tokens, t));
          for (const s of o.rows)
            for (const _ of s)
              n = n.concat(this.walkTokens(_.tokens, t));
          break;
        }
        case "list": {
          const o = a;
          n = n.concat(this.walkTokens(o.items, t));
          break;
        }
        default: {
          const o = a;
          (l = (i = this.defaults.extensions) == null ? void 0 : i.childTokens) != null && l[o.type] ? this.defaults.extensions.childTokens[o.type].forEach((s) => {
            const _ = o[s].flat(1 / 0);
            n = n.concat(this.walkTokens(_, t));
          }) : o.tokens && (n = n.concat(this.walkTokens(o.tokens, t)));
        }
      }
    return n;
  }
  use(...e) {
    const t = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return e.forEach((n) => {
      const i = { ...n };
      if (i.async = this.defaults.async || i.async || !1, n.extensions && (n.extensions.forEach((l) => {
        if (!l.name)
          throw new Error("extension name required");
        if ("renderer" in l) {
          const a = t.renderers[l.name];
          a ? t.renderers[l.name] = function(...o) {
            let s = l.renderer.apply(this, o);
            return s === !1 && (s = a.apply(this, o)), s;
          } : t.renderers[l.name] = l.renderer;
        }
        if ("tokenizer" in l) {
          if (!l.level || l.level !== "block" && l.level !== "inline")
            throw new Error("extension level must be 'block' or 'inline'");
          const a = t[l.level];
          a ? a.unshift(l.tokenizer) : t[l.level] = [l.tokenizer], l.start && (l.level === "block" ? t.startBlock ? t.startBlock.push(l.start) : t.startBlock = [l.start] : l.level === "inline" && (t.startInline ? t.startInline.push(l.start) : t.startInline = [l.start]));
        }
        "childTokens" in l && l.childTokens && (t.childTokens[l.name] = l.childTokens);
      }), i.extensions = t), n.renderer) {
        const l = this.defaults.renderer || new Ft(this.defaults);
        for (const a in n.renderer) {
          if (!(a in l))
            throw new Error(`renderer '${a}' does not exist`);
          if (a === "options")
            continue;
          const o = a, s = n.renderer[o], _ = l[o];
          l[o] = (...c) => {
            let p = s.apply(l, c);
            return p === !1 && (p = _.apply(l, c)), p || "";
          };
        }
        i.renderer = l;
      }
      if (n.tokenizer) {
        const l = this.defaults.tokenizer || new $t(this.defaults);
        for (const a in n.tokenizer) {
          if (!(a in l))
            throw new Error(`tokenizer '${a}' does not exist`);
          if (["options", "rules", "lexer"].includes(a))
            continue;
          const o = a, s = n.tokenizer[o], _ = l[o];
          l[o] = (...c) => {
            let p = s.apply(l, c);
            return p === !1 && (p = _.apply(l, c)), p;
          };
        }
        i.tokenizer = l;
      }
      if (n.hooks) {
        const l = this.defaults.hooks || new Qe();
        for (const a in n.hooks) {
          if (!(a in l))
            throw new Error(`hook '${a}' does not exist`);
          if (a === "options")
            continue;
          const o = a, s = n.hooks[o], _ = l[o];
          Qe.passThroughHooks.has(a) ? l[o] = (c) => {
            if (this.defaults.async)
              return Promise.resolve(s.call(l, c)).then((d) => _.call(l, d));
            const p = s.call(l, c);
            return _.call(l, p);
          } : l[o] = (...c) => {
            let p = s.apply(l, c);
            return p === !1 && (p = _.apply(l, c)), p;
          };
        }
        i.hooks = l;
      }
      if (n.walkTokens) {
        const l = this.defaults.walkTokens, a = n.walkTokens;
        i.walkTokens = function(o) {
          let s = [];
          return s.push(a.call(this, o)), l && (s = s.concat(l.call(this, o))), s;
        };
      }
      this.defaults = { ...this.defaults, ...i };
    }), this;
  }
  setOptions(e) {
    return this.defaults = { ...this.defaults, ...e }, this;
  }
  lexer(e, t) {
    return we.lex(e, t ?? this.defaults);
  }
  parser(e, t) {
    return Fe.parse(e, t ?? this.defaults);
  }
}
ze = new WeakSet(), Ht = function(e, t) {
  return (n, i) => {
    const l = { ...i }, a = { ...this.defaults, ...l };
    this.defaults.async === !0 && l.async === !1 && (a.silent || console.warn("marked(): The async option was set to true by an extension. The async: false option sent to parse will be ignored."), a.async = !0);
    const o = ct(this, ze, Ai).call(this, !!a.silent, !!a.async);
    if (typeof n > "u" || n === null)
      return o(new Error("marked(): input parameter is undefined or null"));
    if (typeof n != "string")
      return o(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(n) + ", string expected"));
    if (a.hooks && (a.hooks.options = a), a.async)
      return Promise.resolve(a.hooks ? a.hooks.preprocess(n) : n).then((s) => e(s, a)).then((s) => a.hooks ? a.hooks.processAllTokens(s) : s).then((s) => a.walkTokens ? Promise.all(this.walkTokens(s, a.walkTokens)).then(() => s) : s).then((s) => t(s, a)).then((s) => a.hooks ? a.hooks.postprocess(s) : s).catch(o);
    try {
      a.hooks && (n = a.hooks.preprocess(n));
      let s = e(n, a);
      a.hooks && (s = a.hooks.processAllTokens(s)), a.walkTokens && this.walkTokens(s, a.walkTokens);
      let _ = t(s, a);
      return a.hooks && (_ = a.hooks.postprocess(_)), _;
    } catch (s) {
      return o(s);
    }
  };
}, Ai = function(e, t) {
  return (n) => {
    if (n.message += `
Please report this to https://github.com/markedjs/marked.`, e) {
      const i = "<p>An error occurred:</p><pre>" + Q(n.message + "", !0) + "</pre>";
      return t ? Promise.resolve(i) : i;
    }
    if (t)
      return Promise.reject(n);
    throw n;
  };
};
const Oe = new Ha();
function I(r, e) {
  return Oe.parse(r, e);
}
I.options = I.setOptions = function(r) {
  return Oe.setOptions(r), I.defaults = Oe.defaults, bi(I.defaults), I;
};
I.getDefaults = Kt;
I.defaults = Pe;
I.use = function(...r) {
  return Oe.use(...r), I.defaults = Oe.defaults, bi(I.defaults), I;
};
I.walkTokens = function(r, e) {
  return Oe.walkTokens(r, e);
};
I.parseInline = Oe.parseInline;
I.Parser = Fe;
I.parser = Fe.parse;
I.Renderer = Ft;
I.TextRenderer = an;
I.Lexer = we;
I.lexer = we.lex;
I.Tokenizer = $t;
I.Hooks = Qe;
I.parse = I;
I.options;
I.setOptions;
I.use;
I.walkTokens;
I.parseInline;
Fe.parse;
we.lex;
const Ga = /[\0-\x1F!-,\.\/:-@\[-\^`\{-\xA9\xAB-\xB4\xB6-\xB9\xBB-\xBF\xD7\xF7\u02C2-\u02C5\u02D2-\u02DF\u02E5-\u02EB\u02ED\u02EF-\u02FF\u0375\u0378\u0379\u037E\u0380-\u0385\u0387\u038B\u038D\u03A2\u03F6\u0482\u0530\u0557\u0558\u055A-\u055F\u0589-\u0590\u05BE\u05C0\u05C3\u05C6\u05C8-\u05CF\u05EB-\u05EE\u05F3-\u060F\u061B-\u061F\u066A-\u066D\u06D4\u06DD\u06DE\u06E9\u06FD\u06FE\u0700-\u070F\u074B\u074C\u07B2-\u07BF\u07F6-\u07F9\u07FB\u07FC\u07FE\u07FF\u082E-\u083F\u085C-\u085F\u086B-\u089F\u08B5\u08C8-\u08D2\u08E2\u0964\u0965\u0970\u0984\u098D\u098E\u0991\u0992\u09A9\u09B1\u09B3-\u09B5\u09BA\u09BB\u09C5\u09C6\u09C9\u09CA\u09CF-\u09D6\u09D8-\u09DB\u09DE\u09E4\u09E5\u09F2-\u09FB\u09FD\u09FF\u0A00\u0A04\u0A0B-\u0A0E\u0A11\u0A12\u0A29\u0A31\u0A34\u0A37\u0A3A\u0A3B\u0A3D\u0A43-\u0A46\u0A49\u0A4A\u0A4E-\u0A50\u0A52-\u0A58\u0A5D\u0A5F-\u0A65\u0A76-\u0A80\u0A84\u0A8E\u0A92\u0AA9\u0AB1\u0AB4\u0ABA\u0ABB\u0AC6\u0ACA\u0ACE\u0ACF\u0AD1-\u0ADF\u0AE4\u0AE5\u0AF0-\u0AF8\u0B00\u0B04\u0B0D\u0B0E\u0B11\u0B12\u0B29\u0B31\u0B34\u0B3A\u0B3B\u0B45\u0B46\u0B49\u0B4A\u0B4E-\u0B54\u0B58-\u0B5B\u0B5E\u0B64\u0B65\u0B70\u0B72-\u0B81\u0B84\u0B8B-\u0B8D\u0B91\u0B96-\u0B98\u0B9B\u0B9D\u0BA0-\u0BA2\u0BA5-\u0BA7\u0BAB-\u0BAD\u0BBA-\u0BBD\u0BC3-\u0BC5\u0BC9\u0BCE\u0BCF\u0BD1-\u0BD6\u0BD8-\u0BE5\u0BF0-\u0BFF\u0C0D\u0C11\u0C29\u0C3A-\u0C3C\u0C45\u0C49\u0C4E-\u0C54\u0C57\u0C5B-\u0C5F\u0C64\u0C65\u0C70-\u0C7F\u0C84\u0C8D\u0C91\u0CA9\u0CB4\u0CBA\u0CBB\u0CC5\u0CC9\u0CCE-\u0CD4\u0CD7-\u0CDD\u0CDF\u0CE4\u0CE5\u0CF0\u0CF3-\u0CFF\u0D0D\u0D11\u0D45\u0D49\u0D4F-\u0D53\u0D58-\u0D5E\u0D64\u0D65\u0D70-\u0D79\u0D80\u0D84\u0D97-\u0D99\u0DB2\u0DBC\u0DBE\u0DBF\u0DC7-\u0DC9\u0DCB-\u0DCE\u0DD5\u0DD7\u0DE0-\u0DE5\u0DF0\u0DF1\u0DF4-\u0E00\u0E3B-\u0E3F\u0E4F\u0E5A-\u0E80\u0E83\u0E85\u0E8B\u0EA4\u0EA6\u0EBE\u0EBF\u0EC5\u0EC7\u0ECE\u0ECF\u0EDA\u0EDB\u0EE0-\u0EFF\u0F01-\u0F17\u0F1A-\u0F1F\u0F2A-\u0F34\u0F36\u0F38\u0F3A-\u0F3D\u0F48\u0F6D-\u0F70\u0F85\u0F98\u0FBD-\u0FC5\u0FC7-\u0FFF\u104A-\u104F\u109E\u109F\u10C6\u10C8-\u10CC\u10CE\u10CF\u10FB\u1249\u124E\u124F\u1257\u1259\u125E\u125F\u1289\u128E\u128F\u12B1\u12B6\u12B7\u12BF\u12C1\u12C6\u12C7\u12D7\u1311\u1316\u1317\u135B\u135C\u1360-\u137F\u1390-\u139F\u13F6\u13F7\u13FE-\u1400\u166D\u166E\u1680\u169B-\u169F\u16EB-\u16ED\u16F9-\u16FF\u170D\u1715-\u171F\u1735-\u173F\u1754-\u175F\u176D\u1771\u1774-\u177F\u17D4-\u17D6\u17D8-\u17DB\u17DE\u17DF\u17EA-\u180A\u180E\u180F\u181A-\u181F\u1879-\u187F\u18AB-\u18AF\u18F6-\u18FF\u191F\u192C-\u192F\u193C-\u1945\u196E\u196F\u1975-\u197F\u19AC-\u19AF\u19CA-\u19CF\u19DA-\u19FF\u1A1C-\u1A1F\u1A5F\u1A7D\u1A7E\u1A8A-\u1A8F\u1A9A-\u1AA6\u1AA8-\u1AAF\u1AC1-\u1AFF\u1B4C-\u1B4F\u1B5A-\u1B6A\u1B74-\u1B7F\u1BF4-\u1BFF\u1C38-\u1C3F\u1C4A-\u1C4C\u1C7E\u1C7F\u1C89-\u1C8F\u1CBB\u1CBC\u1CC0-\u1CCF\u1CD3\u1CFB-\u1CFF\u1DFA\u1F16\u1F17\u1F1E\u1F1F\u1F46\u1F47\u1F4E\u1F4F\u1F58\u1F5A\u1F5C\u1F5E\u1F7E\u1F7F\u1FB5\u1FBD\u1FBF-\u1FC1\u1FC5\u1FCD-\u1FCF\u1FD4\u1FD5\u1FDC-\u1FDF\u1FED-\u1FF1\u1FF5\u1FFD-\u203E\u2041-\u2053\u2055-\u2070\u2072-\u207E\u2080-\u208F\u209D-\u20CF\u20F1-\u2101\u2103-\u2106\u2108\u2109\u2114\u2116-\u2118\u211E-\u2123\u2125\u2127\u2129\u212E\u213A\u213B\u2140-\u2144\u214A-\u214D\u214F-\u215F\u2189-\u24B5\u24EA-\u2BFF\u2C2F\u2C5F\u2CE5-\u2CEA\u2CF4-\u2CFF\u2D26\u2D28-\u2D2C\u2D2E\u2D2F\u2D68-\u2D6E\u2D70-\u2D7E\u2D97-\u2D9F\u2DA7\u2DAF\u2DB7\u2DBF\u2DC7\u2DCF\u2DD7\u2DDF\u2E00-\u2E2E\u2E30-\u3004\u3008-\u3020\u3030\u3036\u3037\u303D-\u3040\u3097\u3098\u309B\u309C\u30A0\u30FB\u3100-\u3104\u3130\u318F-\u319F\u31C0-\u31EF\u3200-\u33FF\u4DC0-\u4DFF\u9FFD-\u9FFF\uA48D-\uA4CF\uA4FE\uA4FF\uA60D-\uA60F\uA62C-\uA63F\uA673\uA67E\uA6F2-\uA716\uA720\uA721\uA789\uA78A\uA7C0\uA7C1\uA7CB-\uA7F4\uA828-\uA82B\uA82D-\uA83F\uA874-\uA87F\uA8C6-\uA8CF\uA8DA-\uA8DF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA954-\uA95F\uA97D-\uA97F\uA9C1-\uA9CE\uA9DA-\uA9DF\uA9FF\uAA37-\uAA3F\uAA4E\uAA4F\uAA5A-\uAA5F\uAA77-\uAA79\uAAC3-\uAADA\uAADE\uAADF\uAAF0\uAAF1\uAAF7-\uAB00\uAB07\uAB08\uAB0F\uAB10\uAB17-\uAB1F\uAB27\uAB2F\uAB5B\uAB6A-\uAB6F\uABEB\uABEE\uABEF\uABFA-\uABFF\uD7A4-\uD7AF\uD7C7-\uD7CA\uD7FC-\uD7FF\uE000-\uF8FF\uFA6E\uFA6F\uFADA-\uFAFF\uFB07-\uFB12\uFB18-\uFB1C\uFB29\uFB37\uFB3D\uFB3F\uFB42\uFB45\uFBB2-\uFBD2\uFD3E-\uFD4F\uFD90\uFD91\uFDC8-\uFDEF\uFDFC-\uFDFF\uFE10-\uFE1F\uFE30-\uFE32\uFE35-\uFE4C\uFE50-\uFE6F\uFE75\uFEFD-\uFF0F\uFF1A-\uFF20\uFF3B-\uFF3E\uFF40\uFF5B-\uFF65\uFFBF-\uFFC1\uFFC8\uFFC9\uFFD0\uFFD1\uFFD8\uFFD9\uFFDD-\uFFFF]|\uD800[\uDC0C\uDC27\uDC3B\uDC3E\uDC4E\uDC4F\uDC5E-\uDC7F\uDCFB-\uDD3F\uDD75-\uDDFC\uDDFE-\uDE7F\uDE9D-\uDE9F\uDED1-\uDEDF\uDEE1-\uDEFF\uDF20-\uDF2C\uDF4B-\uDF4F\uDF7B-\uDF7F\uDF9E\uDF9F\uDFC4-\uDFC7\uDFD0\uDFD6-\uDFFF]|\uD801[\uDC9E\uDC9F\uDCAA-\uDCAF\uDCD4-\uDCD7\uDCFC-\uDCFF\uDD28-\uDD2F\uDD64-\uDDFF\uDF37-\uDF3F\uDF56-\uDF5F\uDF68-\uDFFF]|\uD802[\uDC06\uDC07\uDC09\uDC36\uDC39-\uDC3B\uDC3D\uDC3E\uDC56-\uDC5F\uDC77-\uDC7F\uDC9F-\uDCDF\uDCF3\uDCF6-\uDCFF\uDD16-\uDD1F\uDD3A-\uDD7F\uDDB8-\uDDBD\uDDC0-\uDDFF\uDE04\uDE07-\uDE0B\uDE14\uDE18\uDE36\uDE37\uDE3B-\uDE3E\uDE40-\uDE5F\uDE7D-\uDE7F\uDE9D-\uDEBF\uDEC8\uDEE7-\uDEFF\uDF36-\uDF3F\uDF56-\uDF5F\uDF73-\uDF7F\uDF92-\uDFFF]|\uD803[\uDC49-\uDC7F\uDCB3-\uDCBF\uDCF3-\uDCFF\uDD28-\uDD2F\uDD3A-\uDE7F\uDEAA\uDEAD-\uDEAF\uDEB2-\uDEFF\uDF1D-\uDF26\uDF28-\uDF2F\uDF51-\uDFAF\uDFC5-\uDFDF\uDFF7-\uDFFF]|\uD804[\uDC47-\uDC65\uDC70-\uDC7E\uDCBB-\uDCCF\uDCE9-\uDCEF\uDCFA-\uDCFF\uDD35\uDD40-\uDD43\uDD48-\uDD4F\uDD74\uDD75\uDD77-\uDD7F\uDDC5-\uDDC8\uDDCD\uDDDB\uDDDD-\uDDFF\uDE12\uDE38-\uDE3D\uDE3F-\uDE7F\uDE87\uDE89\uDE8E\uDE9E\uDEA9-\uDEAF\uDEEB-\uDEEF\uDEFA-\uDEFF\uDF04\uDF0D\uDF0E\uDF11\uDF12\uDF29\uDF31\uDF34\uDF3A\uDF45\uDF46\uDF49\uDF4A\uDF4E\uDF4F\uDF51-\uDF56\uDF58-\uDF5C\uDF64\uDF65\uDF6D-\uDF6F\uDF75-\uDFFF]|\uD805[\uDC4B-\uDC4F\uDC5A-\uDC5D\uDC62-\uDC7F\uDCC6\uDCC8-\uDCCF\uDCDA-\uDD7F\uDDB6\uDDB7\uDDC1-\uDDD7\uDDDE-\uDDFF\uDE41-\uDE43\uDE45-\uDE4F\uDE5A-\uDE7F\uDEB9-\uDEBF\uDECA-\uDEFF\uDF1B\uDF1C\uDF2C-\uDF2F\uDF3A-\uDFFF]|\uD806[\uDC3B-\uDC9F\uDCEA-\uDCFE\uDD07\uDD08\uDD0A\uDD0B\uDD14\uDD17\uDD36\uDD39\uDD3A\uDD44-\uDD4F\uDD5A-\uDD9F\uDDA8\uDDA9\uDDD8\uDDD9\uDDE2\uDDE5-\uDDFF\uDE3F-\uDE46\uDE48-\uDE4F\uDE9A-\uDE9C\uDE9E-\uDEBF\uDEF9-\uDFFF]|\uD807[\uDC09\uDC37\uDC41-\uDC4F\uDC5A-\uDC71\uDC90\uDC91\uDCA8\uDCB7-\uDCFF\uDD07\uDD0A\uDD37-\uDD39\uDD3B\uDD3E\uDD48-\uDD4F\uDD5A-\uDD5F\uDD66\uDD69\uDD8F\uDD92\uDD99-\uDD9F\uDDAA-\uDEDF\uDEF7-\uDFAF\uDFB1-\uDFFF]|\uD808[\uDF9A-\uDFFF]|\uD809[\uDC6F-\uDC7F\uDD44-\uDFFF]|[\uD80A\uD80B\uD80E-\uD810\uD812-\uD819\uD824-\uD82B\uD82D\uD82E\uD830-\uD833\uD837\uD839\uD83D\uD83F\uD87B-\uD87D\uD87F\uD885-\uDB3F\uDB41-\uDBFF][\uDC00-\uDFFF]|\uD80D[\uDC2F-\uDFFF]|\uD811[\uDE47-\uDFFF]|\uD81A[\uDE39-\uDE3F\uDE5F\uDE6A-\uDECF\uDEEE\uDEEF\uDEF5-\uDEFF\uDF37-\uDF3F\uDF44-\uDF4F\uDF5A-\uDF62\uDF78-\uDF7C\uDF90-\uDFFF]|\uD81B[\uDC00-\uDE3F\uDE80-\uDEFF\uDF4B-\uDF4E\uDF88-\uDF8E\uDFA0-\uDFDF\uDFE2\uDFE5-\uDFEF\uDFF2-\uDFFF]|\uD821[\uDFF8-\uDFFF]|\uD823[\uDCD6-\uDCFF\uDD09-\uDFFF]|\uD82C[\uDD1F-\uDD4F\uDD53-\uDD63\uDD68-\uDD6F\uDEFC-\uDFFF]|\uD82F[\uDC6B-\uDC6F\uDC7D-\uDC7F\uDC89-\uDC8F\uDC9A-\uDC9C\uDC9F-\uDFFF]|\uD834[\uDC00-\uDD64\uDD6A-\uDD6C\uDD73-\uDD7A\uDD83\uDD84\uDD8C-\uDDA9\uDDAE-\uDE41\uDE45-\uDFFF]|\uD835[\uDC55\uDC9D\uDCA0\uDCA1\uDCA3\uDCA4\uDCA7\uDCA8\uDCAD\uDCBA\uDCBC\uDCC4\uDD06\uDD0B\uDD0C\uDD15\uDD1D\uDD3A\uDD3F\uDD45\uDD47-\uDD49\uDD51\uDEA6\uDEA7\uDEC1\uDEDB\uDEFB\uDF15\uDF35\uDF4F\uDF6F\uDF89\uDFA9\uDFC3\uDFCC\uDFCD]|\uD836[\uDC00-\uDDFF\uDE37-\uDE3A\uDE6D-\uDE74\uDE76-\uDE83\uDE85-\uDE9A\uDEA0\uDEB0-\uDFFF]|\uD838[\uDC07\uDC19\uDC1A\uDC22\uDC25\uDC2B-\uDCFF\uDD2D-\uDD2F\uDD3E\uDD3F\uDD4A-\uDD4D\uDD4F-\uDEBF\uDEFA-\uDFFF]|\uD83A[\uDCC5-\uDCCF\uDCD7-\uDCFF\uDD4C-\uDD4F\uDD5A-\uDFFF]|\uD83B[\uDC00-\uDDFF\uDE04\uDE20\uDE23\uDE25\uDE26\uDE28\uDE33\uDE38\uDE3A\uDE3C-\uDE41\uDE43-\uDE46\uDE48\uDE4A\uDE4C\uDE50\uDE53\uDE55\uDE56\uDE58\uDE5A\uDE5C\uDE5E\uDE60\uDE63\uDE65\uDE66\uDE6B\uDE73\uDE78\uDE7D\uDE7F\uDE8A\uDE9C-\uDEA0\uDEA4\uDEAA\uDEBC-\uDFFF]|\uD83C[\uDC00-\uDD2F\uDD4A-\uDD4F\uDD6A-\uDD6F\uDD8A-\uDFFF]|\uD83E[\uDC00-\uDFEF\uDFFA-\uDFFF]|\uD869[\uDEDE-\uDEFF]|\uD86D[\uDF35-\uDF3F]|\uD86E[\uDC1E\uDC1F]|\uD873[\uDEA2-\uDEAF]|\uD87A[\uDFE1-\uDFFF]|\uD87E[\uDE1E-\uDFFF]|\uD884[\uDF4B-\uDFFF]|\uDB40[\uDC00-\uDCFF\uDDF0-\uDFFF]/g, ja = Object.hasOwnProperty;
class Si {
  /**
   * Create a new slug class.
   */
  constructor() {
    this.occurrences, this.reset();
  }
  /**
   * Generate a unique slug.
  *
  * Tracks previously generated slugs: repeated calls with the same value
  * will result in different slugs.
  * Use the `slug` function to get same slugs.
   *
   * @param  {string} value
   *   String of text to slugify
   * @param  {boolean} [maintainCase=false]
   *   Keep the current case, otherwise make all lowercase
   * @return {string}
   *   A unique slug string
   */
  slug(e, t) {
    const n = this;
    let i = Za(e, t === !0);
    const l = i;
    for (; ja.call(n.occurrences, i); )
      n.occurrences[l]++, i = l + "-" + n.occurrences[l];
    return n.occurrences[i] = 0, i;
  }
  /**
   * Reset - Forget all previous slugs
   *
   * @return void
   */
  reset() {
    this.occurrences = /* @__PURE__ */ Object.create(null);
  }
}
function Za(r, e) {
  return typeof r != "string" ? "" : (e || (r = r.toLowerCase()), r.replace(Ga, "").replace(/ /g, "-"));
}
new Si();
var Cn = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {}, Va = { exports: {} };
(function(r) {
  var e = typeof window < "u" ? window : typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope ? self : {};
  /**
   * Prism: Lightweight, robust, elegant syntax highlighting
   *
   * @license MIT <https://opensource.org/licenses/MIT>
   * @author Lea Verou <https://lea.verou.me>
   * @namespace
   * @public
   */
  var t = function(n) {
    var i = /(?:^|\s)lang(?:uage)?-([\w-]+)(?=\s|$)/i, l = 0, a = {}, o = {
      /**
       * By default, Prism will attempt to highlight all code elements (by calling {@link Prism.highlightAll}) on the
       * current page after the page finished loading. This might be a problem if e.g. you wanted to asynchronously load
       * additional languages or plugins yourself.
       *
       * By setting this value to `true`, Prism will not automatically highlight all code elements on the page.
       *
       * You obviously have to change this value before the automatic highlighting started. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.manual = true;
       * // add a new <script> to load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      manual: n.Prism && n.Prism.manual,
      /**
       * By default, if Prism is in a web worker, it assumes that it is in a worker it created itself, so it uses
       * `addEventListener` to communicate with its parent instance. However, if you're using Prism manually in your
       * own worker, you don't want it to do this.
       *
       * By setting this value to `true`, Prism will not add its own listeners to the worker.
       *
       * You obviously have to change this value before Prism executes. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.disableWorkerMessageHandler = true;
       * // Load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      disableWorkerMessageHandler: n.Prism && n.Prism.disableWorkerMessageHandler,
      /**
       * A namespace for utility methods.
       *
       * All function in this namespace that are not explicitly marked as _public_ are for __internal use only__ and may
       * change or disappear at any time.
       *
       * @namespace
       * @memberof Prism
       */
      util: {
        encode: function h(u) {
          return u instanceof s ? new s(u.type, h(u.content), u.alias) : Array.isArray(u) ? u.map(h) : u.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\u00a0/g, " ");
        },
        /**
         * Returns the name of the type of the given value.
         *
         * @param {any} o
         * @returns {string}
         * @example
         * type(null)      === 'Null'
         * type(undefined) === 'Undefined'
         * type(123)       === 'Number'
         * type('foo')     === 'String'
         * type(true)      === 'Boolean'
         * type([1, 2])    === 'Array'
         * type({})        === 'Object'
         * type(String)    === 'Function'
         * type(/abc+/)    === 'RegExp'
         */
        type: function(h) {
          return Object.prototype.toString.call(h).slice(8, -1);
        },
        /**
         * Returns a unique number for the given object. Later calls will still return the same number.
         *
         * @param {Object} obj
         * @returns {number}
         */
        objId: function(h) {
          return h.__id || Object.defineProperty(h, "__id", { value: ++l }), h.__id;
        },
        /**
         * Creates a deep clone of the given object.
         *
         * The main intended use of this function is to clone language definitions.
         *
         * @param {T} o
         * @param {Record<number, any>} [visited]
         * @returns {T}
         * @template T
         */
        clone: function h(u, f) {
          f = f || {};
          var D, y;
          switch (o.util.type(u)) {
            case "Object":
              if (y = o.util.objId(u), f[y])
                return f[y];
              D = /** @type {Record<string, any>} */
              {}, f[y] = D;
              for (var $ in u)
                u.hasOwnProperty($) && (D[$] = h(u[$], f));
              return (
                /** @type {any} */
                D
              );
            case "Array":
              return y = o.util.objId(u), f[y] ? f[y] : (D = [], f[y] = D, /** @type {Array} */
              /** @type {any} */
              u.forEach(function(S, E) {
                D[E] = h(S, f);
              }), /** @type {any} */
              D);
            default:
              return u;
          }
        },
        /**
         * Returns the Prism language of the given element set by a `language-xxxx` or `lang-xxxx` class.
         *
         * If no language is set for the element or the element is `null` or `undefined`, `none` will be returned.
         *
         * @param {Element} element
         * @returns {string}
         */
        getLanguage: function(h) {
          for (; h; ) {
            var u = i.exec(h.className);
            if (u)
              return u[1].toLowerCase();
            h = h.parentElement;
          }
          return "none";
        },
        /**
         * Sets the Prism `language-xxxx` class of the given element.
         *
         * @param {Element} element
         * @param {string} language
         * @returns {void}
         */
        setLanguage: function(h, u) {
          h.className = h.className.replace(RegExp(i, "gi"), ""), h.classList.add("language-" + u);
        },
        /**
         * Returns the script element that is currently executing.
         *
         * This does __not__ work for line script element.
         *
         * @returns {HTMLScriptElement | null}
         */
        currentScript: function() {
          if (typeof document > "u")
            return null;
          if (document.currentScript && document.currentScript.tagName === "SCRIPT")
            return (
              /** @type {any} */
              document.currentScript
            );
          try {
            throw new Error();
          } catch (D) {
            var h = (/at [^(\r\n]*\((.*):[^:]+:[^:]+\)$/i.exec(D.stack) || [])[1];
            if (h) {
              var u = document.getElementsByTagName("script");
              for (var f in u)
                if (u[f].src == h)
                  return u[f];
            }
            return null;
          }
        },
        /**
         * Returns whether a given class is active for `element`.
         *
         * The class can be activated if `element` or one of its ancestors has the given class and it can be deactivated
         * if `element` or one of its ancestors has the negated version of the given class. The _negated version_ of the
         * given class is just the given class with a `no-` prefix.
         *
         * Whether the class is active is determined by the closest ancestor of `element` (where `element` itself is
         * closest ancestor) that has the given class or the negated version of it. If neither `element` nor any of its
         * ancestors have the given class or the negated version of it, then the default activation will be returned.
         *
         * In the paradoxical situation where the closest ancestor contains __both__ the given class and the negated
         * version of it, the class is considered active.
         *
         * @param {Element} element
         * @param {string} className
         * @param {boolean} [defaultActivation=false]
         * @returns {boolean}
         */
        isActive: function(h, u, f) {
          for (var D = "no-" + u; h; ) {
            var y = h.classList;
            if (y.contains(u))
              return !0;
            if (y.contains(D))
              return !1;
            h = h.parentElement;
          }
          return !!f;
        }
      },
      /**
       * This namespace contains all currently loaded languages and the some helper functions to create and modify languages.
       *
       * @namespace
       * @memberof Prism
       * @public
       */
      languages: {
        /**
         * The grammar for plain, unformatted text.
         */
        plain: a,
        plaintext: a,
        text: a,
        txt: a,
        /**
         * Creates a deep copy of the language with the given id and appends the given tokens.
         *
         * If a token in `redef` also appears in the copied language, then the existing token in the copied language
         * will be overwritten at its original position.
         *
         * ## Best practices
         *
         * Since the position of overwriting tokens (token in `redef` that overwrite tokens in the copied language)
         * doesn't matter, they can technically be in any order. However, this can be confusing to others that trying to
         * understand the language definition because, normally, the order of tokens matters in Prism grammars.
         *
         * Therefore, it is encouraged to order overwriting tokens according to the positions of the overwritten tokens.
         * Furthermore, all non-overwriting tokens should be placed after the overwriting ones.
         *
         * @param {string} id The id of the language to extend. This has to be a key in `Prism.languages`.
         * @param {Grammar} redef The new tokens to append.
         * @returns {Grammar} The new language created.
         * @public
         * @example
         * Prism.languages['css-with-colors'] = Prism.languages.extend('css', {
         *     // Prism.languages.css already has a 'comment' token, so this token will overwrite CSS' 'comment' token
         *     // at its original position
         *     'comment': { ... },
         *     // CSS doesn't have a 'color' token, so this token will be appended
         *     'color': /\b(?:red|green|blue)\b/
         * });
         */
        extend: function(h, u) {
          var f = o.util.clone(o.languages[h]);
          for (var D in u)
            f[D] = u[D];
          return f;
        },
        /**
         * Inserts tokens _before_ another token in a language definition or any other grammar.
         *
         * ## Usage
         *
         * This helper method makes it easy to modify existing languages. For example, the CSS language definition
         * not only defines CSS highlighting for CSS documents, but also needs to define highlighting for CSS embedded
         * in HTML through `<style>` elements. To do this, it needs to modify `Prism.languages.markup` and add the
         * appropriate tokens. However, `Prism.languages.markup` is a regular JavaScript object literal, so if you do
         * this:
         *
         * ```js
         * Prism.languages.markup.style = {
         *     // token
         * };
         * ```
         *
         * then the `style` token will be added (and processed) at the end. `insertBefore` allows you to insert tokens
         * before existing tokens. For the CSS example above, you would use it like this:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'cdata', {
         *     'style': {
         *         // token
         *     }
         * });
         * ```
         *
         * ## Special cases
         *
         * If the grammars of `inside` and `insert` have tokens with the same name, the tokens in `inside`'s grammar
         * will be ignored.
         *
         * This behavior can be used to insert tokens after `before`:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'comment', {
         *     'comment': Prism.languages.markup.comment,
         *     // tokens after 'comment'
         * });
         * ```
         *
         * ## Limitations
         *
         * The main problem `insertBefore` has to solve is iteration order. Since ES2015, the iteration order for object
         * properties is guaranteed to be the insertion order (except for integer keys) but some browsers behave
         * differently when keys are deleted and re-inserted. So `insertBefore` can't be implemented by temporarily
         * deleting properties which is necessary to insert at arbitrary positions.
         *
         * To solve this problem, `insertBefore` doesn't actually insert the given tokens into the target object.
         * Instead, it will create a new object and replace all references to the target object with the new one. This
         * can be done without temporarily deleting properties, so the iteration order is well-defined.
         *
         * However, only references that can be reached from `Prism.languages` or `insert` will be replaced. I.e. if
         * you hold the target object in a variable, then the value of the variable will not change.
         *
         * ```js
         * var oldMarkup = Prism.languages.markup;
         * var newMarkup = Prism.languages.insertBefore('markup', 'comment', { ... });
         *
         * assert(oldMarkup !== Prism.languages.markup);
         * assert(newMarkup === Prism.languages.markup);
         * ```
         *
         * @param {string} inside The property of `root` (e.g. a language id in `Prism.languages`) that contains the
         * object to be modified.
         * @param {string} before The key to insert before.
         * @param {Grammar} insert An object containing the key-value pairs to be inserted.
         * @param {Object<string, any>} [root] The object containing `inside`, i.e. the object that contains the
         * object to be modified.
         *
         * Defaults to `Prism.languages`.
         * @returns {Grammar} The new grammar object.
         * @public
         */
        insertBefore: function(h, u, f, D) {
          D = D || /** @type {any} */
          o.languages;
          var y = D[h], $ = {};
          for (var S in y)
            if (y.hasOwnProperty(S)) {
              if (S == u)
                for (var E in f)
                  f.hasOwnProperty(E) && ($[E] = f[E]);
              f.hasOwnProperty(S) || ($[S] = y[S]);
            }
          var T = D[h];
          return D[h] = $, o.languages.DFS(o.languages, function(N, L) {
            L === T && N != h && (this[N] = $);
          }), $;
        },
        // Traverse a language definition with Depth First Search
        DFS: function h(u, f, D, y) {
          y = y || {};
          var $ = o.util.objId;
          for (var S in u)
            if (u.hasOwnProperty(S)) {
              f.call(u, S, u[S], D || S);
              var E = u[S], T = o.util.type(E);
              T === "Object" && !y[$(E)] ? (y[$(E)] = !0, h(E, f, null, y)) : T === "Array" && !y[$(E)] && (y[$(E)] = !0, h(E, f, S, y));
            }
        }
      },
      plugins: {},
      /**
       * This is the most high-level function in Prism’s API.
       * It fetches all the elements that have a `.language-xxxx` class and then calls {@link Prism.highlightElement} on
       * each one of them.
       *
       * This is equivalent to `Prism.highlightAllUnder(document, async, callback)`.
       *
       * @param {boolean} [async=false] Same as in {@link Prism.highlightAllUnder}.
       * @param {HighlightCallback} [callback] Same as in {@link Prism.highlightAllUnder}.
       * @memberof Prism
       * @public
       */
      highlightAll: function(h, u) {
        o.highlightAllUnder(document, h, u);
      },
      /**
       * Fetches all the descendants of `container` that have a `.language-xxxx` class and then calls
       * {@link Prism.highlightElement} on each one of them.
       *
       * The following hooks will be run:
       * 1. `before-highlightall`
       * 2. `before-all-elements-highlight`
       * 3. All hooks of {@link Prism.highlightElement} for each element.
       *
       * @param {ParentNode} container The root element, whose descendants that have a `.language-xxxx` class will be highlighted.
       * @param {boolean} [async=false] Whether each element is to be highlighted asynchronously using Web Workers.
       * @param {HighlightCallback} [callback] An optional callback to be invoked on each element after its highlighting is done.
       * @memberof Prism
       * @public
       */
      highlightAllUnder: function(h, u, f) {
        var D = {
          callback: f,
          container: h,
          selector: 'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'
        };
        o.hooks.run("before-highlightall", D), D.elements = Array.prototype.slice.apply(D.container.querySelectorAll(D.selector)), o.hooks.run("before-all-elements-highlight", D);
        for (var y = 0, $; $ = D.elements[y++]; )
          o.highlightElement($, u === !0, D.callback);
      },
      /**
       * Highlights the code inside a single element.
       *
       * The following hooks will be run:
       * 1. `before-sanity-check`
       * 2. `before-highlight`
       * 3. All hooks of {@link Prism.highlight}. These hooks will be run by an asynchronous worker if `async` is `true`.
       * 4. `before-insert`
       * 5. `after-highlight`
       * 6. `complete`
       *
       * Some the above hooks will be skipped if the element doesn't contain any text or there is no grammar loaded for
       * the element's language.
       *
       * @param {Element} element The element containing the code.
       * It must have a class of `language-xxxx` to be processed, where `xxxx` is a valid language identifier.
       * @param {boolean} [async=false] Whether the element is to be highlighted asynchronously using Web Workers
       * to improve performance and avoid blocking the UI when highlighting very large chunks of code. This option is
       * [disabled by default](https://prismjs.com/faq.html#why-is-asynchronous-highlighting-disabled-by-default).
       *
       * Note: All language definitions required to highlight the code must be included in the main `prism.js` file for
       * asynchronous highlighting to work. You can build your own bundle on the
       * [Download page](https://prismjs.com/download.html).
       * @param {HighlightCallback} [callback] An optional callback to be invoked after the highlighting is done.
       * Mostly useful when `async` is `true`, since in that case, the highlighting is done asynchronously.
       * @memberof Prism
       * @public
       */
      highlightElement: function(h, u, f) {
        var D = o.util.getLanguage(h), y = o.languages[D];
        o.util.setLanguage(h, D);
        var $ = h.parentElement;
        $ && $.nodeName.toLowerCase() === "pre" && o.util.setLanguage($, D);
        var S = h.textContent, E = {
          element: h,
          language: D,
          grammar: y,
          code: S
        };
        function T(L) {
          E.highlightedCode = L, o.hooks.run("before-insert", E), E.element.innerHTML = E.highlightedCode, o.hooks.run("after-highlight", E), o.hooks.run("complete", E), f && f.call(E.element);
        }
        if (o.hooks.run("before-sanity-check", E), $ = E.element.parentElement, $ && $.nodeName.toLowerCase() === "pre" && !$.hasAttribute("tabindex") && $.setAttribute("tabindex", "0"), !E.code) {
          o.hooks.run("complete", E), f && f.call(E.element);
          return;
        }
        if (o.hooks.run("before-highlight", E), !E.grammar) {
          T(o.util.encode(E.code));
          return;
        }
        if (u && n.Worker) {
          var N = new Worker(o.filename);
          N.onmessage = function(L) {
            T(L.data);
          }, N.postMessage(JSON.stringify({
            language: E.language,
            code: E.code,
            immediateClose: !0
          }));
        } else
          T(o.highlight(E.code, E.grammar, E.language));
      },
      /**
       * Low-level function, only use if you know what you’re doing. It accepts a string of text as input
       * and the language definitions to use, and returns a string with the HTML produced.
       *
       * The following hooks will be run:
       * 1. `before-tokenize`
       * 2. `after-tokenize`
       * 3. `wrap`: On each {@link Token}.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @param {string} language The name of the language definition passed to `grammar`.
       * @returns {string} The highlighted HTML.
       * @memberof Prism
       * @public
       * @example
       * Prism.highlight('var foo = true;', Prism.languages.javascript, 'javascript');
       */
      highlight: function(h, u, f) {
        var D = {
          code: h,
          grammar: u,
          language: f
        };
        if (o.hooks.run("before-tokenize", D), !D.grammar)
          throw new Error('The language "' + D.language + '" has no grammar.');
        return D.tokens = o.tokenize(D.code, D.grammar), o.hooks.run("after-tokenize", D), s.stringify(o.util.encode(D.tokens), D.language);
      },
      /**
       * This is the heart of Prism, and the most low-level function you can use. It accepts a string of text as input
       * and the language definitions to use, and returns an array with the tokenized code.
       *
       * When the language definition includes nested tokens, the function is called recursively on each of these tokens.
       *
       * This method could be useful in other contexts as well, as a very crude parser.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @returns {TokenStream} An array of strings and tokens, a token stream.
       * @memberof Prism
       * @public
       * @example
       * let code = `var foo = 0;`;
       * let tokens = Prism.tokenize(code, Prism.languages.javascript);
       * tokens.forEach(token => {
       *     if (token instanceof Prism.Token && token.type === 'number') {
       *         console.log(`Found numeric literal: ${token.content}`);
       *     }
       * });
       */
      tokenize: function(h, u) {
        var f = u.rest;
        if (f) {
          for (var D in f)
            u[D] = f[D];
          delete u.rest;
        }
        var y = new p();
        return d(y, y.head, h), c(h, y, u, y.head, 0), g(y);
      },
      /**
       * @namespace
       * @memberof Prism
       * @public
       */
      hooks: {
        all: {},
        /**
         * Adds the given callback to the list of callbacks for the given hook.
         *
         * The callback will be invoked when the hook it is registered for is run.
         * Hooks are usually directly run by a highlight function but you can also run hooks yourself.
         *
         * One callback function can be registered to multiple hooks and the same hook multiple times.
         *
         * @param {string} name The name of the hook.
         * @param {HookCallback} callback The callback function which is given environment variables.
         * @public
         */
        add: function(h, u) {
          var f = o.hooks.all;
          f[h] = f[h] || [], f[h].push(u);
        },
        /**
         * Runs a hook invoking all registered callbacks with the given environment variables.
         *
         * Callbacks will be invoked synchronously and in the order in which they were registered.
         *
         * @param {string} name The name of the hook.
         * @param {Object<string, any>} env The environment variables of the hook passed to all callbacks registered.
         * @public
         */
        run: function(h, u) {
          var f = o.hooks.all[h];
          if (!(!f || !f.length))
            for (var D = 0, y; y = f[D++]; )
              y(u);
        }
      },
      Token: s
    };
    n.Prism = o;
    function s(h, u, f, D) {
      this.type = h, this.content = u, this.alias = f, this.length = (D || "").length | 0;
    }
    s.stringify = function h(u, f) {
      if (typeof u == "string")
        return u;
      if (Array.isArray(u)) {
        var D = "";
        return u.forEach(function(T) {
          D += h(T, f);
        }), D;
      }
      var y = {
        type: u.type,
        content: h(u.content, f),
        tag: "span",
        classes: ["token", u.type],
        attributes: {},
        language: f
      }, $ = u.alias;
      $ && (Array.isArray($) ? Array.prototype.push.apply(y.classes, $) : y.classes.push($)), o.hooks.run("wrap", y);
      var S = "";
      for (var E in y.attributes)
        S += " " + E + '="' + (y.attributes[E] || "").replace(/"/g, "&quot;") + '"';
      return "<" + y.tag + ' class="' + y.classes.join(" ") + '"' + S + ">" + y.content + "</" + y.tag + ">";
    };
    function _(h, u, f, D) {
      h.lastIndex = u;
      var y = h.exec(f);
      if (y && D && y[1]) {
        var $ = y[1].length;
        y.index += $, y[0] = y[0].slice($);
      }
      return y;
    }
    function c(h, u, f, D, y, $) {
      for (var S in f)
        if (!(!f.hasOwnProperty(S) || !f[S])) {
          var E = f[S];
          E = Array.isArray(E) ? E : [E];
          for (var T = 0; T < E.length; ++T) {
            if ($ && $.cause == S + "," + T)
              return;
            var N = E[T], L = N.inside, ue = !!N.lookbehind, te = !!N.greedy, Re = N.alias;
            if (te && !N.pattern.global) {
              var X = N.pattern.toString().match(/[imsuy]*$/)[0];
              N.pattern = RegExp(N.pattern.source, X + "g");
            }
            for (var ce = N.pattern || N, q = D.next, j = y; q !== u.tail && !($ && j >= $.reach); j += q.value.length, q = q.next) {
              var be = q.value;
              if (u.length > h.length)
                return;
              if (!(be instanceof s)) {
                var w = 1, U;
                if (te) {
                  if (U = _(ce, j, h, ue), !U || U.index >= h.length)
                    break;
                  var Ae = U.index, Ee = U.index + U[0].length, W = j;
                  for (W += q.value.length; Ae >= W; )
                    q = q.next, W += q.value.length;
                  if (W -= q.value.length, j = W, q.value instanceof s)
                    continue;
                  for (var ve = q; ve !== u.tail && (W < Ee || typeof ve.value == "string"); ve = ve.next)
                    w++, W += ve.value.length;
                  w--, be = h.slice(j, W), U.index -= j;
                } else if (U = _(ce, 0, be, ue), !U)
                  continue;
                var Ae = U.index, Me = U[0], C = be.slice(0, Ae), fn = be.slice(Ae + Me.length), St = j + be.length;
                $ && St > $.reach && ($.reach = St);
                var ut = q.prev;
                C && (ut = d(u, ut, C), j += C.length), m(u, ut, w);
                var Hi = new s(S, L ? o.tokenize(Me, L) : Me, Re, Me);
                if (q = d(u, ut, Hi), fn && d(u, q, fn), w > 1) {
                  var Tt = {
                    cause: S + "," + T,
                    reach: St
                  };
                  c(h, u, f, q.prev, j, Tt), $ && Tt.reach > $.reach && ($.reach = Tt.reach);
                }
              }
            }
          }
        }
    }
    function p() {
      var h = { value: null, prev: null, next: null }, u = { value: null, prev: h, next: null };
      h.next = u, this.head = h, this.tail = u, this.length = 0;
    }
    function d(h, u, f) {
      var D = u.next, y = { value: f, prev: u, next: D };
      return u.next = y, D.prev = y, h.length++, y;
    }
    function m(h, u, f) {
      for (var D = u.next, y = 0; y < f && D !== h.tail; y++)
        D = D.next;
      u.next = D, D.prev = u, h.length -= y;
    }
    function g(h) {
      for (var u = [], f = h.head.next; f !== h.tail; )
        u.push(f.value), f = f.next;
      return u;
    }
    if (!n.document)
      return n.addEventListener && (o.disableWorkerMessageHandler || n.addEventListener("message", function(h) {
        var u = JSON.parse(h.data), f = u.language, D = u.code, y = u.immediateClose;
        n.postMessage(o.highlight(D, o.languages[f], f)), y && n.close();
      }, !1)), o;
    var v = o.util.currentScript();
    v && (o.filename = v.src, v.hasAttribute("data-manual") && (o.manual = !0));
    function b() {
      o.manual || o.highlightAll();
    }
    if (!o.manual) {
      var F = document.readyState;
      F === "loading" || F === "interactive" && v && v.defer ? document.addEventListener("DOMContentLoaded", b) : window.requestAnimationFrame ? window.requestAnimationFrame(b) : window.setTimeout(b, 16);
    }
    return o;
  }(e);
  r.exports && (r.exports = t), typeof Cn < "u" && (Cn.Prism = t), t.languages.markup = {
    comment: {
      pattern: /<!--(?:(?!<!--)[\s\S])*?-->/,
      greedy: !0
    },
    prolog: {
      pattern: /<\?[\s\S]+?\?>/,
      greedy: !0
    },
    doctype: {
      // https://www.w3.org/TR/xml/#NT-doctypedecl
      pattern: /<!DOCTYPE(?:[^>"'[\]]|"[^"]*"|'[^']*')+(?:\[(?:[^<"'\]]|"[^"]*"|'[^']*'|<(?!!--)|<!--(?:[^-]|-(?!->))*-->)*\]\s*)?>/i,
      greedy: !0,
      inside: {
        "internal-subset": {
          pattern: /(^[^\[]*\[)[\s\S]+(?=\]>$)/,
          lookbehind: !0,
          greedy: !0,
          inside: null
          // see below
        },
        string: {
          pattern: /"[^"]*"|'[^']*'/,
          greedy: !0
        },
        punctuation: /^<!|>$|[[\]]/,
        "doctype-tag": /^DOCTYPE/i,
        name: /[^\s<>'"]+/
      }
    },
    cdata: {
      pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
      greedy: !0
    },
    tag: {
      pattern: /<\/?(?!\d)[^\s>\/=$<%]+(?:\s(?:\s*[^\s>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))|(?=[\s/>])))+)?\s*\/?>/,
      greedy: !0,
      inside: {
        tag: {
          pattern: /^<\/?[^\s>\/]+/,
          inside: {
            punctuation: /^<\/?/,
            namespace: /^[^\s>\/:]+:/
          }
        },
        "special-attr": [],
        "attr-value": {
          pattern: /=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+)/,
          inside: {
            punctuation: [
              {
                pattern: /^=/,
                alias: "attr-equals"
              },
              {
                pattern: /^(\s*)["']|["']$/,
                lookbehind: !0
              }
            ]
          }
        },
        punctuation: /\/?>/,
        "attr-name": {
          pattern: /[^\s>\/]+/,
          inside: {
            namespace: /^[^\s>\/:]+:/
          }
        }
      }
    },
    entity: [
      {
        pattern: /&[\da-z]{1,8};/i,
        alias: "named-entity"
      },
      /&#x?[\da-f]{1,8};/i
    ]
  }, t.languages.markup.tag.inside["attr-value"].inside.entity = t.languages.markup.entity, t.languages.markup.doctype.inside["internal-subset"].inside = t.languages.markup, t.hooks.add("wrap", function(n) {
    n.type === "entity" && (n.attributes.title = n.content.replace(/&amp;/, "&"));
  }), Object.defineProperty(t.languages.markup.tag, "addInlined", {
    /**
     * Adds an inlined language to markup.
     *
     * An example of an inlined language is CSS with `<style>` tags.
     *
     * @param {string} tagName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addInlined('style', 'css');
     */
    value: function(i, l) {
      var a = {};
      a["language-" + l] = {
        pattern: /(^<!\[CDATA\[)[\s\S]+?(?=\]\]>$)/i,
        lookbehind: !0,
        inside: t.languages[l]
      }, a.cdata = /^<!\[CDATA\[|\]\]>$/i;
      var o = {
        "included-cdata": {
          pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
          inside: a
        }
      };
      o["language-" + l] = {
        pattern: /[\s\S]+/,
        inside: t.languages[l]
      };
      var s = {};
      s[i] = {
        pattern: RegExp(/(<__[^>]*>)(?:<!\[CDATA\[(?:[^\]]|\](?!\]>))*\]\]>|(?!<!\[CDATA\[)[\s\S])*?(?=<\/__>)/.source.replace(/__/g, function() {
          return i;
        }), "i"),
        lookbehind: !0,
        greedy: !0,
        inside: o
      }, t.languages.insertBefore("markup", "cdata", s);
    }
  }), Object.defineProperty(t.languages.markup.tag, "addAttribute", {
    /**
     * Adds an pattern to highlight languages embedded in HTML attributes.
     *
     * An example of an inlined language is CSS with `style` attributes.
     *
     * @param {string} attrName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addAttribute('style', 'css');
     */
    value: function(n, i) {
      t.languages.markup.tag.inside["special-attr"].push({
        pattern: RegExp(
          /(^|["'\s])/.source + "(?:" + n + ")" + /\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))/.source,
          "i"
        ),
        lookbehind: !0,
        inside: {
          "attr-name": /^[^\s=]+/,
          "attr-value": {
            pattern: /=[\s\S]+/,
            inside: {
              value: {
                pattern: /(^=\s*(["']|(?!["'])))\S[\s\S]*(?=\2$)/,
                lookbehind: !0,
                alias: [i, "language-" + i],
                inside: t.languages[i]
              },
              punctuation: [
                {
                  pattern: /^=/,
                  alias: "attr-equals"
                },
                /"|'/
              ]
            }
          }
        }
      });
    }
  }), t.languages.html = t.languages.markup, t.languages.mathml = t.languages.markup, t.languages.svg = t.languages.markup, t.languages.xml = t.languages.extend("markup", {}), t.languages.ssml = t.languages.xml, t.languages.atom = t.languages.xml, t.languages.rss = t.languages.xml, function(n) {
    var i = /(?:"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n])*')/;
    n.languages.css = {
      comment: /\/\*[\s\S]*?\*\//,
      atrule: {
        pattern: RegExp("@[\\w-](?:" + /[^;{\s"']|\s+(?!\s)/.source + "|" + i.source + ")*?" + /(?:;|(?=\s*\{))/.source),
        inside: {
          rule: /^@[\w-]+/,
          "selector-function-argument": {
            pattern: /(\bselector\s*\(\s*(?![\s)]))(?:[^()\s]|\s+(?![\s)])|\((?:[^()]|\([^()]*\))*\))+(?=\s*\))/,
            lookbehind: !0,
            alias: "selector"
          },
          keyword: {
            pattern: /(^|[^\w-])(?:and|not|only|or)(?![\w-])/,
            lookbehind: !0
          }
          // See rest below
        }
      },
      url: {
        // https://drafts.csswg.org/css-values-3/#urls
        pattern: RegExp("\\burl\\((?:" + i.source + "|" + /(?:[^\\\r\n()"']|\\[\s\S])*/.source + ")\\)", "i"),
        greedy: !0,
        inside: {
          function: /^url/i,
          punctuation: /^\(|\)$/,
          string: {
            pattern: RegExp("^" + i.source + "$"),
            alias: "url"
          }
        }
      },
      selector: {
        pattern: RegExp(`(^|[{}\\s])[^{}\\s](?:[^{};"'\\s]|\\s+(?![\\s{])|` + i.source + ")*(?=\\s*\\{)"),
        lookbehind: !0
      },
      string: {
        pattern: i,
        greedy: !0
      },
      property: {
        pattern: /(^|[^-\w\xA0-\uFFFF])(?!\s)[-_a-z\xA0-\uFFFF](?:(?!\s)[-\w\xA0-\uFFFF])*(?=\s*:)/i,
        lookbehind: !0
      },
      important: /!important\b/i,
      function: {
        pattern: /(^|[^-a-z0-9])[-a-z0-9]+(?=\()/i,
        lookbehind: !0
      },
      punctuation: /[(){};:,]/
    }, n.languages.css.atrule.inside.rest = n.languages.css;
    var l = n.languages.markup;
    l && (l.tag.addInlined("style", "css"), l.tag.addAttribute("style", "css"));
  }(t), t.languages.clike = {
    comment: [
      {
        pattern: /(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,
        lookbehind: !0,
        greedy: !0
      },
      {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0,
        greedy: !0
      }
    ],
    string: {
      pattern: /(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,
      greedy: !0
    },
    "class-name": {
      pattern: /(\b(?:class|extends|implements|instanceof|interface|new|trait)\s+|\bcatch\s+\()[\w.\\]+/i,
      lookbehind: !0,
      inside: {
        punctuation: /[.\\]/
      }
    },
    keyword: /\b(?:break|catch|continue|do|else|finally|for|function|if|in|instanceof|new|null|return|throw|try|while)\b/,
    boolean: /\b(?:false|true)\b/,
    function: /\b\w+(?=\()/,
    number: /\b0x[\da-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,
    operator: /[<>]=?|[!=]=?=?|--?|\+\+?|&&?|\|\|?|[?*/~^%]/,
    punctuation: /[{}[\];(),.:]/
  }, t.languages.javascript = t.languages.extend("clike", {
    "class-name": [
      t.languages.clike["class-name"],
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$A-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\.(?:constructor|prototype))/,
        lookbehind: !0
      }
    ],
    keyword: [
      {
        pattern: /((?:^|\})\s*)catch\b/,
        lookbehind: !0
      },
      {
        pattern: /(^|[^.]|\.\.\.\s*)\b(?:as|assert(?=\s*\{)|async(?=\s*(?:function\b|\(|[$\w\xA0-\uFFFF]|$))|await|break|case|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally(?=\s*(?:\{|$))|for|from(?=\s*(?:['"]|$))|function|(?:get|set)(?=\s*(?:[#\[$\w\xA0-\uFFFF]|$))|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)\b/,
        lookbehind: !0
      }
    ],
    // Allow for all non-ASCII characters (See http://stackoverflow.com/a/2008444)
    function: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*(?:\.\s*(?:apply|bind|call)\s*)?\()/,
    number: {
      pattern: RegExp(
        /(^|[^\w$])/.source + "(?:" + // constant
        (/NaN|Infinity/.source + "|" + // binary integer
        /0[bB][01]+(?:_[01]+)*n?/.source + "|" + // octal integer
        /0[oO][0-7]+(?:_[0-7]+)*n?/.source + "|" + // hexadecimal integer
        /0[xX][\dA-Fa-f]+(?:_[\dA-Fa-f]+)*n?/.source + "|" + // decimal bigint
        /\d+(?:_\d+)*n/.source + "|" + // decimal number (integer or float) but no bigint
        /(?:\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\.\d+(?:_\d+)*)(?:[Ee][+-]?\d+(?:_\d+)*)?/.source) + ")" + /(?![\w$])/.source
      ),
      lookbehind: !0
    },
    operator: /--|\+\+|\*\*=?|=>|&&=?|\|\|=?|[!=]==|<<=?|>>>?=?|[-+*/%&|^!=<>]=?|\.{3}|\?\?=?|\?\.?|[~:]/
  }), t.languages.javascript["class-name"][0].pattern = /(\b(?:class|extends|implements|instanceof|interface|new)\s+)[\w.\\]+/, t.languages.insertBefore("javascript", "keyword", {
    regex: {
      pattern: RegExp(
        // lookbehind
        // eslint-disable-next-line regexp/no-dupe-characters-character-class
        /((?:^|[^$\w\xA0-\uFFFF."'\])\s]|\b(?:return|yield))\s*)/.source + // Regex pattern:
        // There are 2 regex patterns here. The RegExp set notation proposal added support for nested character
        // classes if the `v` flag is present. Unfortunately, nested CCs are both context-free and incompatible
        // with the only syntax, so we have to define 2 different regex patterns.
        /\//.source + "(?:" + /(?:\[(?:[^\]\\\r\n]|\\.)*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}/.source + "|" + // `v` flag syntax. This supports 3 levels of nested character classes.
        /(?:\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.)*\])*\])*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}v[dgimyus]{0,7}/.source + ")" + // lookahead
        /(?=(?:\s|\/\*(?:[^*]|\*(?!\/))*\*\/)*(?:$|[\r\n,.;:})\]]|\/\/))/.source
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        "regex-source": {
          pattern: /^(\/)[\s\S]+(?=\/[a-z]*$)/,
          lookbehind: !0,
          alias: "language-regex",
          inside: t.languages.regex
        },
        "regex-delimiter": /^\/|\/$/,
        "regex-flags": /^[a-z]+$/
      }
    },
    // This must be declared before keyword because we use "function" inside the look-forward
    "function-variable": {
      pattern: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*[=:]\s*(?:async\s*)?(?:\bfunction\b|(?:\((?:[^()]|\([^()]*\))*\)|(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)\s*=>))/,
      alias: "function"
    },
    parameter: [
      {
        pattern: /(function(?:\s+(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)?\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\))/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$a-z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*=>)/i,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*=>)/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /((?:\b|\s|^)(?!(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)(?![$\w\xA0-\uFFFF]))(?:(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*\s*)\(\s*|\]\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*\{)/,
        lookbehind: !0,
        inside: t.languages.javascript
      }
    ],
    constant: /\b[A-Z](?:[A-Z_]|\dx?)*\b/
  }), t.languages.insertBefore("javascript", "string", {
    hashbang: {
      pattern: /^#!.*/,
      greedy: !0,
      alias: "comment"
    },
    "template-string": {
      pattern: /`(?:\\[\s\S]|\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}|(?!\$\{)[^\\`])*`/,
      greedy: !0,
      inside: {
        "template-punctuation": {
          pattern: /^`|`$/,
          alias: "string"
        },
        interpolation: {
          pattern: /((?:^|[^\\])(?:\\{2})*)\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}/,
          lookbehind: !0,
          inside: {
            "interpolation-punctuation": {
              pattern: /^\$\{|\}$/,
              alias: "punctuation"
            },
            rest: t.languages.javascript
          }
        },
        string: /[\s\S]+/
      }
    },
    "string-property": {
      pattern: /((?:^|[,{])[ \t]*)(["'])(?:\\(?:\r\n|[\s\S])|(?!\2)[^\\\r\n])*\2(?=\s*:)/m,
      lookbehind: !0,
      greedy: !0,
      alias: "property"
    }
  }), t.languages.insertBefore("javascript", "operator", {
    "literal-property": {
      pattern: /((?:^|[,{])[ \t]*)(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*:)/m,
      lookbehind: !0,
      alias: "property"
    }
  }), t.languages.markup && (t.languages.markup.tag.addInlined("script", "javascript"), t.languages.markup.tag.addAttribute(
    /on(?:abort|blur|change|click|composition(?:end|start|update)|dblclick|error|focus(?:in|out)?|key(?:down|up)|load|mouse(?:down|enter|leave|move|out|over|up)|reset|resize|scroll|select|slotchange|submit|unload|wheel)/.source,
    "javascript"
  )), t.languages.js = t.languages.javascript, function() {
    if (typeof t > "u" || typeof document > "u")
      return;
    Element.prototype.matches || (Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector);
    var n = "Loading…", i = function(v, b) {
      return "✖ Error " + v + " while fetching file: " + b;
    }, l = "✖ Error: File does not exist or is empty", a = {
      js: "javascript",
      py: "python",
      rb: "ruby",
      ps1: "powershell",
      psm1: "powershell",
      sh: "bash",
      bat: "batch",
      h: "c",
      tex: "latex"
    }, o = "data-src-status", s = "loading", _ = "loaded", c = "failed", p = "pre[data-src]:not([" + o + '="' + _ + '"]):not([' + o + '="' + s + '"])';
    function d(v, b, F) {
      var h = new XMLHttpRequest();
      h.open("GET", v, !0), h.onreadystatechange = function() {
        h.readyState == 4 && (h.status < 400 && h.responseText ? b(h.responseText) : h.status >= 400 ? F(i(h.status, h.statusText)) : F(l));
      }, h.send(null);
    }
    function m(v) {
      var b = /^\s*(\d+)\s*(?:(,)\s*(?:(\d+)\s*)?)?$/.exec(v || "");
      if (b) {
        var F = Number(b[1]), h = b[2], u = b[3];
        return h ? u ? [F, Number(u)] : [F, void 0] : [F, F];
      }
    }
    t.hooks.add("before-highlightall", function(v) {
      v.selector += ", " + p;
    }), t.hooks.add("before-sanity-check", function(v) {
      var b = (
        /** @type {HTMLPreElement} */
        v.element
      );
      if (b.matches(p)) {
        v.code = "", b.setAttribute(o, s);
        var F = b.appendChild(document.createElement("CODE"));
        F.textContent = n;
        var h = b.getAttribute("data-src"), u = v.language;
        if (u === "none") {
          var f = (/\.(\w+)$/.exec(h) || [, "none"])[1];
          u = a[f] || f;
        }
        t.util.setLanguage(F, u), t.util.setLanguage(b, u);
        var D = t.plugins.autoloader;
        D && D.loadLanguages(u), d(
          h,
          function(y) {
            b.setAttribute(o, _);
            var $ = m(b.getAttribute("data-range"));
            if ($) {
              var S = y.split(/\r\n?|\n/g), E = $[0], T = $[1] == null ? S.length : $[1];
              E < 0 && (E += S.length), E = Math.max(0, Math.min(E - 1, S.length)), T < 0 && (T += S.length), T = Math.max(0, Math.min(T, S.length)), y = S.slice(E, T).join(`
`), b.hasAttribute("data-start") || b.setAttribute("data-start", String(E + 1));
            }
            F.textContent = y, t.highlightElement(F);
          },
          function(y) {
            b.setAttribute(o, c), F.textContent = y;
          }
        );
      }
    }), t.plugins.fileHighlight = {
      /**
       * Executes the File Highlight plugin for all matching `pre` elements under the given container.
       *
       * Note: Elements which are already loaded or currently loading will not be touched by this method.
       *
       * @param {ParentNode} [container=document]
       */
      highlight: function(b) {
        for (var F = (b || document).querySelectorAll(p), h = 0, u; u = F[h++]; )
          t.highlightElement(u);
      }
    };
    var g = !1;
    t.fileHighlight = function() {
      g || (console.warn("Prism.fileHighlight is deprecated. Use `Prism.plugins.fileHighlight.highlight` instead."), g = !0), t.plugins.fileHighlight.highlight.apply(this, arguments);
    };
  }();
})(Va);
Prism.languages.python = {
  comment: {
    pattern: /(^|[^\\])#.*/,
    lookbehind: !0,
    greedy: !0
  },
  "string-interpolation": {
    pattern: /(?:f|fr|rf)(?:("""|''')[\s\S]*?\1|("|')(?:\\.|(?!\2)[^\\\r\n])*\2)/i,
    greedy: !0,
    inside: {
      interpolation: {
        // "{" <expression> <optional "!s", "!r", or "!a"> <optional ":" format specifier> "}"
        pattern: /((?:^|[^{])(?:\{\{)*)\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}])+\})+\})+\}/,
        lookbehind: !0,
        inside: {
          "format-spec": {
            pattern: /(:)[^:(){}]+(?=\}$)/,
            lookbehind: !0
          },
          "conversion-option": {
            pattern: /![sra](?=[:}]$)/,
            alias: "punctuation"
          },
          rest: null
        }
      },
      string: /[\s\S]+/
    }
  },
  "triple-quoted-string": {
    pattern: /(?:[rub]|br|rb)?("""|''')[\s\S]*?\1/i,
    greedy: !0,
    alias: "string"
  },
  string: {
    pattern: /(?:[rub]|br|rb)?("|')(?:\\.|(?!\1)[^\\\r\n])*\1/i,
    greedy: !0
  },
  function: {
    pattern: /((?:^|\s)def[ \t]+)[a-zA-Z_]\w*(?=\s*\()/g,
    lookbehind: !0
  },
  "class-name": {
    pattern: /(\bclass\s+)\w+/i,
    lookbehind: !0
  },
  decorator: {
    pattern: /(^[\t ]*)@\w+(?:\.\w+)*/m,
    lookbehind: !0,
    alias: ["annotation", "punctuation"],
    inside: {
      punctuation: /\./
    }
  },
  keyword: /\b(?:_(?=\s*:)|and|as|assert|async|await|break|case|class|continue|def|del|elif|else|except|exec|finally|for|from|global|if|import|in|is|lambda|match|nonlocal|not|or|pass|print|raise|return|try|while|with|yield)\b/,
  builtin: /\b(?:__import__|abs|all|any|apply|ascii|basestring|bin|bool|buffer|bytearray|bytes|callable|chr|classmethod|cmp|coerce|compile|complex|delattr|dict|dir|divmod|enumerate|eval|execfile|file|filter|float|format|frozenset|getattr|globals|hasattr|hash|help|hex|id|input|int|intern|isinstance|issubclass|iter|len|list|locals|long|map|max|memoryview|min|next|object|oct|open|ord|pow|property|range|raw_input|reduce|reload|repr|reversed|round|set|setattr|slice|sorted|staticmethod|str|sum|super|tuple|type|unichr|unicode|vars|xrange|zip)\b/,
  boolean: /\b(?:False|None|True)\b/,
  number: /\b0(?:b(?:_?[01])+|o(?:_?[0-7])+|x(?:_?[a-f0-9])+)\b|(?:\b\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\B\.\d+(?:_\d+)*)(?:e[+-]?\d+(?:_\d+)*)?j?(?!\w)/i,
  operator: /[-+%=]=?|!=|:=|\*\*?=?|\/\/?=?|<[<=>]?|>[=>]?|[&|^~]/,
  punctuation: /[{}[\];(),.:]/
};
Prism.languages.python["string-interpolation"].inside.interpolation.inside.rest = Prism.languages.python;
Prism.languages.py = Prism.languages.python;
(function(r) {
  var e = /\\(?:[^a-z()[\]]|[a-z*]+)/i, t = {
    "equation-command": {
      pattern: e,
      alias: "regex"
    }
  };
  r.languages.latex = {
    comment: /%.*/,
    // the verbatim environment prints whitespace to the document
    cdata: {
      pattern: /(\\begin\{((?:lstlisting|verbatim)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
      lookbehind: !0
    },
    /*
     * equations can be between $$ $$ or $ $ or \( \) or \[ \]
     * (all are multiline)
     */
    equation: [
      {
        pattern: /\$\$(?:\\[\s\S]|[^\\$])+\$\$|\$(?:\\[\s\S]|[^\\$])+\$|\\\([\s\S]*?\\\)|\\\[[\s\S]*?\\\]/,
        inside: t,
        alias: "string"
      },
      {
        pattern: /(\\begin\{((?:align|eqnarray|equation|gather|math|multline)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
        lookbehind: !0,
        inside: t,
        alias: "string"
      }
    ],
    /*
     * arguments which are keywords or references are highlighted
     * as keywords
     */
    keyword: {
      pattern: /(\\(?:begin|cite|documentclass|end|label|ref|usepackage)(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    url: {
      pattern: /(\\url\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    /*
     * section or chapter headlines are highlighted as bold so that
     * they stand out more
     */
    headline: {
      pattern: /(\\(?:chapter|frametitle|paragraph|part|section|subparagraph|subsection|subsubparagraph|subsubsection|subsubsubparagraph)\*?(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0,
      alias: "class-name"
    },
    function: {
      pattern: e,
      alias: "selector"
    },
    punctuation: /[[\]{}&]/
  }, r.languages.tex = r.languages.latex, r.languages.context = r.languages.latex;
})(Prism);
(function(r) {
  var e = "\\b(?:BASH|BASHOPTS|BASH_ALIASES|BASH_ARGC|BASH_ARGV|BASH_CMDS|BASH_COMPLETION_COMPAT_DIR|BASH_LINENO|BASH_REMATCH|BASH_SOURCE|BASH_VERSINFO|BASH_VERSION|COLORTERM|COLUMNS|COMP_WORDBREAKS|DBUS_SESSION_BUS_ADDRESS|DEFAULTS_PATH|DESKTOP_SESSION|DIRSTACK|DISPLAY|EUID|GDMSESSION|GDM_LANG|GNOME_KEYRING_CONTROL|GNOME_KEYRING_PID|GPG_AGENT_INFO|GROUPS|HISTCONTROL|HISTFILE|HISTFILESIZE|HISTSIZE|HOME|HOSTNAME|HOSTTYPE|IFS|INSTANCE|JOB|LANG|LANGUAGE|LC_ADDRESS|LC_ALL|LC_IDENTIFICATION|LC_MEASUREMENT|LC_MONETARY|LC_NAME|LC_NUMERIC|LC_PAPER|LC_TELEPHONE|LC_TIME|LESSCLOSE|LESSOPEN|LINES|LOGNAME|LS_COLORS|MACHTYPE|MAILCHECK|MANDATORY_PATH|NO_AT_BRIDGE|OLDPWD|OPTERR|OPTIND|ORBIT_SOCKETDIR|OSTYPE|PAPERSIZE|PATH|PIPESTATUS|PPID|PS1|PS2|PS3|PS4|PWD|RANDOM|REPLY|SECONDS|SELINUX_INIT|SESSION|SESSIONTYPE|SESSION_MANAGER|SHELL|SHELLOPTS|SHLVL|SSH_AUTH_SOCK|TERM|UID|UPSTART_EVENTS|UPSTART_INSTANCE|UPSTART_JOB|UPSTART_SESSION|USER|WINDOWID|XAUTHORITY|XDG_CONFIG_DIRS|XDG_CURRENT_DESKTOP|XDG_DATA_DIRS|XDG_GREETER_DATA_DIR|XDG_MENU_PREFIX|XDG_RUNTIME_DIR|XDG_SEAT|XDG_SEAT_PATH|XDG_SESSION_DESKTOP|XDG_SESSION_ID|XDG_SESSION_PATH|XDG_SESSION_TYPE|XDG_VTNR|XMODIFIERS)\\b", t = {
    pattern: /(^(["']?)\w+\2)[ \t]+\S.*/,
    lookbehind: !0,
    alias: "punctuation",
    // this looks reasonably well in all themes
    inside: null
    // see below
  }, n = {
    bash: t,
    environment: {
      pattern: RegExp("\\$" + e),
      alias: "constant"
    },
    variable: [
      // [0]: Arithmetic Environment
      {
        pattern: /\$?\(\([\s\S]+?\)\)/,
        greedy: !0,
        inside: {
          // If there is a $ sign at the beginning highlight $(( and )) as variable
          variable: [
            {
              pattern: /(^\$\(\([\s\S]+)\)\)/,
              lookbehind: !0
            },
            /^\$\(\(/
          ],
          number: /\b0x[\dA-Fa-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:[Ee]-?\d+)?/,
          // Operators according to https://www.gnu.org/software/bash/manual/bashref.html#Shell-Arithmetic
          operator: /--|\+\+|\*\*=?|<<=?|>>=?|&&|\|\||[=!+\-*/%<>^&|]=?|[?~:]/,
          // If there is no $ sign at the beginning highlight (( and )) as punctuation
          punctuation: /\(\(?|\)\)?|,|;/
        }
      },
      // [1]: Command Substitution
      {
        pattern: /\$\((?:\([^)]+\)|[^()])+\)|`[^`]+`/,
        greedy: !0,
        inside: {
          variable: /^\$\(|^`|\)$|`$/
        }
      },
      // [2]: Brace expansion
      {
        pattern: /\$\{[^}]+\}/,
        greedy: !0,
        inside: {
          operator: /:[-=?+]?|[!\/]|##?|%%?|\^\^?|,,?/,
          punctuation: /[\[\]]/,
          environment: {
            pattern: RegExp("(\\{)" + e),
            lookbehind: !0,
            alias: "constant"
          }
        }
      },
      /\$(?:\w+|[#?*!@$])/
    ],
    // Escape sequences from echo and printf's manuals, and escaped quotes.
    entity: /\\(?:[abceEfnrtv\\"]|O?[0-7]{1,3}|U[0-9a-fA-F]{8}|u[0-9a-fA-F]{4}|x[0-9a-fA-F]{1,2})/
  };
  r.languages.bash = {
    shebang: {
      pattern: /^#!\s*\/.*/,
      alias: "important"
    },
    comment: {
      pattern: /(^|[^"{\\$])#.*/,
      lookbehind: !0
    },
    "function-name": [
      // a) function foo {
      // b) foo() {
      // c) function foo() {
      // but not “foo {”
      {
        // a) and c)
        pattern: /(\bfunction\s+)[\w-]+(?=(?:\s*\(?:\s*\))?\s*\{)/,
        lookbehind: !0,
        alias: "function"
      },
      {
        // b)
        pattern: /\b[\w-]+(?=\s*\(\s*\)\s*\{)/,
        alias: "function"
      }
    ],
    // Highlight variable names as variables in for and select beginnings.
    "for-or-select": {
      pattern: /(\b(?:for|select)\s+)\w+(?=\s+in\s)/,
      alias: "variable",
      lookbehind: !0
    },
    // Highlight variable names as variables in the left-hand part
    // of assignments (“=” and “+=”).
    "assign-left": {
      pattern: /(^|[\s;|&]|[<>]\()\w+(?:\.\w+)*(?=\+?=)/,
      inside: {
        environment: {
          pattern: RegExp("(^|[\\s;|&]|[<>]\\()" + e),
          lookbehind: !0,
          alias: "constant"
        }
      },
      alias: "variable",
      lookbehind: !0
    },
    // Highlight parameter names as variables
    parameter: {
      pattern: /(^|\s)-{1,2}(?:\w+:[+-]?)?\w+(?:\.\w+)*(?=[=\s]|$)/,
      alias: "variable",
      lookbehind: !0
    },
    string: [
      // Support for Here-documents https://en.wikipedia.org/wiki/Here_document
      {
        pattern: /((?:^|[^<])<<-?\s*)(\w+)\s[\s\S]*?(?:\r?\n|\r)\2/,
        lookbehind: !0,
        greedy: !0,
        inside: n
      },
      // Here-document with quotes around the tag
      // → No expansion (so no “inside”).
      {
        pattern: /((?:^|[^<])<<-?\s*)(["'])(\w+)\2\s[\s\S]*?(?:\r?\n|\r)\3/,
        lookbehind: !0,
        greedy: !0,
        inside: {
          bash: t
        }
      },
      // “Normal” string
      {
        // https://www.gnu.org/software/bash/manual/html_node/Double-Quotes.html
        pattern: /(^|[^\\](?:\\\\)*)"(?:\\[\s\S]|\$\([^)]+\)|\$(?!\()|`[^`]+`|[^"\\`$])*"/,
        lookbehind: !0,
        greedy: !0,
        inside: n
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/Single-Quotes.html
        pattern: /(^|[^$\\])'[^']*'/,
        lookbehind: !0,
        greedy: !0
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/ANSI_002dC-Quoting.html
        pattern: /\$'(?:[^'\\]|\\[\s\S])*'/,
        greedy: !0,
        inside: {
          entity: n.entity
        }
      }
    ],
    environment: {
      pattern: RegExp("\\$?" + e),
      alias: "constant"
    },
    variable: n.variable,
    function: {
      pattern: /(^|[\s;|&]|[<>]\()(?:add|apropos|apt|apt-cache|apt-get|aptitude|aspell|automysqlbackup|awk|basename|bash|bc|bconsole|bg|bzip2|cal|cargo|cat|cfdisk|chgrp|chkconfig|chmod|chown|chroot|cksum|clear|cmp|column|comm|composer|cp|cron|crontab|csplit|curl|cut|date|dc|dd|ddrescue|debootstrap|df|diff|diff3|dig|dir|dircolors|dirname|dirs|dmesg|docker|docker-compose|du|egrep|eject|env|ethtool|expand|expect|expr|fdformat|fdisk|fg|fgrep|file|find|fmt|fold|format|free|fsck|ftp|fuser|gawk|git|gparted|grep|groupadd|groupdel|groupmod|groups|grub-mkconfig|gzip|halt|head|hg|history|host|hostname|htop|iconv|id|ifconfig|ifdown|ifup|import|install|ip|java|jobs|join|kill|killall|less|link|ln|locate|logname|logrotate|look|lpc|lpr|lprint|lprintd|lprintq|lprm|ls|lsof|lynx|make|man|mc|mdadm|mkconfig|mkdir|mke2fs|mkfifo|mkfs|mkisofs|mknod|mkswap|mmv|more|most|mount|mtools|mtr|mutt|mv|nano|nc|netstat|nice|nl|node|nohup|notify-send|npm|nslookup|op|open|parted|passwd|paste|pathchk|ping|pkill|pnpm|podman|podman-compose|popd|pr|printcap|printenv|ps|pushd|pv|quota|quotacheck|quotactl|ram|rar|rcp|reboot|remsync|rename|renice|rev|rm|rmdir|rpm|rsync|scp|screen|sdiff|sed|sendmail|seq|service|sftp|sh|shellcheck|shuf|shutdown|sleep|slocate|sort|split|ssh|stat|strace|su|sudo|sum|suspend|swapon|sync|sysctl|tac|tail|tar|tee|time|timeout|top|touch|tr|traceroute|tsort|tty|umount|uname|unexpand|uniq|units|unrar|unshar|unzip|update-grub|uptime|useradd|userdel|usermod|users|uudecode|uuencode|v|vcpkg|vdir|vi|vim|virsh|vmstat|wait|watch|wc|wget|whereis|which|who|whoami|write|xargs|xdg-open|yarn|yes|zenity|zip|zsh|zypper)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    keyword: {
      pattern: /(^|[\s;|&]|[<>]\()(?:case|do|done|elif|else|esac|fi|for|function|if|in|select|then|until|while)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    // https://www.gnu.org/software/bash/manual/html_node/Shell-Builtin-Commands.html
    builtin: {
      pattern: /(^|[\s;|&]|[<>]\()(?:\.|:|alias|bind|break|builtin|caller|cd|command|continue|declare|echo|enable|eval|exec|exit|export|getopts|hash|help|let|local|logout|mapfile|printf|pwd|read|readarray|readonly|return|set|shift|shopt|source|test|times|trap|type|typeset|ulimit|umask|unalias|unset)(?=$|[)\s;|&])/,
      lookbehind: !0,
      // Alias added to make those easier to distinguish from strings.
      alias: "class-name"
    },
    boolean: {
      pattern: /(^|[\s;|&]|[<>]\()(?:false|true)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    "file-descriptor": {
      pattern: /\B&\d\b/,
      alias: "important"
    },
    operator: {
      // Lots of redirections here, but not just that.
      pattern: /\d?<>|>\||\+=|=[=~]?|!=?|<<[<-]?|[&\d]?>>|\d[<>]&?|[<>][&=]?|&[>&]?|\|[&|]?/,
      inside: {
        "file-descriptor": {
          pattern: /^\d/,
          alias: "important"
        }
      }
    },
    punctuation: /\$?\(\(?|\)\)?|\.\.|[{}[\];\\]/,
    number: {
      pattern: /(^|\s)(?:[1-9]\d*|0)(?:[.,]\d+)?\b/,
      lookbehind: !0
    }
  }, t.inside = r.languages.bash;
  for (var i = [
    "comment",
    "function-name",
    "for-or-select",
    "assign-left",
    "parameter",
    "string",
    "environment",
    "function",
    "keyword",
    "builtin",
    "boolean",
    "file-descriptor",
    "operator",
    "punctuation",
    "number"
  ], l = n.variable[1].inside, a = 0; a < i.length; a++)
    l[i[a]] = r.languages.bash[i[a]];
  r.languages.sh = r.languages.bash, r.languages.shell = r.languages.bash;
})(Prism);
Prism.languages.c = Prism.languages.extend("clike", {
  comment: {
    pattern: /\/\/(?:[^\r\n\\]|\\(?:\r\n?|\n|(?![\r\n])))*|\/\*[\s\S]*?(?:\*\/|$)/,
    greedy: !0
  },
  string: {
    // https://en.cppreference.com/w/c/language/string_literal
    pattern: /"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"/,
    greedy: !0
  },
  "class-name": {
    pattern: /(\b(?:enum|struct)\s+(?:__attribute__\s*\(\([\s\S]*?\)\)\s*)?)\w+|\b[a-z]\w*_t\b/,
    lookbehind: !0
  },
  keyword: /\b(?:_Alignas|_Alignof|_Atomic|_Bool|_Complex|_Generic|_Imaginary|_Noreturn|_Static_assert|_Thread_local|__attribute__|asm|auto|break|case|char|const|continue|default|do|double|else|enum|extern|float|for|goto|if|inline|int|long|register|return|short|signed|sizeof|static|struct|switch|typedef|typeof|union|unsigned|void|volatile|while)\b/,
  function: /\b[a-z_]\w*(?=\s*\()/i,
  number: /(?:\b0x(?:[\da-f]+(?:\.[\da-f]*)?|\.[\da-f]+)(?:p[+-]?\d+)?|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?)[ful]{0,4}/i,
  operator: />>=?|<<=?|->|([-+&|:])\1|[?:~]|[-+*/%&|^!=<>]=?/
});
Prism.languages.insertBefore("c", "string", {
  char: {
    // https://en.cppreference.com/w/c/language/character_constant
    pattern: /'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n]){0,32}'/,
    greedy: !0
  }
});
Prism.languages.insertBefore("c", "string", {
  macro: {
    // allow for multiline macro definitions
    // spaces after the # character compile fine with gcc
    pattern: /(^[\t ]*)#\s*[a-z](?:[^\r\n\\/]|\/(?!\*)|\/\*(?:[^*]|\*(?!\/))*\*\/|\\(?:\r\n|[\s\S]))*/im,
    lookbehind: !0,
    greedy: !0,
    alias: "property",
    inside: {
      string: [
        {
          // highlight the path of the include statement as a string
          pattern: /^(#\s*include\s*)<[^>]+>/,
          lookbehind: !0
        },
        Prism.languages.c.string
      ],
      char: Prism.languages.c.char,
      comment: Prism.languages.c.comment,
      "macro-name": [
        {
          pattern: /(^#\s*define\s+)\w+\b(?!\()/i,
          lookbehind: !0
        },
        {
          pattern: /(^#\s*define\s+)\w+\b(?=\()/i,
          lookbehind: !0,
          alias: "function"
        }
      ],
      // highlight macro directives as keywords
      directive: {
        pattern: /^(#\s*)[a-z]+/,
        lookbehind: !0,
        alias: "keyword"
      },
      "directive-hash": /^#/,
      punctuation: /##|\\(?=[\r\n])/,
      expression: {
        pattern: /\S[\s\S]*/,
        inside: Prism.languages.c
      }
    }
  }
});
Prism.languages.insertBefore("c", "function", {
  // highlight predefined macros as constants
  constant: /\b(?:EOF|NULL|SEEK_CUR|SEEK_END|SEEK_SET|__DATE__|__FILE__|__LINE__|__TIMESTAMP__|__TIME__|__func__|stderr|stdin|stdout)\b/
});
delete Prism.languages.c.boolean;
(function(r) {
  var e = /\b(?:alignas|alignof|asm|auto|bool|break|case|catch|char|char16_t|char32_t|char8_t|class|co_await|co_return|co_yield|compl|concept|const|const_cast|consteval|constexpr|constinit|continue|decltype|default|delete|do|double|dynamic_cast|else|enum|explicit|export|extern|final|float|for|friend|goto|if|import|inline|int|int16_t|int32_t|int64_t|int8_t|long|module|mutable|namespace|new|noexcept|nullptr|operator|override|private|protected|public|register|reinterpret_cast|requires|return|short|signed|sizeof|static|static_assert|static_cast|struct|switch|template|this|thread_local|throw|try|typedef|typeid|typename|uint16_t|uint32_t|uint64_t|uint8_t|union|unsigned|using|virtual|void|volatile|wchar_t|while)\b/, t = /\b(?!<keyword>)\w+(?:\s*\.\s*\w+)*\b/.source.replace(/<keyword>/g, function() {
    return e.source;
  });
  r.languages.cpp = r.languages.extend("c", {
    "class-name": [
      {
        pattern: RegExp(/(\b(?:class|concept|enum|struct|typename)\s+)(?!<keyword>)\w+/.source.replace(/<keyword>/g, function() {
          return e.source;
        })),
        lookbehind: !0
      },
      // This is intended to capture the class name of method implementations like:
      //   void foo::bar() const {}
      // However! The `foo` in the above example could also be a namespace, so we only capture the class name if
      // it starts with an uppercase letter. This approximation should give decent results.
      /\b[A-Z]\w*(?=\s*::\s*\w+\s*\()/,
      // This will capture the class name before destructors like:
      //   Foo::~Foo() {}
      /\b[A-Z_]\w*(?=\s*::\s*~\w+\s*\()/i,
      // This also intends to capture the class name of method implementations but here the class has template
      // parameters, so it can't be a namespace (until C++ adds generic namespaces).
      /\b\w+(?=\s*<(?:[^<>]|<(?:[^<>]|<[^<>]*>)*>)*>\s*::\s*\w+\s*\()/
    ],
    keyword: e,
    number: {
      pattern: /(?:\b0b[01']+|\b0x(?:[\da-f']+(?:\.[\da-f']*)?|\.[\da-f']+)(?:p[+-]?[\d']+)?|(?:\b[\d']+(?:\.[\d']*)?|\B\.[\d']+)(?:e[+-]?[\d']+)?)[ful]{0,4}/i,
      greedy: !0
    },
    operator: />>=?|<<=?|->|--|\+\+|&&|\|\||[?:~]|<=>|[-+*/%&|^!=<>]=?|\b(?:and|and_eq|bitand|bitor|not|not_eq|or|or_eq|xor|xor_eq)\b/,
    boolean: /\b(?:false|true)\b/
  }), r.languages.insertBefore("cpp", "string", {
    module: {
      // https://en.cppreference.com/w/cpp/language/modules
      pattern: RegExp(
        /(\b(?:import|module)\s+)/.source + "(?:" + // header-name
        /"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|<[^<>\r\n]*>/.source + "|" + // module name or partition or both
        /<mod-name>(?:\s*:\s*<mod-name>)?|:\s*<mod-name>/.source.replace(/<mod-name>/g, function() {
          return t;
        }) + ")"
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        string: /^[<"][\s\S]+/,
        operator: /:/,
        punctuation: /\./
      }
    },
    "raw-string": {
      pattern: /R"([^()\\ ]{0,16})\([\s\S]*?\)\1"/,
      alias: "string",
      greedy: !0
    }
  }), r.languages.insertBefore("cpp", "keyword", {
    "generic-function": {
      pattern: /\b(?!operator\b)[a-z_]\w*\s*<(?:[^<>]|<[^<>]*>)*>(?=\s*\()/i,
      inside: {
        function: /^\w+/,
        generic: {
          pattern: /<[\s\S]+/,
          alias: "class-name",
          inside: r.languages.cpp
        }
      }
    }
  }), r.languages.insertBefore("cpp", "operator", {
    "double-colon": {
      pattern: /::/,
      alias: "punctuation"
    }
  }), r.languages.insertBefore("cpp", "class-name", {
    // the base clause is an optional list of parent classes
    // https://en.cppreference.com/w/cpp/language/class
    "base-clause": {
      pattern: /(\b(?:class|struct)\s+\w+\s*:\s*)[^;{}"'\s]+(?:\s+[^;{}"'\s]+)*(?=\s*[;{])/,
      lookbehind: !0,
      greedy: !0,
      inside: r.languages.extend("cpp", {})
    }
  }), r.languages.insertBefore("inside", "double-colon", {
    // All untokenized words that are not namespaces should be class names
    "class-name": /\b[a-z_]\w*\b(?!\s*::)/i
  }, r.languages.cpp["base-clause"]);
})(Prism);
Prism.languages.json = {
  property: {
    pattern: /(^|[^\\])"(?:\\.|[^\\"\r\n])*"(?=\s*:)/,
    lookbehind: !0,
    greedy: !0
  },
  string: {
    pattern: /(^|[^\\])"(?:\\.|[^\\"\r\n])*"(?!\s*:)/,
    lookbehind: !0,
    greedy: !0
  },
  comment: {
    pattern: /\/\/.*|\/\*[\s\S]*?(?:\*\/|$)/,
    greedy: !0
  },
  number: /-?\b\d+(?:\.\d+)?(?:e[+-]?\d+)?\b/i,
  punctuation: /[{}[\],]/,
  operator: /:/,
  boolean: /\b(?:false|true)\b/,
  null: {
    pattern: /\bnull\b/,
    alias: "keyword"
  }
};
Prism.languages.webmanifest = Prism.languages.json;
Prism.languages.sql = {
  comment: {
    pattern: /(^|[^\\])(?:\/\*[\s\S]*?\*\/|(?:--|\/\/|#).*)/,
    lookbehind: !0
  },
  variable: [
    {
      pattern: /@(["'`])(?:\\[\s\S]|(?!\1)[^\\])+\1/,
      greedy: !0
    },
    /@[\w.$]+/
  ],
  string: {
    pattern: /(^|[^@\\])("|')(?:\\[\s\S]|(?!\2)[^\\]|\2\2)*\2/,
    greedy: !0,
    lookbehind: !0
  },
  identifier: {
    pattern: /(^|[^@\\])`(?:\\[\s\S]|[^`\\]|``)*`/,
    greedy: !0,
    lookbehind: !0,
    inside: {
      punctuation: /^`|`$/
    }
  },
  function: /\b(?:AVG|COUNT|FIRST|FORMAT|LAST|LCASE|LEN|MAX|MID|MIN|MOD|NOW|ROUND|SUM|UCASE)(?=\s*\()/i,
  // Should we highlight user defined functions too?
  keyword: /\b(?:ACTION|ADD|AFTER|ALGORITHM|ALL|ALTER|ANALYZE|ANY|APPLY|AS|ASC|AUTHORIZATION|AUTO_INCREMENT|BACKUP|BDB|BEGIN|BERKELEYDB|BIGINT|BINARY|BIT|BLOB|BOOL|BOOLEAN|BREAK|BROWSE|BTREE|BULK|BY|CALL|CASCADED?|CASE|CHAIN|CHAR(?:ACTER|SET)?|CHECK(?:POINT)?|CLOSE|CLUSTERED|COALESCE|COLLATE|COLUMNS?|COMMENT|COMMIT(?:TED)?|COMPUTE|CONNECT|CONSISTENT|CONSTRAINT|CONTAINS(?:TABLE)?|CONTINUE|CONVERT|CREATE|CROSS|CURRENT(?:_DATE|_TIME|_TIMESTAMP|_USER)?|CURSOR|CYCLE|DATA(?:BASES?)?|DATE(?:TIME)?|DAY|DBCC|DEALLOCATE|DEC|DECIMAL|DECLARE|DEFAULT|DEFINER|DELAYED|DELETE|DELIMITERS?|DENY|DESC|DESCRIBE|DETERMINISTIC|DISABLE|DISCARD|DISK|DISTINCT|DISTINCTROW|DISTRIBUTED|DO|DOUBLE|DROP|DUMMY|DUMP(?:FILE)?|DUPLICATE|ELSE(?:IF)?|ENABLE|ENCLOSED|END|ENGINE|ENUM|ERRLVL|ERRORS|ESCAPED?|EXCEPT|EXEC(?:UTE)?|EXISTS|EXIT|EXPLAIN|EXTENDED|FETCH|FIELDS|FILE|FILLFACTOR|FIRST|FIXED|FLOAT|FOLLOWING|FOR(?: EACH ROW)?|FORCE|FOREIGN|FREETEXT(?:TABLE)?|FROM|FULL|FUNCTION|GEOMETRY(?:COLLECTION)?|GLOBAL|GOTO|GRANT|GROUP|HANDLER|HASH|HAVING|HOLDLOCK|HOUR|IDENTITY(?:COL|_INSERT)?|IF|IGNORE|IMPORT|INDEX|INFILE|INNER|INNODB|INOUT|INSERT|INT|INTEGER|INTERSECT|INTERVAL|INTO|INVOKER|ISOLATION|ITERATE|JOIN|KEYS?|KILL|LANGUAGE|LAST|LEAVE|LEFT|LEVEL|LIMIT|LINENO|LINES|LINESTRING|LOAD|LOCAL|LOCK|LONG(?:BLOB|TEXT)|LOOP|MATCH(?:ED)?|MEDIUM(?:BLOB|INT|TEXT)|MERGE|MIDDLEINT|MINUTE|MODE|MODIFIES|MODIFY|MONTH|MULTI(?:LINESTRING|POINT|POLYGON)|NATIONAL|NATURAL|NCHAR|NEXT|NO|NONCLUSTERED|NULLIF|NUMERIC|OFF?|OFFSETS?|ON|OPEN(?:DATASOURCE|QUERY|ROWSET)?|OPTIMIZE|OPTION(?:ALLY)?|ORDER|OUT(?:ER|FILE)?|OVER|PARTIAL|PARTITION|PERCENT|PIVOT|PLAN|POINT|POLYGON|PRECEDING|PRECISION|PREPARE|PREV|PRIMARY|PRINT|PRIVILEGES|PROC(?:EDURE)?|PUBLIC|PURGE|QUICK|RAISERROR|READS?|REAL|RECONFIGURE|REFERENCES|RELEASE|RENAME|REPEAT(?:ABLE)?|REPLACE|REPLICATION|REQUIRE|RESIGNAL|RESTORE|RESTRICT|RETURN(?:ING|S)?|REVOKE|RIGHT|ROLLBACK|ROUTINE|ROW(?:COUNT|GUIDCOL|S)?|RTREE|RULE|SAVE(?:POINT)?|SCHEMA|SECOND|SELECT|SERIAL(?:IZABLE)?|SESSION(?:_USER)?|SET(?:USER)?|SHARE|SHOW|SHUTDOWN|SIMPLE|SMALLINT|SNAPSHOT|SOME|SONAME|SQL|START(?:ING)?|STATISTICS|STATUS|STRIPED|SYSTEM_USER|TABLES?|TABLESPACE|TEMP(?:ORARY|TABLE)?|TERMINATED|TEXT(?:SIZE)?|THEN|TIME(?:STAMP)?|TINY(?:BLOB|INT|TEXT)|TOP?|TRAN(?:SACTIONS?)?|TRIGGER|TRUNCATE|TSEQUAL|TYPES?|UNBOUNDED|UNCOMMITTED|UNDEFINED|UNION|UNIQUE|UNLOCK|UNPIVOT|UNSIGNED|UPDATE(?:TEXT)?|USAGE|USE|USER|USING|VALUES?|VAR(?:BINARY|CHAR|CHARACTER|YING)|VIEW|WAITFOR|WARNINGS|WHEN|WHERE|WHILE|WITH(?: ROLLUP|IN)?|WORK|WRITE(?:TEXT)?|YEAR)\b/i,
  boolean: /\b(?:FALSE|NULL|TRUE)\b/i,
  number: /\b0x[\da-f]+\b|\b\d+(?:\.\d*)?|\B\.\d+\b/i,
  operator: /[-+*\/=%^~]|&&?|\|\|?|!=?|<(?:=>?|<|>)?|>[>=]?|\b(?:AND|BETWEEN|DIV|ILIKE|IN|IS|LIKE|NOT|OR|REGEXP|RLIKE|SOUNDS LIKE|XOR)\b/i,
  punctuation: /[;[\]()`,.]/
};
(function(r) {
  var e = /\b(?:abstract|assert|boolean|break|byte|case|catch|char|class|const|continue|default|do|double|else|enum|exports|extends|final|finally|float|for|goto|if|implements|import|instanceof|int|interface|long|module|native|new|non-sealed|null|open|opens|package|permits|private|protected|provides|public|record(?!\s*[(){}[\]<>=%~.:,;?+\-*/&|^])|requires|return|sealed|short|static|strictfp|super|switch|synchronized|this|throw|throws|to|transient|transitive|try|uses|var|void|volatile|while|with|yield)\b/, t = /(?:[a-z]\w*\s*\.\s*)*(?:[A-Z]\w*\s*\.\s*)*/.source, n = {
    pattern: RegExp(/(^|[^\w.])/.source + t + /[A-Z](?:[\d_A-Z]*[a-z]\w*)?\b/.source),
    lookbehind: !0,
    inside: {
      namespace: {
        pattern: /^[a-z]\w*(?:\s*\.\s*[a-z]\w*)*(?:\s*\.)?/,
        inside: {
          punctuation: /\./
        }
      },
      punctuation: /\./
    }
  };
  r.languages.java = r.languages.extend("clike", {
    string: {
      pattern: /(^|[^\\])"(?:\\.|[^"\\\r\n])*"/,
      lookbehind: !0,
      greedy: !0
    },
    "class-name": [
      n,
      {
        // variables, parameters, and constructor references
        // this to support class names (or generic parameters) which do not contain a lower case letter (also works for methods)
        pattern: RegExp(/(^|[^\w.])/.source + t + /[A-Z]\w*(?=\s+\w+\s*[;,=()]|\s*(?:\[[\s,]*\]\s*)?::\s*new\b)/.source),
        lookbehind: !0,
        inside: n.inside
      },
      {
        // class names based on keyword
        // this to support class names (or generic parameters) which do not contain a lower case letter (also works for methods)
        pattern: RegExp(/(\b(?:class|enum|extends|implements|instanceof|interface|new|record|throws)\s+)/.source + t + /[A-Z]\w*\b/.source),
        lookbehind: !0,
        inside: n.inside
      }
    ],
    keyword: e,
    function: [
      r.languages.clike.function,
      {
        pattern: /(::\s*)[a-z_]\w*/,
        lookbehind: !0
      }
    ],
    number: /\b0b[01][01_]*L?\b|\b0x(?:\.[\da-f_p+-]+|[\da-f_]+(?:\.[\da-f_p+-]+)?)\b|(?:\b\d[\d_]*(?:\.[\d_]*)?|\B\.\d[\d_]*)(?:e[+-]?\d[\d_]*)?[dfl]?/i,
    operator: {
      pattern: /(^|[^.])(?:<<=?|>>>?=?|->|--|\+\+|&&|\|\||::|[?:~]|[-+*/%&|^!=<>]=?)/m,
      lookbehind: !0
    },
    constant: /\b[A-Z][A-Z_\d]+\b/
  }), r.languages.insertBefore("java", "string", {
    "triple-quoted-string": {
      // http://openjdk.java.net/jeps/355#Description
      pattern: /"""[ \t]*[\r\n](?:(?:"|"")?(?:\\.|[^"\\]))*"""/,
      greedy: !0,
      alias: "string"
    },
    char: {
      pattern: /'(?:\\.|[^'\\\r\n]){1,6}'/,
      greedy: !0
    }
  }), r.languages.insertBefore("java", "class-name", {
    annotation: {
      pattern: /(^|[^.])@\w+(?:\s*\.\s*\w+)*/,
      lookbehind: !0,
      alias: "punctuation"
    },
    generics: {
      pattern: /<(?:[\w\s,.?]|&(?!&)|<(?:[\w\s,.?]|&(?!&)|<(?:[\w\s,.?]|&(?!&)|<(?:[\w\s,.?]|&(?!&))*>)*>)*>)*>/,
      inside: {
        "class-name": n,
        keyword: e,
        punctuation: /[<>(),.:]/,
        operator: /[?&|]/
      }
    },
    import: [
      {
        pattern: RegExp(/(\bimport\s+)/.source + t + /(?:[A-Z]\w*|\*)(?=\s*;)/.source),
        lookbehind: !0,
        inside: {
          namespace: n.inside.namespace,
          punctuation: /\./,
          operator: /\*/,
          "class-name": /\w+/
        }
      },
      {
        pattern: RegExp(/(\bimport\s+static\s+)/.source + t + /(?:\w+|\*)(?=\s*;)/.source),
        lookbehind: !0,
        alias: "static",
        inside: {
          namespace: n.inside.namespace,
          static: /\b\w+$/,
          punctuation: /\./,
          operator: /\*/,
          "class-name": /\w+/
        }
      }
    ],
    namespace: {
      pattern: RegExp(
        /(\b(?:exports|import(?:\s+static)?|module|open|opens|package|provides|requires|to|transitive|uses|with)\s+)(?!<keyword>)[a-z]\w*(?:\.[a-z]\w*)*\.?/.source.replace(/<keyword>/g, function() {
          return e.source;
        })
      ),
      lookbehind: !0,
      inside: {
        punctuation: /\./
      }
    }
  });
})(Prism);
Prism.languages.go = Prism.languages.extend("clike", {
  string: {
    pattern: /(^|[^\\])"(?:\\.|[^"\\\r\n])*"|`[^`]*`/,
    lookbehind: !0,
    greedy: !0
  },
  keyword: /\b(?:break|case|chan|const|continue|default|defer|else|fallthrough|for|func|go(?:to)?|if|import|interface|map|package|range|return|select|struct|switch|type|var)\b/,
  boolean: /\b(?:_|false|iota|nil|true)\b/,
  number: [
    // binary and octal integers
    /\b0(?:b[01_]+|o[0-7_]+)i?\b/i,
    // hexadecimal integers and floats
    /\b0x(?:[a-f\d_]+(?:\.[a-f\d_]*)?|\.[a-f\d_]+)(?:p[+-]?\d+(?:_\d+)*)?i?(?!\w)/i,
    // decimal integers and floats
    /(?:\b\d[\d_]*(?:\.[\d_]*)?|\B\.\d[\d_]*)(?:e[+-]?[\d_]+)?i?(?!\w)/i
  ],
  operator: /[*\/%^!=]=?|\+[=+]?|-[=-]?|\|[=|]?|&(?:=|&|\^=?)?|>(?:>=?|=)?|<(?:<=?|=|-)?|:=|\.\.\./,
  builtin: /\b(?:append|bool|byte|cap|close|complex|complex(?:64|128)|copy|delete|error|float(?:32|64)|u?int(?:8|16|32|64)?|imag|len|make|new|panic|print(?:ln)?|real|recover|rune|string|uintptr)\b/
});
Prism.languages.insertBefore("go", "string", {
  char: {
    pattern: /'(?:\\.|[^'\\\r\n]){0,10}'/,
    greedy: !0
  }
});
delete Prism.languages.go["class-name"];
(function(r) {
  for (var e = /\/\*(?:[^*/]|\*(?!\/)|\/(?!\*)|<self>)*\*\//.source, t = 0; t < 2; t++)
    e = e.replace(/<self>/g, function() {
      return e;
    });
  e = e.replace(/<self>/g, function() {
    return /[^\s\S]/.source;
  }), r.languages.rust = {
    comment: [
      {
        pattern: RegExp(/(^|[^\\])/.source + e),
        lookbehind: !0,
        greedy: !0
      },
      {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0,
        greedy: !0
      }
    ],
    string: {
      pattern: /b?"(?:\\[\s\S]|[^\\"])*"|b?r(#*)"(?:[^"]|"(?!\1))*"\1/,
      greedy: !0
    },
    char: {
      pattern: /b?'(?:\\(?:x[0-7][\da-fA-F]|u\{(?:[\da-fA-F]_*){1,6}\}|.)|[^\\\r\n\t'])'/,
      greedy: !0
    },
    attribute: {
      pattern: /#!?\[(?:[^\[\]"]|"(?:\\[\s\S]|[^\\"])*")*\]/,
      greedy: !0,
      alias: "attr-name",
      inside: {
        string: null
        // see below
      }
    },
    // Closure params should not be confused with bitwise OR |
    "closure-params": {
      pattern: /([=(,:]\s*|\bmove\s*)\|[^|]*\||\|[^|]*\|(?=\s*(?:\{|->))/,
      lookbehind: !0,
      greedy: !0,
      inside: {
        "closure-punctuation": {
          pattern: /^\||\|$/,
          alias: "punctuation"
        },
        rest: null
        // see below
      }
    },
    "lifetime-annotation": {
      pattern: /'\w+/,
      alias: "symbol"
    },
    "fragment-specifier": {
      pattern: /(\$\w+:)[a-z]+/,
      lookbehind: !0,
      alias: "punctuation"
    },
    variable: /\$\w+/,
    "function-definition": {
      pattern: /(\bfn\s+)\w+/,
      lookbehind: !0,
      alias: "function"
    },
    "type-definition": {
      pattern: /(\b(?:enum|struct|trait|type|union)\s+)\w+/,
      lookbehind: !0,
      alias: "class-name"
    },
    "module-declaration": [
      {
        pattern: /(\b(?:crate|mod)\s+)[a-z][a-z_\d]*/,
        lookbehind: !0,
        alias: "namespace"
      },
      {
        pattern: /(\b(?:crate|self|super)\s*)::\s*[a-z][a-z_\d]*\b(?:\s*::(?:\s*[a-z][a-z_\d]*\s*::)*)?/,
        lookbehind: !0,
        alias: "namespace",
        inside: {
          punctuation: /::/
        }
      }
    ],
    keyword: [
      // https://github.com/rust-lang/reference/blob/master/src/keywords.md
      /\b(?:Self|abstract|as|async|await|become|box|break|const|continue|crate|do|dyn|else|enum|extern|final|fn|for|if|impl|in|let|loop|macro|match|mod|move|mut|override|priv|pub|ref|return|self|static|struct|super|trait|try|type|typeof|union|unsafe|unsized|use|virtual|where|while|yield)\b/,
      // primitives and str
      // https://doc.rust-lang.org/stable/rust-by-example/primitives.html
      /\b(?:bool|char|f(?:32|64)|[ui](?:8|16|32|64|128|size)|str)\b/
    ],
    // functions can technically start with an upper-case letter, but this will introduce a lot of false positives
    // and Rust's naming conventions recommend snake_case anyway.
    // https://doc.rust-lang.org/1.0.0/style/style/naming/README.html
    function: /\b[a-z_]\w*(?=\s*(?:::\s*<|\())/,
    macro: {
      pattern: /\b\w+!/,
      alias: "property"
    },
    constant: /\b[A-Z_][A-Z_\d]+\b/,
    "class-name": /\b[A-Z]\w*\b/,
    namespace: {
      pattern: /(?:\b[a-z][a-z_\d]*\s*::\s*)*\b[a-z][a-z_\d]*\s*::(?!\s*<)/,
      inside: {
        punctuation: /::/
      }
    },
    // Hex, oct, bin, dec numbers with visual separators and type suffix
    number: /\b(?:0x[\dA-Fa-f](?:_?[\dA-Fa-f])*|0o[0-7](?:_?[0-7])*|0b[01](?:_?[01])*|(?:(?:\d(?:_?\d)*)?\.)?\d(?:_?\d)*(?:[Ee][+-]?\d+)?)(?:_?(?:f32|f64|[iu](?:8|16|32|64|size)?))?\b/,
    boolean: /\b(?:false|true)\b/,
    punctuation: /->|\.\.=|\.{1,3}|::|[{}[\];(),:]/,
    operator: /[-+*\/%!^]=?|=[=>]?|&[&=]?|\|[|=]?|<<?=?|>>?=?|[@?]/
  }, r.languages.rust["closure-params"].inside.rest = r.languages.rust, r.languages.rust.attribute.inside.string = r.languages.rust.string;
})(Prism);
(function(r) {
  var e = /\/\*[\s\S]*?\*\/|\/\/.*|#(?!\[).*/, t = [
    {
      pattern: /\b(?:false|true)\b/i,
      alias: "boolean"
    },
    {
      pattern: /(::\s*)\b[a-z_]\w*\b(?!\s*\()/i,
      greedy: !0,
      lookbehind: !0
    },
    {
      pattern: /(\b(?:case|const)\s+)\b[a-z_]\w*(?=\s*[;=])/i,
      greedy: !0,
      lookbehind: !0
    },
    /\b(?:null)\b/i,
    /\b[A-Z_][A-Z0-9_]*\b(?!\s*\()/
  ], n = /\b0b[01]+(?:_[01]+)*\b|\b0o[0-7]+(?:_[0-7]+)*\b|\b0x[\da-f]+(?:_[\da-f]+)*\b|(?:\b\d+(?:_\d+)*\.?(?:\d+(?:_\d+)*)?|\B\.\d+)(?:e[+-]?\d+)?/i, i = /<?=>|\?\?=?|\.{3}|\??->|[!=]=?=?|::|\*\*=?|--|\+\+|&&|\|\||<<|>>|[?~]|[/^|%*&<>.+-]=?/, l = /[{}\[\](),:;]/;
  r.languages.php = {
    delimiter: {
      pattern: /\?>$|^<\?(?:php(?=\s)|=)?/i,
      alias: "important"
    },
    comment: e,
    variable: /\$+(?:\w+\b|(?=\{))/,
    package: {
      pattern: /(namespace\s+|use\s+(?:function\s+)?)(?:\\?\b[a-z_]\w*)+\b(?!\\)/i,
      lookbehind: !0,
      inside: {
        punctuation: /\\/
      }
    },
    "class-name-definition": {
      pattern: /(\b(?:class|enum|interface|trait)\s+)\b[a-z_]\w*(?!\\)\b/i,
      lookbehind: !0,
      alias: "class-name"
    },
    "function-definition": {
      pattern: /(\bfunction\s+)[a-z_]\w*(?=\s*\()/i,
      lookbehind: !0,
      alias: "function"
    },
    keyword: [
      {
        pattern: /(\(\s*)\b(?:array|bool|boolean|float|int|integer|object|string)\b(?=\s*\))/i,
        alias: "type-casting",
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /([(,?]\s*)\b(?:array(?!\s*\()|bool|callable|(?:false|null)(?=\s*\|)|float|int|iterable|mixed|object|self|static|string)\b(?=\s*\$)/i,
        alias: "type-hint",
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /(\)\s*:\s*(?:\?\s*)?)\b(?:array(?!\s*\()|bool|callable|(?:false|null)(?=\s*\|)|float|int|iterable|mixed|never|object|self|static|string|void)\b/i,
        alias: "return-type",
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /\b(?:array(?!\s*\()|bool|float|int|iterable|mixed|object|string|void)\b/i,
        alias: "type-declaration",
        greedy: !0
      },
      {
        pattern: /(\|\s*)(?:false|null)\b|\b(?:false|null)(?=\s*\|)/i,
        alias: "type-declaration",
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /\b(?:parent|self|static)(?=\s*::)/i,
        alias: "static-context",
        greedy: !0
      },
      {
        // yield from
        pattern: /(\byield\s+)from\b/i,
        lookbehind: !0
      },
      // `class` is always a keyword unlike other keywords
      /\bclass\b/i,
      {
        // https://www.php.net/manual/en/reserved.keywords.php
        //
        // keywords cannot be preceded by "->"
        // the complex lookbehind means `(?<!(?:->|::)\s*)`
        pattern: /((?:^|[^\s>:]|(?:^|[^-])>|(?:^|[^:]):)\s*)\b(?:abstract|and|array|as|break|callable|case|catch|clone|const|continue|declare|default|die|do|echo|else|elseif|empty|enddeclare|endfor|endforeach|endif|endswitch|endwhile|enum|eval|exit|extends|final|finally|fn|for|foreach|function|global|goto|if|implements|include|include_once|instanceof|insteadof|interface|isset|list|match|namespace|never|new|or|parent|print|private|protected|public|readonly|require|require_once|return|self|static|switch|throw|trait|try|unset|use|var|while|xor|yield|__halt_compiler)\b/i,
        lookbehind: !0
      }
    ],
    "argument-name": {
      pattern: /([(,]\s*)\b[a-z_]\w*(?=\s*:(?!:))/i,
      lookbehind: !0
    },
    "class-name": [
      {
        pattern: /(\b(?:extends|implements|instanceof|new(?!\s+self|\s+static))\s+|\bcatch\s*\()\b[a-z_]\w*(?!\\)\b/i,
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /(\|\s*)\b[a-z_]\w*(?!\\)\b/i,
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /\b[a-z_]\w*(?!\\)\b(?=\s*\|)/i,
        greedy: !0
      },
      {
        pattern: /(\|\s*)(?:\\?\b[a-z_]\w*)+\b/i,
        alias: "class-name-fully-qualified",
        greedy: !0,
        lookbehind: !0,
        inside: {
          punctuation: /\\/
        }
      },
      {
        pattern: /(?:\\?\b[a-z_]\w*)+\b(?=\s*\|)/i,
        alias: "class-name-fully-qualified",
        greedy: !0,
        inside: {
          punctuation: /\\/
        }
      },
      {
        pattern: /(\b(?:extends|implements|instanceof|new(?!\s+self\b|\s+static\b))\s+|\bcatch\s*\()(?:\\?\b[a-z_]\w*)+\b(?!\\)/i,
        alias: "class-name-fully-qualified",
        greedy: !0,
        lookbehind: !0,
        inside: {
          punctuation: /\\/
        }
      },
      {
        pattern: /\b[a-z_]\w*(?=\s*\$)/i,
        alias: "type-declaration",
        greedy: !0
      },
      {
        pattern: /(?:\\?\b[a-z_]\w*)+(?=\s*\$)/i,
        alias: ["class-name-fully-qualified", "type-declaration"],
        greedy: !0,
        inside: {
          punctuation: /\\/
        }
      },
      {
        pattern: /\b[a-z_]\w*(?=\s*::)/i,
        alias: "static-context",
        greedy: !0
      },
      {
        pattern: /(?:\\?\b[a-z_]\w*)+(?=\s*::)/i,
        alias: ["class-name-fully-qualified", "static-context"],
        greedy: !0,
        inside: {
          punctuation: /\\/
        }
      },
      {
        pattern: /([(,?]\s*)[a-z_]\w*(?=\s*\$)/i,
        alias: "type-hint",
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /([(,?]\s*)(?:\\?\b[a-z_]\w*)+(?=\s*\$)/i,
        alias: ["class-name-fully-qualified", "type-hint"],
        greedy: !0,
        lookbehind: !0,
        inside: {
          punctuation: /\\/
        }
      },
      {
        pattern: /(\)\s*:\s*(?:\?\s*)?)\b[a-z_]\w*(?!\\)\b/i,
        alias: "return-type",
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /(\)\s*:\s*(?:\?\s*)?)(?:\\?\b[a-z_]\w*)+\b(?!\\)/i,
        alias: ["class-name-fully-qualified", "return-type"],
        greedy: !0,
        lookbehind: !0,
        inside: {
          punctuation: /\\/
        }
      }
    ],
    constant: t,
    function: {
      pattern: /(^|[^\\\w])\\?[a-z_](?:[\w\\]*\w)?(?=\s*\()/i,
      lookbehind: !0,
      inside: {
        punctuation: /\\/
      }
    },
    property: {
      pattern: /(->\s*)\w+/,
      lookbehind: !0
    },
    number: n,
    operator: i,
    punctuation: l
  };
  var a = {
    pattern: /\{\$(?:\{(?:\{[^{}]+\}|[^{}]+)\}|[^{}])+\}|(^|[^\\{])\$+(?:\w+(?:\[[^\r\n\[\]]+\]|->\w+)?)/,
    lookbehind: !0,
    inside: r.languages.php
  }, o = [
    {
      pattern: /<<<'([^']+)'[\r\n](?:.*[\r\n])*?\1;/,
      alias: "nowdoc-string",
      greedy: !0,
      inside: {
        delimiter: {
          pattern: /^<<<'[^']+'|[a-z_]\w*;$/i,
          alias: "symbol",
          inside: {
            punctuation: /^<<<'?|[';]$/
          }
        }
      }
    },
    {
      pattern: /<<<(?:"([^"]+)"[\r\n](?:.*[\r\n])*?\1;|([a-z_]\w*)[\r\n](?:.*[\r\n])*?\2;)/i,
      alias: "heredoc-string",
      greedy: !0,
      inside: {
        delimiter: {
          pattern: /^<<<(?:"[^"]+"|[a-z_]\w*)|[a-z_]\w*;$/i,
          alias: "symbol",
          inside: {
            punctuation: /^<<<"?|[";]$/
          }
        },
        interpolation: a
      }
    },
    {
      pattern: /`(?:\\[\s\S]|[^\\`])*`/,
      alias: "backtick-quoted-string",
      greedy: !0
    },
    {
      pattern: /'(?:\\[\s\S]|[^\\'])*'/,
      alias: "single-quoted-string",
      greedy: !0
    },
    {
      pattern: /"(?:\\[\s\S]|[^\\"])*"/,
      alias: "double-quoted-string",
      greedy: !0,
      inside: {
        interpolation: a
      }
    }
  ];
  r.languages.insertBefore("php", "variable", {
    string: o,
    attribute: {
      pattern: /#\[(?:[^"'\/#]|\/(?![*/])|\/\/.*$|#(?!\[).*$|\/\*(?:[^*]|\*(?!\/))*\*\/|"(?:\\[\s\S]|[^\\"])*"|'(?:\\[\s\S]|[^\\'])*')+\](?=\s*[a-z$#])/im,
      greedy: !0,
      inside: {
        "attribute-content": {
          pattern: /^(#\[)[\s\S]+(?=\]$)/,
          lookbehind: !0,
          // inside can appear subset of php
          inside: {
            comment: e,
            string: o,
            "attribute-class-name": [
              {
                pattern: /([^:]|^)\b[a-z_]\w*(?!\\)\b/i,
                alias: "class-name",
                greedy: !0,
                lookbehind: !0
              },
              {
                pattern: /([^:]|^)(?:\\?\b[a-z_]\w*)+/i,
                alias: [
                  "class-name",
                  "class-name-fully-qualified"
                ],
                greedy: !0,
                lookbehind: !0,
                inside: {
                  punctuation: /\\/
                }
              }
            ],
            constant: t,
            number: n,
            operator: i,
            punctuation: l
          }
        },
        delimiter: {
          pattern: /^#\[|\]$/,
          alias: "punctuation"
        }
      }
    }
  }), r.hooks.add("before-tokenize", function(s) {
    if (/<\?/.test(s.code)) {
      var _ = /<\?(?:[^"'/#]|\/(?![*/])|("|')(?:\\[\s\S]|(?!\1)[^\\])*\1|(?:\/\/|#(?!\[))(?:[^?\n\r]|\?(?!>))*(?=$|\?>|[\r\n])|#\[|\/\*(?:[^*]|\*(?!\/))*(?:\*\/|$))*?(?:\?>|$)/g;
      r.languages["markup-templating"].buildPlaceholders(s, "php", _);
    }
  }), r.hooks.add("after-tokenize", function(s) {
    r.languages["markup-templating"].tokenizePlaceholders(s, "php");
  });
})(Prism);
(function(r) {
  var e = /[*&][^\s[\]{},]+/, t = /!(?:<[\w\-%#;/?:@&=+$,.!~*'()[\]]+>|(?:[a-zA-Z\d-]*!)?[\w\-%#;/?:@&=+$.~*'()]+)?/, n = "(?:" + t.source + "(?:[ 	]+" + e.source + ")?|" + e.source + "(?:[ 	]+" + t.source + ")?)", i = /(?:[^\s\x00-\x08\x0e-\x1f!"#%&'*,\-:>?@[\]`{|}\x7f-\x84\x86-\x9f\ud800-\udfff\ufffe\uffff]|[?:-]<PLAIN>)(?:[ \t]*(?:(?![#:])<PLAIN>|:<PLAIN>))*/.source.replace(/<PLAIN>/g, function() {
    return /[^\s\x00-\x08\x0e-\x1f,[\]{}\x7f-\x84\x86-\x9f\ud800-\udfff\ufffe\uffff]/.source;
  }), l = /"(?:[^"\\\r\n]|\\.)*"|'(?:[^'\\\r\n]|\\.)*'/.source;
  function a(o, s) {
    s = (s || "").replace(/m/g, "") + "m";
    var _ = /([:\-,[{]\s*(?:\s<<prop>>[ \t]+)?)(?:<<value>>)(?=[ \t]*(?:$|,|\]|\}|(?:[\r\n]\s*)?#))/.source.replace(/<<prop>>/g, function() {
      return n;
    }).replace(/<<value>>/g, function() {
      return o;
    });
    return RegExp(_, s);
  }
  r.languages.yaml = {
    scalar: {
      pattern: RegExp(/([\-:]\s*(?:\s<<prop>>[ \t]+)?[|>])[ \t]*(?:((?:\r?\n|\r)[ \t]+)\S[^\r\n]*(?:\2[^\r\n]+)*)/.source.replace(/<<prop>>/g, function() {
        return n;
      })),
      lookbehind: !0,
      alias: "string"
    },
    comment: /#.*/,
    key: {
      pattern: RegExp(/((?:^|[:\-,[{\r\n?])[ \t]*(?:<<prop>>[ \t]+)?)<<key>>(?=\s*:\s)/.source.replace(/<<prop>>/g, function() {
        return n;
      }).replace(/<<key>>/g, function() {
        return "(?:" + i + "|" + l + ")";
      })),
      lookbehind: !0,
      greedy: !0,
      alias: "atrule"
    },
    directive: {
      pattern: /(^[ \t]*)%.+/m,
      lookbehind: !0,
      alias: "important"
    },
    datetime: {
      pattern: a(/\d{4}-\d\d?-\d\d?(?:[tT]|[ \t]+)\d\d?:\d{2}:\d{2}(?:\.\d*)?(?:[ \t]*(?:Z|[-+]\d\d?(?::\d{2})?))?|\d{4}-\d{2}-\d{2}|\d\d?:\d{2}(?::\d{2}(?:\.\d*)?)?/.source),
      lookbehind: !0,
      alias: "number"
    },
    boolean: {
      pattern: a(/false|true/.source, "i"),
      lookbehind: !0,
      alias: "important"
    },
    null: {
      pattern: a(/null|~/.source, "i"),
      lookbehind: !0,
      alias: "important"
    },
    string: {
      pattern: a(l),
      lookbehind: !0,
      greedy: !0
    },
    number: {
      pattern: a(/[+-]?(?:0x[\da-f]+|0o[0-7]+|(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?|\.inf|\.nan)/.source, "i"),
      lookbehind: !0
    },
    tag: t,
    important: e,
    punctuation: /---|[:[\]{}\-,|>?]|\.\.\./
  }, r.languages.yml = r.languages.yaml;
})(Prism);
(function(r) {
  function e(t, n) {
    return "___" + t.toUpperCase() + n + "___";
  }
  Object.defineProperties(r.languages["markup-templating"] = {}, {
    buildPlaceholders: {
      /**
       * Tokenize all inline templating expressions matching `placeholderPattern`.
       *
       * If `replaceFilter` is provided, only matches of `placeholderPattern` for which `replaceFilter` returns
       * `true` will be replaced.
       *
       * @param {object} env The environment of the `before-tokenize` hook.
       * @param {string} language The language id.
       * @param {RegExp} placeholderPattern The matches of this pattern will be replaced by placeholders.
       * @param {(match: string) => boolean} [replaceFilter]
       */
      value: function(t, n, i, l) {
        if (t.language === n) {
          var a = t.tokenStack = [];
          t.code = t.code.replace(i, function(o) {
            if (typeof l == "function" && !l(o))
              return o;
            for (var s = a.length, _; t.code.indexOf(_ = e(n, s)) !== -1; )
              ++s;
            return a[s] = o, _;
          }), t.grammar = r.languages.markup;
        }
      }
    },
    tokenizePlaceholders: {
      /**
       * Replace placeholders with proper tokens after tokenizing.
       *
       * @param {object} env The environment of the `after-tokenize` hook.
       * @param {string} language The language id.
       */
      value: function(t, n) {
        if (t.language !== n || !t.tokenStack)
          return;
        t.grammar = r.languages[n];
        var i = 0, l = Object.keys(t.tokenStack);
        function a(o) {
          for (var s = 0; s < o.length && !(i >= l.length); s++) {
            var _ = o[s];
            if (typeof _ == "string" || _.content && typeof _.content == "string") {
              var c = l[i], p = t.tokenStack[c], d = typeof _ == "string" ? _ : _.content, m = e(n, c), g = d.indexOf(m);
              if (g > -1) {
                ++i;
                var v = d.substring(0, g), b = new r.Token(n, r.tokenize(p, t.grammar), "language-" + n, p), F = d.substring(g + m.length), h = [];
                v && h.push.apply(h, a([v])), h.push(b), F && h.push.apply(h, a([F])), typeof _ == "string" ? o.splice.apply(o, [s, 1].concat(h)) : _.content = h;
              }
            } else _.content && a(_.content);
          }
          return o;
        }
        a(t.tokens);
      }
    }
  });
})(Prism);
new Si();
const Ya = (r) => {
  const e = {};
  for (let t = 0, n = r.length; t < n; t++) {
    const i = r[t];
    for (const l in i)
      e[l] ? e[l] = e[l].concat(i[l]) : e[l] = i[l];
  }
  return e;
}, Xa = [
  "abbr",
  "accept",
  "accept-charset",
  "accesskey",
  "action",
  "align",
  "alink",
  "allow",
  "allowfullscreen",
  "alt",
  "anchor",
  "archive",
  "as",
  "async",
  "autocapitalize",
  "autocomplete",
  "autocorrect",
  "autofocus",
  "autopictureinpicture",
  "autoplay",
  "axis",
  "background",
  "behavior",
  "bgcolor",
  "border",
  "bordercolor",
  "capture",
  "cellpadding",
  "cellspacing",
  "challenge",
  "char",
  "charoff",
  "charset",
  "checked",
  "cite",
  "class",
  "classid",
  "clear",
  "code",
  "codebase",
  "codetype",
  "color",
  "cols",
  "colspan",
  "compact",
  "content",
  "contenteditable",
  "controls",
  "controlslist",
  "conversiondestination",
  "coords",
  "crossorigin",
  "csp",
  "data",
  "datetime",
  "declare",
  "decoding",
  "default",
  "defer",
  "dir",
  "direction",
  "dirname",
  "disabled",
  "disablepictureinpicture",
  "disableremoteplayback",
  "disallowdocumentaccess",
  "download",
  "draggable",
  "elementtiming",
  "enctype",
  "end",
  "enterkeyhint",
  "event",
  "exportparts",
  "face",
  "for",
  "form",
  "formaction",
  "formenctype",
  "formmethod",
  "formnovalidate",
  "formtarget",
  "frame",
  "frameborder",
  "headers",
  "height",
  "hidden",
  "high",
  "href",
  "hreflang",
  "hreftranslate",
  "hspace",
  "http-equiv",
  "id",
  "imagesizes",
  "imagesrcset",
  "importance",
  "impressiondata",
  "impressionexpiry",
  "incremental",
  "inert",
  "inputmode",
  "integrity",
  "invisible",
  "ismap",
  "keytype",
  "kind",
  "label",
  "lang",
  "language",
  "latencyhint",
  "leftmargin",
  "link",
  "list",
  "loading",
  "longdesc",
  "loop",
  "low",
  "lowsrc",
  "manifest",
  "marginheight",
  "marginwidth",
  "max",
  "maxlength",
  "mayscript",
  "media",
  "method",
  "min",
  "minlength",
  "multiple",
  "muted",
  "name",
  "nohref",
  "nomodule",
  "nonce",
  "noresize",
  "noshade",
  "novalidate",
  "nowrap",
  "object",
  "open",
  "optimum",
  "part",
  "pattern",
  "ping",
  "placeholder",
  "playsinline",
  "policy",
  "poster",
  "preload",
  "pseudo",
  "readonly",
  "referrerpolicy",
  "rel",
  "reportingorigin",
  "required",
  "resources",
  "rev",
  "reversed",
  "role",
  "rows",
  "rowspan",
  "rules",
  "sandbox",
  "scheme",
  "scope",
  "scopes",
  "scrollamount",
  "scrolldelay",
  "scrolling",
  "select",
  "selected",
  "shadowroot",
  "shadowrootdelegatesfocus",
  "shape",
  "size",
  "sizes",
  "slot",
  "span",
  "spellcheck",
  "src",
  "srclang",
  "srcset",
  "standby",
  "start",
  "step",
  "style",
  "summary",
  "tabindex",
  "target",
  "text",
  "title",
  "topmargin",
  "translate",
  "truespeed",
  "trusttoken",
  "type",
  "usemap",
  "valign",
  "value",
  "valuetype",
  "version",
  "virtualkeyboardpolicy",
  "vlink",
  "vspace",
  "webkitdirectory",
  "width",
  "wrap"
], Wa = [
  "accent-height",
  "accumulate",
  "additive",
  "alignment-baseline",
  "ascent",
  "attributename",
  "attributetype",
  "azimuth",
  "basefrequency",
  "baseline-shift",
  "begin",
  "bias",
  "by",
  "class",
  "clip",
  "clippathunits",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "cx",
  "cy",
  "d",
  "dx",
  "dy",
  "diffuseconstant",
  "direction",
  "display",
  "divisor",
  "dominant-baseline",
  "dur",
  "edgemode",
  "elevation",
  "end",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "filterunits",
  "flood-color",
  "flood-opacity",
  "font-family",
  "font-size",
  "font-size-adjust",
  "font-stretch",
  "font-style",
  "font-variant",
  "font-weight",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyph-name",
  "glyphref",
  "gradientunits",
  "gradienttransform",
  "height",
  "href",
  "id",
  "image-rendering",
  "in",
  "in2",
  "k",
  "k1",
  "k2",
  "k3",
  "k4",
  "kerning",
  "keypoints",
  "keysplines",
  "keytimes",
  "lang",
  "lengthadjust",
  "letter-spacing",
  "kernelmatrix",
  "kernelunitlength",
  "lighting-color",
  "local",
  "marker-end",
  "marker-mid",
  "marker-start",
  "markerheight",
  "markerunits",
  "markerwidth",
  "maskcontentunits",
  "maskunits",
  "max",
  "mask",
  "media",
  "method",
  "mode",
  "min",
  "name",
  "numoctaves",
  "offset",
  "operator",
  "opacity",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "paint-order",
  "path",
  "pathlength",
  "patterncontentunits",
  "patterntransform",
  "patternunits",
  "points",
  "preservealpha",
  "preserveaspectratio",
  "primitiveunits",
  "r",
  "rx",
  "ry",
  "radius",
  "refx",
  "refy",
  "repeatcount",
  "repeatdur",
  "restart",
  "result",
  "rotate",
  "scale",
  "seed",
  "shape-rendering",
  "specularconstant",
  "specularexponent",
  "spreadmethod",
  "startoffset",
  "stddeviation",
  "stitchtiles",
  "stop-color",
  "stop-opacity",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke",
  "stroke-width",
  "style",
  "surfacescale",
  "systemlanguage",
  "tabindex",
  "targetx",
  "targety",
  "transform",
  "transform-origin",
  "text-anchor",
  "text-decoration",
  "text-rendering",
  "textlength",
  "type",
  "u1",
  "u2",
  "unicode",
  "values",
  "viewbox",
  "visibility",
  "version",
  "vert-adv-y",
  "vert-origin-x",
  "vert-origin-y",
  "width",
  "word-spacing",
  "wrap",
  "writing-mode",
  "xchannelselector",
  "ychannelselector",
  "x",
  "x1",
  "x2",
  "xmlns",
  "y",
  "y1",
  "y2",
  "z",
  "zoomandpan"
], Ka = [
  "accent",
  "accentunder",
  "align",
  "bevelled",
  "close",
  "columnsalign",
  "columnlines",
  "columnspan",
  "denomalign",
  "depth",
  "dir",
  "display",
  "displaystyle",
  "encoding",
  "fence",
  "frame",
  "height",
  "href",
  "id",
  "largeop",
  "length",
  "linethickness",
  "lspace",
  "lquote",
  "mathbackground",
  "mathcolor",
  "mathsize",
  "mathvariant",
  "maxsize",
  "minsize",
  "movablelimits",
  "notation",
  "numalign",
  "open",
  "rowalign",
  "rowlines",
  "rowspacing",
  "rowspan",
  "rspace",
  "rquote",
  "scriptlevel",
  "scriptminsize",
  "scriptsizemultiplier",
  "selection",
  "separator",
  "separators",
  "stretchy",
  "subscriptshift",
  "supscriptshift",
  "symmetric",
  "voffset",
  "width",
  "xmlns"
];
Ya([
  Object.fromEntries(Xa.map((r) => [r, ["*"]])),
  Object.fromEntries(Wa.map((r) => [r, ["svg:*"]])),
  Object.fromEntries(Ka.map((r) => [r, ["math:*"]]))
]);
const {
  HtmlTagHydration: Cl,
  SvelteComponent: Al,
  attr: Sl,
  binding_callbacks: Tl,
  children: xl,
  claim_element: Bl,
  claim_html_tag: Il,
  detach: Rl,
  element: ql,
  init: Ll,
  insert_hydration: Nl,
  noop: Ol,
  safe_not_equal: zl,
  toggle_class: Pl
} = window.__gradio__svelte__internal, { afterUpdate: Ml, tick: Ul, onMount: Hl } = window.__gradio__svelte__internal, {
  SvelteComponent: Gl,
  attr: jl,
  children: Zl,
  claim_component: Vl,
  claim_element: Yl,
  create_component: Xl,
  destroy_component: Wl,
  detach: Kl,
  element: Ql,
  init: Jl,
  insert_hydration: eo,
  mount_component: to,
  safe_not_equal: no,
  transition_in: io,
  transition_out: ao
} = window.__gradio__svelte__internal, {
  SvelteComponent: ro,
  attr: lo,
  check_outros: oo,
  children: so,
  claim_component: uo,
  claim_element: co,
  claim_space: _o,
  create_component: po,
  create_slot: ho,
  destroy_component: fo,
  detach: mo,
  element: go,
  empty: bo,
  get_all_dirty_from_scope: vo,
  get_slot_changes: Do,
  group_outros: yo,
  init: $o,
  insert_hydration: wo,
  mount_component: Fo,
  safe_not_equal: Eo,
  space: ko,
  toggle_class: Co,
  transition_in: Ao,
  transition_out: So,
  update_slot_base: To
} = window.__gradio__svelte__internal, {
  SvelteComponent: xo,
  append_hydration: Bo,
  attr: Io,
  children: Ro,
  claim_component: qo,
  claim_element: Lo,
  claim_space: No,
  claim_text: Oo,
  create_component: zo,
  destroy_component: Po,
  detach: Mo,
  element: Uo,
  init: Ho,
  insert_hydration: Go,
  mount_component: jo,
  safe_not_equal: Zo,
  set_data: Vo,
  space: Yo,
  text: Xo,
  toggle_class: Wo,
  transition_in: Ko,
  transition_out: Qo
} = window.__gradio__svelte__internal, {
  SvelteComponent: Jo,
  assign: es,
  children: ts,
  claim_element: ns,
  compute_rest_props: is,
  create_slot: as,
  detach: rs,
  element: ls,
  exclude_internal_props: os,
  get_all_dirty_from_scope: ss,
  get_slot_changes: us,
  get_spread_update: cs,
  init: _s,
  insert_hydration: ds,
  listen: ps,
  safe_not_equal: hs,
  set_attributes: fs,
  set_style: ms,
  toggle_class: gs,
  transition_in: bs,
  transition_out: vs,
  update_slot_base: Ds
} = window.__gradio__svelte__internal, { createEventDispatcher: ys } = window.__gradio__svelte__internal, {
  SvelteComponent: Qa,
  append_hydration: bt,
  attr: ke,
  bubble: Ja,
  check_outros: er,
  children: Gt,
  claim_component: tr,
  claim_element: jt,
  claim_space: An,
  claim_text: nr,
  construct_svelte_component: Sn,
  create_component: Tn,
  create_slot: ir,
  destroy_component: xn,
  detach: Je,
  element: Zt,
  get_all_dirty_from_scope: ar,
  get_slot_changes: rr,
  group_outros: lr,
  init: or,
  insert_hydration: Ti,
  listen: sr,
  mount_component: Bn,
  safe_not_equal: ur,
  set_data: cr,
  set_style: Ue,
  space: In,
  text: _r,
  toggle_class: H,
  transition_in: It,
  transition_out: Rt,
  update_slot_base: dr
} = window.__gradio__svelte__internal;
function Rn(r) {
  let e, t;
  return {
    c() {
      e = Zt("span"), t = _r(
        /*label*/
        r[1]
      ), this.h();
    },
    l(n) {
      e = jt(n, "SPAN", { class: !0 });
      var i = Gt(e);
      t = nr(
        i,
        /*label*/
        r[1]
      ), i.forEach(Je), this.h();
    },
    h() {
      ke(e, "class", "svelte-y0enk4");
    },
    m(n, i) {
      Ti(n, e, i), bt(e, t);
    },
    p(n, i) {
      i & /*label*/
      2 && cr(
        t,
        /*label*/
        n[1]
      );
    },
    d(n) {
      n && Je(e);
    }
  };
}
function pr(r) {
  let e, t, n, i, l, a, o, s, _ = (
    /*show_label*/
    r[2] && Rn(r)
  );
  var c = (
    /*Icon*/
    r[0]
  );
  function p(g, v) {
    return {};
  }
  c && (i = Sn(c, p()));
  const d = (
    /*#slots*/
    r[15].default
  ), m = ir(
    d,
    r,
    /*$$scope*/
    r[14],
    null
  );
  return {
    c() {
      e = Zt("button"), _ && _.c(), t = In(), n = Zt("div"), i && Tn(i.$$.fragment), l = In(), m && m.c(), this.h();
    },
    l(g) {
      e = jt(g, "BUTTON", {
        class: !0,
        "aria-label": !0,
        "aria-haspopup": !0,
        title: !0
      });
      var v = Gt(e);
      _ && _.l(v), t = An(v), n = jt(v, "DIV", { class: !0 });
      var b = Gt(n);
      i && tr(i.$$.fragment, b), l = An(b), m && m.l(b), b.forEach(Je), v.forEach(Je), this.h();
    },
    h() {
      ke(n, "class", "svelte-y0enk4"), H(
        n,
        "x-small",
        /*size*/
        r[4] === "x-small"
      ), H(
        n,
        "small",
        /*size*/
        r[4] === "small"
      ), H(
        n,
        "large",
        /*size*/
        r[4] === "large"
      ), H(
        n,
        "medium",
        /*size*/
        r[4] === "medium"
      ), ke(e, "class", "icon-button svelte-y0enk4"), e.disabled = /*disabled*/
      r[7], ke(
        e,
        "aria-label",
        /*label*/
        r[1]
      ), ke(
        e,
        "aria-haspopup",
        /*hasPopup*/
        r[8]
      ), ke(
        e,
        "title",
        /*label*/
        r[1]
      ), H(
        e,
        "pending",
        /*pending*/
        r[3]
      ), H(
        e,
        "padded",
        /*padded*/
        r[5]
      ), H(
        e,
        "highlight",
        /*highlight*/
        r[6]
      ), H(
        e,
        "transparent",
        /*transparent*/
        r[9]
      ), Ue(
        e,
        "--border-color",
        /*border*/
        r[11]
      ), Ue(e, "color", !/*disabled*/
      r[7] && /*_color*/
      r[12] ? (
        /*_color*/
        r[12]
      ) : "var(--block-label-text-color)"), Ue(e, "--bg-color", /*disabled*/
      r[7] ? "auto" : (
        /*background*/
        r[10]
      ));
    },
    m(g, v) {
      Ti(g, e, v), _ && _.m(e, null), bt(e, t), bt(e, n), i && Bn(i, n, null), bt(n, l), m && m.m(n, null), a = !0, o || (s = sr(
        e,
        "click",
        /*click_handler*/
        r[16]
      ), o = !0);
    },
    p(g, [v]) {
      if (/*show_label*/
      g[2] ? _ ? _.p(g, v) : (_ = Rn(g), _.c(), _.m(e, t)) : _ && (_.d(1), _ = null), v & /*Icon*/
      1 && c !== (c = /*Icon*/
      g[0])) {
        if (i) {
          lr();
          const b = i;
          Rt(b.$$.fragment, 1, 0, () => {
            xn(b, 1);
          }), er();
        }
        c ? (i = Sn(c, p()), Tn(i.$$.fragment), It(i.$$.fragment, 1), Bn(i, n, l)) : i = null;
      }
      m && m.p && (!a || v & /*$$scope*/
      16384) && dr(
        m,
        d,
        g,
        /*$$scope*/
        g[14],
        a ? rr(
          d,
          /*$$scope*/
          g[14],
          v,
          null
        ) : ar(
          /*$$scope*/
          g[14]
        ),
        null
      ), (!a || v & /*size*/
      16) && H(
        n,
        "x-small",
        /*size*/
        g[4] === "x-small"
      ), (!a || v & /*size*/
      16) && H(
        n,
        "small",
        /*size*/
        g[4] === "small"
      ), (!a || v & /*size*/
      16) && H(
        n,
        "large",
        /*size*/
        g[4] === "large"
      ), (!a || v & /*size*/
      16) && H(
        n,
        "medium",
        /*size*/
        g[4] === "medium"
      ), (!a || v & /*disabled*/
      128) && (e.disabled = /*disabled*/
      g[7]), (!a || v & /*label*/
      2) && ke(
        e,
        "aria-label",
        /*label*/
        g[1]
      ), (!a || v & /*hasPopup*/
      256) && ke(
        e,
        "aria-haspopup",
        /*hasPopup*/
        g[8]
      ), (!a || v & /*label*/
      2) && ke(
        e,
        "title",
        /*label*/
        g[1]
      ), (!a || v & /*pending*/
      8) && H(
        e,
        "pending",
        /*pending*/
        g[3]
      ), (!a || v & /*padded*/
      32) && H(
        e,
        "padded",
        /*padded*/
        g[5]
      ), (!a || v & /*highlight*/
      64) && H(
        e,
        "highlight",
        /*highlight*/
        g[6]
      ), (!a || v & /*transparent*/
      512) && H(
        e,
        "transparent",
        /*transparent*/
        g[9]
      ), v & /*border*/
      2048 && Ue(
        e,
        "--border-color",
        /*border*/
        g[11]
      ), v & /*disabled, _color*/
      4224 && Ue(e, "color", !/*disabled*/
      g[7] && /*_color*/
      g[12] ? (
        /*_color*/
        g[12]
      ) : "var(--block-label-text-color)"), v & /*disabled, background*/
      1152 && Ue(e, "--bg-color", /*disabled*/
      g[7] ? "auto" : (
        /*background*/
        g[10]
      ));
    },
    i(g) {
      a || (i && It(i.$$.fragment, g), It(m, g), a = !0);
    },
    o(g) {
      i && Rt(i.$$.fragment, g), Rt(m, g), a = !1;
    },
    d(g) {
      g && Je(e), _ && _.d(), i && xn(i), m && m.d(g), o = !1, s();
    }
  };
}
function hr(r, e, t) {
  let n, { $$slots: i = {}, $$scope: l } = e, { Icon: a } = e, { label: o = "" } = e, { show_label: s = !1 } = e, { pending: _ = !1 } = e, { size: c = "small" } = e, { padded: p = !0 } = e, { highlight: d = !1 } = e, { disabled: m = !1 } = e, { hasPopup: g = !1 } = e, { color: v = "var(--block-label-text-color)" } = e, { transparent: b = !1 } = e, { background: F = "var(--block-background-fill)" } = e, { border: h = "transparent" } = e;
  function u(f) {
    Ja.call(this, r, f);
  }
  return r.$$set = (f) => {
    "Icon" in f && t(0, a = f.Icon), "label" in f && t(1, o = f.label), "show_label" in f && t(2, s = f.show_label), "pending" in f && t(3, _ = f.pending), "size" in f && t(4, c = f.size), "padded" in f && t(5, p = f.padded), "highlight" in f && t(6, d = f.highlight), "disabled" in f && t(7, m = f.disabled), "hasPopup" in f && t(8, g = f.hasPopup), "color" in f && t(13, v = f.color), "transparent" in f && t(9, b = f.transparent), "background" in f && t(10, F = f.background), "border" in f && t(11, h = f.border), "$$scope" in f && t(14, l = f.$$scope);
  }, r.$$.update = () => {
    r.$$.dirty & /*highlight, color*/
    8256 && t(12, n = d ? "var(--color-accent)" : v);
  }, [
    a,
    o,
    s,
    _,
    c,
    p,
    d,
    m,
    g,
    b,
    F,
    h,
    n,
    v,
    l,
    i,
    u
  ];
}
class xi extends Qa {
  constructor(e) {
    super(), or(this, e, hr, pr, ur, {
      Icon: 0,
      label: 1,
      show_label: 2,
      pending: 3,
      size: 4,
      padded: 5,
      highlight: 6,
      disabled: 7,
      hasPopup: 8,
      color: 13,
      transparent: 9,
      background: 10,
      border: 11
    });
  }
}
const {
  SvelteComponent: $s,
  append_hydration: ws,
  attr: Fs,
  binding_callbacks: Es,
  children: ks,
  claim_element: Cs,
  create_slot: As,
  detach: Ss,
  element: Ts,
  get_all_dirty_from_scope: xs,
  get_slot_changes: Bs,
  init: Is,
  insert_hydration: Rs,
  safe_not_equal: qs,
  toggle_class: Ls,
  transition_in: Ns,
  transition_out: Os,
  update_slot_base: zs
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ps,
  append_hydration: Ms,
  attr: Us,
  children: Hs,
  claim_svg_element: Gs,
  detach: js,
  init: Zs,
  insert_hydration: Vs,
  noop: Ys,
  safe_not_equal: Xs,
  svg_element: Ws
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ks,
  append_hydration: Qs,
  attr: Js,
  children: eu,
  claim_svg_element: tu,
  detach: nu,
  init: iu,
  insert_hydration: au,
  noop: ru,
  safe_not_equal: lu,
  svg_element: ou
} = window.__gradio__svelte__internal, {
  SvelteComponent: su,
  append_hydration: uu,
  attr: cu,
  children: _u,
  claim_svg_element: du,
  detach: pu,
  init: hu,
  insert_hydration: fu,
  noop: mu,
  safe_not_equal: gu,
  svg_element: bu
} = window.__gradio__svelte__internal, {
  SvelteComponent: vu,
  append_hydration: Du,
  attr: yu,
  children: $u,
  claim_svg_element: wu,
  detach: Fu,
  init: Eu,
  insert_hydration: ku,
  noop: Cu,
  safe_not_equal: Au,
  svg_element: Su
} = window.__gradio__svelte__internal, {
  SvelteComponent: Tu,
  append_hydration: xu,
  attr: Bu,
  children: Iu,
  claim_svg_element: Ru,
  detach: qu,
  init: Lu,
  insert_hydration: Nu,
  noop: Ou,
  safe_not_equal: zu,
  svg_element: Pu
} = window.__gradio__svelte__internal, {
  SvelteComponent: Mu,
  append_hydration: Uu,
  attr: Hu,
  children: Gu,
  claim_svg_element: ju,
  detach: Zu,
  init: Vu,
  insert_hydration: Yu,
  noop: Xu,
  safe_not_equal: Wu,
  svg_element: Ku
} = window.__gradio__svelte__internal, {
  SvelteComponent: Qu,
  append_hydration: Ju,
  attr: ec,
  children: tc,
  claim_svg_element: nc,
  detach: ic,
  init: ac,
  insert_hydration: rc,
  noop: lc,
  safe_not_equal: oc,
  svg_element: sc
} = window.__gradio__svelte__internal, {
  SvelteComponent: uc,
  append_hydration: cc,
  attr: _c,
  children: dc,
  claim_svg_element: pc,
  detach: hc,
  init: fc,
  insert_hydration: mc,
  noop: gc,
  safe_not_equal: bc,
  svg_element: vc
} = window.__gradio__svelte__internal, {
  SvelteComponent: Dc,
  append_hydration: yc,
  attr: $c,
  children: wc,
  claim_svg_element: Fc,
  detach: Ec,
  init: kc,
  insert_hydration: Cc,
  noop: Ac,
  safe_not_equal: Sc,
  svg_element: Tc
} = window.__gradio__svelte__internal, {
  SvelteComponent: xc,
  append_hydration: Bc,
  attr: Ic,
  children: Rc,
  claim_svg_element: qc,
  detach: Lc,
  init: Nc,
  insert_hydration: Oc,
  noop: zc,
  safe_not_equal: Pc,
  svg_element: Mc
} = window.__gradio__svelte__internal, {
  SvelteComponent: Uc,
  append_hydration: Hc,
  attr: Gc,
  children: jc,
  claim_svg_element: Zc,
  detach: Vc,
  init: Yc,
  insert_hydration: Xc,
  noop: Wc,
  safe_not_equal: Kc,
  svg_element: Qc
} = window.__gradio__svelte__internal, {
  SvelteComponent: Jc,
  append_hydration: e_,
  attr: t_,
  children: n_,
  claim_svg_element: i_,
  detach: a_,
  init: r_,
  insert_hydration: l_,
  noop: o_,
  safe_not_equal: s_,
  svg_element: u_
} = window.__gradio__svelte__internal, {
  SvelteComponent: fr,
  append_hydration: qt,
  attr: _e,
  children: pt,
  claim_svg_element: ht,
  detach: Ye,
  init: mr,
  insert_hydration: gr,
  noop: Lt,
  safe_not_equal: br,
  set_style: De,
  svg_element: ft
} = window.__gradio__svelte__internal;
function vr(r) {
  let e, t, n, i;
  return {
    c() {
      e = ft("svg"), t = ft("g"), n = ft("path"), i = ft("path"), this.h();
    },
    l(l) {
      e = ht(l, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        version: !0,
        xmlns: !0,
        "xmlns:xlink": !0,
        "xml:space": !0,
        stroke: !0,
        style: !0
      });
      var a = pt(e);
      t = ht(a, "g", { transform: !0 });
      var o = pt(t);
      n = ht(o, "path", { d: !0, style: !0 }), pt(n).forEach(Ye), o.forEach(Ye), i = ht(a, "path", { d: !0, style: !0 }), pt(i).forEach(Ye), a.forEach(Ye), this.h();
    },
    h() {
      _e(n, "d", "M18,6L6.087,17.913"), De(n, "fill", "none"), De(n, "fill-rule", "nonzero"), De(n, "stroke-width", "2px"), _e(t, "transform", "matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"), _e(i, "d", "M4.364,4.364L19.636,19.636"), De(i, "fill", "none"), De(i, "fill-rule", "nonzero"), De(i, "stroke-width", "2px"), _e(e, "width", "100%"), _e(e, "height", "100%"), _e(e, "viewBox", "0 0 24 24"), _e(e, "version", "1.1"), _e(e, "xmlns", "http://www.w3.org/2000/svg"), _e(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), _e(e, "xml:space", "preserve"), _e(e, "stroke", "currentColor"), De(e, "fill-rule", "evenodd"), De(e, "clip-rule", "evenodd"), De(e, "stroke-linecap", "round"), De(e, "stroke-linejoin", "round");
    },
    m(l, a) {
      gr(l, e, a), qt(e, t), qt(t, n), qt(e, i);
    },
    p: Lt,
    i: Lt,
    o: Lt,
    d(l) {
      l && Ye(e);
    }
  };
}
class Bi extends fr {
  constructor(e) {
    super(), mr(this, e, null, vr, br, {});
  }
}
const {
  SvelteComponent: c_,
  append_hydration: __,
  attr: d_,
  children: p_,
  claim_svg_element: h_,
  claim_text: f_,
  detach: m_,
  init: g_,
  insert_hydration: b_,
  noop: v_,
  safe_not_equal: D_,
  svg_element: y_,
  text: $_
} = window.__gradio__svelte__internal, {
  SvelteComponent: w_,
  append_hydration: F_,
  attr: E_,
  children: k_,
  claim_svg_element: C_,
  detach: A_,
  init: S_,
  insert_hydration: T_,
  noop: x_,
  safe_not_equal: B_,
  svg_element: I_
} = window.__gradio__svelte__internal, {
  SvelteComponent: R_,
  append_hydration: q_,
  attr: L_,
  children: N_,
  claim_svg_element: O_,
  detach: z_,
  init: P_,
  insert_hydration: M_,
  noop: U_,
  safe_not_equal: H_,
  svg_element: G_
} = window.__gradio__svelte__internal, {
  SvelteComponent: j_,
  append_hydration: Z_,
  attr: V_,
  children: Y_,
  claim_svg_element: X_,
  detach: W_,
  init: K_,
  insert_hydration: Q_,
  noop: J_,
  safe_not_equal: ed,
  svg_element: td
} = window.__gradio__svelte__internal, {
  SvelteComponent: nd,
  append_hydration: id,
  attr: ad,
  children: rd,
  claim_svg_element: ld,
  detach: od,
  init: sd,
  insert_hydration: ud,
  noop: cd,
  safe_not_equal: _d,
  svg_element: dd
} = window.__gradio__svelte__internal, {
  SvelteComponent: pd,
  append_hydration: hd,
  attr: fd,
  children: md,
  claim_svg_element: gd,
  detach: bd,
  init: vd,
  insert_hydration: Dd,
  noop: yd,
  safe_not_equal: $d,
  svg_element: wd
} = window.__gradio__svelte__internal, {
  SvelteComponent: Fd,
  append_hydration: Ed,
  attr: kd,
  children: Cd,
  claim_svg_element: Ad,
  detach: Sd,
  init: Td,
  insert_hydration: xd,
  noop: Bd,
  safe_not_equal: Id,
  svg_element: Rd
} = window.__gradio__svelte__internal, {
  SvelteComponent: qd,
  append_hydration: Ld,
  attr: Nd,
  children: Od,
  claim_svg_element: zd,
  detach: Pd,
  init: Md,
  insert_hydration: Ud,
  noop: Hd,
  safe_not_equal: Gd,
  svg_element: jd
} = window.__gradio__svelte__internal, {
  SvelteComponent: Zd,
  append_hydration: Vd,
  attr: Yd,
  children: Xd,
  claim_svg_element: Wd,
  detach: Kd,
  init: Qd,
  insert_hydration: Jd,
  noop: ep,
  safe_not_equal: tp,
  svg_element: np
} = window.__gradio__svelte__internal, {
  SvelteComponent: ip,
  append_hydration: ap,
  attr: rp,
  children: lp,
  claim_svg_element: op,
  detach: sp,
  init: up,
  insert_hydration: cp,
  noop: _p,
  safe_not_equal: dp,
  svg_element: pp
} = window.__gradio__svelte__internal, {
  SvelteComponent: hp,
  append_hydration: fp,
  attr: mp,
  children: gp,
  claim_svg_element: bp,
  detach: vp,
  init: Dp,
  insert_hydration: yp,
  noop: $p,
  safe_not_equal: wp,
  svg_element: Fp
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ep,
  append_hydration: kp,
  attr: Cp,
  children: Ap,
  claim_svg_element: Sp,
  detach: Tp,
  init: xp,
  insert_hydration: Bp,
  noop: Ip,
  safe_not_equal: Rp,
  svg_element: qp
} = window.__gradio__svelte__internal, {
  SvelteComponent: Lp,
  append_hydration: Np,
  attr: Op,
  children: zp,
  claim_svg_element: Pp,
  detach: Mp,
  init: Up,
  insert_hydration: Hp,
  noop: Gp,
  safe_not_equal: jp,
  svg_element: Zp
} = window.__gradio__svelte__internal, {
  SvelteComponent: Vp,
  append_hydration: Yp,
  attr: Xp,
  children: Wp,
  claim_svg_element: Kp,
  detach: Qp,
  init: Jp,
  insert_hydration: eh,
  noop: th,
  safe_not_equal: nh,
  svg_element: ih
} = window.__gradio__svelte__internal, {
  SvelteComponent: ah,
  append_hydration: rh,
  attr: lh,
  children: oh,
  claim_svg_element: sh,
  detach: uh,
  init: ch,
  insert_hydration: _h,
  noop: dh,
  safe_not_equal: ph,
  svg_element: hh
} = window.__gradio__svelte__internal, {
  SvelteComponent: fh,
  append_hydration: mh,
  attr: gh,
  children: bh,
  claim_svg_element: vh,
  detach: Dh,
  init: yh,
  insert_hydration: $h,
  noop: wh,
  safe_not_equal: Fh,
  svg_element: Eh
} = window.__gradio__svelte__internal, {
  SvelteComponent: kh,
  append_hydration: Ch,
  attr: Ah,
  children: Sh,
  claim_svg_element: Th,
  detach: xh,
  init: Bh,
  insert_hydration: Ih,
  noop: Rh,
  safe_not_equal: qh,
  svg_element: Lh
} = window.__gradio__svelte__internal, {
  SvelteComponent: Nh,
  append_hydration: Oh,
  attr: zh,
  children: Ph,
  claim_svg_element: Mh,
  detach: Uh,
  init: Hh,
  insert_hydration: Gh,
  noop: jh,
  safe_not_equal: Zh,
  svg_element: Vh
} = window.__gradio__svelte__internal, {
  SvelteComponent: Yh,
  append_hydration: Xh,
  attr: Wh,
  children: Kh,
  claim_svg_element: Qh,
  detach: Jh,
  init: ef,
  insert_hydration: tf,
  noop: nf,
  safe_not_equal: af,
  svg_element: rf
} = window.__gradio__svelte__internal, {
  SvelteComponent: lf,
  append_hydration: of,
  attr: sf,
  children: uf,
  claim_svg_element: cf,
  detach: _f,
  init: df,
  insert_hydration: pf,
  noop: hf,
  safe_not_equal: ff,
  svg_element: mf
} = window.__gradio__svelte__internal, {
  SvelteComponent: gf,
  append_hydration: bf,
  attr: vf,
  children: Df,
  claim_svg_element: yf,
  detach: $f,
  init: wf,
  insert_hydration: Ff,
  noop: Ef,
  safe_not_equal: kf,
  svg_element: Cf
} = window.__gradio__svelte__internal, {
  SvelteComponent: Af,
  append_hydration: Sf,
  attr: Tf,
  children: xf,
  claim_svg_element: Bf,
  detach: If,
  init: Rf,
  insert_hydration: qf,
  noop: Lf,
  safe_not_equal: Nf,
  svg_element: Of
} = window.__gradio__svelte__internal, {
  SvelteComponent: zf,
  append_hydration: Pf,
  attr: Mf,
  children: Uf,
  claim_svg_element: Hf,
  detach: Gf,
  init: jf,
  insert_hydration: Zf,
  noop: Vf,
  safe_not_equal: Yf,
  svg_element: Xf
} = window.__gradio__svelte__internal, {
  SvelteComponent: Wf,
  append_hydration: Kf,
  attr: Qf,
  children: Jf,
  claim_svg_element: em,
  detach: tm,
  init: nm,
  insert_hydration: im,
  noop: am,
  safe_not_equal: rm,
  svg_element: lm
} = window.__gradio__svelte__internal, {
  SvelteComponent: om,
  append_hydration: sm,
  attr: um,
  children: cm,
  claim_svg_element: _m,
  detach: dm,
  init: pm,
  insert_hydration: hm,
  noop: fm,
  safe_not_equal: mm,
  svg_element: gm
} = window.__gradio__svelte__internal, {
  SvelteComponent: bm,
  append_hydration: vm,
  attr: Dm,
  children: ym,
  claim_svg_element: $m,
  detach: wm,
  init: Fm,
  insert_hydration: Em,
  noop: km,
  safe_not_equal: Cm,
  svg_element: Am
} = window.__gradio__svelte__internal, {
  SvelteComponent: Sm,
  append_hydration: Tm,
  attr: xm,
  children: Bm,
  claim_svg_element: Im,
  detach: Rm,
  init: qm,
  insert_hydration: Lm,
  noop: Nm,
  safe_not_equal: Om,
  svg_element: zm
} = window.__gradio__svelte__internal, {
  SvelteComponent: Pm,
  append_hydration: Mm,
  attr: Um,
  children: Hm,
  claim_svg_element: Gm,
  detach: jm,
  init: Zm,
  insert_hydration: Vm,
  noop: Ym,
  safe_not_equal: Xm,
  svg_element: Wm
} = window.__gradio__svelte__internal, {
  SvelteComponent: Km,
  append_hydration: Qm,
  attr: Jm,
  children: eg,
  claim_svg_element: tg,
  detach: ng,
  init: ig,
  insert_hydration: ag,
  noop: rg,
  safe_not_equal: lg,
  svg_element: og
} = window.__gradio__svelte__internal, {
  SvelteComponent: sg,
  append_hydration: ug,
  attr: cg,
  children: _g,
  claim_svg_element: dg,
  detach: pg,
  init: hg,
  insert_hydration: fg,
  noop: mg,
  safe_not_equal: gg,
  svg_element: bg
} = window.__gradio__svelte__internal, {
  SvelteComponent: vg,
  append_hydration: Dg,
  attr: yg,
  children: $g,
  claim_svg_element: wg,
  detach: Fg,
  init: Eg,
  insert_hydration: kg,
  noop: Cg,
  safe_not_equal: Ag,
  svg_element: Sg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Tg,
  append_hydration: xg,
  attr: Bg,
  children: Ig,
  claim_svg_element: Rg,
  detach: qg,
  init: Lg,
  insert_hydration: Ng,
  noop: Og,
  safe_not_equal: zg,
  svg_element: Pg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Mg,
  append_hydration: Ug,
  attr: Hg,
  children: Gg,
  claim_svg_element: jg,
  detach: Zg,
  init: Vg,
  insert_hydration: Yg,
  noop: Xg,
  safe_not_equal: Wg,
  svg_element: Kg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Qg,
  append_hydration: Jg,
  attr: e0,
  children: t0,
  claim_svg_element: n0,
  detach: i0,
  init: a0,
  insert_hydration: r0,
  noop: l0,
  safe_not_equal: o0,
  svg_element: s0
} = window.__gradio__svelte__internal, {
  SvelteComponent: u0,
  append_hydration: c0,
  attr: _0,
  children: d0,
  claim_svg_element: p0,
  detach: h0,
  init: f0,
  insert_hydration: m0,
  noop: g0,
  safe_not_equal: b0,
  set_style: v0,
  svg_element: D0
} = window.__gradio__svelte__internal, {
  SvelteComponent: y0,
  append_hydration: $0,
  attr: w0,
  children: F0,
  claim_svg_element: E0,
  detach: k0,
  init: C0,
  insert_hydration: A0,
  noop: S0,
  safe_not_equal: T0,
  svg_element: x0
} = window.__gradio__svelte__internal, {
  SvelteComponent: B0,
  append_hydration: I0,
  attr: R0,
  children: q0,
  claim_svg_element: L0,
  detach: N0,
  init: O0,
  insert_hydration: z0,
  noop: P0,
  safe_not_equal: M0,
  svg_element: U0
} = window.__gradio__svelte__internal, {
  SvelteComponent: H0,
  append_hydration: G0,
  attr: j0,
  children: Z0,
  claim_svg_element: V0,
  detach: Y0,
  init: X0,
  insert_hydration: W0,
  noop: K0,
  safe_not_equal: Q0,
  svg_element: J0
} = window.__gradio__svelte__internal, {
  SvelteComponent: e1,
  append_hydration: t1,
  attr: n1,
  children: i1,
  claim_svg_element: a1,
  detach: r1,
  init: l1,
  insert_hydration: o1,
  noop: s1,
  safe_not_equal: u1,
  svg_element: c1
} = window.__gradio__svelte__internal, {
  SvelteComponent: _1,
  append_hydration: d1,
  attr: p1,
  children: h1,
  claim_svg_element: f1,
  detach: m1,
  init: g1,
  insert_hydration: b1,
  noop: v1,
  safe_not_equal: D1,
  svg_element: y1
} = window.__gradio__svelte__internal, {
  SvelteComponent: $1,
  append_hydration: w1,
  attr: F1,
  children: E1,
  claim_svg_element: k1,
  detach: C1,
  init: A1,
  insert_hydration: S1,
  noop: T1,
  safe_not_equal: x1,
  svg_element: B1
} = window.__gradio__svelte__internal, {
  SvelteComponent: I1,
  append_hydration: R1,
  attr: q1,
  children: L1,
  claim_svg_element: N1,
  detach: O1,
  init: z1,
  insert_hydration: P1,
  noop: M1,
  safe_not_equal: U1,
  svg_element: H1
} = window.__gradio__svelte__internal, {
  SvelteComponent: G1,
  append_hydration: j1,
  attr: Z1,
  children: V1,
  claim_svg_element: Y1,
  detach: X1,
  init: W1,
  insert_hydration: K1,
  noop: Q1,
  safe_not_equal: J1,
  svg_element: eb
} = window.__gradio__svelte__internal, {
  SvelteComponent: tb,
  append_hydration: nb,
  attr: ib,
  children: ab,
  claim_svg_element: rb,
  claim_text: lb,
  detach: ob,
  init: sb,
  insert_hydration: ub,
  noop: cb,
  safe_not_equal: _b,
  svg_element: db,
  text: pb
} = window.__gradio__svelte__internal, {
  SvelteComponent: hb,
  append_hydration: fb,
  attr: mb,
  children: gb,
  claim_svg_element: bb,
  detach: vb,
  init: Db,
  insert_hydration: yb,
  noop: $b,
  safe_not_equal: wb,
  svg_element: Fb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Eb,
  append_hydration: kb,
  attr: Cb,
  children: Ab,
  claim_svg_element: Sb,
  detach: Tb,
  init: xb,
  insert_hydration: Bb,
  noop: Ib,
  safe_not_equal: Rb,
  svg_element: qb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Lb,
  append_hydration: Nb,
  attr: Ob,
  children: zb,
  claim_svg_element: Pb,
  detach: Mb,
  init: Ub,
  insert_hydration: Hb,
  noop: Gb,
  safe_not_equal: jb,
  svg_element: Zb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Vb,
  append_hydration: Yb,
  attr: Xb,
  children: Wb,
  claim_svg_element: Kb,
  detach: Qb,
  init: Jb,
  insert_hydration: ev,
  noop: tv,
  safe_not_equal: nv,
  svg_element: iv
} = window.__gradio__svelte__internal, {
  SvelteComponent: av,
  append_hydration: rv,
  attr: lv,
  children: ov,
  claim_svg_element: sv,
  detach: uv,
  init: cv,
  insert_hydration: _v,
  noop: dv,
  safe_not_equal: pv,
  svg_element: hv
} = window.__gradio__svelte__internal, {
  SvelteComponent: fv,
  append_hydration: mv,
  attr: gv,
  children: bv,
  claim_svg_element: vv,
  detach: Dv,
  init: yv,
  insert_hydration: $v,
  noop: wv,
  safe_not_equal: Fv,
  svg_element: Ev
} = window.__gradio__svelte__internal, {
  SvelteComponent: kv,
  append_hydration: Cv,
  attr: Av,
  children: Sv,
  claim_svg_element: Tv,
  detach: xv,
  init: Bv,
  insert_hydration: Iv,
  noop: Rv,
  safe_not_equal: qv,
  svg_element: Lv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Nv,
  append_hydration: Ov,
  attr: zv,
  children: Pv,
  claim_svg_element: Mv,
  claim_text: Uv,
  detach: Hv,
  init: Gv,
  insert_hydration: jv,
  noop: Zv,
  safe_not_equal: Vv,
  svg_element: Yv,
  text: Xv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Wv,
  append_hydration: Kv,
  attr: Qv,
  children: Jv,
  claim_svg_element: eD,
  claim_text: tD,
  detach: nD,
  init: iD,
  insert_hydration: aD,
  noop: rD,
  safe_not_equal: lD,
  svg_element: oD,
  text: sD
} = window.__gradio__svelte__internal, {
  SvelteComponent: uD,
  append_hydration: cD,
  attr: _D,
  children: dD,
  claim_svg_element: pD,
  claim_text: hD,
  detach: fD,
  init: mD,
  insert_hydration: gD,
  noop: bD,
  safe_not_equal: vD,
  svg_element: DD,
  text: yD
} = window.__gradio__svelte__internal, {
  SvelteComponent: $D,
  append_hydration: wD,
  attr: FD,
  children: ED,
  claim_svg_element: kD,
  detach: CD,
  init: AD,
  insert_hydration: SD,
  noop: TD,
  safe_not_equal: xD,
  svg_element: BD
} = window.__gradio__svelte__internal, {
  SvelteComponent: ID,
  append_hydration: RD,
  attr: qD,
  children: LD,
  claim_svg_element: ND,
  detach: OD,
  init: zD,
  insert_hydration: PD,
  noop: MD,
  safe_not_equal: UD,
  svg_element: HD
} = window.__gradio__svelte__internal, {
  SvelteComponent: GD,
  append_hydration: jD,
  attr: ZD,
  children: VD,
  claim_svg_element: YD,
  detach: XD,
  init: WD,
  insert_hydration: KD,
  noop: QD,
  safe_not_equal: JD,
  svg_element: ey
} = window.__gradio__svelte__internal, {
  SvelteComponent: ty,
  append_hydration: ny,
  attr: iy,
  children: ay,
  claim_svg_element: ry,
  detach: ly,
  init: oy,
  insert_hydration: sy,
  noop: uy,
  safe_not_equal: cy,
  svg_element: _y
} = window.__gradio__svelte__internal, {
  SvelteComponent: dy,
  append_hydration: py,
  attr: hy,
  children: fy,
  claim_svg_element: my,
  detach: gy,
  init: by,
  insert_hydration: vy,
  noop: Dy,
  safe_not_equal: yy,
  svg_element: $y
} = window.__gradio__svelte__internal, {
  SvelteComponent: wy,
  append_hydration: Fy,
  attr: Ey,
  children: ky,
  claim_svg_element: Cy,
  detach: Ay,
  init: Sy,
  insert_hydration: Ty,
  noop: xy,
  safe_not_equal: By,
  svg_element: Iy
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ry,
  append_hydration: qy,
  attr: Ly,
  children: Ny,
  claim_svg_element: Oy,
  detach: zy,
  init: Py,
  insert_hydration: My,
  noop: Uy,
  safe_not_equal: Hy,
  svg_element: Gy
} = window.__gradio__svelte__internal, {
  SvelteComponent: jy,
  append_hydration: Zy,
  attr: Vy,
  children: Yy,
  claim_svg_element: Xy,
  detach: Wy,
  init: Ky,
  insert_hydration: Qy,
  noop: Jy,
  safe_not_equal: e$,
  svg_element: t$
} = window.__gradio__svelte__internal, {
  SvelteComponent: n$,
  append_hydration: i$,
  attr: a$,
  children: r$,
  claim_svg_element: l$,
  detach: o$,
  init: s$,
  insert_hydration: u$,
  noop: c$,
  safe_not_equal: _$,
  svg_element: d$
} = window.__gradio__svelte__internal, {
  SvelteComponent: p$,
  append_hydration: h$,
  attr: f$,
  children: m$,
  claim_svg_element: g$,
  detach: b$,
  init: v$,
  insert_hydration: D$,
  noop: y$,
  safe_not_equal: $$,
  svg_element: w$
} = window.__gradio__svelte__internal, {
  SvelteComponent: F$,
  append_hydration: E$,
  attr: k$,
  children: C$,
  claim_svg_element: A$,
  detach: S$,
  init: T$,
  insert_hydration: x$,
  noop: B$,
  safe_not_equal: I$,
  svg_element: R$
} = window.__gradio__svelte__internal, Dr = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], qn = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
Dr.reduce(
  (r, { color: e, primary: t, secondary: n }) => ({
    ...r,
    [e]: {
      primary: qn[e][t],
      secondary: qn[e][n]
    }
  }),
  {}
);
const {
  SvelteComponent: q$,
  claim_component: L$,
  create_component: N$,
  destroy_component: O$,
  init: z$,
  mount_component: P$,
  safe_not_equal: M$,
  transition_in: U$,
  transition_out: H$
} = window.__gradio__svelte__internal, { createEventDispatcher: G$ } = window.__gradio__svelte__internal, {
  SvelteComponent: j$,
  append_hydration: Z$,
  attr: V$,
  check_outros: Y$,
  children: X$,
  claim_component: W$,
  claim_element: K$,
  claim_space: Q$,
  claim_text: J$,
  create_component: ew,
  destroy_component: tw,
  detach: nw,
  element: iw,
  empty: aw,
  group_outros: rw,
  init: lw,
  insert_hydration: ow,
  mount_component: sw,
  safe_not_equal: uw,
  set_data: cw,
  space: _w,
  text: dw,
  toggle_class: pw,
  transition_in: hw,
  transition_out: fw
} = window.__gradio__svelte__internal, {
  SvelteComponent: mw,
  attr: gw,
  children: bw,
  claim_element: vw,
  create_slot: Dw,
  detach: yw,
  element: $w,
  get_all_dirty_from_scope: ww,
  get_slot_changes: Fw,
  init: Ew,
  insert_hydration: kw,
  safe_not_equal: Cw,
  toggle_class: Aw,
  transition_in: Sw,
  transition_out: Tw,
  update_slot_base: xw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Bw,
  append_hydration: Iw,
  attr: Rw,
  check_outros: qw,
  children: Lw,
  claim_component: Nw,
  claim_element: Ow,
  claim_space: zw,
  create_component: Pw,
  destroy_component: Mw,
  detach: Uw,
  element: Hw,
  empty: Gw,
  group_outros: jw,
  init: Zw,
  insert_hydration: Vw,
  listen: Yw,
  mount_component: Xw,
  safe_not_equal: Ww,
  space: Kw,
  toggle_class: Qw,
  transition_in: Jw,
  transition_out: eF
} = window.__gradio__svelte__internal, {
  SvelteComponent: tF,
  attr: nF,
  children: iF,
  claim_element: aF,
  create_slot: rF,
  detach: lF,
  element: oF,
  get_all_dirty_from_scope: sF,
  get_slot_changes: uF,
  init: cF,
  insert_hydration: _F,
  null_to_empty: dF,
  safe_not_equal: pF,
  transition_in: hF,
  transition_out: fF,
  update_slot_base: mF
} = window.__gradio__svelte__internal, {
  SvelteComponent: gF,
  check_outros: bF,
  claim_component: vF,
  create_component: DF,
  destroy_component: yF,
  detach: $F,
  empty: wF,
  group_outros: FF,
  init: EF,
  insert_hydration: kF,
  mount_component: CF,
  noop: AF,
  safe_not_equal: SF,
  transition_in: TF,
  transition_out: xF
} = window.__gradio__svelte__internal, { createEventDispatcher: BF } = window.__gradio__svelte__internal;
function Ge(r) {
  let e = ["", "k", "M", "G", "T", "P", "E", "Z"], t = 0;
  for (; r > 1e3 && t < e.length - 1; )
    r /= 1e3, t++;
  let n = e[t];
  return (Number.isInteger(r) ? r : r.toFixed(1)) + n;
}
function vt() {
}
const Ii = typeof window < "u";
let Ln = Ii ? () => window.performance.now() : () => Date.now(), Ri = Ii ? (r) => requestAnimationFrame(r) : vt;
const je = /* @__PURE__ */ new Set();
function qi(r) {
  je.forEach((e) => {
    e.c(r) || (je.delete(e), e.f());
  }), je.size !== 0 && Ri(qi);
}
function yr(r) {
  let e;
  return je.size === 0 && Ri(qi), { promise: new Promise((t) => {
    je.add(e = { c: r, f: t });
  }), abort() {
    je.delete(e);
  } };
}
const He = [];
function $r(r, e = vt) {
  let t;
  const n = /* @__PURE__ */ new Set();
  function i(a) {
    if (s = a, ((o = r) != o ? s == s : o !== s || o && typeof o == "object" || typeof o == "function") && (r = a, t)) {
      const _ = !He.length;
      for (const c of n) c[1](), He.push(c, r);
      if (_) {
        for (let c = 0; c < He.length; c += 2) He[c][0](He[c + 1]);
        He.length = 0;
      }
    }
    var o, s;
  }
  function l(a) {
    i(a(r));
  }
  return { set: i, update: l, subscribe: function(a, o = vt) {
    const s = [a, o];
    return n.add(s), n.size === 1 && (t = e(i, l) || vt), a(r), () => {
      n.delete(s), n.size === 0 && t && (t(), t = null);
    };
  } };
}
function Nn(r) {
  return Object.prototype.toString.call(r) === "[object Date]";
}
function Vt(r, e, t, n) {
  if (typeof t == "number" || Nn(t)) {
    const i = n - t, l = (t - e) / (r.dt || 1 / 60), a = (l + (r.opts.stiffness * i - r.opts.damping * l) * r.inv_mass) * r.dt;
    return Math.abs(a) < r.opts.precision && Math.abs(i) < r.opts.precision ? n : (r.settled = !1, Nn(t) ? new Date(t.getTime() + a) : t + a);
  }
  if (Array.isArray(t)) return t.map((i, l) => Vt(r, e[l], t[l], n[l]));
  if (typeof t == "object") {
    const i = {};
    for (const l in t) i[l] = Vt(r, e[l], t[l], n[l]);
    return i;
  }
  throw new Error(`Cannot spring ${typeof t} values`);
}
function On(r, e = {}) {
  const t = $r(r), { stiffness: n = 0.15, damping: i = 0.8, precision: l = 0.01 } = e;
  let a, o, s, _ = r, c = r, p = 1, d = 0, m = !1;
  function g(b, F = {}) {
    c = b;
    const h = s = {};
    return r == null || F.hard || v.stiffness >= 1 && v.damping >= 1 ? (m = !0, a = Ln(), _ = b, t.set(r = c), Promise.resolve()) : (F.soft && (d = 1 / (60 * (F.soft === !0 ? 0.5 : +F.soft)), p = 0), o || (a = Ln(), m = !1, o = yr((u) => {
      if (m) return m = !1, o = null, !1;
      p = Math.min(p + d, 1);
      const f = { inv_mass: p, opts: v, settled: !0, dt: 60 * (u - a) / 1e3 }, D = Vt(f, _, r, c);
      return a = u, _ = r, t.set(r = D), f.settled && (o = null), !f.settled;
    })), new Promise((u) => {
      o.promise.then(() => {
        h === s && u();
      });
    }));
  }
  const v = { set: g, update: (b, F) => g(b(c, r), F), subscribe: t.subscribe, stiffness: n, damping: i, precision: l };
  return v;
}
const {
  SvelteComponent: wr,
  append_hydration: de,
  attr: x,
  children: ne,
  claim_element: Fr,
  claim_svg_element: pe,
  component_subscribe: zn,
  detach: K,
  element: Er,
  init: kr,
  insert_hydration: Cr,
  noop: Pn,
  safe_not_equal: Ar,
  set_style: mt,
  svg_element: he,
  toggle_class: Mn
} = window.__gradio__svelte__internal, { onMount: Sr } = window.__gradio__svelte__internal;
function Tr(r) {
  let e, t, n, i, l, a, o, s, _, c, p, d;
  return {
    c() {
      e = Er("div"), t = he("svg"), n = he("g"), i = he("path"), l = he("path"), a = he("path"), o = he("path"), s = he("g"), _ = he("path"), c = he("path"), p = he("path"), d = he("path"), this.h();
    },
    l(m) {
      e = Fr(m, "DIV", { class: !0 });
      var g = ne(e);
      t = pe(g, "svg", {
        viewBox: !0,
        fill: !0,
        xmlns: !0,
        class: !0
      });
      var v = ne(t);
      n = pe(v, "g", { style: !0 });
      var b = ne(n);
      i = pe(b, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ne(i).forEach(K), l = pe(b, "path", { d: !0, fill: !0, class: !0 }), ne(l).forEach(K), a = pe(b, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ne(a).forEach(K), o = pe(b, "path", { d: !0, fill: !0, class: !0 }), ne(o).forEach(K), b.forEach(K), s = pe(v, "g", { style: !0 });
      var F = ne(s);
      _ = pe(F, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ne(_).forEach(K), c = pe(F, "path", { d: !0, fill: !0, class: !0 }), ne(c).forEach(K), p = pe(F, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ne(p).forEach(K), d = pe(F, "path", { d: !0, fill: !0, class: !0 }), ne(d).forEach(K), F.forEach(K), v.forEach(K), g.forEach(K), this.h();
    },
    h() {
      x(i, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), x(i, "fill", "#FF7C00"), x(i, "fill-opacity", "0.4"), x(i, "class", "svelte-43sxxs"), x(l, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), x(l, "fill", "#FF7C00"), x(l, "class", "svelte-43sxxs"), x(a, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), x(a, "fill", "#FF7C00"), x(a, "fill-opacity", "0.4"), x(a, "class", "svelte-43sxxs"), x(o, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), x(o, "fill", "#FF7C00"), x(o, "class", "svelte-43sxxs"), mt(n, "transform", "translate(" + /*$top*/
      r[1][0] + "px, " + /*$top*/
      r[1][1] + "px)"), x(_, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), x(_, "fill", "#FF7C00"), x(_, "fill-opacity", "0.4"), x(_, "class", "svelte-43sxxs"), x(c, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), x(c, "fill", "#FF7C00"), x(c, "class", "svelte-43sxxs"), x(p, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), x(p, "fill", "#FF7C00"), x(p, "fill-opacity", "0.4"), x(p, "class", "svelte-43sxxs"), x(d, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), x(d, "fill", "#FF7C00"), x(d, "class", "svelte-43sxxs"), mt(s, "transform", "translate(" + /*$bottom*/
      r[2][0] + "px, " + /*$bottom*/
      r[2][1] + "px)"), x(t, "viewBox", "-1200 -1200 3000 3000"), x(t, "fill", "none"), x(t, "xmlns", "http://www.w3.org/2000/svg"), x(t, "class", "svelte-43sxxs"), x(e, "class", "svelte-43sxxs"), Mn(
        e,
        "margin",
        /*margin*/
        r[0]
      );
    },
    m(m, g) {
      Cr(m, e, g), de(e, t), de(t, n), de(n, i), de(n, l), de(n, a), de(n, o), de(t, s), de(s, _), de(s, c), de(s, p), de(s, d);
    },
    p(m, [g]) {
      g & /*$top*/
      2 && mt(n, "transform", "translate(" + /*$top*/
      m[1][0] + "px, " + /*$top*/
      m[1][1] + "px)"), g & /*$bottom*/
      4 && mt(s, "transform", "translate(" + /*$bottom*/
      m[2][0] + "px, " + /*$bottom*/
      m[2][1] + "px)"), g & /*margin*/
      1 && Mn(
        e,
        "margin",
        /*margin*/
        m[0]
      );
    },
    i: Pn,
    o: Pn,
    d(m) {
      m && K(e);
    }
  };
}
function xr(r, e, t) {
  let n, i;
  var l = this && this.__awaiter || function(m, g, v, b) {
    function F(h) {
      return h instanceof v ? h : new v(function(u) {
        u(h);
      });
    }
    return new (v || (v = Promise))(function(h, u) {
      function f($) {
        try {
          y(b.next($));
        } catch (S) {
          u(S);
        }
      }
      function D($) {
        try {
          y(b.throw($));
        } catch (S) {
          u(S);
        }
      }
      function y($) {
        $.done ? h($.value) : F($.value).then(f, D);
      }
      y((b = b.apply(m, g || [])).next());
    });
  };
  let { margin: a = !0 } = e;
  const o = On([0, 0]);
  zn(r, o, (m) => t(1, n = m));
  const s = On([0, 0]);
  zn(r, s, (m) => t(2, i = m));
  let _;
  function c() {
    return l(this, void 0, void 0, function* () {
      yield Promise.all([o.set([125, 140]), s.set([-125, -140])]), yield Promise.all([o.set([-125, 140]), s.set([125, -140])]), yield Promise.all([o.set([-125, 0]), s.set([125, -0])]), yield Promise.all([o.set([125, 0]), s.set([-125, 0])]);
    });
  }
  function p() {
    return l(this, void 0, void 0, function* () {
      yield c(), _ || p();
    });
  }
  function d() {
    return l(this, void 0, void 0, function* () {
      yield Promise.all([o.set([125, 0]), s.set([-125, 0])]), p();
    });
  }
  return Sr(() => (d(), () => _ = !0)), r.$$set = (m) => {
    "margin" in m && t(0, a = m.margin);
  }, [a, n, i, o, s];
}
class Br extends wr {
  constructor(e) {
    super(), kr(this, e, xr, Tr, Ar, { margin: 0 });
  }
}
const {
  SvelteComponent: Ir,
  append_hydration: ge,
  attr: ae,
  binding_callbacks: Un,
  check_outros: Et,
  children: re,
  claim_component: rn,
  claim_element: le,
  claim_space: V,
  claim_text: z,
  create_component: ln,
  create_slot: Li,
  destroy_component: on,
  destroy_each: Ni,
  detach: k,
  element: oe,
  empty: se,
  ensure_array_like: kt,
  get_all_dirty_from_scope: Oi,
  get_slot_changes: zi,
  group_outros: Ct,
  init: Rr,
  insert_hydration: A,
  mount_component: sn,
  noop: Yt,
  safe_not_equal: qr,
  set_data: ee,
  set_style: Be,
  space: Y,
  text: P,
  toggle_class: ie,
  transition_in: Z,
  transition_out: J,
  update_slot_base: Pi
} = window.__gradio__svelte__internal, { tick: Lr } = window.__gradio__svelte__internal, { onDestroy: Nr } = window.__gradio__svelte__internal, { createEventDispatcher: Or } = window.__gradio__svelte__internal, zr = (r) => ({}), Hn = (r) => ({}), Pr = (r) => ({}), Gn = (r) => ({});
function jn(r, e, t) {
  const n = r.slice();
  return n[43] = e[t], n[45] = t, n;
}
function Zn(r, e, t) {
  const n = r.slice();
  return n[43] = e[t], n;
}
function Vn(r) {
  let e, t, n, i, l, a;
  return l = new xi({
    props: {
      Icon: Bi,
      label: (
        /*i18n*/
        r[2]("common.clear")
      ),
      disabled: !1,
      size: "x-small",
      background: "var(--background-fill-primary)",
      color: "var(--error-background-text)",
      border: "var(--border-color-primary)"
    }
  }), l.$on(
    "click",
    /*click_handler*/
    r[33]
  ), {
    c() {
      e = oe("div"), t = P(
        /*validation_error*/
        r[1]
      ), n = Y(), i = oe("button"), ln(l.$$.fragment), this.h();
    },
    l(o) {
      e = le(o, "DIV", { class: !0 });
      var s = re(e);
      t = z(
        s,
        /*validation_error*/
        r[1]
      ), n = V(s), i = le(s, "BUTTON", {});
      var _ = re(i);
      rn(l.$$.fragment, _), _.forEach(k), s.forEach(k), this.h();
    },
    h() {
      ae(e, "class", "validation-error svelte-vusapu");
    },
    m(o, s) {
      A(o, e, s), ge(e, t), ge(e, n), ge(e, i), sn(l, i, null), a = !0;
    },
    p(o, s) {
      (!a || s[0] & /*validation_error*/
      2) && ee(
        t,
        /*validation_error*/
        o[1]
      );
      const _ = {};
      s[0] & /*i18n*/
      4 && (_.label = /*i18n*/
      o[2]("common.clear")), l.$set(_);
    },
    i(o) {
      a || (Z(l.$$.fragment, o), a = !0);
    },
    o(o) {
      J(l.$$.fragment, o), a = !1;
    },
    d(o) {
      o && k(e), on(l);
    }
  };
}
function Mr(r) {
  let e, t, n, i, l = (
    /*i18n*/
    r[2]("common.error") + ""
  ), a, o, s;
  t = new xi({
    props: {
      Icon: Bi,
      label: (
        /*i18n*/
        r[2]("common.clear")
      ),
      disabled: !1
    }
  }), t.$on(
    "click",
    /*click_handler_1*/
    r[35]
  );
  const _ = (
    /*#slots*/
    r[32].error
  ), c = Li(
    _,
    r,
    /*$$scope*/
    r[31],
    Hn
  );
  return {
    c() {
      e = oe("div"), ln(t.$$.fragment), n = Y(), i = oe("span"), a = P(l), o = Y(), c && c.c(), this.h();
    },
    l(p) {
      e = le(p, "DIV", { class: !0 });
      var d = re(e);
      rn(t.$$.fragment, d), d.forEach(k), n = V(p), i = le(p, "SPAN", { class: !0 });
      var m = re(i);
      a = z(m, l), m.forEach(k), o = V(p), c && c.l(p), this.h();
    },
    h() {
      ae(e, "class", "clear-status svelte-vusapu"), ae(i, "class", "error svelte-vusapu");
    },
    m(p, d) {
      A(p, e, d), sn(t, e, null), A(p, n, d), A(p, i, d), ge(i, a), A(p, o, d), c && c.m(p, d), s = !0;
    },
    p(p, d) {
      const m = {};
      d[0] & /*i18n*/
      4 && (m.label = /*i18n*/
      p[2]("common.clear")), t.$set(m), (!s || d[0] & /*i18n*/
      4) && l !== (l = /*i18n*/
      p[2]("common.error") + "") && ee(a, l), c && c.p && (!s || d[1] & /*$$scope*/
      1) && Pi(
        c,
        _,
        p,
        /*$$scope*/
        p[31],
        s ? zi(
          _,
          /*$$scope*/
          p[31],
          d,
          zr
        ) : Oi(
          /*$$scope*/
          p[31]
        ),
        Hn
      );
    },
    i(p) {
      s || (Z(t.$$.fragment, p), Z(c, p), s = !0);
    },
    o(p) {
      J(t.$$.fragment, p), J(c, p), s = !1;
    },
    d(p) {
      p && (k(e), k(n), k(i), k(o)), on(t), c && c.d(p);
    }
  };
}
function Ur(r) {
  let e, t, n, i, l, a, o, s, _, c = (
    /*variant*/
    r[9] === "default" && /*show_eta_bar*/
    r[20] && /*show_progress*/
    r[7] === "full" && Yn(r)
  );
  function p(u, f) {
    if (
      /*progress*/
      u[8]
    ) return jr;
    if (
      /*queue_position*/
      u[3] !== null && /*queue_size*/
      u[4] !== void 0 && /*queue_position*/
      u[3] >= 0
    ) return Gr;
    if (
      /*queue_position*/
      u[3] === 0
    ) return Hr;
  }
  let d = p(r), m = d && d(r), g = (
    /*timer*/
    r[6] && Kn(r)
  );
  const v = [Xr, Yr], b = [];
  function F(u, f) {
    return (
      /*last_progress_level*/
      u[17] != null ? 0 : (
        /*show_progress*/
        u[7] === "full" ? 1 : -1
      )
    );
  }
  ~(l = F(r)) && (a = b[l] = v[l](r));
  let h = !/*timer*/
  r[6] && ai(r);
  return {
    c() {
      c && c.c(), e = Y(), t = oe("div"), m && m.c(), n = Y(), g && g.c(), i = Y(), a && a.c(), o = Y(), h && h.c(), s = se(), this.h();
    },
    l(u) {
      c && c.l(u), e = V(u), t = le(u, "DIV", { class: !0 });
      var f = re(t);
      m && m.l(f), n = V(f), g && g.l(f), f.forEach(k), i = V(u), a && a.l(u), o = V(u), h && h.l(u), s = se(), this.h();
    },
    h() {
      ae(t, "class", "progress-text svelte-vusapu"), ie(
        t,
        "meta-text-center",
        /*variant*/
        r[9] === "center"
      ), ie(
        t,
        "meta-text",
        /*variant*/
        r[9] === "default"
      );
    },
    m(u, f) {
      c && c.m(u, f), A(u, e, f), A(u, t, f), m && m.m(t, null), ge(t, n), g && g.m(t, null), A(u, i, f), ~l && b[l].m(u, f), A(u, o, f), h && h.m(u, f), A(u, s, f), _ = !0;
    },
    p(u, f) {
      /*variant*/
      u[9] === "default" && /*show_eta_bar*/
      u[20] && /*show_progress*/
      u[7] === "full" ? c ? c.p(u, f) : (c = Yn(u), c.c(), c.m(e.parentNode, e)) : c && (c.d(1), c = null), d === (d = p(u)) && m ? m.p(u, f) : (m && m.d(1), m = d && d(u), m && (m.c(), m.m(t, n))), /*timer*/
      u[6] ? g ? g.p(u, f) : (g = Kn(u), g.c(), g.m(t, null)) : g && (g.d(1), g = null), (!_ || f[0] & /*variant*/
      512) && ie(
        t,
        "meta-text-center",
        /*variant*/
        u[9] === "center"
      ), (!_ || f[0] & /*variant*/
      512) && ie(
        t,
        "meta-text",
        /*variant*/
        u[9] === "default"
      );
      let D = l;
      l = F(u), l === D ? ~l && b[l].p(u, f) : (a && (Ct(), J(b[D], 1, 1, () => {
        b[D] = null;
      }), Et()), ~l ? (a = b[l], a ? a.p(u, f) : (a = b[l] = v[l](u), a.c()), Z(a, 1), a.m(o.parentNode, o)) : a = null), /*timer*/
      u[6] ? h && (Ct(), J(h, 1, 1, () => {
        h = null;
      }), Et()) : h ? (h.p(u, f), f[0] & /*timer*/
      64 && Z(h, 1)) : (h = ai(u), h.c(), Z(h, 1), h.m(s.parentNode, s));
    },
    i(u) {
      _ || (Z(a), Z(h), _ = !0);
    },
    o(u) {
      J(a), J(h), _ = !1;
    },
    d(u) {
      u && (k(e), k(t), k(i), k(o), k(s)), c && c.d(u), m && m.d(), g && g.d(), ~l && b[l].d(u), h && h.d(u);
    }
  };
}
function Yn(r) {
  let e, t = `translateX(${/*eta_level*/
  (r[19] || 0) * 100 - 100}%)`;
  return {
    c() {
      e = oe("div"), this.h();
    },
    l(n) {
      e = le(n, "DIV", { class: !0 }), re(e).forEach(k), this.h();
    },
    h() {
      ae(e, "class", "eta-bar svelte-vusapu"), Be(e, "transform", t);
    },
    m(n, i) {
      A(n, e, i);
    },
    p(n, i) {
      i[0] & /*eta_level*/
      524288 && t !== (t = `translateX(${/*eta_level*/
      (n[19] || 0) * 100 - 100}%)`) && Be(e, "transform", t);
    },
    d(n) {
      n && k(e);
    }
  };
}
function Hr(r) {
  let e;
  return {
    c() {
      e = P("processing |");
    },
    l(t) {
      e = z(t, "processing |");
    },
    m(t, n) {
      A(t, e, n);
    },
    p: Yt,
    d(t) {
      t && k(e);
    }
  };
}
function Gr(r) {
  let e, t = (
    /*queue_position*/
    r[3] + 1 + ""
  ), n, i, l, a;
  return {
    c() {
      e = P("queue: "), n = P(t), i = P("/"), l = P(
        /*queue_size*/
        r[4]
      ), a = P(" |");
    },
    l(o) {
      e = z(o, "queue: "), n = z(o, t), i = z(o, "/"), l = z(
        o,
        /*queue_size*/
        r[4]
      ), a = z(o, " |");
    },
    m(o, s) {
      A(o, e, s), A(o, n, s), A(o, i, s), A(o, l, s), A(o, a, s);
    },
    p(o, s) {
      s[0] & /*queue_position*/
      8 && t !== (t = /*queue_position*/
      o[3] + 1 + "") && ee(n, t), s[0] & /*queue_size*/
      16 && ee(
        l,
        /*queue_size*/
        o[4]
      );
    },
    d(o) {
      o && (k(e), k(n), k(i), k(l), k(a));
    }
  };
}
function jr(r) {
  let e, t = kt(
    /*progress*/
    r[8]
  ), n = [];
  for (let i = 0; i < t.length; i += 1)
    n[i] = Wn(Zn(r, t, i));
  return {
    c() {
      for (let i = 0; i < n.length; i += 1)
        n[i].c();
      e = se();
    },
    l(i) {
      for (let l = 0; l < n.length; l += 1)
        n[l].l(i);
      e = se();
    },
    m(i, l) {
      for (let a = 0; a < n.length; a += 1)
        n[a] && n[a].m(i, l);
      A(i, e, l);
    },
    p(i, l) {
      if (l[0] & /*progress*/
      256) {
        t = kt(
          /*progress*/
          i[8]
        );
        let a;
        for (a = 0; a < t.length; a += 1) {
          const o = Zn(i, t, a);
          n[a] ? n[a].p(o, l) : (n[a] = Wn(o), n[a].c(), n[a].m(e.parentNode, e));
        }
        for (; a < n.length; a += 1)
          n[a].d(1);
        n.length = t.length;
      }
    },
    d(i) {
      i && k(e), Ni(n, i);
    }
  };
}
function Xn(r) {
  let e, t = (
    /*p*/
    r[43].unit + ""
  ), n, i, l = " ", a;
  function o(c, p) {
    return (
      /*p*/
      c[43].length != null ? Vr : Zr
    );
  }
  let s = o(r), _ = s(r);
  return {
    c() {
      _.c(), e = Y(), n = P(t), i = P(" | "), a = P(l);
    },
    l(c) {
      _.l(c), e = V(c), n = z(c, t), i = z(c, " | "), a = z(c, l);
    },
    m(c, p) {
      _.m(c, p), A(c, e, p), A(c, n, p), A(c, i, p), A(c, a, p);
    },
    p(c, p) {
      s === (s = o(c)) && _ ? _.p(c, p) : (_.d(1), _ = s(c), _ && (_.c(), _.m(e.parentNode, e))), p[0] & /*progress*/
      256 && t !== (t = /*p*/
      c[43].unit + "") && ee(n, t);
    },
    d(c) {
      c && (k(e), k(n), k(i), k(a)), _.d(c);
    }
  };
}
function Zr(r) {
  let e = Ge(
    /*p*/
    r[43].index || 0
  ) + "", t;
  return {
    c() {
      t = P(e);
    },
    l(n) {
      t = z(n, e);
    },
    m(n, i) {
      A(n, t, i);
    },
    p(n, i) {
      i[0] & /*progress*/
      256 && e !== (e = Ge(
        /*p*/
        n[43].index || 0
      ) + "") && ee(t, e);
    },
    d(n) {
      n && k(t);
    }
  };
}
function Vr(r) {
  let e = Ge(
    /*p*/
    r[43].index || 0
  ) + "", t, n, i = Ge(
    /*p*/
    r[43].length
  ) + "", l;
  return {
    c() {
      t = P(e), n = P("/"), l = P(i);
    },
    l(a) {
      t = z(a, e), n = z(a, "/"), l = z(a, i);
    },
    m(a, o) {
      A(a, t, o), A(a, n, o), A(a, l, o);
    },
    p(a, o) {
      o[0] & /*progress*/
      256 && e !== (e = Ge(
        /*p*/
        a[43].index || 0
      ) + "") && ee(t, e), o[0] & /*progress*/
      256 && i !== (i = Ge(
        /*p*/
        a[43].length
      ) + "") && ee(l, i);
    },
    d(a) {
      a && (k(t), k(n), k(l));
    }
  };
}
function Wn(r) {
  let e, t = (
    /*p*/
    r[43].index != null && Xn(r)
  );
  return {
    c() {
      t && t.c(), e = se();
    },
    l(n) {
      t && t.l(n), e = se();
    },
    m(n, i) {
      t && t.m(n, i), A(n, e, i);
    },
    p(n, i) {
      /*p*/
      n[43].index != null ? t ? t.p(n, i) : (t = Xn(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && k(e), t && t.d(n);
    }
  };
}
function Kn(r) {
  let e, t = (
    /*eta*/
    r[0] ? `/${/*formatted_eta*/
    r[21]}` : ""
  ), n, i;
  return {
    c() {
      e = P(
        /*formatted_timer*/
        r[22]
      ), n = P(t), i = P("s");
    },
    l(l) {
      e = z(
        l,
        /*formatted_timer*/
        r[22]
      ), n = z(l, t), i = z(l, "s");
    },
    m(l, a) {
      A(l, e, a), A(l, n, a), A(l, i, a);
    },
    p(l, a) {
      a[0] & /*formatted_timer*/
      4194304 && ee(
        e,
        /*formatted_timer*/
        l[22]
      ), a[0] & /*eta, formatted_eta*/
      2097153 && t !== (t = /*eta*/
      l[0] ? `/${/*formatted_eta*/
      l[21]}` : "") && ee(n, t);
    },
    d(l) {
      l && (k(e), k(n), k(i));
    }
  };
}
function Yr(r) {
  let e, t;
  return e = new Br({
    props: { margin: (
      /*variant*/
      r[9] === "default"
    ) }
  }), {
    c() {
      ln(e.$$.fragment);
    },
    l(n) {
      rn(e.$$.fragment, n);
    },
    m(n, i) {
      sn(e, n, i), t = !0;
    },
    p(n, i) {
      const l = {};
      i[0] & /*variant*/
      512 && (l.margin = /*variant*/
      n[9] === "default"), e.$set(l);
    },
    i(n) {
      t || (Z(e.$$.fragment, n), t = !0);
    },
    o(n) {
      J(e.$$.fragment, n), t = !1;
    },
    d(n) {
      on(e, n);
    }
  };
}
function Xr(r) {
  let e, t, n, i, l, a = `${/*last_progress_level*/
  r[17] * 100}%`, o = (
    /*progress*/
    r[8] != null && Qn(r)
  );
  return {
    c() {
      e = oe("div"), t = oe("div"), o && o.c(), n = Y(), i = oe("div"), l = oe("div"), this.h();
    },
    l(s) {
      e = le(s, "DIV", { class: !0 });
      var _ = re(e);
      t = le(_, "DIV", { class: !0 });
      var c = re(t);
      o && o.l(c), c.forEach(k), n = V(_), i = le(_, "DIV", { class: !0 });
      var p = re(i);
      l = le(p, "DIV", { class: !0 }), re(l).forEach(k), p.forEach(k), _.forEach(k), this.h();
    },
    h() {
      ae(t, "class", "progress-level-inner svelte-vusapu"), ae(l, "class", "progress-bar svelte-vusapu"), Be(l, "width", a), ae(i, "class", "progress-bar-wrap svelte-vusapu"), ae(e, "class", "progress-level svelte-vusapu");
    },
    m(s, _) {
      A(s, e, _), ge(e, t), o && o.m(t, null), ge(e, n), ge(e, i), ge(i, l), r[34](l);
    },
    p(s, _) {
      /*progress*/
      s[8] != null ? o ? o.p(s, _) : (o = Qn(s), o.c(), o.m(t, null)) : o && (o.d(1), o = null), _[0] & /*last_progress_level*/
      131072 && a !== (a = `${/*last_progress_level*/
      s[17] * 100}%`) && Be(l, "width", a);
    },
    i: Yt,
    o: Yt,
    d(s) {
      s && k(e), o && o.d(), r[34](null);
    }
  };
}
function Qn(r) {
  let e, t = kt(
    /*progress*/
    r[8]
  ), n = [];
  for (let i = 0; i < t.length; i += 1)
    n[i] = ii(jn(r, t, i));
  return {
    c() {
      for (let i = 0; i < n.length; i += 1)
        n[i].c();
      e = se();
    },
    l(i) {
      for (let l = 0; l < n.length; l += 1)
        n[l].l(i);
      e = se();
    },
    m(i, l) {
      for (let a = 0; a < n.length; a += 1)
        n[a] && n[a].m(i, l);
      A(i, e, l);
    },
    p(i, l) {
      if (l[0] & /*progress_level, progress*/
      65792) {
        t = kt(
          /*progress*/
          i[8]
        );
        let a;
        for (a = 0; a < t.length; a += 1) {
          const o = jn(i, t, a);
          n[a] ? n[a].p(o, l) : (n[a] = ii(o), n[a].c(), n[a].m(e.parentNode, e));
        }
        for (; a < n.length; a += 1)
          n[a].d(1);
        n.length = t.length;
      }
    },
    d(i) {
      i && k(e), Ni(n, i);
    }
  };
}
function Jn(r) {
  let e, t, n, i, l = (
    /*i*/
    r[45] !== 0 && Wr()
  ), a = (
    /*p*/
    r[43].desc != null && ei(r)
  ), o = (
    /*p*/
    r[43].desc != null && /*progress_level*/
    r[16] && /*progress_level*/
    r[16][
      /*i*/
      r[45]
    ] != null && ti()
  ), s = (
    /*progress_level*/
    r[16] != null && ni(r)
  );
  return {
    c() {
      l && l.c(), e = Y(), a && a.c(), t = Y(), o && o.c(), n = Y(), s && s.c(), i = se();
    },
    l(_) {
      l && l.l(_), e = V(_), a && a.l(_), t = V(_), o && o.l(_), n = V(_), s && s.l(_), i = se();
    },
    m(_, c) {
      l && l.m(_, c), A(_, e, c), a && a.m(_, c), A(_, t, c), o && o.m(_, c), A(_, n, c), s && s.m(_, c), A(_, i, c);
    },
    p(_, c) {
      /*p*/
      _[43].desc != null ? a ? a.p(_, c) : (a = ei(_), a.c(), a.m(t.parentNode, t)) : a && (a.d(1), a = null), /*p*/
      _[43].desc != null && /*progress_level*/
      _[16] && /*progress_level*/
      _[16][
        /*i*/
        _[45]
      ] != null ? o || (o = ti(), o.c(), o.m(n.parentNode, n)) : o && (o.d(1), o = null), /*progress_level*/
      _[16] != null ? s ? s.p(_, c) : (s = ni(_), s.c(), s.m(i.parentNode, i)) : s && (s.d(1), s = null);
    },
    d(_) {
      _ && (k(e), k(t), k(n), k(i)), l && l.d(_), a && a.d(_), o && o.d(_), s && s.d(_);
    }
  };
}
function Wr(r) {
  let e;
  return {
    c() {
      e = P(" /");
    },
    l(t) {
      e = z(t, " /");
    },
    m(t, n) {
      A(t, e, n);
    },
    d(t) {
      t && k(e);
    }
  };
}
function ei(r) {
  let e = (
    /*p*/
    r[43].desc + ""
  ), t;
  return {
    c() {
      t = P(e);
    },
    l(n) {
      t = z(n, e);
    },
    m(n, i) {
      A(n, t, i);
    },
    p(n, i) {
      i[0] & /*progress*/
      256 && e !== (e = /*p*/
      n[43].desc + "") && ee(t, e);
    },
    d(n) {
      n && k(t);
    }
  };
}
function ti(r) {
  let e;
  return {
    c() {
      e = P("-");
    },
    l(t) {
      e = z(t, "-");
    },
    m(t, n) {
      A(t, e, n);
    },
    d(t) {
      t && k(e);
    }
  };
}
function ni(r) {
  let e = (100 * /*progress_level*/
  (r[16][
    /*i*/
    r[45]
  ] || 0)).toFixed(1) + "", t, n;
  return {
    c() {
      t = P(e), n = P("%");
    },
    l(i) {
      t = z(i, e), n = z(i, "%");
    },
    m(i, l) {
      A(i, t, l), A(i, n, l);
    },
    p(i, l) {
      l[0] & /*progress_level*/
      65536 && e !== (e = (100 * /*progress_level*/
      (i[16][
        /*i*/
        i[45]
      ] || 0)).toFixed(1) + "") && ee(t, e);
    },
    d(i) {
      i && (k(t), k(n));
    }
  };
}
function ii(r) {
  let e, t = (
    /*p*/
    (r[43].desc != null || /*progress_level*/
    r[16] && /*progress_level*/
    r[16][
      /*i*/
      r[45]
    ] != null) && Jn(r)
  );
  return {
    c() {
      t && t.c(), e = se();
    },
    l(n) {
      t && t.l(n), e = se();
    },
    m(n, i) {
      t && t.m(n, i), A(n, e, i);
    },
    p(n, i) {
      /*p*/
      n[43].desc != null || /*progress_level*/
      n[16] && /*progress_level*/
      n[16][
        /*i*/
        n[45]
      ] != null ? t ? t.p(n, i) : (t = Jn(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && k(e), t && t.d(n);
    }
  };
}
function ai(r) {
  let e, t, n, i;
  const l = (
    /*#slots*/
    r[32]["additional-loading-text"]
  ), a = Li(
    l,
    r,
    /*$$scope*/
    r[31],
    Gn
  );
  return {
    c() {
      e = oe("p"), t = P(
        /*loading_text*/
        r[10]
      ), n = Y(), a && a.c(), this.h();
    },
    l(o) {
      e = le(o, "P", { class: !0 });
      var s = re(e);
      t = z(
        s,
        /*loading_text*/
        r[10]
      ), s.forEach(k), n = V(o), a && a.l(o), this.h();
    },
    h() {
      ae(e, "class", "loading svelte-vusapu");
    },
    m(o, s) {
      A(o, e, s), ge(e, t), A(o, n, s), a && a.m(o, s), i = !0;
    },
    p(o, s) {
      (!i || s[0] & /*loading_text*/
      1024) && ee(
        t,
        /*loading_text*/
        o[10]
      ), a && a.p && (!i || s[1] & /*$$scope*/
      1) && Pi(
        a,
        l,
        o,
        /*$$scope*/
        o[31],
        i ? zi(
          l,
          /*$$scope*/
          o[31],
          s,
          Pr
        ) : Oi(
          /*$$scope*/
          o[31]
        ),
        Gn
      );
    },
    i(o) {
      i || (Z(a, o), i = !0);
    },
    o(o) {
      J(a, o), i = !1;
    },
    d(o) {
      o && (k(e), k(n)), a && a.d(o);
    }
  };
}
function Kr(r) {
  let e, t, n, i, l, a, o = (
    /*validation_error*/
    r[1] && /*show_validation_error*/
    r[14] && Vn(r)
  );
  const s = [Ur, Mr], _ = [];
  function c(p, d) {
    return (
      /*status*/
      p[5] === "pending" ? 0 : (
        /*status*/
        p[5] === "error" ? 1 : -1
      )
    );
  }
  return ~(n = c(r)) && (i = _[n] = s[n](r)), {
    c() {
      e = oe("div"), o && o.c(), t = Y(), i && i.c(), this.h();
    },
    l(p) {
      e = le(p, "DIV", { class: !0 });
      var d = re(e);
      o && o.l(d), t = V(d), i && i.l(d), d.forEach(k), this.h();
    },
    h() {
      ae(e, "class", l = "wrap " + /*variant*/
      r[9] + " " + /*show_progress*/
      r[7] + " svelte-vusapu"), ie(e, "hide", (!/*status*/
      r[5] || /*status*/
      r[5] === "complete" || /*show_progress*/
      r[7] === "hidden" || /*status*/
      r[5] == "streaming") && !/*validation_error*/
      r[1]), ie(
        e,
        "translucent",
        /*variant*/
        r[9] === "center" && /*status*/
        (r[5] === "pending" || /*status*/
        r[5] === "error") || /*translucent*/
        r[12] || /*show_progress*/
        r[7] === "minimal" || /*validation_error*/
        r[1]
      ), ie(
        e,
        "generating",
        /*status*/
        r[5] === "generating" && /*show_progress*/
        r[7] === "full"
      ), ie(
        e,
        "border",
        /*border*/
        r[13]
      ), Be(
        e,
        "position",
        /*absolute*/
        r[11] ? "absolute" : "static"
      ), Be(
        e,
        "padding",
        /*absolute*/
        r[11] ? "0" : "var(--size-8) 0"
      );
    },
    m(p, d) {
      A(p, e, d), o && o.m(e, null), ge(e, t), ~n && _[n].m(e, null), r[36](e), a = !0;
    },
    p(p, d) {
      /*validation_error*/
      p[1] && /*show_validation_error*/
      p[14] ? o ? (o.p(p, d), d[0] & /*validation_error, show_validation_error*/
      16386 && Z(o, 1)) : (o = Vn(p), o.c(), Z(o, 1), o.m(e, t)) : o && (Ct(), J(o, 1, 1, () => {
        o = null;
      }), Et());
      let m = n;
      n = c(p), n === m ? ~n && _[n].p(p, d) : (i && (Ct(), J(_[m], 1, 1, () => {
        _[m] = null;
      }), Et()), ~n ? (i = _[n], i ? i.p(p, d) : (i = _[n] = s[n](p), i.c()), Z(i, 1), i.m(e, null)) : i = null), (!a || d[0] & /*variant, show_progress*/
      640 && l !== (l = "wrap " + /*variant*/
      p[9] + " " + /*show_progress*/
      p[7] + " svelte-vusapu")) && ae(e, "class", l), (!a || d[0] & /*variant, show_progress, status, show_progress, validation_error*/
      674) && ie(e, "hide", (!/*status*/
      p[5] || /*status*/
      p[5] === "complete" || /*show_progress*/
      p[7] === "hidden" || /*status*/
      p[5] == "streaming") && !/*validation_error*/
      p[1]), (!a || d[0] & /*variant, show_progress, variant, status, translucent, show_progress, validation_error*/
      4770) && ie(
        e,
        "translucent",
        /*variant*/
        p[9] === "center" && /*status*/
        (p[5] === "pending" || /*status*/
        p[5] === "error") || /*translucent*/
        p[12] || /*show_progress*/
        p[7] === "minimal" || /*validation_error*/
        p[1]
      ), (!a || d[0] & /*variant, show_progress, status, show_progress*/
      672) && ie(
        e,
        "generating",
        /*status*/
        p[5] === "generating" && /*show_progress*/
        p[7] === "full"
      ), (!a || d[0] & /*variant, show_progress, border*/
      8832) && ie(
        e,
        "border",
        /*border*/
        p[13]
      ), d[0] & /*absolute*/
      2048 && Be(
        e,
        "position",
        /*absolute*/
        p[11] ? "absolute" : "static"
      ), d[0] & /*absolute*/
      2048 && Be(
        e,
        "padding",
        /*absolute*/
        p[11] ? "0" : "var(--size-8) 0"
      );
    },
    i(p) {
      a || (Z(o), Z(i), a = !0);
    },
    o(p) {
      J(o), J(i), a = !1;
    },
    d(p) {
      p && k(e), o && o.d(), ~n && _[n].d(), r[36](null);
    }
  };
}
var Qr = function(r, e, t, n) {
  function i(l) {
    return l instanceof t ? l : new t(function(a) {
      a(l);
    });
  }
  return new (t || (t = Promise))(function(l, a) {
    function o(c) {
      try {
        _(n.next(c));
      } catch (p) {
        a(p);
      }
    }
    function s(c) {
      try {
        _(n.throw(c));
      } catch (p) {
        a(p);
      }
    }
    function _(c) {
      c.done ? l(c.value) : i(c.value).then(o, s);
    }
    _((n = n.apply(r, e || [])).next());
  });
};
let gt = [], Nt = !1;
const Jr = typeof window < "u", Mi = Jr ? window.requestAnimationFrame : (r) => {
};
function el(r) {
  return Qr(this, arguments, void 0, function* (e, t = !0) {
    if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && t !== !0)) {
      if (gt.push(e), !Nt) Nt = !0;
      else return;
      yield Lr(), Mi(() => {
        let n = [0, 0];
        for (let i = 0; i < gt.length; i++) {
          const a = gt[i].getBoundingClientRect();
          (i === 0 || a.top + window.scrollY <= n[0]) && (n[0] = a.top + window.scrollY, n[1] = i);
        }
        window.scrollTo({ top: n[0] - 20, behavior: "smooth" }), Nt = !1, gt = [];
      });
    }
  });
}
function tl(r, e, t) {
  let n, { $$slots: i = {}, $$scope: l } = e;
  const a = Or();
  let { i18n: o } = e, { eta: s = null } = e, { queue_position: _ } = e, { queue_size: c } = e, { status: p } = e, { scroll_to_output: d = !1 } = e, { timer: m = !0 } = e, { show_progress: g = "full" } = e, { message: v = null } = e, { progress: b = null } = e, { variant: F = "default" } = e, { loading_text: h = "Loading..." } = e, { absolute: u = !0 } = e, { translucent: f = !1 } = e, { border: D = !1 } = e, { autoscroll: y } = e, { validation_error: $ = null } = e, { show_validation_error: S = !0 } = e, E, T = !1, N = 0, L = 0, ue = null, te = null, Re = 0, X = null, ce, q = null, j = !0;
  const be = () => {
    t(0, s = t(29, ue = t(21, Ee = null))), t(27, N = performance.now()), t(28, L = 0), T = !0, w();
  };
  function w() {
    Mi(() => {
      t(28, L = (performance.now() - N) / 1e3), T && w();
    });
  }
  function U() {
    t(28, L = 0), t(0, s = t(29, ue = t(21, Ee = null))), T && (T = !1);
  }
  Nr(() => {
    T && U();
  });
  let Ee = null;
  const W = () => t(1, $ = null);
  function ve(C) {
    Un[C ? "unshift" : "push"](() => {
      q = C, t(18, q), t(8, b), t(16, X), t(17, ce);
    });
  }
  const Ae = () => {
    a("clear_status");
  };
  function Me(C) {
    Un[C ? "unshift" : "push"](() => {
      E = C, t(15, E);
    });
  }
  return r.$$set = (C) => {
    "i18n" in C && t(2, o = C.i18n), "eta" in C && t(0, s = C.eta), "queue_position" in C && t(3, _ = C.queue_position), "queue_size" in C && t(4, c = C.queue_size), "status" in C && t(5, p = C.status), "scroll_to_output" in C && t(24, d = C.scroll_to_output), "timer" in C && t(6, m = C.timer), "show_progress" in C && t(7, g = C.show_progress), "message" in C && t(25, v = C.message), "progress" in C && t(8, b = C.progress), "variant" in C && t(9, F = C.variant), "loading_text" in C && t(10, h = C.loading_text), "absolute" in C && t(11, u = C.absolute), "translucent" in C && t(12, f = C.translucent), "border" in C && t(13, D = C.border), "autoscroll" in C && t(26, y = C.autoscroll), "validation_error" in C && t(1, $ = C.validation_error), "show_validation_error" in C && t(14, S = C.show_validation_error), "$$scope" in C && t(31, l = C.$$scope);
  }, r.$$.update = () => {
    r.$$.dirty[0] & /*eta, old_eta, timer_start, eta_from_start*/
    1744830465 && (s === null && t(0, s = ue), s != null && ue !== s && (t(30, te = (performance.now() - N) / 1e3 + s), t(21, Ee = te.toFixed(1)), t(29, ue = s))), r.$$.dirty[0] & /*eta_from_start, timer_diff*/
    1342177280 && t(19, Re = te === null || te <= 0 || !L ? null : Math.min(L / te, 1)), r.$$.dirty[0] & /*progress*/
    256 && b != null && t(20, j = !1), r.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    459008 && (b != null ? t(16, X = b.map((C) => {
      if (C.index != null && C.length != null)
        return C.index / C.length;
      if (C.progress != null)
        return C.progress;
    })) : t(16, X = null), X ? (t(17, ce = X[X.length - 1]), q && (ce === 0 ? t(18, q.style.transition = "0", q) : t(18, q.style.transition = "150ms", q))) : t(17, ce = void 0)), r.$$.dirty[0] & /*status*/
    32 && (p === "pending" ? be() : U()), r.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    83918880 && E && d && (p === "pending" || p === "complete") && el(E, y), r.$$.dirty[0] & /*status, message*/
    33554464, r.$$.dirty[0] & /*timer_diff*/
    268435456 && t(22, n = L.toFixed(1));
  }, [
    s,
    $,
    o,
    _,
    c,
    p,
    m,
    g,
    b,
    F,
    h,
    u,
    f,
    D,
    S,
    E,
    X,
    ce,
    q,
    Re,
    j,
    Ee,
    n,
    a,
    d,
    v,
    y,
    N,
    L,
    ue,
    te,
    l,
    i,
    W,
    ve,
    Ae,
    Me
  ];
}
class nl extends Ir {
  constructor(e) {
    super(), Rr(
      this,
      e,
      tl,
      Kr,
      qr,
      {
        i18n: 2,
        eta: 0,
        queue_position: 3,
        queue_size: 4,
        status: 5,
        scroll_to_output: 24,
        timer: 6,
        show_progress: 7,
        message: 25,
        progress: 8,
        variant: 9,
        loading_text: 10,
        absolute: 11,
        translucent: 12,
        border: 13,
        autoscroll: 26,
        validation_error: 1,
        show_validation_error: 14
      },
      null,
      [-1, -1]
    );
  }
}
const {
  HtmlTagHydration: IF,
  SvelteComponent: RF,
  add_render_callback: qF,
  append_hydration: LF,
  attr: NF,
  bubble: OF,
  check_outros: zF,
  children: PF,
  claim_component: MF,
  claim_element: UF,
  claim_html_tag: HF,
  claim_space: GF,
  claim_text: jF,
  create_component: ZF,
  create_in_transition: VF,
  create_out_transition: YF,
  destroy_component: XF,
  detach: WF,
  element: KF,
  get_svelte_dataset: QF,
  group_outros: JF,
  init: eE,
  insert_hydration: tE,
  listen: nE,
  mount_component: iE,
  run_all: aE,
  safe_not_equal: rE,
  set_data: lE,
  space: oE,
  stop_propagation: sE,
  text: uE,
  toggle_class: cE,
  transition_in: _E,
  transition_out: dE
} = window.__gradio__svelte__internal, { createEventDispatcher: pE, onMount: hE } = window.__gradio__svelte__internal, {
  SvelteComponent: fE,
  append_hydration: mE,
  attr: gE,
  bubble: bE,
  check_outros: vE,
  children: DE,
  claim_component: yE,
  claim_element: $E,
  claim_space: wE,
  component_subscribe: FE,
  create_animation: EE,
  create_component: kE,
  destroy_component: CE,
  detach: AE,
  element: SE,
  ensure_array_like: TE,
  fix_and_outro_and_destroy_block: xE,
  fix_position: BE,
  group_outros: IE,
  init: RE,
  insert_hydration: qE,
  mount_component: LE,
  noop: NE,
  safe_not_equal: OE,
  set_style: zE,
  space: PE,
  transition_in: ME,
  transition_out: UE,
  update_keyed_each: HE
} = window.__gradio__svelte__internal, {
  SvelteComponent: GE,
  attr: jE,
  children: ZE,
  claim_element: VE,
  detach: YE,
  element: XE,
  empty: WE,
  init: KE,
  insert_hydration: QE,
  noop: JE,
  safe_not_equal: ek,
  set_style: tk
} = window.__gradio__svelte__internal, {
  SvelteComponent: il,
  append_hydration: xe,
  attr: et,
  children: tt,
  claim_element: nt,
  claim_space: al,
  claim_text: it,
  detach: Ie,
  element: at,
  init: rl,
  insert_hydration: un,
  listen: ri,
  noop: li,
  run_all: ll,
  safe_not_equal: ol,
  set_data: cn,
  set_style: Se,
  space: sl,
  text: rt
} = window.__gradio__svelte__internal;
function ul(r) {
  let e, t;
  return {
    c() {
      e = at("div"), t = rt(
        /*displayType*/
        r[4]
      ), this.h();
    },
    l(n) {
      e = nt(n, "DIV", { class: !0 });
      var i = tt(e);
      t = it(
        i,
        /*displayType*/
        r[4]
      ), i.forEach(Ie), this.h();
    },
    h() {
      et(e, "class", "type svelte-1f4spu");
    },
    m(n, i) {
      un(n, e, i), xe(e, t);
    },
    p(n, i) {
      i & /*displayType*/
      16 && cn(
        t,
        /*displayType*/
        n[4]
      );
    },
    d(n) {
      n && Ie(e);
    }
  };
}
function cl(r) {
  let e, t;
  return {
    c() {
      e = at("pre"), t = rt(
        /*displayType*/
        r[4]
      ), this.h();
    },
    l(n) {
      e = nt(n, "PRE", { class: !0 });
      var i = tt(e);
      t = it(
        i,
        /*displayType*/
        r[4]
      ), i.forEach(Ie), this.h();
    },
    h() {
      et(e, "class", "func-name svelte-1f4spu");
    },
    m(n, i) {
      un(n, e, i), xe(e, t);
    },
    p(n, i) {
      i & /*displayType*/
      16 && cn(
        t,
        /*displayType*/
        n[4]
      );
    },
    d(n) {
      n && Ie(e);
    }
  };
}
function _l(r) {
  let e, t, n, i, l, a, o, s = `${/*height*/
  r[2]}px`, _ = `1px solid ${/*color*/
  r[5]}44`, c, p;
  function d(v, b) {
    return (
      /*type*/
      v[0] === "function_call" ? cl : ul
    );
  }
  let m = d(r), g = m(r);
  return {
    c() {
      e = at("div"), t = at("div"), g.c(), n = sl(), i = at("div"), l = rt("/ "), a = rt(
        /*tokens*/
        r[1]
      ), o = rt(" tokens"), this.h();
    },
    l(v) {
      e = nt(v, "DIV", { class: !0 });
      var b = tt(e);
      t = nt(b, "DIV", { class: !0 });
      var F = tt(t);
      g.l(F), n = al(F), i = nt(F, "DIV", { class: !0 });
      var h = tt(i);
      l = it(h, "/ "), a = it(
        h,
        /*tokens*/
        r[1]
      ), o = it(h, " tokens"), h.forEach(Ie), F.forEach(Ie), b.forEach(Ie), this.h();
    },
    h() {
      et(i, "class", "tokens svelte-1f4spu"), et(t, "class", "content svelte-1f4spu"), et(e, "class", "bar svelte-1f4spu"), Se(
        e,
        "background",
        /*color*/
        r[5]
      ), Se(e, "height", s), Se(e, "border", _), Se(
        e,
        "transform",
        /*hovered*/
        r[3] ? "scale(1.02)" : "scale(1)"
      );
    },
    m(v, b) {
      un(v, e, b), xe(e, t), g.m(t, null), xe(t, n), xe(t, i), xe(i, l), xe(i, a), xe(i, o), c || (p = [
        ri(
          e,
          "mouseenter",
          /*mouseenter_handler*/
          r[8]
        ),
        ri(
          e,
          "mouseleave",
          /*mouseleave_handler*/
          r[9]
        )
      ], c = !0);
    },
    p(v, [b]) {
      m === (m = d(v)) && g ? g.p(v, b) : (g.d(1), g = m(v), g && (g.c(), g.m(t, n))), b & /*tokens*/
      2 && cn(
        a,
        /*tokens*/
        v[1]
      ), b & /*color*/
      32 && Se(
        e,
        "background",
        /*color*/
        v[5]
      ), b & /*height*/
      4 && s !== (s = `${/*height*/
      v[2]}px`) && Se(e, "height", s), b & /*color*/
      32 && _ !== (_ = `1px solid ${/*color*/
      v[5]}44`) && Se(e, "border", _), b & /*hovered*/
      8 && Se(
        e,
        "transform",
        /*hovered*/
        v[3] ? "scale(1.02)" : "scale(1)"
      );
    },
    i: li,
    o: li,
    d(v) {
      v && Ie(e), g.d(), c = !1, ll(p);
    }
  };
}
function dl(r, e, t) {
  let n, i, { role: l } = e, { type: a = "" } = e, { name: o = "" } = e, { tokens: s } = e, { height: _ } = e;
  const c = {
    system: "#BEF1FE",
    user: "#CFFFD9",
    assistant: "#FEFEB1",
    function_call: "#E9D8FF",
    function_result: "#E9D8FF"
  };
  let p = !1;
  const d = () => t(3, p = !0), m = () => t(3, p = !1);
  return r.$$set = (g) => {
    "role" in g && t(6, l = g.role), "type" in g && t(0, a = g.type), "name" in g && t(7, o = g.name), "tokens" in g && t(1, s = g.tokens), "height" in g && t(2, _ = g.height);
  }, r.$$.update = () => {
    r.$$.dirty & /*type, role*/
    65 && t(5, n = a === "function_call" ? c.function_call : a === "function_call_output" ? c.function_result : l === "system" ? c.system : l === "user" ? c.user : c.assistant), r.$$.dirty & /*type, name, role*/
    193 && t(4, i = a === "function_call" ? o || "unknown" : a === "function_call_output" ? "result" : l);
  }, [
    a,
    s,
    _,
    p,
    i,
    n,
    l,
    o,
    d,
    m
  ];
}
class pl extends il {
  constructor(e) {
    super(), rl(this, e, dl, _l, ol, {
      role: 6,
      type: 0,
      name: 7,
      tokens: 1,
      height: 2
    });
  }
}
const {
  SvelteComponent: hl,
  append_hydration: Te,
  assign: fl,
  attr: qe,
  check_outros: Xt,
  children: Xe,
  claim_component: _n,
  claim_element: Le,
  claim_space: Dt,
  claim_text: Ot,
  create_component: dn,
  destroy_component: pn,
  destroy_each: ml,
  detach: fe,
  element: Ne,
  ensure_array_like: oi,
  flush: ye,
  get_spread_object: gl,
  get_spread_update: bl,
  get_svelte_dataset: Ui,
  group_outros: Wt,
  init: vl,
  insert_hydration: Ze,
  mount_component: hn,
  noop: zt,
  safe_not_equal: Dl,
  set_data: si,
  space: yt,
  text: Pt,
  transition_in: me,
  transition_out: Ce
} = window.__gradio__svelte__internal;
function ui(r, e, t) {
  const n = r.slice();
  return n[16] = e[t], n[18] = t, n;
}
function ci(r) {
  let e, t;
  const n = [
    { autoscroll: (
      /*gradio*/
      r[0].autoscroll
    ) },
    { i18n: (
      /*gradio*/
      r[0].i18n
    ) },
    /*loading_status*/
    r[6]
  ];
  let i = {};
  for (let l = 0; l < n.length; l += 1)
    i = fl(i, n[l]);
  return e = new nl({ props: i }), e.$on(
    "clear_status",
    /*clear_status_handler*/
    r[14]
  ), {
    c() {
      dn(e.$$.fragment);
    },
    l(l) {
      _n(e.$$.fragment, l);
    },
    m(l, a) {
      hn(e, l, a), t = !0;
    },
    p(l, a) {
      const o = a & /*gradio, loading_status*/
      65 ? bl(n, [
        a & /*gradio*/
        1 && { autoscroll: (
          /*gradio*/
          l[0].autoscroll
        ) },
        a & /*gradio*/
        1 && { i18n: (
          /*gradio*/
          l[0].i18n
        ) },
        a & /*loading_status*/
        64 && gl(
          /*loading_status*/
          l[6]
        )
      ]) : {};
      e.$set(o);
    },
    i(l) {
      t || (me(e.$$.fragment, l), t = !0);
    },
    o(l) {
      Ce(e.$$.fragment, l), t = !1;
    },
    d(l) {
      pn(e, l);
    }
  };
}
function yl(r) {
  let e, t, n = "📚 Context Stack", i, l, a = (
    /*messages*/
    r[10].length + ""
  ), o, s, _, c, p, d, m, g, v = oi(
    /*messages*/
    r[10]
  ), b = [];
  for (let h = 0; h < v.length; h += 1)
    b[h] = _i(ui(r, v, h));
  const F = (h) => Ce(b[h], 1, 1, () => {
    b[h] = null;
  });
  return {
    c() {
      e = Ne("div"), t = Ne("h4"), t.textContent = n, i = yt(), l = Ne("span"), o = Pt(a), s = yt(), _ = Ne("span"), c = Pt(
        /*totalTokens*/
        r[9]
      ), p = Pt(" tokens"), d = yt(), m = Ne("div");
      for (let h = 0; h < b.length; h += 1)
        b[h].c();
      this.h();
    },
    l(h) {
      e = Le(h, "DIV", { class: !0 });
      var u = Xe(e);
      t = Le(u, "H4", { class: !0, "data-svelte-h": !0 }), Ui(t) !== "svelte-5vcfer" && (t.textContent = n), i = Dt(u), l = Le(u, "SPAN", { class: !0 });
      var f = Xe(l);
      o = Ot(f, a), f.forEach(fe), s = Dt(u), _ = Le(u, "SPAN", { class: !0 });
      var D = Xe(_);
      c = Ot(
        D,
        /*totalTokens*/
        r[9]
      ), p = Ot(D, " tokens"), D.forEach(fe), u.forEach(fe), d = Dt(h), m = Le(h, "DIV", { class: !0 });
      var y = Xe(m);
      for (let $ = 0; $ < b.length; $ += 1)
        b[$].l(y);
      y.forEach(fe), this.h();
    },
    h() {
      qe(t, "class", "title svelte-1r25mux"), qe(l, "class", "count-badge svelte-1r25mux"), qe(_, "class", "token-count svelte-1r25mux"), qe(e, "class", "header svelte-1r25mux"), qe(m, "class", "bars-container svelte-1r25mux");
    },
    m(h, u) {
      Ze(h, e, u), Te(e, t), Te(e, i), Te(e, l), Te(l, o), Te(e, s), Te(e, _), Te(_, c), Te(_, p), Ze(h, d, u), Ze(h, m, u);
      for (let f = 0; f < b.length; f += 1)
        b[f] && b[f].m(m, null);
      g = !0;
    },
    p(h, u) {
      if ((!g || u & /*messages*/
      1024) && a !== (a = /*messages*/
      h[10].length + "") && si(o, a), (!g || u & /*totalTokens*/
      512) && si(
        c,
        /*totalTokens*/
        h[9]
      ), u & /*messages, tokens, heights*/
      1408) {
        v = oi(
          /*messages*/
          h[10]
        );
        let f;
        for (f = 0; f < v.length; f += 1) {
          const D = ui(h, v, f);
          b[f] ? (b[f].p(D, u), me(b[f], 1)) : (b[f] = _i(D), b[f].c(), me(b[f], 1), b[f].m(m, null));
        }
        for (Wt(), f = v.length; f < b.length; f += 1)
          F(f);
        Xt();
      }
    },
    i(h) {
      if (!g) {
        for (let u = 0; u < v.length; u += 1)
          me(b[u]);
        g = !0;
      }
    },
    o(h) {
      b = b.filter(Boolean);
      for (let u = 0; u < b.length; u += 1)
        Ce(b[u]);
      g = !1;
    },
    d(h) {
      h && (fe(e), fe(d), fe(m)), ml(b, h);
    }
  };
}
function $l(r) {
  let e, t = "No messages yet, start chatting!";
  return {
    c() {
      e = Ne("div"), e.textContent = t, this.h();
    },
    l(n) {
      e = Le(n, "DIV", { class: !0, "data-svelte-h": !0 }), Ui(e) !== "svelte-1blzg72" && (e.textContent = t), this.h();
    },
    h() {
      qe(e, "class", "empty-state svelte-1r25mux");
    },
    m(n, i) {
      Ze(n, e, i);
    },
    p: zt,
    i: zt,
    o: zt,
    d(n) {
      n && fe(e);
    }
  };
}
function _i(r) {
  let e, t;
  return e = new pl({
    props: {
      role: (
        /*message*/
        r[16].role || "unknown"
      ),
      type: (
        /*message*/
        r[16].type || ""
      ),
      name: (
        /*message*/
        r[16].name || ""
      ),
      tokens: (
        /*tokens*/
        r[7][
          /*i*/
          r[18]
        ]
      ),
      height: (
        /*heights*/
        r[8][
          /*i*/
          r[18]
        ]
      )
    }
  }), {
    c() {
      dn(e.$$.fragment);
    },
    l(n) {
      _n(e.$$.fragment, n);
    },
    m(n, i) {
      hn(e, n, i), t = !0;
    },
    p(n, i) {
      const l = {};
      i & /*messages*/
      1024 && (l.role = /*message*/
      n[16].role || "unknown"), i & /*messages*/
      1024 && (l.type = /*message*/
      n[16].type || ""), i & /*messages*/
      1024 && (l.name = /*message*/
      n[16].name || ""), i & /*tokens*/
      128 && (l.tokens = /*tokens*/
      n[7][
        /*i*/
        n[18]
      ]), i & /*heights*/
      256 && (l.height = /*heights*/
      n[8][
        /*i*/
        n[18]
      ]), e.$set(l);
    },
    i(n) {
      t || (me(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Ce(e.$$.fragment, n), t = !1;
    },
    d(n) {
      pn(e, n);
    }
  };
}
function wl(r) {
  let e, t, n, i, l, a = (
    /*loading_status*/
    r[6] && ci(r)
  );
  const o = [$l, yl], s = [];
  function _(c, p) {
    return (
      /*messages*/
      c[10].length === 0 ? 0 : 1
    );
  }
  return n = _(r), i = s[n] = o[n](r), {
    c() {
      a && a.c(), e = yt(), t = Ne("div"), i.c(), this.h();
    },
    l(c) {
      a && a.l(c), e = Dt(c), t = Le(c, "DIV", { class: !0 });
      var p = Xe(t);
      i.l(p), p.forEach(fe), this.h();
    },
    h() {
      qe(t, "class", "context-container svelte-1r25mux");
    },
    m(c, p) {
      a && a.m(c, p), Ze(c, e, p), Ze(c, t, p), s[n].m(t, null), l = !0;
    },
    p(c, p) {
      /*loading_status*/
      c[6] ? a ? (a.p(c, p), p & /*loading_status*/
      64 && me(a, 1)) : (a = ci(c), a.c(), me(a, 1), a.m(e.parentNode, e)) : a && (Wt(), Ce(a, 1, 1, () => {
        a = null;
      }), Xt());
      let d = n;
      n = _(c), n === d ? s[n].p(c, p) : (Wt(), Ce(s[d], 1, 1, () => {
        s[d] = null;
      }), Xt(), i = s[n], i ? i.p(c, p) : (i = s[n] = o[n](c), i.c()), me(i, 1), i.m(t, null));
    },
    i(c) {
      l || (me(a), me(i), l = !0);
    },
    o(c) {
      Ce(a), Ce(i), l = !1;
    },
    d(c) {
      c && (fe(e), fe(t)), a && a.d(c), s[n].d();
    }
  };
}
function Fl(r) {
  let e, t;
  return e = new sa({
    props: {
      visible: (
        /*visible*/
        r[3]
      ),
      elem_id: (
        /*elem_id*/
        r[1]
      ),
      elem_classes: (
        /*elem_classes*/
        r[2]
      ),
      scale: (
        /*scale*/
        r[4]
      ),
      min_width: (
        /*min_width*/
        r[5]
      ),
      allow_overflow: !1,
      padding: !1,
      $$slots: { default: [wl] },
      $$scope: { ctx: r }
    }
  }), {
    c() {
      dn(e.$$.fragment);
    },
    l(n) {
      _n(e.$$.fragment, n);
    },
    m(n, i) {
      hn(e, n, i), t = !0;
    },
    p(n, [i]) {
      const l = {};
      i & /*visible*/
      8 && (l.visible = /*visible*/
      n[3]), i & /*elem_id*/
      2 && (l.elem_id = /*elem_id*/
      n[1]), i & /*elem_classes*/
      4 && (l.elem_classes = /*elem_classes*/
      n[2]), i & /*scale*/
      16 && (l.scale = /*scale*/
      n[4]), i & /*min_width*/
      32 && (l.min_width = /*min_width*/
      n[5]), i & /*$$scope, messages, tokens, heights, totalTokens, gradio, loading_status*/
      526273 && (l.$$scope = { dirty: i, ctx: n }), e.$set(l);
    },
    i(n) {
      t || (me(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Ce(e.$$.fragment, n), t = !1;
    },
    d(n) {
      pn(e, n);
    }
  };
}
function El(r, e, t) {
  let n, i, l, a, { gradio: o } = e, { elem_id: s = "" } = e, { elem_classes: _ = [] } = e, { visible: c = !0 } = e, { value: p = null } = e, { scale: d = null } = e, { min_width: m = void 0 } = e, { loading_status: g = void 0 } = e, { interactive: v = !1 } = e, { min_height: b = "500px" } = e;
  function F() {
    o.dispatch("change");
  }
  const h = () => o.dispatch("clear_status", g);
  return r.$$set = (u) => {
    "gradio" in u && t(0, o = u.gradio), "elem_id" in u && t(1, s = u.elem_id), "elem_classes" in u && t(2, _ = u.elem_classes), "visible" in u && t(3, c = u.visible), "value" in u && t(11, p = u.value), "scale" in u && t(4, d = u.scale), "min_width" in u && t(5, m = u.min_width), "loading_status" in u && t(6, g = u.loading_status), "interactive" in u && t(12, v = u.interactive), "min_height" in u && t(13, b = u.min_height);
  }, r.$$.update = () => {
    r.$$.dirty & /*value*/
    2048 && t(10, n = (p == null ? void 0 : p.messages) || []), r.$$.dirty & /*value*/
    2048 && t(7, i = (p == null ? void 0 : p.tokens_count) || []), r.$$.dirty & /*tokens*/
    128 && t(9, l = i.reduce((u, f) => u + f, 0)), r.$$.dirty & /*tokens*/
    128 && t(8, a = i.map((u) => Math.min(Math.max(20, u * 0.2), 400))), r.$$.dirty & /*value*/
    2048 && F();
  }, [
    o,
    s,
    _,
    c,
    d,
    m,
    g,
    i,
    a,
    l,
    n,
    p,
    v,
    b,
    h
  ];
}
class nk extends hl {
  constructor(e) {
    super(), vl(this, e, El, Fl, Dl, {
      gradio: 0,
      elem_id: 1,
      elem_classes: 2,
      visible: 3,
      value: 11,
      scale: 4,
      min_width: 5,
      loading_status: 6,
      interactive: 12,
      min_height: 13
    });
  }
  get gradio() {
    return this.$$.ctx[0];
  }
  set gradio(e) {
    this.$$set({ gradio: e }), ye();
  }
  get elem_id() {
    return this.$$.ctx[1];
  }
  set elem_id(e) {
    this.$$set({ elem_id: e }), ye();
  }
  get elem_classes() {
    return this.$$.ctx[2];
  }
  set elem_classes(e) {
    this.$$set({ elem_classes: e }), ye();
  }
  get visible() {
    return this.$$.ctx[3];
  }
  set visible(e) {
    this.$$set({ visible: e }), ye();
  }
  get value() {
    return this.$$.ctx[11];
  }
  set value(e) {
    this.$$set({ value: e }), ye();
  }
  get scale() {
    return this.$$.ctx[4];
  }
  set scale(e) {
    this.$$set({ scale: e }), ye();
  }
  get min_width() {
    return this.$$.ctx[5];
  }
  set min_width(e) {
    this.$$set({ min_width: e }), ye();
  }
  get loading_status() {
    return this.$$.ctx[6];
  }
  set loading_status(e) {
    this.$$set({ loading_status: e }), ye();
  }
  get interactive() {
    return this.$$.ctx[12];
  }
  set interactive(e) {
    this.$$set({ interactive: e }), ye();
  }
  get min_height() {
    return this.$$.ctx[13];
  }
  set min_height(e) {
    this.$$set({ min_height: e }), ye();
  }
}
export {
  nk as default
};
