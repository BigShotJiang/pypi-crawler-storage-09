var Gl = Object.defineProperty;
var Oi = (i) => {
  throw TypeError(i);
};
var jl = (i, e, t) => e in i ? Gl(i, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : i[e] = t;
var _e = (i, e, t) => jl(i, typeof e != "symbol" ? e + "" : e, t), Vl = (i, e, t) => e.has(i) || Oi("Cannot " + t);
var Bi = (i, e, t) => e.has(i) ? Oi("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(i) : e.set(i, t);
var hn = (i, e, t) => (Vl(i, e, "access private method"), t);
const {
  SvelteComponent: Yl,
  append_hydration: ni,
  assign: Wl,
  attr: Ie,
  binding_callbacks: Zl,
  children: nn,
  claim_element: Za,
  claim_space: Xa,
  claim_svg_element: Un,
  create_slot: Xl,
  detach: ut,
  element: Ka,
  empty: Mi,
  get_all_dirty_from_scope: Kl,
  get_slot_changes: Ql,
  get_spread_update: Jl,
  init: eo,
  insert_hydration: sn,
  listen: to,
  noop: no,
  safe_not_equal: io,
  set_dynamic_element_data: Pi,
  set_style: oe,
  space: Qa,
  svg_element: Hn,
  toggle_class: $e,
  transition_in: Ja,
  transition_out: el,
  update_slot_base: ao
} = window.__gradio__svelte__internal;
function qi(i) {
  let e, t, n, a, o;
  return {
    c() {
      e = Hn("svg"), t = Hn("line"), n = Hn("line"), this.h();
    },
    l(l) {
      e = Un(l, "svg", { class: !0, xmlns: !0, viewBox: !0 });
      var r = nn(e);
      t = Un(r, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), nn(t).forEach(ut), n = Un(r, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), nn(n).forEach(ut), r.forEach(ut), this.h();
    },
    h() {
      Ie(t, "x1", "1"), Ie(t, "y1", "9"), Ie(t, "x2", "9"), Ie(t, "y2", "1"), Ie(t, "stroke", "gray"), Ie(t, "stroke-width", "0.5"), Ie(n, "x1", "5"), Ie(n, "y1", "9"), Ie(n, "x2", "9"), Ie(n, "y2", "5"), Ie(n, "stroke", "gray"), Ie(n, "stroke-width", "0.5"), Ie(e, "class", "resize-handle svelte-239wnu"), Ie(e, "xmlns", "http://www.w3.org/2000/svg"), Ie(e, "viewBox", "0 0 10 10");
    },
    m(l, r) {
      sn(l, e, r), ni(e, t), ni(e, n), a || (o = to(
        e,
        "mousedown",
        /*resize*/
        i[27]
      ), a = !0);
    },
    p: no,
    d(l) {
      l && ut(e), a = !1, o();
    }
  };
}
function lo(i) {
  var g;
  let e, t, n, a, o;
  const l = (
    /*#slots*/
    i[31].default
  ), r = Xl(
    l,
    i,
    /*$$scope*/
    i[30],
    null
  );
  let s = (
    /*resizable*/
    i[19] && qi(i)
  ), u = [
    { "data-testid": (
      /*test_id*/
      i[11]
    ) },
    { id: (
      /*elem_id*/
      i[6]
    ) },
    {
      class: n = "block " + /*elem_classes*/
      (((g = i[7]) == null ? void 0 : g.join(" ")) || "") + " svelte-239wnu"
    },
    {
      dir: a = /*rtl*/
      i[20] ? "rtl" : "ltr"
    }
  ], c = {};
  for (let _ = 0; _ < u.length; _ += 1)
    c = Wl(c, u[_]);
  return {
    c() {
      e = Ka(
        /*tag*/
        i[25]
      ), r && r.c(), t = Qa(), s && s.c(), this.h();
    },
    l(_) {
      e = Za(
        _,
        /*tag*/
        (i[25] || "null").toUpperCase(),
        {
          "data-testid": !0,
          id: !0,
          class: !0,
          dir: !0
        }
      );
      var m = nn(e);
      r && r.l(m), t = Xa(m), s && s.l(m), m.forEach(ut), this.h();
    },
    h() {
      Pi(
        /*tag*/
        i[25]
      )(e, c), $e(
        e,
        "hidden",
        /*visible*/
        i[14] === !1
      ), $e(
        e,
        "padded",
        /*padding*/
        i[10]
      ), $e(
        e,
        "flex",
        /*flex*/
        i[1]
      ), $e(
        e,
        "border_focus",
        /*border_mode*/
        i[9] === "focus"
      ), $e(
        e,
        "border_contrast",
        /*border_mode*/
        i[9] === "contrast"
      ), $e(e, "hide-container", !/*explicit_call*/
      i[12] && !/*container*/
      i[13]), $e(
        e,
        "fullscreen",
        /*fullscreen*/
        i[0]
      ), $e(
        e,
        "animating",
        /*fullscreen*/
        i[0] && /*preexpansionBoundingRect*/
        i[24] !== null
      ), $e(
        e,
        "auto-margin",
        /*scale*/
        i[17] === null
      ), oe(
        e,
        "height",
        /*fullscreen*/
        i[0] ? void 0 : (
          /*get_dimension*/
          i[26](
            /*height*/
            i[2]
          )
        )
      ), oe(
        e,
        "min-height",
        /*fullscreen*/
        i[0] ? void 0 : (
          /*get_dimension*/
          i[26](
            /*min_height*/
            i[3]
          )
        )
      ), oe(
        e,
        "max-height",
        /*fullscreen*/
        i[0] ? void 0 : (
          /*get_dimension*/
          i[26](
            /*max_height*/
            i[4]
          )
        )
      ), oe(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        i[24] ? `${/*preexpansionBoundingRect*/
        i[24].top}px` : "0px"
      ), oe(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        i[24] ? `${/*preexpansionBoundingRect*/
        i[24].left}px` : "0px"
      ), oe(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        i[24] ? `${/*preexpansionBoundingRect*/
        i[24].width}px` : "0px"
      ), oe(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        i[24] ? `${/*preexpansionBoundingRect*/
        i[24].height}px` : "0px"
      ), oe(
        e,
        "width",
        /*fullscreen*/
        i[0] ? void 0 : typeof /*width*/
        i[5] == "number" ? `calc(min(${/*width*/
        i[5]}px, 100%))` : (
          /*get_dimension*/
          i[26](
            /*width*/
            i[5]
          )
        )
      ), oe(
        e,
        "border-style",
        /*variant*/
        i[8]
      ), oe(
        e,
        "overflow",
        /*allow_overflow*/
        i[15] ? (
          /*overflow_behavior*/
          i[16]
        ) : "hidden"
      ), oe(
        e,
        "flex-grow",
        /*scale*/
        i[17]
      ), oe(e, "min-width", `calc(min(${/*min_width*/
      i[18]}px, 100%))`), oe(e, "border-width", "var(--block-border-width)");
    },
    m(_, m) {
      sn(_, e, m), r && r.m(e, null), ni(e, t), s && s.m(e, null), i[32](e), o = !0;
    },
    p(_, m) {
      var b;
      r && r.p && (!o || m[0] & /*$$scope*/
      1073741824) && ao(
        r,
        l,
        _,
        /*$$scope*/
        _[30],
        o ? Ql(
          l,
          /*$$scope*/
          _[30],
          m,
          null
        ) : Kl(
          /*$$scope*/
          _[30]
        ),
        null
      ), /*resizable*/
      _[19] ? s ? s.p(_, m) : (s = qi(_), s.c(), s.m(e, null)) : s && (s.d(1), s = null), Pi(
        /*tag*/
        _[25]
      )(e, c = Jl(u, [
        (!o || m[0] & /*test_id*/
        2048) && { "data-testid": (
          /*test_id*/
          _[11]
        ) },
        (!o || m[0] & /*elem_id*/
        64) && { id: (
          /*elem_id*/
          _[6]
        ) },
        (!o || m[0] & /*elem_classes*/
        128 && n !== (n = "block " + /*elem_classes*/
        (((b = _[7]) == null ? void 0 : b.join(" ")) || "") + " svelte-239wnu")) && { class: n },
        (!o || m[0] & /*rtl*/
        1048576 && a !== (a = /*rtl*/
        _[20] ? "rtl" : "ltr")) && { dir: a }
      ])), $e(
        e,
        "hidden",
        /*visible*/
        _[14] === !1
      ), $e(
        e,
        "padded",
        /*padding*/
        _[10]
      ), $e(
        e,
        "flex",
        /*flex*/
        _[1]
      ), $e(
        e,
        "border_focus",
        /*border_mode*/
        _[9] === "focus"
      ), $e(
        e,
        "border_contrast",
        /*border_mode*/
        _[9] === "contrast"
      ), $e(e, "hide-container", !/*explicit_call*/
      _[12] && !/*container*/
      _[13]), $e(
        e,
        "fullscreen",
        /*fullscreen*/
        _[0]
      ), $e(
        e,
        "animating",
        /*fullscreen*/
        _[0] && /*preexpansionBoundingRect*/
        _[24] !== null
      ), $e(
        e,
        "auto-margin",
        /*scale*/
        _[17] === null
      ), m[0] & /*fullscreen, height*/
      5 && oe(
        e,
        "height",
        /*fullscreen*/
        _[0] ? void 0 : (
          /*get_dimension*/
          _[26](
            /*height*/
            _[2]
          )
        )
      ), m[0] & /*fullscreen, min_height*/
      9 && oe(
        e,
        "min-height",
        /*fullscreen*/
        _[0] ? void 0 : (
          /*get_dimension*/
          _[26](
            /*min_height*/
            _[3]
          )
        )
      ), m[0] & /*fullscreen, max_height*/
      17 && oe(
        e,
        "max-height",
        /*fullscreen*/
        _[0] ? void 0 : (
          /*get_dimension*/
          _[26](
            /*max_height*/
            _[4]
          )
        )
      ), m[0] & /*preexpansionBoundingRect*/
      16777216 && oe(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        _[24] ? `${/*preexpansionBoundingRect*/
        _[24].top}px` : "0px"
      ), m[0] & /*preexpansionBoundingRect*/
      16777216 && oe(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        _[24] ? `${/*preexpansionBoundingRect*/
        _[24].left}px` : "0px"
      ), m[0] & /*preexpansionBoundingRect*/
      16777216 && oe(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        _[24] ? `${/*preexpansionBoundingRect*/
        _[24].width}px` : "0px"
      ), m[0] & /*preexpansionBoundingRect*/
      16777216 && oe(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        _[24] ? `${/*preexpansionBoundingRect*/
        _[24].height}px` : "0px"
      ), m[0] & /*fullscreen, width*/
      33 && oe(
        e,
        "width",
        /*fullscreen*/
        _[0] ? void 0 : typeof /*width*/
        _[5] == "number" ? `calc(min(${/*width*/
        _[5]}px, 100%))` : (
          /*get_dimension*/
          _[26](
            /*width*/
            _[5]
          )
        )
      ), m[0] & /*variant*/
      256 && oe(
        e,
        "border-style",
        /*variant*/
        _[8]
      ), m[0] & /*allow_overflow, overflow_behavior*/
      98304 && oe(
        e,
        "overflow",
        /*allow_overflow*/
        _[15] ? (
          /*overflow_behavior*/
          _[16]
        ) : "hidden"
      ), m[0] & /*scale*/
      131072 && oe(
        e,
        "flex-grow",
        /*scale*/
        _[17]
      ), m[0] & /*min_width*/
      262144 && oe(e, "min-width", `calc(min(${/*min_width*/
      _[18]}px, 100%))`);
    },
    i(_) {
      o || (Ja(r, _), o = !0);
    },
    o(_) {
      el(r, _), o = !1;
    },
    d(_) {
      _ && ut(e), r && r.d(_), s && s.d(), i[32](null);
    }
  };
}
function zi(i) {
  let e;
  return {
    c() {
      e = Ka("div"), this.h();
    },
    l(t) {
      e = Za(t, "DIV", { class: !0 }), nn(e).forEach(ut), this.h();
    },
    h() {
      Ie(e, "class", "placeholder svelte-239wnu"), oe(
        e,
        "height",
        /*placeholder_height*/
        i[22] + "px"
      ), oe(
        e,
        "width",
        /*placeholder_width*/
        i[23] + "px"
      );
    },
    m(t, n) {
      sn(t, e, n);
    },
    p(t, n) {
      n[0] & /*placeholder_height*/
      4194304 && oe(
        e,
        "height",
        /*placeholder_height*/
        t[22] + "px"
      ), n[0] & /*placeholder_width*/
      8388608 && oe(
        e,
        "width",
        /*placeholder_width*/
        t[23] + "px"
      );
    },
    d(t) {
      t && ut(e);
    }
  };
}
function oo(i) {
  let e, t, n, a = (
    /*tag*/
    i[25] && lo(i)
  ), o = (
    /*fullscreen*/
    i[0] && zi(i)
  );
  return {
    c() {
      a && a.c(), e = Qa(), o && o.c(), t = Mi();
    },
    l(l) {
      a && a.l(l), e = Xa(l), o && o.l(l), t = Mi();
    },
    m(l, r) {
      a && a.m(l, r), sn(l, e, r), o && o.m(l, r), sn(l, t, r), n = !0;
    },
    p(l, r) {
      /*tag*/
      l[25] && a.p(l, r), /*fullscreen*/
      l[0] ? o ? o.p(l, r) : (o = zi(l), o.c(), o.m(t.parentNode, t)) : o && (o.d(1), o = null);
    },
    i(l) {
      n || (Ja(a, l), n = !0);
    },
    o(l) {
      el(a, l), n = !1;
    },
    d(l) {
      l && (ut(e), ut(t)), a && a.d(l), o && o.d(l);
    }
  };
}
function ro(i, e, t) {
  let { $$slots: n = {}, $$scope: a } = e, { height: o = void 0 } = e, { min_height: l = void 0 } = e, { max_height: r = void 0 } = e, { width: s = void 0 } = e, { elem_id: u = "" } = e, { elem_classes: c = [] } = e, { variant: g = "solid" } = e, { border_mode: _ = "base" } = e, { padding: m = !0 } = e, { type: b = "normal" } = e, { test_id: w = void 0 } = e, { explicit_call: y = !1 } = e, { container: x = !0 } = e, { visible: p = !0 } = e, { allow_overflow: d = !0 } = e, { overflow_behavior: h = "auto" } = e, { scale: D = null } = e, { min_width: F = 0 } = e, { flex: S = !1 } = e, { resizable: O = !1 } = e, { rtl: k = !1 } = e, { fullscreen: A = !1 } = e, $ = A, L, ce = b === "fieldset" ? "fieldset" : "div", Q = 0, ne = 0, me = null;
  function Ae(I) {
    A && I.key === "Escape" && t(0, A = !1);
  }
  const ie = (I) => {
    if (I !== void 0) {
      if (typeof I == "number")
        return I + "px";
      if (typeof I == "string")
        return I;
    }
  }, W = (I) => {
    let H = I.clientY;
    const J = (C) => {
      const ye = C.clientY - H;
      H = C.clientY, t(21, L.style.height = `${L.offsetHeight + ye}px`, L);
    }, j = () => {
      window.removeEventListener("mousemove", J), window.removeEventListener("mouseup", j);
    };
    window.addEventListener("mousemove", J), window.addEventListener("mouseup", j);
  };
  function De(I) {
    Zl[I ? "unshift" : "push"](() => {
      L = I, t(21, L);
    });
  }
  return i.$$set = (I) => {
    "height" in I && t(2, o = I.height), "min_height" in I && t(3, l = I.min_height), "max_height" in I && t(4, r = I.max_height), "width" in I && t(5, s = I.width), "elem_id" in I && t(6, u = I.elem_id), "elem_classes" in I && t(7, c = I.elem_classes), "variant" in I && t(8, g = I.variant), "border_mode" in I && t(9, _ = I.border_mode), "padding" in I && t(10, m = I.padding), "type" in I && t(28, b = I.type), "test_id" in I && t(11, w = I.test_id), "explicit_call" in I && t(12, y = I.explicit_call), "container" in I && t(13, x = I.container), "visible" in I && t(14, p = I.visible), "allow_overflow" in I && t(15, d = I.allow_overflow), "overflow_behavior" in I && t(16, h = I.overflow_behavior), "scale" in I && t(17, D = I.scale), "min_width" in I && t(18, F = I.min_width), "flex" in I && t(1, S = I.flex), "resizable" in I && t(19, O = I.resizable), "rtl" in I && t(20, k = I.rtl), "fullscreen" in I && t(0, A = I.fullscreen), "$$scope" in I && t(30, a = I.$$scope);
  }, i.$$.update = () => {
    i.$$.dirty[0] & /*fullscreen, old_fullscreen, element*/
    538968065 && A !== $ && (t(29, $ = A), A ? (t(24, me = L.getBoundingClientRect()), t(22, Q = L.offsetHeight), t(23, ne = L.offsetWidth), window.addEventListener("keydown", Ae)) : (t(24, me = null), window.removeEventListener("keydown", Ae))), i.$$.dirty[0] & /*visible*/
    16384 && (p || t(1, S = !1));
  }, [
    A,
    S,
    o,
    l,
    r,
    s,
    u,
    c,
    g,
    _,
    m,
    w,
    y,
    x,
    p,
    d,
    h,
    D,
    F,
    O,
    k,
    L,
    Q,
    ne,
    me,
    ce,
    ie,
    W,
    b,
    $,
    a,
    n,
    De
  ];
}
class so extends Yl {
  constructor(e) {
    super(), eo(
      this,
      e,
      ro,
      oo,
      io,
      {
        height: 2,
        min_height: 3,
        max_height: 4,
        width: 5,
        elem_id: 6,
        elem_classes: 7,
        variant: 8,
        border_mode: 9,
        padding: 10,
        type: 28,
        test_id: 11,
        explicit_call: 12,
        container: 13,
        visible: 14,
        allow_overflow: 15,
        overflow_behavior: 16,
        scale: 17,
        min_width: 18,
        flex: 1,
        resizable: 19,
        rtl: 20,
        fullscreen: 0
      },
      null,
      [-1, -1]
    );
  }
}
function hi() {
  return {
    async: !1,
    breaks: !1,
    extensions: null,
    gfm: !0,
    hooks: null,
    pedantic: !1,
    renderer: null,
    silent: !1,
    tokenizer: null,
    walkTokens: null
  };
}
let Ot = hi();
function tl(i) {
  Ot = i;
}
const nl = /[&<>"']/, uo = new RegExp(nl.source, "g"), il = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, co = new RegExp(il.source, "g"), _o = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, Ui = (i) => _o[i];
function He(i, e) {
  if (e) {
    if (nl.test(i))
      return i.replace(uo, Ui);
  } else if (il.test(i))
    return i.replace(co, Ui);
  return i;
}
const fo = /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig;
function po(i) {
  return i.replace(fo, (e, t) => (t = t.toLowerCase(), t === "colon" ? ":" : t.charAt(0) === "#" ? t.charAt(1) === "x" ? String.fromCharCode(parseInt(t.substring(2), 16)) : String.fromCharCode(+t.substring(1)) : ""));
}
const ho = /(^|[^\[])\^/g;
function se(i, e) {
  let t = typeof i == "string" ? i : i.source;
  e = e || "";
  const n = {
    replace: (a, o) => {
      let l = typeof o == "string" ? o : o.source;
      return l = l.replace(ho, "$1"), t = t.replace(a, l), n;
    },
    getRegex: () => new RegExp(t, e)
  };
  return n;
}
function Hi(i) {
  try {
    i = encodeURI(i).replace(/%25/g, "%");
  } catch {
    return null;
  }
  return i;
}
const an = { exec: () => null };
function Gi(i, e) {
  const t = i.replace(/\|/g, (o, l, r) => {
    let s = !1, u = l;
    for (; --u >= 0 && r[u] === "\\"; )
      s = !s;
    return s ? "|" : " |";
  }), n = t.split(/ \|/);
  let a = 0;
  if (n[0].trim() || n.shift(), n.length > 0 && !n[n.length - 1].trim() && n.pop(), e)
    if (n.length > e)
      n.splice(e);
    else
      for (; n.length < e; )
        n.push("");
  for (; a < n.length; a++)
    n[a] = n[a].trim().replace(/\\\|/g, "|");
  return n;
}
function mn(i, e, t) {
  const n = i.length;
  if (n === 0)
    return "";
  let a = 0;
  for (; a < n && i.charAt(n - a - 1) === e; )
    a++;
  return i.slice(0, n - a);
}
function mo(i, e) {
  if (i.indexOf(e[1]) === -1)
    return -1;
  let t = 0;
  for (let n = 0; n < i.length; n++)
    if (i[n] === "\\")
      n++;
    else if (i[n] === e[0])
      t++;
    else if (i[n] === e[1] && (t--, t < 0))
      return n;
  return -1;
}
function ji(i, e, t, n) {
  const a = e.href, o = e.title ? He(e.title) : null, l = i[1].replace(/\\([\[\]])/g, "$1");
  if (i[0].charAt(0) !== "!") {
    n.state.inLink = !0;
    const r = {
      type: "link",
      raw: t,
      href: a,
      title: o,
      text: l,
      tokens: n.inlineTokens(l)
    };
    return n.state.inLink = !1, r;
  }
  return {
    type: "image",
    raw: t,
    href: a,
    title: o,
    text: He(l)
  };
}
function go(i, e) {
  const t = i.match(/^(\s+)(?:```)/);
  if (t === null)
    return e;
  const n = t[1];
  return e.split(`
`).map((a) => {
    const o = a.match(/^\s+/);
    if (o === null)
      return a;
    const [l] = o;
    return l.length >= n.length ? a.slice(n.length) : a;
  }).join(`
`);
}
class Tn {
  // set by the lexer
  constructor(e) {
    _e(this, "options");
    _e(this, "rules");
    // set by the lexer
    _e(this, "lexer");
    this.options = e || Ot;
  }
  space(e) {
    const t = this.rules.block.newline.exec(e);
    if (t && t[0].length > 0)
      return {
        type: "space",
        raw: t[0]
      };
  }
  code(e) {
    const t = this.rules.block.code.exec(e);
    if (t) {
      const n = t[0].replace(/^ {1,4}/gm, "");
      return {
        type: "code",
        raw: t[0],
        codeBlockStyle: "indented",
        text: this.options.pedantic ? n : mn(n, `
`)
      };
    }
  }
  fences(e) {
    const t = this.rules.block.fences.exec(e);
    if (t) {
      const n = t[0], a = go(n, t[3] || "");
      return {
        type: "code",
        raw: n,
        lang: t[2] ? t[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : t[2],
        text: a
      };
    }
  }
  heading(e) {
    const t = this.rules.block.heading.exec(e);
    if (t) {
      let n = t[2].trim();
      if (/#$/.test(n)) {
        const a = mn(n, "#");
        (this.options.pedantic || !a || / $/.test(a)) && (n = a.trim());
      }
      return {
        type: "heading",
        raw: t[0],
        depth: t[1].length,
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  hr(e) {
    const t = this.rules.block.hr.exec(e);
    if (t)
      return {
        type: "hr",
        raw: t[0]
      };
  }
  blockquote(e) {
    const t = this.rules.block.blockquote.exec(e);
    if (t) {
      let n = t[0].replace(/\n {0,3}((?:=+|-+) *)(?=\n|$)/g, `
    $1`);
      n = mn(n.replace(/^ *>[ \t]?/gm, ""), `
`);
      const a = this.lexer.state.top;
      this.lexer.state.top = !0;
      const o = this.lexer.blockTokens(n);
      return this.lexer.state.top = a, {
        type: "blockquote",
        raw: t[0],
        tokens: o,
        text: n
      };
    }
  }
  list(e) {
    let t = this.rules.block.list.exec(e);
    if (t) {
      let n = t[1].trim();
      const a = n.length > 1, o = {
        type: "list",
        raw: "",
        ordered: a,
        start: a ? +n.slice(0, -1) : "",
        loose: !1,
        items: []
      };
      n = a ? `\\d{1,9}\\${n.slice(-1)}` : `\\${n}`, this.options.pedantic && (n = a ? n : "[*+-]");
      const l = new RegExp(`^( {0,3}${n})((?:[	 ][^\\n]*)?(?:\\n|$))`);
      let r = "", s = "", u = !1;
      for (; e; ) {
        let c = !1;
        if (!(t = l.exec(e)) || this.rules.block.hr.test(e))
          break;
        r = t[0], e = e.substring(r.length);
        let g = t[2].split(`
`, 1)[0].replace(/^\t+/, (x) => " ".repeat(3 * x.length)), _ = e.split(`
`, 1)[0], m = 0;
        this.options.pedantic ? (m = 2, s = g.trimStart()) : (m = t[2].search(/[^ ]/), m = m > 4 ? 1 : m, s = g.slice(m), m += t[1].length);
        let b = !1;
        if (!g && /^ *$/.test(_) && (r += _ + `
`, e = e.substring(_.length + 1), c = !0), !c) {
          const x = new RegExp(`^ {0,${Math.min(3, m - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`), p = new RegExp(`^ {0,${Math.min(3, m - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`), d = new RegExp(`^ {0,${Math.min(3, m - 1)}}(?:\`\`\`|~~~)`), h = new RegExp(`^ {0,${Math.min(3, m - 1)}}#`);
          for (; e; ) {
            const D = e.split(`
`, 1)[0];
            if (_ = D, this.options.pedantic && (_ = _.replace(/^ {1,4}(?=( {4})*[^ ])/g, "  ")), d.test(_) || h.test(_) || x.test(_) || p.test(e))
              break;
            if (_.search(/[^ ]/) >= m || !_.trim())
              s += `
` + _.slice(m);
            else {
              if (b || g.search(/[^ ]/) >= 4 || d.test(g) || h.test(g) || p.test(g))
                break;
              s += `
` + _;
            }
            !b && !_.trim() && (b = !0), r += D + `
`, e = e.substring(D.length + 1), g = _.slice(m);
          }
        }
        o.loose || (u ? o.loose = !0 : /\n *\n *$/.test(r) && (u = !0));
        let w = null, y;
        this.options.gfm && (w = /^\[[ xX]\] /.exec(s), w && (y = w[0] !== "[ ] ", s = s.replace(/^\[[ xX]\] +/, ""))), o.items.push({
          type: "list_item",
          raw: r,
          task: !!w,
          checked: y,
          loose: !1,
          text: s,
          tokens: []
        }), o.raw += r;
      }
      o.items[o.items.length - 1].raw = r.trimEnd(), o.items[o.items.length - 1].text = s.trimEnd(), o.raw = o.raw.trimEnd();
      for (let c = 0; c < o.items.length; c++)
        if (this.lexer.state.top = !1, o.items[c].tokens = this.lexer.blockTokens(o.items[c].text, []), !o.loose) {
          const g = o.items[c].tokens.filter((m) => m.type === "space"), _ = g.length > 0 && g.some((m) => /\n.*\n/.test(m.raw));
          o.loose = _;
        }
      if (o.loose)
        for (let c = 0; c < o.items.length; c++)
          o.items[c].loose = !0;
      return o;
    }
  }
  html(e) {
    const t = this.rules.block.html.exec(e);
    if (t)
      return {
        type: "html",
        block: !0,
        raw: t[0],
        pre: t[1] === "pre" || t[1] === "script" || t[1] === "style",
        text: t[0]
      };
  }
  def(e) {
    const t = this.rules.block.def.exec(e);
    if (t) {
      const n = t[1].toLowerCase().replace(/\s+/g, " "), a = t[2] ? t[2].replace(/^<(.*)>$/, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", o = t[3] ? t[3].substring(1, t[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : t[3];
      return {
        type: "def",
        tag: n,
        raw: t[0],
        href: a,
        title: o
      };
    }
  }
  table(e) {
    const t = this.rules.block.table.exec(e);
    if (!t || !/[:|]/.test(t[2]))
      return;
    const n = Gi(t[1]), a = t[2].replace(/^\||\| *$/g, "").split("|"), o = t[3] && t[3].trim() ? t[3].replace(/\n[ \t]*$/, "").split(`
`) : [], l = {
      type: "table",
      raw: t[0],
      header: [],
      align: [],
      rows: []
    };
    if (n.length === a.length) {
      for (const r of a)
        /^ *-+: *$/.test(r) ? l.align.push("right") : /^ *:-+: *$/.test(r) ? l.align.push("center") : /^ *:-+ *$/.test(r) ? l.align.push("left") : l.align.push(null);
      for (const r of n)
        l.header.push({
          text: r,
          tokens: this.lexer.inline(r)
        });
      for (const r of o)
        l.rows.push(Gi(r, l.header.length).map((s) => ({
          text: s,
          tokens: this.lexer.inline(s)
        })));
      return l;
    }
  }
  lheading(e) {
    const t = this.rules.block.lheading.exec(e);
    if (t)
      return {
        type: "heading",
        raw: t[0],
        depth: t[2].charAt(0) === "=" ? 1 : 2,
        text: t[1],
        tokens: this.lexer.inline(t[1])
      };
  }
  paragraph(e) {
    const t = this.rules.block.paragraph.exec(e);
    if (t) {
      const n = t[1].charAt(t[1].length - 1) === `
` ? t[1].slice(0, -1) : t[1];
      return {
        type: "paragraph",
        raw: t[0],
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  text(e) {
    const t = this.rules.block.text.exec(e);
    if (t)
      return {
        type: "text",
        raw: t[0],
        text: t[0],
        tokens: this.lexer.inline(t[0])
      };
  }
  escape(e) {
    const t = this.rules.inline.escape.exec(e);
    if (t)
      return {
        type: "escape",
        raw: t[0],
        text: He(t[1])
      };
  }
  tag(e) {
    const t = this.rules.inline.tag.exec(e);
    if (t)
      return !this.lexer.state.inLink && /^<a /i.test(t[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && /^<\/a>/i.test(t[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && /^<(pre|code|kbd|script)(\s|>)/i.test(t[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && /^<\/(pre|code|kbd|script)(\s|>)/i.test(t[0]) && (this.lexer.state.inRawBlock = !1), {
        type: "html",
        raw: t[0],
        inLink: this.lexer.state.inLink,
        inRawBlock: this.lexer.state.inRawBlock,
        block: !1,
        text: t[0]
      };
  }
  link(e) {
    const t = this.rules.inline.link.exec(e);
    if (t) {
      const n = t[2].trim();
      if (!this.options.pedantic && /^</.test(n)) {
        if (!/>$/.test(n))
          return;
        const l = mn(n.slice(0, -1), "\\");
        if ((n.length - l.length) % 2 === 0)
          return;
      } else {
        const l = mo(t[2], "()");
        if (l > -1) {
          const s = (t[0].indexOf("!") === 0 ? 5 : 4) + t[1].length + l;
          t[2] = t[2].substring(0, l), t[0] = t[0].substring(0, s).trim(), t[3] = "";
        }
      }
      let a = t[2], o = "";
      if (this.options.pedantic) {
        const l = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(a);
        l && (a = l[1], o = l[3]);
      } else
        o = t[3] ? t[3].slice(1, -1) : "";
      return a = a.trim(), /^</.test(a) && (this.options.pedantic && !/>$/.test(n) ? a = a.slice(1) : a = a.slice(1, -1)), ji(t, {
        href: a && a.replace(this.rules.inline.anyPunctuation, "$1"),
        title: o && o.replace(this.rules.inline.anyPunctuation, "$1")
      }, t[0], this.lexer);
    }
  }
  reflink(e, t) {
    let n;
    if ((n = this.rules.inline.reflink.exec(e)) || (n = this.rules.inline.nolink.exec(e))) {
      const a = (n[2] || n[1]).replace(/\s+/g, " "), o = t[a.toLowerCase()];
      if (!o) {
        const l = n[0].charAt(0);
        return {
          type: "text",
          raw: l,
          text: l
        };
      }
      return ji(n, o, n[0], this.lexer);
    }
  }
  emStrong(e, t, n = "") {
    let a = this.rules.inline.emStrongLDelim.exec(e);
    if (!a || a[3] && n.match(/[\p{L}\p{N}]/u))
      return;
    if (!(a[1] || a[2] || "") || !n || this.rules.inline.punctuation.exec(n)) {
      const l = [...a[0]].length - 1;
      let r, s, u = l, c = 0;
      const g = a[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (g.lastIndex = 0, t = t.slice(-1 * e.length + l); (a = g.exec(t)) != null; ) {
        if (r = a[1] || a[2] || a[3] || a[4] || a[5] || a[6], !r)
          continue;
        if (s = [...r].length, a[3] || a[4]) {
          u += s;
          continue;
        } else if ((a[5] || a[6]) && l % 3 && !((l + s) % 3)) {
          c += s;
          continue;
        }
        if (u -= s, u > 0)
          continue;
        s = Math.min(s, s + u + c);
        const _ = [...a[0]][0].length, m = e.slice(0, l + a.index + _ + s);
        if (Math.min(l, s) % 2) {
          const w = m.slice(1, -1);
          return {
            type: "em",
            raw: m,
            text: w,
            tokens: this.lexer.inlineTokens(w)
          };
        }
        const b = m.slice(2, -2);
        return {
          type: "strong",
          raw: m,
          text: b,
          tokens: this.lexer.inlineTokens(b)
        };
      }
    }
  }
  codespan(e) {
    const t = this.rules.inline.code.exec(e);
    if (t) {
      let n = t[2].replace(/\n/g, " ");
      const a = /[^ ]/.test(n), o = /^ /.test(n) && / $/.test(n);
      return a && o && (n = n.substring(1, n.length - 1)), n = He(n, !0), {
        type: "codespan",
        raw: t[0],
        text: n
      };
    }
  }
  br(e) {
    const t = this.rules.inline.br.exec(e);
    if (t)
      return {
        type: "br",
        raw: t[0]
      };
  }
  del(e) {
    const t = this.rules.inline.del.exec(e);
    if (t)
      return {
        type: "del",
        raw: t[0],
        text: t[2],
        tokens: this.lexer.inlineTokens(t[2])
      };
  }
  autolink(e) {
    const t = this.rules.inline.autolink.exec(e);
    if (t) {
      let n, a;
      return t[2] === "@" ? (n = He(t[1]), a = "mailto:" + n) : (n = He(t[1]), a = n), {
        type: "link",
        raw: t[0],
        text: n,
        href: a,
        tokens: [
          {
            type: "text",
            raw: n,
            text: n
          }
        ]
      };
    }
  }
  url(e) {
    var n;
    let t;
    if (t = this.rules.inline.url.exec(e)) {
      let a, o;
      if (t[2] === "@")
        a = He(t[0]), o = "mailto:" + a;
      else {
        let l;
        do
          l = t[0], t[0] = ((n = this.rules.inline._backpedal.exec(t[0])) == null ? void 0 : n[0]) ?? "";
        while (l !== t[0]);
        a = He(t[0]), t[1] === "www." ? o = "http://" + t[0] : o = t[0];
      }
      return {
        type: "link",
        raw: t[0],
        text: a,
        href: o,
        tokens: [
          {
            type: "text",
            raw: a,
            text: a
          }
        ]
      };
    }
  }
  inlineText(e) {
    const t = this.rules.inline.text.exec(e);
    if (t) {
      let n;
      return this.lexer.state.inRawBlock ? n = t[0] : n = He(t[0]), {
        type: "text",
        raw: t[0],
        text: n
      };
    }
  }
}
const bo = /^(?: *(?:\n|$))+/, vo = /^( {4}[^\n]+(?:\n(?: *(?:\n|$))*)?)+/, Do = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, un = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, yo = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, al = /(?:[*+-]|\d{1,9}[.)])/, ll = se(/^(?!bull |blockCode|fences|blockquote|heading|html)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html))+?)\n {0,3}(=+|-+) *(?:\n+|$)/).replace(/bull/g, al).replace(/blockCode/g, / {4}/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).getRegex(), mi = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, Eo = /^[^\n]+/, gi = /(?!\s*\])(?:\\.|[^\[\]\\])+/, wo = se(/^ {0,3}\[(label)\]: *(?:\n *)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n *)?| *\n *)(title))? *(?:\n+|$)/).replace("label", gi).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), ko = se(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, al).getRegex(), Bn = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", bi = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, Fo = se("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n *)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$))", "i").replace("comment", bi).replace("tag", Bn).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), ol = se(mi).replace("hr", un).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Bn).getRegex(), $o = se(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", ol).getRegex(), vi = {
  blockquote: $o,
  code: vo,
  def: wo,
  fences: Do,
  heading: yo,
  hr: un,
  html: Fo,
  lheading: ll,
  list: ko,
  newline: bo,
  paragraph: ol,
  table: an,
  text: Eo
}, Vi = se("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", un).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Bn).getRegex(), Ao = {
  ...vi,
  table: Vi,
  paragraph: se(mi).replace("hr", un).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", Vi).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Bn).getRegex()
}, Co = {
  ...vi,
  html: se(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", bi).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: an,
  // fences not supported
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: se(mi).replace("hr", un).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", ll).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
}, rl = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, So = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, sl = /^( {2,}|\\)\n(?!\s*$)/, To = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, cn = "\\p{P}\\p{S}", Io = se(/^((?![*_])[\spunctuation])/, "u").replace(/punctuation/g, cn).getRegex(), Ro = /\[[^[\]]*?\]\([^\(\)]*?\)|`[^`]*?`|<[^<>]*?>/g, xo = se(/^(?:\*+(?:((?!\*)[punct])|[^\s*]))|^_+(?:((?!_)[punct])|([^\s_]))/, "u").replace(/punct/g, cn).getRegex(), Lo = se("^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)[punct](\\*+)(?=[\\s]|$)|[^punct\\s](\\*+)(?!\\*)(?=[punct\\s]|$)|(?!\\*)[punct\\s](\\*+)(?=[^punct\\s])|[\\s](\\*+)(?!\\*)(?=[punct])|(?!\\*)[punct](\\*+)(?!\\*)(?=[punct])|[^punct\\s](\\*+)(?=[^punct\\s])", "gu").replace(/punct/g, cn).getRegex(), No = se("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)[punct](_+)(?=[\\s]|$)|[^punct\\s](_+)(?!_)(?=[punct\\s]|$)|(?!_)[punct\\s](_+)(?=[^punct\\s])|[\\s](_+)(?!_)(?=[punct])|(?!_)[punct](_+)(?!_)(?=[punct])", "gu").replace(/punct/g, cn).getRegex(), Oo = se(/\\([punct])/, "gu").replace(/punct/g, cn).getRegex(), Bo = se(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), Mo = se(bi).replace("(?:-->|$)", "-->").getRegex(), Po = se("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", Mo).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), In = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, qo = se(/^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/).replace("label", In).replace("href", /<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), ul = se(/^!?\[(label)\]\[(ref)\]/).replace("label", In).replace("ref", gi).getRegex(), cl = se(/^!?\[(ref)\](?:\[\])?/).replace("ref", gi).getRegex(), zo = se("reflink|nolink(?!\\()", "g").replace("reflink", ul).replace("nolink", cl).getRegex(), Di = {
  _backpedal: an,
  // only used for GFM url
  anyPunctuation: Oo,
  autolink: Bo,
  blockSkip: Ro,
  br: sl,
  code: So,
  del: an,
  emStrongLDelim: xo,
  emStrongRDelimAst: Lo,
  emStrongRDelimUnd: No,
  escape: rl,
  link: qo,
  nolink: cl,
  punctuation: Io,
  reflink: ul,
  reflinkSearch: zo,
  tag: Po,
  text: To,
  url: an
}, Uo = {
  ...Di,
  link: se(/^!?\[(label)\]\((.*?)\)/).replace("label", In).getRegex(),
  reflink: se(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", In).getRegex()
}, ii = {
  ...Di,
  escape: se(rl).replace("])", "~|])").getRegex(),
  url: se(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])([\s\S]*?[^\s~])\1(?=[^~]|$)/,
  text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
}, Ho = {
  ...ii,
  br: se(sl).replace("{2,}", "*").getRegex(),
  text: se(ii.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
}, gn = {
  normal: vi,
  gfm: Ao,
  pedantic: Co
}, Zt = {
  normal: Di,
  gfm: ii,
  breaks: Ho,
  pedantic: Uo
};
class ct {
  constructor(e) {
    _e(this, "tokens");
    _e(this, "options");
    _e(this, "state");
    _e(this, "tokenizer");
    _e(this, "inlineQueue");
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = e || Ot, this.options.tokenizer = this.options.tokenizer || new Tn(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
      inLink: !1,
      inRawBlock: !1,
      top: !0
    };
    const t = {
      block: gn.normal,
      inline: Zt.normal
    };
    this.options.pedantic ? (t.block = gn.pedantic, t.inline = Zt.pedantic) : this.options.gfm && (t.block = gn.gfm, this.options.breaks ? t.inline = Zt.breaks : t.inline = Zt.gfm), this.tokenizer.rules = t;
  }
  /**
   * Expose Rules
   */
  static get rules() {
    return {
      block: gn,
      inline: Zt
    };
  }
  /**
   * Static Lex Method
   */
  static lex(e, t) {
    return new ct(t).lex(e);
  }
  /**
   * Static Lex Inline Method
   */
  static lexInline(e, t) {
    return new ct(t).inlineTokens(e);
  }
  /**
   * Preprocessing
   */
  lex(e) {
    e = e.replace(/\r\n|\r/g, `
`), this.blockTokens(e, this.tokens);
    for (let t = 0; t < this.inlineQueue.length; t++) {
      const n = this.inlineQueue[t];
      this.inlineTokens(n.src, n.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(e, t = []) {
    this.options.pedantic ? e = e.replace(/\t/g, "    ").replace(/^ +$/gm, "") : e = e.replace(/^( *)(\t+)/gm, (r, s, u) => s + "    ".repeat(u.length));
    let n, a, o, l;
    for (; e; )
      if (!(this.options.extensions && this.options.extensions.block && this.options.extensions.block.some((r) => (n = r.call({ lexer: this }, e, t)) ? (e = e.substring(n.raw.length), t.push(n), !0) : !1))) {
        if (n = this.tokenizer.space(e)) {
          e = e.substring(n.raw.length), n.raw.length === 1 && t.length > 0 ? t[t.length - 1].raw += `
` : t.push(n);
          continue;
        }
        if (n = this.tokenizer.code(e)) {
          e = e.substring(n.raw.length), a = t[t.length - 1], a && (a.type === "paragraph" || a.type === "text") ? (a.raw += `
` + n.raw, a.text += `
` + n.text, this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.fences(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.heading(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.hr(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.blockquote(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.list(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.html(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.def(e)) {
          e = e.substring(n.raw.length), a = t[t.length - 1], a && (a.type === "paragraph" || a.type === "text") ? (a.raw += `
` + n.raw, a.text += `
` + n.raw, this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : this.tokens.links[n.tag] || (this.tokens.links[n.tag] = {
            href: n.href,
            title: n.title
          });
          continue;
        }
        if (n = this.tokenizer.table(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.lheading(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (o = e, this.options.extensions && this.options.extensions.startBlock) {
          let r = 1 / 0;
          const s = e.slice(1);
          let u;
          this.options.extensions.startBlock.forEach((c) => {
            u = c.call({ lexer: this }, s), typeof u == "number" && u >= 0 && (r = Math.min(r, u));
          }), r < 1 / 0 && r >= 0 && (o = e.substring(0, r + 1));
        }
        if (this.state.top && (n = this.tokenizer.paragraph(o))) {
          a = t[t.length - 1], l && a.type === "paragraph" ? (a.raw += `
` + n.raw, a.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : t.push(n), l = o.length !== e.length, e = e.substring(n.raw.length);
          continue;
        }
        if (n = this.tokenizer.text(e)) {
          e = e.substring(n.raw.length), a = t[t.length - 1], a && a.type === "text" ? (a.raw += `
` + n.raw, a.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : t.push(n);
          continue;
        }
        if (e) {
          const r = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(r);
            break;
          } else
            throw new Error(r);
        }
      }
    return this.state.top = !0, t;
  }
  inline(e, t = []) {
    return this.inlineQueue.push({ src: e, tokens: t }), t;
  }
  /**
   * Lexing/Compiling
   */
  inlineTokens(e, t = []) {
    let n, a, o, l = e, r, s, u;
    if (this.tokens.links) {
      const c = Object.keys(this.tokens.links);
      if (c.length > 0)
        for (; (r = this.tokenizer.rules.inline.reflinkSearch.exec(l)) != null; )
          c.includes(r[0].slice(r[0].lastIndexOf("[") + 1, -1)) && (l = l.slice(0, r.index) + "[" + "a".repeat(r[0].length - 2) + "]" + l.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (r = this.tokenizer.rules.inline.blockSkip.exec(l)) != null; )
      l = l.slice(0, r.index) + "[" + "a".repeat(r[0].length - 2) + "]" + l.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    for (; (r = this.tokenizer.rules.inline.anyPunctuation.exec(l)) != null; )
      l = l.slice(0, r.index) + "++" + l.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    for (; e; )
      if (s || (u = ""), s = !1, !(this.options.extensions && this.options.extensions.inline && this.options.extensions.inline.some((c) => (n = c.call({ lexer: this }, e, t)) ? (e = e.substring(n.raw.length), t.push(n), !0) : !1))) {
        if (n = this.tokenizer.escape(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.tag(e)) {
          e = e.substring(n.raw.length), a = t[t.length - 1], a && n.type === "text" && a.type === "text" ? (a.raw += n.raw, a.text += n.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.link(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.reflink(e, this.tokens.links)) {
          e = e.substring(n.raw.length), a = t[t.length - 1], a && n.type === "text" && a.type === "text" ? (a.raw += n.raw, a.text += n.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.emStrong(e, l, u)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.codespan(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.br(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.del(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.autolink(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (!this.state.inLink && (n = this.tokenizer.url(e))) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (o = e, this.options.extensions && this.options.extensions.startInline) {
          let c = 1 / 0;
          const g = e.slice(1);
          let _;
          this.options.extensions.startInline.forEach((m) => {
            _ = m.call({ lexer: this }, g), typeof _ == "number" && _ >= 0 && (c = Math.min(c, _));
          }), c < 1 / 0 && c >= 0 && (o = e.substring(0, c + 1));
        }
        if (n = this.tokenizer.inlineText(o)) {
          e = e.substring(n.raw.length), n.raw.slice(-1) !== "_" && (u = n.raw.slice(-1)), s = !0, a = t[t.length - 1], a && a.type === "text" ? (a.raw += n.raw, a.text += n.text) : t.push(n);
          continue;
        }
        if (e) {
          const c = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(c);
            break;
          } else
            throw new Error(c);
        }
      }
    return t;
  }
}
class Rn {
  constructor(e) {
    _e(this, "options");
    this.options = e || Ot;
  }
  code(e, t, n) {
    var o;
    const a = (o = (t || "").match(/^\S*/)) == null ? void 0 : o[0];
    return e = e.replace(/\n$/, "") + `
`, a ? '<pre><code class="language-' + He(a) + '">' + (n ? e : He(e, !0)) + `</code></pre>
` : "<pre><code>" + (n ? e : He(e, !0)) + `</code></pre>
`;
  }
  blockquote(e) {
    return `<blockquote>
${e}</blockquote>
`;
  }
  html(e, t) {
    return e;
  }
  heading(e, t, n) {
    return `<h${t}>${e}</h${t}>
`;
  }
  hr() {
    return `<hr>
`;
  }
  list(e, t, n) {
    const a = t ? "ol" : "ul", o = t && n !== 1 ? ' start="' + n + '"' : "";
    return "<" + a + o + `>
` + e + "</" + a + `>
`;
  }
  listitem(e, t, n) {
    return `<li>${e}</li>
`;
  }
  checkbox(e) {
    return "<input " + (e ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph(e) {
    return `<p>${e}</p>
`;
  }
  table(e, t) {
    return t && (t = `<tbody>${t}</tbody>`), `<table>
<thead>
` + e + `</thead>
` + t + `</table>
`;
  }
  tablerow(e) {
    return `<tr>
${e}</tr>
`;
  }
  tablecell(e, t) {
    const n = t.header ? "th" : "td";
    return (t.align ? `<${n} align="${t.align}">` : `<${n}>`) + e + `</${n}>
`;
  }
  /**
   * span level renderer
   */
  strong(e) {
    return `<strong>${e}</strong>`;
  }
  em(e) {
    return `<em>${e}</em>`;
  }
  codespan(e) {
    return `<code>${e}</code>`;
  }
  br() {
    return "<br>";
  }
  del(e) {
    return `<del>${e}</del>`;
  }
  link(e, t, n) {
    const a = Hi(e);
    if (a === null)
      return n;
    e = a;
    let o = '<a href="' + e + '"';
    return t && (o += ' title="' + t + '"'), o += ">" + n + "</a>", o;
  }
  image(e, t, n) {
    const a = Hi(e);
    if (a === null)
      return n;
    e = a;
    let o = `<img src="${e}" alt="${n}"`;
    return t && (o += ` title="${t}"`), o += ">", o;
  }
  text(e) {
    return e;
  }
}
class yi {
  // no need for block level renderers
  strong(e) {
    return e;
  }
  em(e) {
    return e;
  }
  codespan(e) {
    return e;
  }
  del(e) {
    return e;
  }
  html(e) {
    return e;
  }
  text(e) {
    return e;
  }
  link(e, t, n) {
    return "" + n;
  }
  image(e, t, n) {
    return "" + n;
  }
  br() {
    return "";
  }
}
class dt {
  constructor(e) {
    _e(this, "options");
    _e(this, "renderer");
    _e(this, "textRenderer");
    this.options = e || Ot, this.options.renderer = this.options.renderer || new Rn(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.textRenderer = new yi();
  }
  /**
   * Static Parse Method
   */
  static parse(e, t) {
    return new dt(t).parse(e);
  }
  /**
   * Static Parse Inline Method
   */
  static parseInline(e, t) {
    return new dt(t).parseInline(e);
  }
  /**
   * Parse Loop
   */
  parse(e, t = !0) {
    let n = "";
    for (let a = 0; a < e.length; a++) {
      const o = e[a];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[o.type]) {
        const l = o, r = this.options.extensions.renderers[l.type].call({ parser: this }, l);
        if (r !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(l.type)) {
          n += r || "";
          continue;
        }
      }
      switch (o.type) {
        case "space":
          continue;
        case "hr": {
          n += this.renderer.hr();
          continue;
        }
        case "heading": {
          const l = o;
          n += this.renderer.heading(this.parseInline(l.tokens), l.depth, po(this.parseInline(l.tokens, this.textRenderer)));
          continue;
        }
        case "code": {
          const l = o;
          n += this.renderer.code(l.text, l.lang, !!l.escaped);
          continue;
        }
        case "table": {
          const l = o;
          let r = "", s = "";
          for (let c = 0; c < l.header.length; c++)
            s += this.renderer.tablecell(this.parseInline(l.header[c].tokens), { header: !0, align: l.align[c] });
          r += this.renderer.tablerow(s);
          let u = "";
          for (let c = 0; c < l.rows.length; c++) {
            const g = l.rows[c];
            s = "";
            for (let _ = 0; _ < g.length; _++)
              s += this.renderer.tablecell(this.parseInline(g[_].tokens), { header: !1, align: l.align[_] });
            u += this.renderer.tablerow(s);
          }
          n += this.renderer.table(r, u);
          continue;
        }
        case "blockquote": {
          const l = o, r = this.parse(l.tokens);
          n += this.renderer.blockquote(r);
          continue;
        }
        case "list": {
          const l = o, r = l.ordered, s = l.start, u = l.loose;
          let c = "";
          for (let g = 0; g < l.items.length; g++) {
            const _ = l.items[g], m = _.checked, b = _.task;
            let w = "";
            if (_.task) {
              const y = this.renderer.checkbox(!!m);
              u ? _.tokens.length > 0 && _.tokens[0].type === "paragraph" ? (_.tokens[0].text = y + " " + _.tokens[0].text, _.tokens[0].tokens && _.tokens[0].tokens.length > 0 && _.tokens[0].tokens[0].type === "text" && (_.tokens[0].tokens[0].text = y + " " + _.tokens[0].tokens[0].text)) : _.tokens.unshift({
                type: "text",
                text: y + " "
              }) : w += y + " ";
            }
            w += this.parse(_.tokens, u), c += this.renderer.listitem(w, b, !!m);
          }
          n += this.renderer.list(c, r, s);
          continue;
        }
        case "html": {
          const l = o;
          n += this.renderer.html(l.text, l.block);
          continue;
        }
        case "paragraph": {
          const l = o;
          n += this.renderer.paragraph(this.parseInline(l.tokens));
          continue;
        }
        case "text": {
          let l = o, r = l.tokens ? this.parseInline(l.tokens) : l.text;
          for (; a + 1 < e.length && e[a + 1].type === "text"; )
            l = e[++a], r += `
` + (l.tokens ? this.parseInline(l.tokens) : l.text);
          n += t ? this.renderer.paragraph(r) : r;
          continue;
        }
        default: {
          const l = 'Token with "' + o.type + '" type was not found.';
          if (this.options.silent)
            return console.error(l), "";
          throw new Error(l);
        }
      }
    }
    return n;
  }
  /**
   * Parse Inline Tokens
   */
  parseInline(e, t) {
    t = t || this.renderer;
    let n = "";
    for (let a = 0; a < e.length; a++) {
      const o = e[a];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[o.type]) {
        const l = this.options.extensions.renderers[o.type].call({ parser: this }, o);
        if (l !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(o.type)) {
          n += l || "";
          continue;
        }
      }
      switch (o.type) {
        case "escape": {
          const l = o;
          n += t.text(l.text);
          break;
        }
        case "html": {
          const l = o;
          n += t.html(l.text);
          break;
        }
        case "link": {
          const l = o;
          n += t.link(l.href, l.title, this.parseInline(l.tokens, t));
          break;
        }
        case "image": {
          const l = o;
          n += t.image(l.href, l.title, l.text);
          break;
        }
        case "strong": {
          const l = o;
          n += t.strong(this.parseInline(l.tokens, t));
          break;
        }
        case "em": {
          const l = o;
          n += t.em(this.parseInline(l.tokens, t));
          break;
        }
        case "codespan": {
          const l = o;
          n += t.codespan(l.text);
          break;
        }
        case "br": {
          n += t.br();
          break;
        }
        case "del": {
          const l = o;
          n += t.del(this.parseInline(l.tokens, t));
          break;
        }
        case "text": {
          const l = o;
          n += t.text(l.text);
          break;
        }
        default: {
          const l = 'Token with "' + o.type + '" type was not found.';
          if (this.options.silent)
            return console.error(l), "";
          throw new Error(l);
        }
      }
    }
    return n;
  }
}
class ln {
  constructor(e) {
    _e(this, "options");
    this.options = e || Ot;
  }
  /**
   * Process markdown before marked
   */
  preprocess(e) {
    return e;
  }
  /**
   * Process HTML after marked is finished
   */
  postprocess(e) {
    return e;
  }
  /**
   * Process all tokens before walk tokens
   */
  processAllTokens(e) {
    return e;
  }
}
_e(ln, "passThroughHooks", /* @__PURE__ */ new Set([
  "preprocess",
  "postprocess",
  "processAllTokens"
]));
var Nt, ai, dl;
class Go {
  constructor(...e) {
    Bi(this, Nt);
    _e(this, "defaults", hi());
    _e(this, "options", this.setOptions);
    _e(this, "parse", hn(this, Nt, ai).call(this, ct.lex, dt.parse));
    _e(this, "parseInline", hn(this, Nt, ai).call(this, ct.lexInline, dt.parseInline));
    _e(this, "Parser", dt);
    _e(this, "Renderer", Rn);
    _e(this, "TextRenderer", yi);
    _e(this, "Lexer", ct);
    _e(this, "Tokenizer", Tn);
    _e(this, "Hooks", ln);
    this.use(...e);
  }
  /**
   * Run callback for every token
   */
  walkTokens(e, t) {
    var a, o;
    let n = [];
    for (const l of e)
      switch (n = n.concat(t.call(this, l)), l.type) {
        case "table": {
          const r = l;
          for (const s of r.header)
            n = n.concat(this.walkTokens(s.tokens, t));
          for (const s of r.rows)
            for (const u of s)
              n = n.concat(this.walkTokens(u.tokens, t));
          break;
        }
        case "list": {
          const r = l;
          n = n.concat(this.walkTokens(r.items, t));
          break;
        }
        default: {
          const r = l;
          (o = (a = this.defaults.extensions) == null ? void 0 : a.childTokens) != null && o[r.type] ? this.defaults.extensions.childTokens[r.type].forEach((s) => {
            const u = r[s].flat(1 / 0);
            n = n.concat(this.walkTokens(u, t));
          }) : r.tokens && (n = n.concat(this.walkTokens(r.tokens, t)));
        }
      }
    return n;
  }
  use(...e) {
    const t = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return e.forEach((n) => {
      const a = { ...n };
      if (a.async = this.defaults.async || a.async || !1, n.extensions && (n.extensions.forEach((o) => {
        if (!o.name)
          throw new Error("extension name required");
        if ("renderer" in o) {
          const l = t.renderers[o.name];
          l ? t.renderers[o.name] = function(...r) {
            let s = o.renderer.apply(this, r);
            return s === !1 && (s = l.apply(this, r)), s;
          } : t.renderers[o.name] = o.renderer;
        }
        if ("tokenizer" in o) {
          if (!o.level || o.level !== "block" && o.level !== "inline")
            throw new Error("extension level must be 'block' or 'inline'");
          const l = t[o.level];
          l ? l.unshift(o.tokenizer) : t[o.level] = [o.tokenizer], o.start && (o.level === "block" ? t.startBlock ? t.startBlock.push(o.start) : t.startBlock = [o.start] : o.level === "inline" && (t.startInline ? t.startInline.push(o.start) : t.startInline = [o.start]));
        }
        "childTokens" in o && o.childTokens && (t.childTokens[o.name] = o.childTokens);
      }), a.extensions = t), n.renderer) {
        const o = this.defaults.renderer || new Rn(this.defaults);
        for (const l in n.renderer) {
          if (!(l in o))
            throw new Error(`renderer '${l}' does not exist`);
          if (l === "options")
            continue;
          const r = l, s = n.renderer[r], u = o[r];
          o[r] = (...c) => {
            let g = s.apply(o, c);
            return g === !1 && (g = u.apply(o, c)), g || "";
          };
        }
        a.renderer = o;
      }
      if (n.tokenizer) {
        const o = this.defaults.tokenizer || new Tn(this.defaults);
        for (const l in n.tokenizer) {
          if (!(l in o))
            throw new Error(`tokenizer '${l}' does not exist`);
          if (["options", "rules", "lexer"].includes(l))
            continue;
          const r = l, s = n.tokenizer[r], u = o[r];
          o[r] = (...c) => {
            let g = s.apply(o, c);
            return g === !1 && (g = u.apply(o, c)), g;
          };
        }
        a.tokenizer = o;
      }
      if (n.hooks) {
        const o = this.defaults.hooks || new ln();
        for (const l in n.hooks) {
          if (!(l in o))
            throw new Error(`hook '${l}' does not exist`);
          if (l === "options")
            continue;
          const r = l, s = n.hooks[r], u = o[r];
          ln.passThroughHooks.has(l) ? o[r] = (c) => {
            if (this.defaults.async)
              return Promise.resolve(s.call(o, c)).then((_) => u.call(o, _));
            const g = s.call(o, c);
            return u.call(o, g);
          } : o[r] = (...c) => {
            let g = s.apply(o, c);
            return g === !1 && (g = u.apply(o, c)), g;
          };
        }
        a.hooks = o;
      }
      if (n.walkTokens) {
        const o = this.defaults.walkTokens, l = n.walkTokens;
        a.walkTokens = function(r) {
          let s = [];
          return s.push(l.call(this, r)), o && (s = s.concat(o.call(this, r))), s;
        };
      }
      this.defaults = { ...this.defaults, ...a };
    }), this;
  }
  setOptions(e) {
    return this.defaults = { ...this.defaults, ...e }, this;
  }
  lexer(e, t) {
    return ct.lex(e, t ?? this.defaults);
  }
  parser(e, t) {
    return dt.parse(e, t ?? this.defaults);
  }
}
Nt = new WeakSet(), ai = function(e, t) {
  return (n, a) => {
    const o = { ...a }, l = { ...this.defaults, ...o };
    this.defaults.async === !0 && o.async === !1 && (l.silent || console.warn("marked(): The async option was set to true by an extension. The async: false option sent to parse will be ignored."), l.async = !0);
    const r = hn(this, Nt, dl).call(this, !!l.silent, !!l.async);
    if (typeof n > "u" || n === null)
      return r(new Error("marked(): input parameter is undefined or null"));
    if (typeof n != "string")
      return r(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(n) + ", string expected"));
    if (l.hooks && (l.hooks.options = l), l.async)
      return Promise.resolve(l.hooks ? l.hooks.preprocess(n) : n).then((s) => e(s, l)).then((s) => l.hooks ? l.hooks.processAllTokens(s) : s).then((s) => l.walkTokens ? Promise.all(this.walkTokens(s, l.walkTokens)).then(() => s) : s).then((s) => t(s, l)).then((s) => l.hooks ? l.hooks.postprocess(s) : s).catch(r);
    try {
      l.hooks && (n = l.hooks.preprocess(n));
      let s = e(n, l);
      l.hooks && (s = l.hooks.processAllTokens(s)), l.walkTokens && this.walkTokens(s, l.walkTokens);
      let u = t(s, l);
      return l.hooks && (u = l.hooks.postprocess(u)), u;
    } catch (s) {
      return r(s);
    }
  };
}, dl = function(e, t) {
  return (n) => {
    if (n.message += `
Please report this to https://github.com/markedjs/marked.`, e) {
      const a = "<p>An error occurred:</p><pre>" + He(n.message + "", !0) + "</pre>";
      return t ? Promise.resolve(a) : a;
    }
    if (t)
      return Promise.reject(n);
    throw n;
  };
};
const Rt = new Go();
function re(i, e) {
  return Rt.parse(i, e);
}
re.options = re.setOptions = function(i) {
  return Rt.setOptions(i), re.defaults = Rt.defaults, tl(re.defaults), re;
};
re.getDefaults = hi;
re.defaults = Ot;
re.use = function(...i) {
  return Rt.use(...i), re.defaults = Rt.defaults, tl(re.defaults), re;
};
re.walkTokens = function(i, e) {
  return Rt.walkTokens(i, e);
};
re.parseInline = Rt.parseInline;
re.Parser = dt;
re.parser = dt.parse;
re.Renderer = Rn;
re.TextRenderer = yi;
re.Lexer = ct;
re.lexer = ct.lex;
re.Tokenizer = Tn;
re.Hooks = ln;
re.parse = re;
re.options;
re.setOptions;
re.use;
re.walkTokens;
re.parseInline;
dt.parse;
ct.lex;
const jo = /[\0-\x1F!-,\.\/:-@\[-\^`\{-\xA9\xAB-\xB4\xB6-\xB9\xBB-\xBF\xD7\xF7\u02C2-\u02C5\u02D2-\u02DF\u02E5-\u02EB\u02ED\u02EF-\u02FF\u0375\u0378\u0379\u037E\u0380-\u0385\u0387\u038B\u038D\u03A2\u03F6\u0482\u0530\u0557\u0558\u055A-\u055F\u0589-\u0590\u05BE\u05C0\u05C3\u05C6\u05C8-\u05CF\u05EB-\u05EE\u05F3-\u060F\u061B-\u061F\u066A-\u066D\u06D4\u06DD\u06DE\u06E9\u06FD\u06FE\u0700-\u070F\u074B\u074C\u07B2-\u07BF\u07F6-\u07F9\u07FB\u07FC\u07FE\u07FF\u082E-\u083F\u085C-\u085F\u086B-\u089F\u08B5\u08C8-\u08D2\u08E2\u0964\u0965\u0970\u0984\u098D\u098E\u0991\u0992\u09A9\u09B1\u09B3-\u09B5\u09BA\u09BB\u09C5\u09C6\u09C9\u09CA\u09CF-\u09D6\u09D8-\u09DB\u09DE\u09E4\u09E5\u09F2-\u09FB\u09FD\u09FF\u0A00\u0A04\u0A0B-\u0A0E\u0A11\u0A12\u0A29\u0A31\u0A34\u0A37\u0A3A\u0A3B\u0A3D\u0A43-\u0A46\u0A49\u0A4A\u0A4E-\u0A50\u0A52-\u0A58\u0A5D\u0A5F-\u0A65\u0A76-\u0A80\u0A84\u0A8E\u0A92\u0AA9\u0AB1\u0AB4\u0ABA\u0ABB\u0AC6\u0ACA\u0ACE\u0ACF\u0AD1-\u0ADF\u0AE4\u0AE5\u0AF0-\u0AF8\u0B00\u0B04\u0B0D\u0B0E\u0B11\u0B12\u0B29\u0B31\u0B34\u0B3A\u0B3B\u0B45\u0B46\u0B49\u0B4A\u0B4E-\u0B54\u0B58-\u0B5B\u0B5E\u0B64\u0B65\u0B70\u0B72-\u0B81\u0B84\u0B8B-\u0B8D\u0B91\u0B96-\u0B98\u0B9B\u0B9D\u0BA0-\u0BA2\u0BA5-\u0BA7\u0BAB-\u0BAD\u0BBA-\u0BBD\u0BC3-\u0BC5\u0BC9\u0BCE\u0BCF\u0BD1-\u0BD6\u0BD8-\u0BE5\u0BF0-\u0BFF\u0C0D\u0C11\u0C29\u0C3A-\u0C3C\u0C45\u0C49\u0C4E-\u0C54\u0C57\u0C5B-\u0C5F\u0C64\u0C65\u0C70-\u0C7F\u0C84\u0C8D\u0C91\u0CA9\u0CB4\u0CBA\u0CBB\u0CC5\u0CC9\u0CCE-\u0CD4\u0CD7-\u0CDD\u0CDF\u0CE4\u0CE5\u0CF0\u0CF3-\u0CFF\u0D0D\u0D11\u0D45\u0D49\u0D4F-\u0D53\u0D58-\u0D5E\u0D64\u0D65\u0D70-\u0D79\u0D80\u0D84\u0D97-\u0D99\u0DB2\u0DBC\u0DBE\u0DBF\u0DC7-\u0DC9\u0DCB-\u0DCE\u0DD5\u0DD7\u0DE0-\u0DE5\u0DF0\u0DF1\u0DF4-\u0E00\u0E3B-\u0E3F\u0E4F\u0E5A-\u0E80\u0E83\u0E85\u0E8B\u0EA4\u0EA6\u0EBE\u0EBF\u0EC5\u0EC7\u0ECE\u0ECF\u0EDA\u0EDB\u0EE0-\u0EFF\u0F01-\u0F17\u0F1A-\u0F1F\u0F2A-\u0F34\u0F36\u0F38\u0F3A-\u0F3D\u0F48\u0F6D-\u0F70\u0F85\u0F98\u0FBD-\u0FC5\u0FC7-\u0FFF\u104A-\u104F\u109E\u109F\u10C6\u10C8-\u10CC\u10CE\u10CF\u10FB\u1249\u124E\u124F\u1257\u1259\u125E\u125F\u1289\u128E\u128F\u12B1\u12B6\u12B7\u12BF\u12C1\u12C6\u12C7\u12D7\u1311\u1316\u1317\u135B\u135C\u1360-\u137F\u1390-\u139F\u13F6\u13F7\u13FE-\u1400\u166D\u166E\u1680\u169B-\u169F\u16EB-\u16ED\u16F9-\u16FF\u170D\u1715-\u171F\u1735-\u173F\u1754-\u175F\u176D\u1771\u1774-\u177F\u17D4-\u17D6\u17D8-\u17DB\u17DE\u17DF\u17EA-\u180A\u180E\u180F\u181A-\u181F\u1879-\u187F\u18AB-\u18AF\u18F6-\u18FF\u191F\u192C-\u192F\u193C-\u1945\u196E\u196F\u1975-\u197F\u19AC-\u19AF\u19CA-\u19CF\u19DA-\u19FF\u1A1C-\u1A1F\u1A5F\u1A7D\u1A7E\u1A8A-\u1A8F\u1A9A-\u1AA6\u1AA8-\u1AAF\u1AC1-\u1AFF\u1B4C-\u1B4F\u1B5A-\u1B6A\u1B74-\u1B7F\u1BF4-\u1BFF\u1C38-\u1C3F\u1C4A-\u1C4C\u1C7E\u1C7F\u1C89-\u1C8F\u1CBB\u1CBC\u1CC0-\u1CCF\u1CD3\u1CFB-\u1CFF\u1DFA\u1F16\u1F17\u1F1E\u1F1F\u1F46\u1F47\u1F4E\u1F4F\u1F58\u1F5A\u1F5C\u1F5E\u1F7E\u1F7F\u1FB5\u1FBD\u1FBF-\u1FC1\u1FC5\u1FCD-\u1FCF\u1FD4\u1FD5\u1FDC-\u1FDF\u1FED-\u1FF1\u1FF5\u1FFD-\u203E\u2041-\u2053\u2055-\u2070\u2072-\u207E\u2080-\u208F\u209D-\u20CF\u20F1-\u2101\u2103-\u2106\u2108\u2109\u2114\u2116-\u2118\u211E-\u2123\u2125\u2127\u2129\u212E\u213A\u213B\u2140-\u2144\u214A-\u214D\u214F-\u215F\u2189-\u24B5\u24EA-\u2BFF\u2C2F\u2C5F\u2CE5-\u2CEA\u2CF4-\u2CFF\u2D26\u2D28-\u2D2C\u2D2E\u2D2F\u2D68-\u2D6E\u2D70-\u2D7E\u2D97-\u2D9F\u2DA7\u2DAF\u2DB7\u2DBF\u2DC7\u2DCF\u2DD7\u2DDF\u2E00-\u2E2E\u2E30-\u3004\u3008-\u3020\u3030\u3036\u3037\u303D-\u3040\u3097\u3098\u309B\u309C\u30A0\u30FB\u3100-\u3104\u3130\u318F-\u319F\u31C0-\u31EF\u3200-\u33FF\u4DC0-\u4DFF\u9FFD-\u9FFF\uA48D-\uA4CF\uA4FE\uA4FF\uA60D-\uA60F\uA62C-\uA63F\uA673\uA67E\uA6F2-\uA716\uA720\uA721\uA789\uA78A\uA7C0\uA7C1\uA7CB-\uA7F4\uA828-\uA82B\uA82D-\uA83F\uA874-\uA87F\uA8C6-\uA8CF\uA8DA-\uA8DF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA954-\uA95F\uA97D-\uA97F\uA9C1-\uA9CE\uA9DA-\uA9DF\uA9FF\uAA37-\uAA3F\uAA4E\uAA4F\uAA5A-\uAA5F\uAA77-\uAA79\uAAC3-\uAADA\uAADE\uAADF\uAAF0\uAAF1\uAAF7-\uAB00\uAB07\uAB08\uAB0F\uAB10\uAB17-\uAB1F\uAB27\uAB2F\uAB5B\uAB6A-\uAB6F\uABEB\uABEE\uABEF\uABFA-\uABFF\uD7A4-\uD7AF\uD7C7-\uD7CA\uD7FC-\uD7FF\uE000-\uF8FF\uFA6E\uFA6F\uFADA-\uFAFF\uFB07-\uFB12\uFB18-\uFB1C\uFB29\uFB37\uFB3D\uFB3F\uFB42\uFB45\uFBB2-\uFBD2\uFD3E-\uFD4F\uFD90\uFD91\uFDC8-\uFDEF\uFDFC-\uFDFF\uFE10-\uFE1F\uFE30-\uFE32\uFE35-\uFE4C\uFE50-\uFE6F\uFE75\uFEFD-\uFF0F\uFF1A-\uFF20\uFF3B-\uFF3E\uFF40\uFF5B-\uFF65\uFFBF-\uFFC1\uFFC8\uFFC9\uFFD0\uFFD1\uFFD8\uFFD9\uFFDD-\uFFFF]|\uD800[\uDC0C\uDC27\uDC3B\uDC3E\uDC4E\uDC4F\uDC5E-\uDC7F\uDCFB-\uDD3F\uDD75-\uDDFC\uDDFE-\uDE7F\uDE9D-\uDE9F\uDED1-\uDEDF\uDEE1-\uDEFF\uDF20-\uDF2C\uDF4B-\uDF4F\uDF7B-\uDF7F\uDF9E\uDF9F\uDFC4-\uDFC7\uDFD0\uDFD6-\uDFFF]|\uD801[\uDC9E\uDC9F\uDCAA-\uDCAF\uDCD4-\uDCD7\uDCFC-\uDCFF\uDD28-\uDD2F\uDD64-\uDDFF\uDF37-\uDF3F\uDF56-\uDF5F\uDF68-\uDFFF]|\uD802[\uDC06\uDC07\uDC09\uDC36\uDC39-\uDC3B\uDC3D\uDC3E\uDC56-\uDC5F\uDC77-\uDC7F\uDC9F-\uDCDF\uDCF3\uDCF6-\uDCFF\uDD16-\uDD1F\uDD3A-\uDD7F\uDDB8-\uDDBD\uDDC0-\uDDFF\uDE04\uDE07-\uDE0B\uDE14\uDE18\uDE36\uDE37\uDE3B-\uDE3E\uDE40-\uDE5F\uDE7D-\uDE7F\uDE9D-\uDEBF\uDEC8\uDEE7-\uDEFF\uDF36-\uDF3F\uDF56-\uDF5F\uDF73-\uDF7F\uDF92-\uDFFF]|\uD803[\uDC49-\uDC7F\uDCB3-\uDCBF\uDCF3-\uDCFF\uDD28-\uDD2F\uDD3A-\uDE7F\uDEAA\uDEAD-\uDEAF\uDEB2-\uDEFF\uDF1D-\uDF26\uDF28-\uDF2F\uDF51-\uDFAF\uDFC5-\uDFDF\uDFF7-\uDFFF]|\uD804[\uDC47-\uDC65\uDC70-\uDC7E\uDCBB-\uDCCF\uDCE9-\uDCEF\uDCFA-\uDCFF\uDD35\uDD40-\uDD43\uDD48-\uDD4F\uDD74\uDD75\uDD77-\uDD7F\uDDC5-\uDDC8\uDDCD\uDDDB\uDDDD-\uDDFF\uDE12\uDE38-\uDE3D\uDE3F-\uDE7F\uDE87\uDE89\uDE8E\uDE9E\uDEA9-\uDEAF\uDEEB-\uDEEF\uDEFA-\uDEFF\uDF04\uDF0D\uDF0E\uDF11\uDF12\uDF29\uDF31\uDF34\uDF3A\uDF45\uDF46\uDF49\uDF4A\uDF4E\uDF4F\uDF51-\uDF56\uDF58-\uDF5C\uDF64\uDF65\uDF6D-\uDF6F\uDF75-\uDFFF]|\uD805[\uDC4B-\uDC4F\uDC5A-\uDC5D\uDC62-\uDC7F\uDCC6\uDCC8-\uDCCF\uDCDA-\uDD7F\uDDB6\uDDB7\uDDC1-\uDDD7\uDDDE-\uDDFF\uDE41-\uDE43\uDE45-\uDE4F\uDE5A-\uDE7F\uDEB9-\uDEBF\uDECA-\uDEFF\uDF1B\uDF1C\uDF2C-\uDF2F\uDF3A-\uDFFF]|\uD806[\uDC3B-\uDC9F\uDCEA-\uDCFE\uDD07\uDD08\uDD0A\uDD0B\uDD14\uDD17\uDD36\uDD39\uDD3A\uDD44-\uDD4F\uDD5A-\uDD9F\uDDA8\uDDA9\uDDD8\uDDD9\uDDE2\uDDE5-\uDDFF\uDE3F-\uDE46\uDE48-\uDE4F\uDE9A-\uDE9C\uDE9E-\uDEBF\uDEF9-\uDFFF]|\uD807[\uDC09\uDC37\uDC41-\uDC4F\uDC5A-\uDC71\uDC90\uDC91\uDCA8\uDCB7-\uDCFF\uDD07\uDD0A\uDD37-\uDD39\uDD3B\uDD3E\uDD48-\uDD4F\uDD5A-\uDD5F\uDD66\uDD69\uDD8F\uDD92\uDD99-\uDD9F\uDDAA-\uDEDF\uDEF7-\uDFAF\uDFB1-\uDFFF]|\uD808[\uDF9A-\uDFFF]|\uD809[\uDC6F-\uDC7F\uDD44-\uDFFF]|[\uD80A\uD80B\uD80E-\uD810\uD812-\uD819\uD824-\uD82B\uD82D\uD82E\uD830-\uD833\uD837\uD839\uD83D\uD83F\uD87B-\uD87D\uD87F\uD885-\uDB3F\uDB41-\uDBFF][\uDC00-\uDFFF]|\uD80D[\uDC2F-\uDFFF]|\uD811[\uDE47-\uDFFF]|\uD81A[\uDE39-\uDE3F\uDE5F\uDE6A-\uDECF\uDEEE\uDEEF\uDEF5-\uDEFF\uDF37-\uDF3F\uDF44-\uDF4F\uDF5A-\uDF62\uDF78-\uDF7C\uDF90-\uDFFF]|\uD81B[\uDC00-\uDE3F\uDE80-\uDEFF\uDF4B-\uDF4E\uDF88-\uDF8E\uDFA0-\uDFDF\uDFE2\uDFE5-\uDFEF\uDFF2-\uDFFF]|\uD821[\uDFF8-\uDFFF]|\uD823[\uDCD6-\uDCFF\uDD09-\uDFFF]|\uD82C[\uDD1F-\uDD4F\uDD53-\uDD63\uDD68-\uDD6F\uDEFC-\uDFFF]|\uD82F[\uDC6B-\uDC6F\uDC7D-\uDC7F\uDC89-\uDC8F\uDC9A-\uDC9C\uDC9F-\uDFFF]|\uD834[\uDC00-\uDD64\uDD6A-\uDD6C\uDD73-\uDD7A\uDD83\uDD84\uDD8C-\uDDA9\uDDAE-\uDE41\uDE45-\uDFFF]|\uD835[\uDC55\uDC9D\uDCA0\uDCA1\uDCA3\uDCA4\uDCA7\uDCA8\uDCAD\uDCBA\uDCBC\uDCC4\uDD06\uDD0B\uDD0C\uDD15\uDD1D\uDD3A\uDD3F\uDD45\uDD47-\uDD49\uDD51\uDEA6\uDEA7\uDEC1\uDEDB\uDEFB\uDF15\uDF35\uDF4F\uDF6F\uDF89\uDFA9\uDFC3\uDFCC\uDFCD]|\uD836[\uDC00-\uDDFF\uDE37-\uDE3A\uDE6D-\uDE74\uDE76-\uDE83\uDE85-\uDE9A\uDEA0\uDEB0-\uDFFF]|\uD838[\uDC07\uDC19\uDC1A\uDC22\uDC25\uDC2B-\uDCFF\uDD2D-\uDD2F\uDD3E\uDD3F\uDD4A-\uDD4D\uDD4F-\uDEBF\uDEFA-\uDFFF]|\uD83A[\uDCC5-\uDCCF\uDCD7-\uDCFF\uDD4C-\uDD4F\uDD5A-\uDFFF]|\uD83B[\uDC00-\uDDFF\uDE04\uDE20\uDE23\uDE25\uDE26\uDE28\uDE33\uDE38\uDE3A\uDE3C-\uDE41\uDE43-\uDE46\uDE48\uDE4A\uDE4C\uDE50\uDE53\uDE55\uDE56\uDE58\uDE5A\uDE5C\uDE5E\uDE60\uDE63\uDE65\uDE66\uDE6B\uDE73\uDE78\uDE7D\uDE7F\uDE8A\uDE9C-\uDEA0\uDEA4\uDEAA\uDEBC-\uDFFF]|\uD83C[\uDC00-\uDD2F\uDD4A-\uDD4F\uDD6A-\uDD6F\uDD8A-\uDFFF]|\uD83E[\uDC00-\uDFEF\uDFFA-\uDFFF]|\uD869[\uDEDE-\uDEFF]|\uD86D[\uDF35-\uDF3F]|\uD86E[\uDC1E\uDC1F]|\uD873[\uDEA2-\uDEAF]|\uD87A[\uDFE1-\uDFFF]|\uD87E[\uDE1E-\uDFFF]|\uD884[\uDF4B-\uDFFF]|\uDB40[\uDC00-\uDCFF\uDDF0-\uDFFF]/g, Vo = Object.hasOwnProperty;
class _l {
  /**
   * Create a new slug class.
   */
  constructor() {
    this.occurrences, this.reset();
  }
  /**
   * Generate a unique slug.
  *
  * Tracks previously generated slugs: repeated calls with the same value
  * will result in different slugs.
  * Use the `slug` function to get same slugs.
   *
   * @param  {string} value
   *   String of text to slugify
   * @param  {boolean} [maintainCase=false]
   *   Keep the current case, otherwise make all lowercase
   * @return {string}
   *   A unique slug string
   */
  slug(e, t) {
    const n = this;
    let a = Yo(e, t === !0);
    const o = a;
    for (; Vo.call(n.occurrences, a); )
      n.occurrences[o]++, a = o + "-" + n.occurrences[o];
    return n.occurrences[a] = 0, a;
  }
  /**
   * Reset - Forget all previous slugs
   *
   * @return void
   */
  reset() {
    this.occurrences = /* @__PURE__ */ Object.create(null);
  }
}
function Yo(i, e) {
  return typeof i != "string" ? "" : (e || (i = i.toLowerCase()), i.replace(jo, "").replace(/ /g, "-"));
}
new _l();
var Yi = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {}, Wo = { exports: {} };
(function(i) {
  var e = typeof window < "u" ? window : typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope ? self : {};
  /**
   * Prism: Lightweight, robust, elegant syntax highlighting
   *
   * @license MIT <https://opensource.org/licenses/MIT>
   * @author Lea Verou <https://lea.verou.me>
   * @namespace
   * @public
   */
  var t = function(n) {
    var a = /(?:^|\s)lang(?:uage)?-([\w-]+)(?=\s|$)/i, o = 0, l = {}, r = {
      /**
       * By default, Prism will attempt to highlight all code elements (by calling {@link Prism.highlightAll}) on the
       * current page after the page finished loading. This might be a problem if e.g. you wanted to asynchronously load
       * additional languages or plugins yourself.
       *
       * By setting this value to `true`, Prism will not automatically highlight all code elements on the page.
       *
       * You obviously have to change this value before the automatic highlighting started. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.manual = true;
       * // add a new <script> to load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      manual: n.Prism && n.Prism.manual,
      /**
       * By default, if Prism is in a web worker, it assumes that it is in a worker it created itself, so it uses
       * `addEventListener` to communicate with its parent instance. However, if you're using Prism manually in your
       * own worker, you don't want it to do this.
       *
       * By setting this value to `true`, Prism will not add its own listeners to the worker.
       *
       * You obviously have to change this value before Prism executes. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.disableWorkerMessageHandler = true;
       * // Load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      disableWorkerMessageHandler: n.Prism && n.Prism.disableWorkerMessageHandler,
      /**
       * A namespace for utility methods.
       *
       * All function in this namespace that are not explicitly marked as _public_ are for __internal use only__ and may
       * change or disappear at any time.
       *
       * @namespace
       * @memberof Prism
       */
      util: {
        encode: function p(d) {
          return d instanceof s ? new s(d.type, p(d.content), d.alias) : Array.isArray(d) ? d.map(p) : d.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\u00a0/g, " ");
        },
        /**
         * Returns the name of the type of the given value.
         *
         * @param {any} o
         * @returns {string}
         * @example
         * type(null)      === 'Null'
         * type(undefined) === 'Undefined'
         * type(123)       === 'Number'
         * type('foo')     === 'String'
         * type(true)      === 'Boolean'
         * type([1, 2])    === 'Array'
         * type({})        === 'Object'
         * type(String)    === 'Function'
         * type(/abc+/)    === 'RegExp'
         */
        type: function(p) {
          return Object.prototype.toString.call(p).slice(8, -1);
        },
        /**
         * Returns a unique number for the given object. Later calls will still return the same number.
         *
         * @param {Object} obj
         * @returns {number}
         */
        objId: function(p) {
          return p.__id || Object.defineProperty(p, "__id", { value: ++o }), p.__id;
        },
        /**
         * Creates a deep clone of the given object.
         *
         * The main intended use of this function is to clone language definitions.
         *
         * @param {T} o
         * @param {Record<number, any>} [visited]
         * @returns {T}
         * @template T
         */
        clone: function p(d, h) {
          h = h || {};
          var D, F;
          switch (r.util.type(d)) {
            case "Object":
              if (F = r.util.objId(d), h[F])
                return h[F];
              D = /** @type {Record<string, any>} */
              {}, h[F] = D;
              for (var S in d)
                d.hasOwnProperty(S) && (D[S] = p(d[S], h));
              return (
                /** @type {any} */
                D
              );
            case "Array":
              return F = r.util.objId(d), h[F] ? h[F] : (D = [], h[F] = D, /** @type {Array} */
              /** @type {any} */
              d.forEach(function(O, k) {
                D[k] = p(O, h);
              }), /** @type {any} */
              D);
            default:
              return d;
          }
        },
        /**
         * Returns the Prism language of the given element set by a `language-xxxx` or `lang-xxxx` class.
         *
         * If no language is set for the element or the element is `null` or `undefined`, `none` will be returned.
         *
         * @param {Element} element
         * @returns {string}
         */
        getLanguage: function(p) {
          for (; p; ) {
            var d = a.exec(p.className);
            if (d)
              return d[1].toLowerCase();
            p = p.parentElement;
          }
          return "none";
        },
        /**
         * Sets the Prism `language-xxxx` class of the given element.
         *
         * @param {Element} element
         * @param {string} language
         * @returns {void}
         */
        setLanguage: function(p, d) {
          p.className = p.className.replace(RegExp(a, "gi"), ""), p.classList.add("language-" + d);
        },
        /**
         * Returns the script element that is currently executing.
         *
         * This does __not__ work for line script element.
         *
         * @returns {HTMLScriptElement | null}
         */
        currentScript: function() {
          if (typeof document > "u")
            return null;
          if (document.currentScript && document.currentScript.tagName === "SCRIPT")
            return (
              /** @type {any} */
              document.currentScript
            );
          try {
            throw new Error();
          } catch (D) {
            var p = (/at [^(\r\n]*\((.*):[^:]+:[^:]+\)$/i.exec(D.stack) || [])[1];
            if (p) {
              var d = document.getElementsByTagName("script");
              for (var h in d)
                if (d[h].src == p)
                  return d[h];
            }
            return null;
          }
        },
        /**
         * Returns whether a given class is active for `element`.
         *
         * The class can be activated if `element` or one of its ancestors has the given class and it can be deactivated
         * if `element` or one of its ancestors has the negated version of the given class. The _negated version_ of the
         * given class is just the given class with a `no-` prefix.
         *
         * Whether the class is active is determined by the closest ancestor of `element` (where `element` itself is
         * closest ancestor) that has the given class or the negated version of it. If neither `element` nor any of its
         * ancestors have the given class or the negated version of it, then the default activation will be returned.
         *
         * In the paradoxical situation where the closest ancestor contains __both__ the given class and the negated
         * version of it, the class is considered active.
         *
         * @param {Element} element
         * @param {string} className
         * @param {boolean} [defaultActivation=false]
         * @returns {boolean}
         */
        isActive: function(p, d, h) {
          for (var D = "no-" + d; p; ) {
            var F = p.classList;
            if (F.contains(d))
              return !0;
            if (F.contains(D))
              return !1;
            p = p.parentElement;
          }
          return !!h;
        }
      },
      /**
       * This namespace contains all currently loaded languages and the some helper functions to create and modify languages.
       *
       * @namespace
       * @memberof Prism
       * @public
       */
      languages: {
        /**
         * The grammar for plain, unformatted text.
         */
        plain: l,
        plaintext: l,
        text: l,
        txt: l,
        /**
         * Creates a deep copy of the language with the given id and appends the given tokens.
         *
         * If a token in `redef` also appears in the copied language, then the existing token in the copied language
         * will be overwritten at its original position.
         *
         * ## Best practices
         *
         * Since the position of overwriting tokens (token in `redef` that overwrite tokens in the copied language)
         * doesn't matter, they can technically be in any order. However, this can be confusing to others that trying to
         * understand the language definition because, normally, the order of tokens matters in Prism grammars.
         *
         * Therefore, it is encouraged to order overwriting tokens according to the positions of the overwritten tokens.
         * Furthermore, all non-overwriting tokens should be placed after the overwriting ones.
         *
         * @param {string} id The id of the language to extend. This has to be a key in `Prism.languages`.
         * @param {Grammar} redef The new tokens to append.
         * @returns {Grammar} The new language created.
         * @public
         * @example
         * Prism.languages['css-with-colors'] = Prism.languages.extend('css', {
         *     // Prism.languages.css already has a 'comment' token, so this token will overwrite CSS' 'comment' token
         *     // at its original position
         *     'comment': { ... },
         *     // CSS doesn't have a 'color' token, so this token will be appended
         *     'color': /\b(?:red|green|blue)\b/
         * });
         */
        extend: function(p, d) {
          var h = r.util.clone(r.languages[p]);
          for (var D in d)
            h[D] = d[D];
          return h;
        },
        /**
         * Inserts tokens _before_ another token in a language definition or any other grammar.
         *
         * ## Usage
         *
         * This helper method makes it easy to modify existing languages. For example, the CSS language definition
         * not only defines CSS highlighting for CSS documents, but also needs to define highlighting for CSS embedded
         * in HTML through `<style>` elements. To do this, it needs to modify `Prism.languages.markup` and add the
         * appropriate tokens. However, `Prism.languages.markup` is a regular JavaScript object literal, so if you do
         * this:
         *
         * ```js
         * Prism.languages.markup.style = {
         *     // token
         * };
         * ```
         *
         * then the `style` token will be added (and processed) at the end. `insertBefore` allows you to insert tokens
         * before existing tokens. For the CSS example above, you would use it like this:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'cdata', {
         *     'style': {
         *         // token
         *     }
         * });
         * ```
         *
         * ## Special cases
         *
         * If the grammars of `inside` and `insert` have tokens with the same name, the tokens in `inside`'s grammar
         * will be ignored.
         *
         * This behavior can be used to insert tokens after `before`:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'comment', {
         *     'comment': Prism.languages.markup.comment,
         *     // tokens after 'comment'
         * });
         * ```
         *
         * ## Limitations
         *
         * The main problem `insertBefore` has to solve is iteration order. Since ES2015, the iteration order for object
         * properties is guaranteed to be the insertion order (except for integer keys) but some browsers behave
         * differently when keys are deleted and re-inserted. So `insertBefore` can't be implemented by temporarily
         * deleting properties which is necessary to insert at arbitrary positions.
         *
         * To solve this problem, `insertBefore` doesn't actually insert the given tokens into the target object.
         * Instead, it will create a new object and replace all references to the target object with the new one. This
         * can be done without temporarily deleting properties, so the iteration order is well-defined.
         *
         * However, only references that can be reached from `Prism.languages` or `insert` will be replaced. I.e. if
         * you hold the target object in a variable, then the value of the variable will not change.
         *
         * ```js
         * var oldMarkup = Prism.languages.markup;
         * var newMarkup = Prism.languages.insertBefore('markup', 'comment', { ... });
         *
         * assert(oldMarkup !== Prism.languages.markup);
         * assert(newMarkup === Prism.languages.markup);
         * ```
         *
         * @param {string} inside The property of `root` (e.g. a language id in `Prism.languages`) that contains the
         * object to be modified.
         * @param {string} before The key to insert before.
         * @param {Grammar} insert An object containing the key-value pairs to be inserted.
         * @param {Object<string, any>} [root] The object containing `inside`, i.e. the object that contains the
         * object to be modified.
         *
         * Defaults to `Prism.languages`.
         * @returns {Grammar} The new grammar object.
         * @public
         */
        insertBefore: function(p, d, h, D) {
          D = D || /** @type {any} */
          r.languages;
          var F = D[p], S = {};
          for (var O in F)
            if (F.hasOwnProperty(O)) {
              if (O == d)
                for (var k in h)
                  h.hasOwnProperty(k) && (S[k] = h[k]);
              h.hasOwnProperty(O) || (S[O] = F[O]);
            }
          var A = D[p];
          return D[p] = S, r.languages.DFS(r.languages, function($, L) {
            L === A && $ != p && (this[$] = S);
          }), S;
        },
        // Traverse a language definition with Depth First Search
        DFS: function p(d, h, D, F) {
          F = F || {};
          var S = r.util.objId;
          for (var O in d)
            if (d.hasOwnProperty(O)) {
              h.call(d, O, d[O], D || O);
              var k = d[O], A = r.util.type(k);
              A === "Object" && !F[S(k)] ? (F[S(k)] = !0, p(k, h, null, F)) : A === "Array" && !F[S(k)] && (F[S(k)] = !0, p(k, h, O, F));
            }
        }
      },
      plugins: {},
      /**
       * This is the most high-level function in Prism’s API.
       * It fetches all the elements that have a `.language-xxxx` class and then calls {@link Prism.highlightElement} on
       * each one of them.
       *
       * This is equivalent to `Prism.highlightAllUnder(document, async, callback)`.
       *
       * @param {boolean} [async=false] Same as in {@link Prism.highlightAllUnder}.
       * @param {HighlightCallback} [callback] Same as in {@link Prism.highlightAllUnder}.
       * @memberof Prism
       * @public
       */
      highlightAll: function(p, d) {
        r.highlightAllUnder(document, p, d);
      },
      /**
       * Fetches all the descendants of `container` that have a `.language-xxxx` class and then calls
       * {@link Prism.highlightElement} on each one of them.
       *
       * The following hooks will be run:
       * 1. `before-highlightall`
       * 2. `before-all-elements-highlight`
       * 3. All hooks of {@link Prism.highlightElement} for each element.
       *
       * @param {ParentNode} container The root element, whose descendants that have a `.language-xxxx` class will be highlighted.
       * @param {boolean} [async=false] Whether each element is to be highlighted asynchronously using Web Workers.
       * @param {HighlightCallback} [callback] An optional callback to be invoked on each element after its highlighting is done.
       * @memberof Prism
       * @public
       */
      highlightAllUnder: function(p, d, h) {
        var D = {
          callback: h,
          container: p,
          selector: 'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'
        };
        r.hooks.run("before-highlightall", D), D.elements = Array.prototype.slice.apply(D.container.querySelectorAll(D.selector)), r.hooks.run("before-all-elements-highlight", D);
        for (var F = 0, S; S = D.elements[F++]; )
          r.highlightElement(S, d === !0, D.callback);
      },
      /**
       * Highlights the code inside a single element.
       *
       * The following hooks will be run:
       * 1. `before-sanity-check`
       * 2. `before-highlight`
       * 3. All hooks of {@link Prism.highlight}. These hooks will be run by an asynchronous worker if `async` is `true`.
       * 4. `before-insert`
       * 5. `after-highlight`
       * 6. `complete`
       *
       * Some the above hooks will be skipped if the element doesn't contain any text or there is no grammar loaded for
       * the element's language.
       *
       * @param {Element} element The element containing the code.
       * It must have a class of `language-xxxx` to be processed, where `xxxx` is a valid language identifier.
       * @param {boolean} [async=false] Whether the element is to be highlighted asynchronously using Web Workers
       * to improve performance and avoid blocking the UI when highlighting very large chunks of code. This option is
       * [disabled by default](https://prismjs.com/faq.html#why-is-asynchronous-highlighting-disabled-by-default).
       *
       * Note: All language definitions required to highlight the code must be included in the main `prism.js` file for
       * asynchronous highlighting to work. You can build your own bundle on the
       * [Download page](https://prismjs.com/download.html).
       * @param {HighlightCallback} [callback] An optional callback to be invoked after the highlighting is done.
       * Mostly useful when `async` is `true`, since in that case, the highlighting is done asynchronously.
       * @memberof Prism
       * @public
       */
      highlightElement: function(p, d, h) {
        var D = r.util.getLanguage(p), F = r.languages[D];
        r.util.setLanguage(p, D);
        var S = p.parentElement;
        S && S.nodeName.toLowerCase() === "pre" && r.util.setLanguage(S, D);
        var O = p.textContent, k = {
          element: p,
          language: D,
          grammar: F,
          code: O
        };
        function A(L) {
          k.highlightedCode = L, r.hooks.run("before-insert", k), k.element.innerHTML = k.highlightedCode, r.hooks.run("after-highlight", k), r.hooks.run("complete", k), h && h.call(k.element);
        }
        if (r.hooks.run("before-sanity-check", k), S = k.element.parentElement, S && S.nodeName.toLowerCase() === "pre" && !S.hasAttribute("tabindex") && S.setAttribute("tabindex", "0"), !k.code) {
          r.hooks.run("complete", k), h && h.call(k.element);
          return;
        }
        if (r.hooks.run("before-highlight", k), !k.grammar) {
          A(r.util.encode(k.code));
          return;
        }
        if (d && n.Worker) {
          var $ = new Worker(r.filename);
          $.onmessage = function(L) {
            A(L.data);
          }, $.postMessage(JSON.stringify({
            language: k.language,
            code: k.code,
            immediateClose: !0
          }));
        } else
          A(r.highlight(k.code, k.grammar, k.language));
      },
      /**
       * Low-level function, only use if you know what you’re doing. It accepts a string of text as input
       * and the language definitions to use, and returns a string with the HTML produced.
       *
       * The following hooks will be run:
       * 1. `before-tokenize`
       * 2. `after-tokenize`
       * 3. `wrap`: On each {@link Token}.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @param {string} language The name of the language definition passed to `grammar`.
       * @returns {string} The highlighted HTML.
       * @memberof Prism
       * @public
       * @example
       * Prism.highlight('var foo = true;', Prism.languages.javascript, 'javascript');
       */
      highlight: function(p, d, h) {
        var D = {
          code: p,
          grammar: d,
          language: h
        };
        if (r.hooks.run("before-tokenize", D), !D.grammar)
          throw new Error('The language "' + D.language + '" has no grammar.');
        return D.tokens = r.tokenize(D.code, D.grammar), r.hooks.run("after-tokenize", D), s.stringify(r.util.encode(D.tokens), D.language);
      },
      /**
       * This is the heart of Prism, and the most low-level function you can use. It accepts a string of text as input
       * and the language definitions to use, and returns an array with the tokenized code.
       *
       * When the language definition includes nested tokens, the function is called recursively on each of these tokens.
       *
       * This method could be useful in other contexts as well, as a very crude parser.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @returns {TokenStream} An array of strings and tokens, a token stream.
       * @memberof Prism
       * @public
       * @example
       * let code = `var foo = 0;`;
       * let tokens = Prism.tokenize(code, Prism.languages.javascript);
       * tokens.forEach(token => {
       *     if (token instanceof Prism.Token && token.type === 'number') {
       *         console.log(`Found numeric literal: ${token.content}`);
       *     }
       * });
       */
      tokenize: function(p, d) {
        var h = d.rest;
        if (h) {
          for (var D in h)
            d[D] = h[D];
          delete d.rest;
        }
        var F = new g();
        return _(F, F.head, p), c(p, F, d, F.head, 0), b(F);
      },
      /**
       * @namespace
       * @memberof Prism
       * @public
       */
      hooks: {
        all: {},
        /**
         * Adds the given callback to the list of callbacks for the given hook.
         *
         * The callback will be invoked when the hook it is registered for is run.
         * Hooks are usually directly run by a highlight function but you can also run hooks yourself.
         *
         * One callback function can be registered to multiple hooks and the same hook multiple times.
         *
         * @param {string} name The name of the hook.
         * @param {HookCallback} callback The callback function which is given environment variables.
         * @public
         */
        add: function(p, d) {
          var h = r.hooks.all;
          h[p] = h[p] || [], h[p].push(d);
        },
        /**
         * Runs a hook invoking all registered callbacks with the given environment variables.
         *
         * Callbacks will be invoked synchronously and in the order in which they were registered.
         *
         * @param {string} name The name of the hook.
         * @param {Object<string, any>} env The environment variables of the hook passed to all callbacks registered.
         * @public
         */
        run: function(p, d) {
          var h = r.hooks.all[p];
          if (!(!h || !h.length))
            for (var D = 0, F; F = h[D++]; )
              F(d);
        }
      },
      Token: s
    };
    n.Prism = r;
    function s(p, d, h, D) {
      this.type = p, this.content = d, this.alias = h, this.length = (D || "").length | 0;
    }
    s.stringify = function p(d, h) {
      if (typeof d == "string")
        return d;
      if (Array.isArray(d)) {
        var D = "";
        return d.forEach(function(A) {
          D += p(A, h);
        }), D;
      }
      var F = {
        type: d.type,
        content: p(d.content, h),
        tag: "span",
        classes: ["token", d.type],
        attributes: {},
        language: h
      }, S = d.alias;
      S && (Array.isArray(S) ? Array.prototype.push.apply(F.classes, S) : F.classes.push(S)), r.hooks.run("wrap", F);
      var O = "";
      for (var k in F.attributes)
        O += " " + k + '="' + (F.attributes[k] || "").replace(/"/g, "&quot;") + '"';
      return "<" + F.tag + ' class="' + F.classes.join(" ") + '"' + O + ">" + F.content + "</" + F.tag + ">";
    };
    function u(p, d, h, D) {
      p.lastIndex = d;
      var F = p.exec(h);
      if (F && D && F[1]) {
        var S = F[1].length;
        F.index += S, F[0] = F[0].slice(S);
      }
      return F;
    }
    function c(p, d, h, D, F, S) {
      for (var O in h)
        if (!(!h.hasOwnProperty(O) || !h[O])) {
          var k = h[O];
          k = Array.isArray(k) ? k : [k];
          for (var A = 0; A < k.length; ++A) {
            if (S && S.cause == O + "," + A)
              return;
            var $ = k[A], L = $.inside, ce = !!$.lookbehind, Q = !!$.greedy, ne = $.alias;
            if (Q && !$.pattern.global) {
              var me = $.pattern.toString().match(/[imsuy]*$/)[0];
              $.pattern = RegExp($.pattern.source, me + "g");
            }
            for (var Ae = $.pattern || $, ie = D.next, W = F; ie !== d.tail && !(S && W >= S.reach); W += ie.value.length, ie = ie.next) {
              var De = ie.value;
              if (d.length > p.length)
                return;
              if (!(De instanceof s)) {
                var I = 1, H;
                if (Q) {
                  if (H = u(Ae, W, p, ce), !H || H.index >= p.length)
                    break;
                  var ye = H.index, J = H.index + H[0].length, j = W;
                  for (j += ie.value.length; ye >= j; )
                    ie = ie.next, j += ie.value.length;
                  if (j -= ie.value.length, W = j, ie.value instanceof s)
                    continue;
                  for (var C = ie; C !== d.tail && (j < J || typeof C.value == "string"); C = C.next)
                    I++, j += C.value.length;
                  I--, De = p.slice(W, j), H.index -= W;
                } else if (H = u(Ae, 0, De, ce), !H)
                  continue;
                var ye = H.index, le = H[0], de = De.slice(0, ye), Re = De.slice(ye + le.length), ue = W + De.length;
                S && ue > S.reach && (S.reach = ue);
                var N = ie.prev;
                de && (N = _(d, N, de), W += de.length), m(d, N, I);
                var V = new s(O, L ? r.tokenize(le, L) : le, ne, le);
                if (ie = _(d, N, V), Re && _(d, ie, Re), I > 1) {
                  var B = {
                    cause: O + "," + A,
                    reach: ue
                  };
                  c(p, d, h, ie.prev, W, B), S && B.reach > S.reach && (S.reach = B.reach);
                }
              }
            }
          }
        }
    }
    function g() {
      var p = { value: null, prev: null, next: null }, d = { value: null, prev: p, next: null };
      p.next = d, this.head = p, this.tail = d, this.length = 0;
    }
    function _(p, d, h) {
      var D = d.next, F = { value: h, prev: d, next: D };
      return d.next = F, D.prev = F, p.length++, F;
    }
    function m(p, d, h) {
      for (var D = d.next, F = 0; F < h && D !== p.tail; F++)
        D = D.next;
      d.next = D, D.prev = d, p.length -= F;
    }
    function b(p) {
      for (var d = [], h = p.head.next; h !== p.tail; )
        d.push(h.value), h = h.next;
      return d;
    }
    if (!n.document)
      return n.addEventListener && (r.disableWorkerMessageHandler || n.addEventListener("message", function(p) {
        var d = JSON.parse(p.data), h = d.language, D = d.code, F = d.immediateClose;
        n.postMessage(r.highlight(D, r.languages[h], h)), F && n.close();
      }, !1)), r;
    var w = r.util.currentScript();
    w && (r.filename = w.src, w.hasAttribute("data-manual") && (r.manual = !0));
    function y() {
      r.manual || r.highlightAll();
    }
    if (!r.manual) {
      var x = document.readyState;
      x === "loading" || x === "interactive" && w && w.defer ? document.addEventListener("DOMContentLoaded", y) : window.requestAnimationFrame ? window.requestAnimationFrame(y) : window.setTimeout(y, 16);
    }
    return r;
  }(e);
  i.exports && (i.exports = t), typeof Yi < "u" && (Yi.Prism = t), t.languages.markup = {
    comment: {
      pattern: /<!--(?:(?!<!--)[\s\S])*?-->/,
      greedy: !0
    },
    prolog: {
      pattern: /<\?[\s\S]+?\?>/,
      greedy: !0
    },
    doctype: {
      // https://www.w3.org/TR/xml/#NT-doctypedecl
      pattern: /<!DOCTYPE(?:[^>"'[\]]|"[^"]*"|'[^']*')+(?:\[(?:[^<"'\]]|"[^"]*"|'[^']*'|<(?!!--)|<!--(?:[^-]|-(?!->))*-->)*\]\s*)?>/i,
      greedy: !0,
      inside: {
        "internal-subset": {
          pattern: /(^[^\[]*\[)[\s\S]+(?=\]>$)/,
          lookbehind: !0,
          greedy: !0,
          inside: null
          // see below
        },
        string: {
          pattern: /"[^"]*"|'[^']*'/,
          greedy: !0
        },
        punctuation: /^<!|>$|[[\]]/,
        "doctype-tag": /^DOCTYPE/i,
        name: /[^\s<>'"]+/
      }
    },
    cdata: {
      pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
      greedy: !0
    },
    tag: {
      pattern: /<\/?(?!\d)[^\s>\/=$<%]+(?:\s(?:\s*[^\s>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))|(?=[\s/>])))+)?\s*\/?>/,
      greedy: !0,
      inside: {
        tag: {
          pattern: /^<\/?[^\s>\/]+/,
          inside: {
            punctuation: /^<\/?/,
            namespace: /^[^\s>\/:]+:/
          }
        },
        "special-attr": [],
        "attr-value": {
          pattern: /=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+)/,
          inside: {
            punctuation: [
              {
                pattern: /^=/,
                alias: "attr-equals"
              },
              {
                pattern: /^(\s*)["']|["']$/,
                lookbehind: !0
              }
            ]
          }
        },
        punctuation: /\/?>/,
        "attr-name": {
          pattern: /[^\s>\/]+/,
          inside: {
            namespace: /^[^\s>\/:]+:/
          }
        }
      }
    },
    entity: [
      {
        pattern: /&[\da-z]{1,8};/i,
        alias: "named-entity"
      },
      /&#x?[\da-f]{1,8};/i
    ]
  }, t.languages.markup.tag.inside["attr-value"].inside.entity = t.languages.markup.entity, t.languages.markup.doctype.inside["internal-subset"].inside = t.languages.markup, t.hooks.add("wrap", function(n) {
    n.type === "entity" && (n.attributes.title = n.content.replace(/&amp;/, "&"));
  }), Object.defineProperty(t.languages.markup.tag, "addInlined", {
    /**
     * Adds an inlined language to markup.
     *
     * An example of an inlined language is CSS with `<style>` tags.
     *
     * @param {string} tagName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addInlined('style', 'css');
     */
    value: function(a, o) {
      var l = {};
      l["language-" + o] = {
        pattern: /(^<!\[CDATA\[)[\s\S]+?(?=\]\]>$)/i,
        lookbehind: !0,
        inside: t.languages[o]
      }, l.cdata = /^<!\[CDATA\[|\]\]>$/i;
      var r = {
        "included-cdata": {
          pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
          inside: l
        }
      };
      r["language-" + o] = {
        pattern: /[\s\S]+/,
        inside: t.languages[o]
      };
      var s = {};
      s[a] = {
        pattern: RegExp(/(<__[^>]*>)(?:<!\[CDATA\[(?:[^\]]|\](?!\]>))*\]\]>|(?!<!\[CDATA\[)[\s\S])*?(?=<\/__>)/.source.replace(/__/g, function() {
          return a;
        }), "i"),
        lookbehind: !0,
        greedy: !0,
        inside: r
      }, t.languages.insertBefore("markup", "cdata", s);
    }
  }), Object.defineProperty(t.languages.markup.tag, "addAttribute", {
    /**
     * Adds an pattern to highlight languages embedded in HTML attributes.
     *
     * An example of an inlined language is CSS with `style` attributes.
     *
     * @param {string} attrName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addAttribute('style', 'css');
     */
    value: function(n, a) {
      t.languages.markup.tag.inside["special-attr"].push({
        pattern: RegExp(
          /(^|["'\s])/.source + "(?:" + n + ")" + /\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))/.source,
          "i"
        ),
        lookbehind: !0,
        inside: {
          "attr-name": /^[^\s=]+/,
          "attr-value": {
            pattern: /=[\s\S]+/,
            inside: {
              value: {
                pattern: /(^=\s*(["']|(?!["'])))\S[\s\S]*(?=\2$)/,
                lookbehind: !0,
                alias: [a, "language-" + a],
                inside: t.languages[a]
              },
              punctuation: [
                {
                  pattern: /^=/,
                  alias: "attr-equals"
                },
                /"|'/
              ]
            }
          }
        }
      });
    }
  }), t.languages.html = t.languages.markup, t.languages.mathml = t.languages.markup, t.languages.svg = t.languages.markup, t.languages.xml = t.languages.extend("markup", {}), t.languages.ssml = t.languages.xml, t.languages.atom = t.languages.xml, t.languages.rss = t.languages.xml, function(n) {
    var a = /(?:"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n])*')/;
    n.languages.css = {
      comment: /\/\*[\s\S]*?\*\//,
      atrule: {
        pattern: RegExp("@[\\w-](?:" + /[^;{\s"']|\s+(?!\s)/.source + "|" + a.source + ")*?" + /(?:;|(?=\s*\{))/.source),
        inside: {
          rule: /^@[\w-]+/,
          "selector-function-argument": {
            pattern: /(\bselector\s*\(\s*(?![\s)]))(?:[^()\s]|\s+(?![\s)])|\((?:[^()]|\([^()]*\))*\))+(?=\s*\))/,
            lookbehind: !0,
            alias: "selector"
          },
          keyword: {
            pattern: /(^|[^\w-])(?:and|not|only|or)(?![\w-])/,
            lookbehind: !0
          }
          // See rest below
        }
      },
      url: {
        // https://drafts.csswg.org/css-values-3/#urls
        pattern: RegExp("\\burl\\((?:" + a.source + "|" + /(?:[^\\\r\n()"']|\\[\s\S])*/.source + ")\\)", "i"),
        greedy: !0,
        inside: {
          function: /^url/i,
          punctuation: /^\(|\)$/,
          string: {
            pattern: RegExp("^" + a.source + "$"),
            alias: "url"
          }
        }
      },
      selector: {
        pattern: RegExp(`(^|[{}\\s])[^{}\\s](?:[^{};"'\\s]|\\s+(?![\\s{])|` + a.source + ")*(?=\\s*\\{)"),
        lookbehind: !0
      },
      string: {
        pattern: a,
        greedy: !0
      },
      property: {
        pattern: /(^|[^-\w\xA0-\uFFFF])(?!\s)[-_a-z\xA0-\uFFFF](?:(?!\s)[-\w\xA0-\uFFFF])*(?=\s*:)/i,
        lookbehind: !0
      },
      important: /!important\b/i,
      function: {
        pattern: /(^|[^-a-z0-9])[-a-z0-9]+(?=\()/i,
        lookbehind: !0
      },
      punctuation: /[(){};:,]/
    }, n.languages.css.atrule.inside.rest = n.languages.css;
    var o = n.languages.markup;
    o && (o.tag.addInlined("style", "css"), o.tag.addAttribute("style", "css"));
  }(t), t.languages.clike = {
    comment: [
      {
        pattern: /(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,
        lookbehind: !0,
        greedy: !0
      },
      {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0,
        greedy: !0
      }
    ],
    string: {
      pattern: /(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,
      greedy: !0
    },
    "class-name": {
      pattern: /(\b(?:class|extends|implements|instanceof|interface|new|trait)\s+|\bcatch\s+\()[\w.\\]+/i,
      lookbehind: !0,
      inside: {
        punctuation: /[.\\]/
      }
    },
    keyword: /\b(?:break|catch|continue|do|else|finally|for|function|if|in|instanceof|new|null|return|throw|try|while)\b/,
    boolean: /\b(?:false|true)\b/,
    function: /\b\w+(?=\()/,
    number: /\b0x[\da-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,
    operator: /[<>]=?|[!=]=?=?|--?|\+\+?|&&?|\|\|?|[?*/~^%]/,
    punctuation: /[{}[\];(),.:]/
  }, t.languages.javascript = t.languages.extend("clike", {
    "class-name": [
      t.languages.clike["class-name"],
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$A-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\.(?:constructor|prototype))/,
        lookbehind: !0
      }
    ],
    keyword: [
      {
        pattern: /((?:^|\})\s*)catch\b/,
        lookbehind: !0
      },
      {
        pattern: /(^|[^.]|\.\.\.\s*)\b(?:as|assert(?=\s*\{)|async(?=\s*(?:function\b|\(|[$\w\xA0-\uFFFF]|$))|await|break|case|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally(?=\s*(?:\{|$))|for|from(?=\s*(?:['"]|$))|function|(?:get|set)(?=\s*(?:[#\[$\w\xA0-\uFFFF]|$))|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)\b/,
        lookbehind: !0
      }
    ],
    // Allow for all non-ASCII characters (See http://stackoverflow.com/a/2008444)
    function: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*(?:\.\s*(?:apply|bind|call)\s*)?\()/,
    number: {
      pattern: RegExp(
        /(^|[^\w$])/.source + "(?:" + // constant
        (/NaN|Infinity/.source + "|" + // binary integer
        /0[bB][01]+(?:_[01]+)*n?/.source + "|" + // octal integer
        /0[oO][0-7]+(?:_[0-7]+)*n?/.source + "|" + // hexadecimal integer
        /0[xX][\dA-Fa-f]+(?:_[\dA-Fa-f]+)*n?/.source + "|" + // decimal bigint
        /\d+(?:_\d+)*n/.source + "|" + // decimal number (integer or float) but no bigint
        /(?:\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\.\d+(?:_\d+)*)(?:[Ee][+-]?\d+(?:_\d+)*)?/.source) + ")" + /(?![\w$])/.source
      ),
      lookbehind: !0
    },
    operator: /--|\+\+|\*\*=?|=>|&&=?|\|\|=?|[!=]==|<<=?|>>>?=?|[-+*/%&|^!=<>]=?|\.{3}|\?\?=?|\?\.?|[~:]/
  }), t.languages.javascript["class-name"][0].pattern = /(\b(?:class|extends|implements|instanceof|interface|new)\s+)[\w.\\]+/, t.languages.insertBefore("javascript", "keyword", {
    regex: {
      pattern: RegExp(
        // lookbehind
        // eslint-disable-next-line regexp/no-dupe-characters-character-class
        /((?:^|[^$\w\xA0-\uFFFF."'\])\s]|\b(?:return|yield))\s*)/.source + // Regex pattern:
        // There are 2 regex patterns here. The RegExp set notation proposal added support for nested character
        // classes if the `v` flag is present. Unfortunately, nested CCs are both context-free and incompatible
        // with the only syntax, so we have to define 2 different regex patterns.
        /\//.source + "(?:" + /(?:\[(?:[^\]\\\r\n]|\\.)*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}/.source + "|" + // `v` flag syntax. This supports 3 levels of nested character classes.
        /(?:\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.)*\])*\])*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}v[dgimyus]{0,7}/.source + ")" + // lookahead
        /(?=(?:\s|\/\*(?:[^*]|\*(?!\/))*\*\/)*(?:$|[\r\n,.;:})\]]|\/\/))/.source
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        "regex-source": {
          pattern: /^(\/)[\s\S]+(?=\/[a-z]*$)/,
          lookbehind: !0,
          alias: "language-regex",
          inside: t.languages.regex
        },
        "regex-delimiter": /^\/|\/$/,
        "regex-flags": /^[a-z]+$/
      }
    },
    // This must be declared before keyword because we use "function" inside the look-forward
    "function-variable": {
      pattern: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*[=:]\s*(?:async\s*)?(?:\bfunction\b|(?:\((?:[^()]|\([^()]*\))*\)|(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)\s*=>))/,
      alias: "function"
    },
    parameter: [
      {
        pattern: /(function(?:\s+(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)?\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\))/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$a-z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*=>)/i,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*=>)/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /((?:\b|\s|^)(?!(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)(?![$\w\xA0-\uFFFF]))(?:(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*\s*)\(\s*|\]\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*\{)/,
        lookbehind: !0,
        inside: t.languages.javascript
      }
    ],
    constant: /\b[A-Z](?:[A-Z_]|\dx?)*\b/
  }), t.languages.insertBefore("javascript", "string", {
    hashbang: {
      pattern: /^#!.*/,
      greedy: !0,
      alias: "comment"
    },
    "template-string": {
      pattern: /`(?:\\[\s\S]|\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}|(?!\$\{)[^\\`])*`/,
      greedy: !0,
      inside: {
        "template-punctuation": {
          pattern: /^`|`$/,
          alias: "string"
        },
        interpolation: {
          pattern: /((?:^|[^\\])(?:\\{2})*)\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}/,
          lookbehind: !0,
          inside: {
            "interpolation-punctuation": {
              pattern: /^\$\{|\}$/,
              alias: "punctuation"
            },
            rest: t.languages.javascript
          }
        },
        string: /[\s\S]+/
      }
    },
    "string-property": {
      pattern: /((?:^|[,{])[ \t]*)(["'])(?:\\(?:\r\n|[\s\S])|(?!\2)[^\\\r\n])*\2(?=\s*:)/m,
      lookbehind: !0,
      greedy: !0,
      alias: "property"
    }
  }), t.languages.insertBefore("javascript", "operator", {
    "literal-property": {
      pattern: /((?:^|[,{])[ \t]*)(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*:)/m,
      lookbehind: !0,
      alias: "property"
    }
  }), t.languages.markup && (t.languages.markup.tag.addInlined("script", "javascript"), t.languages.markup.tag.addAttribute(
    /on(?:abort|blur|change|click|composition(?:end|start|update)|dblclick|error|focus(?:in|out)?|key(?:down|up)|load|mouse(?:down|enter|leave|move|out|over|up)|reset|resize|scroll|select|slotchange|submit|unload|wheel)/.source,
    "javascript"
  )), t.languages.js = t.languages.javascript, function() {
    if (typeof t > "u" || typeof document > "u")
      return;
    Element.prototype.matches || (Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector);
    var n = "Loading…", a = function(w, y) {
      return "✖ Error " + w + " while fetching file: " + y;
    }, o = "✖ Error: File does not exist or is empty", l = {
      js: "javascript",
      py: "python",
      rb: "ruby",
      ps1: "powershell",
      psm1: "powershell",
      sh: "bash",
      bat: "batch",
      h: "c",
      tex: "latex"
    }, r = "data-src-status", s = "loading", u = "loaded", c = "failed", g = "pre[data-src]:not([" + r + '="' + u + '"]):not([' + r + '="' + s + '"])';
    function _(w, y, x) {
      var p = new XMLHttpRequest();
      p.open("GET", w, !0), p.onreadystatechange = function() {
        p.readyState == 4 && (p.status < 400 && p.responseText ? y(p.responseText) : p.status >= 400 ? x(a(p.status, p.statusText)) : x(o));
      }, p.send(null);
    }
    function m(w) {
      var y = /^\s*(\d+)\s*(?:(,)\s*(?:(\d+)\s*)?)?$/.exec(w || "");
      if (y) {
        var x = Number(y[1]), p = y[2], d = y[3];
        return p ? d ? [x, Number(d)] : [x, void 0] : [x, x];
      }
    }
    t.hooks.add("before-highlightall", function(w) {
      w.selector += ", " + g;
    }), t.hooks.add("before-sanity-check", function(w) {
      var y = (
        /** @type {HTMLPreElement} */
        w.element
      );
      if (y.matches(g)) {
        w.code = "", y.setAttribute(r, s);
        var x = y.appendChild(document.createElement("CODE"));
        x.textContent = n;
        var p = y.getAttribute("data-src"), d = w.language;
        if (d === "none") {
          var h = (/\.(\w+)$/.exec(p) || [, "none"])[1];
          d = l[h] || h;
        }
        t.util.setLanguage(x, d), t.util.setLanguage(y, d);
        var D = t.plugins.autoloader;
        D && D.loadLanguages(d), _(
          p,
          function(F) {
            y.setAttribute(r, u);
            var S = m(y.getAttribute("data-range"));
            if (S) {
              var O = F.split(/\r\n?|\n/g), k = S[0], A = S[1] == null ? O.length : S[1];
              k < 0 && (k += O.length), k = Math.max(0, Math.min(k - 1, O.length)), A < 0 && (A += O.length), A = Math.max(0, Math.min(A, O.length)), F = O.slice(k, A).join(`
`), y.hasAttribute("data-start") || y.setAttribute("data-start", String(k + 1));
            }
            x.textContent = F, t.highlightElement(x);
          },
          function(F) {
            y.setAttribute(r, c), x.textContent = F;
          }
        );
      }
    }), t.plugins.fileHighlight = {
      /**
       * Executes the File Highlight plugin for all matching `pre` elements under the given container.
       *
       * Note: Elements which are already loaded or currently loading will not be touched by this method.
       *
       * @param {ParentNode} [container=document]
       */
      highlight: function(y) {
        for (var x = (y || document).querySelectorAll(g), p = 0, d; d = x[p++]; )
          t.highlightElement(d);
      }
    };
    var b = !1;
    t.fileHighlight = function() {
      b || (console.warn("Prism.fileHighlight is deprecated. Use `Prism.plugins.fileHighlight.highlight` instead."), b = !0), t.plugins.fileHighlight.highlight.apply(this, arguments);
    };
  }();
})(Wo);
Prism.languages.python = {
  comment: {
    pattern: /(^|[^\\])#.*/,
    lookbehind: !0,
    greedy: !0
  },
  "string-interpolation": {
    pattern: /(?:f|fr|rf)(?:("""|''')[\s\S]*?\1|("|')(?:\\.|(?!\2)[^\\\r\n])*\2)/i,
    greedy: !0,
    inside: {
      interpolation: {
        // "{" <expression> <optional "!s", "!r", or "!a"> <optional ":" format specifier> "}"
        pattern: /((?:^|[^{])(?:\{\{)*)\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}])+\})+\})+\}/,
        lookbehind: !0,
        inside: {
          "format-spec": {
            pattern: /(:)[^:(){}]+(?=\}$)/,
            lookbehind: !0
          },
          "conversion-option": {
            pattern: /![sra](?=[:}]$)/,
            alias: "punctuation"
          },
          rest: null
        }
      },
      string: /[\s\S]+/
    }
  },
  "triple-quoted-string": {
    pattern: /(?:[rub]|br|rb)?("""|''')[\s\S]*?\1/i,
    greedy: !0,
    alias: "string"
  },
  string: {
    pattern: /(?:[rub]|br|rb)?("|')(?:\\.|(?!\1)[^\\\r\n])*\1/i,
    greedy: !0
  },
  function: {
    pattern: /((?:^|\s)def[ \t]+)[a-zA-Z_]\w*(?=\s*\()/g,
    lookbehind: !0
  },
  "class-name": {
    pattern: /(\bclass\s+)\w+/i,
    lookbehind: !0
  },
  decorator: {
    pattern: /(^[\t ]*)@\w+(?:\.\w+)*/m,
    lookbehind: !0,
    alias: ["annotation", "punctuation"],
    inside: {
      punctuation: /\./
    }
  },
  keyword: /\b(?:_(?=\s*:)|and|as|assert|async|await|break|case|class|continue|def|del|elif|else|except|exec|finally|for|from|global|if|import|in|is|lambda|match|nonlocal|not|or|pass|print|raise|return|try|while|with|yield)\b/,
  builtin: /\b(?:__import__|abs|all|any|apply|ascii|basestring|bin|bool|buffer|bytearray|bytes|callable|chr|classmethod|cmp|coerce|compile|complex|delattr|dict|dir|divmod|enumerate|eval|execfile|file|filter|float|format|frozenset|getattr|globals|hasattr|hash|help|hex|id|input|int|intern|isinstance|issubclass|iter|len|list|locals|long|map|max|memoryview|min|next|object|oct|open|ord|pow|property|range|raw_input|reduce|reload|repr|reversed|round|set|setattr|slice|sorted|staticmethod|str|sum|super|tuple|type|unichr|unicode|vars|xrange|zip)\b/,
  boolean: /\b(?:False|None|True)\b/,
  number: /\b0(?:b(?:_?[01])+|o(?:_?[0-7])+|x(?:_?[a-f0-9])+)\b|(?:\b\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\B\.\d+(?:_\d+)*)(?:e[+-]?\d+(?:_\d+)*)?j?(?!\w)/i,
  operator: /[-+%=]=?|!=|:=|\*\*?=?|\/\/?=?|<[<=>]?|>[=>]?|[&|^~]/,
  punctuation: /[{}[\];(),.:]/
};
Prism.languages.python["string-interpolation"].inside.interpolation.inside.rest = Prism.languages.python;
Prism.languages.py = Prism.languages.python;
(function(i) {
  var e = /\\(?:[^a-z()[\]]|[a-z*]+)/i, t = {
    "equation-command": {
      pattern: e,
      alias: "regex"
    }
  };
  i.languages.latex = {
    comment: /%.*/,
    // the verbatim environment prints whitespace to the document
    cdata: {
      pattern: /(\\begin\{((?:lstlisting|verbatim)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
      lookbehind: !0
    },
    /*
     * equations can be between $$ $$ or $ $ or \( \) or \[ \]
     * (all are multiline)
     */
    equation: [
      {
        pattern: /\$\$(?:\\[\s\S]|[^\\$])+\$\$|\$(?:\\[\s\S]|[^\\$])+\$|\\\([\s\S]*?\\\)|\\\[[\s\S]*?\\\]/,
        inside: t,
        alias: "string"
      },
      {
        pattern: /(\\begin\{((?:align|eqnarray|equation|gather|math|multline)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
        lookbehind: !0,
        inside: t,
        alias: "string"
      }
    ],
    /*
     * arguments which are keywords or references are highlighted
     * as keywords
     */
    keyword: {
      pattern: /(\\(?:begin|cite|documentclass|end|label|ref|usepackage)(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    url: {
      pattern: /(\\url\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    /*
     * section or chapter headlines are highlighted as bold so that
     * they stand out more
     */
    headline: {
      pattern: /(\\(?:chapter|frametitle|paragraph|part|section|subparagraph|subsection|subsubparagraph|subsubsection|subsubsubparagraph)\*?(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0,
      alias: "class-name"
    },
    function: {
      pattern: e,
      alias: "selector"
    },
    punctuation: /[[\]{}&]/
  }, i.languages.tex = i.languages.latex, i.languages.context = i.languages.latex;
})(Prism);
(function(i) {
  var e = "\\b(?:BASH|BASHOPTS|BASH_ALIASES|BASH_ARGC|BASH_ARGV|BASH_CMDS|BASH_COMPLETION_COMPAT_DIR|BASH_LINENO|BASH_REMATCH|BASH_SOURCE|BASH_VERSINFO|BASH_VERSION|COLORTERM|COLUMNS|COMP_WORDBREAKS|DBUS_SESSION_BUS_ADDRESS|DEFAULTS_PATH|DESKTOP_SESSION|DIRSTACK|DISPLAY|EUID|GDMSESSION|GDM_LANG|GNOME_KEYRING_CONTROL|GNOME_KEYRING_PID|GPG_AGENT_INFO|GROUPS|HISTCONTROL|HISTFILE|HISTFILESIZE|HISTSIZE|HOME|HOSTNAME|HOSTTYPE|IFS|INSTANCE|JOB|LANG|LANGUAGE|LC_ADDRESS|LC_ALL|LC_IDENTIFICATION|LC_MEASUREMENT|LC_MONETARY|LC_NAME|LC_NUMERIC|LC_PAPER|LC_TELEPHONE|LC_TIME|LESSCLOSE|LESSOPEN|LINES|LOGNAME|LS_COLORS|MACHTYPE|MAILCHECK|MANDATORY_PATH|NO_AT_BRIDGE|OLDPWD|OPTERR|OPTIND|ORBIT_SOCKETDIR|OSTYPE|PAPERSIZE|PATH|PIPESTATUS|PPID|PS1|PS2|PS3|PS4|PWD|RANDOM|REPLY|SECONDS|SELINUX_INIT|SESSION|SESSIONTYPE|SESSION_MANAGER|SHELL|SHELLOPTS|SHLVL|SSH_AUTH_SOCK|TERM|UID|UPSTART_EVENTS|UPSTART_INSTANCE|UPSTART_JOB|UPSTART_SESSION|USER|WINDOWID|XAUTHORITY|XDG_CONFIG_DIRS|XDG_CURRENT_DESKTOP|XDG_DATA_DIRS|XDG_GREETER_DATA_DIR|XDG_MENU_PREFIX|XDG_RUNTIME_DIR|XDG_SEAT|XDG_SEAT_PATH|XDG_SESSION_DESKTOP|XDG_SESSION_ID|XDG_SESSION_PATH|XDG_SESSION_TYPE|XDG_VTNR|XMODIFIERS)\\b", t = {
    pattern: /(^(["']?)\w+\2)[ \t]+\S.*/,
    lookbehind: !0,
    alias: "punctuation",
    // this looks reasonably well in all themes
    inside: null
    // see below
  }, n = {
    bash: t,
    environment: {
      pattern: RegExp("\\$" + e),
      alias: "constant"
    },
    variable: [
      // [0]: Arithmetic Environment
      {
        pattern: /\$?\(\([\s\S]+?\)\)/,
        greedy: !0,
        inside: {
          // If there is a $ sign at the beginning highlight $(( and )) as variable
          variable: [
            {
              pattern: /(^\$\(\([\s\S]+)\)\)/,
              lookbehind: !0
            },
            /^\$\(\(/
          ],
          number: /\b0x[\dA-Fa-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:[Ee]-?\d+)?/,
          // Operators according to https://www.gnu.org/software/bash/manual/bashref.html#Shell-Arithmetic
          operator: /--|\+\+|\*\*=?|<<=?|>>=?|&&|\|\||[=!+\-*/%<>^&|]=?|[?~:]/,
          // If there is no $ sign at the beginning highlight (( and )) as punctuation
          punctuation: /\(\(?|\)\)?|,|;/
        }
      },
      // [1]: Command Substitution
      {
        pattern: /\$\((?:\([^)]+\)|[^()])+\)|`[^`]+`/,
        greedy: !0,
        inside: {
          variable: /^\$\(|^`|\)$|`$/
        }
      },
      // [2]: Brace expansion
      {
        pattern: /\$\{[^}]+\}/,
        greedy: !0,
        inside: {
          operator: /:[-=?+]?|[!\/]|##?|%%?|\^\^?|,,?/,
          punctuation: /[\[\]]/,
          environment: {
            pattern: RegExp("(\\{)" + e),
            lookbehind: !0,
            alias: "constant"
          }
        }
      },
      /\$(?:\w+|[#?*!@$])/
    ],
    // Escape sequences from echo and printf's manuals, and escaped quotes.
    entity: /\\(?:[abceEfnrtv\\"]|O?[0-7]{1,3}|U[0-9a-fA-F]{8}|u[0-9a-fA-F]{4}|x[0-9a-fA-F]{1,2})/
  };
  i.languages.bash = {
    shebang: {
      pattern: /^#!\s*\/.*/,
      alias: "important"
    },
    comment: {
      pattern: /(^|[^"{\\$])#.*/,
      lookbehind: !0
    },
    "function-name": [
      // a) function foo {
      // b) foo() {
      // c) function foo() {
      // but not “foo {”
      {
        // a) and c)
        pattern: /(\bfunction\s+)[\w-]+(?=(?:\s*\(?:\s*\))?\s*\{)/,
        lookbehind: !0,
        alias: "function"
      },
      {
        // b)
        pattern: /\b[\w-]+(?=\s*\(\s*\)\s*\{)/,
        alias: "function"
      }
    ],
    // Highlight variable names as variables in for and select beginnings.
    "for-or-select": {
      pattern: /(\b(?:for|select)\s+)\w+(?=\s+in\s)/,
      alias: "variable",
      lookbehind: !0
    },
    // Highlight variable names as variables in the left-hand part
    // of assignments (“=” and “+=”).
    "assign-left": {
      pattern: /(^|[\s;|&]|[<>]\()\w+(?:\.\w+)*(?=\+?=)/,
      inside: {
        environment: {
          pattern: RegExp("(^|[\\s;|&]|[<>]\\()" + e),
          lookbehind: !0,
          alias: "constant"
        }
      },
      alias: "variable",
      lookbehind: !0
    },
    // Highlight parameter names as variables
    parameter: {
      pattern: /(^|\s)-{1,2}(?:\w+:[+-]?)?\w+(?:\.\w+)*(?=[=\s]|$)/,
      alias: "variable",
      lookbehind: !0
    },
    string: [
      // Support for Here-documents https://en.wikipedia.org/wiki/Here_document
      {
        pattern: /((?:^|[^<])<<-?\s*)(\w+)\s[\s\S]*?(?:\r?\n|\r)\2/,
        lookbehind: !0,
        greedy: !0,
        inside: n
      },
      // Here-document with quotes around the tag
      // → No expansion (so no “inside”).
      {
        pattern: /((?:^|[^<])<<-?\s*)(["'])(\w+)\2\s[\s\S]*?(?:\r?\n|\r)\3/,
        lookbehind: !0,
        greedy: !0,
        inside: {
          bash: t
        }
      },
      // “Normal” string
      {
        // https://www.gnu.org/software/bash/manual/html_node/Double-Quotes.html
        pattern: /(^|[^\\](?:\\\\)*)"(?:\\[\s\S]|\$\([^)]+\)|\$(?!\()|`[^`]+`|[^"\\`$])*"/,
        lookbehind: !0,
        greedy: !0,
        inside: n
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/Single-Quotes.html
        pattern: /(^|[^$\\])'[^']*'/,
        lookbehind: !0,
        greedy: !0
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/ANSI_002dC-Quoting.html
        pattern: /\$'(?:[^'\\]|\\[\s\S])*'/,
        greedy: !0,
        inside: {
          entity: n.entity
        }
      }
    ],
    environment: {
      pattern: RegExp("\\$?" + e),
      alias: "constant"
    },
    variable: n.variable,
    function: {
      pattern: /(^|[\s;|&]|[<>]\()(?:add|apropos|apt|apt-cache|apt-get|aptitude|aspell|automysqlbackup|awk|basename|bash|bc|bconsole|bg|bzip2|cal|cargo|cat|cfdisk|chgrp|chkconfig|chmod|chown|chroot|cksum|clear|cmp|column|comm|composer|cp|cron|crontab|csplit|curl|cut|date|dc|dd|ddrescue|debootstrap|df|diff|diff3|dig|dir|dircolors|dirname|dirs|dmesg|docker|docker-compose|du|egrep|eject|env|ethtool|expand|expect|expr|fdformat|fdisk|fg|fgrep|file|find|fmt|fold|format|free|fsck|ftp|fuser|gawk|git|gparted|grep|groupadd|groupdel|groupmod|groups|grub-mkconfig|gzip|halt|head|hg|history|host|hostname|htop|iconv|id|ifconfig|ifdown|ifup|import|install|ip|java|jobs|join|kill|killall|less|link|ln|locate|logname|logrotate|look|lpc|lpr|lprint|lprintd|lprintq|lprm|ls|lsof|lynx|make|man|mc|mdadm|mkconfig|mkdir|mke2fs|mkfifo|mkfs|mkisofs|mknod|mkswap|mmv|more|most|mount|mtools|mtr|mutt|mv|nano|nc|netstat|nice|nl|node|nohup|notify-send|npm|nslookup|op|open|parted|passwd|paste|pathchk|ping|pkill|pnpm|podman|podman-compose|popd|pr|printcap|printenv|ps|pushd|pv|quota|quotacheck|quotactl|ram|rar|rcp|reboot|remsync|rename|renice|rev|rm|rmdir|rpm|rsync|scp|screen|sdiff|sed|sendmail|seq|service|sftp|sh|shellcheck|shuf|shutdown|sleep|slocate|sort|split|ssh|stat|strace|su|sudo|sum|suspend|swapon|sync|sysctl|tac|tail|tar|tee|time|timeout|top|touch|tr|traceroute|tsort|tty|umount|uname|unexpand|uniq|units|unrar|unshar|unzip|update-grub|uptime|useradd|userdel|usermod|users|uudecode|uuencode|v|vcpkg|vdir|vi|vim|virsh|vmstat|wait|watch|wc|wget|whereis|which|who|whoami|write|xargs|xdg-open|yarn|yes|zenity|zip|zsh|zypper)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    keyword: {
      pattern: /(^|[\s;|&]|[<>]\()(?:case|do|done|elif|else|esac|fi|for|function|if|in|select|then|until|while)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    // https://www.gnu.org/software/bash/manual/html_node/Shell-Builtin-Commands.html
    builtin: {
      pattern: /(^|[\s;|&]|[<>]\()(?:\.|:|alias|bind|break|builtin|caller|cd|command|continue|declare|echo|enable|eval|exec|exit|export|getopts|hash|help|let|local|logout|mapfile|printf|pwd|read|readarray|readonly|return|set|shift|shopt|source|test|times|trap|type|typeset|ulimit|umask|unalias|unset)(?=$|[)\s;|&])/,
      lookbehind: !0,
      // Alias added to make those easier to distinguish from strings.
      alias: "class-name"
    },
    boolean: {
      pattern: /(^|[\s;|&]|[<>]\()(?:false|true)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    "file-descriptor": {
      pattern: /\B&\d\b/,
      alias: "important"
    },
    operator: {
      // Lots of redirections here, but not just that.
      pattern: /\d?<>|>\||\+=|=[=~]?|!=?|<<[<-]?|[&\d]?>>|\d[<>]&?|[<>][&=]?|&[>&]?|\|[&|]?/,
      inside: {
        "file-descriptor": {
          pattern: /^\d/,
          alias: "important"
        }
      }
    },
    punctuation: /\$?\(\(?|\)\)?|\.\.|[{}[\];\\]/,
    number: {
      pattern: /(^|\s)(?:[1-9]\d*|0)(?:[.,]\d+)?\b/,
      lookbehind: !0
    }
  }, t.inside = i.languages.bash;
  for (var a = [
    "comment",
    "function-name",
    "for-or-select",
    "assign-left",
    "parameter",
    "string",
    "environment",
    "function",
    "keyword",
    "builtin",
    "boolean",
    "file-descriptor",
    "operator",
    "punctuation",
    "number"
  ], o = n.variable[1].inside, l = 0; l < a.length; l++)
    o[a[l]] = i.languages.bash[a[l]];
  i.languages.sh = i.languages.bash, i.languages.shell = i.languages.bash;
})(Prism);
Prism.languages.c = Prism.languages.extend("clike", {
  comment: {
    pattern: /\/\/(?:[^\r\n\\]|\\(?:\r\n?|\n|(?![\r\n])))*|\/\*[\s\S]*?(?:\*\/|$)/,
    greedy: !0
  },
  string: {
    // https://en.cppreference.com/w/c/language/string_literal
    pattern: /"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"/,
    greedy: !0
  },
  "class-name": {
    pattern: /(\b(?:enum|struct)\s+(?:__attribute__\s*\(\([\s\S]*?\)\)\s*)?)\w+|\b[a-z]\w*_t\b/,
    lookbehind: !0
  },
  keyword: /\b(?:_Alignas|_Alignof|_Atomic|_Bool|_Complex|_Generic|_Imaginary|_Noreturn|_Static_assert|_Thread_local|__attribute__|asm|auto|break|case|char|const|continue|default|do|double|else|enum|extern|float|for|goto|if|inline|int|long|register|return|short|signed|sizeof|static|struct|switch|typedef|typeof|union|unsigned|void|volatile|while)\b/,
  function: /\b[a-z_]\w*(?=\s*\()/i,
  number: /(?:\b0x(?:[\da-f]+(?:\.[\da-f]*)?|\.[\da-f]+)(?:p[+-]?\d+)?|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?)[ful]{0,4}/i,
  operator: />>=?|<<=?|->|([-+&|:])\1|[?:~]|[-+*/%&|^!=<>]=?/
});
Prism.languages.insertBefore("c", "string", {
  char: {
    // https://en.cppreference.com/w/c/language/character_constant
    pattern: /'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n]){0,32}'/,
    greedy: !0
  }
});
Prism.languages.insertBefore("c", "string", {
  macro: {
    // allow for multiline macro definitions
    // spaces after the # character compile fine with gcc
    pattern: /(^[\t ]*)#\s*[a-z](?:[^\r\n\\/]|\/(?!\*)|\/\*(?:[^*]|\*(?!\/))*\*\/|\\(?:\r\n|[\s\S]))*/im,
    lookbehind: !0,
    greedy: !0,
    alias: "property",
    inside: {
      string: [
        {
          // highlight the path of the include statement as a string
          pattern: /^(#\s*include\s*)<[^>]+>/,
          lookbehind: !0
        },
        Prism.languages.c.string
      ],
      char: Prism.languages.c.char,
      comment: Prism.languages.c.comment,
      "macro-name": [
        {
          pattern: /(^#\s*define\s+)\w+\b(?!\()/i,
          lookbehind: !0
        },
        {
          pattern: /(^#\s*define\s+)\w+\b(?=\()/i,
          lookbehind: !0,
          alias: "function"
        }
      ],
      // highlight macro directives as keywords
      directive: {
        pattern: /^(#\s*)[a-z]+/,
        lookbehind: !0,
        alias: "keyword"
      },
      "directive-hash": /^#/,
      punctuation: /##|\\(?=[\r\n])/,
      expression: {
        pattern: /\S[\s\S]*/,
        inside: Prism.languages.c
      }
    }
  }
});
Prism.languages.insertBefore("c", "function", {
  // highlight predefined macros as constants
  constant: /\b(?:EOF|NULL|SEEK_CUR|SEEK_END|SEEK_SET|__DATE__|__FILE__|__LINE__|__TIMESTAMP__|__TIME__|__func__|stderr|stdin|stdout)\b/
});
delete Prism.languages.c.boolean;
(function(i) {
  var e = /\b(?:alignas|alignof|asm|auto|bool|break|case|catch|char|char16_t|char32_t|char8_t|class|co_await|co_return|co_yield|compl|concept|const|const_cast|consteval|constexpr|constinit|continue|decltype|default|delete|do|double|dynamic_cast|else|enum|explicit|export|extern|final|float|for|friend|goto|if|import|inline|int|int16_t|int32_t|int64_t|int8_t|long|module|mutable|namespace|new|noexcept|nullptr|operator|override|private|protected|public|register|reinterpret_cast|requires|return|short|signed|sizeof|static|static_assert|static_cast|struct|switch|template|this|thread_local|throw|try|typedef|typeid|typename|uint16_t|uint32_t|uint64_t|uint8_t|union|unsigned|using|virtual|void|volatile|wchar_t|while)\b/, t = /\b(?!<keyword>)\w+(?:\s*\.\s*\w+)*\b/.source.replace(/<keyword>/g, function() {
    return e.source;
  });
  i.languages.cpp = i.languages.extend("c", {
    "class-name": [
      {
        pattern: RegExp(/(\b(?:class|concept|enum|struct|typename)\s+)(?!<keyword>)\w+/.source.replace(/<keyword>/g, function() {
          return e.source;
        })),
        lookbehind: !0
      },
      // This is intended to capture the class name of method implementations like:
      //   void foo::bar() const {}
      // However! The `foo` in the above example could also be a namespace, so we only capture the class name if
      // it starts with an uppercase letter. This approximation should give decent results.
      /\b[A-Z]\w*(?=\s*::\s*\w+\s*\()/,
      // This will capture the class name before destructors like:
      //   Foo::~Foo() {}
      /\b[A-Z_]\w*(?=\s*::\s*~\w+\s*\()/i,
      // This also intends to capture the class name of method implementations but here the class has template
      // parameters, so it can't be a namespace (until C++ adds generic namespaces).
      /\b\w+(?=\s*<(?:[^<>]|<(?:[^<>]|<[^<>]*>)*>)*>\s*::\s*\w+\s*\()/
    ],
    keyword: e,
    number: {
      pattern: /(?:\b0b[01']+|\b0x(?:[\da-f']+(?:\.[\da-f']*)?|\.[\da-f']+)(?:p[+-]?[\d']+)?|(?:\b[\d']+(?:\.[\d']*)?|\B\.[\d']+)(?:e[+-]?[\d']+)?)[ful]{0,4}/i,
      greedy: !0
    },
    operator: />>=?|<<=?|->|--|\+\+|&&|\|\||[?:~]|<=>|[-+*/%&|^!=<>]=?|\b(?:and|and_eq|bitand|bitor|not|not_eq|or|or_eq|xor|xor_eq)\b/,
    boolean: /\b(?:false|true)\b/
  }), i.languages.insertBefore("cpp", "string", {
    module: {
      // https://en.cppreference.com/w/cpp/language/modules
      pattern: RegExp(
        /(\b(?:import|module)\s+)/.source + "(?:" + // header-name
        /"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|<[^<>\r\n]*>/.source + "|" + // module name or partition or both
        /<mod-name>(?:\s*:\s*<mod-name>)?|:\s*<mod-name>/.source.replace(/<mod-name>/g, function() {
          return t;
        }) + ")"
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        string: /^[<"][\s\S]+/,
        operator: /:/,
        punctuation: /\./
      }
    },
    "raw-string": {
      pattern: /R"([^()\\ ]{0,16})\([\s\S]*?\)\1"/,
      alias: "string",
      greedy: !0
    }
  }), i.languages.insertBefore("cpp", "keyword", {
    "generic-function": {
      pattern: /\b(?!operator\b)[a-z_]\w*\s*<(?:[^<>]|<[^<>]*>)*>(?=\s*\()/i,
      inside: {
        function: /^\w+/,
        generic: {
          pattern: /<[\s\S]+/,
          alias: "class-name",
          inside: i.languages.cpp
        }
      }
    }
  }), i.languages.insertBefore("cpp", "operator", {
    "double-colon": {
      pattern: /::/,
      alias: "punctuation"
    }
  }), i.languages.insertBefore("cpp", "class-name", {
    // the base clause is an optional list of parent classes
    // https://en.cppreference.com/w/cpp/language/class
    "base-clause": {
      pattern: /(\b(?:class|struct)\s+\w+\s*:\s*)[^;{}"'\s]+(?:\s+[^;{}"'\s]+)*(?=\s*[;{])/,
      lookbehind: !0,
      greedy: !0,
      inside: i.languages.extend("cpp", {})
    }
  }), i.languages.insertBefore("inside", "double-colon", {
    // All untokenized words that are not namespaces should be class names
    "class-name": /\b[a-z_]\w*\b(?!\s*::)/i
  }, i.languages.cpp["base-clause"]);
})(Prism);
Prism.languages.json = {
  property: {
    pattern: /(^|[^\\])"(?:\\.|[^\\"\r\n])*"(?=\s*:)/,
    lookbehind: !0,
    greedy: !0
  },
  string: {
    pattern: /(^|[^\\])"(?:\\.|[^\\"\r\n])*"(?!\s*:)/,
    lookbehind: !0,
    greedy: !0
  },
  comment: {
    pattern: /\/\/.*|\/\*[\s\S]*?(?:\*\/|$)/,
    greedy: !0
  },
  number: /-?\b\d+(?:\.\d+)?(?:e[+-]?\d+)?\b/i,
  punctuation: /[{}[\],]/,
  operator: /:/,
  boolean: /\b(?:false|true)\b/,
  null: {
    pattern: /\bnull\b/,
    alias: "keyword"
  }
};
Prism.languages.webmanifest = Prism.languages.json;
Prism.languages.sql = {
  comment: {
    pattern: /(^|[^\\])(?:\/\*[\s\S]*?\*\/|(?:--|\/\/|#).*)/,
    lookbehind: !0
  },
  variable: [
    {
      pattern: /@(["'`])(?:\\[\s\S]|(?!\1)[^\\])+\1/,
      greedy: !0
    },
    /@[\w.$]+/
  ],
  string: {
    pattern: /(^|[^@\\])("|')(?:\\[\s\S]|(?!\2)[^\\]|\2\2)*\2/,
    greedy: !0,
    lookbehind: !0
  },
  identifier: {
    pattern: /(^|[^@\\])`(?:\\[\s\S]|[^`\\]|``)*`/,
    greedy: !0,
    lookbehind: !0,
    inside: {
      punctuation: /^`|`$/
    }
  },
  function: /\b(?:AVG|COUNT|FIRST|FORMAT|LAST|LCASE|LEN|MAX|MID|MIN|MOD|NOW|ROUND|SUM|UCASE)(?=\s*\()/i,
  // Should we highlight user defined functions too?
  keyword: /\b(?:ACTION|ADD|AFTER|ALGORITHM|ALL|ALTER|ANALYZE|ANY|APPLY|AS|ASC|AUTHORIZATION|AUTO_INCREMENT|BACKUP|BDB|BEGIN|BERKELEYDB|BIGINT|BINARY|BIT|BLOB|BOOL|BOOLEAN|BREAK|BROWSE|BTREE|BULK|BY|CALL|CASCADED?|CASE|CHAIN|CHAR(?:ACTER|SET)?|CHECK(?:POINT)?|CLOSE|CLUSTERED|COALESCE|COLLATE|COLUMNS?|COMMENT|COMMIT(?:TED)?|COMPUTE|CONNECT|CONSISTENT|CONSTRAINT|CONTAINS(?:TABLE)?|CONTINUE|CONVERT|CREATE|CROSS|CURRENT(?:_DATE|_TIME|_TIMESTAMP|_USER)?|CURSOR|CYCLE|DATA(?:BASES?)?|DATE(?:TIME)?|DAY|DBCC|DEALLOCATE|DEC|DECIMAL|DECLARE|DEFAULT|DEFINER|DELAYED|DELETE|DELIMITERS?|DENY|DESC|DESCRIBE|DETERMINISTIC|DISABLE|DISCARD|DISK|DISTINCT|DISTINCTROW|DISTRIBUTED|DO|DOUBLE|DROP|DUMMY|DUMP(?:FILE)?|DUPLICATE|ELSE(?:IF)?|ENABLE|ENCLOSED|END|ENGINE|ENUM|ERRLVL|ERRORS|ESCAPED?|EXCEPT|EXEC(?:UTE)?|EXISTS|EXIT|EXPLAIN|EXTENDED|FETCH|FIELDS|FILE|FILLFACTOR|FIRST|FIXED|FLOAT|FOLLOWING|FOR(?: EACH ROW)?|FORCE|FOREIGN|FREETEXT(?:TABLE)?|FROM|FULL|FUNCTION|GEOMETRY(?:COLLECTION)?|GLOBAL|GOTO|GRANT|GROUP|HANDLER|HASH|HAVING|HOLDLOCK|HOUR|IDENTITY(?:COL|_INSERT)?|IF|IGNORE|IMPORT|INDEX|INFILE|INNER|INNODB|INOUT|INSERT|INT|INTEGER|INTERSECT|INTERVAL|INTO|INVOKER|ISOLATION|ITERATE|JOIN|KEYS?|KILL|LANGUAGE|LAST|LEAVE|LEFT|LEVEL|LIMIT|LINENO|LINES|LINESTRING|LOAD|LOCAL|LOCK|LONG(?:BLOB|TEXT)|LOOP|MATCH(?:ED)?|MEDIUM(?:BLOB|INT|TEXT)|MERGE|MIDDLEINT|MINUTE|MODE|MODIFIES|MODIFY|MONTH|MULTI(?:LINESTRING|POINT|POLYGON)|NATIONAL|NATURAL|NCHAR|NEXT|NO|NONCLUSTERED|NULLIF|NUMERIC|OFF?|OFFSETS?|ON|OPEN(?:DATASOURCE|QUERY|ROWSET)?|OPTIMIZE|OPTION(?:ALLY)?|ORDER|OUT(?:ER|FILE)?|OVER|PARTIAL|PARTITION|PERCENT|PIVOT|PLAN|POINT|POLYGON|PRECEDING|PRECISION|PREPARE|PREV|PRIMARY|PRINT|PRIVILEGES|PROC(?:EDURE)?|PUBLIC|PURGE|QUICK|RAISERROR|READS?|REAL|RECONFIGURE|REFERENCES|RELEASE|RENAME|REPEAT(?:ABLE)?|REPLACE|REPLICATION|REQUIRE|RESIGNAL|RESTORE|RESTRICT|RETURN(?:ING|S)?|REVOKE|RIGHT|ROLLBACK|ROUTINE|ROW(?:COUNT|GUIDCOL|S)?|RTREE|RULE|SAVE(?:POINT)?|SCHEMA|SECOND|SELECT|SERIAL(?:IZABLE)?|SESSION(?:_USER)?|SET(?:USER)?|SHARE|SHOW|SHUTDOWN|SIMPLE|SMALLINT|SNAPSHOT|SOME|SONAME|SQL|START(?:ING)?|STATISTICS|STATUS|STRIPED|SYSTEM_USER|TABLES?|TABLESPACE|TEMP(?:ORARY|TABLE)?|TERMINATED|TEXT(?:SIZE)?|THEN|TIME(?:STAMP)?|TINY(?:BLOB|INT|TEXT)|TOP?|TRAN(?:SACTIONS?)?|TRIGGER|TRUNCATE|TSEQUAL|TYPES?|UNBOUNDED|UNCOMMITTED|UNDEFINED|UNION|UNIQUE|UNLOCK|UNPIVOT|UNSIGNED|UPDATE(?:TEXT)?|USAGE|USE|USER|USING|VALUES?|VAR(?:BINARY|CHAR|CHARACTER|YING)|VIEW|WAITFOR|WARNINGS|WHEN|WHERE|WHILE|WITH(?: ROLLUP|IN)?|WORK|WRITE(?:TEXT)?|YEAR)\b/i,
  boolean: /\b(?:FALSE|NULL|TRUE)\b/i,
  number: /\b0x[\da-f]+\b|\b\d+(?:\.\d*)?|\B\.\d+\b/i,
  operator: /[-+*\/=%^~]|&&?|\|\|?|!=?|<(?:=>?|<|>)?|>[>=]?|\b(?:AND|BETWEEN|DIV|ILIKE|IN|IS|LIKE|NOT|OR|REGEXP|RLIKE|SOUNDS LIKE|XOR)\b/i,
  punctuation: /[;[\]()`,.]/
};
(function(i) {
  var e = /\b(?:abstract|assert|boolean|break|byte|case|catch|char|class|const|continue|default|do|double|else|enum|exports|extends|final|finally|float|for|goto|if|implements|import|instanceof|int|interface|long|module|native|new|non-sealed|null|open|opens|package|permits|private|protected|provides|public|record(?!\s*[(){}[\]<>=%~.:,;?+\-*/&|^])|requires|return|sealed|short|static|strictfp|super|switch|synchronized|this|throw|throws|to|transient|transitive|try|uses|var|void|volatile|while|with|yield)\b/, t = /(?:[a-z]\w*\s*\.\s*)*(?:[A-Z]\w*\s*\.\s*)*/.source, n = {
    pattern: RegExp(/(^|[^\w.])/.source + t + /[A-Z](?:[\d_A-Z]*[a-z]\w*)?\b/.source),
    lookbehind: !0,
    inside: {
      namespace: {
        pattern: /^[a-z]\w*(?:\s*\.\s*[a-z]\w*)*(?:\s*\.)?/,
        inside: {
          punctuation: /\./
        }
      },
      punctuation: /\./
    }
  };
  i.languages.java = i.languages.extend("clike", {
    string: {
      pattern: /(^|[^\\])"(?:\\.|[^"\\\r\n])*"/,
      lookbehind: !0,
      greedy: !0
    },
    "class-name": [
      n,
      {
        // variables, parameters, and constructor references
        // this to support class names (or generic parameters) which do not contain a lower case letter (also works for methods)
        pattern: RegExp(/(^|[^\w.])/.source + t + /[A-Z]\w*(?=\s+\w+\s*[;,=()]|\s*(?:\[[\s,]*\]\s*)?::\s*new\b)/.source),
        lookbehind: !0,
        inside: n.inside
      },
      {
        // class names based on keyword
        // this to support class names (or generic parameters) which do not contain a lower case letter (also works for methods)
        pattern: RegExp(/(\b(?:class|enum|extends|implements|instanceof|interface|new|record|throws)\s+)/.source + t + /[A-Z]\w*\b/.source),
        lookbehind: !0,
        inside: n.inside
      }
    ],
    keyword: e,
    function: [
      i.languages.clike.function,
      {
        pattern: /(::\s*)[a-z_]\w*/,
        lookbehind: !0
      }
    ],
    number: /\b0b[01][01_]*L?\b|\b0x(?:\.[\da-f_p+-]+|[\da-f_]+(?:\.[\da-f_p+-]+)?)\b|(?:\b\d[\d_]*(?:\.[\d_]*)?|\B\.\d[\d_]*)(?:e[+-]?\d[\d_]*)?[dfl]?/i,
    operator: {
      pattern: /(^|[^.])(?:<<=?|>>>?=?|->|--|\+\+|&&|\|\||::|[?:~]|[-+*/%&|^!=<>]=?)/m,
      lookbehind: !0
    },
    constant: /\b[A-Z][A-Z_\d]+\b/
  }), i.languages.insertBefore("java", "string", {
    "triple-quoted-string": {
      // http://openjdk.java.net/jeps/355#Description
      pattern: /"""[ \t]*[\r\n](?:(?:"|"")?(?:\\.|[^"\\]))*"""/,
      greedy: !0,
      alias: "string"
    },
    char: {
      pattern: /'(?:\\.|[^'\\\r\n]){1,6}'/,
      greedy: !0
    }
  }), i.languages.insertBefore("java", "class-name", {
    annotation: {
      pattern: /(^|[^.])@\w+(?:\s*\.\s*\w+)*/,
      lookbehind: !0,
      alias: "punctuation"
    },
    generics: {
      pattern: /<(?:[\w\s,.?]|&(?!&)|<(?:[\w\s,.?]|&(?!&)|<(?:[\w\s,.?]|&(?!&)|<(?:[\w\s,.?]|&(?!&))*>)*>)*>)*>/,
      inside: {
        "class-name": n,
        keyword: e,
        punctuation: /[<>(),.:]/,
        operator: /[?&|]/
      }
    },
    import: [
      {
        pattern: RegExp(/(\bimport\s+)/.source + t + /(?:[A-Z]\w*|\*)(?=\s*;)/.source),
        lookbehind: !0,
        inside: {
          namespace: n.inside.namespace,
          punctuation: /\./,
          operator: /\*/,
          "class-name": /\w+/
        }
      },
      {
        pattern: RegExp(/(\bimport\s+static\s+)/.source + t + /(?:\w+|\*)(?=\s*;)/.source),
        lookbehind: !0,
        alias: "static",
        inside: {
          namespace: n.inside.namespace,
          static: /\b\w+$/,
          punctuation: /\./,
          operator: /\*/,
          "class-name": /\w+/
        }
      }
    ],
    namespace: {
      pattern: RegExp(
        /(\b(?:exports|import(?:\s+static)?|module|open|opens|package|provides|requires|to|transitive|uses|with)\s+)(?!<keyword>)[a-z]\w*(?:\.[a-z]\w*)*\.?/.source.replace(/<keyword>/g, function() {
          return e.source;
        })
      ),
      lookbehind: !0,
      inside: {
        punctuation: /\./
      }
    }
  });
})(Prism);
Prism.languages.go = Prism.languages.extend("clike", {
  string: {
    pattern: /(^|[^\\])"(?:\\.|[^"\\\r\n])*"|`[^`]*`/,
    lookbehind: !0,
    greedy: !0
  },
  keyword: /\b(?:break|case|chan|const|continue|default|defer|else|fallthrough|for|func|go(?:to)?|if|import|interface|map|package|range|return|select|struct|switch|type|var)\b/,
  boolean: /\b(?:_|false|iota|nil|true)\b/,
  number: [
    // binary and octal integers
    /\b0(?:b[01_]+|o[0-7_]+)i?\b/i,
    // hexadecimal integers and floats
    /\b0x(?:[a-f\d_]+(?:\.[a-f\d_]*)?|\.[a-f\d_]+)(?:p[+-]?\d+(?:_\d+)*)?i?(?!\w)/i,
    // decimal integers and floats
    /(?:\b\d[\d_]*(?:\.[\d_]*)?|\B\.\d[\d_]*)(?:e[+-]?[\d_]+)?i?(?!\w)/i
  ],
  operator: /[*\/%^!=]=?|\+[=+]?|-[=-]?|\|[=|]?|&(?:=|&|\^=?)?|>(?:>=?|=)?|<(?:<=?|=|-)?|:=|\.\.\./,
  builtin: /\b(?:append|bool|byte|cap|close|complex|complex(?:64|128)|copy|delete|error|float(?:32|64)|u?int(?:8|16|32|64)?|imag|len|make|new|panic|print(?:ln)?|real|recover|rune|string|uintptr)\b/
});
Prism.languages.insertBefore("go", "string", {
  char: {
    pattern: /'(?:\\.|[^'\\\r\n]){0,10}'/,
    greedy: !0
  }
});
delete Prism.languages.go["class-name"];
(function(i) {
  for (var e = /\/\*(?:[^*/]|\*(?!\/)|\/(?!\*)|<self>)*\*\//.source, t = 0; t < 2; t++)
    e = e.replace(/<self>/g, function() {
      return e;
    });
  e = e.replace(/<self>/g, function() {
    return /[^\s\S]/.source;
  }), i.languages.rust = {
    comment: [
      {
        pattern: RegExp(/(^|[^\\])/.source + e),
        lookbehind: !0,
        greedy: !0
      },
      {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0,
        greedy: !0
      }
    ],
    string: {
      pattern: /b?"(?:\\[\s\S]|[^\\"])*"|b?r(#*)"(?:[^"]|"(?!\1))*"\1/,
      greedy: !0
    },
    char: {
      pattern: /b?'(?:\\(?:x[0-7][\da-fA-F]|u\{(?:[\da-fA-F]_*){1,6}\}|.)|[^\\\r\n\t'])'/,
      greedy: !0
    },
    attribute: {
      pattern: /#!?\[(?:[^\[\]"]|"(?:\\[\s\S]|[^\\"])*")*\]/,
      greedy: !0,
      alias: "attr-name",
      inside: {
        string: null
        // see below
      }
    },
    // Closure params should not be confused with bitwise OR |
    "closure-params": {
      pattern: /([=(,:]\s*|\bmove\s*)\|[^|]*\||\|[^|]*\|(?=\s*(?:\{|->))/,
      lookbehind: !0,
      greedy: !0,
      inside: {
        "closure-punctuation": {
          pattern: /^\||\|$/,
          alias: "punctuation"
        },
        rest: null
        // see below
      }
    },
    "lifetime-annotation": {
      pattern: /'\w+/,
      alias: "symbol"
    },
    "fragment-specifier": {
      pattern: /(\$\w+:)[a-z]+/,
      lookbehind: !0,
      alias: "punctuation"
    },
    variable: /\$\w+/,
    "function-definition": {
      pattern: /(\bfn\s+)\w+/,
      lookbehind: !0,
      alias: "function"
    },
    "type-definition": {
      pattern: /(\b(?:enum|struct|trait|type|union)\s+)\w+/,
      lookbehind: !0,
      alias: "class-name"
    },
    "module-declaration": [
      {
        pattern: /(\b(?:crate|mod)\s+)[a-z][a-z_\d]*/,
        lookbehind: !0,
        alias: "namespace"
      },
      {
        pattern: /(\b(?:crate|self|super)\s*)::\s*[a-z][a-z_\d]*\b(?:\s*::(?:\s*[a-z][a-z_\d]*\s*::)*)?/,
        lookbehind: !0,
        alias: "namespace",
        inside: {
          punctuation: /::/
        }
      }
    ],
    keyword: [
      // https://github.com/rust-lang/reference/blob/master/src/keywords.md
      /\b(?:Self|abstract|as|async|await|become|box|break|const|continue|crate|do|dyn|else|enum|extern|final|fn|for|if|impl|in|let|loop|macro|match|mod|move|mut|override|priv|pub|ref|return|self|static|struct|super|trait|try|type|typeof|union|unsafe|unsized|use|virtual|where|while|yield)\b/,
      // primitives and str
      // https://doc.rust-lang.org/stable/rust-by-example/primitives.html
      /\b(?:bool|char|f(?:32|64)|[ui](?:8|16|32|64|128|size)|str)\b/
    ],
    // functions can technically start with an upper-case letter, but this will introduce a lot of false positives
    // and Rust's naming conventions recommend snake_case anyway.
    // https://doc.rust-lang.org/1.0.0/style/style/naming/README.html
    function: /\b[a-z_]\w*(?=\s*(?:::\s*<|\())/,
    macro: {
      pattern: /\b\w+!/,
      alias: "property"
    },
    constant: /\b[A-Z_][A-Z_\d]+\b/,
    "class-name": /\b[A-Z]\w*\b/,
    namespace: {
      pattern: /(?:\b[a-z][a-z_\d]*\s*::\s*)*\b[a-z][a-z_\d]*\s*::(?!\s*<)/,
      inside: {
        punctuation: /::/
      }
    },
    // Hex, oct, bin, dec numbers with visual separators and type suffix
    number: /\b(?:0x[\dA-Fa-f](?:_?[\dA-Fa-f])*|0o[0-7](?:_?[0-7])*|0b[01](?:_?[01])*|(?:(?:\d(?:_?\d)*)?\.)?\d(?:_?\d)*(?:[Ee][+-]?\d+)?)(?:_?(?:f32|f64|[iu](?:8|16|32|64|size)?))?\b/,
    boolean: /\b(?:false|true)\b/,
    punctuation: /->|\.\.=|\.{1,3}|::|[{}[\];(),:]/,
    operator: /[-+*\/%!^]=?|=[=>]?|&[&=]?|\|[|=]?|<<?=?|>>?=?|[@?]/
  }, i.languages.rust["closure-params"].inside.rest = i.languages.rust, i.languages.rust.attribute.inside.string = i.languages.rust.string;
})(Prism);
(function(i) {
  var e = /\/\*[\s\S]*?\*\/|\/\/.*|#(?!\[).*/, t = [
    {
      pattern: /\b(?:false|true)\b/i,
      alias: "boolean"
    },
    {
      pattern: /(::\s*)\b[a-z_]\w*\b(?!\s*\()/i,
      greedy: !0,
      lookbehind: !0
    },
    {
      pattern: /(\b(?:case|const)\s+)\b[a-z_]\w*(?=\s*[;=])/i,
      greedy: !0,
      lookbehind: !0
    },
    /\b(?:null)\b/i,
    /\b[A-Z_][A-Z0-9_]*\b(?!\s*\()/
  ], n = /\b0b[01]+(?:_[01]+)*\b|\b0o[0-7]+(?:_[0-7]+)*\b|\b0x[\da-f]+(?:_[\da-f]+)*\b|(?:\b\d+(?:_\d+)*\.?(?:\d+(?:_\d+)*)?|\B\.\d+)(?:e[+-]?\d+)?/i, a = /<?=>|\?\?=?|\.{3}|\??->|[!=]=?=?|::|\*\*=?|--|\+\+|&&|\|\||<<|>>|[?~]|[/^|%*&<>.+-]=?/, o = /[{}\[\](),:;]/;
  i.languages.php = {
    delimiter: {
      pattern: /\?>$|^<\?(?:php(?=\s)|=)?/i,
      alias: "important"
    },
    comment: e,
    variable: /\$+(?:\w+\b|(?=\{))/,
    package: {
      pattern: /(namespace\s+|use\s+(?:function\s+)?)(?:\\?\b[a-z_]\w*)+\b(?!\\)/i,
      lookbehind: !0,
      inside: {
        punctuation: /\\/
      }
    },
    "class-name-definition": {
      pattern: /(\b(?:class|enum|interface|trait)\s+)\b[a-z_]\w*(?!\\)\b/i,
      lookbehind: !0,
      alias: "class-name"
    },
    "function-definition": {
      pattern: /(\bfunction\s+)[a-z_]\w*(?=\s*\()/i,
      lookbehind: !0,
      alias: "function"
    },
    keyword: [
      {
        pattern: /(\(\s*)\b(?:array|bool|boolean|float|int|integer|object|string)\b(?=\s*\))/i,
        alias: "type-casting",
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /([(,?]\s*)\b(?:array(?!\s*\()|bool|callable|(?:false|null)(?=\s*\|)|float|int|iterable|mixed|object|self|static|string)\b(?=\s*\$)/i,
        alias: "type-hint",
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /(\)\s*:\s*(?:\?\s*)?)\b(?:array(?!\s*\()|bool|callable|(?:false|null)(?=\s*\|)|float|int|iterable|mixed|never|object|self|static|string|void)\b/i,
        alias: "return-type",
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /\b(?:array(?!\s*\()|bool|float|int|iterable|mixed|object|string|void)\b/i,
        alias: "type-declaration",
        greedy: !0
      },
      {
        pattern: /(\|\s*)(?:false|null)\b|\b(?:false|null)(?=\s*\|)/i,
        alias: "type-declaration",
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /\b(?:parent|self|static)(?=\s*::)/i,
        alias: "static-context",
        greedy: !0
      },
      {
        // yield from
        pattern: /(\byield\s+)from\b/i,
        lookbehind: !0
      },
      // `class` is always a keyword unlike other keywords
      /\bclass\b/i,
      {
        // https://www.php.net/manual/en/reserved.keywords.php
        //
        // keywords cannot be preceded by "->"
        // the complex lookbehind means `(?<!(?:->|::)\s*)`
        pattern: /((?:^|[^\s>:]|(?:^|[^-])>|(?:^|[^:]):)\s*)\b(?:abstract|and|array|as|break|callable|case|catch|clone|const|continue|declare|default|die|do|echo|else|elseif|empty|enddeclare|endfor|endforeach|endif|endswitch|endwhile|enum|eval|exit|extends|final|finally|fn|for|foreach|function|global|goto|if|implements|include|include_once|instanceof|insteadof|interface|isset|list|match|namespace|never|new|or|parent|print|private|protected|public|readonly|require|require_once|return|self|static|switch|throw|trait|try|unset|use|var|while|xor|yield|__halt_compiler)\b/i,
        lookbehind: !0
      }
    ],
    "argument-name": {
      pattern: /([(,]\s*)\b[a-z_]\w*(?=\s*:(?!:))/i,
      lookbehind: !0
    },
    "class-name": [
      {
        pattern: /(\b(?:extends|implements|instanceof|new(?!\s+self|\s+static))\s+|\bcatch\s*\()\b[a-z_]\w*(?!\\)\b/i,
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /(\|\s*)\b[a-z_]\w*(?!\\)\b/i,
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /\b[a-z_]\w*(?!\\)\b(?=\s*\|)/i,
        greedy: !0
      },
      {
        pattern: /(\|\s*)(?:\\?\b[a-z_]\w*)+\b/i,
        alias: "class-name-fully-qualified",
        greedy: !0,
        lookbehind: !0,
        inside: {
          punctuation: /\\/
        }
      },
      {
        pattern: /(?:\\?\b[a-z_]\w*)+\b(?=\s*\|)/i,
        alias: "class-name-fully-qualified",
        greedy: !0,
        inside: {
          punctuation: /\\/
        }
      },
      {
        pattern: /(\b(?:extends|implements|instanceof|new(?!\s+self\b|\s+static\b))\s+|\bcatch\s*\()(?:\\?\b[a-z_]\w*)+\b(?!\\)/i,
        alias: "class-name-fully-qualified",
        greedy: !0,
        lookbehind: !0,
        inside: {
          punctuation: /\\/
        }
      },
      {
        pattern: /\b[a-z_]\w*(?=\s*\$)/i,
        alias: "type-declaration",
        greedy: !0
      },
      {
        pattern: /(?:\\?\b[a-z_]\w*)+(?=\s*\$)/i,
        alias: ["class-name-fully-qualified", "type-declaration"],
        greedy: !0,
        inside: {
          punctuation: /\\/
        }
      },
      {
        pattern: /\b[a-z_]\w*(?=\s*::)/i,
        alias: "static-context",
        greedy: !0
      },
      {
        pattern: /(?:\\?\b[a-z_]\w*)+(?=\s*::)/i,
        alias: ["class-name-fully-qualified", "static-context"],
        greedy: !0,
        inside: {
          punctuation: /\\/
        }
      },
      {
        pattern: /([(,?]\s*)[a-z_]\w*(?=\s*\$)/i,
        alias: "type-hint",
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /([(,?]\s*)(?:\\?\b[a-z_]\w*)+(?=\s*\$)/i,
        alias: ["class-name-fully-qualified", "type-hint"],
        greedy: !0,
        lookbehind: !0,
        inside: {
          punctuation: /\\/
        }
      },
      {
        pattern: /(\)\s*:\s*(?:\?\s*)?)\b[a-z_]\w*(?!\\)\b/i,
        alias: "return-type",
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /(\)\s*:\s*(?:\?\s*)?)(?:\\?\b[a-z_]\w*)+\b(?!\\)/i,
        alias: ["class-name-fully-qualified", "return-type"],
        greedy: !0,
        lookbehind: !0,
        inside: {
          punctuation: /\\/
        }
      }
    ],
    constant: t,
    function: {
      pattern: /(^|[^\\\w])\\?[a-z_](?:[\w\\]*\w)?(?=\s*\()/i,
      lookbehind: !0,
      inside: {
        punctuation: /\\/
      }
    },
    property: {
      pattern: /(->\s*)\w+/,
      lookbehind: !0
    },
    number: n,
    operator: a,
    punctuation: o
  };
  var l = {
    pattern: /\{\$(?:\{(?:\{[^{}]+\}|[^{}]+)\}|[^{}])+\}|(^|[^\\{])\$+(?:\w+(?:\[[^\r\n\[\]]+\]|->\w+)?)/,
    lookbehind: !0,
    inside: i.languages.php
  }, r = [
    {
      pattern: /<<<'([^']+)'[\r\n](?:.*[\r\n])*?\1;/,
      alias: "nowdoc-string",
      greedy: !0,
      inside: {
        delimiter: {
          pattern: /^<<<'[^']+'|[a-z_]\w*;$/i,
          alias: "symbol",
          inside: {
            punctuation: /^<<<'?|[';]$/
          }
        }
      }
    },
    {
      pattern: /<<<(?:"([^"]+)"[\r\n](?:.*[\r\n])*?\1;|([a-z_]\w*)[\r\n](?:.*[\r\n])*?\2;)/i,
      alias: "heredoc-string",
      greedy: !0,
      inside: {
        delimiter: {
          pattern: /^<<<(?:"[^"]+"|[a-z_]\w*)|[a-z_]\w*;$/i,
          alias: "symbol",
          inside: {
            punctuation: /^<<<"?|[";]$/
          }
        },
        interpolation: l
      }
    },
    {
      pattern: /`(?:\\[\s\S]|[^\\`])*`/,
      alias: "backtick-quoted-string",
      greedy: !0
    },
    {
      pattern: /'(?:\\[\s\S]|[^\\'])*'/,
      alias: "single-quoted-string",
      greedy: !0
    },
    {
      pattern: /"(?:\\[\s\S]|[^\\"])*"/,
      alias: "double-quoted-string",
      greedy: !0,
      inside: {
        interpolation: l
      }
    }
  ];
  i.languages.insertBefore("php", "variable", {
    string: r,
    attribute: {
      pattern: /#\[(?:[^"'\/#]|\/(?![*/])|\/\/.*$|#(?!\[).*$|\/\*(?:[^*]|\*(?!\/))*\*\/|"(?:\\[\s\S]|[^\\"])*"|'(?:\\[\s\S]|[^\\'])*')+\](?=\s*[a-z$#])/im,
      greedy: !0,
      inside: {
        "attribute-content": {
          pattern: /^(#\[)[\s\S]+(?=\]$)/,
          lookbehind: !0,
          // inside can appear subset of php
          inside: {
            comment: e,
            string: r,
            "attribute-class-name": [
              {
                pattern: /([^:]|^)\b[a-z_]\w*(?!\\)\b/i,
                alias: "class-name",
                greedy: !0,
                lookbehind: !0
              },
              {
                pattern: /([^:]|^)(?:\\?\b[a-z_]\w*)+/i,
                alias: [
                  "class-name",
                  "class-name-fully-qualified"
                ],
                greedy: !0,
                lookbehind: !0,
                inside: {
                  punctuation: /\\/
                }
              }
            ],
            constant: t,
            number: n,
            operator: a,
            punctuation: o
          }
        },
        delimiter: {
          pattern: /^#\[|\]$/,
          alias: "punctuation"
        }
      }
    }
  }), i.hooks.add("before-tokenize", function(s) {
    if (/<\?/.test(s.code)) {
      var u = /<\?(?:[^"'/#]|\/(?![*/])|("|')(?:\\[\s\S]|(?!\1)[^\\])*\1|(?:\/\/|#(?!\[))(?:[^?\n\r]|\?(?!>))*(?=$|\?>|[\r\n])|#\[|\/\*(?:[^*]|\*(?!\/))*(?:\*\/|$))*?(?:\?>|$)/g;
      i.languages["markup-templating"].buildPlaceholders(s, "php", u);
    }
  }), i.hooks.add("after-tokenize", function(s) {
    i.languages["markup-templating"].tokenizePlaceholders(s, "php");
  });
})(Prism);
(function(i) {
  var e = /[*&][^\s[\]{},]+/, t = /!(?:<[\w\-%#;/?:@&=+$,.!~*'()[\]]+>|(?:[a-zA-Z\d-]*!)?[\w\-%#;/?:@&=+$.~*'()]+)?/, n = "(?:" + t.source + "(?:[ 	]+" + e.source + ")?|" + e.source + "(?:[ 	]+" + t.source + ")?)", a = /(?:[^\s\x00-\x08\x0e-\x1f!"#%&'*,\-:>?@[\]`{|}\x7f-\x84\x86-\x9f\ud800-\udfff\ufffe\uffff]|[?:-]<PLAIN>)(?:[ \t]*(?:(?![#:])<PLAIN>|:<PLAIN>))*/.source.replace(/<PLAIN>/g, function() {
    return /[^\s\x00-\x08\x0e-\x1f,[\]{}\x7f-\x84\x86-\x9f\ud800-\udfff\ufffe\uffff]/.source;
  }), o = /"(?:[^"\\\r\n]|\\.)*"|'(?:[^'\\\r\n]|\\.)*'/.source;
  function l(r, s) {
    s = (s || "").replace(/m/g, "") + "m";
    var u = /([:\-,[{]\s*(?:\s<<prop>>[ \t]+)?)(?:<<value>>)(?=[ \t]*(?:$|,|\]|\}|(?:[\r\n]\s*)?#))/.source.replace(/<<prop>>/g, function() {
      return n;
    }).replace(/<<value>>/g, function() {
      return r;
    });
    return RegExp(u, s);
  }
  i.languages.yaml = {
    scalar: {
      pattern: RegExp(/([\-:]\s*(?:\s<<prop>>[ \t]+)?[|>])[ \t]*(?:((?:\r?\n|\r)[ \t]+)\S[^\r\n]*(?:\2[^\r\n]+)*)/.source.replace(/<<prop>>/g, function() {
        return n;
      })),
      lookbehind: !0,
      alias: "string"
    },
    comment: /#.*/,
    key: {
      pattern: RegExp(/((?:^|[:\-,[{\r\n?])[ \t]*(?:<<prop>>[ \t]+)?)<<key>>(?=\s*:\s)/.source.replace(/<<prop>>/g, function() {
        return n;
      }).replace(/<<key>>/g, function() {
        return "(?:" + a + "|" + o + ")";
      })),
      lookbehind: !0,
      greedy: !0,
      alias: "atrule"
    },
    directive: {
      pattern: /(^[ \t]*)%.+/m,
      lookbehind: !0,
      alias: "important"
    },
    datetime: {
      pattern: l(/\d{4}-\d\d?-\d\d?(?:[tT]|[ \t]+)\d\d?:\d{2}:\d{2}(?:\.\d*)?(?:[ \t]*(?:Z|[-+]\d\d?(?::\d{2})?))?|\d{4}-\d{2}-\d{2}|\d\d?:\d{2}(?::\d{2}(?:\.\d*)?)?/.source),
      lookbehind: !0,
      alias: "number"
    },
    boolean: {
      pattern: l(/false|true/.source, "i"),
      lookbehind: !0,
      alias: "important"
    },
    null: {
      pattern: l(/null|~/.source, "i"),
      lookbehind: !0,
      alias: "important"
    },
    string: {
      pattern: l(o),
      lookbehind: !0,
      greedy: !0
    },
    number: {
      pattern: l(/[+-]?(?:0x[\da-f]+|0o[0-7]+|(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?|\.inf|\.nan)/.source, "i"),
      lookbehind: !0
    },
    tag: t,
    important: e,
    punctuation: /---|[:[\]{}\-,|>?]|\.\.\./
  }, i.languages.yml = i.languages.yaml;
})(Prism);
(function(i) {
  function e(t, n) {
    return "___" + t.toUpperCase() + n + "___";
  }
  Object.defineProperties(i.languages["markup-templating"] = {}, {
    buildPlaceholders: {
      /**
       * Tokenize all inline templating expressions matching `placeholderPattern`.
       *
       * If `replaceFilter` is provided, only matches of `placeholderPattern` for which `replaceFilter` returns
       * `true` will be replaced.
       *
       * @param {object} env The environment of the `before-tokenize` hook.
       * @param {string} language The language id.
       * @param {RegExp} placeholderPattern The matches of this pattern will be replaced by placeholders.
       * @param {(match: string) => boolean} [replaceFilter]
       */
      value: function(t, n, a, o) {
        if (t.language === n) {
          var l = t.tokenStack = [];
          t.code = t.code.replace(a, function(r) {
            if (typeof o == "function" && !o(r))
              return r;
            for (var s = l.length, u; t.code.indexOf(u = e(n, s)) !== -1; )
              ++s;
            return l[s] = r, u;
          }), t.grammar = i.languages.markup;
        }
      }
    },
    tokenizePlaceholders: {
      /**
       * Replace placeholders with proper tokens after tokenizing.
       *
       * @param {object} env The environment of the `after-tokenize` hook.
       * @param {string} language The language id.
       */
      value: function(t, n) {
        if (t.language !== n || !t.tokenStack)
          return;
        t.grammar = i.languages[n];
        var a = 0, o = Object.keys(t.tokenStack);
        function l(r) {
          for (var s = 0; s < r.length && !(a >= o.length); s++) {
            var u = r[s];
            if (typeof u == "string" || u.content && typeof u.content == "string") {
              var c = o[a], g = t.tokenStack[c], _ = typeof u == "string" ? u : u.content, m = e(n, c), b = _.indexOf(m);
              if (b > -1) {
                ++a;
                var w = _.substring(0, b), y = new i.Token(n, i.tokenize(g, t.grammar), "language-" + n, g), x = _.substring(b + m.length), p = [];
                w && p.push.apply(p, l([w])), p.push(y), x && p.push.apply(p, l([x])), typeof u == "string" ? r.splice.apply(r, [s, 1].concat(p)) : u.content = p;
              }
            } else u.content && l(u.content);
          }
          return r;
        }
        l(t.tokens);
      }
    }
  });
})(Prism);
new _l();
const Zo = (i) => {
  const e = {};
  for (let t = 0, n = i.length; t < n; t++) {
    const a = i[t];
    for (const o in a)
      e[o] ? e[o] = e[o].concat(a[o]) : e[o] = a[o];
  }
  return e;
}, Xo = [
  "abbr",
  "accept",
  "accept-charset",
  "accesskey",
  "action",
  "align",
  "alink",
  "allow",
  "allowfullscreen",
  "alt",
  "anchor",
  "archive",
  "as",
  "async",
  "autocapitalize",
  "autocomplete",
  "autocorrect",
  "autofocus",
  "autopictureinpicture",
  "autoplay",
  "axis",
  "background",
  "behavior",
  "bgcolor",
  "border",
  "bordercolor",
  "capture",
  "cellpadding",
  "cellspacing",
  "challenge",
  "char",
  "charoff",
  "charset",
  "checked",
  "cite",
  "class",
  "classid",
  "clear",
  "code",
  "codebase",
  "codetype",
  "color",
  "cols",
  "colspan",
  "compact",
  "content",
  "contenteditable",
  "controls",
  "controlslist",
  "conversiondestination",
  "coords",
  "crossorigin",
  "csp",
  "data",
  "datetime",
  "declare",
  "decoding",
  "default",
  "defer",
  "dir",
  "direction",
  "dirname",
  "disabled",
  "disablepictureinpicture",
  "disableremoteplayback",
  "disallowdocumentaccess",
  "download",
  "draggable",
  "elementtiming",
  "enctype",
  "end",
  "enterkeyhint",
  "event",
  "exportparts",
  "face",
  "for",
  "form",
  "formaction",
  "formenctype",
  "formmethod",
  "formnovalidate",
  "formtarget",
  "frame",
  "frameborder",
  "headers",
  "height",
  "hidden",
  "high",
  "href",
  "hreflang",
  "hreftranslate",
  "hspace",
  "http-equiv",
  "id",
  "imagesizes",
  "imagesrcset",
  "importance",
  "impressiondata",
  "impressionexpiry",
  "incremental",
  "inert",
  "inputmode",
  "integrity",
  "invisible",
  "ismap",
  "keytype",
  "kind",
  "label",
  "lang",
  "language",
  "latencyhint",
  "leftmargin",
  "link",
  "list",
  "loading",
  "longdesc",
  "loop",
  "low",
  "lowsrc",
  "manifest",
  "marginheight",
  "marginwidth",
  "max",
  "maxlength",
  "mayscript",
  "media",
  "method",
  "min",
  "minlength",
  "multiple",
  "muted",
  "name",
  "nohref",
  "nomodule",
  "nonce",
  "noresize",
  "noshade",
  "novalidate",
  "nowrap",
  "object",
  "open",
  "optimum",
  "part",
  "pattern",
  "ping",
  "placeholder",
  "playsinline",
  "policy",
  "poster",
  "preload",
  "pseudo",
  "readonly",
  "referrerpolicy",
  "rel",
  "reportingorigin",
  "required",
  "resources",
  "rev",
  "reversed",
  "role",
  "rows",
  "rowspan",
  "rules",
  "sandbox",
  "scheme",
  "scope",
  "scopes",
  "scrollamount",
  "scrolldelay",
  "scrolling",
  "select",
  "selected",
  "shadowroot",
  "shadowrootdelegatesfocus",
  "shape",
  "size",
  "sizes",
  "slot",
  "span",
  "spellcheck",
  "src",
  "srclang",
  "srcset",
  "standby",
  "start",
  "step",
  "style",
  "summary",
  "tabindex",
  "target",
  "text",
  "title",
  "topmargin",
  "translate",
  "truespeed",
  "trusttoken",
  "type",
  "usemap",
  "valign",
  "value",
  "valuetype",
  "version",
  "virtualkeyboardpolicy",
  "vlink",
  "vspace",
  "webkitdirectory",
  "width",
  "wrap"
], Ko = [
  "accent-height",
  "accumulate",
  "additive",
  "alignment-baseline",
  "ascent",
  "attributename",
  "attributetype",
  "azimuth",
  "basefrequency",
  "baseline-shift",
  "begin",
  "bias",
  "by",
  "class",
  "clip",
  "clippathunits",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "cx",
  "cy",
  "d",
  "dx",
  "dy",
  "diffuseconstant",
  "direction",
  "display",
  "divisor",
  "dominant-baseline",
  "dur",
  "edgemode",
  "elevation",
  "end",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "filterunits",
  "flood-color",
  "flood-opacity",
  "font-family",
  "font-size",
  "font-size-adjust",
  "font-stretch",
  "font-style",
  "font-variant",
  "font-weight",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyph-name",
  "glyphref",
  "gradientunits",
  "gradienttransform",
  "height",
  "href",
  "id",
  "image-rendering",
  "in",
  "in2",
  "k",
  "k1",
  "k2",
  "k3",
  "k4",
  "kerning",
  "keypoints",
  "keysplines",
  "keytimes",
  "lang",
  "lengthadjust",
  "letter-spacing",
  "kernelmatrix",
  "kernelunitlength",
  "lighting-color",
  "local",
  "marker-end",
  "marker-mid",
  "marker-start",
  "markerheight",
  "markerunits",
  "markerwidth",
  "maskcontentunits",
  "maskunits",
  "max",
  "mask",
  "media",
  "method",
  "mode",
  "min",
  "name",
  "numoctaves",
  "offset",
  "operator",
  "opacity",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "paint-order",
  "path",
  "pathlength",
  "patterncontentunits",
  "patterntransform",
  "patternunits",
  "points",
  "preservealpha",
  "preserveaspectratio",
  "primitiveunits",
  "r",
  "rx",
  "ry",
  "radius",
  "refx",
  "refy",
  "repeatcount",
  "repeatdur",
  "restart",
  "result",
  "rotate",
  "scale",
  "seed",
  "shape-rendering",
  "specularconstant",
  "specularexponent",
  "spreadmethod",
  "startoffset",
  "stddeviation",
  "stitchtiles",
  "stop-color",
  "stop-opacity",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke",
  "stroke-width",
  "style",
  "surfacescale",
  "systemlanguage",
  "tabindex",
  "targetx",
  "targety",
  "transform",
  "transform-origin",
  "text-anchor",
  "text-decoration",
  "text-rendering",
  "textlength",
  "type",
  "u1",
  "u2",
  "unicode",
  "values",
  "viewbox",
  "visibility",
  "version",
  "vert-adv-y",
  "vert-origin-x",
  "vert-origin-y",
  "width",
  "word-spacing",
  "wrap",
  "writing-mode",
  "xchannelselector",
  "ychannelselector",
  "x",
  "x1",
  "x2",
  "xmlns",
  "y",
  "y1",
  "y2",
  "z",
  "zoomandpan"
], Qo = [
  "accent",
  "accentunder",
  "align",
  "bevelled",
  "close",
  "columnsalign",
  "columnlines",
  "columnspan",
  "denomalign",
  "depth",
  "dir",
  "display",
  "displaystyle",
  "encoding",
  "fence",
  "frame",
  "height",
  "href",
  "id",
  "largeop",
  "length",
  "linethickness",
  "lspace",
  "lquote",
  "mathbackground",
  "mathcolor",
  "mathsize",
  "mathvariant",
  "maxsize",
  "minsize",
  "movablelimits",
  "notation",
  "numalign",
  "open",
  "rowalign",
  "rowlines",
  "rowspacing",
  "rowspan",
  "rspace",
  "rquote",
  "scriptlevel",
  "scriptminsize",
  "scriptsizemultiplier",
  "selection",
  "separator",
  "separators",
  "stretchy",
  "subscriptshift",
  "supscriptshift",
  "symmetric",
  "voffset",
  "width",
  "xmlns"
];
Zo([
  Object.fromEntries(Xo.map((i) => [i, ["*"]])),
  Object.fromEntries(Ko.map((i) => [i, ["svg:*"]])),
  Object.fromEntries(Qo.map((i) => [i, ["math:*"]]))
]);
const {
  HtmlTagHydration: Xs,
  SvelteComponent: Ks,
  attr: Qs,
  binding_callbacks: Js,
  children: eu,
  claim_element: tu,
  claim_html_tag: nu,
  detach: iu,
  element: au,
  init: lu,
  insert_hydration: ou,
  noop: ru,
  safe_not_equal: su,
  toggle_class: uu
} = window.__gradio__svelte__internal, { afterUpdate: cu, tick: du, onMount: _u } = window.__gradio__svelte__internal, {
  SvelteComponent: fu,
  attr: pu,
  children: hu,
  claim_component: mu,
  claim_element: gu,
  create_component: bu,
  destroy_component: vu,
  detach: Du,
  element: yu,
  init: Eu,
  insert_hydration: wu,
  mount_component: ku,
  safe_not_equal: Fu,
  transition_in: $u,
  transition_out: Au
} = window.__gradio__svelte__internal, {
  SvelteComponent: Cu,
  attr: Su,
  check_outros: Tu,
  children: Iu,
  claim_component: Ru,
  claim_element: xu,
  claim_space: Lu,
  create_component: Nu,
  create_slot: Ou,
  destroy_component: Bu,
  detach: Mu,
  element: Pu,
  empty: qu,
  get_all_dirty_from_scope: zu,
  get_slot_changes: Uu,
  group_outros: Hu,
  init: Gu,
  insert_hydration: ju,
  mount_component: Vu,
  safe_not_equal: Yu,
  space: Wu,
  toggle_class: Zu,
  transition_in: Xu,
  transition_out: Ku,
  update_slot_base: Qu
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ju,
  append_hydration: ec,
  attr: tc,
  children: nc,
  claim_component: ic,
  claim_element: ac,
  claim_space: lc,
  claim_text: oc,
  create_component: rc,
  destroy_component: sc,
  detach: uc,
  element: cc,
  init: dc,
  insert_hydration: _c,
  mount_component: fc,
  safe_not_equal: pc,
  set_data: hc,
  space: mc,
  text: gc,
  toggle_class: bc,
  transition_in: vc,
  transition_out: Dc
} = window.__gradio__svelte__internal, {
  SvelteComponent: Jo,
  append_hydration: $n,
  attr: vt,
  bubble: er,
  check_outros: tr,
  children: li,
  claim_component: nr,
  claim_element: oi,
  claim_space: Wi,
  claim_text: ir,
  construct_svelte_component: Zi,
  create_component: Xi,
  create_slot: ar,
  destroy_component: Ki,
  detach: on,
  element: ri,
  get_all_dirty_from_scope: lr,
  get_slot_changes: or,
  group_outros: rr,
  init: sr,
  insert_hydration: fl,
  listen: ur,
  mount_component: Qi,
  safe_not_equal: cr,
  set_data: dr,
  set_style: bn,
  space: Ji,
  text: _r,
  toggle_class: Te,
  transition_in: Gn,
  transition_out: jn,
  update_slot_base: fr
} = window.__gradio__svelte__internal;
function ea(i) {
  let e, t;
  return {
    c() {
      e = ri("span"), t = _r(
        /*label*/
        i[1]
      ), this.h();
    },
    l(n) {
      e = oi(n, "SPAN", { class: !0 });
      var a = li(e);
      t = ir(
        a,
        /*label*/
        i[1]
      ), a.forEach(on), this.h();
    },
    h() {
      vt(e, "class", "svelte-qgco6m");
    },
    m(n, a) {
      fl(n, e, a), $n(e, t);
    },
    p(n, a) {
      a & /*label*/
      2 && dr(
        t,
        /*label*/
        n[1]
      );
    },
    d(n) {
      n && on(e);
    }
  };
}
function pr(i) {
  let e, t, n, a, o, l, r, s, u = (
    /*show_label*/
    i[2] && ea(i)
  );
  var c = (
    /*Icon*/
    i[0]
  );
  function g(b, w) {
    return {};
  }
  c && (a = Zi(c, g()));
  const _ = (
    /*#slots*/
    i[14].default
  ), m = ar(
    _,
    i,
    /*$$scope*/
    i[13],
    null
  );
  return {
    c() {
      e = ri("button"), u && u.c(), t = Ji(), n = ri("div"), a && Xi(a.$$.fragment), o = Ji(), m && m.c(), this.h();
    },
    l(b) {
      e = oi(b, "BUTTON", {
        "aria-label": !0,
        "aria-haspopup": !0,
        title: !0,
        class: !0
      });
      var w = li(e);
      u && u.l(w), t = Wi(w), n = oi(w, "DIV", { class: !0 });
      var y = li(n);
      a && nr(a.$$.fragment, y), o = Wi(y), m && m.l(y), y.forEach(on), w.forEach(on), this.h();
    },
    h() {
      vt(n, "class", "svelte-qgco6m"), Te(
        n,
        "x-small",
        /*size*/
        i[4] === "x-small"
      ), Te(
        n,
        "small",
        /*size*/
        i[4] === "small"
      ), Te(
        n,
        "large",
        /*size*/
        i[4] === "large"
      ), Te(
        n,
        "medium",
        /*size*/
        i[4] === "medium"
      ), e.disabled = /*disabled*/
      i[7], vt(
        e,
        "aria-label",
        /*label*/
        i[1]
      ), vt(
        e,
        "aria-haspopup",
        /*hasPopup*/
        i[8]
      ), vt(
        e,
        "title",
        /*label*/
        i[1]
      ), vt(e, "class", "svelte-qgco6m"), Te(
        e,
        "pending",
        /*pending*/
        i[3]
      ), Te(
        e,
        "padded",
        /*padded*/
        i[5]
      ), Te(
        e,
        "highlight",
        /*highlight*/
        i[6]
      ), Te(
        e,
        "transparent",
        /*transparent*/
        i[9]
      ), bn(e, "color", !/*disabled*/
      i[7] && /*_color*/
      i[11] ? (
        /*_color*/
        i[11]
      ) : "var(--block-label-text-color)"), bn(e, "--bg-color", /*disabled*/
      i[7] ? "auto" : (
        /*background*/
        i[10]
      ));
    },
    m(b, w) {
      fl(b, e, w), u && u.m(e, null), $n(e, t), $n(e, n), a && Qi(a, n, null), $n(n, o), m && m.m(n, null), l = !0, r || (s = ur(
        e,
        "click",
        /*click_handler*/
        i[15]
      ), r = !0);
    },
    p(b, [w]) {
      if (/*show_label*/
      b[2] ? u ? u.p(b, w) : (u = ea(b), u.c(), u.m(e, t)) : u && (u.d(1), u = null), w & /*Icon*/
      1 && c !== (c = /*Icon*/
      b[0])) {
        if (a) {
          rr();
          const y = a;
          jn(y.$$.fragment, 1, 0, () => {
            Ki(y, 1);
          }), tr();
        }
        c ? (a = Zi(c, g()), Xi(a.$$.fragment), Gn(a.$$.fragment, 1), Qi(a, n, o)) : a = null;
      }
      m && m.p && (!l || w & /*$$scope*/
      8192) && fr(
        m,
        _,
        b,
        /*$$scope*/
        b[13],
        l ? or(
          _,
          /*$$scope*/
          b[13],
          w,
          null
        ) : lr(
          /*$$scope*/
          b[13]
        ),
        null
      ), (!l || w & /*size*/
      16) && Te(
        n,
        "x-small",
        /*size*/
        b[4] === "x-small"
      ), (!l || w & /*size*/
      16) && Te(
        n,
        "small",
        /*size*/
        b[4] === "small"
      ), (!l || w & /*size*/
      16) && Te(
        n,
        "large",
        /*size*/
        b[4] === "large"
      ), (!l || w & /*size*/
      16) && Te(
        n,
        "medium",
        /*size*/
        b[4] === "medium"
      ), (!l || w & /*disabled*/
      128) && (e.disabled = /*disabled*/
      b[7]), (!l || w & /*label*/
      2) && vt(
        e,
        "aria-label",
        /*label*/
        b[1]
      ), (!l || w & /*hasPopup*/
      256) && vt(
        e,
        "aria-haspopup",
        /*hasPopup*/
        b[8]
      ), (!l || w & /*label*/
      2) && vt(
        e,
        "title",
        /*label*/
        b[1]
      ), (!l || w & /*pending*/
      8) && Te(
        e,
        "pending",
        /*pending*/
        b[3]
      ), (!l || w & /*padded*/
      32) && Te(
        e,
        "padded",
        /*padded*/
        b[5]
      ), (!l || w & /*highlight*/
      64) && Te(
        e,
        "highlight",
        /*highlight*/
        b[6]
      ), (!l || w & /*transparent*/
      512) && Te(
        e,
        "transparent",
        /*transparent*/
        b[9]
      ), w & /*disabled, _color*/
      2176 && bn(e, "color", !/*disabled*/
      b[7] && /*_color*/
      b[11] ? (
        /*_color*/
        b[11]
      ) : "var(--block-label-text-color)"), w & /*disabled, background*/
      1152 && bn(e, "--bg-color", /*disabled*/
      b[7] ? "auto" : (
        /*background*/
        b[10]
      ));
    },
    i(b) {
      l || (a && Gn(a.$$.fragment, b), Gn(m, b), l = !0);
    },
    o(b) {
      a && jn(a.$$.fragment, b), jn(m, b), l = !1;
    },
    d(b) {
      b && on(e), u && u.d(), a && Ki(a), m && m.d(b), r = !1, s();
    }
  };
}
function hr(i, e, t) {
  let n, { $$slots: a = {}, $$scope: o } = e, { Icon: l } = e, { label: r = "" } = e, { show_label: s = !1 } = e, { pending: u = !1 } = e, { size: c = "small" } = e, { padded: g = !0 } = e, { highlight: _ = !1 } = e, { disabled: m = !1 } = e, { hasPopup: b = !1 } = e, { color: w = "var(--block-label-text-color)" } = e, { transparent: y = !1 } = e, { background: x = "var(--block-background-fill)" } = e;
  function p(d) {
    er.call(this, i, d);
  }
  return i.$$set = (d) => {
    "Icon" in d && t(0, l = d.Icon), "label" in d && t(1, r = d.label), "show_label" in d && t(2, s = d.show_label), "pending" in d && t(3, u = d.pending), "size" in d && t(4, c = d.size), "padded" in d && t(5, g = d.padded), "highlight" in d && t(6, _ = d.highlight), "disabled" in d && t(7, m = d.disabled), "hasPopup" in d && t(8, b = d.hasPopup), "color" in d && t(12, w = d.color), "transparent" in d && t(9, y = d.transparent), "background" in d && t(10, x = d.background), "$$scope" in d && t(13, o = d.$$scope);
  }, i.$$.update = () => {
    i.$$.dirty & /*highlight, color*/
    4160 && t(11, n = _ ? "var(--color-accent)" : w);
  }, [
    l,
    r,
    s,
    u,
    c,
    g,
    _,
    m,
    b,
    y,
    x,
    n,
    w,
    o,
    a,
    p
  ];
}
class mr extends Jo {
  constructor(e) {
    super(), sr(this, e, hr, pr, cr, {
      Icon: 0,
      label: 1,
      show_label: 2,
      pending: 3,
      size: 4,
      padded: 5,
      highlight: 6,
      disabled: 7,
      hasPopup: 8,
      color: 12,
      transparent: 9,
      background: 10
    });
  }
}
const {
  SvelteComponent: yc,
  append_hydration: Ec,
  attr: wc,
  binding_callbacks: kc,
  children: Fc,
  claim_element: $c,
  create_slot: Ac,
  detach: Cc,
  element: Sc,
  get_all_dirty_from_scope: Tc,
  get_slot_changes: Ic,
  init: Rc,
  insert_hydration: xc,
  safe_not_equal: Lc,
  toggle_class: Nc,
  transition_in: Oc,
  transition_out: Bc,
  update_slot_base: Mc
} = window.__gradio__svelte__internal, {
  SvelteComponent: Pc,
  append_hydration: qc,
  attr: zc,
  children: Uc,
  claim_svg_element: Hc,
  detach: Gc,
  init: jc,
  insert_hydration: Vc,
  noop: Yc,
  safe_not_equal: Wc,
  svg_element: Zc
} = window.__gradio__svelte__internal, {
  SvelteComponent: Xc,
  append_hydration: Kc,
  attr: Qc,
  children: Jc,
  claim_svg_element: ed,
  detach: td,
  init: nd,
  insert_hydration: id,
  noop: ad,
  safe_not_equal: ld,
  svg_element: od
} = window.__gradio__svelte__internal, {
  SvelteComponent: rd,
  append_hydration: sd,
  attr: ud,
  children: cd,
  claim_svg_element: dd,
  detach: _d,
  init: fd,
  insert_hydration: pd,
  noop: hd,
  safe_not_equal: md,
  svg_element: gd
} = window.__gradio__svelte__internal, {
  SvelteComponent: bd,
  append_hydration: vd,
  attr: Dd,
  children: yd,
  claim_svg_element: Ed,
  detach: wd,
  init: kd,
  insert_hydration: Fd,
  noop: $d,
  safe_not_equal: Ad,
  svg_element: Cd
} = window.__gradio__svelte__internal, {
  SvelteComponent: Sd,
  append_hydration: Td,
  attr: Id,
  children: Rd,
  claim_svg_element: xd,
  detach: Ld,
  init: Nd,
  insert_hydration: Od,
  noop: Bd,
  safe_not_equal: Md,
  svg_element: Pd
} = window.__gradio__svelte__internal, {
  SvelteComponent: qd,
  append_hydration: zd,
  attr: Ud,
  children: Hd,
  claim_svg_element: Gd,
  detach: jd,
  init: Vd,
  insert_hydration: Yd,
  noop: Wd,
  safe_not_equal: Zd,
  svg_element: Xd
} = window.__gradio__svelte__internal, {
  SvelteComponent: Kd,
  append_hydration: Qd,
  attr: Jd,
  children: e_,
  claim_svg_element: t_,
  detach: n_,
  init: i_,
  insert_hydration: a_,
  noop: l_,
  safe_not_equal: o_,
  svg_element: r_
} = window.__gradio__svelte__internal, {
  SvelteComponent: s_,
  append_hydration: u_,
  attr: c_,
  children: d_,
  claim_svg_element: __,
  detach: f_,
  init: p_,
  insert_hydration: h_,
  noop: m_,
  safe_not_equal: g_,
  svg_element: b_
} = window.__gradio__svelte__internal, {
  SvelteComponent: v_,
  append_hydration: D_,
  attr: y_,
  children: E_,
  claim_svg_element: w_,
  detach: k_,
  init: F_,
  insert_hydration: $_,
  noop: A_,
  safe_not_equal: C_,
  svg_element: S_
} = window.__gradio__svelte__internal, {
  SvelteComponent: T_,
  append_hydration: I_,
  attr: R_,
  children: x_,
  claim_svg_element: L_,
  detach: N_,
  init: O_,
  insert_hydration: B_,
  noop: M_,
  safe_not_equal: P_,
  svg_element: q_
} = window.__gradio__svelte__internal, {
  SvelteComponent: z_,
  append_hydration: U_,
  attr: H_,
  children: G_,
  claim_svg_element: j_,
  detach: V_,
  init: Y_,
  insert_hydration: W_,
  noop: Z_,
  safe_not_equal: X_,
  svg_element: K_
} = window.__gradio__svelte__internal, {
  SvelteComponent: Q_,
  append_hydration: J_,
  attr: ef,
  children: tf,
  claim_svg_element: nf,
  detach: af,
  init: lf,
  insert_hydration: of,
  noop: rf,
  safe_not_equal: sf,
  svg_element: uf
} = window.__gradio__svelte__internal, {
  SvelteComponent: gr,
  append_hydration: Vn,
  attr: et,
  children: vn,
  claim_svg_element: Dn,
  detach: Xt,
  init: br,
  insert_hydration: vr,
  noop: Yn,
  safe_not_equal: Dr,
  set_style: st,
  svg_element: yn
} = window.__gradio__svelte__internal;
function yr(i) {
  let e, t, n, a;
  return {
    c() {
      e = yn("svg"), t = yn("g"), n = yn("path"), a = yn("path"), this.h();
    },
    l(o) {
      e = Dn(o, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        version: !0,
        xmlns: !0,
        "xmlns:xlink": !0,
        "xml:space": !0,
        stroke: !0,
        style: !0
      });
      var l = vn(e);
      t = Dn(l, "g", { transform: !0 });
      var r = vn(t);
      n = Dn(r, "path", { d: !0, style: !0 }), vn(n).forEach(Xt), r.forEach(Xt), a = Dn(l, "path", { d: !0, style: !0 }), vn(a).forEach(Xt), l.forEach(Xt), this.h();
    },
    h() {
      et(n, "d", "M18,6L6.087,17.913"), st(n, "fill", "none"), st(n, "fill-rule", "nonzero"), st(n, "stroke-width", "2px"), et(t, "transform", "matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"), et(a, "d", "M4.364,4.364L19.636,19.636"), st(a, "fill", "none"), st(a, "fill-rule", "nonzero"), st(a, "stroke-width", "2px"), et(e, "width", "100%"), et(e, "height", "100%"), et(e, "viewBox", "0 0 24 24"), et(e, "version", "1.1"), et(e, "xmlns", "http://www.w3.org/2000/svg"), et(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), et(e, "xml:space", "preserve"), et(e, "stroke", "currentColor"), st(e, "fill-rule", "evenodd"), st(e, "clip-rule", "evenodd"), st(e, "stroke-linecap", "round"), st(e, "stroke-linejoin", "round");
    },
    m(o, l) {
      vr(o, e, l), Vn(e, t), Vn(t, n), Vn(e, a);
    },
    p: Yn,
    i: Yn,
    o: Yn,
    d(o) {
      o && Xt(e);
    }
  };
}
class Er extends gr {
  constructor(e) {
    super(), br(this, e, null, yr, Dr, {});
  }
}
const {
  SvelteComponent: cf,
  append_hydration: df,
  attr: _f,
  children: ff,
  claim_svg_element: pf,
  detach: hf,
  init: mf,
  insert_hydration: gf,
  noop: bf,
  safe_not_equal: vf,
  svg_element: Df
} = window.__gradio__svelte__internal, {
  SvelteComponent: yf,
  append_hydration: Ef,
  attr: wf,
  children: kf,
  claim_svg_element: Ff,
  detach: $f,
  init: Af,
  insert_hydration: Cf,
  noop: Sf,
  safe_not_equal: Tf,
  svg_element: If
} = window.__gradio__svelte__internal, {
  SvelteComponent: Rf,
  append_hydration: xf,
  attr: Lf,
  children: Nf,
  claim_svg_element: Of,
  detach: Bf,
  init: Mf,
  insert_hydration: Pf,
  noop: qf,
  safe_not_equal: zf,
  svg_element: Uf
} = window.__gradio__svelte__internal, {
  SvelteComponent: Hf,
  append_hydration: Gf,
  attr: jf,
  children: Vf,
  claim_svg_element: Yf,
  detach: Wf,
  init: Zf,
  insert_hydration: Xf,
  noop: Kf,
  safe_not_equal: Qf,
  svg_element: Jf
} = window.__gradio__svelte__internal, {
  SvelteComponent: ep,
  append_hydration: tp,
  attr: np,
  children: ip,
  claim_svg_element: ap,
  detach: lp,
  init: op,
  insert_hydration: rp,
  noop: sp,
  safe_not_equal: up,
  svg_element: cp
} = window.__gradio__svelte__internal, {
  SvelteComponent: dp,
  append_hydration: _p,
  attr: fp,
  children: pp,
  claim_svg_element: hp,
  detach: mp,
  init: gp,
  insert_hydration: bp,
  noop: vp,
  safe_not_equal: Dp,
  svg_element: yp
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ep,
  append_hydration: wp,
  attr: kp,
  children: Fp,
  claim_svg_element: $p,
  detach: Ap,
  init: Cp,
  insert_hydration: Sp,
  noop: Tp,
  safe_not_equal: Ip,
  svg_element: Rp
} = window.__gradio__svelte__internal, {
  SvelteComponent: xp,
  append_hydration: Lp,
  attr: Np,
  children: Op,
  claim_svg_element: Bp,
  detach: Mp,
  init: Pp,
  insert_hydration: qp,
  noop: zp,
  safe_not_equal: Up,
  svg_element: Hp
} = window.__gradio__svelte__internal, {
  SvelteComponent: Gp,
  append_hydration: jp,
  attr: Vp,
  children: Yp,
  claim_svg_element: Wp,
  detach: Zp,
  init: Xp,
  insert_hydration: Kp,
  noop: Qp,
  safe_not_equal: Jp,
  svg_element: eh
} = window.__gradio__svelte__internal, {
  SvelteComponent: th,
  append_hydration: nh,
  attr: ih,
  children: ah,
  claim_svg_element: lh,
  detach: oh,
  init: rh,
  insert_hydration: sh,
  noop: uh,
  safe_not_equal: ch,
  svg_element: dh
} = window.__gradio__svelte__internal, {
  SvelteComponent: _h,
  append_hydration: fh,
  attr: ph,
  children: hh,
  claim_svg_element: mh,
  detach: gh,
  init: bh,
  insert_hydration: vh,
  noop: Dh,
  safe_not_equal: yh,
  svg_element: Eh
} = window.__gradio__svelte__internal, {
  SvelteComponent: wh,
  append_hydration: kh,
  attr: Fh,
  children: $h,
  claim_svg_element: Ah,
  detach: Ch,
  init: Sh,
  insert_hydration: Th,
  noop: Ih,
  safe_not_equal: Rh,
  svg_element: xh
} = window.__gradio__svelte__internal, {
  SvelteComponent: Lh,
  append_hydration: Nh,
  attr: Oh,
  children: Bh,
  claim_svg_element: Mh,
  detach: Ph,
  init: qh,
  insert_hydration: zh,
  noop: Uh,
  safe_not_equal: Hh,
  svg_element: Gh
} = window.__gradio__svelte__internal, {
  SvelteComponent: jh,
  append_hydration: Vh,
  attr: Yh,
  children: Wh,
  claim_svg_element: Zh,
  detach: Xh,
  init: Kh,
  insert_hydration: Qh,
  noop: Jh,
  safe_not_equal: em,
  svg_element: tm
} = window.__gradio__svelte__internal, {
  SvelteComponent: nm,
  append_hydration: im,
  attr: am,
  children: lm,
  claim_svg_element: om,
  detach: rm,
  init: sm,
  insert_hydration: um,
  noop: cm,
  safe_not_equal: dm,
  svg_element: _m
} = window.__gradio__svelte__internal, {
  SvelteComponent: fm,
  append_hydration: pm,
  attr: hm,
  children: mm,
  claim_svg_element: gm,
  detach: bm,
  init: vm,
  insert_hydration: Dm,
  noop: ym,
  safe_not_equal: Em,
  svg_element: wm
} = window.__gradio__svelte__internal, {
  SvelteComponent: km,
  append_hydration: Fm,
  attr: $m,
  children: Am,
  claim_svg_element: Cm,
  detach: Sm,
  init: Tm,
  insert_hydration: Im,
  noop: Rm,
  safe_not_equal: xm,
  svg_element: Lm
} = window.__gradio__svelte__internal, {
  SvelteComponent: Nm,
  append_hydration: Om,
  attr: Bm,
  children: Mm,
  claim_svg_element: Pm,
  detach: qm,
  init: zm,
  insert_hydration: Um,
  noop: Hm,
  safe_not_equal: Gm,
  svg_element: jm
} = window.__gradio__svelte__internal, {
  SvelteComponent: Vm,
  append_hydration: Ym,
  attr: Wm,
  children: Zm,
  claim_svg_element: Xm,
  detach: Km,
  init: Qm,
  insert_hydration: Jm,
  noop: eg,
  safe_not_equal: tg,
  svg_element: ng
} = window.__gradio__svelte__internal, {
  SvelteComponent: ig,
  append_hydration: ag,
  attr: lg,
  children: og,
  claim_svg_element: rg,
  detach: sg,
  init: ug,
  insert_hydration: cg,
  noop: dg,
  safe_not_equal: _g,
  svg_element: fg
} = window.__gradio__svelte__internal, {
  SvelteComponent: pg,
  append_hydration: hg,
  attr: mg,
  children: gg,
  claim_svg_element: bg,
  detach: vg,
  init: Dg,
  insert_hydration: yg,
  noop: Eg,
  safe_not_equal: wg,
  svg_element: kg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Fg,
  append_hydration: $g,
  attr: Ag,
  children: Cg,
  claim_svg_element: Sg,
  detach: Tg,
  init: Ig,
  insert_hydration: Rg,
  noop: xg,
  safe_not_equal: Lg,
  svg_element: Ng
} = window.__gradio__svelte__internal, {
  SvelteComponent: Og,
  append_hydration: Bg,
  attr: Mg,
  children: Pg,
  claim_svg_element: qg,
  detach: zg,
  init: Ug,
  insert_hydration: Hg,
  noop: Gg,
  safe_not_equal: jg,
  svg_element: Vg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Yg,
  append_hydration: Wg,
  attr: Zg,
  children: Xg,
  claim_svg_element: Kg,
  detach: Qg,
  init: Jg,
  insert_hydration: e0,
  noop: t0,
  safe_not_equal: n0,
  svg_element: i0
} = window.__gradio__svelte__internal, {
  SvelteComponent: a0,
  append_hydration: l0,
  attr: o0,
  children: r0,
  claim_svg_element: s0,
  detach: u0,
  init: c0,
  insert_hydration: d0,
  noop: _0,
  safe_not_equal: f0,
  svg_element: p0
} = window.__gradio__svelte__internal, {
  SvelteComponent: h0,
  append_hydration: m0,
  attr: g0,
  children: b0,
  claim_svg_element: v0,
  detach: D0,
  init: y0,
  insert_hydration: E0,
  noop: w0,
  safe_not_equal: k0,
  svg_element: F0
} = window.__gradio__svelte__internal, {
  SvelteComponent: $0,
  append_hydration: A0,
  attr: C0,
  children: S0,
  claim_svg_element: T0,
  detach: I0,
  init: R0,
  insert_hydration: x0,
  noop: L0,
  safe_not_equal: N0,
  svg_element: O0
} = window.__gradio__svelte__internal, {
  SvelteComponent: B0,
  append_hydration: M0,
  attr: P0,
  children: q0,
  claim_svg_element: z0,
  detach: U0,
  init: H0,
  insert_hydration: G0,
  noop: j0,
  safe_not_equal: V0,
  svg_element: Y0
} = window.__gradio__svelte__internal, {
  SvelteComponent: W0,
  append_hydration: Z0,
  attr: X0,
  children: K0,
  claim_svg_element: Q0,
  detach: J0,
  init: e1,
  insert_hydration: t1,
  noop: n1,
  safe_not_equal: i1,
  svg_element: a1
} = window.__gradio__svelte__internal, {
  SvelteComponent: l1,
  append_hydration: o1,
  attr: r1,
  children: s1,
  claim_svg_element: u1,
  detach: c1,
  init: d1,
  insert_hydration: _1,
  noop: f1,
  safe_not_equal: p1,
  svg_element: h1
} = window.__gradio__svelte__internal, {
  SvelteComponent: m1,
  append_hydration: g1,
  attr: b1,
  children: v1,
  claim_svg_element: D1,
  detach: y1,
  init: E1,
  insert_hydration: w1,
  noop: k1,
  safe_not_equal: F1,
  svg_element: $1
} = window.__gradio__svelte__internal, {
  SvelteComponent: A1,
  append_hydration: C1,
  attr: S1,
  children: T1,
  claim_svg_element: I1,
  detach: R1,
  init: x1,
  insert_hydration: L1,
  noop: N1,
  safe_not_equal: O1,
  svg_element: B1
} = window.__gradio__svelte__internal, {
  SvelteComponent: M1,
  append_hydration: P1,
  attr: q1,
  children: z1,
  claim_svg_element: U1,
  detach: H1,
  init: G1,
  insert_hydration: j1,
  noop: V1,
  safe_not_equal: Y1,
  svg_element: W1
} = window.__gradio__svelte__internal, {
  SvelteComponent: Z1,
  append_hydration: X1,
  attr: K1,
  children: Q1,
  claim_svg_element: J1,
  detach: eb,
  init: tb,
  insert_hydration: nb,
  noop: ib,
  safe_not_equal: ab,
  set_style: lb,
  svg_element: ob
} = window.__gradio__svelte__internal, {
  SvelteComponent: rb,
  append_hydration: sb,
  attr: ub,
  children: cb,
  claim_svg_element: db,
  detach: _b,
  init: fb,
  insert_hydration: pb,
  noop: hb,
  safe_not_equal: mb,
  svg_element: gb
} = window.__gradio__svelte__internal, {
  SvelteComponent: bb,
  append_hydration: vb,
  attr: Db,
  children: yb,
  claim_svg_element: Eb,
  detach: wb,
  init: kb,
  insert_hydration: Fb,
  noop: $b,
  safe_not_equal: Ab,
  svg_element: Cb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Sb,
  append_hydration: Tb,
  attr: Ib,
  children: Rb,
  claim_svg_element: xb,
  detach: Lb,
  init: Nb,
  insert_hydration: Ob,
  noop: Bb,
  safe_not_equal: Mb,
  svg_element: Pb
} = window.__gradio__svelte__internal, {
  SvelteComponent: qb,
  append_hydration: zb,
  attr: Ub,
  children: Hb,
  claim_svg_element: Gb,
  detach: jb,
  init: Vb,
  insert_hydration: Yb,
  noop: Wb,
  safe_not_equal: Zb,
  svg_element: Xb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Kb,
  append_hydration: Qb,
  attr: Jb,
  children: ev,
  claim_svg_element: tv,
  detach: nv,
  init: iv,
  insert_hydration: av,
  noop: lv,
  safe_not_equal: ov,
  svg_element: rv
} = window.__gradio__svelte__internal, {
  SvelteComponent: sv,
  append_hydration: uv,
  attr: cv,
  children: dv,
  claim_svg_element: _v,
  detach: fv,
  init: pv,
  insert_hydration: hv,
  noop: mv,
  safe_not_equal: gv,
  svg_element: bv
} = window.__gradio__svelte__internal, {
  SvelteComponent: vv,
  append_hydration: Dv,
  attr: yv,
  children: Ev,
  claim_svg_element: wv,
  detach: kv,
  init: Fv,
  insert_hydration: $v,
  noop: Av,
  safe_not_equal: Cv,
  svg_element: Sv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Tv,
  append_hydration: Iv,
  attr: Rv,
  children: xv,
  claim_svg_element: Lv,
  detach: Nv,
  init: Ov,
  insert_hydration: Bv,
  noop: Mv,
  safe_not_equal: Pv,
  svg_element: qv
} = window.__gradio__svelte__internal, {
  SvelteComponent: zv,
  append_hydration: Uv,
  attr: Hv,
  children: Gv,
  claim_svg_element: jv,
  claim_text: Vv,
  detach: Yv,
  init: Wv,
  insert_hydration: Zv,
  noop: Xv,
  safe_not_equal: Kv,
  svg_element: Qv,
  text: Jv
} = window.__gradio__svelte__internal, {
  SvelteComponent: eD,
  append_hydration: tD,
  attr: nD,
  children: iD,
  claim_svg_element: aD,
  detach: lD,
  init: oD,
  insert_hydration: rD,
  noop: sD,
  safe_not_equal: uD,
  svg_element: cD
} = window.__gradio__svelte__internal, {
  SvelteComponent: dD,
  append_hydration: _D,
  attr: fD,
  children: pD,
  claim_svg_element: hD,
  detach: mD,
  init: gD,
  insert_hydration: bD,
  noop: vD,
  safe_not_equal: DD,
  svg_element: yD
} = window.__gradio__svelte__internal, {
  SvelteComponent: ED,
  append_hydration: wD,
  attr: kD,
  children: FD,
  claim_svg_element: $D,
  detach: AD,
  init: CD,
  insert_hydration: SD,
  noop: TD,
  safe_not_equal: ID,
  svg_element: RD
} = window.__gradio__svelte__internal, {
  SvelteComponent: xD,
  append_hydration: LD,
  attr: ND,
  children: OD,
  claim_svg_element: BD,
  detach: MD,
  init: PD,
  insert_hydration: qD,
  noop: zD,
  safe_not_equal: UD,
  svg_element: HD
} = window.__gradio__svelte__internal, {
  SvelteComponent: GD,
  append_hydration: jD,
  attr: VD,
  children: YD,
  claim_svg_element: WD,
  detach: ZD,
  init: XD,
  insert_hydration: KD,
  noop: QD,
  safe_not_equal: JD,
  svg_element: ey
} = window.__gradio__svelte__internal, {
  SvelteComponent: ty,
  append_hydration: ny,
  attr: iy,
  children: ay,
  claim_svg_element: ly,
  detach: oy,
  init: ry,
  insert_hydration: sy,
  noop: uy,
  safe_not_equal: cy,
  svg_element: dy
} = window.__gradio__svelte__internal, {
  SvelteComponent: _y,
  append_hydration: fy,
  attr: py,
  children: hy,
  claim_svg_element: my,
  detach: gy,
  init: by,
  insert_hydration: vy,
  noop: Dy,
  safe_not_equal: yy,
  svg_element: Ey
} = window.__gradio__svelte__internal, {
  SvelteComponent: wy,
  append_hydration: ky,
  attr: Fy,
  children: $y,
  claim_svg_element: Ay,
  claim_text: Cy,
  detach: Sy,
  init: Ty,
  insert_hydration: Iy,
  noop: Ry,
  safe_not_equal: xy,
  svg_element: Ly,
  text: Ny
} = window.__gradio__svelte__internal, {
  SvelteComponent: Oy,
  append_hydration: By,
  attr: My,
  children: Py,
  claim_svg_element: qy,
  claim_text: zy,
  detach: Uy,
  init: Hy,
  insert_hydration: Gy,
  noop: jy,
  safe_not_equal: Vy,
  svg_element: Yy,
  text: Wy
} = window.__gradio__svelte__internal, {
  SvelteComponent: Zy,
  append_hydration: Xy,
  attr: Ky,
  children: Qy,
  claim_svg_element: Jy,
  claim_text: eE,
  detach: tE,
  init: nE,
  insert_hydration: iE,
  noop: aE,
  safe_not_equal: lE,
  svg_element: oE,
  text: rE
} = window.__gradio__svelte__internal, {
  SvelteComponent: sE,
  append_hydration: uE,
  attr: cE,
  children: dE,
  claim_svg_element: _E,
  detach: fE,
  init: pE,
  insert_hydration: hE,
  noop: mE,
  safe_not_equal: gE,
  svg_element: bE
} = window.__gradio__svelte__internal, {
  SvelteComponent: vE,
  append_hydration: DE,
  attr: yE,
  children: EE,
  claim_svg_element: wE,
  detach: kE,
  init: FE,
  insert_hydration: $E,
  noop: AE,
  safe_not_equal: CE,
  svg_element: SE
} = window.__gradio__svelte__internal, {
  SvelteComponent: TE,
  append_hydration: IE,
  attr: RE,
  children: xE,
  claim_svg_element: LE,
  detach: NE,
  init: OE,
  insert_hydration: BE,
  noop: ME,
  safe_not_equal: PE,
  svg_element: qE
} = window.__gradio__svelte__internal, {
  SvelteComponent: zE,
  append_hydration: UE,
  attr: HE,
  children: GE,
  claim_svg_element: jE,
  detach: VE,
  init: YE,
  insert_hydration: WE,
  noop: ZE,
  safe_not_equal: XE,
  svg_element: KE
} = window.__gradio__svelte__internal, {
  SvelteComponent: QE,
  append_hydration: JE,
  attr: ew,
  children: tw,
  claim_svg_element: nw,
  detach: iw,
  init: aw,
  insert_hydration: lw,
  noop: ow,
  safe_not_equal: rw,
  svg_element: sw
} = window.__gradio__svelte__internal, {
  SvelteComponent: uw,
  append_hydration: cw,
  attr: dw,
  children: _w,
  claim_svg_element: fw,
  detach: pw,
  init: hw,
  insert_hydration: mw,
  noop: gw,
  safe_not_equal: bw,
  svg_element: vw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Dw,
  append_hydration: yw,
  attr: Ew,
  children: ww,
  claim_svg_element: kw,
  detach: Fw,
  init: $w,
  insert_hydration: Aw,
  noop: Cw,
  safe_not_equal: Sw,
  svg_element: Tw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Iw,
  append_hydration: Rw,
  attr: xw,
  children: Lw,
  claim_svg_element: Nw,
  detach: Ow,
  init: Bw,
  insert_hydration: Mw,
  noop: Pw,
  safe_not_equal: qw,
  svg_element: zw
} = window.__gradio__svelte__internal, wr = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], ta = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
wr.reduce(
  (i, { color: e, primary: t, secondary: n }) => ({
    ...i,
    [e]: {
      primary: ta[e][t],
      secondary: ta[e][n]
    }
  }),
  {}
);
const {
  SvelteComponent: Uw,
  claim_component: Hw,
  create_component: Gw,
  destroy_component: jw,
  init: Vw,
  mount_component: Yw,
  safe_not_equal: Ww,
  transition_in: Zw,
  transition_out: Xw
} = window.__gradio__svelte__internal, { createEventDispatcher: Kw } = window.__gradio__svelte__internal, {
  SvelteComponent: Qw,
  append_hydration: Jw,
  attr: ek,
  check_outros: tk,
  children: nk,
  claim_component: ik,
  claim_element: ak,
  claim_space: lk,
  claim_text: ok,
  create_component: rk,
  destroy_component: sk,
  detach: uk,
  element: ck,
  empty: dk,
  group_outros: _k,
  init: fk,
  insert_hydration: pk,
  mount_component: hk,
  safe_not_equal: mk,
  set_data: gk,
  space: bk,
  text: vk,
  toggle_class: Dk,
  transition_in: yk,
  transition_out: Ek
} = window.__gradio__svelte__internal, {
  SvelteComponent: wk,
  attr: kk,
  children: Fk,
  claim_element: $k,
  create_slot: Ak,
  detach: Ck,
  element: Sk,
  get_all_dirty_from_scope: Tk,
  get_slot_changes: Ik,
  init: Rk,
  insert_hydration: xk,
  safe_not_equal: Lk,
  toggle_class: Nk,
  transition_in: Ok,
  transition_out: Bk,
  update_slot_base: Mk
} = window.__gradio__svelte__internal, {
  SvelteComponent: Pk,
  append_hydration: qk,
  attr: zk,
  check_outros: Uk,
  children: Hk,
  claim_component: Gk,
  claim_element: jk,
  claim_space: Vk,
  create_component: Yk,
  destroy_component: Wk,
  detach: Zk,
  element: Xk,
  empty: Kk,
  group_outros: Qk,
  init: Jk,
  insert_hydration: eF,
  listen: tF,
  mount_component: nF,
  safe_not_equal: iF,
  space: aF,
  toggle_class: lF,
  transition_in: oF,
  transition_out: rF
} = window.__gradio__svelte__internal, {
  SvelteComponent: sF,
  attr: uF,
  children: cF,
  claim_element: dF,
  create_slot: _F,
  detach: fF,
  element: pF,
  get_all_dirty_from_scope: hF,
  get_slot_changes: mF,
  init: gF,
  insert_hydration: bF,
  null_to_empty: vF,
  safe_not_equal: DF,
  transition_in: yF,
  transition_out: EF,
  update_slot_base: wF
} = window.__gradio__svelte__internal, {
  SvelteComponent: kF,
  check_outros: FF,
  claim_component: $F,
  create_component: AF,
  destroy_component: CF,
  detach: SF,
  empty: TF,
  group_outros: IF,
  init: RF,
  insert_hydration: xF,
  mount_component: LF,
  noop: NF,
  safe_not_equal: OF,
  transition_in: BF,
  transition_out: MF
} = window.__gradio__svelte__internal, { createEventDispatcher: PF } = window.__gradio__svelte__internal;
function Ht(i) {
  let e = ["", "k", "M", "G", "T", "P", "E", "Z"], t = 0;
  for (; i > 1e3 && t < e.length - 1; )
    i /= 1e3, t++;
  let n = e[t];
  return (Number.isInteger(i) ? i : i.toFixed(1)) + n;
}
function An() {
}
const pl = typeof window < "u";
let na = pl ? () => window.performance.now() : () => Date.now(), hl = pl ? (i) => requestAnimationFrame(i) : An;
const Gt = /* @__PURE__ */ new Set();
function ml(i) {
  Gt.forEach((e) => {
    e.c(i) || (Gt.delete(e), e.f());
  }), Gt.size !== 0 && hl(ml);
}
function kr(i) {
  let e;
  return Gt.size === 0 && hl(ml), { promise: new Promise((t) => {
    Gt.add(e = { c: i, f: t });
  }), abort() {
    Gt.delete(e);
  } };
}
const zt = [];
function Fr(i, e = An) {
  let t;
  const n = /* @__PURE__ */ new Set();
  function a(l) {
    if (s = l, ((r = i) != r ? s == s : r !== s || r && typeof r == "object" || typeof r == "function") && (i = l, t)) {
      const u = !zt.length;
      for (const c of n) c[1](), zt.push(c, i);
      if (u) {
        for (let c = 0; c < zt.length; c += 2) zt[c][0](zt[c + 1]);
        zt.length = 0;
      }
    }
    var r, s;
  }
  function o(l) {
    a(l(i));
  }
  return { set: a, update: o, subscribe: function(l, r = An) {
    const s = [l, r];
    return n.add(s), n.size === 1 && (t = e(a, o) || An), l(i), () => {
      n.delete(s), n.size === 0 && t && (t(), t = null);
    };
  } };
}
function ia(i) {
  return Object.prototype.toString.call(i) === "[object Date]";
}
function si(i, e, t, n) {
  if (typeof t == "number" || ia(t)) {
    const a = n - t, o = (t - e) / (i.dt || 1 / 60), l = (o + (i.opts.stiffness * a - i.opts.damping * o) * i.inv_mass) * i.dt;
    return Math.abs(l) < i.opts.precision && Math.abs(a) < i.opts.precision ? n : (i.settled = !1, ia(t) ? new Date(t.getTime() + l) : t + l);
  }
  if (Array.isArray(t)) return t.map((a, o) => si(i, e[o], t[o], n[o]));
  if (typeof t == "object") {
    const a = {};
    for (const o in t) a[o] = si(i, e[o], t[o], n[o]);
    return a;
  }
  throw new Error(`Cannot spring ${typeof t} values`);
}
function aa(i, e = {}) {
  const t = Fr(i), { stiffness: n = 0.15, damping: a = 0.8, precision: o = 0.01 } = e;
  let l, r, s, u = i, c = i, g = 1, _ = 0, m = !1;
  function b(y, x = {}) {
    c = y;
    const p = s = {};
    return i == null || x.hard || w.stiffness >= 1 && w.damping >= 1 ? (m = !0, l = na(), u = y, t.set(i = c), Promise.resolve()) : (x.soft && (_ = 1 / (60 * (x.soft === !0 ? 0.5 : +x.soft)), g = 0), r || (l = na(), m = !1, r = kr((d) => {
      if (m) return m = !1, r = null, !1;
      g = Math.min(g + _, 1);
      const h = { inv_mass: g, opts: w, settled: !0, dt: 60 * (d - l) / 1e3 }, D = si(h, u, i, c);
      return l = d, u = i, t.set(i = D), h.settled && (r = null), !h.settled;
    })), new Promise((d) => {
      r.promise.then(() => {
        p === s && d();
      });
    }));
  }
  const w = { set: b, update: (y, x) => b(y(c, i), x), subscribe: t.subscribe, stiffness: n, damping: a, precision: o };
  return w;
}
const {
  SvelteComponent: $r,
  append_hydration: tt,
  attr: ee,
  children: Ge,
  claim_element: Ar,
  claim_svg_element: nt,
  component_subscribe: la,
  detach: ze,
  element: Cr,
  init: Sr,
  insert_hydration: Tr,
  noop: oa,
  safe_not_equal: Ir,
  set_style: En,
  svg_element: it,
  toggle_class: ra
} = window.__gradio__svelte__internal, { onMount: Rr } = window.__gradio__svelte__internal;
function xr(i) {
  let e, t, n, a, o, l, r, s, u, c, g, _;
  return {
    c() {
      e = Cr("div"), t = it("svg"), n = it("g"), a = it("path"), o = it("path"), l = it("path"), r = it("path"), s = it("g"), u = it("path"), c = it("path"), g = it("path"), _ = it("path"), this.h();
    },
    l(m) {
      e = Ar(m, "DIV", { class: !0 });
      var b = Ge(e);
      t = nt(b, "svg", {
        viewBox: !0,
        fill: !0,
        xmlns: !0,
        class: !0
      });
      var w = Ge(t);
      n = nt(w, "g", { style: !0 });
      var y = Ge(n);
      a = nt(y, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), Ge(a).forEach(ze), o = nt(y, "path", { d: !0, fill: !0, class: !0 }), Ge(o).forEach(ze), l = nt(y, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), Ge(l).forEach(ze), r = nt(y, "path", { d: !0, fill: !0, class: !0 }), Ge(r).forEach(ze), y.forEach(ze), s = nt(w, "g", { style: !0 });
      var x = Ge(s);
      u = nt(x, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), Ge(u).forEach(ze), c = nt(x, "path", { d: !0, fill: !0, class: !0 }), Ge(c).forEach(ze), g = nt(x, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), Ge(g).forEach(ze), _ = nt(x, "path", { d: !0, fill: !0, class: !0 }), Ge(_).forEach(ze), x.forEach(ze), w.forEach(ze), b.forEach(ze), this.h();
    },
    h() {
      ee(a, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), ee(a, "fill", "#FF7C00"), ee(a, "fill-opacity", "0.4"), ee(a, "class", "svelte-43sxxs"), ee(o, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), ee(o, "fill", "#FF7C00"), ee(o, "class", "svelte-43sxxs"), ee(l, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), ee(l, "fill", "#FF7C00"), ee(l, "fill-opacity", "0.4"), ee(l, "class", "svelte-43sxxs"), ee(r, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), ee(r, "fill", "#FF7C00"), ee(r, "class", "svelte-43sxxs"), En(n, "transform", "translate(" + /*$top*/
      i[1][0] + "px, " + /*$top*/
      i[1][1] + "px)"), ee(u, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), ee(u, "fill", "#FF7C00"), ee(u, "fill-opacity", "0.4"), ee(u, "class", "svelte-43sxxs"), ee(c, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), ee(c, "fill", "#FF7C00"), ee(c, "class", "svelte-43sxxs"), ee(g, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), ee(g, "fill", "#FF7C00"), ee(g, "fill-opacity", "0.4"), ee(g, "class", "svelte-43sxxs"), ee(_, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), ee(_, "fill", "#FF7C00"), ee(_, "class", "svelte-43sxxs"), En(s, "transform", "translate(" + /*$bottom*/
      i[2][0] + "px, " + /*$bottom*/
      i[2][1] + "px)"), ee(t, "viewBox", "-1200 -1200 3000 3000"), ee(t, "fill", "none"), ee(t, "xmlns", "http://www.w3.org/2000/svg"), ee(t, "class", "svelte-43sxxs"), ee(e, "class", "svelte-43sxxs"), ra(
        e,
        "margin",
        /*margin*/
        i[0]
      );
    },
    m(m, b) {
      Tr(m, e, b), tt(e, t), tt(t, n), tt(n, a), tt(n, o), tt(n, l), tt(n, r), tt(t, s), tt(s, u), tt(s, c), tt(s, g), tt(s, _);
    },
    p(m, [b]) {
      b & /*$top*/
      2 && En(n, "transform", "translate(" + /*$top*/
      m[1][0] + "px, " + /*$top*/
      m[1][1] + "px)"), b & /*$bottom*/
      4 && En(s, "transform", "translate(" + /*$bottom*/
      m[2][0] + "px, " + /*$bottom*/
      m[2][1] + "px)"), b & /*margin*/
      1 && ra(
        e,
        "margin",
        /*margin*/
        m[0]
      );
    },
    i: oa,
    o: oa,
    d(m) {
      m && ze(e);
    }
  };
}
function Lr(i, e, t) {
  let n, a, { margin: o = !0 } = e;
  const l = aa([0, 0]);
  la(i, l, (_) => t(1, n = _));
  const r = aa([0, 0]);
  la(i, r, (_) => t(2, a = _));
  let s;
  async function u() {
    await Promise.all([l.set([125, 140]), r.set([-125, -140])]), await Promise.all([l.set([-125, 140]), r.set([125, -140])]), await Promise.all([l.set([-125, 0]), r.set([125, -0])]), await Promise.all([l.set([125, 0]), r.set([-125, 0])]);
  }
  async function c() {
    await u(), s || c();
  }
  async function g() {
    await Promise.all([l.set([125, 0]), r.set([-125, 0])]), c();
  }
  return Rr(() => (g(), () => s = !0)), i.$$set = (_) => {
    "margin" in _ && t(0, o = _.margin);
  }, [o, n, a, l, r];
}
class Nr extends $r {
  constructor(e) {
    super(), Sr(this, e, Lr, xr, Ir, { margin: 0 });
  }
}
const {
  SvelteComponent: Or,
  append_hydration: It,
  attr: ot,
  binding_callbacks: sa,
  check_outros: ui,
  children: _t,
  claim_component: gl,
  claim_element: ft,
  claim_space: Ve,
  claim_text: be,
  create_component: bl,
  create_slot: vl,
  destroy_component: Dl,
  destroy_each: yl,
  detach: z,
  element: pt,
  empty: We,
  ensure_array_like: xn,
  get_all_dirty_from_scope: El,
  get_slot_changes: wl,
  group_outros: ci,
  init: Br,
  insert_hydration: G,
  mount_component: kl,
  noop: di,
  safe_not_equal: Mr,
  set_data: Ze,
  set_style: At,
  space: Ye,
  text: ve,
  toggle_class: je,
  transition_in: lt,
  transition_out: ht,
  update_slot_base: Fl
} = window.__gradio__svelte__internal, { tick: Pr } = window.__gradio__svelte__internal, { onDestroy: qr } = window.__gradio__svelte__internal, { createEventDispatcher: zr } = window.__gradio__svelte__internal, Ur = (i) => ({}), ua = (i) => ({}), Hr = (i) => ({}), ca = (i) => ({});
function da(i, e, t) {
  const n = i.slice();
  return n[40] = e[t], n[42] = t, n;
}
function _a(i, e, t) {
  const n = i.slice();
  return n[40] = e[t], n;
}
function Gr(i) {
  let e, t, n, a, o = (
    /*i18n*/
    i[1]("common.error") + ""
  ), l, r, s;
  t = new mr({
    props: {
      Icon: Er,
      label: (
        /*i18n*/
        i[1]("common.clear")
      ),
      disabled: !1
    }
  }), t.$on(
    "click",
    /*click_handler*/
    i[32]
  );
  const u = (
    /*#slots*/
    i[30].error
  ), c = vl(
    u,
    i,
    /*$$scope*/
    i[29],
    ua
  );
  return {
    c() {
      e = pt("div"), bl(t.$$.fragment), n = Ye(), a = pt("span"), l = ve(o), r = Ye(), c && c.c(), this.h();
    },
    l(g) {
      e = ft(g, "DIV", { class: !0 });
      var _ = _t(e);
      gl(t.$$.fragment, _), _.forEach(z), n = Ve(g), a = ft(g, "SPAN", { class: !0 });
      var m = _t(a);
      l = be(m, o), m.forEach(z), r = Ve(g), c && c.l(g), this.h();
    },
    h() {
      ot(e, "class", "clear-status svelte-17v219f"), ot(a, "class", "error svelte-17v219f");
    },
    m(g, _) {
      G(g, e, _), kl(t, e, null), G(g, n, _), G(g, a, _), It(a, l), G(g, r, _), c && c.m(g, _), s = !0;
    },
    p(g, _) {
      const m = {};
      _[0] & /*i18n*/
      2 && (m.label = /*i18n*/
      g[1]("common.clear")), t.$set(m), (!s || _[0] & /*i18n*/
      2) && o !== (o = /*i18n*/
      g[1]("common.error") + "") && Ze(l, o), c && c.p && (!s || _[0] & /*$$scope*/
      536870912) && Fl(
        c,
        u,
        g,
        /*$$scope*/
        g[29],
        s ? wl(
          u,
          /*$$scope*/
          g[29],
          _,
          Ur
        ) : El(
          /*$$scope*/
          g[29]
        ),
        ua
      );
    },
    i(g) {
      s || (lt(t.$$.fragment, g), lt(c, g), s = !0);
    },
    o(g) {
      ht(t.$$.fragment, g), ht(c, g), s = !1;
    },
    d(g) {
      g && (z(e), z(n), z(a), z(r)), Dl(t), c && c.d(g);
    }
  };
}
function jr(i) {
  let e, t, n, a, o, l, r, s, u, c = (
    /*variant*/
    i[8] === "default" && /*show_eta_bar*/
    i[18] && /*show_progress*/
    i[6] === "full" && fa(i)
  );
  function g(d, h) {
    if (
      /*progress*/
      d[7]
    ) return Wr;
    if (
      /*queue_position*/
      d[2] !== null && /*queue_size*/
      d[3] !== void 0 && /*queue_position*/
      d[2] >= 0
    ) return Yr;
    if (
      /*queue_position*/
      d[2] === 0
    ) return Vr;
  }
  let _ = g(i), m = _ && _(i), b = (
    /*timer*/
    i[5] && ma(i)
  );
  const w = [Qr, Kr], y = [];
  function x(d, h) {
    return (
      /*last_progress_level*/
      d[15] != null ? 0 : (
        /*show_progress*/
        d[6] === "full" ? 1 : -1
      )
    );
  }
  ~(o = x(i)) && (l = y[o] = w[o](i));
  let p = !/*timer*/
  i[5] && wa(i);
  return {
    c() {
      c && c.c(), e = Ye(), t = pt("div"), m && m.c(), n = Ye(), b && b.c(), a = Ye(), l && l.c(), r = Ye(), p && p.c(), s = We(), this.h();
    },
    l(d) {
      c && c.l(d), e = Ve(d), t = ft(d, "DIV", { class: !0 });
      var h = _t(t);
      m && m.l(h), n = Ve(h), b && b.l(h), h.forEach(z), a = Ve(d), l && l.l(d), r = Ve(d), p && p.l(d), s = We(), this.h();
    },
    h() {
      ot(t, "class", "progress-text svelte-17v219f"), je(
        t,
        "meta-text-center",
        /*variant*/
        i[8] === "center"
      ), je(
        t,
        "meta-text",
        /*variant*/
        i[8] === "default"
      );
    },
    m(d, h) {
      c && c.m(d, h), G(d, e, h), G(d, t, h), m && m.m(t, null), It(t, n), b && b.m(t, null), G(d, a, h), ~o && y[o].m(d, h), G(d, r, h), p && p.m(d, h), G(d, s, h), u = !0;
    },
    p(d, h) {
      /*variant*/
      d[8] === "default" && /*show_eta_bar*/
      d[18] && /*show_progress*/
      d[6] === "full" ? c ? c.p(d, h) : (c = fa(d), c.c(), c.m(e.parentNode, e)) : c && (c.d(1), c = null), _ === (_ = g(d)) && m ? m.p(d, h) : (m && m.d(1), m = _ && _(d), m && (m.c(), m.m(t, n))), /*timer*/
      d[5] ? b ? b.p(d, h) : (b = ma(d), b.c(), b.m(t, null)) : b && (b.d(1), b = null), (!u || h[0] & /*variant*/
      256) && je(
        t,
        "meta-text-center",
        /*variant*/
        d[8] === "center"
      ), (!u || h[0] & /*variant*/
      256) && je(
        t,
        "meta-text",
        /*variant*/
        d[8] === "default"
      );
      let D = o;
      o = x(d), o === D ? ~o && y[o].p(d, h) : (l && (ci(), ht(y[D], 1, 1, () => {
        y[D] = null;
      }), ui()), ~o ? (l = y[o], l ? l.p(d, h) : (l = y[o] = w[o](d), l.c()), lt(l, 1), l.m(r.parentNode, r)) : l = null), /*timer*/
      d[5] ? p && (ci(), ht(p, 1, 1, () => {
        p = null;
      }), ui()) : p ? (p.p(d, h), h[0] & /*timer*/
      32 && lt(p, 1)) : (p = wa(d), p.c(), lt(p, 1), p.m(s.parentNode, s));
    },
    i(d) {
      u || (lt(l), lt(p), u = !0);
    },
    o(d) {
      ht(l), ht(p), u = !1;
    },
    d(d) {
      d && (z(e), z(t), z(a), z(r), z(s)), c && c.d(d), m && m.d(), b && b.d(), ~o && y[o].d(d), p && p.d(d);
    }
  };
}
function fa(i) {
  let e, t = `translateX(${/*eta_level*/
  (i[17] || 0) * 100 - 100}%)`;
  return {
    c() {
      e = pt("div"), this.h();
    },
    l(n) {
      e = ft(n, "DIV", { class: !0 }), _t(e).forEach(z), this.h();
    },
    h() {
      ot(e, "class", "eta-bar svelte-17v219f"), At(e, "transform", t);
    },
    m(n, a) {
      G(n, e, a);
    },
    p(n, a) {
      a[0] & /*eta_level*/
      131072 && t !== (t = `translateX(${/*eta_level*/
      (n[17] || 0) * 100 - 100}%)`) && At(e, "transform", t);
    },
    d(n) {
      n && z(e);
    }
  };
}
function Vr(i) {
  let e;
  return {
    c() {
      e = ve("processing |");
    },
    l(t) {
      e = be(t, "processing |");
    },
    m(t, n) {
      G(t, e, n);
    },
    p: di,
    d(t) {
      t && z(e);
    }
  };
}
function Yr(i) {
  let e, t = (
    /*queue_position*/
    i[2] + 1 + ""
  ), n, a, o, l;
  return {
    c() {
      e = ve("queue: "), n = ve(t), a = ve("/"), o = ve(
        /*queue_size*/
        i[3]
      ), l = ve(" |");
    },
    l(r) {
      e = be(r, "queue: "), n = be(r, t), a = be(r, "/"), o = be(
        r,
        /*queue_size*/
        i[3]
      ), l = be(r, " |");
    },
    m(r, s) {
      G(r, e, s), G(r, n, s), G(r, a, s), G(r, o, s), G(r, l, s);
    },
    p(r, s) {
      s[0] & /*queue_position*/
      4 && t !== (t = /*queue_position*/
      r[2] + 1 + "") && Ze(n, t), s[0] & /*queue_size*/
      8 && Ze(
        o,
        /*queue_size*/
        r[3]
      );
    },
    d(r) {
      r && (z(e), z(n), z(a), z(o), z(l));
    }
  };
}
function Wr(i) {
  let e, t = xn(
    /*progress*/
    i[7]
  ), n = [];
  for (let a = 0; a < t.length; a += 1)
    n[a] = ha(_a(i, t, a));
  return {
    c() {
      for (let a = 0; a < n.length; a += 1)
        n[a].c();
      e = We();
    },
    l(a) {
      for (let o = 0; o < n.length; o += 1)
        n[o].l(a);
      e = We();
    },
    m(a, o) {
      for (let l = 0; l < n.length; l += 1)
        n[l] && n[l].m(a, o);
      G(a, e, o);
    },
    p(a, o) {
      if (o[0] & /*progress*/
      128) {
        t = xn(
          /*progress*/
          a[7]
        );
        let l;
        for (l = 0; l < t.length; l += 1) {
          const r = _a(a, t, l);
          n[l] ? n[l].p(r, o) : (n[l] = ha(r), n[l].c(), n[l].m(e.parentNode, e));
        }
        for (; l < n.length; l += 1)
          n[l].d(1);
        n.length = t.length;
      }
    },
    d(a) {
      a && z(e), yl(n, a);
    }
  };
}
function pa(i) {
  let e, t = (
    /*p*/
    i[40].unit + ""
  ), n, a, o = " ", l;
  function r(c, g) {
    return (
      /*p*/
      c[40].length != null ? Xr : Zr
    );
  }
  let s = r(i), u = s(i);
  return {
    c() {
      u.c(), e = Ye(), n = ve(t), a = ve(" | "), l = ve(o);
    },
    l(c) {
      u.l(c), e = Ve(c), n = be(c, t), a = be(c, " | "), l = be(c, o);
    },
    m(c, g) {
      u.m(c, g), G(c, e, g), G(c, n, g), G(c, a, g), G(c, l, g);
    },
    p(c, g) {
      s === (s = r(c)) && u ? u.p(c, g) : (u.d(1), u = s(c), u && (u.c(), u.m(e.parentNode, e))), g[0] & /*progress*/
      128 && t !== (t = /*p*/
      c[40].unit + "") && Ze(n, t);
    },
    d(c) {
      c && (z(e), z(n), z(a), z(l)), u.d(c);
    }
  };
}
function Zr(i) {
  let e = Ht(
    /*p*/
    i[40].index || 0
  ) + "", t;
  return {
    c() {
      t = ve(e);
    },
    l(n) {
      t = be(n, e);
    },
    m(n, a) {
      G(n, t, a);
    },
    p(n, a) {
      a[0] & /*progress*/
      128 && e !== (e = Ht(
        /*p*/
        n[40].index || 0
      ) + "") && Ze(t, e);
    },
    d(n) {
      n && z(t);
    }
  };
}
function Xr(i) {
  let e = Ht(
    /*p*/
    i[40].index || 0
  ) + "", t, n, a = Ht(
    /*p*/
    i[40].length
  ) + "", o;
  return {
    c() {
      t = ve(e), n = ve("/"), o = ve(a);
    },
    l(l) {
      t = be(l, e), n = be(l, "/"), o = be(l, a);
    },
    m(l, r) {
      G(l, t, r), G(l, n, r), G(l, o, r);
    },
    p(l, r) {
      r[0] & /*progress*/
      128 && e !== (e = Ht(
        /*p*/
        l[40].index || 0
      ) + "") && Ze(t, e), r[0] & /*progress*/
      128 && a !== (a = Ht(
        /*p*/
        l[40].length
      ) + "") && Ze(o, a);
    },
    d(l) {
      l && (z(t), z(n), z(o));
    }
  };
}
function ha(i) {
  let e, t = (
    /*p*/
    i[40].index != null && pa(i)
  );
  return {
    c() {
      t && t.c(), e = We();
    },
    l(n) {
      t && t.l(n), e = We();
    },
    m(n, a) {
      t && t.m(n, a), G(n, e, a);
    },
    p(n, a) {
      /*p*/
      n[40].index != null ? t ? t.p(n, a) : (t = pa(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && z(e), t && t.d(n);
    }
  };
}
function ma(i) {
  let e, t = (
    /*eta*/
    i[0] ? `/${/*formatted_eta*/
    i[19]}` : ""
  ), n, a;
  return {
    c() {
      e = ve(
        /*formatted_timer*/
        i[20]
      ), n = ve(t), a = ve("s");
    },
    l(o) {
      e = be(
        o,
        /*formatted_timer*/
        i[20]
      ), n = be(o, t), a = be(o, "s");
    },
    m(o, l) {
      G(o, e, l), G(o, n, l), G(o, a, l);
    },
    p(o, l) {
      l[0] & /*formatted_timer*/
      1048576 && Ze(
        e,
        /*formatted_timer*/
        o[20]
      ), l[0] & /*eta, formatted_eta*/
      524289 && t !== (t = /*eta*/
      o[0] ? `/${/*formatted_eta*/
      o[19]}` : "") && Ze(n, t);
    },
    d(o) {
      o && (z(e), z(n), z(a));
    }
  };
}
function Kr(i) {
  let e, t;
  return e = new Nr({
    props: { margin: (
      /*variant*/
      i[8] === "default"
    ) }
  }), {
    c() {
      bl(e.$$.fragment);
    },
    l(n) {
      gl(e.$$.fragment, n);
    },
    m(n, a) {
      kl(e, n, a), t = !0;
    },
    p(n, a) {
      const o = {};
      a[0] & /*variant*/
      256 && (o.margin = /*variant*/
      n[8] === "default"), e.$set(o);
    },
    i(n) {
      t || (lt(e.$$.fragment, n), t = !0);
    },
    o(n) {
      ht(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Dl(e, n);
    }
  };
}
function Qr(i) {
  let e, t, n, a, o, l = `${/*last_progress_level*/
  i[15] * 100}%`, r = (
    /*progress*/
    i[7] != null && ga(i)
  );
  return {
    c() {
      e = pt("div"), t = pt("div"), r && r.c(), n = Ye(), a = pt("div"), o = pt("div"), this.h();
    },
    l(s) {
      e = ft(s, "DIV", { class: !0 });
      var u = _t(e);
      t = ft(u, "DIV", { class: !0 });
      var c = _t(t);
      r && r.l(c), c.forEach(z), n = Ve(u), a = ft(u, "DIV", { class: !0 });
      var g = _t(a);
      o = ft(g, "DIV", { class: !0 }), _t(o).forEach(z), g.forEach(z), u.forEach(z), this.h();
    },
    h() {
      ot(t, "class", "progress-level-inner svelte-17v219f"), ot(o, "class", "progress-bar svelte-17v219f"), At(o, "width", l), ot(a, "class", "progress-bar-wrap svelte-17v219f"), ot(e, "class", "progress-level svelte-17v219f");
    },
    m(s, u) {
      G(s, e, u), It(e, t), r && r.m(t, null), It(e, n), It(e, a), It(a, o), i[31](o);
    },
    p(s, u) {
      /*progress*/
      s[7] != null ? r ? r.p(s, u) : (r = ga(s), r.c(), r.m(t, null)) : r && (r.d(1), r = null), u[0] & /*last_progress_level*/
      32768 && l !== (l = `${/*last_progress_level*/
      s[15] * 100}%`) && At(o, "width", l);
    },
    i: di,
    o: di,
    d(s) {
      s && z(e), r && r.d(), i[31](null);
    }
  };
}
function ga(i) {
  let e, t = xn(
    /*progress*/
    i[7]
  ), n = [];
  for (let a = 0; a < t.length; a += 1)
    n[a] = Ea(da(i, t, a));
  return {
    c() {
      for (let a = 0; a < n.length; a += 1)
        n[a].c();
      e = We();
    },
    l(a) {
      for (let o = 0; o < n.length; o += 1)
        n[o].l(a);
      e = We();
    },
    m(a, o) {
      for (let l = 0; l < n.length; l += 1)
        n[l] && n[l].m(a, o);
      G(a, e, o);
    },
    p(a, o) {
      if (o[0] & /*progress_level, progress*/
      16512) {
        t = xn(
          /*progress*/
          a[7]
        );
        let l;
        for (l = 0; l < t.length; l += 1) {
          const r = da(a, t, l);
          n[l] ? n[l].p(r, o) : (n[l] = Ea(r), n[l].c(), n[l].m(e.parentNode, e));
        }
        for (; l < n.length; l += 1)
          n[l].d(1);
        n.length = t.length;
      }
    },
    d(a) {
      a && z(e), yl(n, a);
    }
  };
}
function ba(i) {
  let e, t, n, a, o = (
    /*i*/
    i[42] !== 0 && Jr()
  ), l = (
    /*p*/
    i[40].desc != null && va(i)
  ), r = (
    /*p*/
    i[40].desc != null && /*progress_level*/
    i[14] && /*progress_level*/
    i[14][
      /*i*/
      i[42]
    ] != null && Da()
  ), s = (
    /*progress_level*/
    i[14] != null && ya(i)
  );
  return {
    c() {
      o && o.c(), e = Ye(), l && l.c(), t = Ye(), r && r.c(), n = Ye(), s && s.c(), a = We();
    },
    l(u) {
      o && o.l(u), e = Ve(u), l && l.l(u), t = Ve(u), r && r.l(u), n = Ve(u), s && s.l(u), a = We();
    },
    m(u, c) {
      o && o.m(u, c), G(u, e, c), l && l.m(u, c), G(u, t, c), r && r.m(u, c), G(u, n, c), s && s.m(u, c), G(u, a, c);
    },
    p(u, c) {
      /*p*/
      u[40].desc != null ? l ? l.p(u, c) : (l = va(u), l.c(), l.m(t.parentNode, t)) : l && (l.d(1), l = null), /*p*/
      u[40].desc != null && /*progress_level*/
      u[14] && /*progress_level*/
      u[14][
        /*i*/
        u[42]
      ] != null ? r || (r = Da(), r.c(), r.m(n.parentNode, n)) : r && (r.d(1), r = null), /*progress_level*/
      u[14] != null ? s ? s.p(u, c) : (s = ya(u), s.c(), s.m(a.parentNode, a)) : s && (s.d(1), s = null);
    },
    d(u) {
      u && (z(e), z(t), z(n), z(a)), o && o.d(u), l && l.d(u), r && r.d(u), s && s.d(u);
    }
  };
}
function Jr(i) {
  let e;
  return {
    c() {
      e = ve(" /");
    },
    l(t) {
      e = be(t, " /");
    },
    m(t, n) {
      G(t, e, n);
    },
    d(t) {
      t && z(e);
    }
  };
}
function va(i) {
  let e = (
    /*p*/
    i[40].desc + ""
  ), t;
  return {
    c() {
      t = ve(e);
    },
    l(n) {
      t = be(n, e);
    },
    m(n, a) {
      G(n, t, a);
    },
    p(n, a) {
      a[0] & /*progress*/
      128 && e !== (e = /*p*/
      n[40].desc + "") && Ze(t, e);
    },
    d(n) {
      n && z(t);
    }
  };
}
function Da(i) {
  let e;
  return {
    c() {
      e = ve("-");
    },
    l(t) {
      e = be(t, "-");
    },
    m(t, n) {
      G(t, e, n);
    },
    d(t) {
      t && z(e);
    }
  };
}
function ya(i) {
  let e = (100 * /*progress_level*/
  (i[14][
    /*i*/
    i[42]
  ] || 0)).toFixed(1) + "", t, n;
  return {
    c() {
      t = ve(e), n = ve("%");
    },
    l(a) {
      t = be(a, e), n = be(a, "%");
    },
    m(a, o) {
      G(a, t, o), G(a, n, o);
    },
    p(a, o) {
      o[0] & /*progress_level*/
      16384 && e !== (e = (100 * /*progress_level*/
      (a[14][
        /*i*/
        a[42]
      ] || 0)).toFixed(1) + "") && Ze(t, e);
    },
    d(a) {
      a && (z(t), z(n));
    }
  };
}
function Ea(i) {
  let e, t = (
    /*p*/
    (i[40].desc != null || /*progress_level*/
    i[14] && /*progress_level*/
    i[14][
      /*i*/
      i[42]
    ] != null) && ba(i)
  );
  return {
    c() {
      t && t.c(), e = We();
    },
    l(n) {
      t && t.l(n), e = We();
    },
    m(n, a) {
      t && t.m(n, a), G(n, e, a);
    },
    p(n, a) {
      /*p*/
      n[40].desc != null || /*progress_level*/
      n[14] && /*progress_level*/
      n[14][
        /*i*/
        n[42]
      ] != null ? t ? t.p(n, a) : (t = ba(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && z(e), t && t.d(n);
    }
  };
}
function wa(i) {
  let e, t, n, a;
  const o = (
    /*#slots*/
    i[30]["additional-loading-text"]
  ), l = vl(
    o,
    i,
    /*$$scope*/
    i[29],
    ca
  );
  return {
    c() {
      e = pt("p"), t = ve(
        /*loading_text*/
        i[9]
      ), n = Ye(), l && l.c(), this.h();
    },
    l(r) {
      e = ft(r, "P", { class: !0 });
      var s = _t(e);
      t = be(
        s,
        /*loading_text*/
        i[9]
      ), s.forEach(z), n = Ve(r), l && l.l(r), this.h();
    },
    h() {
      ot(e, "class", "loading svelte-17v219f");
    },
    m(r, s) {
      G(r, e, s), It(e, t), G(r, n, s), l && l.m(r, s), a = !0;
    },
    p(r, s) {
      (!a || s[0] & /*loading_text*/
      512) && Ze(
        t,
        /*loading_text*/
        r[9]
      ), l && l.p && (!a || s[0] & /*$$scope*/
      536870912) && Fl(
        l,
        o,
        r,
        /*$$scope*/
        r[29],
        a ? wl(
          o,
          /*$$scope*/
          r[29],
          s,
          Hr
        ) : El(
          /*$$scope*/
          r[29]
        ),
        ca
      );
    },
    i(r) {
      a || (lt(l, r), a = !0);
    },
    o(r) {
      ht(l, r), a = !1;
    },
    d(r) {
      r && (z(e), z(n)), l && l.d(r);
    }
  };
}
function es(i) {
  let e, t, n, a, o;
  const l = [jr, Gr], r = [];
  function s(u, c) {
    return (
      /*status*/
      u[4] === "pending" ? 0 : (
        /*status*/
        u[4] === "error" ? 1 : -1
      )
    );
  }
  return ~(t = s(i)) && (n = r[t] = l[t](i)), {
    c() {
      e = pt("div"), n && n.c(), this.h();
    },
    l(u) {
      e = ft(u, "DIV", { class: !0 });
      var c = _t(e);
      n && n.l(c), c.forEach(z), this.h();
    },
    h() {
      ot(e, "class", a = "wrap " + /*variant*/
      i[8] + " " + /*show_progress*/
      i[6] + " svelte-17v219f"), je(e, "hide", !/*status*/
      i[4] || /*status*/
      i[4] === "complete" || /*show_progress*/
      i[6] === "hidden" || /*status*/
      i[4] == "streaming"), je(
        e,
        "translucent",
        /*variant*/
        i[8] === "center" && /*status*/
        (i[4] === "pending" || /*status*/
        i[4] === "error") || /*translucent*/
        i[11] || /*show_progress*/
        i[6] === "minimal"
      ), je(
        e,
        "generating",
        /*status*/
        i[4] === "generating" && /*show_progress*/
        i[6] === "full"
      ), je(
        e,
        "border",
        /*border*/
        i[12]
      ), At(
        e,
        "position",
        /*absolute*/
        i[10] ? "absolute" : "static"
      ), At(
        e,
        "padding",
        /*absolute*/
        i[10] ? "0" : "var(--size-8) 0"
      );
    },
    m(u, c) {
      G(u, e, c), ~t && r[t].m(e, null), i[33](e), o = !0;
    },
    p(u, c) {
      let g = t;
      t = s(u), t === g ? ~t && r[t].p(u, c) : (n && (ci(), ht(r[g], 1, 1, () => {
        r[g] = null;
      }), ui()), ~t ? (n = r[t], n ? n.p(u, c) : (n = r[t] = l[t](u), n.c()), lt(n, 1), n.m(e, null)) : n = null), (!o || c[0] & /*variant, show_progress*/
      320 && a !== (a = "wrap " + /*variant*/
      u[8] + " " + /*show_progress*/
      u[6] + " svelte-17v219f")) && ot(e, "class", a), (!o || c[0] & /*variant, show_progress, status, show_progress*/
      336) && je(e, "hide", !/*status*/
      u[4] || /*status*/
      u[4] === "complete" || /*show_progress*/
      u[6] === "hidden" || /*status*/
      u[4] == "streaming"), (!o || c[0] & /*variant, show_progress, variant, status, translucent, show_progress*/
      2384) && je(
        e,
        "translucent",
        /*variant*/
        u[8] === "center" && /*status*/
        (u[4] === "pending" || /*status*/
        u[4] === "error") || /*translucent*/
        u[11] || /*show_progress*/
        u[6] === "minimal"
      ), (!o || c[0] & /*variant, show_progress, status, show_progress*/
      336) && je(
        e,
        "generating",
        /*status*/
        u[4] === "generating" && /*show_progress*/
        u[6] === "full"
      ), (!o || c[0] & /*variant, show_progress, border*/
      4416) && je(
        e,
        "border",
        /*border*/
        u[12]
      ), c[0] & /*absolute*/
      1024 && At(
        e,
        "position",
        /*absolute*/
        u[10] ? "absolute" : "static"
      ), c[0] & /*absolute*/
      1024 && At(
        e,
        "padding",
        /*absolute*/
        u[10] ? "0" : "var(--size-8) 0"
      );
    },
    i(u) {
      o || (lt(n), o = !0);
    },
    o(u) {
      ht(n), o = !1;
    },
    d(u) {
      u && z(e), ~t && r[t].d(), i[33](null);
    }
  };
}
let wn = [], Wn = !1;
const ts = typeof window < "u", $l = ts ? window.requestAnimationFrame : (i) => {
};
async function ns(i, e = !0) {
  if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && e !== !0)) {
    if (wn.push(i), !Wn) Wn = !0;
    else return;
    await Pr(), $l(() => {
      let t = [0, 0];
      for (let n = 0; n < wn.length; n++) {
        const o = wn[n].getBoundingClientRect();
        (n === 0 || o.top + window.scrollY <= t[0]) && (t[0] = o.top + window.scrollY, t[1] = n);
      }
      window.scrollTo({ top: t[0] - 20, behavior: "smooth" }), Wn = !1, wn = [];
    });
  }
}
function is(i, e, t) {
  let n, { $$slots: a = {}, $$scope: o } = e;
  const l = zr();
  let { i18n: r } = e, { eta: s = null } = e, { queue_position: u } = e, { queue_size: c } = e, { status: g } = e, { scroll_to_output: _ = !1 } = e, { timer: m = !0 } = e, { show_progress: b = "full" } = e, { message: w = null } = e, { progress: y = null } = e, { variant: x = "default" } = e, { loading_text: p = "Loading..." } = e, { absolute: d = !0 } = e, { translucent: h = !1 } = e, { border: D = !1 } = e, { autoscroll: F } = e, S, O = !1, k = 0, A = 0, $ = null, L = null, ce = 0, Q = null, ne, me = null, Ae = !0;
  const ie = () => {
    t(0, s = t(27, $ = t(19, I = null))), t(25, k = performance.now()), t(26, A = 0), O = !0, W();
  };
  function W() {
    $l(() => {
      t(26, A = (performance.now() - k) / 1e3), O && W();
    });
  }
  function De() {
    t(26, A = 0), t(0, s = t(27, $ = t(19, I = null))), O && (O = !1);
  }
  qr(() => {
    O && De();
  });
  let I = null;
  function H(C) {
    sa[C ? "unshift" : "push"](() => {
      me = C, t(16, me), t(7, y), t(14, Q), t(15, ne);
    });
  }
  const J = () => {
    l("clear_status");
  };
  function j(C) {
    sa[C ? "unshift" : "push"](() => {
      S = C, t(13, S);
    });
  }
  return i.$$set = (C) => {
    "i18n" in C && t(1, r = C.i18n), "eta" in C && t(0, s = C.eta), "queue_position" in C && t(2, u = C.queue_position), "queue_size" in C && t(3, c = C.queue_size), "status" in C && t(4, g = C.status), "scroll_to_output" in C && t(22, _ = C.scroll_to_output), "timer" in C && t(5, m = C.timer), "show_progress" in C && t(6, b = C.show_progress), "message" in C && t(23, w = C.message), "progress" in C && t(7, y = C.progress), "variant" in C && t(8, x = C.variant), "loading_text" in C && t(9, p = C.loading_text), "absolute" in C && t(10, d = C.absolute), "translucent" in C && t(11, h = C.translucent), "border" in C && t(12, D = C.border), "autoscroll" in C && t(24, F = C.autoscroll), "$$scope" in C && t(29, o = C.$$scope);
  }, i.$$.update = () => {
    i.$$.dirty[0] & /*eta, old_eta, timer_start, eta_from_start*/
    436207617 && (s === null && t(0, s = $), s != null && $ !== s && (t(28, L = (performance.now() - k) / 1e3 + s), t(19, I = L.toFixed(1)), t(27, $ = s))), i.$$.dirty[0] & /*eta_from_start, timer_diff*/
    335544320 && t(17, ce = L === null || L <= 0 || !A ? null : Math.min(A / L, 1)), i.$$.dirty[0] & /*progress*/
    128 && y != null && t(18, Ae = !1), i.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    114816 && (y != null ? t(14, Q = y.map((C) => {
      if (C.index != null && C.length != null)
        return C.index / C.length;
      if (C.progress != null)
        return C.progress;
    })) : t(14, Q = null), Q ? (t(15, ne = Q[Q.length - 1]), me && (ne === 0 ? t(16, me.style.transition = "0", me) : t(16, me.style.transition = "150ms", me))) : t(15, ne = void 0)), i.$$.dirty[0] & /*status*/
    16 && (g === "pending" ? ie() : De()), i.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    20979728 && S && _ && (g === "pending" || g === "complete") && ns(S, F), i.$$.dirty[0] & /*status, message*/
    8388624, i.$$.dirty[0] & /*timer_diff*/
    67108864 && t(20, n = A.toFixed(1));
  }, [
    s,
    r,
    u,
    c,
    g,
    m,
    b,
    y,
    x,
    p,
    d,
    h,
    D,
    S,
    Q,
    ne,
    me,
    ce,
    Ae,
    I,
    n,
    l,
    _,
    w,
    F,
    k,
    A,
    $,
    L,
    o,
    a,
    H,
    J,
    j
  ];
}
class as extends Or {
  constructor(e) {
    super(), Br(
      this,
      e,
      is,
      es,
      Mr,
      {
        i18n: 1,
        eta: 0,
        queue_position: 2,
        queue_size: 3,
        status: 4,
        scroll_to_output: 22,
        timer: 5,
        show_progress: 6,
        message: 23,
        progress: 7,
        variant: 8,
        loading_text: 9,
        absolute: 10,
        translucent: 11,
        border: 12,
        autoscroll: 24
      },
      null,
      [-1, -1]
    );
  }
}
/*! @license DOMPurify 3.2.7 | (c) Cure53 and other contributors | Released under the Apache license 2.0 and Mozilla Public License 2.0 | github.com/cure53/DOMPurify/blob/3.2.7/LICENSE */
const {
  entries: Al,
  setPrototypeOf: ka,
  isFrozen: ls,
  getPrototypeOf: os,
  getOwnPropertyDescriptor: rs
} = Object;
let {
  freeze: Le,
  seal: Xe,
  create: Cl
} = Object, {
  apply: _i,
  construct: fi
} = typeof Reflect < "u" && Reflect;
Le || (Le = function(e) {
  return e;
});
Xe || (Xe = function(e) {
  return e;
});
_i || (_i = function(e, t) {
  for (var n = arguments.length, a = new Array(n > 2 ? n - 2 : 0), o = 2; o < n; o++)
    a[o - 2] = arguments[o];
  return e.apply(t, a);
});
fi || (fi = function(e) {
  for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), a = 1; a < t; a++)
    n[a - 1] = arguments[a];
  return new e(...n);
});
const kn = Ne(Array.prototype.forEach), ss = Ne(Array.prototype.lastIndexOf), Fa = Ne(Array.prototype.pop), Kt = Ne(Array.prototype.push), us = Ne(Array.prototype.splice), Cn = Ne(String.prototype.toLowerCase), Zn = Ne(String.prototype.toString), Xn = Ne(String.prototype.match), Qt = Ne(String.prototype.replace), cs = Ne(String.prototype.indexOf), ds = Ne(String.prototype.trim), at = Ne(Object.prototype.hasOwnProperty), xe = Ne(RegExp.prototype.test), Jt = _s(TypeError);
function Ne(i) {
  return function(e) {
    e instanceof RegExp && (e.lastIndex = 0);
    for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), a = 1; a < t; a++)
      n[a - 1] = arguments[a];
    return _i(i, e, n);
  };
}
function _s(i) {
  return function() {
    for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++)
      t[n] = arguments[n];
    return fi(i, t);
  };
}
function Y(i, e) {
  let t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : Cn;
  ka && ka(i, null);
  let n = e.length;
  for (; n--; ) {
    let a = e[n];
    if (typeof a == "string") {
      const o = t(a);
      o !== a && (ls(e) || (e[n] = o), a = o);
    }
    i[a] = !0;
  }
  return i;
}
function fs(i) {
  for (let e = 0; e < i.length; e++)
    at(i, e) || (i[e] = null);
  return i;
}
function Dt(i) {
  const e = Cl(null);
  for (const [t, n] of Al(i))
    at(i, t) && (Array.isArray(n) ? e[t] = fs(n) : n && typeof n == "object" && n.constructor === Object ? e[t] = Dt(n) : e[t] = n);
  return e;
}
function en(i, e) {
  for (; i !== null; ) {
    const n = rs(i, e);
    if (n) {
      if (n.get)
        return Ne(n.get);
      if (typeof n.value == "function")
        return Ne(n.value);
    }
    i = os(i);
  }
  function t() {
    return null;
  }
  return t;
}
const $a = Le(["a", "abbr", "acronym", "address", "area", "article", "aside", "audio", "b", "bdi", "bdo", "big", "blink", "blockquote", "body", "br", "button", "canvas", "caption", "center", "cite", "code", "col", "colgroup", "content", "data", "datalist", "dd", "decorator", "del", "details", "dfn", "dialog", "dir", "div", "dl", "dt", "element", "em", "fieldset", "figcaption", "figure", "font", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "i", "img", "input", "ins", "kbd", "label", "legend", "li", "main", "map", "mark", "marquee", "menu", "menuitem", "meter", "nav", "nobr", "ol", "optgroup", "option", "output", "p", "picture", "pre", "progress", "q", "rp", "rt", "ruby", "s", "samp", "search", "section", "select", "shadow", "slot", "small", "source", "spacer", "span", "strike", "strong", "style", "sub", "summary", "sup", "table", "tbody", "td", "template", "textarea", "tfoot", "th", "thead", "time", "tr", "track", "tt", "u", "ul", "var", "video", "wbr"]), Kn = Le(["svg", "a", "altglyph", "altglyphdef", "altglyphitem", "animatecolor", "animatemotion", "animatetransform", "circle", "clippath", "defs", "desc", "ellipse", "enterkeyhint", "exportparts", "filter", "font", "g", "glyph", "glyphref", "hkern", "image", "inputmode", "line", "lineargradient", "marker", "mask", "metadata", "mpath", "part", "path", "pattern", "polygon", "polyline", "radialgradient", "rect", "slot", "stop", "style", "switch", "symbol", "text", "textpath", "title", "tref", "tspan", "view", "vkern"]), Qn = Le(["feBlend", "feColorMatrix", "feComponentTransfer", "feComposite", "feConvolveMatrix", "feDiffuseLighting", "feDisplacementMap", "feDistantLight", "feDropShadow", "feFlood", "feFuncA", "feFuncB", "feFuncG", "feFuncR", "feGaussianBlur", "feImage", "feMerge", "feMergeNode", "feMorphology", "feOffset", "fePointLight", "feSpecularLighting", "feSpotLight", "feTile", "feTurbulence"]), ps = Le(["animate", "color-profile", "cursor", "discard", "font-face", "font-face-format", "font-face-name", "font-face-src", "font-face-uri", "foreignobject", "hatch", "hatchpath", "mesh", "meshgradient", "meshpatch", "meshrow", "missing-glyph", "script", "set", "solidcolor", "unknown", "use"]), Jn = Le(["math", "menclose", "merror", "mfenced", "mfrac", "mglyph", "mi", "mlabeledtr", "mmultiscripts", "mn", "mo", "mover", "mpadded", "mphantom", "mroot", "mrow", "ms", "mspace", "msqrt", "mstyle", "msub", "msup", "msubsup", "mtable", "mtd", "mtext", "mtr", "munder", "munderover", "mprescripts"]), hs = Le(["maction", "maligngroup", "malignmark", "mlongdiv", "mscarries", "mscarry", "msgroup", "mstack", "msline", "msrow", "semantics", "annotation", "annotation-xml", "mprescripts", "none"]), Aa = Le(["#text"]), Ca = Le(["accept", "action", "align", "alt", "autocapitalize", "autocomplete", "autopictureinpicture", "autoplay", "background", "bgcolor", "border", "capture", "cellpadding", "cellspacing", "checked", "cite", "class", "clear", "color", "cols", "colspan", "controls", "controlslist", "coords", "crossorigin", "datetime", "decoding", "default", "dir", "disabled", "disablepictureinpicture", "disableremoteplayback", "download", "draggable", "enctype", "enterkeyhint", "exportparts", "face", "for", "headers", "height", "hidden", "high", "href", "hreflang", "id", "inert", "inputmode", "integrity", "ismap", "kind", "label", "lang", "list", "loading", "loop", "low", "max", "maxlength", "media", "method", "min", "minlength", "multiple", "muted", "name", "nonce", "noshade", "novalidate", "nowrap", "open", "optimum", "part", "pattern", "placeholder", "playsinline", "popover", "popovertarget", "popovertargetaction", "poster", "preload", "pubdate", "radiogroup", "readonly", "rel", "required", "rev", "reversed", "role", "rows", "rowspan", "spellcheck", "scope", "selected", "shape", "size", "sizes", "slot", "span", "srclang", "start", "src", "srcset", "step", "style", "summary", "tabindex", "title", "translate", "type", "usemap", "valign", "value", "width", "wrap", "xmlns", "slot"]), ei = Le(["accent-height", "accumulate", "additive", "alignment-baseline", "amplitude", "ascent", "attributename", "attributetype", "azimuth", "basefrequency", "baseline-shift", "begin", "bias", "by", "class", "clip", "clippathunits", "clip-path", "clip-rule", "color", "color-interpolation", "color-interpolation-filters", "color-profile", "color-rendering", "cx", "cy", "d", "dx", "dy", "diffuseconstant", "direction", "display", "divisor", "dur", "edgemode", "elevation", "end", "exponent", "fill", "fill-opacity", "fill-rule", "filter", "filterunits", "flood-color", "flood-opacity", "font-family", "font-size", "font-size-adjust", "font-stretch", "font-style", "font-variant", "font-weight", "fx", "fy", "g1", "g2", "glyph-name", "glyphref", "gradientunits", "gradienttransform", "height", "href", "id", "image-rendering", "in", "in2", "intercept", "k", "k1", "k2", "k3", "k4", "kerning", "keypoints", "keysplines", "keytimes", "lang", "lengthadjust", "letter-spacing", "kernelmatrix", "kernelunitlength", "lighting-color", "local", "marker-end", "marker-mid", "marker-start", "markerheight", "markerunits", "markerwidth", "maskcontentunits", "maskunits", "max", "mask", "media", "method", "mode", "min", "name", "numoctaves", "offset", "operator", "opacity", "order", "orient", "orientation", "origin", "overflow", "paint-order", "path", "pathlength", "patterncontentunits", "patterntransform", "patternunits", "points", "preservealpha", "preserveaspectratio", "primitiveunits", "r", "rx", "ry", "radius", "refx", "refy", "repeatcount", "repeatdur", "restart", "result", "rotate", "scale", "seed", "shape-rendering", "slope", "specularconstant", "specularexponent", "spreadmethod", "startoffset", "stddeviation", "stitchtiles", "stop-color", "stop-opacity", "stroke-dasharray", "stroke-dashoffset", "stroke-linecap", "stroke-linejoin", "stroke-miterlimit", "stroke-opacity", "stroke", "stroke-width", "style", "surfacescale", "systemlanguage", "tabindex", "tablevalues", "targetx", "targety", "transform", "transform-origin", "text-anchor", "text-decoration", "text-rendering", "textlength", "type", "u1", "u2", "unicode", "values", "viewbox", "visibility", "version", "vert-adv-y", "vert-origin-x", "vert-origin-y", "width", "word-spacing", "wrap", "writing-mode", "xchannelselector", "ychannelselector", "x", "x1", "x2", "xmlns", "y", "y1", "y2", "z", "zoomandpan"]), Sa = Le(["accent", "accentunder", "align", "bevelled", "close", "columnsalign", "columnlines", "columnspan", "denomalign", "depth", "dir", "display", "displaystyle", "encoding", "fence", "frame", "height", "href", "id", "largeop", "length", "linethickness", "lspace", "lquote", "mathbackground", "mathcolor", "mathsize", "mathvariant", "maxsize", "minsize", "movablelimits", "notation", "numalign", "open", "rowalign", "rowlines", "rowspacing", "rowspan", "rspace", "rquote", "scriptlevel", "scriptminsize", "scriptsizemultiplier", "selection", "separator", "separators", "stretchy", "subscriptshift", "supscriptshift", "symmetric", "voffset", "width", "xmlns"]), Fn = Le(["xlink:href", "xml:id", "xlink:title", "xml:space", "xmlns:xlink"]), ms = Xe(/\{\{[\w\W]*|[\w\W]*\}\}/gm), gs = Xe(/<%[\w\W]*|[\w\W]*%>/gm), bs = Xe(/\$\{[\w\W]*/gm), vs = Xe(/^data-[\-\w.\u00B7-\uFFFF]+$/), Ds = Xe(/^aria-[\-\w]+$/), Sl = Xe(
  /^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp|matrix):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i
  // eslint-disable-line no-useless-escape
), ys = Xe(/^(?:\w+script|data):/i), Es = Xe(
  /[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g
  // eslint-disable-line no-control-regex
), Tl = Xe(/^html$/i), ws = Xe(/^[a-z][.\w]*(-[.\w]+)+$/i);
var Ta = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  ARIA_ATTR: Ds,
  ATTR_WHITESPACE: Es,
  CUSTOM_ELEMENT: ws,
  DATA_ATTR: vs,
  DOCTYPE_NAME: Tl,
  ERB_EXPR: gs,
  IS_ALLOWED_URI: Sl,
  IS_SCRIPT_OR_DATA: ys,
  MUSTACHE_EXPR: ms,
  TMPLIT_EXPR: bs
});
const tn = {
  element: 1,
  text: 3,
  // Deprecated
  progressingInstruction: 7,
  comment: 8,
  document: 9
}, ks = function() {
  return typeof window > "u" ? null : window;
}, Fs = function(e, t) {
  if (typeof e != "object" || typeof e.createPolicy != "function")
    return null;
  let n = null;
  const a = "data-tt-policy-suffix";
  t && t.hasAttribute(a) && (n = t.getAttribute(a));
  const o = "dompurify" + (n ? "#" + n : "");
  try {
    return e.createPolicy(o, {
      createHTML(l) {
        return l;
      },
      createScriptURL(l) {
        return l;
      }
    });
  } catch {
    return console.warn("TrustedTypes policy " + o + " could not be created."), null;
  }
}, Ia = function() {
  return {
    afterSanitizeAttributes: [],
    afterSanitizeElements: [],
    afterSanitizeShadowDOM: [],
    beforeSanitizeAttributes: [],
    beforeSanitizeElements: [],
    beforeSanitizeShadowDOM: [],
    uponSanitizeAttribute: [],
    uponSanitizeElement: [],
    uponSanitizeShadowNode: []
  };
};
function Il() {
  let i = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : ks();
  const e = (q) => Il(q);
  if (e.version = "3.2.7", e.removed = [], !i || !i.document || i.document.nodeType !== tn.document || !i.Element)
    return e.isSupported = !1, e;
  let {
    document: t
  } = i;
  const n = t, a = n.currentScript, {
    DocumentFragment: o,
    HTMLTemplateElement: l,
    Node: r,
    Element: s,
    NodeFilter: u,
    NamedNodeMap: c = i.NamedNodeMap || i.MozNamedAttrMap,
    HTMLFormElement: g,
    DOMParser: _,
    trustedTypes: m
  } = i, b = s.prototype, w = en(b, "cloneNode"), y = en(b, "remove"), x = en(b, "nextSibling"), p = en(b, "childNodes"), d = en(b, "parentNode");
  if (typeof l == "function") {
    const q = t.createElement("template");
    q.content && q.content.ownerDocument && (t = q.content.ownerDocument);
  }
  let h, D = "";
  const {
    implementation: F,
    createNodeIterator: S,
    createDocumentFragment: O,
    getElementsByTagName: k
  } = t, {
    importNode: A
  } = n;
  let $ = Ia();
  e.isSupported = typeof Al == "function" && typeof d == "function" && F && F.createHTMLDocument !== void 0;
  const {
    MUSTACHE_EXPR: L,
    ERB_EXPR: ce,
    TMPLIT_EXPR: Q,
    DATA_ATTR: ne,
    ARIA_ATTR: me,
    IS_SCRIPT_OR_DATA: Ae,
    ATTR_WHITESPACE: ie,
    CUSTOM_ELEMENT: W
  } = Ta;
  let {
    IS_ALLOWED_URI: De
  } = Ta, I = null;
  const H = Y({}, [...$a, ...Kn, ...Qn, ...Jn, ...Aa]);
  let J = null;
  const j = Y({}, [...Ca, ...ei, ...Sa, ...Fn]);
  let C = Object.seal(Cl(null, {
    tagNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    attributeNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    allowCustomizedBuiltInElements: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: !1
    }
  })), ye = null, le = null, de = !0, Re = !0, ue = !1, N = !0, V = !1, B = !0, ge = !1, yt = !1, Et = !1, Ke = !1, Pe = !1, Qe = !1, Ct = !0, St = !1;
  const wt = "user-content-";
  let mt = !0, we = !1, kt = {}, Ft = null;
  const dn = Y({}, ["annotation-xml", "audio", "colgroup", "desc", "foreignobject", "head", "iframe", "math", "mi", "mn", "mo", "ms", "mtext", "noembed", "noframes", "noscript", "plaintext", "script", "style", "svg", "template", "thead", "title", "video", "xmp"]);
  let _n = null;
  const fn = Y({}, ["audio", "video", "img", "source", "image", "track"]);
  let Vt = null;
  const E = Y({}, ["alt", "class", "for", "id", "label", "name", "pattern", "placeholder", "role", "summary", "title", "value", "style", "xmlns"]), T = "http://www.w3.org/1998/Math/MathML", te = "http://www.w3.org/2000/svg", ke = "http://www.w3.org/1999/xhtml";
  let qe = ke, Je = !1, Yt = null;
  const Mn = Y({}, [T, te, ke], Zn);
  let Mt = Y({}, ["mi", "mo", "mn", "ms", "mtext"]), pn = Y({}, ["annotation-xml"]);
  const Ml = Y({}, ["title", "style", "font", "a", "script"]);
  let Wt = null;
  const Pl = ["application/xhtml+xml", "text/html"], ql = "text/html";
  let Fe = null, Pt = null;
  const zl = t.createElement("form"), ki = function(f) {
    return f instanceof RegExp || f instanceof Function;
  }, Pn = function() {
    let f = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    if (!(Pt && Pt === f)) {
      if ((!f || typeof f != "object") && (f = {}), f = Dt(f), Wt = // eslint-disable-next-line unicorn/prefer-includes
      Pl.indexOf(f.PARSER_MEDIA_TYPE) === -1 ? ql : f.PARSER_MEDIA_TYPE, Fe = Wt === "application/xhtml+xml" ? Zn : Cn, I = at(f, "ALLOWED_TAGS") ? Y({}, f.ALLOWED_TAGS, Fe) : H, J = at(f, "ALLOWED_ATTR") ? Y({}, f.ALLOWED_ATTR, Fe) : j, Yt = at(f, "ALLOWED_NAMESPACES") ? Y({}, f.ALLOWED_NAMESPACES, Zn) : Mn, Vt = at(f, "ADD_URI_SAFE_ATTR") ? Y(Dt(E), f.ADD_URI_SAFE_ATTR, Fe) : E, _n = at(f, "ADD_DATA_URI_TAGS") ? Y(Dt(fn), f.ADD_DATA_URI_TAGS, Fe) : fn, Ft = at(f, "FORBID_CONTENTS") ? Y({}, f.FORBID_CONTENTS, Fe) : dn, ye = at(f, "FORBID_TAGS") ? Y({}, f.FORBID_TAGS, Fe) : Dt({}), le = at(f, "FORBID_ATTR") ? Y({}, f.FORBID_ATTR, Fe) : Dt({}), kt = at(f, "USE_PROFILES") ? f.USE_PROFILES : !1, de = f.ALLOW_ARIA_ATTR !== !1, Re = f.ALLOW_DATA_ATTR !== !1, ue = f.ALLOW_UNKNOWN_PROTOCOLS || !1, N = f.ALLOW_SELF_CLOSE_IN_ATTR !== !1, V = f.SAFE_FOR_TEMPLATES || !1, B = f.SAFE_FOR_XML !== !1, ge = f.WHOLE_DOCUMENT || !1, Ke = f.RETURN_DOM || !1, Pe = f.RETURN_DOM_FRAGMENT || !1, Qe = f.RETURN_TRUSTED_TYPE || !1, Et = f.FORCE_BODY || !1, Ct = f.SANITIZE_DOM !== !1, St = f.SANITIZE_NAMED_PROPS || !1, mt = f.KEEP_CONTENT !== !1, we = f.IN_PLACE || !1, De = f.ALLOWED_URI_REGEXP || Sl, qe = f.NAMESPACE || ke, Mt = f.MATHML_TEXT_INTEGRATION_POINTS || Mt, pn = f.HTML_INTEGRATION_POINTS || pn, C = f.CUSTOM_ELEMENT_HANDLING || {}, f.CUSTOM_ELEMENT_HANDLING && ki(f.CUSTOM_ELEMENT_HANDLING.tagNameCheck) && (C.tagNameCheck = f.CUSTOM_ELEMENT_HANDLING.tagNameCheck), f.CUSTOM_ELEMENT_HANDLING && ki(f.CUSTOM_ELEMENT_HANDLING.attributeNameCheck) && (C.attributeNameCheck = f.CUSTOM_ELEMENT_HANDLING.attributeNameCheck), f.CUSTOM_ELEMENT_HANDLING && typeof f.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements == "boolean" && (C.allowCustomizedBuiltInElements = f.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements), V && (Re = !1), Pe && (Ke = !0), kt && (I = Y({}, Aa), J = [], kt.html === !0 && (Y(I, $a), Y(J, Ca)), kt.svg === !0 && (Y(I, Kn), Y(J, ei), Y(J, Fn)), kt.svgFilters === !0 && (Y(I, Qn), Y(J, ei), Y(J, Fn)), kt.mathMl === !0 && (Y(I, Jn), Y(J, Sa), Y(J, Fn))), f.ADD_TAGS && (I === H && (I = Dt(I)), Y(I, f.ADD_TAGS, Fe)), f.ADD_ATTR && (J === j && (J = Dt(J)), Y(J, f.ADD_ATTR, Fe)), f.ADD_URI_SAFE_ATTR && Y(Vt, f.ADD_URI_SAFE_ATTR, Fe), f.FORBID_CONTENTS && (Ft === dn && (Ft = Dt(Ft)), Y(Ft, f.FORBID_CONTENTS, Fe)), mt && (I["#text"] = !0), ge && Y(I, ["html", "head", "body"]), I.table && (Y(I, ["tbody"]), delete ye.tbody), f.TRUSTED_TYPES_POLICY) {
        if (typeof f.TRUSTED_TYPES_POLICY.createHTML != "function")
          throw Jt('TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.');
        if (typeof f.TRUSTED_TYPES_POLICY.createScriptURL != "function")
          throw Jt('TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.');
        h = f.TRUSTED_TYPES_POLICY, D = h.createHTML("");
      } else
        h === void 0 && (h = Fs(m, a)), h !== null && typeof D == "string" && (D = h.createHTML(""));
      Le && Le(f), Pt = f;
    }
  }, Fi = Y({}, [...Kn, ...Qn, ...ps]), $i = Y({}, [...Jn, ...hs]), Ul = function(f) {
    let R = d(f);
    (!R || !R.tagName) && (R = {
      namespaceURI: qe,
      tagName: "template"
    });
    const M = Cn(f.tagName), fe = Cn(R.tagName);
    return Yt[f.namespaceURI] ? f.namespaceURI === te ? R.namespaceURI === ke ? M === "svg" : R.namespaceURI === T ? M === "svg" && (fe === "annotation-xml" || Mt[fe]) : !!Fi[M] : f.namespaceURI === T ? R.namespaceURI === ke ? M === "math" : R.namespaceURI === te ? M === "math" && pn[fe] : !!$i[M] : f.namespaceURI === ke ? R.namespaceURI === te && !pn[fe] || R.namespaceURI === T && !Mt[fe] ? !1 : !$i[M] && (Ml[M] || !Fi[M]) : !!(Wt === "application/xhtml+xml" && Yt[f.namespaceURI]) : !1;
  }, rt = function(f) {
    Kt(e.removed, {
      element: f
    });
    try {
      d(f).removeChild(f);
    } catch {
      y(f);
    }
  }, Tt = function(f, R) {
    try {
      Kt(e.removed, {
        attribute: R.getAttributeNode(f),
        from: R
      });
    } catch {
      Kt(e.removed, {
        attribute: null,
        from: R
      });
    }
    if (R.removeAttribute(f), f === "is")
      if (Ke || Pe)
        try {
          rt(R);
        } catch {
        }
      else
        try {
          R.setAttribute(f, "");
        } catch {
        }
  }, Ai = function(f) {
    let R = null, M = null;
    if (Et)
      f = "<remove></remove>" + f;
    else {
      const Ee = Xn(f, /^[\r\n\t ]+/);
      M = Ee && Ee[0];
    }
    Wt === "application/xhtml+xml" && qe === ke && (f = '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>' + f + "</body></html>");
    const fe = h ? h.createHTML(f) : f;
    if (qe === ke)
      try {
        R = new _().parseFromString(fe, Wt);
      } catch {
      }
    if (!R || !R.documentElement) {
      R = F.createDocument(qe, "template", null);
      try {
        R.documentElement.innerHTML = Je ? D : fe;
      } catch {
      }
    }
    const Se = R.body || R.documentElement;
    return f && M && Se.insertBefore(t.createTextNode(M), Se.childNodes[0] || null), qe === ke ? k.call(R, ge ? "html" : "body")[0] : ge ? R.documentElement : Se;
  }, Ci = function(f) {
    return S.call(
      f.ownerDocument || f,
      f,
      // eslint-disable-next-line no-bitwise
      u.SHOW_ELEMENT | u.SHOW_COMMENT | u.SHOW_TEXT | u.SHOW_PROCESSING_INSTRUCTION | u.SHOW_CDATA_SECTION,
      null
    );
  }, qn = function(f) {
    return f instanceof g && (typeof f.nodeName != "string" || typeof f.textContent != "string" || typeof f.removeChild != "function" || !(f.attributes instanceof c) || typeof f.removeAttribute != "function" || typeof f.setAttribute != "function" || typeof f.namespaceURI != "string" || typeof f.insertBefore != "function" || typeof f.hasChildNodes != "function");
  }, Si = function(f) {
    return typeof r == "function" && f instanceof r;
  };
  function gt(q, f, R) {
    kn(q, (M) => {
      M.call(e, f, R, Pt);
    });
  }
  const Ti = function(f) {
    let R = null;
    if (gt($.beforeSanitizeElements, f, null), qn(f))
      return rt(f), !0;
    const M = Fe(f.nodeName);
    if (gt($.uponSanitizeElement, f, {
      tagName: M,
      allowedTags: I
    }), B && f.hasChildNodes() && !Si(f.firstElementChild) && xe(/<[/\w!]/g, f.innerHTML) && xe(/<[/\w!]/g, f.textContent) || f.nodeType === tn.progressingInstruction || B && f.nodeType === tn.comment && xe(/<[/\w]/g, f.data))
      return rt(f), !0;
    if (!I[M] || ye[M]) {
      if (!ye[M] && Ri(M) && (C.tagNameCheck instanceof RegExp && xe(C.tagNameCheck, M) || C.tagNameCheck instanceof Function && C.tagNameCheck(M)))
        return !1;
      if (mt && !Ft[M]) {
        const fe = d(f) || f.parentNode, Se = p(f) || f.childNodes;
        if (Se && fe) {
          const Ee = Se.length;
          for (let Be = Ee - 1; Be >= 0; --Be) {
            const bt = w(Se[Be], !0);
            bt.__removalCount = (f.__removalCount || 0) + 1, fe.insertBefore(bt, x(f));
          }
        }
      }
      return rt(f), !0;
    }
    return f instanceof s && !Ul(f) || (M === "noscript" || M === "noembed" || M === "noframes") && xe(/<\/no(script|embed|frames)/i, f.innerHTML) ? (rt(f), !0) : (V && f.nodeType === tn.text && (R = f.textContent, kn([L, ce, Q], (fe) => {
      R = Qt(R, fe, " ");
    }), f.textContent !== R && (Kt(e.removed, {
      element: f.cloneNode()
    }), f.textContent = R)), gt($.afterSanitizeElements, f, null), !1);
  }, Ii = function(f, R, M) {
    if (Ct && (R === "id" || R === "name") && (M in t || M in zl))
      return !1;
    if (!(Re && !le[R] && xe(ne, R))) {
      if (!(de && xe(me, R))) {
        if (!J[R] || le[R]) {
          if (
            // First condition does a very basic check if a) it's basically a valid custom element tagname AND
            // b) if the tagName passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            // and c) if the attribute name passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.attributeNameCheck
            !(Ri(f) && (C.tagNameCheck instanceof RegExp && xe(C.tagNameCheck, f) || C.tagNameCheck instanceof Function && C.tagNameCheck(f)) && (C.attributeNameCheck instanceof RegExp && xe(C.attributeNameCheck, R) || C.attributeNameCheck instanceof Function && C.attributeNameCheck(R, f)) || // Alternative, second condition checks if it's an `is`-attribute, AND
            // the value passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            R === "is" && C.allowCustomizedBuiltInElements && (C.tagNameCheck instanceof RegExp && xe(C.tagNameCheck, M) || C.tagNameCheck instanceof Function && C.tagNameCheck(M)))
          ) return !1;
        } else if (!Vt[R]) {
          if (!xe(De, Qt(M, ie, ""))) {
            if (!((R === "src" || R === "xlink:href" || R === "href") && f !== "script" && cs(M, "data:") === 0 && _n[f])) {
              if (!(ue && !xe(Ae, Qt(M, ie, "")))) {
                if (M)
                  return !1;
              }
            }
          }
        }
      }
    }
    return !0;
  }, Ri = function(f) {
    return f !== "annotation-xml" && Xn(f, W);
  }, xi = function(f) {
    gt($.beforeSanitizeAttributes, f, null);
    const {
      attributes: R
    } = f;
    if (!R || qn(f))
      return;
    const M = {
      attrName: "",
      attrValue: "",
      keepAttr: !0,
      allowedAttributes: J,
      forceKeepAttr: void 0
    };
    let fe = R.length;
    for (; fe--; ) {
      const Se = R[fe], {
        name: Ee,
        namespaceURI: Be,
        value: bt
      } = Se, qt = Fe(Ee), zn = bt;
      let Ce = Ee === "value" ? zn : ds(zn);
      if (M.attrName = qt, M.attrValue = Ce, M.keepAttr = !0, M.forceKeepAttr = void 0, gt($.uponSanitizeAttribute, f, M), Ce = M.attrValue, St && (qt === "id" || qt === "name") && (Tt(Ee, f), Ce = wt + Ce), B && xe(/((--!?|])>)|<\/(style|title|textarea)/i, Ce)) {
        Tt(Ee, f);
        continue;
      }
      if (qt === "attributename" && Xn(Ce, "href")) {
        Tt(Ee, f);
        continue;
      }
      if (M.forceKeepAttr)
        continue;
      if (!M.keepAttr) {
        Tt(Ee, f);
        continue;
      }
      if (!N && xe(/\/>/i, Ce)) {
        Tt(Ee, f);
        continue;
      }
      V && kn([L, ce, Q], (Ni) => {
        Ce = Qt(Ce, Ni, " ");
      });
      const Li = Fe(f.nodeName);
      if (!Ii(Li, qt, Ce)) {
        Tt(Ee, f);
        continue;
      }
      if (h && typeof m == "object" && typeof m.getAttributeType == "function" && !Be)
        switch (m.getAttributeType(Li, qt)) {
          case "TrustedHTML": {
            Ce = h.createHTML(Ce);
            break;
          }
          case "TrustedScriptURL": {
            Ce = h.createScriptURL(Ce);
            break;
          }
        }
      if (Ce !== zn)
        try {
          Be ? f.setAttributeNS(Be, Ee, Ce) : f.setAttribute(Ee, Ce), qn(f) ? rt(f) : Fa(e.removed);
        } catch {
          Tt(Ee, f);
        }
    }
    gt($.afterSanitizeAttributes, f, null);
  }, Hl = function q(f) {
    let R = null;
    const M = Ci(f);
    for (gt($.beforeSanitizeShadowDOM, f, null); R = M.nextNode(); )
      gt($.uponSanitizeShadowNode, R, null), Ti(R), xi(R), R.content instanceof o && q(R.content);
    gt($.afterSanitizeShadowDOM, f, null);
  };
  return e.sanitize = function(q) {
    let f = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, R = null, M = null, fe = null, Se = null;
    if (Je = !q, Je && (q = "<!-->"), typeof q != "string" && !Si(q))
      if (typeof q.toString == "function") {
        if (q = q.toString(), typeof q != "string")
          throw Jt("dirty is not a string, aborting");
      } else
        throw Jt("toString is not a function");
    if (!e.isSupported)
      return q;
    if (yt || Pn(f), e.removed = [], typeof q == "string" && (we = !1), we) {
      if (q.nodeName) {
        const bt = Fe(q.nodeName);
        if (!I[bt] || ye[bt])
          throw Jt("root node is forbidden and cannot be sanitized in-place");
      }
    } else if (q instanceof r)
      R = Ai("<!---->"), M = R.ownerDocument.importNode(q, !0), M.nodeType === tn.element && M.nodeName === "BODY" || M.nodeName === "HTML" ? R = M : R.appendChild(M);
    else {
      if (!Ke && !V && !ge && // eslint-disable-next-line unicorn/prefer-includes
      q.indexOf("<") === -1)
        return h && Qe ? h.createHTML(q) : q;
      if (R = Ai(q), !R)
        return Ke ? null : Qe ? D : "";
    }
    R && Et && rt(R.firstChild);
    const Ee = Ci(we ? q : R);
    for (; fe = Ee.nextNode(); )
      Ti(fe), xi(fe), fe.content instanceof o && Hl(fe.content);
    if (we)
      return q;
    if (Ke) {
      if (Pe)
        for (Se = O.call(R.ownerDocument); R.firstChild; )
          Se.appendChild(R.firstChild);
      else
        Se = R;
      return (J.shadowroot || J.shadowrootmode) && (Se = A.call(n, Se, !0)), Se;
    }
    let Be = ge ? R.outerHTML : R.innerHTML;
    return ge && I["!doctype"] && R.ownerDocument && R.ownerDocument.doctype && R.ownerDocument.doctype.name && xe(Tl, R.ownerDocument.doctype.name) && (Be = "<!DOCTYPE " + R.ownerDocument.doctype.name + `>
` + Be), V && kn([L, ce, Q], (bt) => {
      Be = Qt(Be, bt, " ");
    }), h && Qe ? h.createHTML(Be) : Be;
  }, e.setConfig = function() {
    let q = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    Pn(q), yt = !0;
  }, e.clearConfig = function() {
    Pt = null, yt = !1;
  }, e.isValidAttribute = function(q, f, R) {
    Pt || Pn({});
    const M = Fe(q), fe = Fe(f);
    return Ii(M, fe, R);
  }, e.addHook = function(q, f) {
    typeof f == "function" && Kt($[q], f);
  }, e.removeHook = function(q, f) {
    if (f !== void 0) {
      const R = ss($[q], f);
      return R === -1 ? void 0 : us($[q], R, 1)[0];
    }
    return Fa($[q]);
  }, e.removeHooks = function(q) {
    $[q] = [];
  }, e.removeAllHooks = function() {
    $ = Ia();
  }, e;
}
Il();
const {
  HtmlTagHydration: qF,
  SvelteComponent: zF,
  add_render_callback: UF,
  append_hydration: HF,
  attr: GF,
  bubble: jF,
  check_outros: VF,
  children: YF,
  claim_component: WF,
  claim_element: ZF,
  claim_html_tag: XF,
  claim_space: KF,
  claim_text: QF,
  create_component: JF,
  create_in_transition: e$,
  create_out_transition: t$,
  destroy_component: n$,
  detach: i$,
  element: a$,
  get_svelte_dataset: l$,
  group_outros: o$,
  init: r$,
  insert_hydration: s$,
  listen: u$,
  mount_component: c$,
  run_all: d$,
  safe_not_equal: _$,
  set_data: f$,
  space: p$,
  stop_propagation: h$,
  text: m$,
  toggle_class: g$,
  transition_in: b$,
  transition_out: v$
} = window.__gradio__svelte__internal, { createEventDispatcher: D$, onMount: y$ } = window.__gradio__svelte__internal, {
  SvelteComponent: E$,
  append_hydration: w$,
  attr: k$,
  bubble: F$,
  check_outros: $$,
  children: A$,
  claim_component: C$,
  claim_element: S$,
  claim_space: T$,
  create_animation: I$,
  create_component: R$,
  destroy_component: x$,
  detach: L$,
  element: N$,
  ensure_array_like: O$,
  fix_and_outro_and_destroy_block: B$,
  fix_position: M$,
  group_outros: P$,
  init: q$,
  insert_hydration: z$,
  mount_component: U$,
  noop: H$,
  safe_not_equal: G$,
  set_style: j$,
  space: V$,
  transition_in: Y$,
  transition_out: W$,
  update_keyed_each: Z$
} = window.__gradio__svelte__internal, {
  SvelteComponent: X$,
  attr: K$,
  children: Q$,
  claim_element: J$,
  detach: eA,
  element: tA,
  empty: nA,
  init: iA,
  insert_hydration: aA,
  noop: lA,
  safe_not_equal: oA,
  set_style: rA
} = window.__gradio__svelte__internal, {
  SvelteComponent: $s,
  append_hydration: P,
  assign: As,
  attr: v,
  binding_callbacks: Cs,
  check_outros: Ss,
  children: ae,
  claim_component: Rl,
  claim_element: Z,
  claim_space: pe,
  claim_svg_element: Ei,
  claim_text: xt,
  create_component: xl,
  destroy_component: Ll,
  destroy_each: Sn,
  detach: U,
  element: X,
  empty: jt,
  ensure_array_like: $t,
  flush: Ue,
  get_spread_object: Ts,
  get_spread_update: Is,
  get_svelte_dataset: Ut,
  group_outros: Rs,
  init: xs,
  insert_hydration: Oe,
  listen: K,
  mount_component: Nl,
  run_all: Bt,
  safe_not_equal: Ls,
  set_data: Ln,
  set_input_value: Ra,
  set_style: Me,
  space: he,
  src_url_equal: Ol,
  stop_propagation: pi,
  svg_element: wi,
  text: Lt,
  transition_in: rn,
  transition_out: Nn
} = window.__gradio__svelte__internal;
function xa(i, e, t) {
  const n = i.slice();
  return n[66] = e[t], n[68] = t, n;
}
function La(i, e, t) {
  const n = i.slice();
  n[69] = e[t], n[68] = t;
  const a = (
    /*nodes*/
    n[10][
      /*conn*/
      n[69].from
    ]
  );
  n[70] = a;
  const o = (
    /*nodes*/
    n[10][
      /*conn*/
      n[69].to
    ]
  );
  return n[71] = o, n;
}
function ti(i) {
  const e = i.slice(), t = typeof document < "u" ? document.getElementById(`${/*elem_id*/
  e[1]}-node-${/*conn*/
  e[69].from}`) : null;
  e[73] = t;
  const n = typeof document < "u" ? document.getElementById(`${/*elem_id*/
  e[1]}-node-${/*conn*/
  e[69].to}`) : null;
  e[74] = n;
  const a = (
    /*fromNodeElement*/
    e[73] ? (
      /*fromNodeElement*/
      e[73].offsetHeight
    ) : 30
  );
  e[75] = a;
  const o = (
    /*toNodeElement*/
    e[74] ? (
      /*toNodeElement*/
      e[74].offsetHeight
    ) : 30
  );
  return e[76] = o, e;
}
function Na(i, e, t) {
  const n = i.slice();
  return n[77] = e[t], n[78] = e, n[79] = t, n;
}
function Oa(i, e, t) {
  const n = i.slice();
  return n[80] = e[t], n[68] = t, n;
}
function Ba(i) {
  let e, t;
  const n = [
    /*loading_status*/
    i[6],
    { i18n: (
      /*gradio*/
      i[0].i18n
    ) },
    { autoscroll: (
      /*gradio*/
      i[0].autoscroll
    ) }
  ];
  let a = {};
  for (let o = 0; o < n.length; o += 1)
    a = As(a, n[o]);
  return e = new as({ props: a }), e.$on(
    "clear_status",
    /*clear_status_handler*/
    i[34]
  ), {
    c() {
      xl(e.$$.fragment);
    },
    l(o) {
      Rl(e.$$.fragment, o);
    },
    m(o, l) {
      Nl(e, o, l), t = !0;
    },
    p(o, l) {
      const r = l[0] & /*loading_status, gradio*/
      65 ? Is(n, [
        l[0] & /*loading_status*/
        64 && Ts(
          /*loading_status*/
          o[6]
        ),
        l[0] & /*gradio*/
        1 && { i18n: (
          /*gradio*/
          o[0].i18n
        ) },
        l[0] & /*gradio*/
        1 && { autoscroll: (
          /*gradio*/
          o[0].autoscroll
        ) }
      ]) : {};
      e.$set(r);
    },
    i(o) {
      t || (rn(e.$$.fragment, o), t = !0);
    },
    o(o) {
      Nn(e.$$.fragment, o), t = !1;
    },
    d(o) {
      Ll(e, o);
    }
  };
}
function Ma(i) {
  let e, t = (
    /*box*/
    i[80].label + ""
  ), n, a, o, l, r;
  function s(...u) {
    return (
      /*dragstart_handler*/
      i[35](
        /*box*/
        i[80],
        ...u
      )
    );
  }
  return {
    c() {
      e = X("div"), n = Lt(t), a = he(), this.h();
    },
    l(u) {
      e = Z(u, "DIV", {
        class: !0,
        id: !0,
        draggable: !0,
        role: !0,
        tabindex: !0
      });
      var c = ae(e);
      n = xt(c, t), a = pe(c), c.forEach(U), this.h();
    },
    h() {
      v(e, "class", "draggable-box svelte-cxu8lj"), v(e, "id", o = /*elem_id*/
      i[1] + "-box-" + /*i*/
      i[68]), v(e, "draggable", "true"), v(e, "role", "button"), v(e, "tabindex", "0");
    },
    m(u, c) {
      Oe(u, e, c), P(e, n), P(e, a), l || (r = [
        K(e, "dragstart", s),
        K(e, "dragend", Bl)
      ], l = !0);
    },
    p(u, c) {
      i = u, c[0] & /*boxes*/
      128 && t !== (t = /*box*/
      i[80].label + "") && Ln(n, t), c[0] & /*elem_id*/
      2 && o !== (o = /*elem_id*/
      i[1] + "-box-" + /*i*/
      i[68]) && v(e, "id", o);
    },
    d(u) {
      u && U(e), l = !1, Bt(r);
    }
  };
}
function Pa(i) {
  let e, t, n, a = "Configuration Email", o, l, r = "×", s, u, c, g = "Destinataires :", _, m, b, w = "+", y, x, p, d = "Sauvegarder", h, D, F, S = $t(
    /*recipientFields*/
    i[18]
  ), O = [];
  for (let k = 0; k < S.length; k += 1)
    O[k] = za(Na(i, S, k));
  return {
    c() {
      e = X("div"), t = X("div"), n = X("h4"), n.textContent = a, o = he(), l = X("button"), l.textContent = r, s = he(), u = X("div"), c = X("label"), c.textContent = g, _ = he();
      for (let k = 0; k < O.length; k += 1)
        O[k].c();
      m = he(), b = X("button"), b.textContent = w, y = he(), x = X("div"), p = X("button"), p.textContent = d, this.h();
    },
    l(k) {
      e = Z(k, "DIV", { class: !0, id: !0 });
      var A = ae(e);
      t = Z(A, "DIV", { class: !0 });
      var $ = ae(t);
      n = Z($, "H4", { class: !0, "data-svelte-h": !0 }), Ut(n) !== "svelte-19roke8" && (n.textContent = a), o = pe($), l = Z($, "BUTTON", {
        class: !0,
        "aria-label": !0,
        title: !0,
        "data-svelte-h": !0
      }), Ut(l) !== "svelte-wpdfr0" && (l.textContent = r), $.forEach(U), s = pe(A), u = Z(A, "DIV", { class: !0 });
      var L = ae(u);
      c = Z(L, "LABEL", { class: !0, "data-svelte-h": !0 }), Ut(c) !== "svelte-1pn0zpc" && (c.textContent = g), _ = pe(L);
      for (let Q = 0; Q < O.length; Q += 1)
        O[Q].l(L);
      m = pe(L), b = Z(L, "BUTTON", {
        class: !0,
        title: !0,
        "data-svelte-h": !0
      }), Ut(b) !== "svelte-ua63w4" && (b.textContent = w), y = pe(L), x = Z(L, "DIV", { class: !0 });
      var ce = ae(x);
      p = Z(ce, "BUTTON", { class: !0, "data-svelte-h": !0 }), Ut(p) !== "svelte-9bmm2i" && (p.textContent = d), ce.forEach(U), L.forEach(U), A.forEach(U), this.h();
    },
    h() {
      v(n, "class", "svelte-cxu8lj"), v(l, "class", "close-config-button svelte-cxu8lj"), v(l, "aria-label", "Fermer la configuration"), v(l, "title", "Fermer"), v(t, "class", "email-config-header svelte-cxu8lj"), v(c, "class", "svelte-cxu8lj"), v(b, "class", "add-recipient-button svelte-cxu8lj"), v(b, "title", "Ajouter un destinataire"), v(p, "class", "btn-save svelte-cxu8lj"), v(x, "class", "email-config-buttons svelte-cxu8lj"), v(u, "class", "email-config-content svelte-cxu8lj"), v(e, "class", "email-config-panel svelte-cxu8lj"), v(e, "id", h = /*elem_id*/
      i[1] + "-email-config");
    },
    m(k, A) {
      Oe(k, e, A), P(e, t), P(t, n), P(t, o), P(t, l), P(e, s), P(e, u), P(u, c), P(u, _);
      for (let $ = 0; $ < O.length; $ += 1)
        O[$] && O[$].m(u, null);
      P(u, m), P(u, b), P(u, y), P(u, x), P(x, p), D || (F = [
        K(
          l,
          "click",
          /*closeEmailConfig*/
          i[27]
        ),
        K(
          b,
          "click",
          /*addRecipientField*/
          i[29]
        ),
        K(
          p,
          "click",
          /*saveEmailConfig*/
          i[28]
        )
      ], D = !0);
    },
    p(k, A) {
      if (A[0] & /*removeRecipientField, recipientFields*/
      1074003968) {
        S = $t(
          /*recipientFields*/
          k[18]
        );
        let $;
        for ($ = 0; $ < S.length; $ += 1) {
          const L = Na(k, S, $);
          O[$] ? O[$].p(L, A) : (O[$] = za(L), O[$].c(), O[$].m(u, m));
        }
        for (; $ < O.length; $ += 1)
          O[$].d(1);
        O.length = S.length;
      }
      A[0] & /*elem_id*/
      2 && h !== (h = /*elem_id*/
      k[1] + "-email-config") && v(e, "id", h);
    },
    d(k) {
      k && U(e), Sn(O, k), D = !1, Bt(F);
    }
  };
}
function qa(i) {
  let e, t = "×", n, a;
  function o() {
    return (
      /*click_handler*/
      i[38](
        /*index*/
        i[79]
      )
    );
  }
  return {
    c() {
      e = X("button"), e.textContent = t, this.h();
    },
    l(l) {
      e = Z(l, "BUTTON", {
        class: !0,
        "aria-label": !0,
        title: !0,
        "data-svelte-h": !0
      }), Ut(e) !== "svelte-14day9s" && (e.textContent = t), this.h();
    },
    h() {
      v(e, "class", "remove-recipient-button svelte-cxu8lj"), v(e, "aria-label", "Supprimer ce destinataire"), v(e, "title", "Supprimer");
    },
    m(l, r) {
      Oe(l, e, r), n || (a = K(e, "click", o), n = !0);
    },
    p(l, r) {
      i = l;
    },
    d(l) {
      l && U(e), n = !1, a();
    }
  };
}
function za(i) {
  let e, t, n, a, o, l;
  function r() {
    i[37].call(
      t,
      /*index*/
      i[79]
    );
  }
  let s = (
    /*recipientFields*/
    i[18].length > 1 && qa(i)
  );
  return {
    c() {
      e = X("div"), t = X("input"), n = he(), s && s.c(), a = he(), this.h();
    },
    l(u) {
      e = Z(u, "DIV", { class: !0 });
      var c = ae(e);
      t = Z(c, "INPUT", {
        type: !0,
        placeholder: !0,
        class: !0
      }), n = pe(c), s && s.l(c), a = pe(c), c.forEach(U), this.h();
    },
    h() {
      v(t, "type", "email"), v(t, "placeholder", "email@example.com"), v(t, "class", "recipient-input svelte-cxu8lj"), v(e, "class", "recipient-field-container svelte-cxu8lj");
    },
    m(u, c) {
      Oe(u, e, c), P(e, t), Ra(
        t,
        /*recipientFields*/
        i[18][
          /*index*/
          i[79]
        ]
      ), P(e, n), s && s.m(e, null), P(e, a), o || (l = K(t, "input", r), o = !0);
    },
    p(u, c) {
      i = u, c[0] & /*recipientFields*/
      262144 && t.value !== /*recipientFields*/
      i[18][
        /*index*/
        i[79]
      ] && Ra(
        t,
        /*recipientFields*/
        i[18][
          /*index*/
          i[79]
        ]
      ), /*recipientFields*/
      i[18].length > 1 ? s ? s.p(i, c) : (s = qa(i), s.c(), s.m(e, a)) : s && (s.d(1), s = null);
    },
    d(u) {
      u && U(e), s && s.d(), o = !1, l();
    }
  };
}
function Ua(i) {
  let e, t, n;
  return {
    c() {
      e = wi("path"), this.h();
    },
    l(a) {
      e = Ei(a, "path", {
        id: !0,
        class: !0,
        d: !0,
        stroke: !0,
        "stroke-width": !0,
        fill: !0
      }), ae(e).forEach(U), this.h();
    },
    h() {
      v(e, "id", t = /*elem_id*/
      i[1] + "-connection-" + /*i*/
      i[68]), v(e, "class", "connection-path svelte-cxu8lj"), v(e, "d", n = On(
        /*fromNode*/
        i[70].x + /*fromNode*/
        (i[70].type === "email" ? 40 : 100) + /*offset*/
        i[12].x,
        /*fromNode*/
        i[70].y + /*fromNodeHeight*/
        i[75] / 2 + /*offset*/
        i[12].y,
        /*toNode*/
        i[71].x + /*offset*/
        i[12].x,
        /*toNode*/
        i[71].y + /*toNodeHeight*/
        i[76] / 2 + /*offset*/
        i[12].y
      )), v(e, "stroke", "#666"), v(e, "stroke-width", "2"), v(e, "fill", "none");
    },
    m(a, o) {
      Oe(a, e, o);
    },
    p(a, o) {
      o[0] & /*elem_id*/
      2 && t !== (t = /*elem_id*/
      a[1] + "-connection-" + /*i*/
      a[68]) && v(e, "id", t), o[0] & /*nodes, connections, offset, elem_id*/
      7170 && n !== (n = On(
        /*fromNode*/
        a[70].x + /*fromNode*/
        (a[70].type === "email" ? 40 : 100) + /*offset*/
        a[12].x,
        /*fromNode*/
        a[70].y + /*fromNodeHeight*/
        a[75] / 2 + /*offset*/
        a[12].y,
        /*toNode*/
        a[71].x + /*offset*/
        a[12].x,
        /*toNode*/
        a[71].y + /*toNodeHeight*/
        a[76] / 2 + /*offset*/
        a[12].y
      )) && v(e, "d", n);
    },
    d(a) {
      a && U(e);
    }
  };
}
function Ha(i) {
  let e, t = (
    /*fromNode*/
    i[70] && /*toNode*/
    i[71] && Ua(ti(i))
  );
  return {
    c() {
      t && t.c(), e = jt();
    },
    l(n) {
      t && t.l(n), e = jt();
    },
    m(n, a) {
      t && t.m(n, a), Oe(n, e, a);
    },
    p(n, a) {
      /*fromNode*/
      n[70] && /*toNode*/
      n[71] ? t ? t.p(ti(n), a) : (t = Ua(ti(n)), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && U(e), t && t.d(n);
    }
  };
}
function Ga(i) {
  let e, t, n;
  return {
    c() {
      e = wi("path"), this.h();
    },
    l(a) {
      e = Ei(a, "path", {
        id: !0,
        class: !0,
        d: !0,
        stroke: !0,
        "stroke-width": !0,
        "stroke-dasharray": !0,
        fill: !0
      }), ae(e).forEach(U), this.h();
    },
    h() {
      v(e, "id", t = /*elem_id*/
      i[1] + "-temp-connection"), v(e, "class", "temp-connection-path svelte-cxu8lj"), v(e, "d", n = On(
        /*tempConnection*/
        i[15].from.x + /*offset*/
        i[12].x,
        /*tempConnection*/
        i[15].from.y + /*offset*/
        i[12].y,
        /*tempConnection*/
        i[15].to.x + /*offset*/
        i[12].x,
        /*tempConnection*/
        i[15].to.y + /*offset*/
        i[12].y
      )), v(e, "stroke", "#999"), v(e, "stroke-width", "2"), v(e, "stroke-dasharray", "5,5"), v(e, "fill", "none");
    },
    m(a, o) {
      Oe(a, e, o);
    },
    p(a, o) {
      o[0] & /*elem_id*/
      2 && t !== (t = /*elem_id*/
      a[1] + "-temp-connection") && v(e, "id", t), o[0] & /*tempConnection, offset*/
      36864 && n !== (n = On(
        /*tempConnection*/
        a[15].from.x + /*offset*/
        a[12].x,
        /*tempConnection*/
        a[15].from.y + /*offset*/
        a[12].y,
        /*tempConnection*/
        a[15].to.x + /*offset*/
        a[12].x,
        /*tempConnection*/
        a[15].to.y + /*offset*/
        a[12].y
      )) && v(e, "d", n);
    },
    d(a) {
      a && U(e);
    }
  };
}
function Ns(i) {
  let e, t, n, a, o, l, r, s, u = (
    /*node*/
    i[66].label + ""
  ), c, g, _, m, b, w, y, x, p, d;
  function h() {
    return (
      /*click_handler_3*/
      i[46](
        /*i*/
        i[68]
      )
    );
  }
  let D = (
    /*isConnecting*/
    i[13] && ja(i)
  );
  function F(...k) {
    return (
      /*mousedown_handler_2*/
      i[49](
        /*i*/
        i[68],
        ...k
      )
    );
  }
  function S(...k) {
    return (
      /*keydown_handler_5*/
      i[50](
        /*i*/
        i[68],
        ...k
      )
    );
  }
  function O(...k) {
    return (
      /*mousedown_handler_3*/
      i[51](
        /*i*/
        i[68],
        ...k
      )
    );
  }
  return {
    c() {
      e = X("div"), t = X("button"), n = Lt("×"), l = he(), D && D.c(), r = he(), s = X("span"), c = Lt(u), _ = he(), m = X("div"), w = he(), this.h();
    },
    l(k) {
      e = Z(k, "DIV", {
        class: !0,
        id: !0,
        "data-type": !0,
        role: !0,
        tabindex: !0,
        "aria-label": !0,
        style: !0
      });
      var A = ae(e);
      t = Z(A, "BUTTON", {
        class: !0,
        id: !0,
        "aria-label": !0,
        title: !0
      });
      var $ = ae(t);
      n = xt($, "×"), $.forEach(U), l = pe(A), D && D.l(A), r = pe(A), s = Z(A, "SPAN", { class: !0, id: !0 });
      var L = ae(s);
      c = xt(L, u), L.forEach(U), _ = pe(A), m = Z(A, "DIV", {
        class: !0,
        id: !0,
        role: !0,
        tabindex: !0,
        "aria-label": !0,
        style: !0
      }), ae(m).forEach(U), w = pe(A), A.forEach(U), this.h();
    },
    h() {
      v(t, "class", "delete-button svelte-cxu8lj"), v(t, "id", a = /*elem_id*/
      i[1] + "-delete-button-" + /*i*/
      i[68]), v(t, "aria-label", o = "Supprimer le nœud " + /*node*/
      i[66].label), v(t, "title", "Supprimer le nœud"), v(s, "class", "node-label svelte-cxu8lj"), v(s, "id", g = /*elem_id*/
      i[1] + "-node-label-" + /*i*/
      i[68]), v(m, "class", "connector output-connector svelte-cxu8lj"), v(m, "id", b = /*elem_id*/
      i[1] + "-output-connector-" + /*i*/
      i[68]), v(m, "role", "button"), v(m, "tabindex", "0"), v(m, "aria-label", "Point de connexion de sortie"), Me(m, "opacity", "0"), v(e, "class", "workflow-node svelte-cxu8lj"), v(e, "id", y = /*elem_id*/
      i[1] + "-node-" + /*i*/
      i[68]), v(e, "data-type", "node"), v(e, "role", "button"), v(e, "tabindex", "0"), v(e, "aria-label", x = "Nœud - " + /*node*/
      i[66].label), Me(
        e,
        "left",
        /*node*/
        i[66].x + /*offset*/
        i[12].x + "px"
      ), Me(
        e,
        "top",
        /*node*/
        i[66].y + /*offset*/
        i[12].y + "px"
      ), Me(
        e,
        "border",
        /*connectionStart*/
        i[14] === /*i*/
        i[68] ? "2px solid #007acc" : "1px solid #999"
      );
    },
    m(k, A) {
      Oe(k, e, A), P(e, t), P(t, n), P(e, l), D && D.m(e, null), P(e, r), P(e, s), P(s, c), P(e, _), P(e, m), P(e, w), p || (d = [
        K(t, "click", pi(h)),
        K(m, "mousedown", F),
        K(m, "mouseenter", Gs),
        K(m, "mouseleave", js),
        K(m, "keydown", S),
        K(e, "mousedown", O),
        K(e, "keydown", Vs)
      ], p = !0);
    },
    p(k, A) {
      i = k, A[0] & /*elem_id*/
      2 && a !== (a = /*elem_id*/
      i[1] + "-delete-button-" + /*i*/
      i[68]) && v(t, "id", a), A[0] & /*nodes*/
      1024 && o !== (o = "Supprimer le nœud " + /*node*/
      i[66].label) && v(t, "aria-label", o), /*isConnecting*/
      i[13] ? D ? D.p(i, A) : (D = ja(i), D.c(), D.m(e, r)) : D && (D.d(1), D = null), A[0] & /*nodes*/
      1024 && u !== (u = /*node*/
      i[66].label + "") && Ln(c, u), A[0] & /*elem_id*/
      2 && g !== (g = /*elem_id*/
      i[1] + "-node-label-" + /*i*/
      i[68]) && v(s, "id", g), A[0] & /*elem_id*/
      2 && b !== (b = /*elem_id*/
      i[1] + "-output-connector-" + /*i*/
      i[68]) && v(m, "id", b), A[0] & /*elem_id*/
      2 && y !== (y = /*elem_id*/
      i[1] + "-node-" + /*i*/
      i[68]) && v(e, "id", y), A[0] & /*nodes*/
      1024 && x !== (x = "Nœud - " + /*node*/
      i[66].label) && v(e, "aria-label", x), A[0] & /*nodes, offset*/
      5120 && Me(
        e,
        "left",
        /*node*/
        i[66].x + /*offset*/
        i[12].x + "px"
      ), A[0] & /*nodes, offset*/
      5120 && Me(
        e,
        "top",
        /*node*/
        i[66].y + /*offset*/
        i[12].y + "px"
      ), A[0] & /*connectionStart*/
      16384 && Me(
        e,
        "border",
        /*connectionStart*/
        i[14] === /*i*/
        i[68] ? "2px solid #007acc" : "1px solid #999"
      );
    },
    d(k) {
      k && U(e), D && D.d(), p = !1, Bt(d);
    }
  };
}
function Os(i) {
  let e, t, n, a, o, l, r, s, u, c, g, _, m, b, w, y, x, p, d, h;
  function D() {
    return (
      /*click_handler_1*/
      i[39](
        /*i*/
        i[68]
      )
    );
  }
  function F(...$) {
    return (
      /*click_handler_2*/
      i[40](
        /*i*/
        i[68],
        ...$
      )
    );
  }
  let S = (
    /*isConnecting*/
    i[13] && Va(i)
  );
  function O(...$) {
    return (
      /*mousedown_handler*/
      i[43](
        /*i*/
        i[68],
        ...$
      )
    );
  }
  function k(...$) {
    return (
      /*keydown_handler_2*/
      i[44](
        /*i*/
        i[68],
        ...$
      )
    );
  }
  function A(...$) {
    return (
      /*mousedown_handler_1*/
      i[45](
        /*i*/
        i[68],
        ...$
      )
    );
  }
  return {
    c() {
      e = X("div"), t = X("button"), n = Lt("×"), o = he(), l = X("button"), r = Lt("⚙"), u = he(), S && S.c(), c = he(), g = X("img"), m = he(), b = X("div"), p = he(), this.h();
    },
    l($) {
      e = Z($, "DIV", {
        class: !0,
        id: !0,
        "data-type": !0,
        role: !0,
        tabindex: !0,
        "aria-label": !0,
        style: !0
      });
      var L = ae(e);
      t = Z(L, "BUTTON", {
        class: !0,
        id: !0,
        "aria-label": !0,
        title: !0
      });
      var ce = ae(t);
      n = xt(ce, "×"), ce.forEach(U), o = pe(L), l = Z(L, "BUTTON", {
        class: !0,
        id: !0,
        "aria-label": !0,
        title: !0
      });
      var Q = ae(l);
      r = xt(Q, "⚙"), Q.forEach(U), u = pe(L), S && S.l(L), c = pe(L), g = Z(L, "IMG", { src: !0, alt: !0, class: !0 }), m = pe(L), b = Z(L, "DIV", {
        class: !0,
        id: !0,
        role: !0,
        tabindex: !0,
        "aria-label": !0,
        style: !0
      }), ae(b).forEach(U), L.forEach(U), p = pe($), this.h();
    },
    h() {
      v(t, "class", "delete-button svelte-cxu8lj"), v(t, "id", a = /*elem_id*/
      i[1] + "-delete-button-" + /*i*/
      i[68]), v(t, "aria-label", "Supprimer le nœud email"), v(t, "title", "Supprimer le nœud"), v(l, "class", "config-email-button svelte-cxu8lj"), v(l, "id", s = /*elem_id*/
      i[1] + "-config-button-" + /*i*/
      i[68]), v(l, "aria-label", "Configurer le nœud email"), v(l, "title", "Configurer les destinataires"), Ol(g.src, _ = "https://upload.wikimedia.org/wikipedia/commons/7/7e/Gmail_icon_%282020%29.svg") || v(g, "src", _), v(g, "alt", "Gmail"), v(g, "class", "email-node-icon svelte-cxu8lj"), v(b, "class", "connector output-connector svelte-cxu8lj"), v(b, "id", w = /*elem_id*/
      i[1] + "-output-connector-" + /*i*/
      i[68]), v(b, "role", "button"), v(b, "tabindex", "0"), v(b, "aria-label", "Point de connexion de sortie"), Me(b, "opacity", "0"), v(e, "class", "workflow-node email-node svelte-cxu8lj"), v(e, "id", y = /*elem_id*/
      i[1] + "-node-" + /*i*/
      i[68]), v(e, "data-type", "node"), v(e, "role", "button"), v(e, "tabindex", "0"), v(e, "aria-label", x = "Nœud email - " + /*node*/
      i[66].label), Me(
        e,
        "left",
        /*node*/
        i[66].x + /*offset*/
        i[12].x + "px"
      ), Me(
        e,
        "top",
        /*node*/
        i[66].y + /*offset*/
        i[12].y + "px"
      ), Me(
        e,
        "border",
        /*connectionStart*/
        i[14] === /*i*/
        i[68] ? "2px solid #007acc" : "1px solid #ccc"
      );
    },
    m($, L) {
      Oe($, e, L), P(e, t), P(t, n), P(e, o), P(e, l), P(l, r), P(e, u), S && S.m(e, null), P(e, c), P(e, g), P(e, m), P(e, b), Oe($, p, L), d || (h = [
        K(t, "click", pi(D)),
        K(l, "click", pi(F)),
        K(b, "mousedown", O),
        K(b, "mouseenter", zs),
        K(b, "mouseleave", Us),
        K(b, "keydown", k),
        K(e, "mousedown", A),
        K(e, "keydown", Hs)
      ], d = !0);
    },
    p($, L) {
      i = $, L[0] & /*elem_id*/
      2 && a !== (a = /*elem_id*/
      i[1] + "-delete-button-" + /*i*/
      i[68]) && v(t, "id", a), L[0] & /*elem_id*/
      2 && s !== (s = /*elem_id*/
      i[1] + "-config-button-" + /*i*/
      i[68]) && v(l, "id", s), /*isConnecting*/
      i[13] ? S ? S.p(i, L) : (S = Va(i), S.c(), S.m(e, c)) : S && (S.d(1), S = null), L[0] & /*elem_id*/
      2 && w !== (w = /*elem_id*/
      i[1] + "-output-connector-" + /*i*/
      i[68]) && v(b, "id", w), L[0] & /*elem_id*/
      2 && y !== (y = /*elem_id*/
      i[1] + "-node-" + /*i*/
      i[68]) && v(e, "id", y), L[0] & /*nodes*/
      1024 && x !== (x = "Nœud email - " + /*node*/
      i[66].label) && v(e, "aria-label", x), L[0] & /*nodes, offset*/
      5120 && Me(
        e,
        "left",
        /*node*/
        i[66].x + /*offset*/
        i[12].x + "px"
      ), L[0] & /*nodes, offset*/
      5120 && Me(
        e,
        "top",
        /*node*/
        i[66].y + /*offset*/
        i[12].y + "px"
      ), L[0] & /*connectionStart*/
      16384 && Me(
        e,
        "border",
        /*connectionStart*/
        i[14] === /*i*/
        i[68] ? "2px solid #007acc" : "1px solid #ccc"
      );
    },
    d($) {
      $ && (U(e), U(p)), S && S.d(), d = !1, Bt(h);
    }
  };
}
function ja(i) {
  let e, t, n, a;
  function o(...r) {
    return (
      /*mouseup_handler_1*/
      i[47](
        /*i*/
        i[68],
        ...r
      )
    );
  }
  function l(...r) {
    return (
      /*keydown_handler_4*/
      i[48](
        /*i*/
        i[68],
        ...r
      )
    );
  }
  return {
    c() {
      e = X("div"), this.h();
    },
    l(r) {
      e = Z(r, "DIV", {
        class: !0,
        id: !0,
        role: !0,
        tabindex: !0,
        "aria-label": !0
      }), ae(e).forEach(U), this.h();
    },
    h() {
      v(e, "class", "connector input-connector svelte-cxu8lj"), v(e, "id", t = /*elem_id*/
      i[1] + "-input-connector-" + /*i*/
      i[68]), v(e, "role", "button"), v(e, "tabindex", "0"), v(e, "aria-label", "Point de connexion d'entrée");
    },
    m(r, s) {
      Oe(r, e, s), n || (a = [
        K(e, "mouseup", o),
        K(e, "keydown", l)
      ], n = !0);
    },
    p(r, s) {
      i = r, s[0] & /*elem_id*/
      2 && t !== (t = /*elem_id*/
      i[1] + "-input-connector-" + /*i*/
      i[68]) && v(e, "id", t);
    },
    d(r) {
      r && U(e), n = !1, Bt(a);
    }
  };
}
function Va(i) {
  let e, t, n, a;
  function o(...r) {
    return (
      /*mouseup_handler*/
      i[41](
        /*i*/
        i[68],
        ...r
      )
    );
  }
  function l(...r) {
    return (
      /*keydown_handler_1*/
      i[42](
        /*i*/
        i[68],
        ...r
      )
    );
  }
  return {
    c() {
      e = X("div"), this.h();
    },
    l(r) {
      e = Z(r, "DIV", {
        class: !0,
        id: !0,
        role: !0,
        tabindex: !0,
        "aria-label": !0
      }), ae(e).forEach(U), this.h();
    },
    h() {
      v(e, "class", "connector input-connector svelte-cxu8lj"), v(e, "id", t = /*elem_id*/
      i[1] + "-input-connector-" + /*i*/
      i[68]), v(e, "role", "button"), v(e, "tabindex", "0"), v(e, "aria-label", "Point de connexion d'entrée");
    },
    m(r, s) {
      Oe(r, e, s), n || (a = [
        K(e, "mouseup", o),
        K(e, "keydown", l)
      ], n = !0);
    },
    p(r, s) {
      i = r, s[0] & /*elem_id*/
      2 && t !== (t = /*elem_id*/
      i[1] + "-input-connector-" + /*i*/
      i[68]) && v(e, "id", t);
    },
    d(r) {
      r && U(e), n = !1, Bt(a);
    }
  };
}
function Ya(i) {
  let e;
  function t(o, l) {
    return (
      /*node*/
      o[66].type === "email" ? Os : Ns
    );
  }
  let n = t(i), a = n(i);
  return {
    c() {
      a.c(), e = jt();
    },
    l(o) {
      a.l(o), e = jt();
    },
    m(o, l) {
      a.m(o, l), Oe(o, e, l);
    },
    p(o, l) {
      n === (n = t(o)) && a ? a.p(o, l) : (a.d(1), a = n(o), a && (a.c(), a.m(e.parentNode, e)));
    },
    d(o) {
      o && U(e), a.d(o);
    }
  };
}
function Bs(i) {
  let e, t, n, a, o, l, r, s, u, c, g, _, m, b, w, y, x, p, d, h, D, F, S, O, k, A, $, L, ce, Q, ne, me, Ae, ie, W, De, I, H = (
    /*loading_status*/
    i[6] && Ba(i)
  ), J = $t(
    /*boxes*/
    i[7]
  ), j = [];
  for (let N = 0; N < J.length; N += 1)
    j[N] = Ma(Oa(i, J, N));
  let C = (
    /*showEmailConfig*/
    i[17] && Pa(i)
  ), ye = $t(
    /*connections*/
    i[11]
  ), le = [];
  for (let N = 0; N < ye.length; N += 1)
    le[N] = Ha(La(i, ye, N));
  let de = (
    /*tempConnection*/
    i[15] && Ga(i)
  ), Re = $t(
    /*nodes*/
    i[10]
  ), ue = [];
  for (let N = 0; N < Re.length; N += 1)
    ue[N] = Ya(xa(i, Re, N));
  return {
    c() {
      H && H.c(), e = he(), t = X("div"), n = X("div"), a = X("div"), o = X("div"), l = X("h3"), r = Lt(
        /*label_list*/
        i[8]
      ), u = he(), c = X("div");
      for (let N = 0; N < j.length; N += 1)
        j[N].c();
      m = he(), b = X("div"), w = X("div"), y = X("h3"), x = Lt(
        /*label_workflow*/
        i[9]
      ), d = he(), h = X("div"), D = X("img"), O = he(), C && C.c(), k = he(), A = X("div"), $ = wi("svg");
      for (let N = 0; N < le.length; N += 1)
        le[N].c();
      L = jt(), de && de.c(), Q = he();
      for (let N = 0; N < ue.length; N += 1)
        ue[N].c();
      this.h();
    },
    l(N) {
      H && H.l(N), e = pe(N), t = Z(N, "DIV", { class: !0, id: !0 });
      var V = ae(t);
      n = Z(V, "DIV", { class: !0, id: !0 });
      var B = ae(n);
      a = Z(B, "DIV", { class: !0, id: !0 });
      var ge = ae(a);
      o = Z(ge, "DIV", { class: !0 });
      var yt = ae(o);
      l = Z(yt, "H3", { id: !0, class: !0 });
      var Et = ae(l);
      r = xt(
        Et,
        /*label_list*/
        i[8]
      ), Et.forEach(U), yt.forEach(U), u = pe(ge), c = Z(ge, "DIV", { class: !0, id: !0 });
      var Ke = ae(c);
      for (let we = 0; we < j.length; we += 1)
        j[we].l(Ke);
      Ke.forEach(U), ge.forEach(U), m = pe(B), b = Z(B, "DIV", { class: !0, id: !0 });
      var Pe = ae(b);
      w = Z(Pe, "DIV", { class: !0 });
      var Qe = ae(w);
      y = Z(Qe, "H3", { id: !0, class: !0 });
      var Ct = ae(y);
      x = xt(
        Ct,
        /*label_workflow*/
        i[9]
      ), Ct.forEach(U), d = pe(Qe), h = Z(Qe, "DIV", {
        class: !0,
        id: !0,
        draggable: !0,
        role: !0,
        tabindex: !0,
        title: !0
      });
      var St = ae(h);
      D = Z(St, "IMG", { src: !0, alt: !0, class: !0 }), St.forEach(U), Qe.forEach(U), O = pe(Pe), C && C.l(Pe), k = pe(Pe), A = Z(Pe, "DIV", {
        class: !0,
        id: !0,
        role: !0,
        "aria-label": !0
      });
      var wt = ae(A);
      $ = Ei(wt, "svg", { class: !0, id: !0 });
      var mt = ae($);
      for (let we = 0; we < le.length; we += 1)
        le[we].l(mt);
      L = jt(), de && de.l(mt), mt.forEach(U), Q = pe(wt);
      for (let we = 0; we < ue.length; we += 1)
        ue[we].l(wt);
      wt.forEach(U), Pe.forEach(U), B.forEach(U), V.forEach(U), this.h();
    },
    h() {
      v(l, "id", s = /*elem_id*/
      i[1] + "-agents-title"), v(l, "class", "svelte-cxu8lj"), v(o, "class", "agents-header svelte-cxu8lj"), v(c, "class", "boxes-container svelte-cxu8lj"), v(c, "id", g = /*elem_id*/
      i[1] + "-boxes-container"), v(a, "class", "agents-list svelte-cxu8lj"), v(a, "id", _ = /*elem_id*/
      i[1] + "-agents-list"), v(y, "id", p = /*elem_id*/
      i[1] + "-workflow-title"), v(y, "class", "svelte-cxu8lj"), Ol(D.src, F = "https://upload.wikimedia.org/wikipedia/commons/7/7e/Gmail_icon_%282020%29.svg") || v(D, "src", F), v(D, "alt", "Gmail"), v(D, "class", "email-button-icon svelte-cxu8lj"), v(h, "class", "email-button svelte-cxu8lj"), v(h, "id", S = /*elem_id*/
      i[1] + "-email-button"), v(h, "draggable", "true"), v(h, "role", "button"), v(h, "tabindex", "0"), v(h, "title", "Glisser pour ajouter un bloc Email"), v(w, "class", "workflow-header svelte-cxu8lj"), v($, "class", "connections-svg svelte-cxu8lj"), v($, "id", ce = /*elem_id*/
      i[1] + "-connections-svg"), v(A, "class", "canvas-area svelte-cxu8lj"), v(A, "id", ne = /*elem_id*/
      i[1] + "-canvas-area"), v(A, "role", "application"), v(A, "aria-label", "Workflow canvas"), v(b, "class", "workflow-canvas svelte-cxu8lj"), v(b, "id", me = /*elem_id*/
      i[1] + "-workflow-canvas"), v(n, "class", "workflow-main svelte-cxu8lj"), v(n, "id", Ae = /*elem_id*/
      i[1] + "-main"), v(t, "class", "canvas-workflow-container svelte-cxu8lj"), v(t, "id", ie = /*elem_id*/
      i[1] + "-container");
    },
    m(N, V) {
      H && H.m(N, V), Oe(N, e, V), Oe(N, t, V), P(t, n), P(n, a), P(a, o), P(o, l), P(l, r), P(a, u), P(a, c);
      for (let B = 0; B < j.length; B += 1)
        j[B] && j[B].m(c, null);
      P(n, m), P(n, b), P(b, w), P(w, y), P(y, x), P(w, d), P(w, h), P(h, D), P(b, O), C && C.m(b, null), P(b, k), P(b, A), P(A, $);
      for (let B = 0; B < le.length; B += 1)
        le[B] && le[B].m($, null);
      P($, L), de && de.m($, null), P(A, Q);
      for (let B = 0; B < ue.length; B += 1)
        ue[B] && ue[B].m(A, null);
      i[52](A), W = !0, De || (I = [
        K(
          h,
          "dragstart",
          /*dragstart_handler_1*/
          i[36]
        ),
        K(h, "dragend", Bl),
        K(h, "keydown", qs),
        K(A, "dragover", Ys),
        K(
          A,
          "drop",
          /*drop_handler*/
          i[53]
        ),
        K(
          A,
          "mousedown",
          /*handleMouseDownPan*/
          i[19]
        ),
        K(
          A,
          "mousemove",
          /*handleMouseMovePan*/
          i[20]
        ),
        K(
          A,
          "mouseup",
          /*handleMouseUpPan*/
          i[21]
        )
      ], De = !0);
    },
    p(N, V) {
      if (/*loading_status*/
      N[6] ? H ? (H.p(N, V), V[0] & /*loading_status*/
      64 && rn(H, 1)) : (H = Ba(N), H.c(), rn(H, 1), H.m(e.parentNode, e)) : H && (Rs(), Nn(H, 1, 1, () => {
        H = null;
      }), Ss()), (!W || V[0] & /*label_list*/
      256) && Ln(
        r,
        /*label_list*/
        N[8]
      ), (!W || V[0] & /*elem_id*/
      2 && s !== (s = /*elem_id*/
      N[1] + "-agents-title")) && v(l, "id", s), V[0] & /*elem_id, boxes*/
      130) {
        J = $t(
          /*boxes*/
          N[7]
        );
        let B;
        for (B = 0; B < J.length; B += 1) {
          const ge = Oa(N, J, B);
          j[B] ? j[B].p(ge, V) : (j[B] = Ma(ge), j[B].c(), j[B].m(c, null));
        }
        for (; B < j.length; B += 1)
          j[B].d(1);
        j.length = J.length;
      }
      if ((!W || V[0] & /*elem_id*/
      2 && g !== (g = /*elem_id*/
      N[1] + "-boxes-container")) && v(c, "id", g), (!W || V[0] & /*elem_id*/
      2 && _ !== (_ = /*elem_id*/
      N[1] + "-agents-list")) && v(a, "id", _), (!W || V[0] & /*label_workflow*/
      512) && Ln(
        x,
        /*label_workflow*/
        N[9]
      ), (!W || V[0] & /*elem_id*/
      2 && p !== (p = /*elem_id*/
      N[1] + "-workflow-title")) && v(y, "id", p), (!W || V[0] & /*elem_id*/
      2 && S !== (S = /*elem_id*/
      N[1] + "-email-button")) && v(h, "id", S), /*showEmailConfig*/
      N[17] ? C ? C.p(N, V) : (C = Pa(N), C.c(), C.m(b, k)) : C && (C.d(1), C = null), V[0] & /*elem_id, nodes, connections, offset*/
      7170) {
        ye = $t(
          /*connections*/
          N[11]
        );
        let B;
        for (B = 0; B < ye.length; B += 1) {
          const ge = La(N, ye, B);
          le[B] ? le[B].p(ge, V) : (le[B] = Ha(ge), le[B].c(), le[B].m($, L));
        }
        for (; B < le.length; B += 1)
          le[B].d(1);
        le.length = ye.length;
      }
      if (/*tempConnection*/
      N[15] ? de ? de.p(N, V) : (de = Ga(N), de.c(), de.m($, null)) : de && (de.d(1), de = null), (!W || V[0] & /*elem_id*/
      2 && ce !== (ce = /*elem_id*/
      N[1] + "-connections-svg")) && v($, "id", ce), V[0] & /*elem_id, nodes, offset, connectionStart, handleNodeMouseDown, startConnection, endConnection, isConnecting, handleEmailConfigClick, deleteNode*/
      130053122) {
        Re = $t(
          /*nodes*/
          N[10]
        );
        let B;
        for (B = 0; B < Re.length; B += 1) {
          const ge = xa(N, Re, B);
          ue[B] ? ue[B].p(ge, V) : (ue[B] = Ya(ge), ue[B].c(), ue[B].m(A, null));
        }
        for (; B < ue.length; B += 1)
          ue[B].d(1);
        ue.length = Re.length;
      }
      (!W || V[0] & /*elem_id*/
      2 && ne !== (ne = /*elem_id*/
      N[1] + "-canvas-area")) && v(A, "id", ne), (!W || V[0] & /*elem_id*/
      2 && me !== (me = /*elem_id*/
      N[1] + "-workflow-canvas")) && v(b, "id", me), (!W || V[0] & /*elem_id*/
      2 && Ae !== (Ae = /*elem_id*/
      N[1] + "-main")) && v(n, "id", Ae), (!W || V[0] & /*elem_id*/
      2 && ie !== (ie = /*elem_id*/
      N[1] + "-container")) && v(t, "id", ie);
    },
    i(N) {
      W || (rn(H), W = !0);
    },
    o(N) {
      Nn(H), W = !1;
    },
    d(N) {
      N && (U(e), U(t)), H && H.d(N), Sn(j, N), C && C.d(), Sn(le, N), de && de.d(), Sn(ue, N), i[52](null), De = !1, Bt(I);
    }
  };
}
function Ms(i) {
  let e, t;
  return e = new so({
    props: {
      visible: (
        /*visible*/
        i[3]
      ),
      elem_id: (
        /*elem_id*/
        i[1]
      ),
      elem_classes: (
        /*elem_classes*/
        i[2]
      ),
      scale: (
        /*scale*/
        i[4]
      ),
      min_width: (
        /*min_width*/
        i[5]
      ),
      allow_overflow: !1,
      padding: !0,
      $$slots: { default: [Bs] },
      $$scope: { ctx: i }
    }
  }), {
    c() {
      xl(e.$$.fragment);
    },
    l(n) {
      Rl(e.$$.fragment, n);
    },
    m(n, a) {
      Nl(e, n, a), t = !0;
    },
    p(n, a) {
      const o = {};
      a[0] & /*visible*/
      8 && (o.visible = /*visible*/
      n[3]), a[0] & /*elem_id*/
      2 && (o.elem_id = /*elem_id*/
      n[1]), a[0] & /*elem_classes*/
      4 && (o.elem_classes = /*elem_classes*/
      n[2]), a[0] & /*scale*/
      16 && (o.scale = /*scale*/
      n[4]), a[0] & /*min_width*/
      32 && (o.min_width = /*min_width*/
      n[5]), a[0] & /*elem_id, workflowRef, offset, nodes, connectionStart, isConnecting, tempConnection, connections, recipientFields, showEmailConfig, label_workflow, boxes, label_list, loading_status, gradio*/
      524227 | a[2] & /*$$scope*/
      1048576 && (o.$$scope = { dirty: a, ctx: n }), e.$set(o);
    },
    i(n) {
      t || (rn(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Nn(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Ll(e, n);
    }
  };
}
function Ps(i) {
  if (!i.agents) return { nodes: [], connections: [] };
  const e = /* @__PURE__ */ new Map();
  i.agents.forEach((a, o) => {
    e.set(a.id, o);
  });
  const t = i.agents.map((a, o) => {
    const l = Math.floor(o / 3), s = 50 + o % 3 * 150, u = 50 + l * 100;
    return {
      id: `node_${a.id}`,
      id_original: a.id,
      label: a.id,
      // Utiliser l'ID comme label pour le moment
      type: a.type,
      x: s,
      y: u
    };
  }), n = (i.flow || []).map((a, o) => {
    const l = e.get(a.from), r = e.get(a.to);
    return {
      id: `conn_${l}_${r}`,
      from: l,
      to: r
    };
  }).filter((a) => a.from !== void 0 && a.to !== void 0);
  return {
    nodes: t,
    connections: n
  };
}
function Wa(i, e) {
  var t;
  (t = i.dataTransfer) == null || t.setData("text/plain", JSON.stringify(e)), i.target.style.cursor = "grabbing";
}
function Bl(i) {
  i.target.style.cursor = "grab";
}
function On(i, e, t, n) {
  const a = t - i, o = i + Math.abs(a) * 0.5, l = e, r = t - Math.abs(a) * 0.5;
  return `M ${i} ${e} C ${o} ${l}, ${r} ${n}, ${t} ${n}`;
}
const qs = (i) => {
  (i.key === "Enter" || i.key === " ") && i.preventDefault();
}, zs = (i) => i.currentTarget.style.opacity = "1", Us = (i) => i.currentTarget.style.opacity = "0", Hs = (i) => {
  (i.key === "Enter" || i.key === " ") && i.preventDefault();
}, Gs = (i) => i.currentTarget.style.opacity = "1", js = (i) => i.currentTarget.style.opacity = "0", Vs = (i) => {
  (i.key === "Enter" || i.key === " ") && i.preventDefault();
}, Ys = (i) => i.preventDefault();
function Ws(i, e, t) {
  let { gradio: n } = e, { elem_id: a = "" } = e, { elem_classes: o = [] } = e, { visible: l = !0 } = e, { value: r = { nodes: [], connections: [] } } = e, { show_label: s } = e, { scale: u = null } = e, { min_width: c = void 0 } = e, { loading_status: g = void 0 } = e, { value_is_output: _ = !1 } = e, { boxes: m = [] } = e, { label_list: b = "Agents" } = e, { label_workflow: w = "Workflow" } = e, y = [], x = [], p = { x: 0, y: 0 }, d = !1, h = !1, D = !1, F = null, S = null, O = { x: 0, y: 0 }, k = null, A = { x: 0, y: 0 }, $ = { x: 0, y: 0 }, L, ce = !1, Q = null, ne = [""];
  function me() {
    const E = {
      agents: y.map((T) => ({
        id: T.id_original || T.id,
        type: T.type || "agent",
        ...T.type === "email" && T.recipients && { recipients: T.recipients }
      })),
      flow: x.map((T) => {
        var te, ke, qe, Je;
        return {
          from: ((te = y[T.from]) == null ? void 0 : te.id_original) || ((ke = y[T.from]) == null ? void 0 : ke.id),
          to: ((qe = y[T.to]) == null ? void 0 : qe.id_original) || ((Je = y[T.to]) == null ? void 0 : Je.id)
        };
      })
    };
    t(31, r = E), n.dispatch("change"), _ || n.dispatch("input");
  }
  function Ae(E) {
    if (!(E.target.dataset.type === "node" || E.target.dataset.type === "connector")) {
      if (D) {
        t(13, D = !1), t(14, F = null), t(15, S = null);
        return;
      }
      d = !0, O = {
        x: E.clientX - p.x,
        y: E.clientY - p.y
      };
    }
  }
  function ie(E) {
    if (d && !h && t(12, p = {
      x: E.clientX - O.x,
      y: E.clientY - O.y
    }), D && F !== null && L) {
      const T = L.getBoundingClientRect(), te = y[F], ke = document.getElementById(`${a}-node-${F}`), qe = ke ? ke.offsetHeight : 30, Je = te.x + (te.type === "email" ? 40 : 100), Yt = te.y + qe / 2, Mn = E.clientX - T.left - p.x, Mt = E.clientY - T.top - p.y;
      t(15, S = {
        from: { x: Je, y: Yt },
        to: { x: Mn, y: Mt }
      });
    }
    h && J(E);
  }
  function W() {
    d = !1, D && (t(13, D = !1), t(14, F = null), t(15, S = null)), h = !1, k = null;
  }
  function De(E, T) {
    if (E.target.dataset.type === "connector") return;
    h = !0, k = T;
    const te = L.getBoundingClientRect();
    $ = { x: E.clientX, y: E.clientY }, A = {
      x: E.clientX - te.left - y[T].x - p.x,
      y: E.clientY - te.top - y[T].y - p.y
    };
  }
  function I(E, T) {
    E.stopPropagation(), ye(T);
  }
  function H(E) {
    t(10, y = y.filter((T, te) => te !== E)), t(11, x = x.filter((T) => T.from !== E && T.to !== E)), t(11, x = x.map((T) => ({
      ...T,
      from: T.from > E ? T.from - 1 : T.from,
      to: T.to > E ? T.to - 1 : T.to
    })));
  }
  function J(E) {
    if (h && k !== null && L) {
      Math.sqrt(Math.pow(E.clientX - $.x, 2) + Math.pow(E.clientY - $.y, 2));
      const T = L.getBoundingClientRect(), te = E.clientX - T.left - p.x - A.x, ke = E.clientY - T.top - p.y - A.y;
      t(
        10,
        y[k] = {
          ...y[k],
          x: te,
          y: ke
        },
        y
      );
    }
  }
  function j(E, T) {
    E.stopPropagation(), t(13, D = !0), t(14, F = T);
  }
  function C(E, T) {
    if (E.stopPropagation(), D && F !== null && F !== T) {
      const te = {
        id: `conn_${F}_${T}`,
        from: F,
        to: T
      };
      t(11, x = [...x, te]), t(15, S = null), t(13, D = !1), t(14, F = null);
    }
  }
  function ye(E) {
    const T = y[E];
    T.type === "email" && (Q = T, t(17, ce = !0), T.id, T.recipients && T.recipients.length > 0 ? t(18, ne = [...T.recipients]) : t(18, ne = [""]));
  }
  function le() {
    t(17, ce = !1), Q = null, t(18, ne = [""]);
  }
  function de() {
    if (Q) {
      const E = ne.map((te) => te.trim()).filter((te) => te.length > 0), T = y.findIndex((te) => te.id === Q.id);
      T !== -1 && t(10, y[T] = { ...y[T], recipients: E }, y);
    }
    le();
  }
  function Re() {
    t(18, ne = [...ne, ""]);
  }
  function ue(E) {
    ne.length > 1 && t(18, ne = ne.filter((T, te) => te !== E));
  }
  const N = () => n.dispatch("clear_status", g), V = (E, T) => Wa(T, E), B = (E) => Wa(E, { label: "Email", type: "email" });
  function ge(E) {
    ne[E] = this.value, t(18, ne);
  }
  const yt = (E) => ue(E), Et = (E) => H(E), Ke = (E, T) => I(T, E), Pe = (E, T) => C(T, E), Qe = (E, T) => {
    (T.key === "Enter" || T.key === " ") && (T.preventDefault(), C(T, E));
  }, Ct = (E, T) => j(T, E), St = (E, T) => {
    (T.key === "Enter" || T.key === " ") && (T.preventDefault(), j(T, E));
  }, wt = (E, T) => De(T, E), mt = (E) => H(E), we = (E, T) => C(T, E), kt = (E, T) => {
    (T.key === "Enter" || T.key === " ") && (T.preventDefault(), C(T, E));
  }, Ft = (E, T) => j(T, E), dn = (E, T) => {
    (T.key === "Enter" || T.key === " ") && (T.preventDefault(), j(T, E));
  }, _n = (E, T) => De(T, E);
  function fn(E) {
    Cs[E ? "unshift" : "push"](() => {
      L = E, t(16, L);
    });
  }
  const Vt = (E) => {
    var Je;
    E.preventDefault();
    const T = JSON.parse(((Je = E.dataTransfer) == null ? void 0 : Je.getData("text/plain")) || "{}"), te = L.getBoundingClientRect(), ke = E.clientX - te.left - p.x, qe = E.clientY - te.top - p.y;
    t(10, y = [
      ...y,
      {
        ...T,
        x: ke,
        y: qe,
        id: `node_${Date.now()}`,
        id_original: T.id
        // Conserver l'ID original de l'agent
      }
    ]);
  };
  return i.$$set = (E) => {
    "gradio" in E && t(0, n = E.gradio), "elem_id" in E && t(1, a = E.elem_id), "elem_classes" in E && t(2, o = E.elem_classes), "visible" in E && t(3, l = E.visible), "value" in E && t(31, r = E.value), "show_label" in E && t(32, s = E.show_label), "scale" in E && t(4, u = E.scale), "min_width" in E && t(5, c = E.min_width), "loading_status" in E && t(6, g = E.loading_status), "value_is_output" in E && t(33, _ = E.value_is_output), "boxes" in E && t(7, m = E.boxes), "label_list" in E && t(8, b = E.label_list), "label_workflow" in E && t(9, w = E.label_workflow);
  }, i.$$.update = () => {
    if (i.$$.dirty[1] & /*value*/
    1 && r != null && r.nodes && t(10, y = r.nodes), i.$$.dirty[1] & /*value*/
    1 && r != null && r.connections && t(11, x = r.connections), i.$$.dirty[0] & /*nodes*/
    1024 | i.$$.dirty[1] & /*value*/
    1 && r != null && r.agents && r != null && r.flow && !y.length) {
      const E = Ps(r);
      t(10, y = E.nodes), t(11, x = E.connections);
    }
    i.$$.dirty[0] & /*nodes, connections*/
    3072 && me();
  }, [
    n,
    a,
    o,
    l,
    u,
    c,
    g,
    m,
    b,
    w,
    y,
    x,
    p,
    D,
    F,
    S,
    L,
    ce,
    ne,
    Ae,
    ie,
    W,
    De,
    I,
    H,
    j,
    C,
    le,
    de,
    Re,
    ue,
    r,
    s,
    _,
    N,
    V,
    B,
    ge,
    yt,
    Et,
    Ke,
    Pe,
    Qe,
    Ct,
    St,
    wt,
    mt,
    we,
    kt,
    Ft,
    dn,
    _n,
    fn,
    Vt
  ];
}
class sA extends $s {
  constructor(e) {
    super(), xs(
      this,
      e,
      Ws,
      Ms,
      Ls,
      {
        gradio: 0,
        elem_id: 1,
        elem_classes: 2,
        visible: 3,
        value: 31,
        show_label: 32,
        scale: 4,
        min_width: 5,
        loading_status: 6,
        value_is_output: 33,
        boxes: 7,
        label_list: 8,
        label_workflow: 9
      },
      null,
      [-1, -1, -1]
    );
  }
  get gradio() {
    return this.$$.ctx[0];
  }
  set gradio(e) {
    this.$$set({ gradio: e }), Ue();
  }
  get elem_id() {
    return this.$$.ctx[1];
  }
  set elem_id(e) {
    this.$$set({ elem_id: e }), Ue();
  }
  get elem_classes() {
    return this.$$.ctx[2];
  }
  set elem_classes(e) {
    this.$$set({ elem_classes: e }), Ue();
  }
  get visible() {
    return this.$$.ctx[3];
  }
  set visible(e) {
    this.$$set({ visible: e }), Ue();
  }
  get value() {
    return this.$$.ctx[31];
  }
  set value(e) {
    this.$$set({ value: e }), Ue();
  }
  get show_label() {
    return this.$$.ctx[32];
  }
  set show_label(e) {
    this.$$set({ show_label: e }), Ue();
  }
  get scale() {
    return this.$$.ctx[4];
  }
  set scale(e) {
    this.$$set({ scale: e }), Ue();
  }
  get min_width() {
    return this.$$.ctx[5];
  }
  set min_width(e) {
    this.$$set({ min_width: e }), Ue();
  }
  get loading_status() {
    return this.$$.ctx[6];
  }
  set loading_status(e) {
    this.$$set({ loading_status: e }), Ue();
  }
  get value_is_output() {
    return this.$$.ctx[33];
  }
  set value_is_output(e) {
    this.$$set({ value_is_output: e }), Ue();
  }
  get boxes() {
    return this.$$.ctx[7];
  }
  set boxes(e) {
    this.$$set({ boxes: e }), Ue();
  }
  get label_list() {
    return this.$$.ctx[8];
  }
  set label_list(e) {
    this.$$set({ label_list: e }), Ue();
  }
  get label_workflow() {
    return this.$$.ctx[9];
  }
  set label_workflow(e) {
    this.$$set({ label_workflow: e }), Ue();
  }
}
export {
  sA as default
};
