var Xl = Object.defineProperty;
var Bi = (i) => {
  throw TypeError(i);
};
var Kl = (i, e, t) => e in i ? Xl(i, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : i[e] = t;
var ee = (i, e, t) => Kl(i, typeof e != "symbol" ? e + "" : e, t), Ql = (i, e, t) => e.has(i) || Bi("Cannot " + t);
var Ri = (i, e, t) => e.has(i) ? Bi("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(i) : e.set(i, t);
var pn = (i, e, t) => (Ql(i, e, "access private method"), t);
const {
  SvelteComponent: Jl,
  append_hydration: Jn,
  assign: eo,
  attr: we,
  binding_callbacks: to,
  children: tn,
  claim_element: Qa,
  claim_space: Ja,
  claim_svg_element: Mn,
  create_slot: no,
  detach: nt,
  element: el,
  empty: Ii,
  get_all_dirty_from_scope: io,
  get_slot_changes: ao,
  get_spread_update: lo,
  init: oo,
  insert_hydration: rn,
  listen: ro,
  noop: so,
  safe_not_equal: uo,
  set_dynamic_element_data: Li,
  set_style: W,
  space: tl,
  svg_element: Pn,
  toggle_class: pe,
  transition_in: nl,
  transition_out: il,
  update_slot_base: co
} = window.__gradio__svelte__internal;
function Oi(i) {
  let e, t, n, a, o;
  return {
    c() {
      e = Pn("svg"), t = Pn("line"), n = Pn("line"), this.h();
    },
    l(l) {
      e = Mn(l, "svg", { class: !0, xmlns: !0, viewBox: !0 });
      var r = tn(e);
      t = Mn(r, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), tn(t).forEach(nt), n = Mn(r, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), tn(n).forEach(nt), r.forEach(nt), this.h();
    },
    h() {
      we(t, "x1", "1"), we(t, "y1", "9"), we(t, "x2", "9"), we(t, "y2", "1"), we(t, "stroke", "gray"), we(t, "stroke-width", "0.5"), we(n, "x1", "5"), we(n, "y1", "9"), we(n, "x2", "9"), we(n, "y2", "5"), we(n, "stroke", "gray"), we(n, "stroke-width", "0.5"), we(e, "class", "resize-handle svelte-239wnu"), we(e, "xmlns", "http://www.w3.org/2000/svg"), we(e, "viewBox", "0 0 10 10");
    },
    m(l, r) {
      rn(l, e, r), Jn(e, t), Jn(e, n), a || (o = ro(
        e,
        "mousedown",
        /*resize*/
        i[27]
      ), a = !0);
    },
    p: so,
    d(l) {
      l && nt(e), a = !1, o();
    }
  };
}
function _o(i) {
  var h;
  let e, t, n, a, o;
  const l = (
    /*#slots*/
    i[31].default
  ), r = no(
    l,
    i,
    /*$$scope*/
    i[30],
    null
  );
  let s = (
    /*resizable*/
    i[19] && Oi(i)
  ), u = [
    { "data-testid": (
      /*test_id*/
      i[11]
    ) },
    { id: (
      /*elem_id*/
      i[6]
    ) },
    {
      class: n = "block " + /*elem_classes*/
      (((h = i[7]) == null ? void 0 : h.join(" ")) || "") + " svelte-239wnu"
    },
    {
      dir: a = /*rtl*/
      i[20] ? "rtl" : "ltr"
    }
  ], c = {};
  for (let d = 0; d < u.length; d += 1)
    c = eo(c, u[d]);
  return {
    c() {
      e = el(
        /*tag*/
        i[25]
      ), r && r.c(), t = tl(), s && s.c(), this.h();
    },
    l(d) {
      e = Qa(
        d,
        /*tag*/
        (i[25] || "null").toUpperCase(),
        {
          "data-testid": !0,
          id: !0,
          class: !0,
          dir: !0
        }
      );
      var f = tn(e);
      r && r.l(f), t = Ja(f), s && s.l(f), f.forEach(nt), this.h();
    },
    h() {
      Li(
        /*tag*/
        i[25]
      )(e, c), pe(
        e,
        "hidden",
        /*visible*/
        i[14] === !1
      ), pe(
        e,
        "padded",
        /*padding*/
        i[10]
      ), pe(
        e,
        "flex",
        /*flex*/
        i[1]
      ), pe(
        e,
        "border_focus",
        /*border_mode*/
        i[9] === "focus"
      ), pe(
        e,
        "border_contrast",
        /*border_mode*/
        i[9] === "contrast"
      ), pe(e, "hide-container", !/*explicit_call*/
      i[12] && !/*container*/
      i[13]), pe(
        e,
        "fullscreen",
        /*fullscreen*/
        i[0]
      ), pe(
        e,
        "animating",
        /*fullscreen*/
        i[0] && /*preexpansionBoundingRect*/
        i[24] !== null
      ), pe(
        e,
        "auto-margin",
        /*scale*/
        i[17] === null
      ), W(
        e,
        "height",
        /*fullscreen*/
        i[0] ? void 0 : (
          /*get_dimension*/
          i[26](
            /*height*/
            i[2]
          )
        )
      ), W(
        e,
        "min-height",
        /*fullscreen*/
        i[0] ? void 0 : (
          /*get_dimension*/
          i[26](
            /*min_height*/
            i[3]
          )
        )
      ), W(
        e,
        "max-height",
        /*fullscreen*/
        i[0] ? void 0 : (
          /*get_dimension*/
          i[26](
            /*max_height*/
            i[4]
          )
        )
      ), W(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        i[24] ? `${/*preexpansionBoundingRect*/
        i[24].top}px` : "0px"
      ), W(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        i[24] ? `${/*preexpansionBoundingRect*/
        i[24].left}px` : "0px"
      ), W(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        i[24] ? `${/*preexpansionBoundingRect*/
        i[24].width}px` : "0px"
      ), W(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        i[24] ? `${/*preexpansionBoundingRect*/
        i[24].height}px` : "0px"
      ), W(
        e,
        "width",
        /*fullscreen*/
        i[0] ? void 0 : typeof /*width*/
        i[5] == "number" ? `calc(min(${/*width*/
        i[5]}px, 100%))` : (
          /*get_dimension*/
          i[26](
            /*width*/
            i[5]
          )
        )
      ), W(
        e,
        "border-style",
        /*variant*/
        i[8]
      ), W(
        e,
        "overflow",
        /*allow_overflow*/
        i[15] ? (
          /*overflow_behavior*/
          i[16]
        ) : "hidden"
      ), W(
        e,
        "flex-grow",
        /*scale*/
        i[17]
      ), W(e, "min-width", `calc(min(${/*min_width*/
      i[18]}px, 100%))`), W(e, "border-width", "var(--block-border-width)");
    },
    m(d, f) {
      rn(d, e, f), r && r.m(e, null), Jn(e, t), s && s.m(e, null), i[32](e), o = !0;
    },
    p(d, f) {
      var v;
      r && r.p && (!o || f[0] & /*$$scope*/
      1073741824) && co(
        r,
        l,
        d,
        /*$$scope*/
        d[30],
        o ? ao(
          l,
          /*$$scope*/
          d[30],
          f,
          null
        ) : io(
          /*$$scope*/
          d[30]
        ),
        null
      ), /*resizable*/
      d[19] ? s ? s.p(d, f) : (s = Oi(d), s.c(), s.m(e, null)) : s && (s.d(1), s = null), Li(
        /*tag*/
        d[25]
      )(e, c = lo(u, [
        (!o || f[0] & /*test_id*/
        2048) && { "data-testid": (
          /*test_id*/
          d[11]
        ) },
        (!o || f[0] & /*elem_id*/
        64) && { id: (
          /*elem_id*/
          d[6]
        ) },
        (!o || f[0] & /*elem_classes*/
        128 && n !== (n = "block " + /*elem_classes*/
        (((v = d[7]) == null ? void 0 : v.join(" ")) || "") + " svelte-239wnu")) && { class: n },
        (!o || f[0] & /*rtl*/
        1048576 && a !== (a = /*rtl*/
        d[20] ? "rtl" : "ltr")) && { dir: a }
      ])), pe(
        e,
        "hidden",
        /*visible*/
        d[14] === !1
      ), pe(
        e,
        "padded",
        /*padding*/
        d[10]
      ), pe(
        e,
        "flex",
        /*flex*/
        d[1]
      ), pe(
        e,
        "border_focus",
        /*border_mode*/
        d[9] === "focus"
      ), pe(
        e,
        "border_contrast",
        /*border_mode*/
        d[9] === "contrast"
      ), pe(e, "hide-container", !/*explicit_call*/
      d[12] && !/*container*/
      d[13]), pe(
        e,
        "fullscreen",
        /*fullscreen*/
        d[0]
      ), pe(
        e,
        "animating",
        /*fullscreen*/
        d[0] && /*preexpansionBoundingRect*/
        d[24] !== null
      ), pe(
        e,
        "auto-margin",
        /*scale*/
        d[17] === null
      ), f[0] & /*fullscreen, height*/
      5 && W(
        e,
        "height",
        /*fullscreen*/
        d[0] ? void 0 : (
          /*get_dimension*/
          d[26](
            /*height*/
            d[2]
          )
        )
      ), f[0] & /*fullscreen, min_height*/
      9 && W(
        e,
        "min-height",
        /*fullscreen*/
        d[0] ? void 0 : (
          /*get_dimension*/
          d[26](
            /*min_height*/
            d[3]
          )
        )
      ), f[0] & /*fullscreen, max_height*/
      17 && W(
        e,
        "max-height",
        /*fullscreen*/
        d[0] ? void 0 : (
          /*get_dimension*/
          d[26](
            /*max_height*/
            d[4]
          )
        )
      ), f[0] & /*preexpansionBoundingRect*/
      16777216 && W(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].top}px` : "0px"
      ), f[0] & /*preexpansionBoundingRect*/
      16777216 && W(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].left}px` : "0px"
      ), f[0] & /*preexpansionBoundingRect*/
      16777216 && W(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].width}px` : "0px"
      ), f[0] & /*preexpansionBoundingRect*/
      16777216 && W(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].height}px` : "0px"
      ), f[0] & /*fullscreen, width*/
      33 && W(
        e,
        "width",
        /*fullscreen*/
        d[0] ? void 0 : typeof /*width*/
        d[5] == "number" ? `calc(min(${/*width*/
        d[5]}px, 100%))` : (
          /*get_dimension*/
          d[26](
            /*width*/
            d[5]
          )
        )
      ), f[0] & /*variant*/
      256 && W(
        e,
        "border-style",
        /*variant*/
        d[8]
      ), f[0] & /*allow_overflow, overflow_behavior*/
      98304 && W(
        e,
        "overflow",
        /*allow_overflow*/
        d[15] ? (
          /*overflow_behavior*/
          d[16]
        ) : "hidden"
      ), f[0] & /*scale*/
      131072 && W(
        e,
        "flex-grow",
        /*scale*/
        d[17]
      ), f[0] & /*min_width*/
      262144 && W(e, "min-width", `calc(min(${/*min_width*/
      d[18]}px, 100%))`);
    },
    i(d) {
      o || (nl(r, d), o = !0);
    },
    o(d) {
      il(r, d), o = !1;
    },
    d(d) {
      d && nt(e), r && r.d(d), s && s.d(), i[32](null);
    }
  };
}
function qi(i) {
  let e;
  return {
    c() {
      e = el("div"), this.h();
    },
    l(t) {
      e = Qa(t, "DIV", { class: !0 }), tn(e).forEach(nt), this.h();
    },
    h() {
      we(e, "class", "placeholder svelte-239wnu"), W(
        e,
        "height",
        /*placeholder_height*/
        i[22] + "px"
      ), W(
        e,
        "width",
        /*placeholder_width*/
        i[23] + "px"
      );
    },
    m(t, n) {
      rn(t, e, n);
    },
    p(t, n) {
      n[0] & /*placeholder_height*/
      4194304 && W(
        e,
        "height",
        /*placeholder_height*/
        t[22] + "px"
      ), n[0] & /*placeholder_width*/
      8388608 && W(
        e,
        "width",
        /*placeholder_width*/
        t[23] + "px"
      );
    },
    d(t) {
      t && nt(e);
    }
  };
}
function fo(i) {
  let e, t, n, a = (
    /*tag*/
    i[25] && _o(i)
  ), o = (
    /*fullscreen*/
    i[0] && qi(i)
  );
  return {
    c() {
      a && a.c(), e = tl(), o && o.c(), t = Ii();
    },
    l(l) {
      a && a.l(l), e = Ja(l), o && o.l(l), t = Ii();
    },
    m(l, r) {
      a && a.m(l, r), rn(l, e, r), o && o.m(l, r), rn(l, t, r), n = !0;
    },
    p(l, r) {
      /*tag*/
      l[25] && a.p(l, r), /*fullscreen*/
      l[0] ? o ? o.p(l, r) : (o = qi(l), o.c(), o.m(t.parentNode, t)) : o && (o.d(1), o = null);
    },
    i(l) {
      n || (nl(a, l), n = !0);
    },
    o(l) {
      il(a, l), n = !1;
    },
    d(l) {
      l && (nt(e), nt(t)), a && a.d(l), o && o.d(l);
    }
  };
}
function po(i, e, t) {
  let { $$slots: n = {}, $$scope: a } = e, { height: o = void 0 } = e, { min_height: l = void 0 } = e, { max_height: r = void 0 } = e, { width: s = void 0 } = e, { elem_id: u = "" } = e, { elem_classes: c = [] } = e, { variant: h = "solid" } = e, { border_mode: d = "base" } = e, { padding: f = !0 } = e, { type: v = "normal" } = e, { test_id: b = void 0 } = e, { explicit_call: w = !1 } = e, { container: k = !0 } = e, { visible: m = !0 } = e, { allow_overflow: _ = !0 } = e, { overflow_behavior: g = "auto" } = e, { scale: y = null } = e, { min_width: F = 0 } = e, { flex: C = !1 } = e, { resizable: T = !1 } = e, { rtl: S = !1 } = e, { fullscreen: z = !1 } = e, N = z, j, ke = v === "fieldset" ? "fieldset" : "div", ue = 0, $e = 0, _e = null;
  function ne($) {
    z && $.key === "Escape" && t(0, z = !1);
  }
  const X = ($) => {
    if ($ !== void 0) {
      if (typeof $ == "number")
        return $ + "px";
      if (typeof $ == "string")
        return $;
    }
  }, se = ($) => {
    let oe = $.clientY;
    const K = (A) => {
      const Se = A.clientY - oe;
      oe = A.clientY, t(21, j.style.height = `${j.offsetHeight + Se}px`, j);
    }, de = () => {
      window.removeEventListener("mousemove", K), window.removeEventListener("mouseup", de);
    };
    window.addEventListener("mousemove", K), window.addEventListener("mouseup", de);
  };
  function ve($) {
    to[$ ? "unshift" : "push"](() => {
      j = $, t(21, j);
    });
  }
  return i.$$set = ($) => {
    "height" in $ && t(2, o = $.height), "min_height" in $ && t(3, l = $.min_height), "max_height" in $ && t(4, r = $.max_height), "width" in $ && t(5, s = $.width), "elem_id" in $ && t(6, u = $.elem_id), "elem_classes" in $ && t(7, c = $.elem_classes), "variant" in $ && t(8, h = $.variant), "border_mode" in $ && t(9, d = $.border_mode), "padding" in $ && t(10, f = $.padding), "type" in $ && t(28, v = $.type), "test_id" in $ && t(11, b = $.test_id), "explicit_call" in $ && t(12, w = $.explicit_call), "container" in $ && t(13, k = $.container), "visible" in $ && t(14, m = $.visible), "allow_overflow" in $ && t(15, _ = $.allow_overflow), "overflow_behavior" in $ && t(16, g = $.overflow_behavior), "scale" in $ && t(17, y = $.scale), "min_width" in $ && t(18, F = $.min_width), "flex" in $ && t(1, C = $.flex), "resizable" in $ && t(19, T = $.resizable), "rtl" in $ && t(20, S = $.rtl), "fullscreen" in $ && t(0, z = $.fullscreen), "$$scope" in $ && t(30, a = $.$$scope);
  }, i.$$.update = () => {
    i.$$.dirty[0] & /*fullscreen, old_fullscreen, element*/
    538968065 && z !== N && (t(29, N = z), z ? (t(24, _e = j.getBoundingClientRect()), t(22, ue = j.offsetHeight), t(23, $e = j.offsetWidth), window.addEventListener("keydown", ne)) : (t(24, _e = null), window.removeEventListener("keydown", ne))), i.$$.dirty[0] & /*visible*/
    16384 && (m || t(1, C = !1));
  }, [
    z,
    C,
    o,
    l,
    r,
    s,
    u,
    c,
    h,
    d,
    f,
    b,
    w,
    k,
    m,
    _,
    g,
    y,
    F,
    T,
    S,
    j,
    ue,
    $e,
    _e,
    ke,
    X,
    se,
    v,
    N,
    a,
    n,
    ve
  ];
}
class ho extends Jl {
  constructor(e) {
    super(), oo(
      this,
      e,
      po,
      fo,
      uo,
      {
        height: 2,
        min_height: 3,
        max_height: 4,
        width: 5,
        elem_id: 6,
        elem_classes: 7,
        variant: 8,
        border_mode: 9,
        padding: 10,
        type: 28,
        test_id: 11,
        explicit_call: 12,
        container: 13,
        visible: 14,
        allow_overflow: 15,
        overflow_behavior: 16,
        scale: 17,
        min_width: 18,
        flex: 1,
        resizable: 19,
        rtl: 20,
        fullscreen: 0
      },
      null,
      [-1, -1]
    );
  }
}
function di() {
  return {
    async: !1,
    breaks: !1,
    extensions: null,
    gfm: !0,
    hooks: null,
    pedantic: !1,
    renderer: null,
    silent: !1,
    tokenizer: null,
    walkTokens: null
  };
}
let Bt = di();
function al(i) {
  Bt = i;
}
const ll = /[&<>"']/, mo = new RegExp(ll.source, "g"), ol = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, go = new RegExp(ol.source, "g"), vo = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, Ni = (i) => vo[i];
function Oe(i, e) {
  if (e) {
    if (ll.test(i))
      return i.replace(mo, Ni);
  } else if (ol.test(i))
    return i.replace(go, Ni);
  return i;
}
const Do = /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig;
function bo(i) {
  return i.replace(Do, (e, t) => (t = t.toLowerCase(), t === "colon" ? ":" : t.charAt(0) === "#" ? t.charAt(1) === "x" ? String.fromCharCode(parseInt(t.substring(2), 16)) : String.fromCharCode(+t.substring(1)) : ""));
}
const yo = /(^|[^\[])\^/g;
function Y(i, e) {
  let t = typeof i == "string" ? i : i.source;
  e = e || "";
  const n = {
    replace: (a, o) => {
      let l = typeof o == "string" ? o : o.source;
      return l = l.replace(yo, "$1"), t = t.replace(a, l), n;
    },
    getRegex: () => new RegExp(t, e)
  };
  return n;
}
function zi(i) {
  try {
    i = encodeURI(i).replace(/%25/g, "%");
  } catch {
    return null;
  }
  return i;
}
const nn = { exec: () => null };
function Mi(i, e) {
  const t = i.replace(/\|/g, (o, l, r) => {
    let s = !1, u = l;
    for (; --u >= 0 && r[u] === "\\"; )
      s = !s;
    return s ? "|" : " |";
  }), n = t.split(/ \|/);
  let a = 0;
  if (n[0].trim() || n.shift(), n.length > 0 && !n[n.length - 1].trim() && n.pop(), e)
    if (n.length > e)
      n.splice(e);
    else
      for (; n.length < e; )
        n.push("");
  for (; a < n.length; a++)
    n[a] = n[a].trim().replace(/\\\|/g, "|");
  return n;
}
function hn(i, e, t) {
  const n = i.length;
  if (n === 0)
    return "";
  let a = 0;
  for (; a < n && i.charAt(n - a - 1) === e; )
    a++;
  return i.slice(0, n - a);
}
function wo(i, e) {
  if (i.indexOf(e[1]) === -1)
    return -1;
  let t = 0;
  for (let n = 0; n < i.length; n++)
    if (i[n] === "\\")
      n++;
    else if (i[n] === e[0])
      t++;
    else if (i[n] === e[1] && (t--, t < 0))
      return n;
  return -1;
}
function Pi(i, e, t, n) {
  const a = e.href, o = e.title ? Oe(e.title) : null, l = i[1].replace(/\\([\[\]])/g, "$1");
  if (i[0].charAt(0) !== "!") {
    n.state.inLink = !0;
    const r = {
      type: "link",
      raw: t,
      href: a,
      title: o,
      text: l,
      tokens: n.inlineTokens(l)
    };
    return n.state.inLink = !1, r;
  }
  return {
    type: "image",
    raw: t,
    href: a,
    title: o,
    text: Oe(l)
  };
}
function Fo(i, e) {
  const t = i.match(/^(\s+)(?:```)/);
  if (t === null)
    return e;
  const n = t[1];
  return e.split(`
`).map((a) => {
    const o = a.match(/^\s+/);
    if (o === null)
      return a;
    const [l] = o;
    return l.length >= n.length ? a.slice(n.length) : a;
  }).join(`
`);
}
class Cn {
  // set by the lexer
  constructor(e) {
    ee(this, "options");
    ee(this, "rules");
    // set by the lexer
    ee(this, "lexer");
    this.options = e || Bt;
  }
  space(e) {
    const t = this.rules.block.newline.exec(e);
    if (t && t[0].length > 0)
      return {
        type: "space",
        raw: t[0]
      };
  }
  code(e) {
    const t = this.rules.block.code.exec(e);
    if (t) {
      const n = t[0].replace(/^ {1,4}/gm, "");
      return {
        type: "code",
        raw: t[0],
        codeBlockStyle: "indented",
        text: this.options.pedantic ? n : hn(n, `
`)
      };
    }
  }
  fences(e) {
    const t = this.rules.block.fences.exec(e);
    if (t) {
      const n = t[0], a = Fo(n, t[3] || "");
      return {
        type: "code",
        raw: n,
        lang: t[2] ? t[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : t[2],
        text: a
      };
    }
  }
  heading(e) {
    const t = this.rules.block.heading.exec(e);
    if (t) {
      let n = t[2].trim();
      if (/#$/.test(n)) {
        const a = hn(n, "#");
        (this.options.pedantic || !a || / $/.test(a)) && (n = a.trim());
      }
      return {
        type: "heading",
        raw: t[0],
        depth: t[1].length,
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  hr(e) {
    const t = this.rules.block.hr.exec(e);
    if (t)
      return {
        type: "hr",
        raw: t[0]
      };
  }
  blockquote(e) {
    const t = this.rules.block.blockquote.exec(e);
    if (t) {
      let n = t[0].replace(/\n {0,3}((?:=+|-+) *)(?=\n|$)/g, `
    $1`);
      n = hn(n.replace(/^ *>[ \t]?/gm, ""), `
`);
      const a = this.lexer.state.top;
      this.lexer.state.top = !0;
      const o = this.lexer.blockTokens(n);
      return this.lexer.state.top = a, {
        type: "blockquote",
        raw: t[0],
        tokens: o,
        text: n
      };
    }
  }
  list(e) {
    let t = this.rules.block.list.exec(e);
    if (t) {
      let n = t[1].trim();
      const a = n.length > 1, o = {
        type: "list",
        raw: "",
        ordered: a,
        start: a ? +n.slice(0, -1) : "",
        loose: !1,
        items: []
      };
      n = a ? `\\d{1,9}\\${n.slice(-1)}` : `\\${n}`, this.options.pedantic && (n = a ? n : "[*+-]");
      const l = new RegExp(`^( {0,3}${n})((?:[	 ][^\\n]*)?(?:\\n|$))`);
      let r = "", s = "", u = !1;
      for (; e; ) {
        let c = !1;
        if (!(t = l.exec(e)) || this.rules.block.hr.test(e))
          break;
        r = t[0], e = e.substring(r.length);
        let h = t[2].split(`
`, 1)[0].replace(/^\t+/, (k) => " ".repeat(3 * k.length)), d = e.split(`
`, 1)[0], f = 0;
        this.options.pedantic ? (f = 2, s = h.trimStart()) : (f = t[2].search(/[^ ]/), f = f > 4 ? 1 : f, s = h.slice(f), f += t[1].length);
        let v = !1;
        if (!h && /^ *$/.test(d) && (r += d + `
`, e = e.substring(d.length + 1), c = !0), !c) {
          const k = new RegExp(`^ {0,${Math.min(3, f - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`), m = new RegExp(`^ {0,${Math.min(3, f - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`), _ = new RegExp(`^ {0,${Math.min(3, f - 1)}}(?:\`\`\`|~~~)`), g = new RegExp(`^ {0,${Math.min(3, f - 1)}}#`);
          for (; e; ) {
            const y = e.split(`
`, 1)[0];
            if (d = y, this.options.pedantic && (d = d.replace(/^ {1,4}(?=( {4})*[^ ])/g, "  ")), _.test(d) || g.test(d) || k.test(d) || m.test(e))
              break;
            if (d.search(/[^ ]/) >= f || !d.trim())
              s += `
` + d.slice(f);
            else {
              if (v || h.search(/[^ ]/) >= 4 || _.test(h) || g.test(h) || m.test(h))
                break;
              s += `
` + d;
            }
            !v && !d.trim() && (v = !0), r += y + `
`, e = e.substring(y.length + 1), h = d.slice(f);
          }
        }
        o.loose || (u ? o.loose = !0 : /\n *\n *$/.test(r) && (u = !0));
        let b = null, w;
        this.options.gfm && (b = /^\[[ xX]\] /.exec(s), b && (w = b[0] !== "[ ] ", s = s.replace(/^\[[ xX]\] +/, ""))), o.items.push({
          type: "list_item",
          raw: r,
          task: !!b,
          checked: w,
          loose: !1,
          text: s,
          tokens: []
        }), o.raw += r;
      }
      o.items[o.items.length - 1].raw = r.trimEnd(), o.items[o.items.length - 1].text = s.trimEnd(), o.raw = o.raw.trimEnd();
      for (let c = 0; c < o.items.length; c++)
        if (this.lexer.state.top = !1, o.items[c].tokens = this.lexer.blockTokens(o.items[c].text, []), !o.loose) {
          const h = o.items[c].tokens.filter((f) => f.type === "space"), d = h.length > 0 && h.some((f) => /\n.*\n/.test(f.raw));
          o.loose = d;
        }
      if (o.loose)
        for (let c = 0; c < o.items.length; c++)
          o.items[c].loose = !0;
      return o;
    }
  }
  html(e) {
    const t = this.rules.block.html.exec(e);
    if (t)
      return {
        type: "html",
        block: !0,
        raw: t[0],
        pre: t[1] === "pre" || t[1] === "script" || t[1] === "style",
        text: t[0]
      };
  }
  def(e) {
    const t = this.rules.block.def.exec(e);
    if (t) {
      const n = t[1].toLowerCase().replace(/\s+/g, " "), a = t[2] ? t[2].replace(/^<(.*)>$/, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", o = t[3] ? t[3].substring(1, t[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : t[3];
      return {
        type: "def",
        tag: n,
        raw: t[0],
        href: a,
        title: o
      };
    }
  }
  table(e) {
    const t = this.rules.block.table.exec(e);
    if (!t || !/[:|]/.test(t[2]))
      return;
    const n = Mi(t[1]), a = t[2].replace(/^\||\| *$/g, "").split("|"), o = t[3] && t[3].trim() ? t[3].replace(/\n[ \t]*$/, "").split(`
`) : [], l = {
      type: "table",
      raw: t[0],
      header: [],
      align: [],
      rows: []
    };
    if (n.length === a.length) {
      for (const r of a)
        /^ *-+: *$/.test(r) ? l.align.push("right") : /^ *:-+: *$/.test(r) ? l.align.push("center") : /^ *:-+ *$/.test(r) ? l.align.push("left") : l.align.push(null);
      for (const r of n)
        l.header.push({
          text: r,
          tokens: this.lexer.inline(r)
        });
      for (const r of o)
        l.rows.push(Mi(r, l.header.length).map((s) => ({
          text: s,
          tokens: this.lexer.inline(s)
        })));
      return l;
    }
  }
  lheading(e) {
    const t = this.rules.block.lheading.exec(e);
    if (t)
      return {
        type: "heading",
        raw: t[0],
        depth: t[2].charAt(0) === "=" ? 1 : 2,
        text: t[1],
        tokens: this.lexer.inline(t[1])
      };
  }
  paragraph(e) {
    const t = this.rules.block.paragraph.exec(e);
    if (t) {
      const n = t[1].charAt(t[1].length - 1) === `
` ? t[1].slice(0, -1) : t[1];
      return {
        type: "paragraph",
        raw: t[0],
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  text(e) {
    const t = this.rules.block.text.exec(e);
    if (t)
      return {
        type: "text",
        raw: t[0],
        text: t[0],
        tokens: this.lexer.inline(t[0])
      };
  }
  escape(e) {
    const t = this.rules.inline.escape.exec(e);
    if (t)
      return {
        type: "escape",
        raw: t[0],
        text: Oe(t[1])
      };
  }
  tag(e) {
    const t = this.rules.inline.tag.exec(e);
    if (t)
      return !this.lexer.state.inLink && /^<a /i.test(t[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && /^<\/a>/i.test(t[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && /^<(pre|code|kbd|script)(\s|>)/i.test(t[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && /^<\/(pre|code|kbd|script)(\s|>)/i.test(t[0]) && (this.lexer.state.inRawBlock = !1), {
        type: "html",
        raw: t[0],
        inLink: this.lexer.state.inLink,
        inRawBlock: this.lexer.state.inRawBlock,
        block: !1,
        text: t[0]
      };
  }
  link(e) {
    const t = this.rules.inline.link.exec(e);
    if (t) {
      const n = t[2].trim();
      if (!this.options.pedantic && /^</.test(n)) {
        if (!/>$/.test(n))
          return;
        const l = hn(n.slice(0, -1), "\\");
        if ((n.length - l.length) % 2 === 0)
          return;
      } else {
        const l = wo(t[2], "()");
        if (l > -1) {
          const s = (t[0].indexOf("!") === 0 ? 5 : 4) + t[1].length + l;
          t[2] = t[2].substring(0, l), t[0] = t[0].substring(0, s).trim(), t[3] = "";
        }
      }
      let a = t[2], o = "";
      if (this.options.pedantic) {
        const l = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(a);
        l && (a = l[1], o = l[3]);
      } else
        o = t[3] ? t[3].slice(1, -1) : "";
      return a = a.trim(), /^</.test(a) && (this.options.pedantic && !/>$/.test(n) ? a = a.slice(1) : a = a.slice(1, -1)), Pi(t, {
        href: a && a.replace(this.rules.inline.anyPunctuation, "$1"),
        title: o && o.replace(this.rules.inline.anyPunctuation, "$1")
      }, t[0], this.lexer);
    }
  }
  reflink(e, t) {
    let n;
    if ((n = this.rules.inline.reflink.exec(e)) || (n = this.rules.inline.nolink.exec(e))) {
      const a = (n[2] || n[1]).replace(/\s+/g, " "), o = t[a.toLowerCase()];
      if (!o) {
        const l = n[0].charAt(0);
        return {
          type: "text",
          raw: l,
          text: l
        };
      }
      return Pi(n, o, n[0], this.lexer);
    }
  }
  emStrong(e, t, n = "") {
    let a = this.rules.inline.emStrongLDelim.exec(e);
    if (!a || a[3] && n.match(/[\p{L}\p{N}]/u))
      return;
    if (!(a[1] || a[2] || "") || !n || this.rules.inline.punctuation.exec(n)) {
      const l = [...a[0]].length - 1;
      let r, s, u = l, c = 0;
      const h = a[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (h.lastIndex = 0, t = t.slice(-1 * e.length + l); (a = h.exec(t)) != null; ) {
        if (r = a[1] || a[2] || a[3] || a[4] || a[5] || a[6], !r)
          continue;
        if (s = [...r].length, a[3] || a[4]) {
          u += s;
          continue;
        } else if ((a[5] || a[6]) && l % 3 && !((l + s) % 3)) {
          c += s;
          continue;
        }
        if (u -= s, u > 0)
          continue;
        s = Math.min(s, s + u + c);
        const d = [...a[0]][0].length, f = e.slice(0, l + a.index + d + s);
        if (Math.min(l, s) % 2) {
          const b = f.slice(1, -1);
          return {
            type: "em",
            raw: f,
            text: b,
            tokens: this.lexer.inlineTokens(b)
          };
        }
        const v = f.slice(2, -2);
        return {
          type: "strong",
          raw: f,
          text: v,
          tokens: this.lexer.inlineTokens(v)
        };
      }
    }
  }
  codespan(e) {
    const t = this.rules.inline.code.exec(e);
    if (t) {
      let n = t[2].replace(/\n/g, " ");
      const a = /[^ ]/.test(n), o = /^ /.test(n) && / $/.test(n);
      return a && o && (n = n.substring(1, n.length - 1)), n = Oe(n, !0), {
        type: "codespan",
        raw: t[0],
        text: n
      };
    }
  }
  br(e) {
    const t = this.rules.inline.br.exec(e);
    if (t)
      return {
        type: "br",
        raw: t[0]
      };
  }
  del(e) {
    const t = this.rules.inline.del.exec(e);
    if (t)
      return {
        type: "del",
        raw: t[0],
        text: t[2],
        tokens: this.lexer.inlineTokens(t[2])
      };
  }
  autolink(e) {
    const t = this.rules.inline.autolink.exec(e);
    if (t) {
      let n, a;
      return t[2] === "@" ? (n = Oe(t[1]), a = "mailto:" + n) : (n = Oe(t[1]), a = n), {
        type: "link",
        raw: t[0],
        text: n,
        href: a,
        tokens: [
          {
            type: "text",
            raw: n,
            text: n
          }
        ]
      };
    }
  }
  url(e) {
    var n;
    let t;
    if (t = this.rules.inline.url.exec(e)) {
      let a, o;
      if (t[2] === "@")
        a = Oe(t[0]), o = "mailto:" + a;
      else {
        let l;
        do
          l = t[0], t[0] = ((n = this.rules.inline._backpedal.exec(t[0])) == null ? void 0 : n[0]) ?? "";
        while (l !== t[0]);
        a = Oe(t[0]), t[1] === "www." ? o = "http://" + t[0] : o = t[0];
      }
      return {
        type: "link",
        raw: t[0],
        text: a,
        href: o,
        tokens: [
          {
            type: "text",
            raw: a,
            text: a
          }
        ]
      };
    }
  }
  inlineText(e) {
    const t = this.rules.inline.text.exec(e);
    if (t) {
      let n;
      return this.lexer.state.inRawBlock ? n = t[0] : n = Oe(t[0]), {
        type: "text",
        raw: t[0],
        text: n
      };
    }
  }
}
const ko = /^(?: *(?:\n|$))+/, $o = /^( {4}[^\n]+(?:\n(?: *(?:\n|$))*)?)+/, Eo = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, sn = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, Ao = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, rl = /(?:[*+-]|\d{1,9}[.)])/, sl = Y(/^(?!bull |blockCode|fences|blockquote|heading|html)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html))+?)\n {0,3}(=+|-+) *(?:\n+|$)/).replace(/bull/g, rl).replace(/blockCode/g, / {4}/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).getRegex(), fi = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, Co = /^[^\n]+/, pi = /(?!\s*\])(?:\\.|[^\[\]\\])+/, So = Y(/^ {0,3}\[(label)\]: *(?:\n *)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n *)?| *\n *)(title))? *(?:\n+|$)/).replace("label", pi).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), To = Y(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, rl).getRegex(), In = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", hi = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, Bo = Y("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n *)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$))", "i").replace("comment", hi).replace("tag", In).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), ul = Y(fi).replace("hr", sn).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", In).getRegex(), Ro = Y(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", ul).getRegex(), mi = {
  blockquote: Ro,
  code: $o,
  def: So,
  fences: Eo,
  heading: Ao,
  hr: sn,
  html: Bo,
  lheading: sl,
  list: To,
  newline: ko,
  paragraph: ul,
  table: nn,
  text: Co
}, xi = Y("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", sn).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", In).getRegex(), Io = {
  ...mi,
  table: xi,
  paragraph: Y(fi).replace("hr", sn).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", xi).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", In).getRegex()
}, Lo = {
  ...mi,
  html: Y(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", hi).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: nn,
  // fences not supported
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: Y(fi).replace("hr", sn).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", sl).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
}, cl = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, Oo = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, _l = /^( {2,}|\\)\n(?!\s*$)/, qo = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, un = "\\p{P}\\p{S}", No = Y(/^((?![*_])[\spunctuation])/, "u").replace(/punctuation/g, un).getRegex(), zo = /\[[^[\]]*?\]\([^\(\)]*?\)|`[^`]*?`|<[^<>]*?>/g, Mo = Y(/^(?:\*+(?:((?!\*)[punct])|[^\s*]))|^_+(?:((?!_)[punct])|([^\s_]))/, "u").replace(/punct/g, un).getRegex(), Po = Y("^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)[punct](\\*+)(?=[\\s]|$)|[^punct\\s](\\*+)(?!\\*)(?=[punct\\s]|$)|(?!\\*)[punct\\s](\\*+)(?=[^punct\\s])|[\\s](\\*+)(?!\\*)(?=[punct])|(?!\\*)[punct](\\*+)(?!\\*)(?=[punct])|[^punct\\s](\\*+)(?=[^punct\\s])", "gu").replace(/punct/g, un).getRegex(), xo = Y("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)[punct](_+)(?=[\\s]|$)|[^punct\\s](_+)(?!_)(?=[punct\\s]|$)|(?!_)[punct\\s](_+)(?=[^punct\\s])|[\\s](_+)(?!_)(?=[punct])|(?!_)[punct](_+)(?!_)(?=[punct])", "gu").replace(/punct/g, un).getRegex(), Uo = Y(/\\([punct])/, "gu").replace(/punct/g, un).getRegex(), Ho = Y(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), jo = Y(hi).replace("(?:-->|$)", "-->").getRegex(), Go = Y("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", jo).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), Sn = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, Vo = Y(/^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/).replace("label", Sn).replace("href", /<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), dl = Y(/^!?\[(label)\]\[(ref)\]/).replace("label", Sn).replace("ref", pi).getRegex(), fl = Y(/^!?\[(ref)\](?:\[\])?/).replace("ref", pi).getRegex(), Wo = Y("reflink|nolink(?!\\()", "g").replace("reflink", dl).replace("nolink", fl).getRegex(), gi = {
  _backpedal: nn,
  // only used for GFM url
  anyPunctuation: Uo,
  autolink: Ho,
  blockSkip: zo,
  br: _l,
  code: Oo,
  del: nn,
  emStrongLDelim: Mo,
  emStrongRDelimAst: Po,
  emStrongRDelimUnd: xo,
  escape: cl,
  link: Vo,
  nolink: fl,
  punctuation: No,
  reflink: dl,
  reflinkSearch: Wo,
  tag: Go,
  text: qo,
  url: nn
}, Zo = {
  ...gi,
  link: Y(/^!?\[(label)\]\((.*?)\)/).replace("label", Sn).getRegex(),
  reflink: Y(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", Sn).getRegex()
}, ei = {
  ...gi,
  escape: Y(cl).replace("])", "~|])").getRegex(),
  url: Y(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])([\s\S]*?[^\s~])\1(?=[^~]|$)/,
  text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
}, Yo = {
  ...ei,
  br: Y(_l).replace("{2,}", "*").getRegex(),
  text: Y(ei.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
}, mn = {
  normal: mi,
  gfm: Io,
  pedantic: Lo
}, Zt = {
  normal: gi,
  gfm: ei,
  breaks: Yo,
  pedantic: Zo
};
class it {
  constructor(e) {
    ee(this, "tokens");
    ee(this, "options");
    ee(this, "state");
    ee(this, "tokenizer");
    ee(this, "inlineQueue");
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = e || Bt, this.options.tokenizer = this.options.tokenizer || new Cn(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
      inLink: !1,
      inRawBlock: !1,
      top: !0
    };
    const t = {
      block: mn.normal,
      inline: Zt.normal
    };
    this.options.pedantic ? (t.block = mn.pedantic, t.inline = Zt.pedantic) : this.options.gfm && (t.block = mn.gfm, this.options.breaks ? t.inline = Zt.breaks : t.inline = Zt.gfm), this.tokenizer.rules = t;
  }
  /**
   * Expose Rules
   */
  static get rules() {
    return {
      block: mn,
      inline: Zt
    };
  }
  /**
   * Static Lex Method
   */
  static lex(e, t) {
    return new it(t).lex(e);
  }
  /**
   * Static Lex Inline Method
   */
  static lexInline(e, t) {
    return new it(t).inlineTokens(e);
  }
  /**
   * Preprocessing
   */
  lex(e) {
    e = e.replace(/\r\n|\r/g, `
`), this.blockTokens(e, this.tokens);
    for (let t = 0; t < this.inlineQueue.length; t++) {
      const n = this.inlineQueue[t];
      this.inlineTokens(n.src, n.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(e, t = []) {
    this.options.pedantic ? e = e.replace(/\t/g, "    ").replace(/^ +$/gm, "") : e = e.replace(/^( *)(\t+)/gm, (r, s, u) => s + "    ".repeat(u.length));
    let n, a, o, l;
    for (; e; )
      if (!(this.options.extensions && this.options.extensions.block && this.options.extensions.block.some((r) => (n = r.call({ lexer: this }, e, t)) ? (e = e.substring(n.raw.length), t.push(n), !0) : !1))) {
        if (n = this.tokenizer.space(e)) {
          e = e.substring(n.raw.length), n.raw.length === 1 && t.length > 0 ? t[t.length - 1].raw += `
` : t.push(n);
          continue;
        }
        if (n = this.tokenizer.code(e)) {
          e = e.substring(n.raw.length), a = t[t.length - 1], a && (a.type === "paragraph" || a.type === "text") ? (a.raw += `
` + n.raw, a.text += `
` + n.text, this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.fences(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.heading(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.hr(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.blockquote(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.list(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.html(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.def(e)) {
          e = e.substring(n.raw.length), a = t[t.length - 1], a && (a.type === "paragraph" || a.type === "text") ? (a.raw += `
` + n.raw, a.text += `
` + n.raw, this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : this.tokens.links[n.tag] || (this.tokens.links[n.tag] = {
            href: n.href,
            title: n.title
          });
          continue;
        }
        if (n = this.tokenizer.table(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.lheading(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (o = e, this.options.extensions && this.options.extensions.startBlock) {
          let r = 1 / 0;
          const s = e.slice(1);
          let u;
          this.options.extensions.startBlock.forEach((c) => {
            u = c.call({ lexer: this }, s), typeof u == "number" && u >= 0 && (r = Math.min(r, u));
          }), r < 1 / 0 && r >= 0 && (o = e.substring(0, r + 1));
        }
        if (this.state.top && (n = this.tokenizer.paragraph(o))) {
          a = t[t.length - 1], l && a.type === "paragraph" ? (a.raw += `
` + n.raw, a.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : t.push(n), l = o.length !== e.length, e = e.substring(n.raw.length);
          continue;
        }
        if (n = this.tokenizer.text(e)) {
          e = e.substring(n.raw.length), a = t[t.length - 1], a && a.type === "text" ? (a.raw += `
` + n.raw, a.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : t.push(n);
          continue;
        }
        if (e) {
          const r = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(r);
            break;
          } else
            throw new Error(r);
        }
      }
    return this.state.top = !0, t;
  }
  inline(e, t = []) {
    return this.inlineQueue.push({ src: e, tokens: t }), t;
  }
  /**
   * Lexing/Compiling
   */
  inlineTokens(e, t = []) {
    let n, a, o, l = e, r, s, u;
    if (this.tokens.links) {
      const c = Object.keys(this.tokens.links);
      if (c.length > 0)
        for (; (r = this.tokenizer.rules.inline.reflinkSearch.exec(l)) != null; )
          c.includes(r[0].slice(r[0].lastIndexOf("[") + 1, -1)) && (l = l.slice(0, r.index) + "[" + "a".repeat(r[0].length - 2) + "]" + l.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (r = this.tokenizer.rules.inline.blockSkip.exec(l)) != null; )
      l = l.slice(0, r.index) + "[" + "a".repeat(r[0].length - 2) + "]" + l.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    for (; (r = this.tokenizer.rules.inline.anyPunctuation.exec(l)) != null; )
      l = l.slice(0, r.index) + "++" + l.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    for (; e; )
      if (s || (u = ""), s = !1, !(this.options.extensions && this.options.extensions.inline && this.options.extensions.inline.some((c) => (n = c.call({ lexer: this }, e, t)) ? (e = e.substring(n.raw.length), t.push(n), !0) : !1))) {
        if (n = this.tokenizer.escape(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.tag(e)) {
          e = e.substring(n.raw.length), a = t[t.length - 1], a && n.type === "text" && a.type === "text" ? (a.raw += n.raw, a.text += n.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.link(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.reflink(e, this.tokens.links)) {
          e = e.substring(n.raw.length), a = t[t.length - 1], a && n.type === "text" && a.type === "text" ? (a.raw += n.raw, a.text += n.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.emStrong(e, l, u)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.codespan(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.br(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.del(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.autolink(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (!this.state.inLink && (n = this.tokenizer.url(e))) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (o = e, this.options.extensions && this.options.extensions.startInline) {
          let c = 1 / 0;
          const h = e.slice(1);
          let d;
          this.options.extensions.startInline.forEach((f) => {
            d = f.call({ lexer: this }, h), typeof d == "number" && d >= 0 && (c = Math.min(c, d));
          }), c < 1 / 0 && c >= 0 && (o = e.substring(0, c + 1));
        }
        if (n = this.tokenizer.inlineText(o)) {
          e = e.substring(n.raw.length), n.raw.slice(-1) !== "_" && (u = n.raw.slice(-1)), s = !0, a = t[t.length - 1], a && a.type === "text" ? (a.raw += n.raw, a.text += n.text) : t.push(n);
          continue;
        }
        if (e) {
          const c = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(c);
            break;
          } else
            throw new Error(c);
        }
      }
    return t;
  }
}
class Tn {
  constructor(e) {
    ee(this, "options");
    this.options = e || Bt;
  }
  code(e, t, n) {
    var o;
    const a = (o = (t || "").match(/^\S*/)) == null ? void 0 : o[0];
    return e = e.replace(/\n$/, "") + `
`, a ? '<pre><code class="language-' + Oe(a) + '">' + (n ? e : Oe(e, !0)) + `</code></pre>
` : "<pre><code>" + (n ? e : Oe(e, !0)) + `</code></pre>
`;
  }
  blockquote(e) {
    return `<blockquote>
${e}</blockquote>
`;
  }
  html(e, t) {
    return e;
  }
  heading(e, t, n) {
    return `<h${t}>${e}</h${t}>
`;
  }
  hr() {
    return `<hr>
`;
  }
  list(e, t, n) {
    const a = t ? "ol" : "ul", o = t && n !== 1 ? ' start="' + n + '"' : "";
    return "<" + a + o + `>
` + e + "</" + a + `>
`;
  }
  listitem(e, t, n) {
    return `<li>${e}</li>
`;
  }
  checkbox(e) {
    return "<input " + (e ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph(e) {
    return `<p>${e}</p>
`;
  }
  table(e, t) {
    return t && (t = `<tbody>${t}</tbody>`), `<table>
<thead>
` + e + `</thead>
` + t + `</table>
`;
  }
  tablerow(e) {
    return `<tr>
${e}</tr>
`;
  }
  tablecell(e, t) {
    const n = t.header ? "th" : "td";
    return (t.align ? `<${n} align="${t.align}">` : `<${n}>`) + e + `</${n}>
`;
  }
  /**
   * span level renderer
   */
  strong(e) {
    return `<strong>${e}</strong>`;
  }
  em(e) {
    return `<em>${e}</em>`;
  }
  codespan(e) {
    return `<code>${e}</code>`;
  }
  br() {
    return "<br>";
  }
  del(e) {
    return `<del>${e}</del>`;
  }
  link(e, t, n) {
    const a = zi(e);
    if (a === null)
      return n;
    e = a;
    let o = '<a href="' + e + '"';
    return t && (o += ' title="' + t + '"'), o += ">" + n + "</a>", o;
  }
  image(e, t, n) {
    const a = zi(e);
    if (a === null)
      return n;
    e = a;
    let o = `<img src="${e}" alt="${n}"`;
    return t && (o += ` title="${t}"`), o += ">", o;
  }
  text(e) {
    return e;
  }
}
class vi {
  // no need for block level renderers
  strong(e) {
    return e;
  }
  em(e) {
    return e;
  }
  codespan(e) {
    return e;
  }
  del(e) {
    return e;
  }
  html(e) {
    return e;
  }
  text(e) {
    return e;
  }
  link(e, t, n) {
    return "" + n;
  }
  image(e, t, n) {
    return "" + n;
  }
  br() {
    return "";
  }
}
class at {
  constructor(e) {
    ee(this, "options");
    ee(this, "renderer");
    ee(this, "textRenderer");
    this.options = e || Bt, this.options.renderer = this.options.renderer || new Tn(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.textRenderer = new vi();
  }
  /**
   * Static Parse Method
   */
  static parse(e, t) {
    return new at(t).parse(e);
  }
  /**
   * Static Parse Inline Method
   */
  static parseInline(e, t) {
    return new at(t).parseInline(e);
  }
  /**
   * Parse Loop
   */
  parse(e, t = !0) {
    let n = "";
    for (let a = 0; a < e.length; a++) {
      const o = e[a];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[o.type]) {
        const l = o, r = this.options.extensions.renderers[l.type].call({ parser: this }, l);
        if (r !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(l.type)) {
          n += r || "";
          continue;
        }
      }
      switch (o.type) {
        case "space":
          continue;
        case "hr": {
          n += this.renderer.hr();
          continue;
        }
        case "heading": {
          const l = o;
          n += this.renderer.heading(this.parseInline(l.tokens), l.depth, bo(this.parseInline(l.tokens, this.textRenderer)));
          continue;
        }
        case "code": {
          const l = o;
          n += this.renderer.code(l.text, l.lang, !!l.escaped);
          continue;
        }
        case "table": {
          const l = o;
          let r = "", s = "";
          for (let c = 0; c < l.header.length; c++)
            s += this.renderer.tablecell(this.parseInline(l.header[c].tokens), { header: !0, align: l.align[c] });
          r += this.renderer.tablerow(s);
          let u = "";
          for (let c = 0; c < l.rows.length; c++) {
            const h = l.rows[c];
            s = "";
            for (let d = 0; d < h.length; d++)
              s += this.renderer.tablecell(this.parseInline(h[d].tokens), { header: !1, align: l.align[d] });
            u += this.renderer.tablerow(s);
          }
          n += this.renderer.table(r, u);
          continue;
        }
        case "blockquote": {
          const l = o, r = this.parse(l.tokens);
          n += this.renderer.blockquote(r);
          continue;
        }
        case "list": {
          const l = o, r = l.ordered, s = l.start, u = l.loose;
          let c = "";
          for (let h = 0; h < l.items.length; h++) {
            const d = l.items[h], f = d.checked, v = d.task;
            let b = "";
            if (d.task) {
              const w = this.renderer.checkbox(!!f);
              u ? d.tokens.length > 0 && d.tokens[0].type === "paragraph" ? (d.tokens[0].text = w + " " + d.tokens[0].text, d.tokens[0].tokens && d.tokens[0].tokens.length > 0 && d.tokens[0].tokens[0].type === "text" && (d.tokens[0].tokens[0].text = w + " " + d.tokens[0].tokens[0].text)) : d.tokens.unshift({
                type: "text",
                text: w + " "
              }) : b += w + " ";
            }
            b += this.parse(d.tokens, u), c += this.renderer.listitem(b, v, !!f);
          }
          n += this.renderer.list(c, r, s);
          continue;
        }
        case "html": {
          const l = o;
          n += this.renderer.html(l.text, l.block);
          continue;
        }
        case "paragraph": {
          const l = o;
          n += this.renderer.paragraph(this.parseInline(l.tokens));
          continue;
        }
        case "text": {
          let l = o, r = l.tokens ? this.parseInline(l.tokens) : l.text;
          for (; a + 1 < e.length && e[a + 1].type === "text"; )
            l = e[++a], r += `
` + (l.tokens ? this.parseInline(l.tokens) : l.text);
          n += t ? this.renderer.paragraph(r) : r;
          continue;
        }
        default: {
          const l = 'Token with "' + o.type + '" type was not found.';
          if (this.options.silent)
            return console.error(l), "";
          throw new Error(l);
        }
      }
    }
    return n;
  }
  /**
   * Parse Inline Tokens
   */
  parseInline(e, t) {
    t = t || this.renderer;
    let n = "";
    for (let a = 0; a < e.length; a++) {
      const o = e[a];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[o.type]) {
        const l = this.options.extensions.renderers[o.type].call({ parser: this }, o);
        if (l !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(o.type)) {
          n += l || "";
          continue;
        }
      }
      switch (o.type) {
        case "escape": {
          const l = o;
          n += t.text(l.text);
          break;
        }
        case "html": {
          const l = o;
          n += t.html(l.text);
          break;
        }
        case "link": {
          const l = o;
          n += t.link(l.href, l.title, this.parseInline(l.tokens, t));
          break;
        }
        case "image": {
          const l = o;
          n += t.image(l.href, l.title, l.text);
          break;
        }
        case "strong": {
          const l = o;
          n += t.strong(this.parseInline(l.tokens, t));
          break;
        }
        case "em": {
          const l = o;
          n += t.em(this.parseInline(l.tokens, t));
          break;
        }
        case "codespan": {
          const l = o;
          n += t.codespan(l.text);
          break;
        }
        case "br": {
          n += t.br();
          break;
        }
        case "del": {
          const l = o;
          n += t.del(this.parseInline(l.tokens, t));
          break;
        }
        case "text": {
          const l = o;
          n += t.text(l.text);
          break;
        }
        default: {
          const l = 'Token with "' + o.type + '" type was not found.';
          if (this.options.silent)
            return console.error(l), "";
          throw new Error(l);
        }
      }
    }
    return n;
  }
}
class an {
  constructor(e) {
    ee(this, "options");
    this.options = e || Bt;
  }
  /**
   * Process markdown before marked
   */
  preprocess(e) {
    return e;
  }
  /**
   * Process HTML after marked is finished
   */
  postprocess(e) {
    return e;
  }
  /**
   * Process all tokens before walk tokens
   */
  processAllTokens(e) {
    return e;
  }
}
ee(an, "passThroughHooks", /* @__PURE__ */ new Set([
  "preprocess",
  "postprocess",
  "processAllTokens"
]));
var Tt, ti, pl;
class Xo {
  constructor(...e) {
    Ri(this, Tt);
    ee(this, "defaults", di());
    ee(this, "options", this.setOptions);
    ee(this, "parse", pn(this, Tt, ti).call(this, it.lex, at.parse));
    ee(this, "parseInline", pn(this, Tt, ti).call(this, it.lexInline, at.parseInline));
    ee(this, "Parser", at);
    ee(this, "Renderer", Tn);
    ee(this, "TextRenderer", vi);
    ee(this, "Lexer", it);
    ee(this, "Tokenizer", Cn);
    ee(this, "Hooks", an);
    this.use(...e);
  }
  /**
   * Run callback for every token
   */
  walkTokens(e, t) {
    var a, o;
    let n = [];
    for (const l of e)
      switch (n = n.concat(t.call(this, l)), l.type) {
        case "table": {
          const r = l;
          for (const s of r.header)
            n = n.concat(this.walkTokens(s.tokens, t));
          for (const s of r.rows)
            for (const u of s)
              n = n.concat(this.walkTokens(u.tokens, t));
          break;
        }
        case "list": {
          const r = l;
          n = n.concat(this.walkTokens(r.items, t));
          break;
        }
        default: {
          const r = l;
          (o = (a = this.defaults.extensions) == null ? void 0 : a.childTokens) != null && o[r.type] ? this.defaults.extensions.childTokens[r.type].forEach((s) => {
            const u = r[s].flat(1 / 0);
            n = n.concat(this.walkTokens(u, t));
          }) : r.tokens && (n = n.concat(this.walkTokens(r.tokens, t)));
        }
      }
    return n;
  }
  use(...e) {
    const t = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return e.forEach((n) => {
      const a = { ...n };
      if (a.async = this.defaults.async || a.async || !1, n.extensions && (n.extensions.forEach((o) => {
        if (!o.name)
          throw new Error("extension name required");
        if ("renderer" in o) {
          const l = t.renderers[o.name];
          l ? t.renderers[o.name] = function(...r) {
            let s = o.renderer.apply(this, r);
            return s === !1 && (s = l.apply(this, r)), s;
          } : t.renderers[o.name] = o.renderer;
        }
        if ("tokenizer" in o) {
          if (!o.level || o.level !== "block" && o.level !== "inline")
            throw new Error("extension level must be 'block' or 'inline'");
          const l = t[o.level];
          l ? l.unshift(o.tokenizer) : t[o.level] = [o.tokenizer], o.start && (o.level === "block" ? t.startBlock ? t.startBlock.push(o.start) : t.startBlock = [o.start] : o.level === "inline" && (t.startInline ? t.startInline.push(o.start) : t.startInline = [o.start]));
        }
        "childTokens" in o && o.childTokens && (t.childTokens[o.name] = o.childTokens);
      }), a.extensions = t), n.renderer) {
        const o = this.defaults.renderer || new Tn(this.defaults);
        for (const l in n.renderer) {
          if (!(l in o))
            throw new Error(`renderer '${l}' does not exist`);
          if (l === "options")
            continue;
          const r = l, s = n.renderer[r], u = o[r];
          o[r] = (...c) => {
            let h = s.apply(o, c);
            return h === !1 && (h = u.apply(o, c)), h || "";
          };
        }
        a.renderer = o;
      }
      if (n.tokenizer) {
        const o = this.defaults.tokenizer || new Cn(this.defaults);
        for (const l in n.tokenizer) {
          if (!(l in o))
            throw new Error(`tokenizer '${l}' does not exist`);
          if (["options", "rules", "lexer"].includes(l))
            continue;
          const r = l, s = n.tokenizer[r], u = o[r];
          o[r] = (...c) => {
            let h = s.apply(o, c);
            return h === !1 && (h = u.apply(o, c)), h;
          };
        }
        a.tokenizer = o;
      }
      if (n.hooks) {
        const o = this.defaults.hooks || new an();
        for (const l in n.hooks) {
          if (!(l in o))
            throw new Error(`hook '${l}' does not exist`);
          if (l === "options")
            continue;
          const r = l, s = n.hooks[r], u = o[r];
          an.passThroughHooks.has(l) ? o[r] = (c) => {
            if (this.defaults.async)
              return Promise.resolve(s.call(o, c)).then((d) => u.call(o, d));
            const h = s.call(o, c);
            return u.call(o, h);
          } : o[r] = (...c) => {
            let h = s.apply(o, c);
            return h === !1 && (h = u.apply(o, c)), h;
          };
        }
        a.hooks = o;
      }
      if (n.walkTokens) {
        const o = this.defaults.walkTokens, l = n.walkTokens;
        a.walkTokens = function(r) {
          let s = [];
          return s.push(l.call(this, r)), o && (s = s.concat(o.call(this, r))), s;
        };
      }
      this.defaults = { ...this.defaults, ...a };
    }), this;
  }
  setOptions(e) {
    return this.defaults = { ...this.defaults, ...e }, this;
  }
  lexer(e, t) {
    return it.lex(e, t ?? this.defaults);
  }
  parser(e, t) {
    return at.parse(e, t ?? this.defaults);
  }
}
Tt = new WeakSet(), ti = function(e, t) {
  return (n, a) => {
    const o = { ...a }, l = { ...this.defaults, ...o };
    this.defaults.async === !0 && o.async === !1 && (l.silent || console.warn("marked(): The async option was set to true by an extension. The async: false option sent to parse will be ignored."), l.async = !0);
    const r = pn(this, Tt, pl).call(this, !!l.silent, !!l.async);
    if (typeof n > "u" || n === null)
      return r(new Error("marked(): input parameter is undefined or null"));
    if (typeof n != "string")
      return r(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(n) + ", string expected"));
    if (l.hooks && (l.hooks.options = l), l.async)
      return Promise.resolve(l.hooks ? l.hooks.preprocess(n) : n).then((s) => e(s, l)).then((s) => l.hooks ? l.hooks.processAllTokens(s) : s).then((s) => l.walkTokens ? Promise.all(this.walkTokens(s, l.walkTokens)).then(() => s) : s).then((s) => t(s, l)).then((s) => l.hooks ? l.hooks.postprocess(s) : s).catch(r);
    try {
      l.hooks && (n = l.hooks.preprocess(n));
      let s = e(n, l);
      l.hooks && (s = l.hooks.processAllTokens(s)), l.walkTokens && this.walkTokens(s, l.walkTokens);
      let u = t(s, l);
      return l.hooks && (u = l.hooks.postprocess(u)), u;
    } catch (s) {
      return r(s);
    }
  };
}, pl = function(e, t) {
  return (n) => {
    if (n.message += `
Please report this to https://github.com/markedjs/marked.`, e) {
      const a = "<p>An error occurred:</p><pre>" + Oe(n.message + "", !0) + "</pre>";
      return t ? Promise.resolve(a) : a;
    }
    if (t)
      return Promise.reject(n);
    throw n;
  };
};
const St = new Xo();
function Z(i, e) {
  return St.parse(i, e);
}
Z.options = Z.setOptions = function(i) {
  return St.setOptions(i), Z.defaults = St.defaults, al(Z.defaults), Z;
};
Z.getDefaults = di;
Z.defaults = Bt;
Z.use = function(...i) {
  return St.use(...i), Z.defaults = St.defaults, al(Z.defaults), Z;
};
Z.walkTokens = function(i, e) {
  return St.walkTokens(i, e);
};
Z.parseInline = St.parseInline;
Z.Parser = at;
Z.parser = at.parse;
Z.Renderer = Tn;
Z.TextRenderer = vi;
Z.Lexer = it;
Z.lexer = it.lex;
Z.Tokenizer = Cn;
Z.Hooks = an;
Z.parse = Z;
Z.options;
Z.setOptions;
Z.use;
Z.walkTokens;
Z.parseInline;
at.parse;
it.lex;
const Ko = /[\0-\x1F!-,\.\/:-@\[-\^`\{-\xA9\xAB-\xB4\xB6-\xB9\xBB-\xBF\xD7\xF7\u02C2-\u02C5\u02D2-\u02DF\u02E5-\u02EB\u02ED\u02EF-\u02FF\u0375\u0378\u0379\u037E\u0380-\u0385\u0387\u038B\u038D\u03A2\u03F6\u0482\u0530\u0557\u0558\u055A-\u055F\u0589-\u0590\u05BE\u05C0\u05C3\u05C6\u05C8-\u05CF\u05EB-\u05EE\u05F3-\u060F\u061B-\u061F\u066A-\u066D\u06D4\u06DD\u06DE\u06E9\u06FD\u06FE\u0700-\u070F\u074B\u074C\u07B2-\u07BF\u07F6-\u07F9\u07FB\u07FC\u07FE\u07FF\u082E-\u083F\u085C-\u085F\u086B-\u089F\u08B5\u08C8-\u08D2\u08E2\u0964\u0965\u0970\u0984\u098D\u098E\u0991\u0992\u09A9\u09B1\u09B3-\u09B5\u09BA\u09BB\u09C5\u09C6\u09C9\u09CA\u09CF-\u09D6\u09D8-\u09DB\u09DE\u09E4\u09E5\u09F2-\u09FB\u09FD\u09FF\u0A00\u0A04\u0A0B-\u0A0E\u0A11\u0A12\u0A29\u0A31\u0A34\u0A37\u0A3A\u0A3B\u0A3D\u0A43-\u0A46\u0A49\u0A4A\u0A4E-\u0A50\u0A52-\u0A58\u0A5D\u0A5F-\u0A65\u0A76-\u0A80\u0A84\u0A8E\u0A92\u0AA9\u0AB1\u0AB4\u0ABA\u0ABB\u0AC6\u0ACA\u0ACE\u0ACF\u0AD1-\u0ADF\u0AE4\u0AE5\u0AF0-\u0AF8\u0B00\u0B04\u0B0D\u0B0E\u0B11\u0B12\u0B29\u0B31\u0B34\u0B3A\u0B3B\u0B45\u0B46\u0B49\u0B4A\u0B4E-\u0B54\u0B58-\u0B5B\u0B5E\u0B64\u0B65\u0B70\u0B72-\u0B81\u0B84\u0B8B-\u0B8D\u0B91\u0B96-\u0B98\u0B9B\u0B9D\u0BA0-\u0BA2\u0BA5-\u0BA7\u0BAB-\u0BAD\u0BBA-\u0BBD\u0BC3-\u0BC5\u0BC9\u0BCE\u0BCF\u0BD1-\u0BD6\u0BD8-\u0BE5\u0BF0-\u0BFF\u0C0D\u0C11\u0C29\u0C3A-\u0C3C\u0C45\u0C49\u0C4E-\u0C54\u0C57\u0C5B-\u0C5F\u0C64\u0C65\u0C70-\u0C7F\u0C84\u0C8D\u0C91\u0CA9\u0CB4\u0CBA\u0CBB\u0CC5\u0CC9\u0CCE-\u0CD4\u0CD7-\u0CDD\u0CDF\u0CE4\u0CE5\u0CF0\u0CF3-\u0CFF\u0D0D\u0D11\u0D45\u0D49\u0D4F-\u0D53\u0D58-\u0D5E\u0D64\u0D65\u0D70-\u0D79\u0D80\u0D84\u0D97-\u0D99\u0DB2\u0DBC\u0DBE\u0DBF\u0DC7-\u0DC9\u0DCB-\u0DCE\u0DD5\u0DD7\u0DE0-\u0DE5\u0DF0\u0DF1\u0DF4-\u0E00\u0E3B-\u0E3F\u0E4F\u0E5A-\u0E80\u0E83\u0E85\u0E8B\u0EA4\u0EA6\u0EBE\u0EBF\u0EC5\u0EC7\u0ECE\u0ECF\u0EDA\u0EDB\u0EE0-\u0EFF\u0F01-\u0F17\u0F1A-\u0F1F\u0F2A-\u0F34\u0F36\u0F38\u0F3A-\u0F3D\u0F48\u0F6D-\u0F70\u0F85\u0F98\u0FBD-\u0FC5\u0FC7-\u0FFF\u104A-\u104F\u109E\u109F\u10C6\u10C8-\u10CC\u10CE\u10CF\u10FB\u1249\u124E\u124F\u1257\u1259\u125E\u125F\u1289\u128E\u128F\u12B1\u12B6\u12B7\u12BF\u12C1\u12C6\u12C7\u12D7\u1311\u1316\u1317\u135B\u135C\u1360-\u137F\u1390-\u139F\u13F6\u13F7\u13FE-\u1400\u166D\u166E\u1680\u169B-\u169F\u16EB-\u16ED\u16F9-\u16FF\u170D\u1715-\u171F\u1735-\u173F\u1754-\u175F\u176D\u1771\u1774-\u177F\u17D4-\u17D6\u17D8-\u17DB\u17DE\u17DF\u17EA-\u180A\u180E\u180F\u181A-\u181F\u1879-\u187F\u18AB-\u18AF\u18F6-\u18FF\u191F\u192C-\u192F\u193C-\u1945\u196E\u196F\u1975-\u197F\u19AC-\u19AF\u19CA-\u19CF\u19DA-\u19FF\u1A1C-\u1A1F\u1A5F\u1A7D\u1A7E\u1A8A-\u1A8F\u1A9A-\u1AA6\u1AA8-\u1AAF\u1AC1-\u1AFF\u1B4C-\u1B4F\u1B5A-\u1B6A\u1B74-\u1B7F\u1BF4-\u1BFF\u1C38-\u1C3F\u1C4A-\u1C4C\u1C7E\u1C7F\u1C89-\u1C8F\u1CBB\u1CBC\u1CC0-\u1CCF\u1CD3\u1CFB-\u1CFF\u1DFA\u1F16\u1F17\u1F1E\u1F1F\u1F46\u1F47\u1F4E\u1F4F\u1F58\u1F5A\u1F5C\u1F5E\u1F7E\u1F7F\u1FB5\u1FBD\u1FBF-\u1FC1\u1FC5\u1FCD-\u1FCF\u1FD4\u1FD5\u1FDC-\u1FDF\u1FED-\u1FF1\u1FF5\u1FFD-\u203E\u2041-\u2053\u2055-\u2070\u2072-\u207E\u2080-\u208F\u209D-\u20CF\u20F1-\u2101\u2103-\u2106\u2108\u2109\u2114\u2116-\u2118\u211E-\u2123\u2125\u2127\u2129\u212E\u213A\u213B\u2140-\u2144\u214A-\u214D\u214F-\u215F\u2189-\u24B5\u24EA-\u2BFF\u2C2F\u2C5F\u2CE5-\u2CEA\u2CF4-\u2CFF\u2D26\u2D28-\u2D2C\u2D2E\u2D2F\u2D68-\u2D6E\u2D70-\u2D7E\u2D97-\u2D9F\u2DA7\u2DAF\u2DB7\u2DBF\u2DC7\u2DCF\u2DD7\u2DDF\u2E00-\u2E2E\u2E30-\u3004\u3008-\u3020\u3030\u3036\u3037\u303D-\u3040\u3097\u3098\u309B\u309C\u30A0\u30FB\u3100-\u3104\u3130\u318F-\u319F\u31C0-\u31EF\u3200-\u33FF\u4DC0-\u4DFF\u9FFD-\u9FFF\uA48D-\uA4CF\uA4FE\uA4FF\uA60D-\uA60F\uA62C-\uA63F\uA673\uA67E\uA6F2-\uA716\uA720\uA721\uA789\uA78A\uA7C0\uA7C1\uA7CB-\uA7F4\uA828-\uA82B\uA82D-\uA83F\uA874-\uA87F\uA8C6-\uA8CF\uA8DA-\uA8DF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA954-\uA95F\uA97D-\uA97F\uA9C1-\uA9CE\uA9DA-\uA9DF\uA9FF\uAA37-\uAA3F\uAA4E\uAA4F\uAA5A-\uAA5F\uAA77-\uAA79\uAAC3-\uAADA\uAADE\uAADF\uAAF0\uAAF1\uAAF7-\uAB00\uAB07\uAB08\uAB0F\uAB10\uAB17-\uAB1F\uAB27\uAB2F\uAB5B\uAB6A-\uAB6F\uABEB\uABEE\uABEF\uABFA-\uABFF\uD7A4-\uD7AF\uD7C7-\uD7CA\uD7FC-\uD7FF\uE000-\uF8FF\uFA6E\uFA6F\uFADA-\uFAFF\uFB07-\uFB12\uFB18-\uFB1C\uFB29\uFB37\uFB3D\uFB3F\uFB42\uFB45\uFBB2-\uFBD2\uFD3E-\uFD4F\uFD90\uFD91\uFDC8-\uFDEF\uFDFC-\uFDFF\uFE10-\uFE1F\uFE30-\uFE32\uFE35-\uFE4C\uFE50-\uFE6F\uFE75\uFEFD-\uFF0F\uFF1A-\uFF20\uFF3B-\uFF3E\uFF40\uFF5B-\uFF65\uFFBF-\uFFC1\uFFC8\uFFC9\uFFD0\uFFD1\uFFD8\uFFD9\uFFDD-\uFFFF]|\uD800[\uDC0C\uDC27\uDC3B\uDC3E\uDC4E\uDC4F\uDC5E-\uDC7F\uDCFB-\uDD3F\uDD75-\uDDFC\uDDFE-\uDE7F\uDE9D-\uDE9F\uDED1-\uDEDF\uDEE1-\uDEFF\uDF20-\uDF2C\uDF4B-\uDF4F\uDF7B-\uDF7F\uDF9E\uDF9F\uDFC4-\uDFC7\uDFD0\uDFD6-\uDFFF]|\uD801[\uDC9E\uDC9F\uDCAA-\uDCAF\uDCD4-\uDCD7\uDCFC-\uDCFF\uDD28-\uDD2F\uDD64-\uDDFF\uDF37-\uDF3F\uDF56-\uDF5F\uDF68-\uDFFF]|\uD802[\uDC06\uDC07\uDC09\uDC36\uDC39-\uDC3B\uDC3D\uDC3E\uDC56-\uDC5F\uDC77-\uDC7F\uDC9F-\uDCDF\uDCF3\uDCF6-\uDCFF\uDD16-\uDD1F\uDD3A-\uDD7F\uDDB8-\uDDBD\uDDC0-\uDDFF\uDE04\uDE07-\uDE0B\uDE14\uDE18\uDE36\uDE37\uDE3B-\uDE3E\uDE40-\uDE5F\uDE7D-\uDE7F\uDE9D-\uDEBF\uDEC8\uDEE7-\uDEFF\uDF36-\uDF3F\uDF56-\uDF5F\uDF73-\uDF7F\uDF92-\uDFFF]|\uD803[\uDC49-\uDC7F\uDCB3-\uDCBF\uDCF3-\uDCFF\uDD28-\uDD2F\uDD3A-\uDE7F\uDEAA\uDEAD-\uDEAF\uDEB2-\uDEFF\uDF1D-\uDF26\uDF28-\uDF2F\uDF51-\uDFAF\uDFC5-\uDFDF\uDFF7-\uDFFF]|\uD804[\uDC47-\uDC65\uDC70-\uDC7E\uDCBB-\uDCCF\uDCE9-\uDCEF\uDCFA-\uDCFF\uDD35\uDD40-\uDD43\uDD48-\uDD4F\uDD74\uDD75\uDD77-\uDD7F\uDDC5-\uDDC8\uDDCD\uDDDB\uDDDD-\uDDFF\uDE12\uDE38-\uDE3D\uDE3F-\uDE7F\uDE87\uDE89\uDE8E\uDE9E\uDEA9-\uDEAF\uDEEB-\uDEEF\uDEFA-\uDEFF\uDF04\uDF0D\uDF0E\uDF11\uDF12\uDF29\uDF31\uDF34\uDF3A\uDF45\uDF46\uDF49\uDF4A\uDF4E\uDF4F\uDF51-\uDF56\uDF58-\uDF5C\uDF64\uDF65\uDF6D-\uDF6F\uDF75-\uDFFF]|\uD805[\uDC4B-\uDC4F\uDC5A-\uDC5D\uDC62-\uDC7F\uDCC6\uDCC8-\uDCCF\uDCDA-\uDD7F\uDDB6\uDDB7\uDDC1-\uDDD7\uDDDE-\uDDFF\uDE41-\uDE43\uDE45-\uDE4F\uDE5A-\uDE7F\uDEB9-\uDEBF\uDECA-\uDEFF\uDF1B\uDF1C\uDF2C-\uDF2F\uDF3A-\uDFFF]|\uD806[\uDC3B-\uDC9F\uDCEA-\uDCFE\uDD07\uDD08\uDD0A\uDD0B\uDD14\uDD17\uDD36\uDD39\uDD3A\uDD44-\uDD4F\uDD5A-\uDD9F\uDDA8\uDDA9\uDDD8\uDDD9\uDDE2\uDDE5-\uDDFF\uDE3F-\uDE46\uDE48-\uDE4F\uDE9A-\uDE9C\uDE9E-\uDEBF\uDEF9-\uDFFF]|\uD807[\uDC09\uDC37\uDC41-\uDC4F\uDC5A-\uDC71\uDC90\uDC91\uDCA8\uDCB7-\uDCFF\uDD07\uDD0A\uDD37-\uDD39\uDD3B\uDD3E\uDD48-\uDD4F\uDD5A-\uDD5F\uDD66\uDD69\uDD8F\uDD92\uDD99-\uDD9F\uDDAA-\uDEDF\uDEF7-\uDFAF\uDFB1-\uDFFF]|\uD808[\uDF9A-\uDFFF]|\uD809[\uDC6F-\uDC7F\uDD44-\uDFFF]|[\uD80A\uD80B\uD80E-\uD810\uD812-\uD819\uD824-\uD82B\uD82D\uD82E\uD830-\uD833\uD837\uD839\uD83D\uD83F\uD87B-\uD87D\uD87F\uD885-\uDB3F\uDB41-\uDBFF][\uDC00-\uDFFF]|\uD80D[\uDC2F-\uDFFF]|\uD811[\uDE47-\uDFFF]|\uD81A[\uDE39-\uDE3F\uDE5F\uDE6A-\uDECF\uDEEE\uDEEF\uDEF5-\uDEFF\uDF37-\uDF3F\uDF44-\uDF4F\uDF5A-\uDF62\uDF78-\uDF7C\uDF90-\uDFFF]|\uD81B[\uDC00-\uDE3F\uDE80-\uDEFF\uDF4B-\uDF4E\uDF88-\uDF8E\uDFA0-\uDFDF\uDFE2\uDFE5-\uDFEF\uDFF2-\uDFFF]|\uD821[\uDFF8-\uDFFF]|\uD823[\uDCD6-\uDCFF\uDD09-\uDFFF]|\uD82C[\uDD1F-\uDD4F\uDD53-\uDD63\uDD68-\uDD6F\uDEFC-\uDFFF]|\uD82F[\uDC6B-\uDC6F\uDC7D-\uDC7F\uDC89-\uDC8F\uDC9A-\uDC9C\uDC9F-\uDFFF]|\uD834[\uDC00-\uDD64\uDD6A-\uDD6C\uDD73-\uDD7A\uDD83\uDD84\uDD8C-\uDDA9\uDDAE-\uDE41\uDE45-\uDFFF]|\uD835[\uDC55\uDC9D\uDCA0\uDCA1\uDCA3\uDCA4\uDCA7\uDCA8\uDCAD\uDCBA\uDCBC\uDCC4\uDD06\uDD0B\uDD0C\uDD15\uDD1D\uDD3A\uDD3F\uDD45\uDD47-\uDD49\uDD51\uDEA6\uDEA7\uDEC1\uDEDB\uDEFB\uDF15\uDF35\uDF4F\uDF6F\uDF89\uDFA9\uDFC3\uDFCC\uDFCD]|\uD836[\uDC00-\uDDFF\uDE37-\uDE3A\uDE6D-\uDE74\uDE76-\uDE83\uDE85-\uDE9A\uDEA0\uDEB0-\uDFFF]|\uD838[\uDC07\uDC19\uDC1A\uDC22\uDC25\uDC2B-\uDCFF\uDD2D-\uDD2F\uDD3E\uDD3F\uDD4A-\uDD4D\uDD4F-\uDEBF\uDEFA-\uDFFF]|\uD83A[\uDCC5-\uDCCF\uDCD7-\uDCFF\uDD4C-\uDD4F\uDD5A-\uDFFF]|\uD83B[\uDC00-\uDDFF\uDE04\uDE20\uDE23\uDE25\uDE26\uDE28\uDE33\uDE38\uDE3A\uDE3C-\uDE41\uDE43-\uDE46\uDE48\uDE4A\uDE4C\uDE50\uDE53\uDE55\uDE56\uDE58\uDE5A\uDE5C\uDE5E\uDE60\uDE63\uDE65\uDE66\uDE6B\uDE73\uDE78\uDE7D\uDE7F\uDE8A\uDE9C-\uDEA0\uDEA4\uDEAA\uDEBC-\uDFFF]|\uD83C[\uDC00-\uDD2F\uDD4A-\uDD4F\uDD6A-\uDD6F\uDD8A-\uDFFF]|\uD83E[\uDC00-\uDFEF\uDFFA-\uDFFF]|\uD869[\uDEDE-\uDEFF]|\uD86D[\uDF35-\uDF3F]|\uD86E[\uDC1E\uDC1F]|\uD873[\uDEA2-\uDEAF]|\uD87A[\uDFE1-\uDFFF]|\uD87E[\uDE1E-\uDFFF]|\uD884[\uDF4B-\uDFFF]|\uDB40[\uDC00-\uDCFF\uDDF0-\uDFFF]/g, Qo = Object.hasOwnProperty;
class hl {
  /**
   * Create a new slug class.
   */
  constructor() {
    this.occurrences, this.reset();
  }
  /**
   * Generate a unique slug.
  *
  * Tracks previously generated slugs: repeated calls with the same value
  * will result in different slugs.
  * Use the `slug` function to get same slugs.
   *
   * @param  {string} value
   *   String of text to slugify
   * @param  {boolean} [maintainCase=false]
   *   Keep the current case, otherwise make all lowercase
   * @return {string}
   *   A unique slug string
   */
  slug(e, t) {
    const n = this;
    let a = Jo(e, t === !0);
    const o = a;
    for (; Qo.call(n.occurrences, a); )
      n.occurrences[o]++, a = o + "-" + n.occurrences[o];
    return n.occurrences[a] = 0, a;
  }
  /**
   * Reset - Forget all previous slugs
   *
   * @return void
   */
  reset() {
    this.occurrences = /* @__PURE__ */ Object.create(null);
  }
}
function Jo(i, e) {
  return typeof i != "string" ? "" : (e || (i = i.toLowerCase()), i.replace(Ko, "").replace(/ /g, "-"));
}
new hl();
var Ui = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {}, er = { exports: {} };
(function(i) {
  var e = typeof window < "u" ? window : typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope ? self : {};
  /**
   * Prism: Lightweight, robust, elegant syntax highlighting
   *
   * @license MIT <https://opensource.org/licenses/MIT>
   * @author Lea Verou <https://lea.verou.me>
   * @namespace
   * @public
   */
  var t = function(n) {
    var a = /(?:^|\s)lang(?:uage)?-([\w-]+)(?=\s|$)/i, o = 0, l = {}, r = {
      /**
       * By default, Prism will attempt to highlight all code elements (by calling {@link Prism.highlightAll}) on the
       * current page after the page finished loading. This might be a problem if e.g. you wanted to asynchronously load
       * additional languages or plugins yourself.
       *
       * By setting this value to `true`, Prism will not automatically highlight all code elements on the page.
       *
       * You obviously have to change this value before the automatic highlighting started. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.manual = true;
       * // add a new <script> to load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      manual: n.Prism && n.Prism.manual,
      /**
       * By default, if Prism is in a web worker, it assumes that it is in a worker it created itself, so it uses
       * `addEventListener` to communicate with its parent instance. However, if you're using Prism manually in your
       * own worker, you don't want it to do this.
       *
       * By setting this value to `true`, Prism will not add its own listeners to the worker.
       *
       * You obviously have to change this value before Prism executes. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.disableWorkerMessageHandler = true;
       * // Load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      disableWorkerMessageHandler: n.Prism && n.Prism.disableWorkerMessageHandler,
      /**
       * A namespace for utility methods.
       *
       * All function in this namespace that are not explicitly marked as _public_ are for __internal use only__ and may
       * change or disappear at any time.
       *
       * @namespace
       * @memberof Prism
       */
      util: {
        encode: function m(_) {
          return _ instanceof s ? new s(_.type, m(_.content), _.alias) : Array.isArray(_) ? _.map(m) : _.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\u00a0/g, " ");
        },
        /**
         * Returns the name of the type of the given value.
         *
         * @param {any} o
         * @returns {string}
         * @example
         * type(null)      === 'Null'
         * type(undefined) === 'Undefined'
         * type(123)       === 'Number'
         * type('foo')     === 'String'
         * type(true)      === 'Boolean'
         * type([1, 2])    === 'Array'
         * type({})        === 'Object'
         * type(String)    === 'Function'
         * type(/abc+/)    === 'RegExp'
         */
        type: function(m) {
          return Object.prototype.toString.call(m).slice(8, -1);
        },
        /**
         * Returns a unique number for the given object. Later calls will still return the same number.
         *
         * @param {Object} obj
         * @returns {number}
         */
        objId: function(m) {
          return m.__id || Object.defineProperty(m, "__id", { value: ++o }), m.__id;
        },
        /**
         * Creates a deep clone of the given object.
         *
         * The main intended use of this function is to clone language definitions.
         *
         * @param {T} o
         * @param {Record<number, any>} [visited]
         * @returns {T}
         * @template T
         */
        clone: function m(_, g) {
          g = g || {};
          var y, F;
          switch (r.util.type(_)) {
            case "Object":
              if (F = r.util.objId(_), g[F])
                return g[F];
              y = /** @type {Record<string, any>} */
              {}, g[F] = y;
              for (var C in _)
                _.hasOwnProperty(C) && (y[C] = m(_[C], g));
              return (
                /** @type {any} */
                y
              );
            case "Array":
              return F = r.util.objId(_), g[F] ? g[F] : (y = [], g[F] = y, /** @type {Array} */
              /** @type {any} */
              _.forEach(function(T, S) {
                y[S] = m(T, g);
              }), /** @type {any} */
              y);
            default:
              return _;
          }
        },
        /**
         * Returns the Prism language of the given element set by a `language-xxxx` or `lang-xxxx` class.
         *
         * If no language is set for the element or the element is `null` or `undefined`, `none` will be returned.
         *
         * @param {Element} element
         * @returns {string}
         */
        getLanguage: function(m) {
          for (; m; ) {
            var _ = a.exec(m.className);
            if (_)
              return _[1].toLowerCase();
            m = m.parentElement;
          }
          return "none";
        },
        /**
         * Sets the Prism `language-xxxx` class of the given element.
         *
         * @param {Element} element
         * @param {string} language
         * @returns {void}
         */
        setLanguage: function(m, _) {
          m.className = m.className.replace(RegExp(a, "gi"), ""), m.classList.add("language-" + _);
        },
        /**
         * Returns the script element that is currently executing.
         *
         * This does __not__ work for line script element.
         *
         * @returns {HTMLScriptElement | null}
         */
        currentScript: function() {
          if (typeof document > "u")
            return null;
          if ("currentScript" in document)
            return (
              /** @type {any} */
              document.currentScript
            );
          try {
            throw new Error();
          } catch (y) {
            var m = (/at [^(\r\n]*\((.*):[^:]+:[^:]+\)$/i.exec(y.stack) || [])[1];
            if (m) {
              var _ = document.getElementsByTagName("script");
              for (var g in _)
                if (_[g].src == m)
                  return _[g];
            }
            return null;
          }
        },
        /**
         * Returns whether a given class is active for `element`.
         *
         * The class can be activated if `element` or one of its ancestors has the given class and it can be deactivated
         * if `element` or one of its ancestors has the negated version of the given class. The _negated version_ of the
         * given class is just the given class with a `no-` prefix.
         *
         * Whether the class is active is determined by the closest ancestor of `element` (where `element` itself is
         * closest ancestor) that has the given class or the negated version of it. If neither `element` nor any of its
         * ancestors have the given class or the negated version of it, then the default activation will be returned.
         *
         * In the paradoxical situation where the closest ancestor contains __both__ the given class and the negated
         * version of it, the class is considered active.
         *
         * @param {Element} element
         * @param {string} className
         * @param {boolean} [defaultActivation=false]
         * @returns {boolean}
         */
        isActive: function(m, _, g) {
          for (var y = "no-" + _; m; ) {
            var F = m.classList;
            if (F.contains(_))
              return !0;
            if (F.contains(y))
              return !1;
            m = m.parentElement;
          }
          return !!g;
        }
      },
      /**
       * This namespace contains all currently loaded languages and the some helper functions to create and modify languages.
       *
       * @namespace
       * @memberof Prism
       * @public
       */
      languages: {
        /**
         * The grammar for plain, unformatted text.
         */
        plain: l,
        plaintext: l,
        text: l,
        txt: l,
        /**
         * Creates a deep copy of the language with the given id and appends the given tokens.
         *
         * If a token in `redef` also appears in the copied language, then the existing token in the copied language
         * will be overwritten at its original position.
         *
         * ## Best practices
         *
         * Since the position of overwriting tokens (token in `redef` that overwrite tokens in the copied language)
         * doesn't matter, they can technically be in any order. However, this can be confusing to others that trying to
         * understand the language definition because, normally, the order of tokens matters in Prism grammars.
         *
         * Therefore, it is encouraged to order overwriting tokens according to the positions of the overwritten tokens.
         * Furthermore, all non-overwriting tokens should be placed after the overwriting ones.
         *
         * @param {string} id The id of the language to extend. This has to be a key in `Prism.languages`.
         * @param {Grammar} redef The new tokens to append.
         * @returns {Grammar} The new language created.
         * @public
         * @example
         * Prism.languages['css-with-colors'] = Prism.languages.extend('css', {
         *     // Prism.languages.css already has a 'comment' token, so this token will overwrite CSS' 'comment' token
         *     // at its original position
         *     'comment': { ... },
         *     // CSS doesn't have a 'color' token, so this token will be appended
         *     'color': /\b(?:red|green|blue)\b/
         * });
         */
        extend: function(m, _) {
          var g = r.util.clone(r.languages[m]);
          for (var y in _)
            g[y] = _[y];
          return g;
        },
        /**
         * Inserts tokens _before_ another token in a language definition or any other grammar.
         *
         * ## Usage
         *
         * This helper method makes it easy to modify existing languages. For example, the CSS language definition
         * not only defines CSS highlighting for CSS documents, but also needs to define highlighting for CSS embedded
         * in HTML through `<style>` elements. To do this, it needs to modify `Prism.languages.markup` and add the
         * appropriate tokens. However, `Prism.languages.markup` is a regular JavaScript object literal, so if you do
         * this:
         *
         * ```js
         * Prism.languages.markup.style = {
         *     // token
         * };
         * ```
         *
         * then the `style` token will be added (and processed) at the end. `insertBefore` allows you to insert tokens
         * before existing tokens. For the CSS example above, you would use it like this:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'cdata', {
         *     'style': {
         *         // token
         *     }
         * });
         * ```
         *
         * ## Special cases
         *
         * If the grammars of `inside` and `insert` have tokens with the same name, the tokens in `inside`'s grammar
         * will be ignored.
         *
         * This behavior can be used to insert tokens after `before`:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'comment', {
         *     'comment': Prism.languages.markup.comment,
         *     // tokens after 'comment'
         * });
         * ```
         *
         * ## Limitations
         *
         * The main problem `insertBefore` has to solve is iteration order. Since ES2015, the iteration order for object
         * properties is guaranteed to be the insertion order (except for integer keys) but some browsers behave
         * differently when keys are deleted and re-inserted. So `insertBefore` can't be implemented by temporarily
         * deleting properties which is necessary to insert at arbitrary positions.
         *
         * To solve this problem, `insertBefore` doesn't actually insert the given tokens into the target object.
         * Instead, it will create a new object and replace all references to the target object with the new one. This
         * can be done without temporarily deleting properties, so the iteration order is well-defined.
         *
         * However, only references that can be reached from `Prism.languages` or `insert` will be replaced. I.e. if
         * you hold the target object in a variable, then the value of the variable will not change.
         *
         * ```js
         * var oldMarkup = Prism.languages.markup;
         * var newMarkup = Prism.languages.insertBefore('markup', 'comment', { ... });
         *
         * assert(oldMarkup !== Prism.languages.markup);
         * assert(newMarkup === Prism.languages.markup);
         * ```
         *
         * @param {string} inside The property of `root` (e.g. a language id in `Prism.languages`) that contains the
         * object to be modified.
         * @param {string} before The key to insert before.
         * @param {Grammar} insert An object containing the key-value pairs to be inserted.
         * @param {Object<string, any>} [root] The object containing `inside`, i.e. the object that contains the
         * object to be modified.
         *
         * Defaults to `Prism.languages`.
         * @returns {Grammar} The new grammar object.
         * @public
         */
        insertBefore: function(m, _, g, y) {
          y = y || /** @type {any} */
          r.languages;
          var F = y[m], C = {};
          for (var T in F)
            if (F.hasOwnProperty(T)) {
              if (T == _)
                for (var S in g)
                  g.hasOwnProperty(S) && (C[S] = g[S]);
              g.hasOwnProperty(T) || (C[T] = F[T]);
            }
          var z = y[m];
          return y[m] = C, r.languages.DFS(r.languages, function(N, j) {
            j === z && N != m && (this[N] = C);
          }), C;
        },
        // Traverse a language definition with Depth First Search
        DFS: function m(_, g, y, F) {
          F = F || {};
          var C = r.util.objId;
          for (var T in _)
            if (_.hasOwnProperty(T)) {
              g.call(_, T, _[T], y || T);
              var S = _[T], z = r.util.type(S);
              z === "Object" && !F[C(S)] ? (F[C(S)] = !0, m(S, g, null, F)) : z === "Array" && !F[C(S)] && (F[C(S)] = !0, m(S, g, T, F));
            }
        }
      },
      plugins: {},
      /**
       * This is the most high-level function in Prism’s API.
       * It fetches all the elements that have a `.language-xxxx` class and then calls {@link Prism.highlightElement} on
       * each one of them.
       *
       * This is equivalent to `Prism.highlightAllUnder(document, async, callback)`.
       *
       * @param {boolean} [async=false] Same as in {@link Prism.highlightAllUnder}.
       * @param {HighlightCallback} [callback] Same as in {@link Prism.highlightAllUnder}.
       * @memberof Prism
       * @public
       */
      highlightAll: function(m, _) {
        r.highlightAllUnder(document, m, _);
      },
      /**
       * Fetches all the descendants of `container` that have a `.language-xxxx` class and then calls
       * {@link Prism.highlightElement} on each one of them.
       *
       * The following hooks will be run:
       * 1. `before-highlightall`
       * 2. `before-all-elements-highlight`
       * 3. All hooks of {@link Prism.highlightElement} for each element.
       *
       * @param {ParentNode} container The root element, whose descendants that have a `.language-xxxx` class will be highlighted.
       * @param {boolean} [async=false] Whether each element is to be highlighted asynchronously using Web Workers.
       * @param {HighlightCallback} [callback] An optional callback to be invoked on each element after its highlighting is done.
       * @memberof Prism
       * @public
       */
      highlightAllUnder: function(m, _, g) {
        var y = {
          callback: g,
          container: m,
          selector: 'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'
        };
        r.hooks.run("before-highlightall", y), y.elements = Array.prototype.slice.apply(y.container.querySelectorAll(y.selector)), r.hooks.run("before-all-elements-highlight", y);
        for (var F = 0, C; C = y.elements[F++]; )
          r.highlightElement(C, _ === !0, y.callback);
      },
      /**
       * Highlights the code inside a single element.
       *
       * The following hooks will be run:
       * 1. `before-sanity-check`
       * 2. `before-highlight`
       * 3. All hooks of {@link Prism.highlight}. These hooks will be run by an asynchronous worker if `async` is `true`.
       * 4. `before-insert`
       * 5. `after-highlight`
       * 6. `complete`
       *
       * Some the above hooks will be skipped if the element doesn't contain any text or there is no grammar loaded for
       * the element's language.
       *
       * @param {Element} element The element containing the code.
       * It must have a class of `language-xxxx` to be processed, where `xxxx` is a valid language identifier.
       * @param {boolean} [async=false] Whether the element is to be highlighted asynchronously using Web Workers
       * to improve performance and avoid blocking the UI when highlighting very large chunks of code. This option is
       * [disabled by default](https://prismjs.com/faq.html#why-is-asynchronous-highlighting-disabled-by-default).
       *
       * Note: All language definitions required to highlight the code must be included in the main `prism.js` file for
       * asynchronous highlighting to work. You can build your own bundle on the
       * [Download page](https://prismjs.com/download.html).
       * @param {HighlightCallback} [callback] An optional callback to be invoked after the highlighting is done.
       * Mostly useful when `async` is `true`, since in that case, the highlighting is done asynchronously.
       * @memberof Prism
       * @public
       */
      highlightElement: function(m, _, g) {
        var y = r.util.getLanguage(m), F = r.languages[y];
        r.util.setLanguage(m, y);
        var C = m.parentElement;
        C && C.nodeName.toLowerCase() === "pre" && r.util.setLanguage(C, y);
        var T = m.textContent, S = {
          element: m,
          language: y,
          grammar: F,
          code: T
        };
        function z(j) {
          S.highlightedCode = j, r.hooks.run("before-insert", S), S.element.innerHTML = S.highlightedCode, r.hooks.run("after-highlight", S), r.hooks.run("complete", S), g && g.call(S.element);
        }
        if (r.hooks.run("before-sanity-check", S), C = S.element.parentElement, C && C.nodeName.toLowerCase() === "pre" && !C.hasAttribute("tabindex") && C.setAttribute("tabindex", "0"), !S.code) {
          r.hooks.run("complete", S), g && g.call(S.element);
          return;
        }
        if (r.hooks.run("before-highlight", S), !S.grammar) {
          z(r.util.encode(S.code));
          return;
        }
        if (_ && n.Worker) {
          var N = new Worker(r.filename);
          N.onmessage = function(j) {
            z(j.data);
          }, N.postMessage(JSON.stringify({
            language: S.language,
            code: S.code,
            immediateClose: !0
          }));
        } else
          z(r.highlight(S.code, S.grammar, S.language));
      },
      /**
       * Low-level function, only use if you know what you’re doing. It accepts a string of text as input
       * and the language definitions to use, and returns a string with the HTML produced.
       *
       * The following hooks will be run:
       * 1. `before-tokenize`
       * 2. `after-tokenize`
       * 3. `wrap`: On each {@link Token}.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @param {string} language The name of the language definition passed to `grammar`.
       * @returns {string} The highlighted HTML.
       * @memberof Prism
       * @public
       * @example
       * Prism.highlight('var foo = true;', Prism.languages.javascript, 'javascript');
       */
      highlight: function(m, _, g) {
        var y = {
          code: m,
          grammar: _,
          language: g
        };
        if (r.hooks.run("before-tokenize", y), !y.grammar)
          throw new Error('The language "' + y.language + '" has no grammar.');
        return y.tokens = r.tokenize(y.code, y.grammar), r.hooks.run("after-tokenize", y), s.stringify(r.util.encode(y.tokens), y.language);
      },
      /**
       * This is the heart of Prism, and the most low-level function you can use. It accepts a string of text as input
       * and the language definitions to use, and returns an array with the tokenized code.
       *
       * When the language definition includes nested tokens, the function is called recursively on each of these tokens.
       *
       * This method could be useful in other contexts as well, as a very crude parser.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @returns {TokenStream} An array of strings and tokens, a token stream.
       * @memberof Prism
       * @public
       * @example
       * let code = `var foo = 0;`;
       * let tokens = Prism.tokenize(code, Prism.languages.javascript);
       * tokens.forEach(token => {
       *     if (token instanceof Prism.Token && token.type === 'number') {
       *         console.log(`Found numeric literal: ${token.content}`);
       *     }
       * });
       */
      tokenize: function(m, _) {
        var g = _.rest;
        if (g) {
          for (var y in g)
            _[y] = g[y];
          delete _.rest;
        }
        var F = new h();
        return d(F, F.head, m), c(m, F, _, F.head, 0), v(F);
      },
      /**
       * @namespace
       * @memberof Prism
       * @public
       */
      hooks: {
        all: {},
        /**
         * Adds the given callback to the list of callbacks for the given hook.
         *
         * The callback will be invoked when the hook it is registered for is run.
         * Hooks are usually directly run by a highlight function but you can also run hooks yourself.
         *
         * One callback function can be registered to multiple hooks and the same hook multiple times.
         *
         * @param {string} name The name of the hook.
         * @param {HookCallback} callback The callback function which is given environment variables.
         * @public
         */
        add: function(m, _) {
          var g = r.hooks.all;
          g[m] = g[m] || [], g[m].push(_);
        },
        /**
         * Runs a hook invoking all registered callbacks with the given environment variables.
         *
         * Callbacks will be invoked synchronously and in the order in which they were registered.
         *
         * @param {string} name The name of the hook.
         * @param {Object<string, any>} env The environment variables of the hook passed to all callbacks registered.
         * @public
         */
        run: function(m, _) {
          var g = r.hooks.all[m];
          if (!(!g || !g.length))
            for (var y = 0, F; F = g[y++]; )
              F(_);
        }
      },
      Token: s
    };
    n.Prism = r;
    function s(m, _, g, y) {
      this.type = m, this.content = _, this.alias = g, this.length = (y || "").length | 0;
    }
    s.stringify = function m(_, g) {
      if (typeof _ == "string")
        return _;
      if (Array.isArray(_)) {
        var y = "";
        return _.forEach(function(z) {
          y += m(z, g);
        }), y;
      }
      var F = {
        type: _.type,
        content: m(_.content, g),
        tag: "span",
        classes: ["token", _.type],
        attributes: {},
        language: g
      }, C = _.alias;
      C && (Array.isArray(C) ? Array.prototype.push.apply(F.classes, C) : F.classes.push(C)), r.hooks.run("wrap", F);
      var T = "";
      for (var S in F.attributes)
        T += " " + S + '="' + (F.attributes[S] || "").replace(/"/g, "&quot;") + '"';
      return "<" + F.tag + ' class="' + F.classes.join(" ") + '"' + T + ">" + F.content + "</" + F.tag + ">";
    };
    function u(m, _, g, y) {
      m.lastIndex = _;
      var F = m.exec(g);
      if (F && y && F[1]) {
        var C = F[1].length;
        F.index += C, F[0] = F[0].slice(C);
      }
      return F;
    }
    function c(m, _, g, y, F, C) {
      for (var T in g)
        if (!(!g.hasOwnProperty(T) || !g[T])) {
          var S = g[T];
          S = Array.isArray(S) ? S : [S];
          for (var z = 0; z < S.length; ++z) {
            if (C && C.cause == T + "," + z)
              return;
            var N = S[z], j = N.inside, ke = !!N.lookbehind, ue = !!N.greedy, $e = N.alias;
            if (ue && !N.pattern.global) {
              var _e = N.pattern.toString().match(/[imsuy]*$/)[0];
              N.pattern = RegExp(N.pattern.source, _e + "g");
            }
            for (var ne = N.pattern || N, X = y.next, se = F; X !== _.tail && !(C && se >= C.reach); se += X.value.length, X = X.next) {
              var ve = X.value;
              if (_.length > m.length)
                return;
              if (!(ve instanceof s)) {
                var $ = 1, oe;
                if (ue) {
                  if (oe = u(ne, se, m, ke), !oe || oe.index >= m.length)
                    break;
                  var Se = oe.index, K = oe.index + oe[0].length, de = se;
                  for (de += X.value.length; Se >= de; )
                    X = X.next, de += X.value.length;
                  if (de -= X.value.length, se = de, X.value instanceof s)
                    continue;
                  for (var A = X; A !== _.tail && (de < K || typeof A.value == "string"); A = A.next)
                    $++, de += A.value.length;
                  $--, ve = m.slice(se, de), oe.index -= se;
                } else if (oe = u(ne, 0, ve, ke), !oe)
                  continue;
                var Se = oe.index, Ke = oe[0], Dt = ve.slice(0, Se), bt = ve.slice(Se + Ke.length), yt = se + ve.length;
                C && yt > C.reach && (C.reach = yt);
                var _t = X.prev;
                Dt && (_t = d(_, _t, Dt), se += Dt.length), f(_, _t, $);
                var Qe = new s(T, j ? r.tokenize(Ke, j) : Ke, $e, Ke);
                if (X = d(_, _t, Qe), bt && d(_, X, bt), $ > 1) {
                  var Je = {
                    cause: T + "," + z,
                    reach: yt
                  };
                  c(m, _, g, X.prev, se, Je), C && Je.reach > C.reach && (C.reach = Je.reach);
                }
              }
            }
          }
        }
    }
    function h() {
      var m = { value: null, prev: null, next: null }, _ = { value: null, prev: m, next: null };
      m.next = _, this.head = m, this.tail = _, this.length = 0;
    }
    function d(m, _, g) {
      var y = _.next, F = { value: g, prev: _, next: y };
      return _.next = F, y.prev = F, m.length++, F;
    }
    function f(m, _, g) {
      for (var y = _.next, F = 0; F < g && y !== m.tail; F++)
        y = y.next;
      _.next = y, y.prev = _, m.length -= F;
    }
    function v(m) {
      for (var _ = [], g = m.head.next; g !== m.tail; )
        _.push(g.value), g = g.next;
      return _;
    }
    if (!n.document)
      return n.addEventListener && (r.disableWorkerMessageHandler || n.addEventListener("message", function(m) {
        var _ = JSON.parse(m.data), g = _.language, y = _.code, F = _.immediateClose;
        n.postMessage(r.highlight(y, r.languages[g], g)), F && n.close();
      }, !1)), r;
    var b = r.util.currentScript();
    b && (r.filename = b.src, b.hasAttribute("data-manual") && (r.manual = !0));
    function w() {
      r.manual || r.highlightAll();
    }
    if (!r.manual) {
      var k = document.readyState;
      k === "loading" || k === "interactive" && b && b.defer ? document.addEventListener("DOMContentLoaded", w) : window.requestAnimationFrame ? window.requestAnimationFrame(w) : window.setTimeout(w, 16);
    }
    return r;
  }(e);
  i.exports && (i.exports = t), typeof Ui < "u" && (Ui.Prism = t), t.languages.markup = {
    comment: {
      pattern: /<!--(?:(?!<!--)[\s\S])*?-->/,
      greedy: !0
    },
    prolog: {
      pattern: /<\?[\s\S]+?\?>/,
      greedy: !0
    },
    doctype: {
      // https://www.w3.org/TR/xml/#NT-doctypedecl
      pattern: /<!DOCTYPE(?:[^>"'[\]]|"[^"]*"|'[^']*')+(?:\[(?:[^<"'\]]|"[^"]*"|'[^']*'|<(?!!--)|<!--(?:[^-]|-(?!->))*-->)*\]\s*)?>/i,
      greedy: !0,
      inside: {
        "internal-subset": {
          pattern: /(^[^\[]*\[)[\s\S]+(?=\]>$)/,
          lookbehind: !0,
          greedy: !0,
          inside: null
          // see below
        },
        string: {
          pattern: /"[^"]*"|'[^']*'/,
          greedy: !0
        },
        punctuation: /^<!|>$|[[\]]/,
        "doctype-tag": /^DOCTYPE/i,
        name: /[^\s<>'"]+/
      }
    },
    cdata: {
      pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
      greedy: !0
    },
    tag: {
      pattern: /<\/?(?!\d)[^\s>\/=$<%]+(?:\s(?:\s*[^\s>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))|(?=[\s/>])))+)?\s*\/?>/,
      greedy: !0,
      inside: {
        tag: {
          pattern: /^<\/?[^\s>\/]+/,
          inside: {
            punctuation: /^<\/?/,
            namespace: /^[^\s>\/:]+:/
          }
        },
        "special-attr": [],
        "attr-value": {
          pattern: /=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+)/,
          inside: {
            punctuation: [
              {
                pattern: /^=/,
                alias: "attr-equals"
              },
              {
                pattern: /^(\s*)["']|["']$/,
                lookbehind: !0
              }
            ]
          }
        },
        punctuation: /\/?>/,
        "attr-name": {
          pattern: /[^\s>\/]+/,
          inside: {
            namespace: /^[^\s>\/:]+:/
          }
        }
      }
    },
    entity: [
      {
        pattern: /&[\da-z]{1,8};/i,
        alias: "named-entity"
      },
      /&#x?[\da-f]{1,8};/i
    ]
  }, t.languages.markup.tag.inside["attr-value"].inside.entity = t.languages.markup.entity, t.languages.markup.doctype.inside["internal-subset"].inside = t.languages.markup, t.hooks.add("wrap", function(n) {
    n.type === "entity" && (n.attributes.title = n.content.replace(/&amp;/, "&"));
  }), Object.defineProperty(t.languages.markup.tag, "addInlined", {
    /**
     * Adds an inlined language to markup.
     *
     * An example of an inlined language is CSS with `<style>` tags.
     *
     * @param {string} tagName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addInlined('style', 'css');
     */
    value: function(a, o) {
      var l = {};
      l["language-" + o] = {
        pattern: /(^<!\[CDATA\[)[\s\S]+?(?=\]\]>$)/i,
        lookbehind: !0,
        inside: t.languages[o]
      }, l.cdata = /^<!\[CDATA\[|\]\]>$/i;
      var r = {
        "included-cdata": {
          pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
          inside: l
        }
      };
      r["language-" + o] = {
        pattern: /[\s\S]+/,
        inside: t.languages[o]
      };
      var s = {};
      s[a] = {
        pattern: RegExp(/(<__[^>]*>)(?:<!\[CDATA\[(?:[^\]]|\](?!\]>))*\]\]>|(?!<!\[CDATA\[)[\s\S])*?(?=<\/__>)/.source.replace(/__/g, function() {
          return a;
        }), "i"),
        lookbehind: !0,
        greedy: !0,
        inside: r
      }, t.languages.insertBefore("markup", "cdata", s);
    }
  }), Object.defineProperty(t.languages.markup.tag, "addAttribute", {
    /**
     * Adds an pattern to highlight languages embedded in HTML attributes.
     *
     * An example of an inlined language is CSS with `style` attributes.
     *
     * @param {string} attrName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addAttribute('style', 'css');
     */
    value: function(n, a) {
      t.languages.markup.tag.inside["special-attr"].push({
        pattern: RegExp(
          /(^|["'\s])/.source + "(?:" + n + ")" + /\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))/.source,
          "i"
        ),
        lookbehind: !0,
        inside: {
          "attr-name": /^[^\s=]+/,
          "attr-value": {
            pattern: /=[\s\S]+/,
            inside: {
              value: {
                pattern: /(^=\s*(["']|(?!["'])))\S[\s\S]*(?=\2$)/,
                lookbehind: !0,
                alias: [a, "language-" + a],
                inside: t.languages[a]
              },
              punctuation: [
                {
                  pattern: /^=/,
                  alias: "attr-equals"
                },
                /"|'/
              ]
            }
          }
        }
      });
    }
  }), t.languages.html = t.languages.markup, t.languages.mathml = t.languages.markup, t.languages.svg = t.languages.markup, t.languages.xml = t.languages.extend("markup", {}), t.languages.ssml = t.languages.xml, t.languages.atom = t.languages.xml, t.languages.rss = t.languages.xml, function(n) {
    var a = /(?:"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n])*')/;
    n.languages.css = {
      comment: /\/\*[\s\S]*?\*\//,
      atrule: {
        pattern: RegExp("@[\\w-](?:" + /[^;{\s"']|\s+(?!\s)/.source + "|" + a.source + ")*?" + /(?:;|(?=\s*\{))/.source),
        inside: {
          rule: /^@[\w-]+/,
          "selector-function-argument": {
            pattern: /(\bselector\s*\(\s*(?![\s)]))(?:[^()\s]|\s+(?![\s)])|\((?:[^()]|\([^()]*\))*\))+(?=\s*\))/,
            lookbehind: !0,
            alias: "selector"
          },
          keyword: {
            pattern: /(^|[^\w-])(?:and|not|only|or)(?![\w-])/,
            lookbehind: !0
          }
          // See rest below
        }
      },
      url: {
        // https://drafts.csswg.org/css-values-3/#urls
        pattern: RegExp("\\burl\\((?:" + a.source + "|" + /(?:[^\\\r\n()"']|\\[\s\S])*/.source + ")\\)", "i"),
        greedy: !0,
        inside: {
          function: /^url/i,
          punctuation: /^\(|\)$/,
          string: {
            pattern: RegExp("^" + a.source + "$"),
            alias: "url"
          }
        }
      },
      selector: {
        pattern: RegExp(`(^|[{}\\s])[^{}\\s](?:[^{};"'\\s]|\\s+(?![\\s{])|` + a.source + ")*(?=\\s*\\{)"),
        lookbehind: !0
      },
      string: {
        pattern: a,
        greedy: !0
      },
      property: {
        pattern: /(^|[^-\w\xA0-\uFFFF])(?!\s)[-_a-z\xA0-\uFFFF](?:(?!\s)[-\w\xA0-\uFFFF])*(?=\s*:)/i,
        lookbehind: !0
      },
      important: /!important\b/i,
      function: {
        pattern: /(^|[^-a-z0-9])[-a-z0-9]+(?=\()/i,
        lookbehind: !0
      },
      punctuation: /[(){};:,]/
    }, n.languages.css.atrule.inside.rest = n.languages.css;
    var o = n.languages.markup;
    o && (o.tag.addInlined("style", "css"), o.tag.addAttribute("style", "css"));
  }(t), t.languages.clike = {
    comment: [
      {
        pattern: /(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,
        lookbehind: !0,
        greedy: !0
      },
      {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0,
        greedy: !0
      }
    ],
    string: {
      pattern: /(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,
      greedy: !0
    },
    "class-name": {
      pattern: /(\b(?:class|extends|implements|instanceof|interface|new|trait)\s+|\bcatch\s+\()[\w.\\]+/i,
      lookbehind: !0,
      inside: {
        punctuation: /[.\\]/
      }
    },
    keyword: /\b(?:break|catch|continue|do|else|finally|for|function|if|in|instanceof|new|null|return|throw|try|while)\b/,
    boolean: /\b(?:false|true)\b/,
    function: /\b\w+(?=\()/,
    number: /\b0x[\da-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,
    operator: /[<>]=?|[!=]=?=?|--?|\+\+?|&&?|\|\|?|[?*/~^%]/,
    punctuation: /[{}[\];(),.:]/
  }, t.languages.javascript = t.languages.extend("clike", {
    "class-name": [
      t.languages.clike["class-name"],
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$A-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\.(?:constructor|prototype))/,
        lookbehind: !0
      }
    ],
    keyword: [
      {
        pattern: /((?:^|\})\s*)catch\b/,
        lookbehind: !0
      },
      {
        pattern: /(^|[^.]|\.\.\.\s*)\b(?:as|assert(?=\s*\{)|async(?=\s*(?:function\b|\(|[$\w\xA0-\uFFFF]|$))|await|break|case|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally(?=\s*(?:\{|$))|for|from(?=\s*(?:['"]|$))|function|(?:get|set)(?=\s*(?:[#\[$\w\xA0-\uFFFF]|$))|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)\b/,
        lookbehind: !0
      }
    ],
    // Allow for all non-ASCII characters (See http://stackoverflow.com/a/2008444)
    function: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*(?:\.\s*(?:apply|bind|call)\s*)?\()/,
    number: {
      pattern: RegExp(
        /(^|[^\w$])/.source + "(?:" + // constant
        (/NaN|Infinity/.source + "|" + // binary integer
        /0[bB][01]+(?:_[01]+)*n?/.source + "|" + // octal integer
        /0[oO][0-7]+(?:_[0-7]+)*n?/.source + "|" + // hexadecimal integer
        /0[xX][\dA-Fa-f]+(?:_[\dA-Fa-f]+)*n?/.source + "|" + // decimal bigint
        /\d+(?:_\d+)*n/.source + "|" + // decimal number (integer or float) but no bigint
        /(?:\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\.\d+(?:_\d+)*)(?:[Ee][+-]?\d+(?:_\d+)*)?/.source) + ")" + /(?![\w$])/.source
      ),
      lookbehind: !0
    },
    operator: /--|\+\+|\*\*=?|=>|&&=?|\|\|=?|[!=]==|<<=?|>>>?=?|[-+*/%&|^!=<>]=?|\.{3}|\?\?=?|\?\.?|[~:]/
  }), t.languages.javascript["class-name"][0].pattern = /(\b(?:class|extends|implements|instanceof|interface|new)\s+)[\w.\\]+/, t.languages.insertBefore("javascript", "keyword", {
    regex: {
      pattern: RegExp(
        // lookbehind
        // eslint-disable-next-line regexp/no-dupe-characters-character-class
        /((?:^|[^$\w\xA0-\uFFFF."'\])\s]|\b(?:return|yield))\s*)/.source + // Regex pattern:
        // There are 2 regex patterns here. The RegExp set notation proposal added support for nested character
        // classes if the `v` flag is present. Unfortunately, nested CCs are both context-free and incompatible
        // with the only syntax, so we have to define 2 different regex patterns.
        /\//.source + "(?:" + /(?:\[(?:[^\]\\\r\n]|\\.)*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}/.source + "|" + // `v` flag syntax. This supports 3 levels of nested character classes.
        /(?:\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.)*\])*\])*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}v[dgimyus]{0,7}/.source + ")" + // lookahead
        /(?=(?:\s|\/\*(?:[^*]|\*(?!\/))*\*\/)*(?:$|[\r\n,.;:})\]]|\/\/))/.source
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        "regex-source": {
          pattern: /^(\/)[\s\S]+(?=\/[a-z]*$)/,
          lookbehind: !0,
          alias: "language-regex",
          inside: t.languages.regex
        },
        "regex-delimiter": /^\/|\/$/,
        "regex-flags": /^[a-z]+$/
      }
    },
    // This must be declared before keyword because we use "function" inside the look-forward
    "function-variable": {
      pattern: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*[=:]\s*(?:async\s*)?(?:\bfunction\b|(?:\((?:[^()]|\([^()]*\))*\)|(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)\s*=>))/,
      alias: "function"
    },
    parameter: [
      {
        pattern: /(function(?:\s+(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)?\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\))/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$a-z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*=>)/i,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*=>)/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /((?:\b|\s|^)(?!(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)(?![$\w\xA0-\uFFFF]))(?:(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*\s*)\(\s*|\]\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*\{)/,
        lookbehind: !0,
        inside: t.languages.javascript
      }
    ],
    constant: /\b[A-Z](?:[A-Z_]|\dx?)*\b/
  }), t.languages.insertBefore("javascript", "string", {
    hashbang: {
      pattern: /^#!.*/,
      greedy: !0,
      alias: "comment"
    },
    "template-string": {
      pattern: /`(?:\\[\s\S]|\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}|(?!\$\{)[^\\`])*`/,
      greedy: !0,
      inside: {
        "template-punctuation": {
          pattern: /^`|`$/,
          alias: "string"
        },
        interpolation: {
          pattern: /((?:^|[^\\])(?:\\{2})*)\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}/,
          lookbehind: !0,
          inside: {
            "interpolation-punctuation": {
              pattern: /^\$\{|\}$/,
              alias: "punctuation"
            },
            rest: t.languages.javascript
          }
        },
        string: /[\s\S]+/
      }
    },
    "string-property": {
      pattern: /((?:^|[,{])[ \t]*)(["'])(?:\\(?:\r\n|[\s\S])|(?!\2)[^\\\r\n])*\2(?=\s*:)/m,
      lookbehind: !0,
      greedy: !0,
      alias: "property"
    }
  }), t.languages.insertBefore("javascript", "operator", {
    "literal-property": {
      pattern: /((?:^|[,{])[ \t]*)(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*:)/m,
      lookbehind: !0,
      alias: "property"
    }
  }), t.languages.markup && (t.languages.markup.tag.addInlined("script", "javascript"), t.languages.markup.tag.addAttribute(
    /on(?:abort|blur|change|click|composition(?:end|start|update)|dblclick|error|focus(?:in|out)?|key(?:down|up)|load|mouse(?:down|enter|leave|move|out|over|up)|reset|resize|scroll|select|slotchange|submit|unload|wheel)/.source,
    "javascript"
  )), t.languages.js = t.languages.javascript, function() {
    if (typeof t > "u" || typeof document > "u")
      return;
    Element.prototype.matches || (Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector);
    var n = "Loading…", a = function(b, w) {
      return "✖ Error " + b + " while fetching file: " + w;
    }, o = "✖ Error: File does not exist or is empty", l = {
      js: "javascript",
      py: "python",
      rb: "ruby",
      ps1: "powershell",
      psm1: "powershell",
      sh: "bash",
      bat: "batch",
      h: "c",
      tex: "latex"
    }, r = "data-src-status", s = "loading", u = "loaded", c = "failed", h = "pre[data-src]:not([" + r + '="' + u + '"]):not([' + r + '="' + s + '"])';
    function d(b, w, k) {
      var m = new XMLHttpRequest();
      m.open("GET", b, !0), m.onreadystatechange = function() {
        m.readyState == 4 && (m.status < 400 && m.responseText ? w(m.responseText) : m.status >= 400 ? k(a(m.status, m.statusText)) : k(o));
      }, m.send(null);
    }
    function f(b) {
      var w = /^\s*(\d+)\s*(?:(,)\s*(?:(\d+)\s*)?)?$/.exec(b || "");
      if (w) {
        var k = Number(w[1]), m = w[2], _ = w[3];
        return m ? _ ? [k, Number(_)] : [k, void 0] : [k, k];
      }
    }
    t.hooks.add("before-highlightall", function(b) {
      b.selector += ", " + h;
    }), t.hooks.add("before-sanity-check", function(b) {
      var w = (
        /** @type {HTMLPreElement} */
        b.element
      );
      if (w.matches(h)) {
        b.code = "", w.setAttribute(r, s);
        var k = w.appendChild(document.createElement("CODE"));
        k.textContent = n;
        var m = w.getAttribute("data-src"), _ = b.language;
        if (_ === "none") {
          var g = (/\.(\w+)$/.exec(m) || [, "none"])[1];
          _ = l[g] || g;
        }
        t.util.setLanguage(k, _), t.util.setLanguage(w, _);
        var y = t.plugins.autoloader;
        y && y.loadLanguages(_), d(
          m,
          function(F) {
            w.setAttribute(r, u);
            var C = f(w.getAttribute("data-range"));
            if (C) {
              var T = F.split(/\r\n?|\n/g), S = C[0], z = C[1] == null ? T.length : C[1];
              S < 0 && (S += T.length), S = Math.max(0, Math.min(S - 1, T.length)), z < 0 && (z += T.length), z = Math.max(0, Math.min(z, T.length)), F = T.slice(S, z).join(`
`), w.hasAttribute("data-start") || w.setAttribute("data-start", String(S + 1));
            }
            k.textContent = F, t.highlightElement(k);
          },
          function(F) {
            w.setAttribute(r, c), k.textContent = F;
          }
        );
      }
    }), t.plugins.fileHighlight = {
      /**
       * Executes the File Highlight plugin for all matching `pre` elements under the given container.
       *
       * Note: Elements which are already loaded or currently loading will not be touched by this method.
       *
       * @param {ParentNode} [container=document]
       */
      highlight: function(w) {
        for (var k = (w || document).querySelectorAll(h), m = 0, _; _ = k[m++]; )
          t.highlightElement(_);
      }
    };
    var v = !1;
    t.fileHighlight = function() {
      v || (console.warn("Prism.fileHighlight is deprecated. Use `Prism.plugins.fileHighlight.highlight` instead."), v = !0), t.plugins.fileHighlight.highlight.apply(this, arguments);
    };
  }();
})(er);
Prism.languages.python = {
  comment: {
    pattern: /(^|[^\\])#.*/,
    lookbehind: !0,
    greedy: !0
  },
  "string-interpolation": {
    pattern: /(?:f|fr|rf)(?:("""|''')[\s\S]*?\1|("|')(?:\\.|(?!\2)[^\\\r\n])*\2)/i,
    greedy: !0,
    inside: {
      interpolation: {
        // "{" <expression> <optional "!s", "!r", or "!a"> <optional ":" format specifier> "}"
        pattern: /((?:^|[^{])(?:\{\{)*)\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}])+\})+\})+\}/,
        lookbehind: !0,
        inside: {
          "format-spec": {
            pattern: /(:)[^:(){}]+(?=\}$)/,
            lookbehind: !0
          },
          "conversion-option": {
            pattern: /![sra](?=[:}]$)/,
            alias: "punctuation"
          },
          rest: null
        }
      },
      string: /[\s\S]+/
    }
  },
  "triple-quoted-string": {
    pattern: /(?:[rub]|br|rb)?("""|''')[\s\S]*?\1/i,
    greedy: !0,
    alias: "string"
  },
  string: {
    pattern: /(?:[rub]|br|rb)?("|')(?:\\.|(?!\1)[^\\\r\n])*\1/i,
    greedy: !0
  },
  function: {
    pattern: /((?:^|\s)def[ \t]+)[a-zA-Z_]\w*(?=\s*\()/g,
    lookbehind: !0
  },
  "class-name": {
    pattern: /(\bclass\s+)\w+/i,
    lookbehind: !0
  },
  decorator: {
    pattern: /(^[\t ]*)@\w+(?:\.\w+)*/m,
    lookbehind: !0,
    alias: ["annotation", "punctuation"],
    inside: {
      punctuation: /\./
    }
  },
  keyword: /\b(?:_(?=\s*:)|and|as|assert|async|await|break|case|class|continue|def|del|elif|else|except|exec|finally|for|from|global|if|import|in|is|lambda|match|nonlocal|not|or|pass|print|raise|return|try|while|with|yield)\b/,
  builtin: /\b(?:__import__|abs|all|any|apply|ascii|basestring|bin|bool|buffer|bytearray|bytes|callable|chr|classmethod|cmp|coerce|compile|complex|delattr|dict|dir|divmod|enumerate|eval|execfile|file|filter|float|format|frozenset|getattr|globals|hasattr|hash|help|hex|id|input|int|intern|isinstance|issubclass|iter|len|list|locals|long|map|max|memoryview|min|next|object|oct|open|ord|pow|property|range|raw_input|reduce|reload|repr|reversed|round|set|setattr|slice|sorted|staticmethod|str|sum|super|tuple|type|unichr|unicode|vars|xrange|zip)\b/,
  boolean: /\b(?:False|None|True)\b/,
  number: /\b0(?:b(?:_?[01])+|o(?:_?[0-7])+|x(?:_?[a-f0-9])+)\b|(?:\b\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\B\.\d+(?:_\d+)*)(?:e[+-]?\d+(?:_\d+)*)?j?(?!\w)/i,
  operator: /[-+%=]=?|!=|:=|\*\*?=?|\/\/?=?|<[<=>]?|>[=>]?|[&|^~]/,
  punctuation: /[{}[\];(),.:]/
};
Prism.languages.python["string-interpolation"].inside.interpolation.inside.rest = Prism.languages.python;
Prism.languages.py = Prism.languages.python;
(function(i) {
  var e = /\\(?:[^a-z()[\]]|[a-z*]+)/i, t = {
    "equation-command": {
      pattern: e,
      alias: "regex"
    }
  };
  i.languages.latex = {
    comment: /%.*/,
    // the verbatim environment prints whitespace to the document
    cdata: {
      pattern: /(\\begin\{((?:lstlisting|verbatim)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
      lookbehind: !0
    },
    /*
     * equations can be between $$ $$ or $ $ or \( \) or \[ \]
     * (all are multiline)
     */
    equation: [
      {
        pattern: /\$\$(?:\\[\s\S]|[^\\$])+\$\$|\$(?:\\[\s\S]|[^\\$])+\$|\\\([\s\S]*?\\\)|\\\[[\s\S]*?\\\]/,
        inside: t,
        alias: "string"
      },
      {
        pattern: /(\\begin\{((?:align|eqnarray|equation|gather|math|multline)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
        lookbehind: !0,
        inside: t,
        alias: "string"
      }
    ],
    /*
     * arguments which are keywords or references are highlighted
     * as keywords
     */
    keyword: {
      pattern: /(\\(?:begin|cite|documentclass|end|label|ref|usepackage)(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    url: {
      pattern: /(\\url\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    /*
     * section or chapter headlines are highlighted as bold so that
     * they stand out more
     */
    headline: {
      pattern: /(\\(?:chapter|frametitle|paragraph|part|section|subparagraph|subsection|subsubparagraph|subsubsection|subsubsubparagraph)\*?(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0,
      alias: "class-name"
    },
    function: {
      pattern: e,
      alias: "selector"
    },
    punctuation: /[[\]{}&]/
  }, i.languages.tex = i.languages.latex, i.languages.context = i.languages.latex;
})(Prism);
(function(i) {
  var e = "\\b(?:BASH|BASHOPTS|BASH_ALIASES|BASH_ARGC|BASH_ARGV|BASH_CMDS|BASH_COMPLETION_COMPAT_DIR|BASH_LINENO|BASH_REMATCH|BASH_SOURCE|BASH_VERSINFO|BASH_VERSION|COLORTERM|COLUMNS|COMP_WORDBREAKS|DBUS_SESSION_BUS_ADDRESS|DEFAULTS_PATH|DESKTOP_SESSION|DIRSTACK|DISPLAY|EUID|GDMSESSION|GDM_LANG|GNOME_KEYRING_CONTROL|GNOME_KEYRING_PID|GPG_AGENT_INFO|GROUPS|HISTCONTROL|HISTFILE|HISTFILESIZE|HISTSIZE|HOME|HOSTNAME|HOSTTYPE|IFS|INSTANCE|JOB|LANG|LANGUAGE|LC_ADDRESS|LC_ALL|LC_IDENTIFICATION|LC_MEASUREMENT|LC_MONETARY|LC_NAME|LC_NUMERIC|LC_PAPER|LC_TELEPHONE|LC_TIME|LESSCLOSE|LESSOPEN|LINES|LOGNAME|LS_COLORS|MACHTYPE|MAILCHECK|MANDATORY_PATH|NO_AT_BRIDGE|OLDPWD|OPTERR|OPTIND|ORBIT_SOCKETDIR|OSTYPE|PAPERSIZE|PATH|PIPESTATUS|PPID|PS1|PS2|PS3|PS4|PWD|RANDOM|REPLY|SECONDS|SELINUX_INIT|SESSION|SESSIONTYPE|SESSION_MANAGER|SHELL|SHELLOPTS|SHLVL|SSH_AUTH_SOCK|TERM|UID|UPSTART_EVENTS|UPSTART_INSTANCE|UPSTART_JOB|UPSTART_SESSION|USER|WINDOWID|XAUTHORITY|XDG_CONFIG_DIRS|XDG_CURRENT_DESKTOP|XDG_DATA_DIRS|XDG_GREETER_DATA_DIR|XDG_MENU_PREFIX|XDG_RUNTIME_DIR|XDG_SEAT|XDG_SEAT_PATH|XDG_SESSION_DESKTOP|XDG_SESSION_ID|XDG_SESSION_PATH|XDG_SESSION_TYPE|XDG_VTNR|XMODIFIERS)\\b", t = {
    pattern: /(^(["']?)\w+\2)[ \t]+\S.*/,
    lookbehind: !0,
    alias: "punctuation",
    // this looks reasonably well in all themes
    inside: null
    // see below
  }, n = {
    bash: t,
    environment: {
      pattern: RegExp("\\$" + e),
      alias: "constant"
    },
    variable: [
      // [0]: Arithmetic Environment
      {
        pattern: /\$?\(\([\s\S]+?\)\)/,
        greedy: !0,
        inside: {
          // If there is a $ sign at the beginning highlight $(( and )) as variable
          variable: [
            {
              pattern: /(^\$\(\([\s\S]+)\)\)/,
              lookbehind: !0
            },
            /^\$\(\(/
          ],
          number: /\b0x[\dA-Fa-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:[Ee]-?\d+)?/,
          // Operators according to https://www.gnu.org/software/bash/manual/bashref.html#Shell-Arithmetic
          operator: /--|\+\+|\*\*=?|<<=?|>>=?|&&|\|\||[=!+\-*/%<>^&|]=?|[?~:]/,
          // If there is no $ sign at the beginning highlight (( and )) as punctuation
          punctuation: /\(\(?|\)\)?|,|;/
        }
      },
      // [1]: Command Substitution
      {
        pattern: /\$\((?:\([^)]+\)|[^()])+\)|`[^`]+`/,
        greedy: !0,
        inside: {
          variable: /^\$\(|^`|\)$|`$/
        }
      },
      // [2]: Brace expansion
      {
        pattern: /\$\{[^}]+\}/,
        greedy: !0,
        inside: {
          operator: /:[-=?+]?|[!\/]|##?|%%?|\^\^?|,,?/,
          punctuation: /[\[\]]/,
          environment: {
            pattern: RegExp("(\\{)" + e),
            lookbehind: !0,
            alias: "constant"
          }
        }
      },
      /\$(?:\w+|[#?*!@$])/
    ],
    // Escape sequences from echo and printf's manuals, and escaped quotes.
    entity: /\\(?:[abceEfnrtv\\"]|O?[0-7]{1,3}|U[0-9a-fA-F]{8}|u[0-9a-fA-F]{4}|x[0-9a-fA-F]{1,2})/
  };
  i.languages.bash = {
    shebang: {
      pattern: /^#!\s*\/.*/,
      alias: "important"
    },
    comment: {
      pattern: /(^|[^"{\\$])#.*/,
      lookbehind: !0
    },
    "function-name": [
      // a) function foo {
      // b) foo() {
      // c) function foo() {
      // but not “foo {”
      {
        // a) and c)
        pattern: /(\bfunction\s+)[\w-]+(?=(?:\s*\(?:\s*\))?\s*\{)/,
        lookbehind: !0,
        alias: "function"
      },
      {
        // b)
        pattern: /\b[\w-]+(?=\s*\(\s*\)\s*\{)/,
        alias: "function"
      }
    ],
    // Highlight variable names as variables in for and select beginnings.
    "for-or-select": {
      pattern: /(\b(?:for|select)\s+)\w+(?=\s+in\s)/,
      alias: "variable",
      lookbehind: !0
    },
    // Highlight variable names as variables in the left-hand part
    // of assignments (“=” and “+=”).
    "assign-left": {
      pattern: /(^|[\s;|&]|[<>]\()\w+(?:\.\w+)*(?=\+?=)/,
      inside: {
        environment: {
          pattern: RegExp("(^|[\\s;|&]|[<>]\\()" + e),
          lookbehind: !0,
          alias: "constant"
        }
      },
      alias: "variable",
      lookbehind: !0
    },
    // Highlight parameter names as variables
    parameter: {
      pattern: /(^|\s)-{1,2}(?:\w+:[+-]?)?\w+(?:\.\w+)*(?=[=\s]|$)/,
      alias: "variable",
      lookbehind: !0
    },
    string: [
      // Support for Here-documents https://en.wikipedia.org/wiki/Here_document
      {
        pattern: /((?:^|[^<])<<-?\s*)(\w+)\s[\s\S]*?(?:\r?\n|\r)\2/,
        lookbehind: !0,
        greedy: !0,
        inside: n
      },
      // Here-document with quotes around the tag
      // → No expansion (so no “inside”).
      {
        pattern: /((?:^|[^<])<<-?\s*)(["'])(\w+)\2\s[\s\S]*?(?:\r?\n|\r)\3/,
        lookbehind: !0,
        greedy: !0,
        inside: {
          bash: t
        }
      },
      // “Normal” string
      {
        // https://www.gnu.org/software/bash/manual/html_node/Double-Quotes.html
        pattern: /(^|[^\\](?:\\\\)*)"(?:\\[\s\S]|\$\([^)]+\)|\$(?!\()|`[^`]+`|[^"\\`$])*"/,
        lookbehind: !0,
        greedy: !0,
        inside: n
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/Single-Quotes.html
        pattern: /(^|[^$\\])'[^']*'/,
        lookbehind: !0,
        greedy: !0
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/ANSI_002dC-Quoting.html
        pattern: /\$'(?:[^'\\]|\\[\s\S])*'/,
        greedy: !0,
        inside: {
          entity: n.entity
        }
      }
    ],
    environment: {
      pattern: RegExp("\\$?" + e),
      alias: "constant"
    },
    variable: n.variable,
    function: {
      pattern: /(^|[\s;|&]|[<>]\()(?:add|apropos|apt|apt-cache|apt-get|aptitude|aspell|automysqlbackup|awk|basename|bash|bc|bconsole|bg|bzip2|cal|cargo|cat|cfdisk|chgrp|chkconfig|chmod|chown|chroot|cksum|clear|cmp|column|comm|composer|cp|cron|crontab|csplit|curl|cut|date|dc|dd|ddrescue|debootstrap|df|diff|diff3|dig|dir|dircolors|dirname|dirs|dmesg|docker|docker-compose|du|egrep|eject|env|ethtool|expand|expect|expr|fdformat|fdisk|fg|fgrep|file|find|fmt|fold|format|free|fsck|ftp|fuser|gawk|git|gparted|grep|groupadd|groupdel|groupmod|groups|grub-mkconfig|gzip|halt|head|hg|history|host|hostname|htop|iconv|id|ifconfig|ifdown|ifup|import|install|ip|java|jobs|join|kill|killall|less|link|ln|locate|logname|logrotate|look|lpc|lpr|lprint|lprintd|lprintq|lprm|ls|lsof|lynx|make|man|mc|mdadm|mkconfig|mkdir|mke2fs|mkfifo|mkfs|mkisofs|mknod|mkswap|mmv|more|most|mount|mtools|mtr|mutt|mv|nano|nc|netstat|nice|nl|node|nohup|notify-send|npm|nslookup|op|open|parted|passwd|paste|pathchk|ping|pkill|pnpm|podman|podman-compose|popd|pr|printcap|printenv|ps|pushd|pv|quota|quotacheck|quotactl|ram|rar|rcp|reboot|remsync|rename|renice|rev|rm|rmdir|rpm|rsync|scp|screen|sdiff|sed|sendmail|seq|service|sftp|sh|shellcheck|shuf|shutdown|sleep|slocate|sort|split|ssh|stat|strace|su|sudo|sum|suspend|swapon|sync|sysctl|tac|tail|tar|tee|time|timeout|top|touch|tr|traceroute|tsort|tty|umount|uname|unexpand|uniq|units|unrar|unshar|unzip|update-grub|uptime|useradd|userdel|usermod|users|uudecode|uuencode|v|vcpkg|vdir|vi|vim|virsh|vmstat|wait|watch|wc|wget|whereis|which|who|whoami|write|xargs|xdg-open|yarn|yes|zenity|zip|zsh|zypper)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    keyword: {
      pattern: /(^|[\s;|&]|[<>]\()(?:case|do|done|elif|else|esac|fi|for|function|if|in|select|then|until|while)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    // https://www.gnu.org/software/bash/manual/html_node/Shell-Builtin-Commands.html
    builtin: {
      pattern: /(^|[\s;|&]|[<>]\()(?:\.|:|alias|bind|break|builtin|caller|cd|command|continue|declare|echo|enable|eval|exec|exit|export|getopts|hash|help|let|local|logout|mapfile|printf|pwd|read|readarray|readonly|return|set|shift|shopt|source|test|times|trap|type|typeset|ulimit|umask|unalias|unset)(?=$|[)\s;|&])/,
      lookbehind: !0,
      // Alias added to make those easier to distinguish from strings.
      alias: "class-name"
    },
    boolean: {
      pattern: /(^|[\s;|&]|[<>]\()(?:false|true)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    "file-descriptor": {
      pattern: /\B&\d\b/,
      alias: "important"
    },
    operator: {
      // Lots of redirections here, but not just that.
      pattern: /\d?<>|>\||\+=|=[=~]?|!=?|<<[<-]?|[&\d]?>>|\d[<>]&?|[<>][&=]?|&[>&]?|\|[&|]?/,
      inside: {
        "file-descriptor": {
          pattern: /^\d/,
          alias: "important"
        }
      }
    },
    punctuation: /\$?\(\(?|\)\)?|\.\.|[{}[\];\\]/,
    number: {
      pattern: /(^|\s)(?:[1-9]\d*|0)(?:[.,]\d+)?\b/,
      lookbehind: !0
    }
  }, t.inside = i.languages.bash;
  for (var a = [
    "comment",
    "function-name",
    "for-or-select",
    "assign-left",
    "parameter",
    "string",
    "environment",
    "function",
    "keyword",
    "builtin",
    "boolean",
    "file-descriptor",
    "operator",
    "punctuation",
    "number"
  ], o = n.variable[1].inside, l = 0; l < a.length; l++)
    o[a[l]] = i.languages.bash[a[l]];
  i.languages.sh = i.languages.bash, i.languages.shell = i.languages.bash;
})(Prism);
new hl();
const tr = (i) => {
  const e = {};
  for (let t = 0, n = i.length; t < n; t++) {
    const a = i[t];
    for (const o in a)
      e[o] ? e[o] = e[o].concat(a[o]) : e[o] = a[o];
  }
  return e;
}, nr = [
  "abbr",
  "accept",
  "accept-charset",
  "accesskey",
  "action",
  "align",
  "alink",
  "allow",
  "allowfullscreen",
  "alt",
  "anchor",
  "archive",
  "as",
  "async",
  "autocapitalize",
  "autocomplete",
  "autocorrect",
  "autofocus",
  "autopictureinpicture",
  "autoplay",
  "axis",
  "background",
  "behavior",
  "bgcolor",
  "border",
  "bordercolor",
  "capture",
  "cellpadding",
  "cellspacing",
  "challenge",
  "char",
  "charoff",
  "charset",
  "checked",
  "cite",
  "class",
  "classid",
  "clear",
  "code",
  "codebase",
  "codetype",
  "color",
  "cols",
  "colspan",
  "compact",
  "content",
  "contenteditable",
  "controls",
  "controlslist",
  "conversiondestination",
  "coords",
  "crossorigin",
  "csp",
  "data",
  "datetime",
  "declare",
  "decoding",
  "default",
  "defer",
  "dir",
  "direction",
  "dirname",
  "disabled",
  "disablepictureinpicture",
  "disableremoteplayback",
  "disallowdocumentaccess",
  "download",
  "draggable",
  "elementtiming",
  "enctype",
  "end",
  "enterkeyhint",
  "event",
  "exportparts",
  "face",
  "for",
  "form",
  "formaction",
  "formenctype",
  "formmethod",
  "formnovalidate",
  "formtarget",
  "frame",
  "frameborder",
  "headers",
  "height",
  "hidden",
  "high",
  "href",
  "hreflang",
  "hreftranslate",
  "hspace",
  "http-equiv",
  "id",
  "imagesizes",
  "imagesrcset",
  "importance",
  "impressiondata",
  "impressionexpiry",
  "incremental",
  "inert",
  "inputmode",
  "integrity",
  "invisible",
  "ismap",
  "keytype",
  "kind",
  "label",
  "lang",
  "language",
  "latencyhint",
  "leftmargin",
  "link",
  "list",
  "loading",
  "longdesc",
  "loop",
  "low",
  "lowsrc",
  "manifest",
  "marginheight",
  "marginwidth",
  "max",
  "maxlength",
  "mayscript",
  "media",
  "method",
  "min",
  "minlength",
  "multiple",
  "muted",
  "name",
  "nohref",
  "nomodule",
  "nonce",
  "noresize",
  "noshade",
  "novalidate",
  "nowrap",
  "object",
  "open",
  "optimum",
  "part",
  "pattern",
  "ping",
  "placeholder",
  "playsinline",
  "policy",
  "poster",
  "preload",
  "pseudo",
  "readonly",
  "referrerpolicy",
  "rel",
  "reportingorigin",
  "required",
  "resources",
  "rev",
  "reversed",
  "role",
  "rows",
  "rowspan",
  "rules",
  "sandbox",
  "scheme",
  "scope",
  "scopes",
  "scrollamount",
  "scrolldelay",
  "scrolling",
  "select",
  "selected",
  "shadowroot",
  "shadowrootdelegatesfocus",
  "shape",
  "size",
  "sizes",
  "slot",
  "span",
  "spellcheck",
  "src",
  "srclang",
  "srcset",
  "standby",
  "start",
  "step",
  "style",
  "summary",
  "tabindex",
  "target",
  "text",
  "title",
  "topmargin",
  "translate",
  "truespeed",
  "trusttoken",
  "type",
  "usemap",
  "valign",
  "value",
  "valuetype",
  "version",
  "virtualkeyboardpolicy",
  "vlink",
  "vspace",
  "webkitdirectory",
  "width",
  "wrap"
], ir = [
  "accent-height",
  "accumulate",
  "additive",
  "alignment-baseline",
  "ascent",
  "attributename",
  "attributetype",
  "azimuth",
  "basefrequency",
  "baseline-shift",
  "begin",
  "bias",
  "by",
  "class",
  "clip",
  "clippathunits",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "cx",
  "cy",
  "d",
  "dx",
  "dy",
  "diffuseconstant",
  "direction",
  "display",
  "divisor",
  "dominant-baseline",
  "dur",
  "edgemode",
  "elevation",
  "end",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "filterunits",
  "flood-color",
  "flood-opacity",
  "font-family",
  "font-size",
  "font-size-adjust",
  "font-stretch",
  "font-style",
  "font-variant",
  "font-weight",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyph-name",
  "glyphref",
  "gradientunits",
  "gradienttransform",
  "height",
  "href",
  "id",
  "image-rendering",
  "in",
  "in2",
  "k",
  "k1",
  "k2",
  "k3",
  "k4",
  "kerning",
  "keypoints",
  "keysplines",
  "keytimes",
  "lang",
  "lengthadjust",
  "letter-spacing",
  "kernelmatrix",
  "kernelunitlength",
  "lighting-color",
  "local",
  "marker-end",
  "marker-mid",
  "marker-start",
  "markerheight",
  "markerunits",
  "markerwidth",
  "maskcontentunits",
  "maskunits",
  "max",
  "mask",
  "media",
  "method",
  "mode",
  "min",
  "name",
  "numoctaves",
  "offset",
  "operator",
  "opacity",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "paint-order",
  "path",
  "pathlength",
  "patterncontentunits",
  "patterntransform",
  "patternunits",
  "points",
  "preservealpha",
  "preserveaspectratio",
  "primitiveunits",
  "r",
  "rx",
  "ry",
  "radius",
  "refx",
  "refy",
  "repeatcount",
  "repeatdur",
  "restart",
  "result",
  "rotate",
  "scale",
  "seed",
  "shape-rendering",
  "specularconstant",
  "specularexponent",
  "spreadmethod",
  "startoffset",
  "stddeviation",
  "stitchtiles",
  "stop-color",
  "stop-opacity",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke",
  "stroke-width",
  "style",
  "surfacescale",
  "systemlanguage",
  "tabindex",
  "targetx",
  "targety",
  "transform",
  "transform-origin",
  "text-anchor",
  "text-decoration",
  "text-rendering",
  "textlength",
  "type",
  "u1",
  "u2",
  "unicode",
  "values",
  "viewbox",
  "visibility",
  "version",
  "vert-adv-y",
  "vert-origin-x",
  "vert-origin-y",
  "width",
  "word-spacing",
  "wrap",
  "writing-mode",
  "xchannelselector",
  "ychannelselector",
  "x",
  "x1",
  "x2",
  "xmlns",
  "y",
  "y1",
  "y2",
  "z",
  "zoomandpan"
], ar = [
  "accent",
  "accentunder",
  "align",
  "bevelled",
  "close",
  "columnsalign",
  "columnlines",
  "columnspan",
  "denomalign",
  "depth",
  "dir",
  "display",
  "displaystyle",
  "encoding",
  "fence",
  "frame",
  "height",
  "href",
  "id",
  "largeop",
  "length",
  "linethickness",
  "lspace",
  "lquote",
  "mathbackground",
  "mathcolor",
  "mathsize",
  "mathvariant",
  "maxsize",
  "minsize",
  "movablelimits",
  "notation",
  "numalign",
  "open",
  "rowalign",
  "rowlines",
  "rowspacing",
  "rowspan",
  "rspace",
  "rquote",
  "scriptlevel",
  "scriptminsize",
  "scriptsizemultiplier",
  "selection",
  "separator",
  "separators",
  "stretchy",
  "subscriptshift",
  "supscriptshift",
  "symmetric",
  "voffset",
  "width",
  "xmlns"
];
tr([
  Object.fromEntries(nr.map((i) => [i, ["*"]])),
  Object.fromEntries(ir.map((i) => [i, ["svg:*"]])),
  Object.fromEntries(ar.map((i) => [i, ["math:*"]]))
]);
const {
  HtmlTagHydration: iu,
  SvelteComponent: au,
  attr: lu,
  binding_callbacks: ou,
  children: ru,
  claim_element: su,
  claim_html_tag: uu,
  detach: cu,
  element: _u,
  init: du,
  insert_hydration: fu,
  noop: pu,
  safe_not_equal: hu,
  toggle_class: mu
} = window.__gradio__svelte__internal, { afterUpdate: gu, tick: vu, onMount: Du } = window.__gradio__svelte__internal, {
  SvelteComponent: bu,
  attr: yu,
  children: wu,
  claim_component: Fu,
  claim_element: ku,
  create_component: $u,
  destroy_component: Eu,
  detach: Au,
  element: Cu,
  init: Su,
  insert_hydration: Tu,
  mount_component: Bu,
  safe_not_equal: Ru,
  transition_in: Iu,
  transition_out: Lu
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ou,
  attr: qu,
  check_outros: Nu,
  children: zu,
  claim_component: Mu,
  claim_element: Pu,
  claim_space: xu,
  create_component: Uu,
  create_slot: Hu,
  destroy_component: ju,
  detach: Gu,
  element: Vu,
  empty: Wu,
  get_all_dirty_from_scope: Zu,
  get_slot_changes: Yu,
  group_outros: Xu,
  init: Ku,
  insert_hydration: Qu,
  mount_component: Ju,
  safe_not_equal: ec,
  space: tc,
  toggle_class: nc,
  transition_in: ic,
  transition_out: ac,
  update_slot_base: lc
} = window.__gradio__svelte__internal, {
  SvelteComponent: oc,
  append_hydration: rc,
  attr: sc,
  children: uc,
  claim_component: cc,
  claim_element: _c,
  claim_space: dc,
  claim_text: fc,
  create_component: pc,
  destroy_component: hc,
  detach: mc,
  element: gc,
  init: vc,
  insert_hydration: Dc,
  mount_component: bc,
  safe_not_equal: yc,
  set_data: wc,
  space: Fc,
  text: kc,
  toggle_class: $c,
  transition_in: Ec,
  transition_out: Ac
} = window.__gradio__svelte__internal, {
  SvelteComponent: lr,
  append_hydration: $n,
  attr: mt,
  bubble: or,
  check_outros: rr,
  children: ni,
  claim_component: sr,
  claim_element: ii,
  claim_space: Hi,
  claim_text: ur,
  construct_svelte_component: ji,
  create_component: Gi,
  create_slot: cr,
  destroy_component: Vi,
  detach: ln,
  element: ai,
  get_all_dirty_from_scope: _r,
  get_slot_changes: dr,
  group_outros: fr,
  init: pr,
  insert_hydration: ml,
  listen: hr,
  mount_component: Wi,
  safe_not_equal: mr,
  set_data: gr,
  set_style: gn,
  space: Zi,
  text: vr,
  toggle_class: ye,
  transition_in: xn,
  transition_out: Un,
  update_slot_base: Dr
} = window.__gradio__svelte__internal;
function Yi(i) {
  let e, t;
  return {
    c() {
      e = ai("span"), t = vr(
        /*label*/
        i[1]
      ), this.h();
    },
    l(n) {
      e = ii(n, "SPAN", { class: !0 });
      var a = ni(e);
      t = ur(
        a,
        /*label*/
        i[1]
      ), a.forEach(ln), this.h();
    },
    h() {
      mt(e, "class", "svelte-qgco6m");
    },
    m(n, a) {
      ml(n, e, a), $n(e, t);
    },
    p(n, a) {
      a & /*label*/
      2 && gr(
        t,
        /*label*/
        n[1]
      );
    },
    d(n) {
      n && ln(e);
    }
  };
}
function br(i) {
  let e, t, n, a, o, l, r, s, u = (
    /*show_label*/
    i[2] && Yi(i)
  );
  var c = (
    /*Icon*/
    i[0]
  );
  function h(v, b) {
    return {};
  }
  c && (a = ji(c, h()));
  const d = (
    /*#slots*/
    i[14].default
  ), f = cr(
    d,
    i,
    /*$$scope*/
    i[13],
    null
  );
  return {
    c() {
      e = ai("button"), u && u.c(), t = Zi(), n = ai("div"), a && Gi(a.$$.fragment), o = Zi(), f && f.c(), this.h();
    },
    l(v) {
      e = ii(v, "BUTTON", {
        "aria-label": !0,
        "aria-haspopup": !0,
        title: !0,
        class: !0
      });
      var b = ni(e);
      u && u.l(b), t = Hi(b), n = ii(b, "DIV", { class: !0 });
      var w = ni(n);
      a && sr(a.$$.fragment, w), o = Hi(w), f && f.l(w), w.forEach(ln), b.forEach(ln), this.h();
    },
    h() {
      mt(n, "class", "svelte-qgco6m"), ye(
        n,
        "x-small",
        /*size*/
        i[4] === "x-small"
      ), ye(
        n,
        "small",
        /*size*/
        i[4] === "small"
      ), ye(
        n,
        "large",
        /*size*/
        i[4] === "large"
      ), ye(
        n,
        "medium",
        /*size*/
        i[4] === "medium"
      ), e.disabled = /*disabled*/
      i[7], mt(
        e,
        "aria-label",
        /*label*/
        i[1]
      ), mt(
        e,
        "aria-haspopup",
        /*hasPopup*/
        i[8]
      ), mt(
        e,
        "title",
        /*label*/
        i[1]
      ), mt(e, "class", "svelte-qgco6m"), ye(
        e,
        "pending",
        /*pending*/
        i[3]
      ), ye(
        e,
        "padded",
        /*padded*/
        i[5]
      ), ye(
        e,
        "highlight",
        /*highlight*/
        i[6]
      ), ye(
        e,
        "transparent",
        /*transparent*/
        i[9]
      ), gn(e, "color", !/*disabled*/
      i[7] && /*_color*/
      i[11] ? (
        /*_color*/
        i[11]
      ) : "var(--block-label-text-color)"), gn(e, "--bg-color", /*disabled*/
      i[7] ? "auto" : (
        /*background*/
        i[10]
      ));
    },
    m(v, b) {
      ml(v, e, b), u && u.m(e, null), $n(e, t), $n(e, n), a && Wi(a, n, null), $n(n, o), f && f.m(n, null), l = !0, r || (s = hr(
        e,
        "click",
        /*click_handler*/
        i[15]
      ), r = !0);
    },
    p(v, [b]) {
      if (/*show_label*/
      v[2] ? u ? u.p(v, b) : (u = Yi(v), u.c(), u.m(e, t)) : u && (u.d(1), u = null), b & /*Icon*/
      1 && c !== (c = /*Icon*/
      v[0])) {
        if (a) {
          fr();
          const w = a;
          Un(w.$$.fragment, 1, 0, () => {
            Vi(w, 1);
          }), rr();
        }
        c ? (a = ji(c, h()), Gi(a.$$.fragment), xn(a.$$.fragment, 1), Wi(a, n, o)) : a = null;
      }
      f && f.p && (!l || b & /*$$scope*/
      8192) && Dr(
        f,
        d,
        v,
        /*$$scope*/
        v[13],
        l ? dr(
          d,
          /*$$scope*/
          v[13],
          b,
          null
        ) : _r(
          /*$$scope*/
          v[13]
        ),
        null
      ), (!l || b & /*size*/
      16) && ye(
        n,
        "x-small",
        /*size*/
        v[4] === "x-small"
      ), (!l || b & /*size*/
      16) && ye(
        n,
        "small",
        /*size*/
        v[4] === "small"
      ), (!l || b & /*size*/
      16) && ye(
        n,
        "large",
        /*size*/
        v[4] === "large"
      ), (!l || b & /*size*/
      16) && ye(
        n,
        "medium",
        /*size*/
        v[4] === "medium"
      ), (!l || b & /*disabled*/
      128) && (e.disabled = /*disabled*/
      v[7]), (!l || b & /*label*/
      2) && mt(
        e,
        "aria-label",
        /*label*/
        v[1]
      ), (!l || b & /*hasPopup*/
      256) && mt(
        e,
        "aria-haspopup",
        /*hasPopup*/
        v[8]
      ), (!l || b & /*label*/
      2) && mt(
        e,
        "title",
        /*label*/
        v[1]
      ), (!l || b & /*pending*/
      8) && ye(
        e,
        "pending",
        /*pending*/
        v[3]
      ), (!l || b & /*padded*/
      32) && ye(
        e,
        "padded",
        /*padded*/
        v[5]
      ), (!l || b & /*highlight*/
      64) && ye(
        e,
        "highlight",
        /*highlight*/
        v[6]
      ), (!l || b & /*transparent*/
      512) && ye(
        e,
        "transparent",
        /*transparent*/
        v[9]
      ), b & /*disabled, _color*/
      2176 && gn(e, "color", !/*disabled*/
      v[7] && /*_color*/
      v[11] ? (
        /*_color*/
        v[11]
      ) : "var(--block-label-text-color)"), b & /*disabled, background*/
      1152 && gn(e, "--bg-color", /*disabled*/
      v[7] ? "auto" : (
        /*background*/
        v[10]
      ));
    },
    i(v) {
      l || (a && xn(a.$$.fragment, v), xn(f, v), l = !0);
    },
    o(v) {
      a && Un(a.$$.fragment, v), Un(f, v), l = !1;
    },
    d(v) {
      v && ln(e), u && u.d(), a && Vi(a), f && f.d(v), r = !1, s();
    }
  };
}
function yr(i, e, t) {
  let n, { $$slots: a = {}, $$scope: o } = e, { Icon: l } = e, { label: r = "" } = e, { show_label: s = !1 } = e, { pending: u = !1 } = e, { size: c = "small" } = e, { padded: h = !0 } = e, { highlight: d = !1 } = e, { disabled: f = !1 } = e, { hasPopup: v = !1 } = e, { color: b = "var(--block-label-text-color)" } = e, { transparent: w = !1 } = e, { background: k = "var(--block-background-fill)" } = e;
  function m(_) {
    or.call(this, i, _);
  }
  return i.$$set = (_) => {
    "Icon" in _ && t(0, l = _.Icon), "label" in _ && t(1, r = _.label), "show_label" in _ && t(2, s = _.show_label), "pending" in _ && t(3, u = _.pending), "size" in _ && t(4, c = _.size), "padded" in _ && t(5, h = _.padded), "highlight" in _ && t(6, d = _.highlight), "disabled" in _ && t(7, f = _.disabled), "hasPopup" in _ && t(8, v = _.hasPopup), "color" in _ && t(12, b = _.color), "transparent" in _ && t(9, w = _.transparent), "background" in _ && t(10, k = _.background), "$$scope" in _ && t(13, o = _.$$scope);
  }, i.$$.update = () => {
    i.$$.dirty & /*highlight, color*/
    4160 && t(11, n = d ? "var(--color-accent)" : b);
  }, [
    l,
    r,
    s,
    u,
    c,
    h,
    d,
    f,
    v,
    w,
    k,
    n,
    b,
    o,
    a,
    m
  ];
}
class wr extends lr {
  constructor(e) {
    super(), pr(this, e, yr, br, mr, {
      Icon: 0,
      label: 1,
      show_label: 2,
      pending: 3,
      size: 4,
      padded: 5,
      highlight: 6,
      disabled: 7,
      hasPopup: 8,
      color: 12,
      transparent: 9,
      background: 10
    });
  }
}
const {
  SvelteComponent: Cc,
  append_hydration: Sc,
  attr: Tc,
  binding_callbacks: Bc,
  children: Rc,
  claim_element: Ic,
  create_slot: Lc,
  detach: Oc,
  element: qc,
  get_all_dirty_from_scope: Nc,
  get_slot_changes: zc,
  init: Mc,
  insert_hydration: Pc,
  safe_not_equal: xc,
  toggle_class: Uc,
  transition_in: Hc,
  transition_out: jc,
  update_slot_base: Gc
} = window.__gradio__svelte__internal, {
  SvelteComponent: Vc,
  append_hydration: Wc,
  attr: Zc,
  children: Yc,
  claim_svg_element: Xc,
  detach: Kc,
  init: Qc,
  insert_hydration: Jc,
  noop: e_,
  safe_not_equal: t_,
  svg_element: n_
} = window.__gradio__svelte__internal, {
  SvelteComponent: i_,
  append_hydration: a_,
  attr: l_,
  children: o_,
  claim_svg_element: r_,
  detach: s_,
  init: u_,
  insert_hydration: c_,
  noop: __,
  safe_not_equal: d_,
  svg_element: f_
} = window.__gradio__svelte__internal, {
  SvelteComponent: p_,
  append_hydration: h_,
  attr: m_,
  children: g_,
  claim_svg_element: v_,
  detach: D_,
  init: b_,
  insert_hydration: y_,
  noop: w_,
  safe_not_equal: F_,
  svg_element: k_
} = window.__gradio__svelte__internal, {
  SvelteComponent: $_,
  append_hydration: E_,
  attr: A_,
  children: C_,
  claim_svg_element: S_,
  detach: T_,
  init: B_,
  insert_hydration: R_,
  noop: I_,
  safe_not_equal: L_,
  svg_element: O_
} = window.__gradio__svelte__internal, {
  SvelteComponent: q_,
  append_hydration: N_,
  attr: z_,
  children: M_,
  claim_svg_element: P_,
  detach: x_,
  init: U_,
  insert_hydration: H_,
  noop: j_,
  safe_not_equal: G_,
  svg_element: V_
} = window.__gradio__svelte__internal, {
  SvelteComponent: W_,
  append_hydration: Z_,
  attr: Y_,
  children: X_,
  claim_svg_element: K_,
  detach: Q_,
  init: J_,
  insert_hydration: ed,
  noop: td,
  safe_not_equal: nd,
  svg_element: id
} = window.__gradio__svelte__internal, {
  SvelteComponent: ad,
  append_hydration: ld,
  attr: od,
  children: rd,
  claim_svg_element: sd,
  detach: ud,
  init: cd,
  insert_hydration: _d,
  noop: dd,
  safe_not_equal: fd,
  svg_element: pd
} = window.__gradio__svelte__internal, {
  SvelteComponent: hd,
  append_hydration: md,
  attr: gd,
  children: vd,
  claim_svg_element: Dd,
  detach: bd,
  init: yd,
  insert_hydration: wd,
  noop: Fd,
  safe_not_equal: kd,
  svg_element: $d
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ed,
  append_hydration: Ad,
  attr: Cd,
  children: Sd,
  claim_svg_element: Td,
  detach: Bd,
  init: Rd,
  insert_hydration: Id,
  noop: Ld,
  safe_not_equal: Od,
  svg_element: qd
} = window.__gradio__svelte__internal, {
  SvelteComponent: Nd,
  append_hydration: zd,
  attr: Md,
  children: Pd,
  claim_svg_element: xd,
  detach: Ud,
  init: Hd,
  insert_hydration: jd,
  noop: Gd,
  safe_not_equal: Vd,
  svg_element: Wd
} = window.__gradio__svelte__internal, {
  SvelteComponent: Zd,
  append_hydration: Yd,
  attr: Xd,
  children: Kd,
  claim_svg_element: Qd,
  detach: Jd,
  init: ef,
  insert_hydration: tf,
  noop: nf,
  safe_not_equal: af,
  svg_element: lf
} = window.__gradio__svelte__internal, {
  SvelteComponent: of,
  append_hydration: rf,
  attr: sf,
  children: uf,
  claim_svg_element: cf,
  detach: _f,
  init: df,
  insert_hydration: ff,
  noop: pf,
  safe_not_equal: hf,
  svg_element: mf
} = window.__gradio__svelte__internal, {
  SvelteComponent: Fr,
  append_hydration: Hn,
  attr: je,
  children: vn,
  claim_svg_element: Dn,
  detach: Yt,
  init: kr,
  insert_hydration: $r,
  noop: jn,
  safe_not_equal: Er,
  set_style: tt,
  svg_element: bn
} = window.__gradio__svelte__internal;
function Ar(i) {
  let e, t, n, a;
  return {
    c() {
      e = bn("svg"), t = bn("g"), n = bn("path"), a = bn("path"), this.h();
    },
    l(o) {
      e = Dn(o, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        version: !0,
        xmlns: !0,
        "xmlns:xlink": !0,
        "xml:space": !0,
        stroke: !0,
        style: !0
      });
      var l = vn(e);
      t = Dn(l, "g", { transform: !0 });
      var r = vn(t);
      n = Dn(r, "path", { d: !0, style: !0 }), vn(n).forEach(Yt), r.forEach(Yt), a = Dn(l, "path", { d: !0, style: !0 }), vn(a).forEach(Yt), l.forEach(Yt), this.h();
    },
    h() {
      je(n, "d", "M18,6L6.087,17.913"), tt(n, "fill", "none"), tt(n, "fill-rule", "nonzero"), tt(n, "stroke-width", "2px"), je(t, "transform", "matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"), je(a, "d", "M4.364,4.364L19.636,19.636"), tt(a, "fill", "none"), tt(a, "fill-rule", "nonzero"), tt(a, "stroke-width", "2px"), je(e, "width", "100%"), je(e, "height", "100%"), je(e, "viewBox", "0 0 24 24"), je(e, "version", "1.1"), je(e, "xmlns", "http://www.w3.org/2000/svg"), je(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), je(e, "xml:space", "preserve"), je(e, "stroke", "currentColor"), tt(e, "fill-rule", "evenodd"), tt(e, "clip-rule", "evenodd"), tt(e, "stroke-linecap", "round"), tt(e, "stroke-linejoin", "round");
    },
    m(o, l) {
      $r(o, e, l), Hn(e, t), Hn(t, n), Hn(e, a);
    },
    p: jn,
    i: jn,
    o: jn,
    d(o) {
      o && Yt(e);
    }
  };
}
class Cr extends Fr {
  constructor(e) {
    super(), kr(this, e, null, Ar, Er, {});
  }
}
const {
  SvelteComponent: gf,
  append_hydration: vf,
  attr: Df,
  children: bf,
  claim_svg_element: yf,
  detach: wf,
  init: Ff,
  insert_hydration: kf,
  noop: $f,
  safe_not_equal: Ef,
  svg_element: Af
} = window.__gradio__svelte__internal, {
  SvelteComponent: Cf,
  append_hydration: Sf,
  attr: Tf,
  children: Bf,
  claim_svg_element: Rf,
  detach: If,
  init: Lf,
  insert_hydration: Of,
  noop: qf,
  safe_not_equal: Nf,
  svg_element: zf
} = window.__gradio__svelte__internal, {
  SvelteComponent: Mf,
  append_hydration: Pf,
  attr: xf,
  children: Uf,
  claim_svg_element: Hf,
  detach: jf,
  init: Gf,
  insert_hydration: Vf,
  noop: Wf,
  safe_not_equal: Zf,
  svg_element: Yf
} = window.__gradio__svelte__internal, {
  SvelteComponent: Xf,
  append_hydration: Kf,
  attr: Qf,
  children: Jf,
  claim_svg_element: ep,
  detach: tp,
  init: np,
  insert_hydration: ip,
  noop: ap,
  safe_not_equal: lp,
  svg_element: op
} = window.__gradio__svelte__internal, {
  SvelteComponent: rp,
  append_hydration: sp,
  attr: up,
  children: cp,
  claim_svg_element: _p,
  detach: dp,
  init: fp,
  insert_hydration: pp,
  noop: hp,
  safe_not_equal: mp,
  svg_element: gp
} = window.__gradio__svelte__internal, {
  SvelteComponent: vp,
  append_hydration: Dp,
  attr: bp,
  children: yp,
  claim_svg_element: wp,
  detach: Fp,
  init: kp,
  insert_hydration: $p,
  noop: Ep,
  safe_not_equal: Ap,
  svg_element: Cp
} = window.__gradio__svelte__internal, {
  SvelteComponent: Sp,
  append_hydration: Tp,
  attr: Bp,
  children: Rp,
  claim_svg_element: Ip,
  detach: Lp,
  init: Op,
  insert_hydration: qp,
  noop: Np,
  safe_not_equal: zp,
  svg_element: Mp
} = window.__gradio__svelte__internal, {
  SvelteComponent: Pp,
  append_hydration: xp,
  attr: Up,
  children: Hp,
  claim_svg_element: jp,
  detach: Gp,
  init: Vp,
  insert_hydration: Wp,
  noop: Zp,
  safe_not_equal: Yp,
  svg_element: Xp
} = window.__gradio__svelte__internal, {
  SvelteComponent: Kp,
  append_hydration: Qp,
  attr: Jp,
  children: eh,
  claim_svg_element: th,
  detach: nh,
  init: ih,
  insert_hydration: ah,
  noop: lh,
  safe_not_equal: oh,
  svg_element: rh
} = window.__gradio__svelte__internal, {
  SvelteComponent: sh,
  append_hydration: uh,
  attr: ch,
  children: _h,
  claim_svg_element: dh,
  detach: fh,
  init: ph,
  insert_hydration: hh,
  noop: mh,
  safe_not_equal: gh,
  svg_element: vh
} = window.__gradio__svelte__internal, {
  SvelteComponent: Dh,
  append_hydration: bh,
  attr: yh,
  children: wh,
  claim_svg_element: Fh,
  detach: kh,
  init: $h,
  insert_hydration: Eh,
  noop: Ah,
  safe_not_equal: Ch,
  svg_element: Sh
} = window.__gradio__svelte__internal, {
  SvelteComponent: Th,
  append_hydration: Bh,
  attr: Rh,
  children: Ih,
  claim_svg_element: Lh,
  detach: Oh,
  init: qh,
  insert_hydration: Nh,
  noop: zh,
  safe_not_equal: Mh,
  svg_element: Ph
} = window.__gradio__svelte__internal, {
  SvelteComponent: xh,
  append_hydration: Uh,
  attr: Hh,
  children: jh,
  claim_svg_element: Gh,
  detach: Vh,
  init: Wh,
  insert_hydration: Zh,
  noop: Yh,
  safe_not_equal: Xh,
  svg_element: Kh
} = window.__gradio__svelte__internal, {
  SvelteComponent: Qh,
  append_hydration: Jh,
  attr: em,
  children: tm,
  claim_svg_element: nm,
  detach: im,
  init: am,
  insert_hydration: lm,
  noop: om,
  safe_not_equal: rm,
  svg_element: sm
} = window.__gradio__svelte__internal, {
  SvelteComponent: um,
  append_hydration: cm,
  attr: _m,
  children: dm,
  claim_svg_element: fm,
  detach: pm,
  init: hm,
  insert_hydration: mm,
  noop: gm,
  safe_not_equal: vm,
  svg_element: Dm
} = window.__gradio__svelte__internal, {
  SvelteComponent: bm,
  append_hydration: ym,
  attr: wm,
  children: Fm,
  claim_svg_element: km,
  detach: $m,
  init: Em,
  insert_hydration: Am,
  noop: Cm,
  safe_not_equal: Sm,
  svg_element: Tm
} = window.__gradio__svelte__internal, {
  SvelteComponent: Bm,
  append_hydration: Rm,
  attr: Im,
  children: Lm,
  claim_svg_element: Om,
  detach: qm,
  init: Nm,
  insert_hydration: zm,
  noop: Mm,
  safe_not_equal: Pm,
  svg_element: xm
} = window.__gradio__svelte__internal, {
  SvelteComponent: Um,
  append_hydration: Hm,
  attr: jm,
  children: Gm,
  claim_svg_element: Vm,
  detach: Wm,
  init: Zm,
  insert_hydration: Ym,
  noop: Xm,
  safe_not_equal: Km,
  svg_element: Qm
} = window.__gradio__svelte__internal, {
  SvelteComponent: Jm,
  append_hydration: eg,
  attr: tg,
  children: ng,
  claim_svg_element: ig,
  detach: ag,
  init: lg,
  insert_hydration: og,
  noop: rg,
  safe_not_equal: sg,
  svg_element: ug
} = window.__gradio__svelte__internal, {
  SvelteComponent: cg,
  append_hydration: _g,
  attr: dg,
  children: fg,
  claim_svg_element: pg,
  detach: hg,
  init: mg,
  insert_hydration: gg,
  noop: vg,
  safe_not_equal: Dg,
  svg_element: bg
} = window.__gradio__svelte__internal, {
  SvelteComponent: yg,
  append_hydration: wg,
  attr: Fg,
  children: kg,
  claim_svg_element: $g,
  detach: Eg,
  init: Ag,
  insert_hydration: Cg,
  noop: Sg,
  safe_not_equal: Tg,
  svg_element: Bg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Rg,
  append_hydration: Ig,
  attr: Lg,
  children: Og,
  claim_svg_element: qg,
  detach: Ng,
  init: zg,
  insert_hydration: Mg,
  noop: Pg,
  safe_not_equal: xg,
  svg_element: Ug
} = window.__gradio__svelte__internal, {
  SvelteComponent: Hg,
  append_hydration: jg,
  attr: Gg,
  children: Vg,
  claim_svg_element: Wg,
  detach: Zg,
  init: Yg,
  insert_hydration: Xg,
  noop: Kg,
  safe_not_equal: Qg,
  svg_element: Jg
} = window.__gradio__svelte__internal, {
  SvelteComponent: e0,
  append_hydration: t0,
  attr: n0,
  children: i0,
  claim_svg_element: a0,
  detach: l0,
  init: o0,
  insert_hydration: r0,
  noop: s0,
  safe_not_equal: u0,
  svg_element: c0
} = window.__gradio__svelte__internal, {
  SvelteComponent: _0,
  append_hydration: d0,
  attr: f0,
  children: p0,
  claim_svg_element: h0,
  detach: m0,
  init: g0,
  insert_hydration: v0,
  noop: D0,
  safe_not_equal: b0,
  svg_element: y0
} = window.__gradio__svelte__internal, {
  SvelteComponent: w0,
  append_hydration: F0,
  attr: k0,
  children: $0,
  claim_svg_element: E0,
  detach: A0,
  init: C0,
  insert_hydration: S0,
  noop: T0,
  safe_not_equal: B0,
  svg_element: R0
} = window.__gradio__svelte__internal, {
  SvelteComponent: I0,
  append_hydration: L0,
  attr: O0,
  children: q0,
  claim_svg_element: N0,
  detach: z0,
  init: M0,
  insert_hydration: P0,
  noop: x0,
  safe_not_equal: U0,
  svg_element: H0
} = window.__gradio__svelte__internal, {
  SvelteComponent: j0,
  append_hydration: G0,
  attr: V0,
  children: W0,
  claim_svg_element: Z0,
  detach: Y0,
  init: X0,
  insert_hydration: K0,
  noop: Q0,
  safe_not_equal: J0,
  svg_element: e1
} = window.__gradio__svelte__internal, {
  SvelteComponent: t1,
  append_hydration: n1,
  attr: i1,
  children: a1,
  claim_svg_element: l1,
  detach: o1,
  init: r1,
  insert_hydration: s1,
  noop: u1,
  safe_not_equal: c1,
  svg_element: _1
} = window.__gradio__svelte__internal, {
  SvelteComponent: d1,
  append_hydration: f1,
  attr: p1,
  children: h1,
  claim_svg_element: m1,
  detach: g1,
  init: v1,
  insert_hydration: D1,
  noop: b1,
  safe_not_equal: y1,
  svg_element: w1
} = window.__gradio__svelte__internal, {
  SvelteComponent: F1,
  append_hydration: k1,
  attr: $1,
  children: E1,
  claim_svg_element: A1,
  detach: C1,
  init: S1,
  insert_hydration: T1,
  noop: B1,
  safe_not_equal: R1,
  svg_element: I1
} = window.__gradio__svelte__internal, {
  SvelteComponent: L1,
  append_hydration: O1,
  attr: q1,
  children: N1,
  claim_svg_element: z1,
  detach: M1,
  init: P1,
  insert_hydration: x1,
  noop: U1,
  safe_not_equal: H1,
  svg_element: j1
} = window.__gradio__svelte__internal, {
  SvelteComponent: G1,
  append_hydration: V1,
  attr: W1,
  children: Z1,
  claim_svg_element: Y1,
  detach: X1,
  init: K1,
  insert_hydration: Q1,
  noop: J1,
  safe_not_equal: ev,
  svg_element: tv
} = window.__gradio__svelte__internal, {
  SvelteComponent: nv,
  append_hydration: iv,
  attr: av,
  children: lv,
  claim_svg_element: ov,
  detach: rv,
  init: sv,
  insert_hydration: uv,
  noop: cv,
  safe_not_equal: _v,
  svg_element: dv
} = window.__gradio__svelte__internal, {
  SvelteComponent: fv,
  append_hydration: pv,
  attr: hv,
  children: mv,
  claim_svg_element: gv,
  detach: vv,
  init: Dv,
  insert_hydration: bv,
  noop: yv,
  safe_not_equal: wv,
  set_style: Fv,
  svg_element: kv
} = window.__gradio__svelte__internal, {
  SvelteComponent: $v,
  append_hydration: Ev,
  attr: Av,
  children: Cv,
  claim_svg_element: Sv,
  detach: Tv,
  init: Bv,
  insert_hydration: Rv,
  noop: Iv,
  safe_not_equal: Lv,
  svg_element: Ov
} = window.__gradio__svelte__internal, {
  SvelteComponent: qv,
  append_hydration: Nv,
  attr: zv,
  children: Mv,
  claim_svg_element: Pv,
  detach: xv,
  init: Uv,
  insert_hydration: Hv,
  noop: jv,
  safe_not_equal: Gv,
  svg_element: Vv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Wv,
  append_hydration: Zv,
  attr: Yv,
  children: Xv,
  claim_svg_element: Kv,
  detach: Qv,
  init: Jv,
  insert_hydration: eD,
  noop: tD,
  safe_not_equal: nD,
  svg_element: iD
} = window.__gradio__svelte__internal, {
  SvelteComponent: aD,
  append_hydration: lD,
  attr: oD,
  children: rD,
  claim_svg_element: sD,
  detach: uD,
  init: cD,
  insert_hydration: _D,
  noop: dD,
  safe_not_equal: fD,
  svg_element: pD
} = window.__gradio__svelte__internal, {
  SvelteComponent: hD,
  append_hydration: mD,
  attr: gD,
  children: vD,
  claim_svg_element: DD,
  detach: bD,
  init: yD,
  insert_hydration: wD,
  noop: FD,
  safe_not_equal: kD,
  svg_element: $D
} = window.__gradio__svelte__internal, {
  SvelteComponent: ED,
  append_hydration: AD,
  attr: CD,
  children: SD,
  claim_svg_element: TD,
  detach: BD,
  init: RD,
  insert_hydration: ID,
  noop: LD,
  safe_not_equal: OD,
  svg_element: qD
} = window.__gradio__svelte__internal, {
  SvelteComponent: ND,
  append_hydration: zD,
  attr: MD,
  children: PD,
  claim_svg_element: xD,
  detach: UD,
  init: HD,
  insert_hydration: jD,
  noop: GD,
  safe_not_equal: VD,
  svg_element: WD
} = window.__gradio__svelte__internal, {
  SvelteComponent: ZD,
  append_hydration: YD,
  attr: XD,
  children: KD,
  claim_svg_element: QD,
  detach: JD,
  init: eb,
  insert_hydration: tb,
  noop: nb,
  safe_not_equal: ib,
  svg_element: ab
} = window.__gradio__svelte__internal, {
  SvelteComponent: lb,
  append_hydration: ob,
  attr: rb,
  children: sb,
  claim_svg_element: ub,
  claim_text: cb,
  detach: _b,
  init: db,
  insert_hydration: fb,
  noop: pb,
  safe_not_equal: hb,
  svg_element: mb,
  text: gb
} = window.__gradio__svelte__internal, {
  SvelteComponent: vb,
  append_hydration: Db,
  attr: bb,
  children: yb,
  claim_svg_element: wb,
  detach: Fb,
  init: kb,
  insert_hydration: $b,
  noop: Eb,
  safe_not_equal: Ab,
  svg_element: Cb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Sb,
  append_hydration: Tb,
  attr: Bb,
  children: Rb,
  claim_svg_element: Ib,
  detach: Lb,
  init: Ob,
  insert_hydration: qb,
  noop: Nb,
  safe_not_equal: zb,
  svg_element: Mb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Pb,
  append_hydration: xb,
  attr: Ub,
  children: Hb,
  claim_svg_element: jb,
  detach: Gb,
  init: Vb,
  insert_hydration: Wb,
  noop: Zb,
  safe_not_equal: Yb,
  svg_element: Xb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Kb,
  append_hydration: Qb,
  attr: Jb,
  children: ey,
  claim_svg_element: ty,
  detach: ny,
  init: iy,
  insert_hydration: ay,
  noop: ly,
  safe_not_equal: oy,
  svg_element: ry
} = window.__gradio__svelte__internal, {
  SvelteComponent: sy,
  append_hydration: uy,
  attr: cy,
  children: _y,
  claim_svg_element: dy,
  detach: fy,
  init: py,
  insert_hydration: hy,
  noop: my,
  safe_not_equal: gy,
  svg_element: vy
} = window.__gradio__svelte__internal, {
  SvelteComponent: Dy,
  append_hydration: by,
  attr: yy,
  children: wy,
  claim_svg_element: Fy,
  detach: ky,
  init: $y,
  insert_hydration: Ey,
  noop: Ay,
  safe_not_equal: Cy,
  svg_element: Sy
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ty,
  append_hydration: By,
  attr: Ry,
  children: Iy,
  claim_svg_element: Ly,
  detach: Oy,
  init: qy,
  insert_hydration: Ny,
  noop: zy,
  safe_not_equal: My,
  svg_element: Py
} = window.__gradio__svelte__internal, {
  SvelteComponent: xy,
  append_hydration: Uy,
  attr: Hy,
  children: jy,
  claim_svg_element: Gy,
  claim_text: Vy,
  detach: Wy,
  init: Zy,
  insert_hydration: Yy,
  noop: Xy,
  safe_not_equal: Ky,
  svg_element: Qy,
  text: Jy
} = window.__gradio__svelte__internal, {
  SvelteComponent: ew,
  append_hydration: tw,
  attr: nw,
  children: iw,
  claim_svg_element: aw,
  claim_text: lw,
  detach: ow,
  init: rw,
  insert_hydration: sw,
  noop: uw,
  safe_not_equal: cw,
  svg_element: _w,
  text: dw
} = window.__gradio__svelte__internal, {
  SvelteComponent: fw,
  append_hydration: pw,
  attr: hw,
  children: mw,
  claim_svg_element: gw,
  claim_text: vw,
  detach: Dw,
  init: bw,
  insert_hydration: yw,
  noop: ww,
  safe_not_equal: Fw,
  svg_element: kw,
  text: $w
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ew,
  append_hydration: Aw,
  attr: Cw,
  children: Sw,
  claim_svg_element: Tw,
  detach: Bw,
  init: Rw,
  insert_hydration: Iw,
  noop: Lw,
  safe_not_equal: Ow,
  svg_element: qw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Nw,
  append_hydration: zw,
  attr: Mw,
  children: Pw,
  claim_svg_element: xw,
  detach: Uw,
  init: Hw,
  insert_hydration: jw,
  noop: Gw,
  safe_not_equal: Vw,
  svg_element: Ww
} = window.__gradio__svelte__internal, {
  SvelteComponent: Zw,
  append_hydration: Yw,
  attr: Xw,
  children: Kw,
  claim_svg_element: Qw,
  detach: Jw,
  init: eF,
  insert_hydration: tF,
  noop: nF,
  safe_not_equal: iF,
  svg_element: aF
} = window.__gradio__svelte__internal, {
  SvelteComponent: lF,
  append_hydration: oF,
  attr: rF,
  children: sF,
  claim_svg_element: uF,
  detach: cF,
  init: _F,
  insert_hydration: dF,
  noop: fF,
  safe_not_equal: pF,
  svg_element: hF
} = window.__gradio__svelte__internal, {
  SvelteComponent: mF,
  append_hydration: gF,
  attr: vF,
  children: DF,
  claim_svg_element: bF,
  detach: yF,
  init: wF,
  insert_hydration: FF,
  noop: kF,
  safe_not_equal: $F,
  svg_element: EF
} = window.__gradio__svelte__internal, {
  SvelteComponent: AF,
  append_hydration: CF,
  attr: SF,
  children: TF,
  claim_svg_element: BF,
  detach: RF,
  init: IF,
  insert_hydration: LF,
  noop: OF,
  safe_not_equal: qF,
  svg_element: NF
} = window.__gradio__svelte__internal, {
  SvelteComponent: zF,
  append_hydration: MF,
  attr: PF,
  children: xF,
  claim_svg_element: UF,
  detach: HF,
  init: jF,
  insert_hydration: GF,
  noop: VF,
  safe_not_equal: WF,
  svg_element: ZF
} = window.__gradio__svelte__internal, {
  SvelteComponent: YF,
  append_hydration: XF,
  attr: KF,
  children: QF,
  claim_svg_element: JF,
  detach: ek,
  init: tk,
  insert_hydration: nk,
  noop: ik,
  safe_not_equal: ak,
  svg_element: lk
} = window.__gradio__svelte__internal, Sr = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], Xi = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
Sr.reduce(
  (i, { color: e, primary: t, secondary: n }) => ({
    ...i,
    [e]: {
      primary: Xi[e][t],
      secondary: Xi[e][n]
    }
  }),
  {}
);
const {
  SvelteComponent: ok,
  claim_component: rk,
  create_component: sk,
  destroy_component: uk,
  init: ck,
  mount_component: _k,
  safe_not_equal: dk,
  transition_in: fk,
  transition_out: pk
} = window.__gradio__svelte__internal, { createEventDispatcher: hk } = window.__gradio__svelte__internal, {
  SvelteComponent: mk,
  append_hydration: gk,
  attr: vk,
  check_outros: Dk,
  children: bk,
  claim_component: yk,
  claim_element: wk,
  claim_space: Fk,
  claim_text: kk,
  create_component: $k,
  destroy_component: Ek,
  detach: Ak,
  element: Ck,
  empty: Sk,
  group_outros: Tk,
  init: Bk,
  insert_hydration: Rk,
  mount_component: Ik,
  safe_not_equal: Lk,
  set_data: Ok,
  space: qk,
  text: Nk,
  toggle_class: zk,
  transition_in: Mk,
  transition_out: Pk
} = window.__gradio__svelte__internal, {
  SvelteComponent: xk,
  attr: Uk,
  children: Hk,
  claim_element: jk,
  create_slot: Gk,
  detach: Vk,
  element: Wk,
  get_all_dirty_from_scope: Zk,
  get_slot_changes: Yk,
  init: Xk,
  insert_hydration: Kk,
  safe_not_equal: Qk,
  toggle_class: Jk,
  transition_in: e2,
  transition_out: t2,
  update_slot_base: n2
} = window.__gradio__svelte__internal, {
  SvelteComponent: i2,
  append_hydration: a2,
  attr: l2,
  check_outros: o2,
  children: r2,
  claim_component: s2,
  claim_element: u2,
  claim_space: c2,
  create_component: _2,
  destroy_component: d2,
  detach: f2,
  element: p2,
  empty: h2,
  group_outros: m2,
  init: g2,
  insert_hydration: v2,
  listen: D2,
  mount_component: b2,
  safe_not_equal: y2,
  space: w2,
  toggle_class: F2,
  transition_in: k2,
  transition_out: $2
} = window.__gradio__svelte__internal, {
  SvelteComponent: E2,
  attr: A2,
  children: C2,
  claim_element: S2,
  create_slot: T2,
  detach: B2,
  element: R2,
  get_all_dirty_from_scope: I2,
  get_slot_changes: L2,
  init: O2,
  insert_hydration: q2,
  null_to_empty: N2,
  safe_not_equal: z2,
  transition_in: M2,
  transition_out: P2,
  update_slot_base: x2
} = window.__gradio__svelte__internal, {
  SvelteComponent: U2,
  check_outros: H2,
  claim_component: j2,
  create_component: G2,
  destroy_component: V2,
  detach: W2,
  empty: Z2,
  group_outros: Y2,
  init: X2,
  insert_hydration: K2,
  mount_component: Q2,
  noop: J2,
  safe_not_equal: e$,
  transition_in: t$,
  transition_out: n$
} = window.__gradio__svelte__internal, { createEventDispatcher: i$ } = window.__gradio__svelte__internal;
function Mt(i) {
  let e = ["", "k", "M", "G", "T", "P", "E", "Z"], t = 0;
  for (; i > 1e3 && t < e.length - 1; )
    i /= 1e3, t++;
  let n = e[t];
  return (Number.isInteger(i) ? i : i.toFixed(1)) + n;
}
function En() {
}
const gl = typeof window < "u";
let Ki = gl ? () => window.performance.now() : () => Date.now(), vl = gl ? (i) => requestAnimationFrame(i) : En;
const xt = /* @__PURE__ */ new Set();
function Dl(i) {
  xt.forEach((e) => {
    e.c(i) || (xt.delete(e), e.f());
  }), xt.size !== 0 && vl(Dl);
}
function Tr(i) {
  let e;
  return xt.size === 0 && vl(Dl), { promise: new Promise((t) => {
    xt.add(e = { c: i, f: t });
  }), abort() {
    xt.delete(e);
  } };
}
const zt = [];
function Br(i, e = En) {
  let t;
  const n = /* @__PURE__ */ new Set();
  function a(l) {
    if (s = l, ((r = i) != r ? s == s : r !== s || r && typeof r == "object" || typeof r == "function") && (i = l, t)) {
      const u = !zt.length;
      for (const c of n) c[1](), zt.push(c, i);
      if (u) {
        for (let c = 0; c < zt.length; c += 2) zt[c][0](zt[c + 1]);
        zt.length = 0;
      }
    }
    var r, s;
  }
  function o(l) {
    a(l(i));
  }
  return { set: a, update: o, subscribe: function(l, r = En) {
    const s = [l, r];
    return n.add(s), n.size === 1 && (t = e(a, o) || En), l(i), () => {
      n.delete(s), n.size === 0 && t && (t(), t = null);
    };
  } };
}
function Qi(i) {
  return Object.prototype.toString.call(i) === "[object Date]";
}
function li(i, e, t, n) {
  if (typeof t == "number" || Qi(t)) {
    const a = n - t, o = (t - e) / (i.dt || 1 / 60), l = (o + (i.opts.stiffness * a - i.opts.damping * o) * i.inv_mass) * i.dt;
    return Math.abs(l) < i.opts.precision && Math.abs(a) < i.opts.precision ? n : (i.settled = !1, Qi(t) ? new Date(t.getTime() + l) : t + l);
  }
  if (Array.isArray(t)) return t.map((a, o) => li(i, e[o], t[o], n[o]));
  if (typeof t == "object") {
    const a = {};
    for (const o in t) a[o] = li(i, e[o], t[o], n[o]);
    return a;
  }
  throw new Error(`Cannot spring ${typeof t} values`);
}
function Ji(i, e = {}) {
  const t = Br(i), { stiffness: n = 0.15, damping: a = 0.8, precision: o = 0.01 } = e;
  let l, r, s, u = i, c = i, h = 1, d = 0, f = !1;
  function v(w, k = {}) {
    c = w;
    const m = s = {};
    return i == null || k.hard || b.stiffness >= 1 && b.damping >= 1 ? (f = !0, l = Ki(), u = w, t.set(i = c), Promise.resolve()) : (k.soft && (d = 1 / (60 * (k.soft === !0 ? 0.5 : +k.soft)), h = 0), r || (l = Ki(), f = !1, r = Tr((_) => {
      if (f) return f = !1, r = null, !1;
      h = Math.min(h + d, 1);
      const g = { inv_mass: h, opts: b, settled: !0, dt: 60 * (_ - l) / 1e3 }, y = li(g, u, i, c);
      return l = _, u = i, t.set(i = y), g.settled && (r = null), !g.settled;
    })), new Promise((_) => {
      r.promise.then(() => {
        m === s && _();
      });
    }));
  }
  const b = { set: v, update: (w, k) => v(w(c, i), k), subscribe: t.subscribe, stiffness: n, damping: a, precision: o };
  return b;
}
const {
  SvelteComponent: Rr,
  append_hydration: Ge,
  attr: V,
  children: Ne,
  claim_element: Ir,
  claim_svg_element: Ve,
  component_subscribe: ea,
  detach: Le,
  element: Lr,
  init: Or,
  insert_hydration: qr,
  noop: ta,
  safe_not_equal: Nr,
  set_style: yn,
  svg_element: We,
  toggle_class: na
} = window.__gradio__svelte__internal, { onMount: zr } = window.__gradio__svelte__internal;
function Mr(i) {
  let e, t, n, a, o, l, r, s, u, c, h, d;
  return {
    c() {
      e = Lr("div"), t = We("svg"), n = We("g"), a = We("path"), o = We("path"), l = We("path"), r = We("path"), s = We("g"), u = We("path"), c = We("path"), h = We("path"), d = We("path"), this.h();
    },
    l(f) {
      e = Ir(f, "DIV", { class: !0 });
      var v = Ne(e);
      t = Ve(v, "svg", {
        viewBox: !0,
        fill: !0,
        xmlns: !0,
        class: !0
      });
      var b = Ne(t);
      n = Ve(b, "g", { style: !0 });
      var w = Ne(n);
      a = Ve(w, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), Ne(a).forEach(Le), o = Ve(w, "path", { d: !0, fill: !0, class: !0 }), Ne(o).forEach(Le), l = Ve(w, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), Ne(l).forEach(Le), r = Ve(w, "path", { d: !0, fill: !0, class: !0 }), Ne(r).forEach(Le), w.forEach(Le), s = Ve(b, "g", { style: !0 });
      var k = Ne(s);
      u = Ve(k, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), Ne(u).forEach(Le), c = Ve(k, "path", { d: !0, fill: !0, class: !0 }), Ne(c).forEach(Le), h = Ve(k, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), Ne(h).forEach(Le), d = Ve(k, "path", { d: !0, fill: !0, class: !0 }), Ne(d).forEach(Le), k.forEach(Le), b.forEach(Le), v.forEach(Le), this.h();
    },
    h() {
      V(a, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), V(a, "fill", "#FF7C00"), V(a, "fill-opacity", "0.4"), V(a, "class", "svelte-43sxxs"), V(o, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), V(o, "fill", "#FF7C00"), V(o, "class", "svelte-43sxxs"), V(l, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), V(l, "fill", "#FF7C00"), V(l, "fill-opacity", "0.4"), V(l, "class", "svelte-43sxxs"), V(r, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), V(r, "fill", "#FF7C00"), V(r, "class", "svelte-43sxxs"), yn(n, "transform", "translate(" + /*$top*/
      i[1][0] + "px, " + /*$top*/
      i[1][1] + "px)"), V(u, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), V(u, "fill", "#FF7C00"), V(u, "fill-opacity", "0.4"), V(u, "class", "svelte-43sxxs"), V(c, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), V(c, "fill", "#FF7C00"), V(c, "class", "svelte-43sxxs"), V(h, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), V(h, "fill", "#FF7C00"), V(h, "fill-opacity", "0.4"), V(h, "class", "svelte-43sxxs"), V(d, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), V(d, "fill", "#FF7C00"), V(d, "class", "svelte-43sxxs"), yn(s, "transform", "translate(" + /*$bottom*/
      i[2][0] + "px, " + /*$bottom*/
      i[2][1] + "px)"), V(t, "viewBox", "-1200 -1200 3000 3000"), V(t, "fill", "none"), V(t, "xmlns", "http://www.w3.org/2000/svg"), V(t, "class", "svelte-43sxxs"), V(e, "class", "svelte-43sxxs"), na(
        e,
        "margin",
        /*margin*/
        i[0]
      );
    },
    m(f, v) {
      qr(f, e, v), Ge(e, t), Ge(t, n), Ge(n, a), Ge(n, o), Ge(n, l), Ge(n, r), Ge(t, s), Ge(s, u), Ge(s, c), Ge(s, h), Ge(s, d);
    },
    p(f, [v]) {
      v & /*$top*/
      2 && yn(n, "transform", "translate(" + /*$top*/
      f[1][0] + "px, " + /*$top*/
      f[1][1] + "px)"), v & /*$bottom*/
      4 && yn(s, "transform", "translate(" + /*$bottom*/
      f[2][0] + "px, " + /*$bottom*/
      f[2][1] + "px)"), v & /*margin*/
      1 && na(
        e,
        "margin",
        /*margin*/
        f[0]
      );
    },
    i: ta,
    o: ta,
    d(f) {
      f && Le(e);
    }
  };
}
function Pr(i, e, t) {
  let n, a;
  var o = this && this.__awaiter || function(f, v, b, w) {
    function k(m) {
      return m instanceof b ? m : new b(function(_) {
        _(m);
      });
    }
    return new (b || (b = Promise))(function(m, _) {
      function g(C) {
        try {
          F(w.next(C));
        } catch (T) {
          _(T);
        }
      }
      function y(C) {
        try {
          F(w.throw(C));
        } catch (T) {
          _(T);
        }
      }
      function F(C) {
        C.done ? m(C.value) : k(C.value).then(g, y);
      }
      F((w = w.apply(f, v || [])).next());
    });
  };
  let { margin: l = !0 } = e;
  const r = Ji([0, 0]);
  ea(i, r, (f) => t(1, n = f));
  const s = Ji([0, 0]);
  ea(i, s, (f) => t(2, a = f));
  let u;
  function c() {
    return o(this, void 0, void 0, function* () {
      yield Promise.all([r.set([125, 140]), s.set([-125, -140])]), yield Promise.all([r.set([-125, 140]), s.set([125, -140])]), yield Promise.all([r.set([-125, 0]), s.set([125, -0])]), yield Promise.all([r.set([125, 0]), s.set([-125, 0])]);
    });
  }
  function h() {
    return o(this, void 0, void 0, function* () {
      yield c(), u || h();
    });
  }
  function d() {
    return o(this, void 0, void 0, function* () {
      yield Promise.all([r.set([125, 0]), s.set([-125, 0])]), h();
    });
  }
  return zr(() => (d(), () => u = !0)), i.$$set = (f) => {
    "margin" in f && t(0, l = f.margin);
  }, [l, n, a, r, s];
}
class xr extends Rr {
  constructor(e) {
    super(), Or(this, e, Pr, Mr, Nr, { margin: 0 });
  }
}
const {
  SvelteComponent: Ur,
  append_hydration: Ct,
  attr: Xe,
  binding_callbacks: ia,
  check_outros: oi,
  children: lt,
  claim_component: bl,
  claim_element: ot,
  claim_space: Me,
  claim_text: ie,
  create_component: yl,
  create_slot: wl,
  destroy_component: Fl,
  destroy_each: kl,
  detach: q,
  element: rt,
  empty: xe,
  ensure_array_like: Bn,
  get_all_dirty_from_scope: $l,
  get_slot_changes: El,
  group_outros: ri,
  init: Hr,
  insert_hydration: M,
  mount_component: Al,
  noop: si,
  safe_not_equal: jr,
  set_data: Ue,
  set_style: Ft,
  space: Pe,
  text: ae,
  toggle_class: ze,
  transition_in: Ye,
  transition_out: st,
  update_slot_base: Cl
} = window.__gradio__svelte__internal, { tick: Gr } = window.__gradio__svelte__internal, { onDestroy: Vr } = window.__gradio__svelte__internal, { createEventDispatcher: Wr } = window.__gradio__svelte__internal, Zr = (i) => ({}), aa = (i) => ({}), Yr = (i) => ({}), la = (i) => ({});
function oa(i, e, t) {
  const n = i.slice();
  return n[40] = e[t], n[42] = t, n;
}
function ra(i, e, t) {
  const n = i.slice();
  return n[40] = e[t], n;
}
function Xr(i) {
  let e, t, n, a, o = (
    /*i18n*/
    i[1]("common.error") + ""
  ), l, r, s;
  t = new wr({
    props: {
      Icon: Cr,
      label: (
        /*i18n*/
        i[1]("common.clear")
      ),
      disabled: !1
    }
  }), t.$on(
    "click",
    /*click_handler*/
    i[32]
  );
  const u = (
    /*#slots*/
    i[30].error
  ), c = wl(
    u,
    i,
    /*$$scope*/
    i[29],
    aa
  );
  return {
    c() {
      e = rt("div"), yl(t.$$.fragment), n = Pe(), a = rt("span"), l = ae(o), r = Pe(), c && c.c(), this.h();
    },
    l(h) {
      e = ot(h, "DIV", { class: !0 });
      var d = lt(e);
      bl(t.$$.fragment, d), d.forEach(q), n = Me(h), a = ot(h, "SPAN", { class: !0 });
      var f = lt(a);
      l = ie(f, o), f.forEach(q), r = Me(h), c && c.l(h), this.h();
    },
    h() {
      Xe(e, "class", "clear-status svelte-17v219f"), Xe(a, "class", "error svelte-17v219f");
    },
    m(h, d) {
      M(h, e, d), Al(t, e, null), M(h, n, d), M(h, a, d), Ct(a, l), M(h, r, d), c && c.m(h, d), s = !0;
    },
    p(h, d) {
      const f = {};
      d[0] & /*i18n*/
      2 && (f.label = /*i18n*/
      h[1]("common.clear")), t.$set(f), (!s || d[0] & /*i18n*/
      2) && o !== (o = /*i18n*/
      h[1]("common.error") + "") && Ue(l, o), c && c.p && (!s || d[0] & /*$$scope*/
      536870912) && Cl(
        c,
        u,
        h,
        /*$$scope*/
        h[29],
        s ? El(
          u,
          /*$$scope*/
          h[29],
          d,
          Zr
        ) : $l(
          /*$$scope*/
          h[29]
        ),
        aa
      );
    },
    i(h) {
      s || (Ye(t.$$.fragment, h), Ye(c, h), s = !0);
    },
    o(h) {
      st(t.$$.fragment, h), st(c, h), s = !1;
    },
    d(h) {
      h && (q(e), q(n), q(a), q(r)), Fl(t), c && c.d(h);
    }
  };
}
function Kr(i) {
  let e, t, n, a, o, l, r, s, u, c = (
    /*variant*/
    i[8] === "default" && /*show_eta_bar*/
    i[18] && /*show_progress*/
    i[6] === "full" && sa(i)
  );
  function h(_, g) {
    if (
      /*progress*/
      _[7]
    ) return es;
    if (
      /*queue_position*/
      _[2] !== null && /*queue_size*/
      _[3] !== void 0 && /*queue_position*/
      _[2] >= 0
    ) return Jr;
    if (
      /*queue_position*/
      _[2] === 0
    ) return Qr;
  }
  let d = h(i), f = d && d(i), v = (
    /*timer*/
    i[5] && _a(i)
  );
  const b = [as, is], w = [];
  function k(_, g) {
    return (
      /*last_progress_level*/
      _[15] != null ? 0 : (
        /*show_progress*/
        _[6] === "full" ? 1 : -1
      )
    );
  }
  ~(o = k(i)) && (l = w[o] = b[o](i));
  let m = !/*timer*/
  i[5] && va(i);
  return {
    c() {
      c && c.c(), e = Pe(), t = rt("div"), f && f.c(), n = Pe(), v && v.c(), a = Pe(), l && l.c(), r = Pe(), m && m.c(), s = xe(), this.h();
    },
    l(_) {
      c && c.l(_), e = Me(_), t = ot(_, "DIV", { class: !0 });
      var g = lt(t);
      f && f.l(g), n = Me(g), v && v.l(g), g.forEach(q), a = Me(_), l && l.l(_), r = Me(_), m && m.l(_), s = xe(), this.h();
    },
    h() {
      Xe(t, "class", "progress-text svelte-17v219f"), ze(
        t,
        "meta-text-center",
        /*variant*/
        i[8] === "center"
      ), ze(
        t,
        "meta-text",
        /*variant*/
        i[8] === "default"
      );
    },
    m(_, g) {
      c && c.m(_, g), M(_, e, g), M(_, t, g), f && f.m(t, null), Ct(t, n), v && v.m(t, null), M(_, a, g), ~o && w[o].m(_, g), M(_, r, g), m && m.m(_, g), M(_, s, g), u = !0;
    },
    p(_, g) {
      /*variant*/
      _[8] === "default" && /*show_eta_bar*/
      _[18] && /*show_progress*/
      _[6] === "full" ? c ? c.p(_, g) : (c = sa(_), c.c(), c.m(e.parentNode, e)) : c && (c.d(1), c = null), d === (d = h(_)) && f ? f.p(_, g) : (f && f.d(1), f = d && d(_), f && (f.c(), f.m(t, n))), /*timer*/
      _[5] ? v ? v.p(_, g) : (v = _a(_), v.c(), v.m(t, null)) : v && (v.d(1), v = null), (!u || g[0] & /*variant*/
      256) && ze(
        t,
        "meta-text-center",
        /*variant*/
        _[8] === "center"
      ), (!u || g[0] & /*variant*/
      256) && ze(
        t,
        "meta-text",
        /*variant*/
        _[8] === "default"
      );
      let y = o;
      o = k(_), o === y ? ~o && w[o].p(_, g) : (l && (ri(), st(w[y], 1, 1, () => {
        w[y] = null;
      }), oi()), ~o ? (l = w[o], l ? l.p(_, g) : (l = w[o] = b[o](_), l.c()), Ye(l, 1), l.m(r.parentNode, r)) : l = null), /*timer*/
      _[5] ? m && (ri(), st(m, 1, 1, () => {
        m = null;
      }), oi()) : m ? (m.p(_, g), g[0] & /*timer*/
      32 && Ye(m, 1)) : (m = va(_), m.c(), Ye(m, 1), m.m(s.parentNode, s));
    },
    i(_) {
      u || (Ye(l), Ye(m), u = !0);
    },
    o(_) {
      st(l), st(m), u = !1;
    },
    d(_) {
      _ && (q(e), q(t), q(a), q(r), q(s)), c && c.d(_), f && f.d(), v && v.d(), ~o && w[o].d(_), m && m.d(_);
    }
  };
}
function sa(i) {
  let e, t = `translateX(${/*eta_level*/
  (i[17] || 0) * 100 - 100}%)`;
  return {
    c() {
      e = rt("div"), this.h();
    },
    l(n) {
      e = ot(n, "DIV", { class: !0 }), lt(e).forEach(q), this.h();
    },
    h() {
      Xe(e, "class", "eta-bar svelte-17v219f"), Ft(e, "transform", t);
    },
    m(n, a) {
      M(n, e, a);
    },
    p(n, a) {
      a[0] & /*eta_level*/
      131072 && t !== (t = `translateX(${/*eta_level*/
      (n[17] || 0) * 100 - 100}%)`) && Ft(e, "transform", t);
    },
    d(n) {
      n && q(e);
    }
  };
}
function Qr(i) {
  let e;
  return {
    c() {
      e = ae("processing |");
    },
    l(t) {
      e = ie(t, "processing |");
    },
    m(t, n) {
      M(t, e, n);
    },
    p: si,
    d(t) {
      t && q(e);
    }
  };
}
function Jr(i) {
  let e, t = (
    /*queue_position*/
    i[2] + 1 + ""
  ), n, a, o, l;
  return {
    c() {
      e = ae("queue: "), n = ae(t), a = ae("/"), o = ae(
        /*queue_size*/
        i[3]
      ), l = ae(" |");
    },
    l(r) {
      e = ie(r, "queue: "), n = ie(r, t), a = ie(r, "/"), o = ie(
        r,
        /*queue_size*/
        i[3]
      ), l = ie(r, " |");
    },
    m(r, s) {
      M(r, e, s), M(r, n, s), M(r, a, s), M(r, o, s), M(r, l, s);
    },
    p(r, s) {
      s[0] & /*queue_position*/
      4 && t !== (t = /*queue_position*/
      r[2] + 1 + "") && Ue(n, t), s[0] & /*queue_size*/
      8 && Ue(
        o,
        /*queue_size*/
        r[3]
      );
    },
    d(r) {
      r && (q(e), q(n), q(a), q(o), q(l));
    }
  };
}
function es(i) {
  let e, t = Bn(
    /*progress*/
    i[7]
  ), n = [];
  for (let a = 0; a < t.length; a += 1)
    n[a] = ca(ra(i, t, a));
  return {
    c() {
      for (let a = 0; a < n.length; a += 1)
        n[a].c();
      e = xe();
    },
    l(a) {
      for (let o = 0; o < n.length; o += 1)
        n[o].l(a);
      e = xe();
    },
    m(a, o) {
      for (let l = 0; l < n.length; l += 1)
        n[l] && n[l].m(a, o);
      M(a, e, o);
    },
    p(a, o) {
      if (o[0] & /*progress*/
      128) {
        t = Bn(
          /*progress*/
          a[7]
        );
        let l;
        for (l = 0; l < t.length; l += 1) {
          const r = ra(a, t, l);
          n[l] ? n[l].p(r, o) : (n[l] = ca(r), n[l].c(), n[l].m(e.parentNode, e));
        }
        for (; l < n.length; l += 1)
          n[l].d(1);
        n.length = t.length;
      }
    },
    d(a) {
      a && q(e), kl(n, a);
    }
  };
}
function ua(i) {
  let e, t = (
    /*p*/
    i[40].unit + ""
  ), n, a, o = " ", l;
  function r(c, h) {
    return (
      /*p*/
      c[40].length != null ? ns : ts
    );
  }
  let s = r(i), u = s(i);
  return {
    c() {
      u.c(), e = Pe(), n = ae(t), a = ae(" | "), l = ae(o);
    },
    l(c) {
      u.l(c), e = Me(c), n = ie(c, t), a = ie(c, " | "), l = ie(c, o);
    },
    m(c, h) {
      u.m(c, h), M(c, e, h), M(c, n, h), M(c, a, h), M(c, l, h);
    },
    p(c, h) {
      s === (s = r(c)) && u ? u.p(c, h) : (u.d(1), u = s(c), u && (u.c(), u.m(e.parentNode, e))), h[0] & /*progress*/
      128 && t !== (t = /*p*/
      c[40].unit + "") && Ue(n, t);
    },
    d(c) {
      c && (q(e), q(n), q(a), q(l)), u.d(c);
    }
  };
}
function ts(i) {
  let e = Mt(
    /*p*/
    i[40].index || 0
  ) + "", t;
  return {
    c() {
      t = ae(e);
    },
    l(n) {
      t = ie(n, e);
    },
    m(n, a) {
      M(n, t, a);
    },
    p(n, a) {
      a[0] & /*progress*/
      128 && e !== (e = Mt(
        /*p*/
        n[40].index || 0
      ) + "") && Ue(t, e);
    },
    d(n) {
      n && q(t);
    }
  };
}
function ns(i) {
  let e = Mt(
    /*p*/
    i[40].index || 0
  ) + "", t, n, a = Mt(
    /*p*/
    i[40].length
  ) + "", o;
  return {
    c() {
      t = ae(e), n = ae("/"), o = ae(a);
    },
    l(l) {
      t = ie(l, e), n = ie(l, "/"), o = ie(l, a);
    },
    m(l, r) {
      M(l, t, r), M(l, n, r), M(l, o, r);
    },
    p(l, r) {
      r[0] & /*progress*/
      128 && e !== (e = Mt(
        /*p*/
        l[40].index || 0
      ) + "") && Ue(t, e), r[0] & /*progress*/
      128 && a !== (a = Mt(
        /*p*/
        l[40].length
      ) + "") && Ue(o, a);
    },
    d(l) {
      l && (q(t), q(n), q(o));
    }
  };
}
function ca(i) {
  let e, t = (
    /*p*/
    i[40].index != null && ua(i)
  );
  return {
    c() {
      t && t.c(), e = xe();
    },
    l(n) {
      t && t.l(n), e = xe();
    },
    m(n, a) {
      t && t.m(n, a), M(n, e, a);
    },
    p(n, a) {
      /*p*/
      n[40].index != null ? t ? t.p(n, a) : (t = ua(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && q(e), t && t.d(n);
    }
  };
}
function _a(i) {
  let e, t = (
    /*eta*/
    i[0] ? `/${/*formatted_eta*/
    i[19]}` : ""
  ), n, a;
  return {
    c() {
      e = ae(
        /*formatted_timer*/
        i[20]
      ), n = ae(t), a = ae("s");
    },
    l(o) {
      e = ie(
        o,
        /*formatted_timer*/
        i[20]
      ), n = ie(o, t), a = ie(o, "s");
    },
    m(o, l) {
      M(o, e, l), M(o, n, l), M(o, a, l);
    },
    p(o, l) {
      l[0] & /*formatted_timer*/
      1048576 && Ue(
        e,
        /*formatted_timer*/
        o[20]
      ), l[0] & /*eta, formatted_eta*/
      524289 && t !== (t = /*eta*/
      o[0] ? `/${/*formatted_eta*/
      o[19]}` : "") && Ue(n, t);
    },
    d(o) {
      o && (q(e), q(n), q(a));
    }
  };
}
function is(i) {
  let e, t;
  return e = new xr({
    props: { margin: (
      /*variant*/
      i[8] === "default"
    ) }
  }), {
    c() {
      yl(e.$$.fragment);
    },
    l(n) {
      bl(e.$$.fragment, n);
    },
    m(n, a) {
      Al(e, n, a), t = !0;
    },
    p(n, a) {
      const o = {};
      a[0] & /*variant*/
      256 && (o.margin = /*variant*/
      n[8] === "default"), e.$set(o);
    },
    i(n) {
      t || (Ye(e.$$.fragment, n), t = !0);
    },
    o(n) {
      st(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Fl(e, n);
    }
  };
}
function as(i) {
  let e, t, n, a, o, l = `${/*last_progress_level*/
  i[15] * 100}%`, r = (
    /*progress*/
    i[7] != null && da(i)
  );
  return {
    c() {
      e = rt("div"), t = rt("div"), r && r.c(), n = Pe(), a = rt("div"), o = rt("div"), this.h();
    },
    l(s) {
      e = ot(s, "DIV", { class: !0 });
      var u = lt(e);
      t = ot(u, "DIV", { class: !0 });
      var c = lt(t);
      r && r.l(c), c.forEach(q), n = Me(u), a = ot(u, "DIV", { class: !0 });
      var h = lt(a);
      o = ot(h, "DIV", { class: !0 }), lt(o).forEach(q), h.forEach(q), u.forEach(q), this.h();
    },
    h() {
      Xe(t, "class", "progress-level-inner svelte-17v219f"), Xe(o, "class", "progress-bar svelte-17v219f"), Ft(o, "width", l), Xe(a, "class", "progress-bar-wrap svelte-17v219f"), Xe(e, "class", "progress-level svelte-17v219f");
    },
    m(s, u) {
      M(s, e, u), Ct(e, t), r && r.m(t, null), Ct(e, n), Ct(e, a), Ct(a, o), i[31](o);
    },
    p(s, u) {
      /*progress*/
      s[7] != null ? r ? r.p(s, u) : (r = da(s), r.c(), r.m(t, null)) : r && (r.d(1), r = null), u[0] & /*last_progress_level*/
      32768 && l !== (l = `${/*last_progress_level*/
      s[15] * 100}%`) && Ft(o, "width", l);
    },
    i: si,
    o: si,
    d(s) {
      s && q(e), r && r.d(), i[31](null);
    }
  };
}
function da(i) {
  let e, t = Bn(
    /*progress*/
    i[7]
  ), n = [];
  for (let a = 0; a < t.length; a += 1)
    n[a] = ga(oa(i, t, a));
  return {
    c() {
      for (let a = 0; a < n.length; a += 1)
        n[a].c();
      e = xe();
    },
    l(a) {
      for (let o = 0; o < n.length; o += 1)
        n[o].l(a);
      e = xe();
    },
    m(a, o) {
      for (let l = 0; l < n.length; l += 1)
        n[l] && n[l].m(a, o);
      M(a, e, o);
    },
    p(a, o) {
      if (o[0] & /*progress_level, progress*/
      16512) {
        t = Bn(
          /*progress*/
          a[7]
        );
        let l;
        for (l = 0; l < t.length; l += 1) {
          const r = oa(a, t, l);
          n[l] ? n[l].p(r, o) : (n[l] = ga(r), n[l].c(), n[l].m(e.parentNode, e));
        }
        for (; l < n.length; l += 1)
          n[l].d(1);
        n.length = t.length;
      }
    },
    d(a) {
      a && q(e), kl(n, a);
    }
  };
}
function fa(i) {
  let e, t, n, a, o = (
    /*i*/
    i[42] !== 0 && ls()
  ), l = (
    /*p*/
    i[40].desc != null && pa(i)
  ), r = (
    /*p*/
    i[40].desc != null && /*progress_level*/
    i[14] && /*progress_level*/
    i[14][
      /*i*/
      i[42]
    ] != null && ha()
  ), s = (
    /*progress_level*/
    i[14] != null && ma(i)
  );
  return {
    c() {
      o && o.c(), e = Pe(), l && l.c(), t = Pe(), r && r.c(), n = Pe(), s && s.c(), a = xe();
    },
    l(u) {
      o && o.l(u), e = Me(u), l && l.l(u), t = Me(u), r && r.l(u), n = Me(u), s && s.l(u), a = xe();
    },
    m(u, c) {
      o && o.m(u, c), M(u, e, c), l && l.m(u, c), M(u, t, c), r && r.m(u, c), M(u, n, c), s && s.m(u, c), M(u, a, c);
    },
    p(u, c) {
      /*p*/
      u[40].desc != null ? l ? l.p(u, c) : (l = pa(u), l.c(), l.m(t.parentNode, t)) : l && (l.d(1), l = null), /*p*/
      u[40].desc != null && /*progress_level*/
      u[14] && /*progress_level*/
      u[14][
        /*i*/
        u[42]
      ] != null ? r || (r = ha(), r.c(), r.m(n.parentNode, n)) : r && (r.d(1), r = null), /*progress_level*/
      u[14] != null ? s ? s.p(u, c) : (s = ma(u), s.c(), s.m(a.parentNode, a)) : s && (s.d(1), s = null);
    },
    d(u) {
      u && (q(e), q(t), q(n), q(a)), o && o.d(u), l && l.d(u), r && r.d(u), s && s.d(u);
    }
  };
}
function ls(i) {
  let e;
  return {
    c() {
      e = ae(" /");
    },
    l(t) {
      e = ie(t, " /");
    },
    m(t, n) {
      M(t, e, n);
    },
    d(t) {
      t && q(e);
    }
  };
}
function pa(i) {
  let e = (
    /*p*/
    i[40].desc + ""
  ), t;
  return {
    c() {
      t = ae(e);
    },
    l(n) {
      t = ie(n, e);
    },
    m(n, a) {
      M(n, t, a);
    },
    p(n, a) {
      a[0] & /*progress*/
      128 && e !== (e = /*p*/
      n[40].desc + "") && Ue(t, e);
    },
    d(n) {
      n && q(t);
    }
  };
}
function ha(i) {
  let e;
  return {
    c() {
      e = ae("-");
    },
    l(t) {
      e = ie(t, "-");
    },
    m(t, n) {
      M(t, e, n);
    },
    d(t) {
      t && q(e);
    }
  };
}
function ma(i) {
  let e = (100 * /*progress_level*/
  (i[14][
    /*i*/
    i[42]
  ] || 0)).toFixed(1) + "", t, n;
  return {
    c() {
      t = ae(e), n = ae("%");
    },
    l(a) {
      t = ie(a, e), n = ie(a, "%");
    },
    m(a, o) {
      M(a, t, o), M(a, n, o);
    },
    p(a, o) {
      o[0] & /*progress_level*/
      16384 && e !== (e = (100 * /*progress_level*/
      (a[14][
        /*i*/
        a[42]
      ] || 0)).toFixed(1) + "") && Ue(t, e);
    },
    d(a) {
      a && (q(t), q(n));
    }
  };
}
function ga(i) {
  let e, t = (
    /*p*/
    (i[40].desc != null || /*progress_level*/
    i[14] && /*progress_level*/
    i[14][
      /*i*/
      i[42]
    ] != null) && fa(i)
  );
  return {
    c() {
      t && t.c(), e = xe();
    },
    l(n) {
      t && t.l(n), e = xe();
    },
    m(n, a) {
      t && t.m(n, a), M(n, e, a);
    },
    p(n, a) {
      /*p*/
      n[40].desc != null || /*progress_level*/
      n[14] && /*progress_level*/
      n[14][
        /*i*/
        n[42]
      ] != null ? t ? t.p(n, a) : (t = fa(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && q(e), t && t.d(n);
    }
  };
}
function va(i) {
  let e, t, n, a;
  const o = (
    /*#slots*/
    i[30]["additional-loading-text"]
  ), l = wl(
    o,
    i,
    /*$$scope*/
    i[29],
    la
  );
  return {
    c() {
      e = rt("p"), t = ae(
        /*loading_text*/
        i[9]
      ), n = Pe(), l && l.c(), this.h();
    },
    l(r) {
      e = ot(r, "P", { class: !0 });
      var s = lt(e);
      t = ie(
        s,
        /*loading_text*/
        i[9]
      ), s.forEach(q), n = Me(r), l && l.l(r), this.h();
    },
    h() {
      Xe(e, "class", "loading svelte-17v219f");
    },
    m(r, s) {
      M(r, e, s), Ct(e, t), M(r, n, s), l && l.m(r, s), a = !0;
    },
    p(r, s) {
      (!a || s[0] & /*loading_text*/
      512) && Ue(
        t,
        /*loading_text*/
        r[9]
      ), l && l.p && (!a || s[0] & /*$$scope*/
      536870912) && Cl(
        l,
        o,
        r,
        /*$$scope*/
        r[29],
        a ? El(
          o,
          /*$$scope*/
          r[29],
          s,
          Yr
        ) : $l(
          /*$$scope*/
          r[29]
        ),
        la
      );
    },
    i(r) {
      a || (Ye(l, r), a = !0);
    },
    o(r) {
      st(l, r), a = !1;
    },
    d(r) {
      r && (q(e), q(n)), l && l.d(r);
    }
  };
}
function os(i) {
  let e, t, n, a, o;
  const l = [Kr, Xr], r = [];
  function s(u, c) {
    return (
      /*status*/
      u[4] === "pending" ? 0 : (
        /*status*/
        u[4] === "error" ? 1 : -1
      )
    );
  }
  return ~(t = s(i)) && (n = r[t] = l[t](i)), {
    c() {
      e = rt("div"), n && n.c(), this.h();
    },
    l(u) {
      e = ot(u, "DIV", { class: !0 });
      var c = lt(e);
      n && n.l(c), c.forEach(q), this.h();
    },
    h() {
      Xe(e, "class", a = "wrap " + /*variant*/
      i[8] + " " + /*show_progress*/
      i[6] + " svelte-17v219f"), ze(e, "hide", !/*status*/
      i[4] || /*status*/
      i[4] === "complete" || /*show_progress*/
      i[6] === "hidden" || /*status*/
      i[4] == "streaming"), ze(
        e,
        "translucent",
        /*variant*/
        i[8] === "center" && /*status*/
        (i[4] === "pending" || /*status*/
        i[4] === "error") || /*translucent*/
        i[11] || /*show_progress*/
        i[6] === "minimal"
      ), ze(
        e,
        "generating",
        /*status*/
        i[4] === "generating" && /*show_progress*/
        i[6] === "full"
      ), ze(
        e,
        "border",
        /*border*/
        i[12]
      ), Ft(
        e,
        "position",
        /*absolute*/
        i[10] ? "absolute" : "static"
      ), Ft(
        e,
        "padding",
        /*absolute*/
        i[10] ? "0" : "var(--size-8) 0"
      );
    },
    m(u, c) {
      M(u, e, c), ~t && r[t].m(e, null), i[33](e), o = !0;
    },
    p(u, c) {
      let h = t;
      t = s(u), t === h ? ~t && r[t].p(u, c) : (n && (ri(), st(r[h], 1, 1, () => {
        r[h] = null;
      }), oi()), ~t ? (n = r[t], n ? n.p(u, c) : (n = r[t] = l[t](u), n.c()), Ye(n, 1), n.m(e, null)) : n = null), (!o || c[0] & /*variant, show_progress*/
      320 && a !== (a = "wrap " + /*variant*/
      u[8] + " " + /*show_progress*/
      u[6] + " svelte-17v219f")) && Xe(e, "class", a), (!o || c[0] & /*variant, show_progress, status, show_progress*/
      336) && ze(e, "hide", !/*status*/
      u[4] || /*status*/
      u[4] === "complete" || /*show_progress*/
      u[6] === "hidden" || /*status*/
      u[4] == "streaming"), (!o || c[0] & /*variant, show_progress, variant, status, translucent, show_progress*/
      2384) && ze(
        e,
        "translucent",
        /*variant*/
        u[8] === "center" && /*status*/
        (u[4] === "pending" || /*status*/
        u[4] === "error") || /*translucent*/
        u[11] || /*show_progress*/
        u[6] === "minimal"
      ), (!o || c[0] & /*variant, show_progress, status, show_progress*/
      336) && ze(
        e,
        "generating",
        /*status*/
        u[4] === "generating" && /*show_progress*/
        u[6] === "full"
      ), (!o || c[0] & /*variant, show_progress, border*/
      4416) && ze(
        e,
        "border",
        /*border*/
        u[12]
      ), c[0] & /*absolute*/
      1024 && Ft(
        e,
        "position",
        /*absolute*/
        u[10] ? "absolute" : "static"
      ), c[0] & /*absolute*/
      1024 && Ft(
        e,
        "padding",
        /*absolute*/
        u[10] ? "0" : "var(--size-8) 0"
      );
    },
    i(u) {
      o || (Ye(n), o = !0);
    },
    o(u) {
      st(n), o = !1;
    },
    d(u) {
      u && q(e), ~t && r[t].d(), i[33](null);
    }
  };
}
var rs = function(i, e, t, n) {
  function a(o) {
    return o instanceof t ? o : new t(function(l) {
      l(o);
    });
  }
  return new (t || (t = Promise))(function(o, l) {
    function r(c) {
      try {
        u(n.next(c));
      } catch (h) {
        l(h);
      }
    }
    function s(c) {
      try {
        u(n.throw(c));
      } catch (h) {
        l(h);
      }
    }
    function u(c) {
      c.done ? o(c.value) : a(c.value).then(r, s);
    }
    u((n = n.apply(i, e || [])).next());
  });
};
let wn = [], Gn = !1;
const ss = typeof window < "u", Sl = ss ? window.requestAnimationFrame : (i) => {
};
function us(i) {
  return rs(this, arguments, void 0, function* (e, t = !0) {
    if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && t !== !0)) {
      if (wn.push(e), !Gn) Gn = !0;
      else return;
      yield Gr(), Sl(() => {
        let n = [0, 0];
        for (let a = 0; a < wn.length; a++) {
          const l = wn[a].getBoundingClientRect();
          (a === 0 || l.top + window.scrollY <= n[0]) && (n[0] = l.top + window.scrollY, n[1] = a);
        }
        window.scrollTo({ top: n[0] - 20, behavior: "smooth" }), Gn = !1, wn = [];
      });
    }
  });
}
function cs(i, e, t) {
  let n, { $$slots: a = {}, $$scope: o } = e;
  const l = Wr();
  let { i18n: r } = e, { eta: s = null } = e, { queue_position: u } = e, { queue_size: c } = e, { status: h } = e, { scroll_to_output: d = !1 } = e, { timer: f = !0 } = e, { show_progress: v = "full" } = e, { message: b = null } = e, { progress: w = null } = e, { variant: k = "default" } = e, { loading_text: m = "Loading..." } = e, { absolute: _ = !0 } = e, { translucent: g = !1 } = e, { border: y = !1 } = e, { autoscroll: F } = e, C, T = !1, S = 0, z = 0, N = null, j = null, ke = 0, ue = null, $e, _e = null, ne = !0;
  const X = () => {
    t(0, s = t(27, N = t(19, $ = null))), t(25, S = performance.now()), t(26, z = 0), T = !0, se();
  };
  function se() {
    Sl(() => {
      t(26, z = (performance.now() - S) / 1e3), T && se();
    });
  }
  function ve() {
    t(26, z = 0), t(0, s = t(27, N = t(19, $ = null))), T && (T = !1);
  }
  Vr(() => {
    T && ve();
  });
  let $ = null;
  function oe(A) {
    ia[A ? "unshift" : "push"](() => {
      _e = A, t(16, _e), t(7, w), t(14, ue), t(15, $e);
    });
  }
  const K = () => {
    l("clear_status");
  };
  function de(A) {
    ia[A ? "unshift" : "push"](() => {
      C = A, t(13, C);
    });
  }
  return i.$$set = (A) => {
    "i18n" in A && t(1, r = A.i18n), "eta" in A && t(0, s = A.eta), "queue_position" in A && t(2, u = A.queue_position), "queue_size" in A && t(3, c = A.queue_size), "status" in A && t(4, h = A.status), "scroll_to_output" in A && t(22, d = A.scroll_to_output), "timer" in A && t(5, f = A.timer), "show_progress" in A && t(6, v = A.show_progress), "message" in A && t(23, b = A.message), "progress" in A && t(7, w = A.progress), "variant" in A && t(8, k = A.variant), "loading_text" in A && t(9, m = A.loading_text), "absolute" in A && t(10, _ = A.absolute), "translucent" in A && t(11, g = A.translucent), "border" in A && t(12, y = A.border), "autoscroll" in A && t(24, F = A.autoscroll), "$$scope" in A && t(29, o = A.$$scope);
  }, i.$$.update = () => {
    i.$$.dirty[0] & /*eta, old_eta, timer_start, eta_from_start*/
    436207617 && (s === null && t(0, s = N), s != null && N !== s && (t(28, j = (performance.now() - S) / 1e3 + s), t(19, $ = j.toFixed(1)), t(27, N = s))), i.$$.dirty[0] & /*eta_from_start, timer_diff*/
    335544320 && t(17, ke = j === null || j <= 0 || !z ? null : Math.min(z / j, 1)), i.$$.dirty[0] & /*progress*/
    128 && w != null && t(18, ne = !1), i.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    114816 && (w != null ? t(14, ue = w.map((A) => {
      if (A.index != null && A.length != null)
        return A.index / A.length;
      if (A.progress != null)
        return A.progress;
    })) : t(14, ue = null), ue ? (t(15, $e = ue[ue.length - 1]), _e && ($e === 0 ? t(16, _e.style.transition = "0", _e) : t(16, _e.style.transition = "150ms", _e))) : t(15, $e = void 0)), i.$$.dirty[0] & /*status*/
    16 && (h === "pending" ? X() : ve()), i.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    20979728 && C && d && (h === "pending" || h === "complete") && us(C, F), i.$$.dirty[0] & /*status, message*/
    8388624, i.$$.dirty[0] & /*timer_diff*/
    67108864 && t(20, n = z.toFixed(1));
  }, [
    s,
    r,
    u,
    c,
    h,
    f,
    v,
    w,
    k,
    m,
    _,
    g,
    y,
    C,
    ue,
    $e,
    _e,
    ke,
    ne,
    $,
    n,
    l,
    d,
    b,
    F,
    S,
    z,
    N,
    j,
    o,
    a,
    oe,
    K,
    de
  ];
}
class _s extends Ur {
  constructor(e) {
    super(), Hr(
      this,
      e,
      cs,
      os,
      jr,
      {
        i18n: 1,
        eta: 0,
        queue_position: 2,
        queue_size: 3,
        status: 4,
        scroll_to_output: 22,
        timer: 5,
        show_progress: 6,
        message: 23,
        progress: 7,
        variant: 8,
        loading_text: 9,
        absolute: 10,
        translucent: 11,
        border: 12,
        autoscroll: 24
      },
      null,
      [-1, -1]
    );
  }
}
/*! @license DOMPurify 3.2.6 | (c) Cure53 and other contributors | Released under the Apache license 2.0 and Mozilla Public License 2.0 | github.com/cure53/DOMPurify/blob/3.2.6/LICENSE */
const {
  entries: Tl,
  setPrototypeOf: Da,
  isFrozen: ds,
  getPrototypeOf: fs,
  getOwnPropertyDescriptor: ps
} = Object;
let {
  freeze: Ae,
  seal: He,
  create: Bl
} = Object, {
  apply: ui,
  construct: ci
} = typeof Reflect < "u" && Reflect;
Ae || (Ae = function(e) {
  return e;
});
He || (He = function(e) {
  return e;
});
ui || (ui = function(e, t, n) {
  return e.apply(t, n);
});
ci || (ci = function(e, t) {
  return new e(...t);
});
const Fn = Ce(Array.prototype.forEach), hs = Ce(Array.prototype.lastIndexOf), ba = Ce(Array.prototype.pop), Xt = Ce(Array.prototype.push), ms = Ce(Array.prototype.splice), An = Ce(String.prototype.toLowerCase), Vn = Ce(String.prototype.toString), ya = Ce(String.prototype.match), Kt = Ce(String.prototype.replace), gs = Ce(String.prototype.indexOf), vs = Ce(String.prototype.trim), Ze = Ce(Object.prototype.hasOwnProperty), Ee = Ce(RegExp.prototype.test), Qt = Ds(TypeError);
function Ce(i) {
  return function(e) {
    e instanceof RegExp && (e.lastIndex = 0);
    for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), a = 1; a < t; a++)
      n[a - 1] = arguments[a];
    return ui(i, e, n);
  };
}
function Ds(i) {
  return function() {
    for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++)
      t[n] = arguments[n];
    return ci(i, t);
  };
}
function P(i, e) {
  let t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : An;
  Da && Da(i, null);
  let n = e.length;
  for (; n--; ) {
    let a = e[n];
    if (typeof a == "string") {
      const o = t(a);
      o !== a && (ds(e) || (e[n] = o), a = o);
    }
    i[a] = !0;
  }
  return i;
}
function bs(i) {
  for (let e = 0; e < i.length; e++)
    Ze(i, e) || (i[e] = null);
  return i;
}
function gt(i) {
  const e = Bl(null);
  for (const [t, n] of Tl(i))
    Ze(i, t) && (Array.isArray(n) ? e[t] = bs(n) : n && typeof n == "object" && n.constructor === Object ? e[t] = gt(n) : e[t] = n);
  return e;
}
function Jt(i, e) {
  for (; i !== null; ) {
    const n = ps(i, e);
    if (n) {
      if (n.get)
        return Ce(n.get);
      if (typeof n.value == "function")
        return Ce(n.value);
    }
    i = fs(i);
  }
  function t() {
    return null;
  }
  return t;
}
const wa = Ae(["a", "abbr", "acronym", "address", "area", "article", "aside", "audio", "b", "bdi", "bdo", "big", "blink", "blockquote", "body", "br", "button", "canvas", "caption", "center", "cite", "code", "col", "colgroup", "content", "data", "datalist", "dd", "decorator", "del", "details", "dfn", "dialog", "dir", "div", "dl", "dt", "element", "em", "fieldset", "figcaption", "figure", "font", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "i", "img", "input", "ins", "kbd", "label", "legend", "li", "main", "map", "mark", "marquee", "menu", "menuitem", "meter", "nav", "nobr", "ol", "optgroup", "option", "output", "p", "picture", "pre", "progress", "q", "rp", "rt", "ruby", "s", "samp", "section", "select", "shadow", "small", "source", "spacer", "span", "strike", "strong", "style", "sub", "summary", "sup", "table", "tbody", "td", "template", "textarea", "tfoot", "th", "thead", "time", "tr", "track", "tt", "u", "ul", "var", "video", "wbr"]), Wn = Ae(["svg", "a", "altglyph", "altglyphdef", "altglyphitem", "animatecolor", "animatemotion", "animatetransform", "circle", "clippath", "defs", "desc", "ellipse", "filter", "font", "g", "glyph", "glyphref", "hkern", "image", "line", "lineargradient", "marker", "mask", "metadata", "mpath", "path", "pattern", "polygon", "polyline", "radialgradient", "rect", "stop", "style", "switch", "symbol", "text", "textpath", "title", "tref", "tspan", "view", "vkern"]), Zn = Ae(["feBlend", "feColorMatrix", "feComponentTransfer", "feComposite", "feConvolveMatrix", "feDiffuseLighting", "feDisplacementMap", "feDistantLight", "feDropShadow", "feFlood", "feFuncA", "feFuncB", "feFuncG", "feFuncR", "feGaussianBlur", "feImage", "feMerge", "feMergeNode", "feMorphology", "feOffset", "fePointLight", "feSpecularLighting", "feSpotLight", "feTile", "feTurbulence"]), ys = Ae(["animate", "color-profile", "cursor", "discard", "font-face", "font-face-format", "font-face-name", "font-face-src", "font-face-uri", "foreignobject", "hatch", "hatchpath", "mesh", "meshgradient", "meshpatch", "meshrow", "missing-glyph", "script", "set", "solidcolor", "unknown", "use"]), Yn = Ae(["math", "menclose", "merror", "mfenced", "mfrac", "mglyph", "mi", "mlabeledtr", "mmultiscripts", "mn", "mo", "mover", "mpadded", "mphantom", "mroot", "mrow", "ms", "mspace", "msqrt", "mstyle", "msub", "msup", "msubsup", "mtable", "mtd", "mtext", "mtr", "munder", "munderover", "mprescripts"]), ws = Ae(["maction", "maligngroup", "malignmark", "mlongdiv", "mscarries", "mscarry", "msgroup", "mstack", "msline", "msrow", "semantics", "annotation", "annotation-xml", "mprescripts", "none"]), Fa = Ae(["#text"]), ka = Ae(["accept", "action", "align", "alt", "autocapitalize", "autocomplete", "autopictureinpicture", "autoplay", "background", "bgcolor", "border", "capture", "cellpadding", "cellspacing", "checked", "cite", "class", "clear", "color", "cols", "colspan", "controls", "controlslist", "coords", "crossorigin", "datetime", "decoding", "default", "dir", "disabled", "disablepictureinpicture", "disableremoteplayback", "download", "draggable", "enctype", "enterkeyhint", "face", "for", "headers", "height", "hidden", "high", "href", "hreflang", "id", "inputmode", "integrity", "ismap", "kind", "label", "lang", "list", "loading", "loop", "low", "max", "maxlength", "media", "method", "min", "minlength", "multiple", "muted", "name", "nonce", "noshade", "novalidate", "nowrap", "open", "optimum", "pattern", "placeholder", "playsinline", "popover", "popovertarget", "popovertargetaction", "poster", "preload", "pubdate", "radiogroup", "readonly", "rel", "required", "rev", "reversed", "role", "rows", "rowspan", "spellcheck", "scope", "selected", "shape", "size", "sizes", "span", "srclang", "start", "src", "srcset", "step", "style", "summary", "tabindex", "title", "translate", "type", "usemap", "valign", "value", "width", "wrap", "xmlns", "slot"]), Xn = Ae(["accent-height", "accumulate", "additive", "alignment-baseline", "amplitude", "ascent", "attributename", "attributetype", "azimuth", "basefrequency", "baseline-shift", "begin", "bias", "by", "class", "clip", "clippathunits", "clip-path", "clip-rule", "color", "color-interpolation", "color-interpolation-filters", "color-profile", "color-rendering", "cx", "cy", "d", "dx", "dy", "diffuseconstant", "direction", "display", "divisor", "dur", "edgemode", "elevation", "end", "exponent", "fill", "fill-opacity", "fill-rule", "filter", "filterunits", "flood-color", "flood-opacity", "font-family", "font-size", "font-size-adjust", "font-stretch", "font-style", "font-variant", "font-weight", "fx", "fy", "g1", "g2", "glyph-name", "glyphref", "gradientunits", "gradienttransform", "height", "href", "id", "image-rendering", "in", "in2", "intercept", "k", "k1", "k2", "k3", "k4", "kerning", "keypoints", "keysplines", "keytimes", "lang", "lengthadjust", "letter-spacing", "kernelmatrix", "kernelunitlength", "lighting-color", "local", "marker-end", "marker-mid", "marker-start", "markerheight", "markerunits", "markerwidth", "maskcontentunits", "maskunits", "max", "mask", "media", "method", "mode", "min", "name", "numoctaves", "offset", "operator", "opacity", "order", "orient", "orientation", "origin", "overflow", "paint-order", "path", "pathlength", "patterncontentunits", "patterntransform", "patternunits", "points", "preservealpha", "preserveaspectratio", "primitiveunits", "r", "rx", "ry", "radius", "refx", "refy", "repeatcount", "repeatdur", "restart", "result", "rotate", "scale", "seed", "shape-rendering", "slope", "specularconstant", "specularexponent", "spreadmethod", "startoffset", "stddeviation", "stitchtiles", "stop-color", "stop-opacity", "stroke-dasharray", "stroke-dashoffset", "stroke-linecap", "stroke-linejoin", "stroke-miterlimit", "stroke-opacity", "stroke", "stroke-width", "style", "surfacescale", "systemlanguage", "tabindex", "tablevalues", "targetx", "targety", "transform", "transform-origin", "text-anchor", "text-decoration", "text-rendering", "textlength", "type", "u1", "u2", "unicode", "values", "viewbox", "visibility", "version", "vert-adv-y", "vert-origin-x", "vert-origin-y", "width", "word-spacing", "wrap", "writing-mode", "xchannelselector", "ychannelselector", "x", "x1", "x2", "xmlns", "y", "y1", "y2", "z", "zoomandpan"]), $a = Ae(["accent", "accentunder", "align", "bevelled", "close", "columnsalign", "columnlines", "columnspan", "denomalign", "depth", "dir", "display", "displaystyle", "encoding", "fence", "frame", "height", "href", "id", "largeop", "length", "linethickness", "lspace", "lquote", "mathbackground", "mathcolor", "mathsize", "mathvariant", "maxsize", "minsize", "movablelimits", "notation", "numalign", "open", "rowalign", "rowlines", "rowspacing", "rowspan", "rspace", "rquote", "scriptlevel", "scriptminsize", "scriptsizemultiplier", "selection", "separator", "separators", "stretchy", "subscriptshift", "supscriptshift", "symmetric", "voffset", "width", "xmlns"]), kn = Ae(["xlink:href", "xml:id", "xlink:title", "xml:space", "xmlns:xlink"]), Fs = He(/\{\{[\w\W]*|[\w\W]*\}\}/gm), ks = He(/<%[\w\W]*|[\w\W]*%>/gm), $s = He(/\$\{[\w\W]*/gm), Es = He(/^data-[\-\w.\u00B7-\uFFFF]+$/), As = He(/^aria-[\-\w]+$/), Rl = He(
  /^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp|matrix):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i
  // eslint-disable-line no-useless-escape
), Cs = He(/^(?:\w+script|data):/i), Ss = He(
  /[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g
  // eslint-disable-line no-control-regex
), Il = He(/^html$/i), Ts = He(/^[a-z][.\w]*(-[.\w]+)+$/i);
var Ea = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  ARIA_ATTR: As,
  ATTR_WHITESPACE: Ss,
  CUSTOM_ELEMENT: Ts,
  DATA_ATTR: Es,
  DOCTYPE_NAME: Il,
  ERB_EXPR: ks,
  IS_ALLOWED_URI: Rl,
  IS_SCRIPT_OR_DATA: Cs,
  MUSTACHE_EXPR: Fs,
  TMPLIT_EXPR: $s
});
const en = {
  element: 1,
  text: 3,
  // Deprecated
  progressingInstruction: 7,
  comment: 8,
  document: 9
}, Bs = function() {
  return typeof window > "u" ? null : window;
}, Rs = function(e, t) {
  if (typeof e != "object" || typeof e.createPolicy != "function")
    return null;
  let n = null;
  const a = "data-tt-policy-suffix";
  t && t.hasAttribute(a) && (n = t.getAttribute(a));
  const o = "dompurify" + (n ? "#" + n : "");
  try {
    return e.createPolicy(o, {
      createHTML(l) {
        return l;
      },
      createScriptURL(l) {
        return l;
      }
    });
  } catch {
    return console.warn("TrustedTypes policy " + o + " could not be created."), null;
  }
}, Aa = function() {
  return {
    afterSanitizeAttributes: [],
    afterSanitizeElements: [],
    afterSanitizeShadowDOM: [],
    beforeSanitizeAttributes: [],
    beforeSanitizeElements: [],
    beforeSanitizeShadowDOM: [],
    uponSanitizeAttribute: [],
    uponSanitizeElement: [],
    uponSanitizeShadowNode: []
  };
};
function Ll() {
  let i = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : Bs();
  const e = (O) => Ll(O);
  if (e.version = "3.2.6", e.removed = [], !i || !i.document || i.document.nodeType !== en.document || !i.Element)
    return e.isSupported = !1, e;
  let {
    document: t
  } = i;
  const n = t, a = n.currentScript, {
    DocumentFragment: o,
    HTMLTemplateElement: l,
    Node: r,
    Element: s,
    NodeFilter: u,
    NamedNodeMap: c = i.NamedNodeMap || i.MozNamedAttrMap,
    HTMLFormElement: h,
    DOMParser: d,
    trustedTypes: f
  } = i, v = s.prototype, b = Jt(v, "cloneNode"), w = Jt(v, "remove"), k = Jt(v, "nextSibling"), m = Jt(v, "childNodes"), _ = Jt(v, "parentNode");
  if (typeof l == "function") {
    const O = t.createElement("template");
    O.content && O.content.ownerDocument && (t = O.content.ownerDocument);
  }
  let g, y = "";
  const {
    implementation: F,
    createNodeIterator: C,
    createDocumentFragment: T,
    getElementsByTagName: S
  } = t, {
    importNode: z
  } = n;
  let N = Aa();
  e.isSupported = typeof Tl == "function" && typeof _ == "function" && F && F.createHTMLDocument !== void 0;
  const {
    MUSTACHE_EXPR: j,
    ERB_EXPR: ke,
    TMPLIT_EXPR: ue,
    DATA_ATTR: $e,
    ARIA_ATTR: _e,
    IS_SCRIPT_OR_DATA: ne,
    ATTR_WHITESPACE: X,
    CUSTOM_ELEMENT: se
  } = Ea;
  let {
    IS_ALLOWED_URI: ve
  } = Ea, $ = null;
  const oe = P({}, [...wa, ...Wn, ...Zn, ...Yn, ...Fa]);
  let K = null;
  const de = P({}, [...ka, ...Xn, ...$a, ...kn]);
  let A = Object.seal(Bl(null, {
    tagNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    attributeNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    allowCustomizedBuiltInElements: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: !1
    }
  })), Se = null, Ke = null, Dt = !0, bt = !0, yt = !1, _t = !0, Qe = !1, Je = !0, dt = !1, Ht = !1, jt = !1, wt = !1, Rt = !1, It = !1, cn = !0, _n = !1;
  const Ln = "user-content-";
  let Gt = !0, $t = !1, D = {}, I = null;
  const Q = P({}, ["annotation-xml", "audio", "colgroup", "desc", "foreignobject", "head", "iframe", "math", "mi", "mn", "mo", "ms", "mtext", "noembed", "noframes", "noscript", "plaintext", "script", "style", "svg", "template", "thead", "title", "video", "xmp"]);
  let re = null;
  const qe = P({}, ["audio", "video", "img", "source", "image", "track"]);
  let ft = null;
  const Et = P({}, ["alt", "class", "for", "id", "label", "name", "pattern", "placeholder", "role", "summary", "title", "value", "style", "xmlns"]), Lt = "http://www.w3.org/1998/Math/MathML", Ot = "http://www.w3.org/2000/svg", Ie = "http://www.w3.org/1999/xhtml";
  let Te = Ie, At = !1, On = null;
  const Hl = P({}, [Lt, Ot, Ie], Vn);
  let dn = P({}, ["mi", "mo", "mn", "ms", "mtext"]), fn = P({}, ["annotation-xml"]);
  const jl = P({}, ["title", "style", "font", "a", "script"]);
  let Vt = null;
  const Gl = ["application/xhtml+xml", "text/html"], Vl = "text/html";
  let fe = null, qt = null;
  const Wl = t.createElement("form"), Di = function(p) {
    return p instanceof RegExp || p instanceof Function;
  }, qn = function() {
    let p = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    if (!(qt && qt === p)) {
      if ((!p || typeof p != "object") && (p = {}), p = gt(p), Vt = // eslint-disable-next-line unicorn/prefer-includes
      Gl.indexOf(p.PARSER_MEDIA_TYPE) === -1 ? Vl : p.PARSER_MEDIA_TYPE, fe = Vt === "application/xhtml+xml" ? Vn : An, $ = Ze(p, "ALLOWED_TAGS") ? P({}, p.ALLOWED_TAGS, fe) : oe, K = Ze(p, "ALLOWED_ATTR") ? P({}, p.ALLOWED_ATTR, fe) : de, On = Ze(p, "ALLOWED_NAMESPACES") ? P({}, p.ALLOWED_NAMESPACES, Vn) : Hl, ft = Ze(p, "ADD_URI_SAFE_ATTR") ? P(gt(Et), p.ADD_URI_SAFE_ATTR, fe) : Et, re = Ze(p, "ADD_DATA_URI_TAGS") ? P(gt(qe), p.ADD_DATA_URI_TAGS, fe) : qe, I = Ze(p, "FORBID_CONTENTS") ? P({}, p.FORBID_CONTENTS, fe) : Q, Se = Ze(p, "FORBID_TAGS") ? P({}, p.FORBID_TAGS, fe) : gt({}), Ke = Ze(p, "FORBID_ATTR") ? P({}, p.FORBID_ATTR, fe) : gt({}), D = Ze(p, "USE_PROFILES") ? p.USE_PROFILES : !1, Dt = p.ALLOW_ARIA_ATTR !== !1, bt = p.ALLOW_DATA_ATTR !== !1, yt = p.ALLOW_UNKNOWN_PROTOCOLS || !1, _t = p.ALLOW_SELF_CLOSE_IN_ATTR !== !1, Qe = p.SAFE_FOR_TEMPLATES || !1, Je = p.SAFE_FOR_XML !== !1, dt = p.WHOLE_DOCUMENT || !1, wt = p.RETURN_DOM || !1, Rt = p.RETURN_DOM_FRAGMENT || !1, It = p.RETURN_TRUSTED_TYPE || !1, jt = p.FORCE_BODY || !1, cn = p.SANITIZE_DOM !== !1, _n = p.SANITIZE_NAMED_PROPS || !1, Gt = p.KEEP_CONTENT !== !1, $t = p.IN_PLACE || !1, ve = p.ALLOWED_URI_REGEXP || Rl, Te = p.NAMESPACE || Ie, dn = p.MATHML_TEXT_INTEGRATION_POINTS || dn, fn = p.HTML_INTEGRATION_POINTS || fn, A = p.CUSTOM_ELEMENT_HANDLING || {}, p.CUSTOM_ELEMENT_HANDLING && Di(p.CUSTOM_ELEMENT_HANDLING.tagNameCheck) && (A.tagNameCheck = p.CUSTOM_ELEMENT_HANDLING.tagNameCheck), p.CUSTOM_ELEMENT_HANDLING && Di(p.CUSTOM_ELEMENT_HANDLING.attributeNameCheck) && (A.attributeNameCheck = p.CUSTOM_ELEMENT_HANDLING.attributeNameCheck), p.CUSTOM_ELEMENT_HANDLING && typeof p.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements == "boolean" && (A.allowCustomizedBuiltInElements = p.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements), Qe && (bt = !1), Rt && (wt = !0), D && ($ = P({}, Fa), K = [], D.html === !0 && (P($, wa), P(K, ka)), D.svg === !0 && (P($, Wn), P(K, Xn), P(K, kn)), D.svgFilters === !0 && (P($, Zn), P(K, Xn), P(K, kn)), D.mathMl === !0 && (P($, Yn), P(K, $a), P(K, kn))), p.ADD_TAGS && ($ === oe && ($ = gt($)), P($, p.ADD_TAGS, fe)), p.ADD_ATTR && (K === de && (K = gt(K)), P(K, p.ADD_ATTR, fe)), p.ADD_URI_SAFE_ATTR && P(ft, p.ADD_URI_SAFE_ATTR, fe), p.FORBID_CONTENTS && (I === Q && (I = gt(I)), P(I, p.FORBID_CONTENTS, fe)), Gt && ($["#text"] = !0), dt && P($, ["html", "head", "body"]), $.table && (P($, ["tbody"]), delete Se.tbody), p.TRUSTED_TYPES_POLICY) {
        if (typeof p.TRUSTED_TYPES_POLICY.createHTML != "function")
          throw Qt('TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.');
        if (typeof p.TRUSTED_TYPES_POLICY.createScriptURL != "function")
          throw Qt('TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.');
        g = p.TRUSTED_TYPES_POLICY, y = g.createHTML("");
      } else
        g === void 0 && (g = Rs(f, a)), g !== null && typeof y == "string" && (y = g.createHTML(""));
      Ae && Ae(p), qt = p;
    }
  }, bi = P({}, [...Wn, ...Zn, ...ys]), yi = P({}, [...Yn, ...ws]), Zl = function(p) {
    let E = _(p);
    (!E || !E.tagName) && (E = {
      namespaceURI: Te,
      tagName: "template"
    });
    const B = An(p.tagName), te = An(E.tagName);
    return On[p.namespaceURI] ? p.namespaceURI === Ot ? E.namespaceURI === Ie ? B === "svg" : E.namespaceURI === Lt ? B === "svg" && (te === "annotation-xml" || dn[te]) : !!bi[B] : p.namespaceURI === Lt ? E.namespaceURI === Ie ? B === "math" : E.namespaceURI === Ot ? B === "math" && fn[te] : !!yi[B] : p.namespaceURI === Ie ? E.namespaceURI === Ot && !fn[te] || E.namespaceURI === Lt && !dn[te] ? !1 : !yi[B] && (jl[B] || !bi[B]) : !!(Vt === "application/xhtml+xml" && On[p.namespaceURI]) : !1;
  }, et = function(p) {
    Xt(e.removed, {
      element: p
    });
    try {
      _(p).removeChild(p);
    } catch {
      w(p);
    }
  }, Nt = function(p, E) {
    try {
      Xt(e.removed, {
        attribute: E.getAttributeNode(p),
        from: E
      });
    } catch {
      Xt(e.removed, {
        attribute: null,
        from: E
      });
    }
    if (E.removeAttribute(p), p === "is")
      if (wt || Rt)
        try {
          et(E);
        } catch {
        }
      else
        try {
          E.setAttribute(p, "");
        } catch {
        }
  }, wi = function(p) {
    let E = null, B = null;
    if (jt)
      p = "<remove></remove>" + p;
    else {
      const ce = ya(p, /^[\r\n\t ]+/);
      B = ce && ce[0];
    }
    Vt === "application/xhtml+xml" && Te === Ie && (p = '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>' + p + "</body></html>");
    const te = g ? g.createHTML(p) : p;
    if (Te === Ie)
      try {
        E = new d().parseFromString(te, Vt);
      } catch {
      }
    if (!E || !E.documentElement) {
      E = F.createDocument(Te, "template", null);
      try {
        E.documentElement.innerHTML = At ? y : te;
      } catch {
      }
    }
    const De = E.body || E.documentElement;
    return p && B && De.insertBefore(t.createTextNode(B), De.childNodes[0] || null), Te === Ie ? S.call(E, dt ? "html" : "body")[0] : dt ? E.documentElement : De;
  }, Fi = function(p) {
    return C.call(
      p.ownerDocument || p,
      p,
      // eslint-disable-next-line no-bitwise
      u.SHOW_ELEMENT | u.SHOW_COMMENT | u.SHOW_TEXT | u.SHOW_PROCESSING_INSTRUCTION | u.SHOW_CDATA_SECTION,
      null
    );
  }, Nn = function(p) {
    return p instanceof h && (typeof p.nodeName != "string" || typeof p.textContent != "string" || typeof p.removeChild != "function" || !(p.attributes instanceof c) || typeof p.removeAttribute != "function" || typeof p.setAttribute != "function" || typeof p.namespaceURI != "string" || typeof p.insertBefore != "function" || typeof p.hasChildNodes != "function");
  }, ki = function(p) {
    return typeof r == "function" && p instanceof r;
  };
  function pt(O, p, E) {
    Fn(O, (B) => {
      B.call(e, p, E, qt);
    });
  }
  const $i = function(p) {
    let E = null;
    if (pt(N.beforeSanitizeElements, p, null), Nn(p))
      return et(p), !0;
    const B = fe(p.nodeName);
    if (pt(N.uponSanitizeElement, p, {
      tagName: B,
      allowedTags: $
    }), Je && p.hasChildNodes() && !ki(p.firstElementChild) && Ee(/<[/\w!]/g, p.innerHTML) && Ee(/<[/\w!]/g, p.textContent) || p.nodeType === en.progressingInstruction || Je && p.nodeType === en.comment && Ee(/<[/\w]/g, p.data))
      return et(p), !0;
    if (!$[B] || Se[B]) {
      if (!Se[B] && Ai(B) && (A.tagNameCheck instanceof RegExp && Ee(A.tagNameCheck, B) || A.tagNameCheck instanceof Function && A.tagNameCheck(B)))
        return !1;
      if (Gt && !I[B]) {
        const te = _(p) || p.parentNode, De = m(p) || p.childNodes;
        if (De && te) {
          const ce = De.length;
          for (let Be = ce - 1; Be >= 0; --Be) {
            const ht = b(De[Be], !0);
            ht.__removalCount = (p.__removalCount || 0) + 1, te.insertBefore(ht, k(p));
          }
        }
      }
      return et(p), !0;
    }
    return p instanceof s && !Zl(p) || (B === "noscript" || B === "noembed" || B === "noframes") && Ee(/<\/no(script|embed|frames)/i, p.innerHTML) ? (et(p), !0) : (Qe && p.nodeType === en.text && (E = p.textContent, Fn([j, ke, ue], (te) => {
      E = Kt(E, te, " ");
    }), p.textContent !== E && (Xt(e.removed, {
      element: p.cloneNode()
    }), p.textContent = E)), pt(N.afterSanitizeElements, p, null), !1);
  }, Ei = function(p, E, B) {
    if (cn && (E === "id" || E === "name") && (B in t || B in Wl))
      return !1;
    if (!(bt && !Ke[E] && Ee($e, E))) {
      if (!(Dt && Ee(_e, E))) {
        if (!K[E] || Ke[E]) {
          if (
            // First condition does a very basic check if a) it's basically a valid custom element tagname AND
            // b) if the tagName passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            // and c) if the attribute name passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.attributeNameCheck
            !(Ai(p) && (A.tagNameCheck instanceof RegExp && Ee(A.tagNameCheck, p) || A.tagNameCheck instanceof Function && A.tagNameCheck(p)) && (A.attributeNameCheck instanceof RegExp && Ee(A.attributeNameCheck, E) || A.attributeNameCheck instanceof Function && A.attributeNameCheck(E)) || // Alternative, second condition checks if it's an `is`-attribute, AND
            // the value passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            E === "is" && A.allowCustomizedBuiltInElements && (A.tagNameCheck instanceof RegExp && Ee(A.tagNameCheck, B) || A.tagNameCheck instanceof Function && A.tagNameCheck(B)))
          ) return !1;
        } else if (!ft[E]) {
          if (!Ee(ve, Kt(B, X, ""))) {
            if (!((E === "src" || E === "xlink:href" || E === "href") && p !== "script" && gs(B, "data:") === 0 && re[p])) {
              if (!(yt && !Ee(ne, Kt(B, X, "")))) {
                if (B)
                  return !1;
              }
            }
          }
        }
      }
    }
    return !0;
  }, Ai = function(p) {
    return p !== "annotation-xml" && ya(p, se);
  }, Ci = function(p) {
    pt(N.beforeSanitizeAttributes, p, null);
    const {
      attributes: E
    } = p;
    if (!E || Nn(p))
      return;
    const B = {
      attrName: "",
      attrValue: "",
      keepAttr: !0,
      allowedAttributes: K,
      forceKeepAttr: void 0
    };
    let te = E.length;
    for (; te--; ) {
      const De = E[te], {
        name: ce,
        namespaceURI: Be,
        value: ht
      } = De, Wt = fe(ce), zn = ht;
      let be = ce === "value" ? zn : vs(zn);
      if (B.attrName = Wt, B.attrValue = be, B.keepAttr = !0, B.forceKeepAttr = void 0, pt(N.uponSanitizeAttribute, p, B), be = B.attrValue, _n && (Wt === "id" || Wt === "name") && (Nt(ce, p), be = Ln + be), Je && Ee(/((--!?|])>)|<\/(style|title)/i, be)) {
        Nt(ce, p);
        continue;
      }
      if (B.forceKeepAttr)
        continue;
      if (!B.keepAttr) {
        Nt(ce, p);
        continue;
      }
      if (!_t && Ee(/\/>/i, be)) {
        Nt(ce, p);
        continue;
      }
      Qe && Fn([j, ke, ue], (Ti) => {
        be = Kt(be, Ti, " ");
      });
      const Si = fe(p.nodeName);
      if (!Ei(Si, Wt, be)) {
        Nt(ce, p);
        continue;
      }
      if (g && typeof f == "object" && typeof f.getAttributeType == "function" && !Be)
        switch (f.getAttributeType(Si, Wt)) {
          case "TrustedHTML": {
            be = g.createHTML(be);
            break;
          }
          case "TrustedScriptURL": {
            be = g.createScriptURL(be);
            break;
          }
        }
      if (be !== zn)
        try {
          Be ? p.setAttributeNS(Be, ce, be) : p.setAttribute(ce, be), Nn(p) ? et(p) : ba(e.removed);
        } catch {
          Nt(ce, p);
        }
    }
    pt(N.afterSanitizeAttributes, p, null);
  }, Yl = function O(p) {
    let E = null;
    const B = Fi(p);
    for (pt(N.beforeSanitizeShadowDOM, p, null); E = B.nextNode(); )
      pt(N.uponSanitizeShadowNode, E, null), $i(E), Ci(E), E.content instanceof o && O(E.content);
    pt(N.afterSanitizeShadowDOM, p, null);
  };
  return e.sanitize = function(O) {
    let p = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, E = null, B = null, te = null, De = null;
    if (At = !O, At && (O = "<!-->"), typeof O != "string" && !ki(O))
      if (typeof O.toString == "function") {
        if (O = O.toString(), typeof O != "string")
          throw Qt("dirty is not a string, aborting");
      } else
        throw Qt("toString is not a function");
    if (!e.isSupported)
      return O;
    if (Ht || qn(p), e.removed = [], typeof O == "string" && ($t = !1), $t) {
      if (O.nodeName) {
        const ht = fe(O.nodeName);
        if (!$[ht] || Se[ht])
          throw Qt("root node is forbidden and cannot be sanitized in-place");
      }
    } else if (O instanceof r)
      E = wi("<!---->"), B = E.ownerDocument.importNode(O, !0), B.nodeType === en.element && B.nodeName === "BODY" || B.nodeName === "HTML" ? E = B : E.appendChild(B);
    else {
      if (!wt && !Qe && !dt && // eslint-disable-next-line unicorn/prefer-includes
      O.indexOf("<") === -1)
        return g && It ? g.createHTML(O) : O;
      if (E = wi(O), !E)
        return wt ? null : It ? y : "";
    }
    E && jt && et(E.firstChild);
    const ce = Fi($t ? O : E);
    for (; te = ce.nextNode(); )
      $i(te), Ci(te), te.content instanceof o && Yl(te.content);
    if ($t)
      return O;
    if (wt) {
      if (Rt)
        for (De = T.call(E.ownerDocument); E.firstChild; )
          De.appendChild(E.firstChild);
      else
        De = E;
      return (K.shadowroot || K.shadowrootmode) && (De = z.call(n, De, !0)), De;
    }
    let Be = dt ? E.outerHTML : E.innerHTML;
    return dt && $["!doctype"] && E.ownerDocument && E.ownerDocument.doctype && E.ownerDocument.doctype.name && Ee(Il, E.ownerDocument.doctype.name) && (Be = "<!DOCTYPE " + E.ownerDocument.doctype.name + `>
` + Be), Qe && Fn([j, ke, ue], (ht) => {
      Be = Kt(Be, ht, " ");
    }), g && It ? g.createHTML(Be) : Be;
  }, e.setConfig = function() {
    let O = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    qn(O), Ht = !0;
  }, e.clearConfig = function() {
    qt = null, Ht = !1;
  }, e.isValidAttribute = function(O, p, E) {
    qt || qn({});
    const B = fe(O), te = fe(p);
    return Ei(B, te, E);
  }, e.addHook = function(O, p) {
    typeof p == "function" && Xt(N[O], p);
  }, e.removeHook = function(O, p) {
    if (p !== void 0) {
      const E = hs(N[O], p);
      return E === -1 ? void 0 : ms(N[O], E, 1)[0];
    }
    return ba(N[O]);
  }, e.removeHooks = function(O) {
    N[O] = [];
  }, e.removeAllHooks = function() {
    N = Aa();
  }, e;
}
Ll();
const {
  HtmlTagHydration: a$,
  SvelteComponent: l$,
  add_render_callback: o$,
  append_hydration: r$,
  attr: s$,
  bubble: u$,
  check_outros: c$,
  children: _$,
  claim_component: d$,
  claim_element: f$,
  claim_html_tag: p$,
  claim_space: h$,
  claim_text: m$,
  create_component: g$,
  create_in_transition: v$,
  create_out_transition: D$,
  destroy_component: b$,
  detach: y$,
  element: w$,
  get_svelte_dataset: F$,
  group_outros: k$,
  init: $$,
  insert_hydration: E$,
  listen: A$,
  mount_component: C$,
  run_all: S$,
  safe_not_equal: T$,
  set_data: B$,
  space: R$,
  stop_propagation: I$,
  text: L$,
  toggle_class: O$,
  transition_in: q$,
  transition_out: N$
} = window.__gradio__svelte__internal, { createEventDispatcher: z$, onMount: M$ } = window.__gradio__svelte__internal, {
  SvelteComponent: P$,
  append_hydration: x$,
  attr: U$,
  bubble: H$,
  check_outros: j$,
  children: G$,
  claim_component: V$,
  claim_element: W$,
  claim_space: Z$,
  create_animation: Y$,
  create_component: X$,
  destroy_component: K$,
  detach: Q$,
  element: J$,
  ensure_array_like: eE,
  fix_and_outro_and_destroy_block: tE,
  fix_position: nE,
  group_outros: iE,
  init: aE,
  insert_hydration: lE,
  mount_component: oE,
  noop: rE,
  safe_not_equal: sE,
  set_style: uE,
  space: cE,
  transition_in: _E,
  transition_out: dE,
  update_keyed_each: fE
} = window.__gradio__svelte__internal, {
  SvelteComponent: pE,
  attr: hE,
  children: mE,
  claim_element: gE,
  detach: vE,
  element: DE,
  empty: bE,
  init: yE,
  insert_hydration: wE,
  noop: FE,
  safe_not_equal: kE,
  set_style: $E
} = window.__gradio__svelte__internal, {
  SvelteComponent: Is,
  append_hydration: x,
  assign: Ls,
  attr: L,
  binding_callbacks: Os,
  check_outros: qs,
  children: J,
  claim_component: Ol,
  claim_element: U,
  claim_space: me,
  claim_text: ut,
  create_component: ql,
  destroy_block: Nl,
  destroy_component: zl,
  destroy_each: Ml,
  detach: R,
  element: H,
  empty: he,
  ensure_array_like: kt,
  get_spread_object: Ns,
  get_spread_update: zs,
  get_svelte_dataset: Pl,
  group_outros: Ms,
  init: Ps,
  init_binding_group_dynamic: xs,
  insert_hydration: G,
  listen: le,
  mount_component: xl,
  run_all: Ut,
  safe_not_equal: Us,
  select_option: Ca,
  set_data: vt,
  set_input_value: Re,
  set_style: Pt,
  space: ge,
  stop_propagation: Hs,
  text: ct,
  to_number: _i,
  toggle_class: Fe,
  transition_in: on,
  transition_out: Rn,
  update_keyed_each: Ul
} = window.__gradio__svelte__internal, { onMount: js, tick: Kn } = window.__gradio__svelte__internal;
function Sa(i, e, t) {
  const n = i.slice();
  return n[59] = e[t], n[61] = t, n;
}
function Ta(i, e, t) {
  const n = i.slice();
  return n[62] = e[t], n[63] = e, n[64] = t, n;
}
function Ba(i, e, t) {
  const n = i.slice();
  return n[71] = e[t], n;
}
function Ra(i, e, t) {
  const n = i.slice();
  return n[71] = e[t], n;
}
function Qn(i) {
  const e = i.slice(), t = (
    /*prop*/
    e[62].interactive_if
  );
  e[65] = t;
  const n = (
    /*prop*/
    e[62].visible_if
  );
  e[66] = n;
  const a = (
    /*i_condition*/
    e[65] ? (
      /*get_prop_value*/
      e[23](
        /*i_condition*/
        e[65].field
      )
    ) : null
  );
  e[67] = a;
  const o = (
    /*v_condition*/
    e[66] ? (
      /*get_prop_value*/
      e[23](
        /*v_condition*/
        e[66].field
      )
    ) : null
  );
  e[68] = o;
  const l = (
    /*interactive*/
    e[13] && (/*i_condition*/
    e[65] ? (
      /*i_condition*/
      e[65].value !== void 0 ? Array.isArray(
        /*i_condition*/
        e[65].value
      ) ? (
        /*i_condition*/
        e[65].value.includes(
          /*i_parent_value*/
          e[67]
        )
      ) : (
        /*i_parent_value*/
        e[67] === /*i_condition*/
        e[65].value
      ) : (
        /*i_condition*/
        e[65].neq !== void 0 ? (
          /*i_parent_value*/
          e[67] !== /*i_condition*/
          e[65].neq
        ) : !0
      )
    ) : !0)
  );
  e[69] = l;
  const r = (
    /*prop*/
    (e[62].visible ?? !0) && (/*v_condition*/
    e[66] ? (
      /*v_condition*/
      e[66].value !== void 0 ? Array.isArray(
        /*v_condition*/
        e[66].value
      ) ? (
        /*v_condition*/
        e[66].value.includes(
          /*v_parent_value*/
          e[68]
        )
      ) : (
        /*v_parent_value*/
        e[68] === /*v_condition*/
        e[66].value
      ) : (
        /*v_condition*/
        e[66].neq !== void 0 ? (
          /*v_parent_value*/
          e[68] !== /*v_condition*/
          e[66].neq
        ) : !0
      )
    ) : !0)
  );
  return e[70] = r, e;
}
function Ia(i) {
  let e, t;
  const n = [
    {
      autoscroll: (
        /*gradio*/
        i[14].autoscroll
      )
    },
    { i18n: (
      /*gradio*/
      i[14].i18n
    ) },
    /*loading_status*/
    i[12]
  ];
  let a = {};
  for (let o = 0; o < n.length; o += 1)
    a = Ls(a, n[o]);
  return e = new _s({ props: a }), e.$on(
    "clear_status",
    /*clear_status_handler*/
    i[30]
  ), {
    c() {
      ql(e.$$.fragment);
    },
    l(o) {
      Ol(e.$$.fragment, o);
    },
    m(o, l) {
      xl(e, o, l), t = !0;
    },
    p(o, l) {
      const r = l[0] & /*gradio, loading_status*/
      20480 ? zs(n, [
        l[0] & /*gradio*/
        16384 && {
          autoscroll: (
            /*gradio*/
            o[14].autoscroll
          )
        },
        l[0] & /*gradio*/
        16384 && { i18n: (
          /*gradio*/
          o[14].i18n
        ) },
        l[0] & /*loading_status*/
        4096 && Ns(
          /*loading_status*/
          o[12]
        )
      ]) : {};
      e.$set(r);
    },
    i(o) {
      t || (on(e.$$.fragment, o), t = !0);
    },
    o(o) {
      Rn(e.$$.fragment, o), t = !1;
    },
    d(o) {
      zl(e, o);
    }
  };
}
function La(i) {
  let e, t;
  return {
    c() {
      e = H("span"), t = ct(
        /*label*/
        i[2]
      ), this.h();
    },
    l(n) {
      e = U(n, "SPAN", { class: !0 });
      var a = J(e);
      t = ut(
        a,
        /*label*/
        i[2]
      ), a.forEach(R), this.h();
    },
    h() {
      L(e, "class", "label");
    },
    m(n, a) {
      G(n, e, a), x(e, t);
    },
    p(n, a) {
      a[0] & /*label*/
      4 && vt(
        t,
        /*label*/
        n[2]
      );
    },
    d(n) {
      n && R(e);
    }
  };
}
function Oa(i) {
  let e, t = "▼";
  return {
    c() {
      e = H("span"), e.textContent = t, this.h();
    },
    l(n) {
      e = U(n, "SPAN", { class: !0, "data-svelte-h": !0 }), Pl(e) !== "svelte-zp2qne" && (e.textContent = t), this.h();
    },
    h() {
      L(e, "class", "accordion-icon svelte-1eiz7kj"), Pt(
        e,
        "transform",
        /*open*/
        i[1] ? "rotate(0)" : "rotate(-90deg)"
      );
    },
    m(n, a) {
      G(n, e, a);
    },
    p(n, a) {
      a[0] & /*open*/
      2 && Pt(
        e,
        "transform",
        /*open*/
        n[1] ? "rotate(0)" : "rotate(-90deg)"
      );
    },
    d(n) {
      n && R(e);
    }
  };
}
function qa(i) {
  let e, t = Array.isArray(
    /*value*/
    i[0]
  ), n = t && Na(i);
  return {
    c() {
      e = H("div"), n && n.c(), this.h();
    },
    l(a) {
      e = U(a, "DIV", { class: !0, style: !0 });
      var o = J(e);
      n && n.l(o), o.forEach(R), this.h();
    },
    h() {
      L(e, "class", "container svelte-1eiz7kj"), Pt(
        e,
        "--show-group-name",
        /*value*/
        i[0].length > 1 || /*show_group_name_only_one*/
        i[3] && /*value*/
        i[0].length === 1 ? "none" : "1px solid var(--border-color-primary)"
      ), Pt(
        e,
        "--sheet-max-height",
        /*height*/
        i[11] ? `${/*height*/
        i[11]}px` : "none"
      );
    },
    m(a, o) {
      G(a, e, o), n && n.m(e, null);
    },
    p(a, o) {
      o[0] & /*value*/
      1 && (t = Array.isArray(
        /*value*/
        a[0]
      )), t ? n ? n.p(a, o) : (n = Na(a), n.c(), n.m(e, null)) : n && (n.d(1), n = null), o[0] & /*value, show_group_name_only_one*/
      9 && Pt(
        e,
        "--show-group-name",
        /*value*/
        a[0].length > 1 || /*show_group_name_only_one*/
        a[3] && /*value*/
        a[0].length === 1 ? "none" : "1px solid var(--border-color-primary)"
      ), o[0] & /*height*/
      2048 && Pt(
        e,
        "--sheet-max-height",
        /*height*/
        a[11] ? `${/*height*/
        a[11]}px` : "none"
      );
    },
    d(a) {
      a && R(e), n && n.d();
    }
  };
}
function Na(i) {
  let e = [], t = /* @__PURE__ */ new Map(), n, a = kt(
    /*value*/
    i[0]
  );
  const o = (l) => (
    /*group*/
    l[59].group_name
  );
  for (let l = 0; l < a.length; l += 1) {
    let r = Sa(i, a, l), s = o(r);
    t.set(s, e[l] = Xa(s, r));
  }
  return {
    c() {
      for (let l = 0; l < e.length; l += 1)
        e[l].c();
      n = he();
    },
    l(l) {
      for (let r = 0; r < e.length; r += 1)
        e[r].l(l);
      n = he();
    },
    m(l, r) {
      for (let s = 0; s < e.length; s += 1)
        e[s] && e[s].m(l, r);
      G(l, n, r);
    },
    p(l, r) {
      r[0] & /*value, interactive, get_prop_value, initialValues, handle_reset_prop, dispatch_update, validationState, validate_prop, sliderElements, handle_dropdown_change, groupVisibility, toggleGroup, show_group_name_only_one*/
      131571721 && (a = kt(
        /*value*/
        l[0]
      ), e = Ul(e, r, o, 1, l, a, t, n.parentNode, Nl, Xa, n, Sa));
    },
    d(l) {
      l && R(n);
      for (let r = 0; r < e.length; r += 1)
        e[r].d(l);
    }
  };
}
function za(i) {
  let e, t, n = (
    /*group*/
    i[59].group_name + ""
  ), a, o, l, r = (
    /*groupVisibility*/
    i[15][
      /*group*/
      i[59].group_name
    ] ? "−" : "+"
  ), s, u, c;
  function h() {
    return (
      /*click_handler*/
      i[31](
        /*group*/
        i[59]
      )
    );
  }
  return {
    c() {
      e = H("button"), t = H("span"), a = ct(n), o = ge(), l = H("span"), s = ct(r), this.h();
    },
    l(d) {
      e = U(d, "BUTTON", { class: !0 });
      var f = J(e);
      t = U(f, "SPAN", { class: !0 });
      var v = J(t);
      a = ut(v, n), v.forEach(R), o = me(f), l = U(f, "SPAN", { class: !0 });
      var b = J(l);
      s = ut(b, r), b.forEach(R), f.forEach(R), this.h();
    },
    h() {
      L(t, "class", "group-title"), L(l, "class", "group-toggle-icon"), L(e, "class", "group-header svelte-1eiz7kj");
    },
    m(d, f) {
      G(d, e, f), x(e, t), x(t, a), x(e, o), x(e, l), x(l, s), u || (c = le(e, "click", h), u = !0);
    },
    p(d, f) {
      i = d, f[0] & /*value*/
      1 && n !== (n = /*group*/
      i[59].group_name + "") && vt(a, n), f[0] & /*groupVisibility, value*/
      32769 && r !== (r = /*groupVisibility*/
      i[15][
        /*group*/
        i[59].group_name
      ] ? "−" : "+") && vt(s, r);
    },
    d(d) {
      d && R(e), u = !1, c();
    }
  };
}
function Ma(i) {
  let e, t = Array.isArray(
    /*group*/
    i[59].properties
  ), n, a = t && Pa(i);
  return {
    c() {
      e = H("div"), a && a.c(), n = ge(), this.h();
    },
    l(o) {
      e = U(o, "DIV", { class: !0 });
      var l = J(e);
      a && a.l(l), n = me(l), l.forEach(R), this.h();
    },
    h() {
      L(e, "class", "properties-grid svelte-1eiz7kj");
    },
    m(o, l) {
      G(o, e, l), a && a.m(e, null), x(e, n);
    },
    p(o, l) {
      l[0] & /*value*/
      1 && (t = Array.isArray(
        /*group*/
        o[59].properties
      )), t ? a ? a.p(o, l) : (a = Pa(o), a.c(), a.m(e, n)) : a && (a.d(1), a = null);
    },
    d(o) {
      o && R(e), a && a.d();
    }
  };
}
function Pa(i) {
  let e = [], t = /* @__PURE__ */ new Map(), n, a = kt(
    /*group*/
    i[59].properties
  );
  const o = (l) => (
    /*prop*/
    l[62].name
  );
  for (let l = 0; l < a.length; l += 1) {
    let r = Ta(i, a, l), s = o(r);
    t.set(s, e[l] = Ya(s, r));
  }
  return {
    c() {
      for (let l = 0; l < e.length; l += 1)
        e[l].c();
      n = he();
    },
    l(l) {
      for (let r = 0; r < e.length; r += 1)
        e[r].l(l);
      n = he();
    },
    m(l, r) {
      for (let s = 0; s < e.length; s += 1)
        e[s] && e[s].m(l, r);
      G(l, n, r);
    },
    p(l, r) {
      r[0] & /*interactive, value, get_prop_value, initialValues, handle_reset_prop, dispatch_update, validationState, validate_prop, sliderElements, handle_dropdown_change*/
      127344641 && (a = kt(
        /*group*/
        l[59].properties
      ), e = Ul(e, r, o, 1, l, a, t, n.parentNode, Nl, Ya, n, Ta));
    },
    d(l) {
      l && R(n);
      for (let r = 0; r < e.length; r += 1)
        e[r].d(l);
    }
  };
}
function xa(i) {
  let e, t = (
    /*is_visible*/
    i[70] && Ua(i)
  );
  return {
    c() {
      t && t.c(), e = he();
    },
    l(n) {
      t && t.l(n), e = he();
    },
    m(n, a) {
      t && t.m(n, a), G(n, e, a);
    },
    p(n, a) {
      /*is_visible*/
      n[70] ? t ? t.p(n, a) : (t = Ua(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && R(e), t && t.d(n);
    }
  };
}
function Ua(i) {
  let e, t, n, a = (
    /*prop*/
    i[62].label + ""
  ), o, l, r, s, u, c, h, d = (
    /*prop*/
    i[62].help && Ha(i)
  );
  function f(k, m) {
    if (
      /*prop*/
      k[62].component === "string"
    ) return Qs;
    if (
      /*prop*/
      k[62].component === "password"
    ) return Ks;
    if (
      /*prop*/
      k[62].component === "checkbox"
    ) return Xs;
    if (
      /*prop*/
      k[62].component === "number_integer" || /*prop*/
      k[62].component === "number_float"
    ) return Ys;
    if (
      /*prop*/
      k[62].component === "slider"
    ) return Zs;
    if (
      /*prop*/
      k[62].component === "colorpicker"
    ) return Ws;
    if (
      /*prop*/
      k[62].component === "dropdown"
    ) return Vs;
    if (
      /*prop*/
      k[62].component === "radio"
    ) return Gs;
  }
  let v = f(i), b = v && v(i), w = (
    /*prop*/
    i[62].component !== "checkbox" && Za(i)
  );
  return {
    c() {
      e = H("label"), t = H("div"), n = H("span"), o = ct(a), l = ge(), d && d.c(), s = ge(), u = H("div"), b && b.c(), c = ge(), w && w.c(), h = ge(), this.h();
    },
    l(k) {
      e = U(k, "LABEL", { class: !0, for: !0 });
      var m = J(e);
      t = U(m, "DIV", { class: !0 });
      var _ = J(t);
      n = U(_, "SPAN", {});
      var g = J(n);
      o = ut(g, a), g.forEach(R), l = me(_), d && d.l(_), _.forEach(R), m.forEach(R), s = me(k), u = U(k, "DIV", { class: !0 });
      var y = J(u);
      b && b.l(y), c = me(y), w && w.l(y), h = me(y), y.forEach(R), this.h();
    },
    h() {
      L(t, "class", "prop-label-wrapper svelte-1eiz7kj"), L(e, "class", "prop-label svelte-1eiz7kj"), L(e, "for", r = /*prop*/
      i[62].name), L(u, "class", "prop-control svelte-1eiz7kj");
    },
    m(k, m) {
      G(k, e, m), x(e, t), x(t, n), x(n, o), x(t, l), d && d.m(t, null), G(k, s, m), G(k, u, m), b && b.m(u, null), x(u, c), w && w.m(u, null), x(u, h);
    },
    p(k, m) {
      m[0] & /*value*/
      1 && a !== (a = /*prop*/
      k[62].label + "") && vt(o, a), /*prop*/
      k[62].help ? d ? d.p(k, m) : (d = Ha(k), d.c(), d.m(t, null)) : d && (d.d(1), d = null), m[0] & /*value*/
      1 && r !== (r = /*prop*/
      k[62].name) && L(e, "for", r), v === (v = f(k)) && b ? b.p(k, m) : (b && b.d(1), b = v && v(k), b && (b.c(), b.m(u, c))), /*prop*/
      k[62].component !== "checkbox" ? w ? w.p(k, m) : (w = Za(k), w.c(), w.m(u, h)) : w && (w.d(1), w = null);
    },
    d(k) {
      k && (R(e), R(s), R(u)), d && d.d(), b && b.d(), w && w.d();
    }
  };
}
function Ha(i) {
  let e, t, n = "?", a, o, l = (
    /*prop*/
    i[62].help + ""
  ), r;
  return {
    c() {
      e = H("div"), t = H("span"), t.textContent = n, a = ge(), o = H("span"), r = ct(l), this.h();
    },
    l(s) {
      e = U(s, "DIV", { class: !0 });
      var u = J(e);
      t = U(u, "SPAN", { class: !0, "data-svelte-h": !0 }), Pl(t) !== "svelte-fzek5l" && (t.textContent = n), a = me(u), o = U(u, "SPAN", { class: !0 });
      var c = J(o);
      r = ut(c, l), c.forEach(R), u.forEach(R), this.h();
    },
    h() {
      L(t, "class", "tooltip-icon svelte-1eiz7kj"), L(o, "class", "tooltip-text svelte-1eiz7kj"), L(e, "class", "tooltip-container svelte-1eiz7kj");
    },
    m(s, u) {
      G(s, e, u), x(e, t), x(e, a), x(e, o), x(o, r);
    },
    p(s, u) {
      u[0] & /*value*/
      1 && l !== (l = /*prop*/
      s[62].help + "") && vt(r, l);
    },
    d(s) {
      s && R(e);
    }
  };
}
function Gs(i) {
  let e, t = Array.isArray(
    /*prop*/
    i[62].choices
  ), n, a, o = t && ja(i);
  function l() {
    return (
      /*change_handler_7*/
      i[52](
        /*prop*/
        i[62]
      )
    );
  }
  return {
    c() {
      e = H("div"), o && o.c(), this.h();
    },
    l(r) {
      e = U(r, "DIV", { class: !0 });
      var s = J(e);
      o && o.l(s), s.forEach(R), this.h();
    },
    h() {
      L(e, "class", "radio-group svelte-1eiz7kj"), Fe(e, "disabled", !/*is_interactive*/
      i[69]);
    },
    m(r, s) {
      G(r, e, s), o && o.m(e, null), n || (a = le(e, "change", l), n = !0);
    },
    p(r, s) {
      i = r, s[0] & /*value*/
      1 && (t = Array.isArray(
        /*prop*/
        i[62].choices
      )), t ? o ? o.p(i, s) : (o = ja(i), o.c(), o.m(e, null)) : o && (o.d(1), o = null), s[0] & /*interactive, value, get_prop_value*/
      8396801 && Fe(e, "disabled", !/*is_interactive*/
      i[69]);
    },
    d(r) {
      r && R(e), o && o.d(), n = !1, a();
    }
  };
}
function Vs(i) {
  let e, t, n = Array.isArray(
    /*prop*/
    i[62].choices
  ), a, o, l, r, s, u, c = n && Va(i);
  function h(...d) {
    return (
      /*change_handler_6*/
      i[49](
        /*prop*/
        i[62],
        ...d
      )
    );
  }
  return {
    c() {
      e = H("div"), t = H("select"), c && c.c(), l = ge(), r = H("div"), this.h();
    },
    l(d) {
      e = U(d, "DIV", { class: !0 });
      var f = J(e);
      t = U(f, "SELECT", { class: !0 });
      var v = J(t);
      c && c.l(v), v.forEach(R), l = me(f), r = U(f, "DIV", { class: !0 }), J(r).forEach(R), f.forEach(R), this.h();
    },
    h() {
      t.disabled = a = !/*is_interactive*/
      i[69], L(t, "class", "svelte-1eiz7kj"), L(r, "class", "dropdown-arrow-icon svelte-1eiz7kj"), L(e, "class", "dropdown-wrapper svelte-1eiz7kj"), Fe(e, "disabled", !/*is_interactive*/
      i[69]);
    },
    m(d, f) {
      G(d, e, f), x(e, t), c && c.m(t, null), Ca(
        t,
        /*prop*/
        i[62].value
      ), x(e, l), x(e, r), s || (u = le(t, "change", h), s = !0);
    },
    p(d, f) {
      i = d, f[0] & /*value*/
      1 && (n = Array.isArray(
        /*prop*/
        i[62].choices
      )), n ? c ? c.p(i, f) : (c = Va(i), c.c(), c.m(t, null)) : c && (c.d(1), c = null), f[0] & /*interactive, value*/
      8193 && a !== (a = !/*is_interactive*/
      i[69]) && (t.disabled = a), f[0] & /*value*/
      1 && o !== (o = /*prop*/
      i[62].value) && Ca(
        t,
        /*prop*/
        i[62].value
      ), f[0] & /*interactive, value, get_prop_value*/
      8396801 && Fe(e, "disabled", !/*is_interactive*/
      i[69]);
    },
    d(d) {
      d && R(e), c && c.d(), s = !1, u();
    }
  };
}
function Ws(i) {
  let e, t, n, a, o, l = (
    /*prop*/
    i[62].value + ""
  ), r, s, u;
  function c() {
    i[47].call(
      t,
      /*each_value_1*/
      i[63],
      /*prop_index*/
      i[64]
    );
  }
  function h() {
    return (
      /*change_handler_5*/
      i[48](
        /*prop*/
        i[62]
      )
    );
  }
  return {
    c() {
      e = H("div"), t = H("input"), a = ge(), o = H("span"), r = ct(l), this.h();
    },
    l(d) {
      e = U(d, "DIV", { class: !0 });
      var f = J(e);
      t = U(f, "INPUT", { type: !0, class: !0 }), a = me(f), o = U(f, "SPAN", { class: !0 });
      var v = J(o);
      r = ut(v, l), v.forEach(R), f.forEach(R), this.h();
    },
    h() {
      L(t, "type", "color"), L(t, "class", "color-picker-input svelte-1eiz7kj"), t.disabled = n = !/*is_interactive*/
      i[69], L(o, "class", "color-picker-value svelte-1eiz7kj"), L(e, "class", "color-picker-container svelte-1eiz7kj"), Fe(e, "disabled", !/*is_interactive*/
      i[69]);
    },
    m(d, f) {
      G(d, e, f), x(e, t), Re(
        t,
        /*prop*/
        i[62].value
      ), x(e, a), x(e, o), x(o, r), s || (u = [
        le(t, "input", c),
        le(t, "change", h)
      ], s = !0);
    },
    p(d, f) {
      i = d, f[0] & /*interactive, value*/
      8193 && n !== (n = !/*is_interactive*/
      i[69]) && (t.disabled = n), f[0] & /*value*/
      1 && Re(
        t,
        /*prop*/
        i[62].value
      ), f[0] & /*value*/
      1 && l !== (l = /*prop*/
      i[62].value + "") && vt(r, l), f[0] & /*interactive, value, get_prop_value*/
      8396801 && Fe(e, "disabled", !/*is_interactive*/
      i[69]);
    },
    d(d) {
      d && R(e), s = !1, Ut(u);
    }
  };
}
function Zs(i) {
  let e, t, n, a, o, l, r = (
    /*prop*/
    i[62]
  ), s, u, c = (
    /*prop*/
    i[62].value + ""
  ), h, d, f;
  function v() {
    i[43].call(
      t,
      /*each_value_1*/
      i[63],
      /*prop_index*/
      i[64]
    );
  }
  const b = () => (
    /*input_binding*/
    i[44](t, r)
  ), w = () => (
    /*input_binding*/
    i[44](null, r)
  );
  function k() {
    return (
      /*input_handler_3*/
      i[45](
        /*prop*/
        i[62]
      )
    );
  }
  function m() {
    return (
      /*change_handler_4*/
      i[46](
        /*prop*/
        i[62]
      )
    );
  }
  return {
    c() {
      e = H("div"), t = H("input"), s = ge(), u = H("span"), h = ct(c), this.h();
    },
    l(_) {
      e = U(_, "DIV", { class: !0 });
      var g = J(e);
      t = U(g, "INPUT", {
        type: !0,
        min: !0,
        max: !0,
        step: !0,
        class: !0
      }), s = me(g), u = U(g, "SPAN", { class: !0 });
      var y = J(u);
      h = ut(y, c), y.forEach(R), g.forEach(R), this.h();
    },
    h() {
      L(t, "type", "range"), L(t, "min", n = /*prop*/
      i[62].minimum), L(t, "max", a = /*prop*/
      i[62].maximum), L(t, "step", o = /*prop*/
      i[62].step || 1), t.disabled = l = !/*is_interactive*/
      i[69], L(t, "class", "svelte-1eiz7kj"), L(u, "class", "slider-value svelte-1eiz7kj"), L(e, "class", "slider-container svelte-1eiz7kj"), Fe(e, "disabled", !/*is_interactive*/
      i[69]);
    },
    m(_, g) {
      G(_, e, g), x(e, t), Re(
        t,
        /*prop*/
        i[62].value
      ), b(), x(e, s), x(e, u), x(u, h), d || (f = [
        le(t, "change", v),
        le(t, "input", v),
        le(t, "input", k),
        le(t, "change", m)
      ], d = !0);
    },
    p(_, g) {
      i = _, g[0] & /*value*/
      1 && n !== (n = /*prop*/
      i[62].minimum) && L(t, "min", n), g[0] & /*value*/
      1 && a !== (a = /*prop*/
      i[62].maximum) && L(t, "max", a), g[0] & /*value*/
      1 && o !== (o = /*prop*/
      i[62].step || 1) && L(t, "step", o), g[0] & /*interactive, value*/
      8193 && l !== (l = !/*is_interactive*/
      i[69]) && (t.disabled = l), g[0] & /*value*/
      1 && Re(
        t,
        /*prop*/
        i[62].value
      ), r !== /*prop*/
      i[62] && (w(), r = /*prop*/
      i[62], b()), g[0] & /*value*/
      1 && c !== (c = /*prop*/
      i[62].value + "") && vt(h, c), g[0] & /*interactive, value, get_prop_value*/
      8396801 && Fe(e, "disabled", !/*is_interactive*/
      i[69]);
    },
    d(_) {
      _ && R(e), w(), d = !1, Ut(f);
    }
  };
}
function Ys(i) {
  let e, t, n, a, o;
  function l() {
    i[40].call(
      e,
      /*each_value_1*/
      i[63],
      /*prop_index*/
      i[64]
    );
  }
  function r() {
    return (
      /*change_handler_3*/
      i[41](
        /*prop*/
        i[62]
      )
    );
  }
  function s() {
    return (
      /*input_handler_2*/
      i[42](
        /*prop*/
        i[62]
      )
    );
  }
  return {
    c() {
      e = H("input"), this.h();
    },
    l(u) {
      e = U(u, "INPUT", { type: !0, step: !0, class: !0 }), this.h();
    },
    h() {
      L(e, "type", "number"), L(e, "step", t = /*prop*/
      i[62].step || 1), e.disabled = n = !/*is_interactive*/
      i[69], L(e, "class", "svelte-1eiz7kj"), Fe(
        e,
        "invalid",
        /*validationState*/
        i[17][
          /*prop*/
          i[62].name
        ] === !1
      ), Fe(e, "disabled", !/*is_interactive*/
      i[69]);
    },
    m(u, c) {
      G(u, e, c), Re(
        e,
        /*prop*/
        i[62].value
      ), a || (o = [
        le(e, "input", l),
        le(e, "change", r),
        le(e, "input", s)
      ], a = !0);
    },
    p(u, c) {
      i = u, c[0] & /*value*/
      1 && t !== (t = /*prop*/
      i[62].step || 1) && L(e, "step", t), c[0] & /*interactive, value*/
      8193 && n !== (n = !/*is_interactive*/
      i[69]) && (e.disabled = n), c[0] & /*value*/
      1 && _i(e.value) !== /*prop*/
      i[62].value && Re(
        e,
        /*prop*/
        i[62].value
      ), c[0] & /*validationState, value*/
      131073 && Fe(
        e,
        "invalid",
        /*validationState*/
        i[17][
          /*prop*/
          i[62].name
        ] === !1
      ), c[0] & /*interactive, value, get_prop_value*/
      8396801 && Fe(e, "disabled", !/*is_interactive*/
      i[69]);
    },
    d(u) {
      u && R(e), a = !1, Ut(o);
    }
  };
}
function Xs(i) {
  let e, t, n, a;
  function o() {
    i[38].call(
      e,
      /*each_value_1*/
      i[63],
      /*prop_index*/
      i[64]
    );
  }
  function l() {
    return (
      /*change_handler_2*/
      i[39](
        /*prop*/
        i[62]
      )
    );
  }
  return {
    c() {
      e = H("input"), this.h();
    },
    l(r) {
      e = U(r, "INPUT", { type: !0, class: !0 }), this.h();
    },
    h() {
      L(e, "type", "checkbox"), e.disabled = t = !/*is_interactive*/
      i[69], L(e, "class", "svelte-1eiz7kj");
    },
    m(r, s) {
      G(r, e, s), e.checked = /*prop*/
      i[62].value, n || (a = [
        le(e, "change", o),
        le(e, "change", l)
      ], n = !0);
    },
    p(r, s) {
      i = r, s[0] & /*interactive, value*/
      8193 && t !== (t = !/*is_interactive*/
      i[69]) && (e.disabled = t), s[0] & /*value*/
      1 && (e.checked = /*prop*/
      i[62].value);
    },
    d(r) {
      r && R(e), n = !1, Ut(a);
    }
  };
}
function Ks(i) {
  let e, t, n, a;
  function o() {
    i[35].call(
      e,
      /*each_value_1*/
      i[63],
      /*prop_index*/
      i[64]
    );
  }
  function l() {
    return (
      /*change_handler_1*/
      i[36](
        /*prop*/
        i[62]
      )
    );
  }
  function r() {
    return (
      /*input_handler_1*/
      i[37](
        /*prop*/
        i[62]
      )
    );
  }
  return {
    c() {
      e = H("input"), this.h();
    },
    l(s) {
      e = U(s, "INPUT", { type: !0, class: !0 }), this.h();
    },
    h() {
      L(e, "type", "password"), e.disabled = t = !/*is_interactive*/
      i[69], L(e, "class", "svelte-1eiz7kj");
    },
    m(s, u) {
      G(s, e, u), Re(
        e,
        /*prop*/
        i[62].value
      ), n || (a = [
        le(e, "input", o),
        le(e, "change", l),
        le(e, "input", r)
      ], n = !0);
    },
    p(s, u) {
      i = s, u[0] & /*interactive, value*/
      8193 && t !== (t = !/*is_interactive*/
      i[69]) && (e.disabled = t), u[0] & /*value*/
      1 && e.value !== /*prop*/
      i[62].value && Re(
        e,
        /*prop*/
        i[62].value
      );
    },
    d(s) {
      s && R(e), n = !1, Ut(a);
    }
  };
}
function Qs(i) {
  let e, t, n, a;
  function o() {
    i[32].call(
      e,
      /*each_value_1*/
      i[63],
      /*prop_index*/
      i[64]
    );
  }
  function l() {
    return (
      /*change_handler*/
      i[33](
        /*prop*/
        i[62]
      )
    );
  }
  function r() {
    return (
      /*input_handler*/
      i[34](
        /*prop*/
        i[62]
      )
    );
  }
  return {
    c() {
      e = H("input"), this.h();
    },
    l(s) {
      e = U(s, "INPUT", { type: !0, class: !0 }), this.h();
    },
    h() {
      L(e, "type", "text"), e.disabled = t = !/*is_interactive*/
      i[69], L(e, "class", "svelte-1eiz7kj");
    },
    m(s, u) {
      G(s, e, u), Re(
        e,
        /*prop*/
        i[62].value
      ), n || (a = [
        le(e, "input", o),
        le(e, "change", l),
        le(e, "input", r)
      ], n = !0);
    },
    p(s, u) {
      i = s, u[0] & /*interactive, value*/
      8193 && t !== (t = !/*is_interactive*/
      i[69]) && (e.disabled = t), u[0] & /*value*/
      1 && e.value !== /*prop*/
      i[62].value && Re(
        e,
        /*prop*/
        i[62].value
      );
    },
    d(s) {
      s && R(e), n = !1, Ut(a);
    }
  };
}
function ja(i) {
  let e, t = kt(
    /*prop*/
    i[62].choices
  ), n = [];
  for (let a = 0; a < t.length; a += 1)
    n[a] = Ga(Ba(i, t, a));
  return {
    c() {
      for (let a = 0; a < n.length; a += 1)
        n[a].c();
      e = he();
    },
    l(a) {
      for (let o = 0; o < n.length; o += 1)
        n[o].l(a);
      e = he();
    },
    m(a, o) {
      for (let l = 0; l < n.length; l += 1)
        n[l] && n[l].m(a, o);
      G(a, e, o);
    },
    p(a, o) {
      if (o[0] & /*value, interactive, get_prop_value*/
      8396801) {
        t = kt(
          /*prop*/
          a[62].choices
        );
        let l;
        for (l = 0; l < t.length; l += 1) {
          const r = Ba(a, t, l);
          n[l] ? n[l].p(r, o) : (n[l] = Ga(r), n[l].c(), n[l].m(e.parentNode, e));
        }
        for (; l < n.length; l += 1)
          n[l].d(1);
        n.length = t.length;
      }
    },
    d(a) {
      a && R(e), Ml(n, a);
    }
  };
}
function Ga(i) {
  let e, t, n, a, o, l = !1, r, s, u, c = (
    /*choice*/
    i[71] + ""
  ), h, d, f, v, b, w;
  function k() {
    i[50].call(
      t,
      /*each_value_1*/
      i[63],
      /*prop_index*/
      i[64]
    );
  }
  return v = xs(
    /*$$binding_groups*/
    i[51][0],
    [
      /*prop_index*/
      i[64],
      /*group_index*/
      i[61]
    ]
  ), {
    c() {
      e = H("div"), t = H("input"), s = ge(), u = H("label"), h = ct(c), f = ge(), this.h();
    },
    l(m) {
      e = U(m, "DIV", { class: !0 });
      var _ = J(e);
      t = U(_, "INPUT", {
        type: !0,
        id: !0,
        name: !0,
        class: !0
      }), s = me(_), u = U(_, "LABEL", { for: !0, class: !0 });
      var g = J(u);
      h = ut(g, c), g.forEach(R), f = me(_), _.forEach(R), this.h();
    },
    h() {
      L(t, "type", "radio"), L(t, "id", n = /*prop*/
      i[62].name + "-" + /*choice*/
      i[71]), L(t, "name", a = /*prop*/
      i[62].name), t.__value = o = /*choice*/
      i[71], Re(t, t.__value), t.disabled = r = !/*is_interactive*/
      i[69], L(t, "class", "svelte-1eiz7kj"), L(u, "for", d = /*prop*/
      i[62].name + "-" + /*choice*/
      i[71]), L(u, "class", "svelte-1eiz7kj"), L(e, "class", "radio-item svelte-1eiz7kj"), v.p(t);
    },
    m(m, _) {
      G(m, e, _), x(e, t), t.checked = t.__value === /*prop*/
      i[62].value, x(e, s), x(e, u), x(u, h), x(e, f), b || (w = le(t, "change", k), b = !0);
    },
    p(m, _) {
      i = m, _[0] & /*value*/
      1 && n !== (n = /*prop*/
      i[62].name + "-" + /*choice*/
      i[71]) && L(t, "id", n), _[0] & /*value*/
      1 && a !== (a = /*prop*/
      i[62].name) && L(t, "name", a), _[0] & /*value*/
      1 && o !== (o = /*choice*/
      i[71]) && (t.__value = o, Re(t, t.__value), l = !0), _[0] & /*interactive, value*/
      8193 && r !== (r = !/*is_interactive*/
      i[69]) && (t.disabled = r), (l || _[0] & /*value*/
      1) && (t.checked = t.__value === /*prop*/
      i[62].value), _[0] & /*value*/
      1 && c !== (c = /*choice*/
      i[71] + "") && vt(h, c), _[0] & /*value*/
      1 && d !== (d = /*prop*/
      i[62].name + "-" + /*choice*/
      i[71]) && L(u, "for", d), _[0] & /*value*/
      1 && v.u([
        /*prop_index*/
        i[64],
        /*group_index*/
        i[61]
      ]);
    },
    d(m) {
      m && R(e), v.r(), b = !1, w();
    }
  };
}
function Va(i) {
  let e, t = kt(
    /*prop*/
    i[62].choices
  ), n = [];
  for (let a = 0; a < t.length; a += 1)
    n[a] = Wa(Ra(i, t, a));
  return {
    c() {
      for (let a = 0; a < n.length; a += 1)
        n[a].c();
      e = he();
    },
    l(a) {
      for (let o = 0; o < n.length; o += 1)
        n[o].l(a);
      e = he();
    },
    m(a, o) {
      for (let l = 0; l < n.length; l += 1)
        n[l] && n[l].m(a, o);
      G(a, e, o);
    },
    p(a, o) {
      if (o[0] & /*value*/
      1) {
        t = kt(
          /*prop*/
          a[62].choices
        );
        let l;
        for (l = 0; l < t.length; l += 1) {
          const r = Ra(a, t, l);
          n[l] ? n[l].p(r, o) : (n[l] = Wa(r), n[l].c(), n[l].m(e.parentNode, e));
        }
        for (; l < n.length; l += 1)
          n[l].d(1);
        n.length = t.length;
      }
    },
    d(a) {
      a && R(e), Ml(n, a);
    }
  };
}
function Wa(i) {
  let e, t = (
    /*choice*/
    i[71] + ""
  ), n, a, o, l;
  return {
    c() {
      e = H("option"), n = ct(t), a = ge(), this.h();
    },
    l(r) {
      e = U(r, "OPTION", { class: !0 });
      var s = J(e);
      n = ut(s, t), a = me(s), s.forEach(R), this.h();
    },
    h() {
      e.__value = o = /*choice*/
      i[71], Re(e, e.__value), e.selected = l = /*prop*/
      i[62].value === /*choice*/
      i[71], L(e, "class", "svelte-1eiz7kj");
    },
    m(r, s) {
      G(r, e, s), x(e, n), x(e, a);
    },
    p(r, s) {
      s[0] & /*value*/
      1 && t !== (t = /*choice*/
      r[71] + "") && vt(n, t), s[0] & /*value*/
      1 && o !== (o = /*choice*/
      r[71]) && (e.__value = o, Re(e, e.__value)), s[0] & /*value*/
      1 && l !== (l = /*prop*/
      r[62].value === /*choice*/
      r[71]) && (e.selected = l);
    },
    d(r) {
      r && R(e);
    }
  };
}
function Za(i) {
  let e, t, n, a, o;
  function l() {
    return (
      /*click_handler_1*/
      i[53](
        /*prop*/
        i[62]
      )
    );
  }
  return {
    c() {
      e = H("button"), t = ct("↺"), this.h();
    },
    l(r) {
      e = U(r, "BUTTON", { class: !0, title: !0 });
      var s = J(e);
      t = ut(s, "↺"), s.forEach(R), this.h();
    },
    h() {
      L(e, "class", "reset-button-prop svelte-1eiz7kj"), L(e, "title", "Reset to default"), e.disabled = n = !/*is_interactive*/
      i[69], Fe(
        e,
        "visible",
        /*initialValues*/
        i[18][
          /*prop*/
          i[62].name
        ] !== /*prop*/
        i[62].value
      );
    },
    m(r, s) {
      G(r, e, s), x(e, t), a || (o = le(e, "click", Hs(l)), a = !0);
    },
    p(r, s) {
      i = r, s[0] & /*interactive, value*/
      8193 && n !== (n = !/*is_interactive*/
      i[69]) && (e.disabled = n), s[0] & /*initialValues, value*/
      262145 && Fe(
        e,
        "visible",
        /*initialValues*/
        i[18][
          /*prop*/
          i[62].name
        ] !== /*prop*/
        i[62].value
      );
    },
    d(r) {
      r && R(e), a = !1, o();
    }
  };
}
function Ya(i, e) {
  let t, n, a = (
    /*prop*/
    (e[62].visible ?? !0) && xa(Qn(e))
  );
  return {
    key: i,
    first: null,
    c() {
      t = he(), a && a.c(), n = he(), this.h();
    },
    l(o) {
      t = he(), a && a.l(o), n = he(), this.h();
    },
    h() {
      this.first = t;
    },
    m(o, l) {
      G(o, t, l), a && a.m(o, l), G(o, n, l);
    },
    p(o, l) {
      e = o, /*prop*/
      e[62].visible ?? !0 ? a ? a.p(Qn(e), l) : (a = xa(Qn(e)), a.c(), a.m(n.parentNode, n)) : a && (a.d(1), a = null);
    },
    d(o) {
      o && (R(t), R(n)), a && a.d(o);
    }
  };
}
function Xa(i, e) {
  let t, n, a, o = (
    /*value*/
    (e[0].length > 1 || /*show_group_name_only_one*/
    e[3] && /*value*/
    e[0].length === 1) && za(e)
  ), l = (
    /*groupVisibility*/
    e[15][
      /*group*/
      e[59].group_name
    ] && Ma(e)
  );
  return {
    key: i,
    first: null,
    c() {
      t = he(), o && o.c(), n = ge(), l && l.c(), a = he(), this.h();
    },
    l(r) {
      t = he(), o && o.l(r), n = me(r), l && l.l(r), a = he(), this.h();
    },
    h() {
      this.first = t;
    },
    m(r, s) {
      G(r, t, s), o && o.m(r, s), G(r, n, s), l && l.m(r, s), G(r, a, s);
    },
    p(r, s) {
      e = r, /*value*/
      e[0].length > 1 || /*show_group_name_only_one*/
      e[3] && /*value*/
      e[0].length === 1 ? o ? o.p(e, s) : (o = za(e), o.c(), o.m(n.parentNode, n)) : o && (o.d(1), o = null), /*groupVisibility*/
      e[15][
        /*group*/
        e[59].group_name
      ] ? l ? l.p(e, s) : (l = Ma(e), l.c(), l.m(a.parentNode, a)) : l && (l.d(1), l = null);
    },
    d(r) {
      r && (R(t), R(n), R(a)), o && o.d(r), l && l.d(r);
    }
  };
}
function Js(i) {
  let e, t, n, a, o, l, r, s, u = (
    /*loading_status*/
    i[12] && Ia(i)
  ), c = (
    /*label*/
    i[2] && La(i)
  ), h = !/*disable_accordion*/
  i[4] && Oa(i), d = (
    /*open*/
    i[1] && qa(i)
  );
  return {
    c() {
      u && u.c(), e = ge(), t = H("button"), c && c.c(), n = ge(), h && h.c(), a = ge(), o = H("div"), d && d.c(), this.h();
    },
    l(f) {
      u && u.l(f), e = me(f), t = U(f, "BUTTON", { class: !0 });
      var v = J(t);
      c && c.l(v), n = me(v), h && h.l(v), v.forEach(R), a = me(f), o = U(f, "DIV", { class: !0 });
      var b = J(o);
      d && d.l(b), b.forEach(R), this.h();
    },
    h() {
      L(t, "class", "accordion-header svelte-1eiz7kj"), t.disabled = /*disable_accordion*/
      i[4], L(o, "class", "content-wrapper svelte-1eiz7kj"), Fe(o, "closed", !/*open*/
      i[1]);
    },
    m(f, v) {
      u && u.m(f, v), G(f, e, v), G(f, t, v), c && c.m(t, null), x(t, n), h && h.m(t, null), G(f, a, v), G(f, o, v), d && d.m(o, null), l = !0, r || (s = le(
        t,
        "click",
        /*handle_toggle*/
        i[21]
      ), r = !0);
    },
    p(f, v) {
      /*loading_status*/
      f[12] ? u ? (u.p(f, v), v[0] & /*loading_status*/
      4096 && on(u, 1)) : (u = Ia(f), u.c(), on(u, 1), u.m(e.parentNode, e)) : u && (Ms(), Rn(u, 1, 1, () => {
        u = null;
      }), qs()), /*label*/
      f[2] ? c ? c.p(f, v) : (c = La(f), c.c(), c.m(t, n)) : c && (c.d(1), c = null), /*disable_accordion*/
      f[4] ? h && (h.d(1), h = null) : h ? h.p(f, v) : (h = Oa(f), h.c(), h.m(t, null)), (!l || v[0] & /*disable_accordion*/
      16) && (t.disabled = /*disable_accordion*/
      f[4]), /*open*/
      f[1] ? d ? d.p(f, v) : (d = qa(f), d.c(), d.m(o, null)) : d && (d.d(1), d = null), (!l || v[0] & /*open*/
      2) && Fe(o, "closed", !/*open*/
      f[1]);
    },
    i(f) {
      l || (on(u), l = !0);
    },
    o(f) {
      Rn(u), l = !1;
    },
    d(f) {
      f && (R(e), R(t), R(a), R(o)), u && u.d(f), c && c.d(), h && h.d(), d && d.d(), r = !1, s();
    }
  };
}
function eu(i) {
  let e, t;
  return e = new ho({
    props: {
      visible: (
        /*visible*/
        i[5]
      ),
      elem_id: (
        /*elem_id*/
        i[6]
      ),
      elem_classes: (
        /*final_classes*/
        i[19]
      ),
      container: (
        /*container*/
        i[7]
      ),
      scale: (
        /*scale*/
        i[8]
      ),
      min_width: (
        /*min_width*/
        i[9]
      ),
      width: (
        /*width*/
        i[10]
      ),
      $$slots: { default: [Js] },
      $$scope: { ctx: i }
    }
  }), {
    c() {
      ql(e.$$.fragment);
    },
    l(n) {
      Ol(e.$$.fragment, n);
    },
    m(n, a) {
      xl(e, n, a), t = !0;
    },
    p(n, a) {
      const o = {};
      a[0] & /*visible*/
      32 && (o.visible = /*visible*/
      n[5]), a[0] & /*elem_id*/
      64 && (o.elem_id = /*elem_id*/
      n[6]), a[0] & /*final_classes*/
      524288 && (o.elem_classes = /*final_classes*/
      n[19]), a[0] & /*container*/
      128 && (o.container = /*container*/
      n[7]), a[0] & /*scale*/
      256 && (o.scale = /*scale*/
      n[8]), a[0] & /*min_width*/
      512 && (o.min_width = /*min_width*/
      n[9]), a[0] & /*width*/
      1024 && (o.width = /*width*/
      n[10]), a[0] & /*open, value, show_group_name_only_one, height, interactive, initialValues, validationState, sliderElements, groupVisibility, disable_accordion, label, gradio, loading_status*/
      522271 | a[2] & /*$$scope*/
      16384 && (o.$$scope = { dirty: a, ctx: n }), e.$set(o);
    },
    i(n) {
      t || (on(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Rn(e.$$.fragment, n), t = !1;
    },
    d(n) {
      zl(e, n);
    }
  };
}
function Ka(i, e) {
  var t, n;
  if (!e) return;
  const a = (t = i.minimum) !== null && t !== void 0 ? t : 0, o = (n = i.maximum) !== null && n !== void 0 ? n : 100, l = Number(i.value), r = l <= a ? 0 : (l - a) * 100 / (o - a);
  e.style.setProperty("--slider-progress", `${r}%`);
}
function tu(i, e, t) {
  let n;
  var a = this && this.__awaiter || function(D, I, Q, re) {
    function qe(ft) {
      return ft instanceof Q ? ft : new Q(function(Et) {
        Et(ft);
      });
    }
    return new (Q || (Q = Promise))(function(ft, Et) {
      function Lt(Te) {
        try {
          Ie(re.next(Te));
        } catch (At) {
          Et(At);
        }
      }
      function Ot(Te) {
        try {
          Ie(re.throw(Te));
        } catch (At) {
          Et(At);
        }
      }
      function Ie(Te) {
        Te.done ? ft(Te.value) : qe(Te.value).then(Lt, Ot);
      }
      Ie((re = re.apply(D, I || [])).next());
    });
  }, o;
  let { value: l = [] } = e, { label: r = void 0 } = e, { show_group_name_only_one: s = !0 } = e, { disable_accordion: u = !1 } = e, { visible: c = !0 } = e, { open: h = !0 } = e, { elem_id: d = "" } = e, { elem_classes: f = [] } = e, { container: v = !1 } = e, { scale: b = null } = e, { min_width: w = void 0 } = e, { width: k = void 0 } = e, { height: m = void 0 } = e, { loading_status: _ = void 0 } = e, { interactive: g = !0 } = e, { gradio: y } = e, F = {}, C = {}, T = {}, S = null, z = !1, N = {};
  function j(D) {
    if (D.minimum === void 0 && D.maximum === void 0) {
      T[D.name] !== !0 && (t(17, T[D.name] = !0, T), t(17, T = Object.assign({}, T)));
      return;
    }
    const I = Number(D.value);
    let Q = !0;
    D.minimum !== void 0 && I < D.minimum && (Q = !1), D.maximum !== void 0 && I > D.maximum && (Q = !1), T[D.name] !== Q && (t(17, T[D.name] = Q, T), t(17, T = Object.assign({}, T)));
  }
  function ke() {
    if (Array.isArray(l)) {
      for (const D of l)
        if (Array.isArray(D.properties))
          for (const I of D.properties)
            I.component === "slider" && C[I.name] && Ka(I, C[I.name]);
    }
  }
  function ue() {
    t(1, h = !h), h ? y.dispatch("expand") : y.dispatch("collapse");
  }
  function $e(D) {
    t(15, F[D] = !F[D], F);
  }
  function _e(D) {
    if (!(!Array.isArray(l) || !D))
      for (const I of l) {
        if (!Array.isArray(I.properties)) continue;
        const Q = I.properties.find((re) => re.name === D);
        if (Q)
          return Q.value;
      }
  }
  function ne(D, I) {
    var Q;
    if (T[I.name] === !1)
      return;
    const re = {};
    let qe = I.value;
    !((Q = I.component) === null || Q === void 0) && Q.startsWith("number") || I.component === "slider" ? qe = Number(I.value) : I.component === "checkbox" && (qe = I.value), re[I.name] = qe, y.dispatch(D, re);
  }
  function X(D, I) {
    return a(this, void 0, void 0, function* () {
      const Q = D.target.value;
      t(0, l = l.map((re) => re.properties ? Object.assign(Object.assign({}, re), {
        properties: re.properties.map((qe) => qe.name === I.name ? Object.assign(Object.assign({}, qe), { value: Q }) : qe)
      }) : re)), yield Kn(), y.dispatch("change", l);
    });
  }
  function se(D) {
    if (z) return;
    if (z = !0, !(D in N)) {
      z = !1;
      return;
    }
    let I = l.map((Q) => (Q.properties && (Q.properties = Q.properties.map((re) => re.name === D ? Object.assign(Object.assign({}, re), { value: N[D] }) : re)), Q));
    t(0, l = I), y.dispatch("undo", I), setTimeout(
      () => {
        z = !1;
      },
      100
    );
  }
  function ve() {
    t(29, S = JSON.stringify(l)), Array.isArray(l) && l.forEach((D) => {
      Array.isArray(D.properties) && D.properties.forEach((I) => {
        t(18, N[I.name] = I.value, N);
      });
    }), setTimeout(ke, 50);
  }
  js(() => {
    ve();
  });
  const $ = [[]], oe = () => y.dispatch("clear_status"), K = (D) => $e(D.group_name);
  function de(D, I) {
    D[I].value = this.value, t(0, l);
  }
  const A = (D) => ne("change", D), Se = (D) => ne("input", D);
  function Ke(D, I) {
    D[I].value = this.value, t(0, l);
  }
  const Dt = (D) => ne("change", D), bt = (D) => ne("input", D);
  function yt(D, I) {
    D[I].value = this.checked, t(0, l);
  }
  const _t = (D) => ne("change", D);
  function Qe(D, I) {
    D[I].value = _i(this.value), t(0, l);
  }
  const Je = (D) => ne("change", D), dt = (D) => {
    j(D), ne("input", D);
  };
  function Ht(D, I) {
    D[I].value = _i(this.value), t(0, l);
  }
  function jt(D, I) {
    Os[D ? "unshift" : "push"](() => {
      C[I.name] = D, t(16, C);
    });
  }
  const wt = (D) => {
    j(D), Ka(D, C[D.name]), ne("input", D);
  }, Rt = (D) => ne("change", D);
  function It(D, I) {
    D[I].value = this.value, t(0, l);
  }
  const cn = (D) => ne("change", D), _n = (D, I) => X(I, D);
  function Ln(D, I) {
    D[I].value = this.__value, t(0, l);
  }
  const Gt = (D) => ne("change", D), $t = (D) => se(D.name);
  return i.$$set = (D) => {
    "value" in D && t(0, l = D.value), "label" in D && t(2, r = D.label), "show_group_name_only_one" in D && t(3, s = D.show_group_name_only_one), "disable_accordion" in D && t(4, u = D.disable_accordion), "visible" in D && t(5, c = D.visible), "open" in D && t(1, h = D.open), "elem_id" in D && t(6, d = D.elem_id), "elem_classes" in D && t(27, f = D.elem_classes), "container" in D && t(7, v = D.container), "scale" in D && t(8, b = D.scale), "min_width" in D && t(9, w = D.min_width), "width" in D && t(10, k = D.width), "height" in D && t(11, m = D.height), "loading_status" in D && t(12, _ = D.loading_status), "interactive" in D && t(13, g = D.interactive), "gradio" in D && t(14, y = D.gradio);
  }, i.$$.update = () => {
    if (i.$$.dirty[0] & /*elem_classes*/
    134217728 && t(19, n = ["propertysheet-wrapper", ...f]), i.$$.dirty[0] & /*open, height*/
    2050, i.$$.dirty[0] & /*value, lastValue, groupVisibility, _a*/
    805339137 && Array.isArray(l)) {
      if (JSON.stringify(l) !== S) {
        t(29, S = JSON.stringify(l));
        for (const D of l)
          F[D.group_name] === void 0 && t(15, F[D.group_name] = !0, F);
      }
      for (const D of l)
        if (Array.isArray(D.properties))
          for (const I of D.properties)
            (!(t(28, o = I.component) === null || o === void 0) && o.startsWith("number") || I.component === "slider") && j(I);
      Kn().then(ke);
    }
    i.$$.dirty[0] & /*open, groupVisibility*/
    32770 && h && F && Kn().then(ke);
  }, [
    l,
    h,
    r,
    s,
    u,
    c,
    d,
    v,
    b,
    w,
    k,
    m,
    _,
    g,
    y,
    F,
    C,
    T,
    N,
    n,
    j,
    ue,
    $e,
    _e,
    ne,
    X,
    se,
    f,
    o,
    S,
    oe,
    K,
    de,
    A,
    Se,
    Ke,
    Dt,
    bt,
    yt,
    _t,
    Qe,
    Je,
    dt,
    Ht,
    jt,
    wt,
    Rt,
    It,
    cn,
    _n,
    Ln,
    $,
    Gt,
    $t
  ];
}
class EE extends Is {
  constructor(e) {
    super(), Ps(
      this,
      e,
      tu,
      eu,
      Us,
      {
        value: 0,
        label: 2,
        show_group_name_only_one: 3,
        disable_accordion: 4,
        visible: 5,
        open: 1,
        elem_id: 6,
        elem_classes: 27,
        container: 7,
        scale: 8,
        min_width: 9,
        width: 10,
        height: 11,
        loading_status: 12,
        interactive: 13,
        gradio: 14
      },
      null,
      [-1, -1, -1]
    );
  }
}
export {
  EE as default
};
