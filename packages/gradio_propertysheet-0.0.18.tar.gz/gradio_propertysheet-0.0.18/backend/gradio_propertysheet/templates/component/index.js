var eo = Object.defineProperty;
var Ri = (i) => {
  throw TypeError(i);
};
var to = (i, e, t) => e in i ? eo(i, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : i[e] = t;
var ee = (i, e, t) => to(i, typeof e != "symbol" ? e + "" : e, t), no = (i, e, t) => e.has(i) || Ri("Cannot " + t);
var Li = (i, e, t) => e.has(i) ? Ri("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(i) : e.set(i, t);
var mn = (i, e, t) => (no(i, e, "access private method"), t);
const {
  SvelteComponent: io,
  append_hydration: ei,
  assign: ao,
  attr: Fe,
  binding_callbacks: lo,
  children: an,
  claim_element: il,
  claim_space: al,
  claim_svg_element: xn,
  create_slot: oo,
  detach: at,
  element: ll,
  empty: Oi,
  get_all_dirty_from_scope: ro,
  get_slot_changes: so,
  get_spread_update: uo,
  init: co,
  insert_hydration: un,
  listen: _o,
  noop: fo,
  safe_not_equal: po,
  set_dynamic_element_data: qi,
  set_style: Z,
  space: ol,
  svg_element: Un,
  toggle_class: ge,
  transition_in: rl,
  transition_out: sl,
  update_slot_base: ho
} = window.__gradio__svelte__internal;
function Ni(i) {
  let e, t, n, a, o;
  return {
    c() {
      e = Un("svg"), t = Un("line"), n = Un("line"), this.h();
    },
    l(l) {
      e = xn(l, "svg", { class: !0, xmlns: !0, viewBox: !0 });
      var r = an(e);
      t = xn(r, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), an(t).forEach(at), n = xn(r, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), an(n).forEach(at), r.forEach(at), this.h();
    },
    h() {
      Fe(t, "x1", "1"), Fe(t, "y1", "9"), Fe(t, "x2", "9"), Fe(t, "y2", "1"), Fe(t, "stroke", "gray"), Fe(t, "stroke-width", "0.5"), Fe(n, "x1", "5"), Fe(n, "y1", "9"), Fe(n, "x2", "9"), Fe(n, "y2", "5"), Fe(n, "stroke", "gray"), Fe(n, "stroke-width", "0.5"), Fe(e, "class", "resize-handle svelte-239wnu"), Fe(e, "xmlns", "http://www.w3.org/2000/svg"), Fe(e, "viewBox", "0 0 10 10");
    },
    m(l, r) {
      un(l, e, r), ei(e, t), ei(e, n), a || (o = _o(
        e,
        "mousedown",
        /*resize*/
        i[27]
      ), a = !0);
    },
    p: fo,
    d(l) {
      l && at(e), a = !1, o();
    }
  };
}
function mo(i) {
  var m;
  let e, t, n, a, o;
  const l = (
    /*#slots*/
    i[31].default
  ), r = oo(
    l,
    i,
    /*$$scope*/
    i[30],
    null
  );
  let s = (
    /*resizable*/
    i[19] && Ni(i)
  ), u = [
    { "data-testid": (
      /*test_id*/
      i[11]
    ) },
    { id: (
      /*elem_id*/
      i[6]
    ) },
    {
      class: n = "block " + /*elem_classes*/
      (((m = i[7]) == null ? void 0 : m.join(" ")) || "") + " svelte-239wnu"
    },
    {
      dir: a = /*rtl*/
      i[20] ? "rtl" : "ltr"
    }
  ], c = {};
  for (let d = 0; d < u.length; d += 1)
    c = ao(c, u[d]);
  return {
    c() {
      e = ll(
        /*tag*/
        i[25]
      ), r && r.c(), t = ol(), s && s.c(), this.h();
    },
    l(d) {
      e = il(
        d,
        /*tag*/
        (i[25] || "null").toUpperCase(),
        {
          "data-testid": !0,
          id: !0,
          class: !0,
          dir: !0
        }
      );
      var f = an(e);
      r && r.l(f), t = al(f), s && s.l(f), f.forEach(at), this.h();
    },
    h() {
      qi(
        /*tag*/
        i[25]
      )(e, c), ge(
        e,
        "hidden",
        /*visible*/
        i[14] === !1
      ), ge(
        e,
        "padded",
        /*padding*/
        i[10]
      ), ge(
        e,
        "flex",
        /*flex*/
        i[1]
      ), ge(
        e,
        "border_focus",
        /*border_mode*/
        i[9] === "focus"
      ), ge(
        e,
        "border_contrast",
        /*border_mode*/
        i[9] === "contrast"
      ), ge(e, "hide-container", !/*explicit_call*/
      i[12] && !/*container*/
      i[13]), ge(
        e,
        "fullscreen",
        /*fullscreen*/
        i[0]
      ), ge(
        e,
        "animating",
        /*fullscreen*/
        i[0] && /*preexpansionBoundingRect*/
        i[24] !== null
      ), ge(
        e,
        "auto-margin",
        /*scale*/
        i[17] === null
      ), Z(
        e,
        "height",
        /*fullscreen*/
        i[0] ? void 0 : (
          /*get_dimension*/
          i[26](
            /*height*/
            i[2]
          )
        )
      ), Z(
        e,
        "min-height",
        /*fullscreen*/
        i[0] ? void 0 : (
          /*get_dimension*/
          i[26](
            /*min_height*/
            i[3]
          )
        )
      ), Z(
        e,
        "max-height",
        /*fullscreen*/
        i[0] ? void 0 : (
          /*get_dimension*/
          i[26](
            /*max_height*/
            i[4]
          )
        )
      ), Z(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        i[24] ? `${/*preexpansionBoundingRect*/
        i[24].top}px` : "0px"
      ), Z(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        i[24] ? `${/*preexpansionBoundingRect*/
        i[24].left}px` : "0px"
      ), Z(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        i[24] ? `${/*preexpansionBoundingRect*/
        i[24].width}px` : "0px"
      ), Z(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        i[24] ? `${/*preexpansionBoundingRect*/
        i[24].height}px` : "0px"
      ), Z(
        e,
        "width",
        /*fullscreen*/
        i[0] ? void 0 : typeof /*width*/
        i[5] == "number" ? `calc(min(${/*width*/
        i[5]}px, 100%))` : (
          /*get_dimension*/
          i[26](
            /*width*/
            i[5]
          )
        )
      ), Z(
        e,
        "border-style",
        /*variant*/
        i[8]
      ), Z(
        e,
        "overflow",
        /*allow_overflow*/
        i[15] ? (
          /*overflow_behavior*/
          i[16]
        ) : "hidden"
      ), Z(
        e,
        "flex-grow",
        /*scale*/
        i[17]
      ), Z(e, "min-width", `calc(min(${/*min_width*/
      i[18]}px, 100%))`), Z(e, "border-width", "var(--block-border-width)");
    },
    m(d, f) {
      un(d, e, f), r && r.m(e, null), ei(e, t), s && s.m(e, null), i[32](e), o = !0;
    },
    p(d, f) {
      var v;
      r && r.p && (!o || f[0] & /*$$scope*/
      1073741824) && ho(
        r,
        l,
        d,
        /*$$scope*/
        d[30],
        o ? so(
          l,
          /*$$scope*/
          d[30],
          f,
          null
        ) : ro(
          /*$$scope*/
          d[30]
        ),
        null
      ), /*resizable*/
      d[19] ? s ? s.p(d, f) : (s = Ni(d), s.c(), s.m(e, null)) : s && (s.d(1), s = null), qi(
        /*tag*/
        d[25]
      )(e, c = uo(u, [
        (!o || f[0] & /*test_id*/
        2048) && { "data-testid": (
          /*test_id*/
          d[11]
        ) },
        (!o || f[0] & /*elem_id*/
        64) && { id: (
          /*elem_id*/
          d[6]
        ) },
        (!o || f[0] & /*elem_classes*/
        128 && n !== (n = "block " + /*elem_classes*/
        (((v = d[7]) == null ? void 0 : v.join(" ")) || "") + " svelte-239wnu")) && { class: n },
        (!o || f[0] & /*rtl*/
        1048576 && a !== (a = /*rtl*/
        d[20] ? "rtl" : "ltr")) && { dir: a }
      ])), ge(
        e,
        "hidden",
        /*visible*/
        d[14] === !1
      ), ge(
        e,
        "padded",
        /*padding*/
        d[10]
      ), ge(
        e,
        "flex",
        /*flex*/
        d[1]
      ), ge(
        e,
        "border_focus",
        /*border_mode*/
        d[9] === "focus"
      ), ge(
        e,
        "border_contrast",
        /*border_mode*/
        d[9] === "contrast"
      ), ge(e, "hide-container", !/*explicit_call*/
      d[12] && !/*container*/
      d[13]), ge(
        e,
        "fullscreen",
        /*fullscreen*/
        d[0]
      ), ge(
        e,
        "animating",
        /*fullscreen*/
        d[0] && /*preexpansionBoundingRect*/
        d[24] !== null
      ), ge(
        e,
        "auto-margin",
        /*scale*/
        d[17] === null
      ), f[0] & /*fullscreen, height*/
      5 && Z(
        e,
        "height",
        /*fullscreen*/
        d[0] ? void 0 : (
          /*get_dimension*/
          d[26](
            /*height*/
            d[2]
          )
        )
      ), f[0] & /*fullscreen, min_height*/
      9 && Z(
        e,
        "min-height",
        /*fullscreen*/
        d[0] ? void 0 : (
          /*get_dimension*/
          d[26](
            /*min_height*/
            d[3]
          )
        )
      ), f[0] & /*fullscreen, max_height*/
      17 && Z(
        e,
        "max-height",
        /*fullscreen*/
        d[0] ? void 0 : (
          /*get_dimension*/
          d[26](
            /*max_height*/
            d[4]
          )
        )
      ), f[0] & /*preexpansionBoundingRect*/
      16777216 && Z(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].top}px` : "0px"
      ), f[0] & /*preexpansionBoundingRect*/
      16777216 && Z(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].left}px` : "0px"
      ), f[0] & /*preexpansionBoundingRect*/
      16777216 && Z(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].width}px` : "0px"
      ), f[0] & /*preexpansionBoundingRect*/
      16777216 && Z(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].height}px` : "0px"
      ), f[0] & /*fullscreen, width*/
      33 && Z(
        e,
        "width",
        /*fullscreen*/
        d[0] ? void 0 : typeof /*width*/
        d[5] == "number" ? `calc(min(${/*width*/
        d[5]}px, 100%))` : (
          /*get_dimension*/
          d[26](
            /*width*/
            d[5]
          )
        )
      ), f[0] & /*variant*/
      256 && Z(
        e,
        "border-style",
        /*variant*/
        d[8]
      ), f[0] & /*allow_overflow, overflow_behavior*/
      98304 && Z(
        e,
        "overflow",
        /*allow_overflow*/
        d[15] ? (
          /*overflow_behavior*/
          d[16]
        ) : "hidden"
      ), f[0] & /*scale*/
      131072 && Z(
        e,
        "flex-grow",
        /*scale*/
        d[17]
      ), f[0] & /*min_width*/
      262144 && Z(e, "min-width", `calc(min(${/*min_width*/
      d[18]}px, 100%))`);
    },
    i(d) {
      o || (rl(r, d), o = !0);
    },
    o(d) {
      sl(r, d), o = !1;
    },
    d(d) {
      d && at(e), r && r.d(d), s && s.d(), i[32](null);
    }
  };
}
function Mi(i) {
  let e;
  return {
    c() {
      e = ll("div"), this.h();
    },
    l(t) {
      e = il(t, "DIV", { class: !0 }), an(e).forEach(at), this.h();
    },
    h() {
      Fe(e, "class", "placeholder svelte-239wnu"), Z(
        e,
        "height",
        /*placeholder_height*/
        i[22] + "px"
      ), Z(
        e,
        "width",
        /*placeholder_width*/
        i[23] + "px"
      );
    },
    m(t, n) {
      un(t, e, n);
    },
    p(t, n) {
      n[0] & /*placeholder_height*/
      4194304 && Z(
        e,
        "height",
        /*placeholder_height*/
        t[22] + "px"
      ), n[0] & /*placeholder_width*/
      8388608 && Z(
        e,
        "width",
        /*placeholder_width*/
        t[23] + "px"
      );
    },
    d(t) {
      t && at(e);
    }
  };
}
function go(i) {
  let e, t, n, a = (
    /*tag*/
    i[25] && mo(i)
  ), o = (
    /*fullscreen*/
    i[0] && Mi(i)
  );
  return {
    c() {
      a && a.c(), e = ol(), o && o.c(), t = Oi();
    },
    l(l) {
      a && a.l(l), e = al(l), o && o.l(l), t = Oi();
    },
    m(l, r) {
      a && a.m(l, r), un(l, e, r), o && o.m(l, r), un(l, t, r), n = !0;
    },
    p(l, r) {
      /*tag*/
      l[25] && a.p(l, r), /*fullscreen*/
      l[0] ? o ? o.p(l, r) : (o = Mi(l), o.c(), o.m(t.parentNode, t)) : o && (o.d(1), o = null);
    },
    i(l) {
      n || (rl(a, l), n = !0);
    },
    o(l) {
      sl(a, l), n = !1;
    },
    d(l) {
      l && (at(e), at(t)), a && a.d(l), o && o.d(l);
    }
  };
}
function vo(i, e, t) {
  let { $$slots: n = {}, $$scope: a } = e, { height: o = void 0 } = e, { min_height: l = void 0 } = e, { max_height: r = void 0 } = e, { width: s = void 0 } = e, { elem_id: u = "" } = e, { elem_classes: c = [] } = e, { variant: m = "solid" } = e, { border_mode: d = "base" } = e, { padding: f = !0 } = e, { type: v = "normal" } = e, { test_id: D = void 0 } = e, { explicit_call: w = !1 } = e, { container: F = !0 } = e, { visible: h = !0 } = e, { allow_overflow: _ = !0 } = e, { overflow_behavior: g = "auto" } = e, { scale: y = null } = e, { min_width: $ = 0 } = e, { flex: C = !1 } = e, { resizable: I = !1 } = e, { rtl: T = !1 } = e, { fullscreen: M = !1 } = e, N = M, j, ke = v === "fieldset" ? "fieldset" : "div", ce = 0, Ee = 0, pe = null;
  function ie(k) {
    M && k.key === "Escape" && t(0, M = !1);
  }
  const Q = (k) => {
    if (k !== void 0) {
      if (typeof k == "number")
        return k + "px";
      if (typeof k == "string")
        return k;
    }
  }, se = (k) => {
    let oe = k.clientY;
    const J = (A) => {
      const Te = A.clientY - oe;
      oe = A.clientY, t(21, j.style.height = `${j.offsetHeight + Te}px`, j);
    }, he = () => {
      window.removeEventListener("mousemove", J), window.removeEventListener("mouseup", he);
    };
    window.addEventListener("mousemove", J), window.addEventListener("mouseup", he);
  };
  function be(k) {
    lo[k ? "unshift" : "push"](() => {
      j = k, t(21, j);
    });
  }
  return i.$$set = (k) => {
    "height" in k && t(2, o = k.height), "min_height" in k && t(3, l = k.min_height), "max_height" in k && t(4, r = k.max_height), "width" in k && t(5, s = k.width), "elem_id" in k && t(6, u = k.elem_id), "elem_classes" in k && t(7, c = k.elem_classes), "variant" in k && t(8, m = k.variant), "border_mode" in k && t(9, d = k.border_mode), "padding" in k && t(10, f = k.padding), "type" in k && t(28, v = k.type), "test_id" in k && t(11, D = k.test_id), "explicit_call" in k && t(12, w = k.explicit_call), "container" in k && t(13, F = k.container), "visible" in k && t(14, h = k.visible), "allow_overflow" in k && t(15, _ = k.allow_overflow), "overflow_behavior" in k && t(16, g = k.overflow_behavior), "scale" in k && t(17, y = k.scale), "min_width" in k && t(18, $ = k.min_width), "flex" in k && t(1, C = k.flex), "resizable" in k && t(19, I = k.resizable), "rtl" in k && t(20, T = k.rtl), "fullscreen" in k && t(0, M = k.fullscreen), "$$scope" in k && t(30, a = k.$$scope);
  }, i.$$.update = () => {
    i.$$.dirty[0] & /*fullscreen, old_fullscreen, element*/
    538968065 && M !== N && (t(29, N = M), M ? (t(24, pe = j.getBoundingClientRect()), t(22, ce = j.offsetHeight), t(23, Ee = j.offsetWidth), window.addEventListener("keydown", ie)) : (t(24, pe = null), window.removeEventListener("keydown", ie))), i.$$.dirty[0] & /*visible*/
    16384 && (h || t(1, C = !1));
  }, [
    M,
    C,
    o,
    l,
    r,
    s,
    u,
    c,
    m,
    d,
    f,
    D,
    w,
    F,
    h,
    _,
    g,
    y,
    $,
    I,
    T,
    j,
    ce,
    Ee,
    pe,
    ke,
    Q,
    se,
    v,
    N,
    a,
    n,
    be
  ];
}
class bo extends io {
  constructor(e) {
    super(), co(
      this,
      e,
      vo,
      go,
      po,
      {
        height: 2,
        min_height: 3,
        max_height: 4,
        width: 5,
        elem_id: 6,
        elem_classes: 7,
        variant: 8,
        border_mode: 9,
        padding: 10,
        type: 28,
        test_id: 11,
        explicit_call: 12,
        container: 13,
        visible: 14,
        allow_overflow: 15,
        overflow_behavior: 16,
        scale: 17,
        min_width: 18,
        flex: 1,
        resizable: 19,
        rtl: 20,
        fullscreen: 0
      },
      null,
      [-1, -1]
    );
  }
}
function fi() {
  return {
    async: !1,
    breaks: !1,
    extensions: null,
    gfm: !0,
    hooks: null,
    pedantic: !1,
    renderer: null,
    silent: !1,
    tokenizer: null,
    walkTokens: null
  };
}
let Lt = fi();
function ul(i) {
  Lt = i;
}
const cl = /[&<>"']/, Do = new RegExp(cl.source, "g"), _l = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, yo = new RegExp(_l.source, "g"), wo = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, Pi = (i) => wo[i];
function Oe(i, e) {
  if (e) {
    if (cl.test(i))
      return i.replace(Do, Pi);
  } else if (_l.test(i))
    return i.replace(yo, Pi);
  return i;
}
const Fo = /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig;
function $o(i) {
  return i.replace(Fo, (e, t) => (t = t.toLowerCase(), t === "colon" ? ":" : t.charAt(0) === "#" ? t.charAt(1) === "x" ? String.fromCharCode(parseInt(t.substring(2), 16)) : String.fromCharCode(+t.substring(1)) : ""));
}
const ko = /(^|[^\[])\^/g;
function K(i, e) {
  let t = typeof i == "string" ? i : i.source;
  e = e || "";
  const n = {
    replace: (a, o) => {
      let l = typeof o == "string" ? o : o.source;
      return l = l.replace(ko, "$1"), t = t.replace(a, l), n;
    },
    getRegex: () => new RegExp(t, e)
  };
  return n;
}
function zi(i) {
  try {
    i = encodeURI(i).replace(/%25/g, "%");
  } catch {
    return null;
  }
  return i;
}
const ln = { exec: () => null };
function xi(i, e) {
  const t = i.replace(/\|/g, (o, l, r) => {
    let s = !1, u = l;
    for (; --u >= 0 && r[u] === "\\"; )
      s = !s;
    return s ? "|" : " |";
  }), n = t.split(/ \|/);
  let a = 0;
  if (n[0].trim() || n.shift(), n.length > 0 && !n[n.length - 1].trim() && n.pop(), e)
    if (n.length > e)
      n.splice(e);
    else
      for (; n.length < e; )
        n.push("");
  for (; a < n.length; a++)
    n[a] = n[a].trim().replace(/\\\|/g, "|");
  return n;
}
function gn(i, e, t) {
  const n = i.length;
  if (n === 0)
    return "";
  let a = 0;
  for (; a < n && i.charAt(n - a - 1) === e; )
    a++;
  return i.slice(0, n - a);
}
function Eo(i, e) {
  if (i.indexOf(e[1]) === -1)
    return -1;
  let t = 0;
  for (let n = 0; n < i.length; n++)
    if (i[n] === "\\")
      n++;
    else if (i[n] === e[0])
      t++;
    else if (i[n] === e[1] && (t--, t < 0))
      return n;
  return -1;
}
function Ui(i, e, t, n) {
  const a = e.href, o = e.title ? Oe(e.title) : null, l = i[1].replace(/\\([\[\]])/g, "$1");
  if (i[0].charAt(0) !== "!") {
    n.state.inLink = !0;
    const r = {
      type: "link",
      raw: t,
      href: a,
      title: o,
      text: l,
      tokens: n.inlineTokens(l)
    };
    return n.state.inLink = !1, r;
  }
  return {
    type: "image",
    raw: t,
    href: a,
    title: o,
    text: Oe(l)
  };
}
function Ao(i, e) {
  const t = i.match(/^(\s+)(?:```)/);
  if (t === null)
    return e;
  const n = t[1];
  return e.split(`
`).map((a) => {
    const o = a.match(/^\s+/);
    if (o === null)
      return a;
    const [l] = o;
    return l.length >= n.length ? a.slice(n.length) : a;
  }).join(`
`);
}
class Bn {
  // set by the lexer
  constructor(e) {
    ee(this, "options");
    ee(this, "rules");
    // set by the lexer
    ee(this, "lexer");
    this.options = e || Lt;
  }
  space(e) {
    const t = this.rules.block.newline.exec(e);
    if (t && t[0].length > 0)
      return {
        type: "space",
        raw: t[0]
      };
  }
  code(e) {
    const t = this.rules.block.code.exec(e);
    if (t) {
      const n = t[0].replace(/^ {1,4}/gm, "");
      return {
        type: "code",
        raw: t[0],
        codeBlockStyle: "indented",
        text: this.options.pedantic ? n : gn(n, `
`)
      };
    }
  }
  fences(e) {
    const t = this.rules.block.fences.exec(e);
    if (t) {
      const n = t[0], a = Ao(n, t[3] || "");
      return {
        type: "code",
        raw: n,
        lang: t[2] ? t[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : t[2],
        text: a
      };
    }
  }
  heading(e) {
    const t = this.rules.block.heading.exec(e);
    if (t) {
      let n = t[2].trim();
      if (/#$/.test(n)) {
        const a = gn(n, "#");
        (this.options.pedantic || !a || / $/.test(a)) && (n = a.trim());
      }
      return {
        type: "heading",
        raw: t[0],
        depth: t[1].length,
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  hr(e) {
    const t = this.rules.block.hr.exec(e);
    if (t)
      return {
        type: "hr",
        raw: t[0]
      };
  }
  blockquote(e) {
    const t = this.rules.block.blockquote.exec(e);
    if (t) {
      let n = t[0].replace(/\n {0,3}((?:=+|-+) *)(?=\n|$)/g, `
    $1`);
      n = gn(n.replace(/^ *>[ \t]?/gm, ""), `
`);
      const a = this.lexer.state.top;
      this.lexer.state.top = !0;
      const o = this.lexer.blockTokens(n);
      return this.lexer.state.top = a, {
        type: "blockquote",
        raw: t[0],
        tokens: o,
        text: n
      };
    }
  }
  list(e) {
    let t = this.rules.block.list.exec(e);
    if (t) {
      let n = t[1].trim();
      const a = n.length > 1, o = {
        type: "list",
        raw: "",
        ordered: a,
        start: a ? +n.slice(0, -1) : "",
        loose: !1,
        items: []
      };
      n = a ? `\\d{1,9}\\${n.slice(-1)}` : `\\${n}`, this.options.pedantic && (n = a ? n : "[*+-]");
      const l = new RegExp(`^( {0,3}${n})((?:[	 ][^\\n]*)?(?:\\n|$))`);
      let r = "", s = "", u = !1;
      for (; e; ) {
        let c = !1;
        if (!(t = l.exec(e)) || this.rules.block.hr.test(e))
          break;
        r = t[0], e = e.substring(r.length);
        let m = t[2].split(`
`, 1)[0].replace(/^\t+/, (F) => " ".repeat(3 * F.length)), d = e.split(`
`, 1)[0], f = 0;
        this.options.pedantic ? (f = 2, s = m.trimStart()) : (f = t[2].search(/[^ ]/), f = f > 4 ? 1 : f, s = m.slice(f), f += t[1].length);
        let v = !1;
        if (!m && /^ *$/.test(d) && (r += d + `
`, e = e.substring(d.length + 1), c = !0), !c) {
          const F = new RegExp(`^ {0,${Math.min(3, f - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`), h = new RegExp(`^ {0,${Math.min(3, f - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`), _ = new RegExp(`^ {0,${Math.min(3, f - 1)}}(?:\`\`\`|~~~)`), g = new RegExp(`^ {0,${Math.min(3, f - 1)}}#`);
          for (; e; ) {
            const y = e.split(`
`, 1)[0];
            if (d = y, this.options.pedantic && (d = d.replace(/^ {1,4}(?=( {4})*[^ ])/g, "  ")), _.test(d) || g.test(d) || F.test(d) || h.test(e))
              break;
            if (d.search(/[^ ]/) >= f || !d.trim())
              s += `
` + d.slice(f);
            else {
              if (v || m.search(/[^ ]/) >= 4 || _.test(m) || g.test(m) || h.test(m))
                break;
              s += `
` + d;
            }
            !v && !d.trim() && (v = !0), r += y + `
`, e = e.substring(y.length + 1), m = d.slice(f);
          }
        }
        o.loose || (u ? o.loose = !0 : /\n *\n *$/.test(r) && (u = !0));
        let D = null, w;
        this.options.gfm && (D = /^\[[ xX]\] /.exec(s), D && (w = D[0] !== "[ ] ", s = s.replace(/^\[[ xX]\] +/, ""))), o.items.push({
          type: "list_item",
          raw: r,
          task: !!D,
          checked: w,
          loose: !1,
          text: s,
          tokens: []
        }), o.raw += r;
      }
      o.items[o.items.length - 1].raw = r.trimEnd(), o.items[o.items.length - 1].text = s.trimEnd(), o.raw = o.raw.trimEnd();
      for (let c = 0; c < o.items.length; c++)
        if (this.lexer.state.top = !1, o.items[c].tokens = this.lexer.blockTokens(o.items[c].text, []), !o.loose) {
          const m = o.items[c].tokens.filter((f) => f.type === "space"), d = m.length > 0 && m.some((f) => /\n.*\n/.test(f.raw));
          o.loose = d;
        }
      if (o.loose)
        for (let c = 0; c < o.items.length; c++)
          o.items[c].loose = !0;
      return o;
    }
  }
  html(e) {
    const t = this.rules.block.html.exec(e);
    if (t)
      return {
        type: "html",
        block: !0,
        raw: t[0],
        pre: t[1] === "pre" || t[1] === "script" || t[1] === "style",
        text: t[0]
      };
  }
  def(e) {
    const t = this.rules.block.def.exec(e);
    if (t) {
      const n = t[1].toLowerCase().replace(/\s+/g, " "), a = t[2] ? t[2].replace(/^<(.*)>$/, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", o = t[3] ? t[3].substring(1, t[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : t[3];
      return {
        type: "def",
        tag: n,
        raw: t[0],
        href: a,
        title: o
      };
    }
  }
  table(e) {
    const t = this.rules.block.table.exec(e);
    if (!t || !/[:|]/.test(t[2]))
      return;
    const n = xi(t[1]), a = t[2].replace(/^\||\| *$/g, "").split("|"), o = t[3] && t[3].trim() ? t[3].replace(/\n[ \t]*$/, "").split(`
`) : [], l = {
      type: "table",
      raw: t[0],
      header: [],
      align: [],
      rows: []
    };
    if (n.length === a.length) {
      for (const r of a)
        /^ *-+: *$/.test(r) ? l.align.push("right") : /^ *:-+: *$/.test(r) ? l.align.push("center") : /^ *:-+ *$/.test(r) ? l.align.push("left") : l.align.push(null);
      for (const r of n)
        l.header.push({
          text: r,
          tokens: this.lexer.inline(r)
        });
      for (const r of o)
        l.rows.push(xi(r, l.header.length).map((s) => ({
          text: s,
          tokens: this.lexer.inline(s)
        })));
      return l;
    }
  }
  lheading(e) {
    const t = this.rules.block.lheading.exec(e);
    if (t)
      return {
        type: "heading",
        raw: t[0],
        depth: t[2].charAt(0) === "=" ? 1 : 2,
        text: t[1],
        tokens: this.lexer.inline(t[1])
      };
  }
  paragraph(e) {
    const t = this.rules.block.paragraph.exec(e);
    if (t) {
      const n = t[1].charAt(t[1].length - 1) === `
` ? t[1].slice(0, -1) : t[1];
      return {
        type: "paragraph",
        raw: t[0],
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  text(e) {
    const t = this.rules.block.text.exec(e);
    if (t)
      return {
        type: "text",
        raw: t[0],
        text: t[0],
        tokens: this.lexer.inline(t[0])
      };
  }
  escape(e) {
    const t = this.rules.inline.escape.exec(e);
    if (t)
      return {
        type: "escape",
        raw: t[0],
        text: Oe(t[1])
      };
  }
  tag(e) {
    const t = this.rules.inline.tag.exec(e);
    if (t)
      return !this.lexer.state.inLink && /^<a /i.test(t[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && /^<\/a>/i.test(t[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && /^<(pre|code|kbd|script)(\s|>)/i.test(t[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && /^<\/(pre|code|kbd|script)(\s|>)/i.test(t[0]) && (this.lexer.state.inRawBlock = !1), {
        type: "html",
        raw: t[0],
        inLink: this.lexer.state.inLink,
        inRawBlock: this.lexer.state.inRawBlock,
        block: !1,
        text: t[0]
      };
  }
  link(e) {
    const t = this.rules.inline.link.exec(e);
    if (t) {
      const n = t[2].trim();
      if (!this.options.pedantic && /^</.test(n)) {
        if (!/>$/.test(n))
          return;
        const l = gn(n.slice(0, -1), "\\");
        if ((n.length - l.length) % 2 === 0)
          return;
      } else {
        const l = Eo(t[2], "()");
        if (l > -1) {
          const s = (t[0].indexOf("!") === 0 ? 5 : 4) + t[1].length + l;
          t[2] = t[2].substring(0, l), t[0] = t[0].substring(0, s).trim(), t[3] = "";
        }
      }
      let a = t[2], o = "";
      if (this.options.pedantic) {
        const l = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(a);
        l && (a = l[1], o = l[3]);
      } else
        o = t[3] ? t[3].slice(1, -1) : "";
      return a = a.trim(), /^</.test(a) && (this.options.pedantic && !/>$/.test(n) ? a = a.slice(1) : a = a.slice(1, -1)), Ui(t, {
        href: a && a.replace(this.rules.inline.anyPunctuation, "$1"),
        title: o && o.replace(this.rules.inline.anyPunctuation, "$1")
      }, t[0], this.lexer);
    }
  }
  reflink(e, t) {
    let n;
    if ((n = this.rules.inline.reflink.exec(e)) || (n = this.rules.inline.nolink.exec(e))) {
      const a = (n[2] || n[1]).replace(/\s+/g, " "), o = t[a.toLowerCase()];
      if (!o) {
        const l = n[0].charAt(0);
        return {
          type: "text",
          raw: l,
          text: l
        };
      }
      return Ui(n, o, n[0], this.lexer);
    }
  }
  emStrong(e, t, n = "") {
    let a = this.rules.inline.emStrongLDelim.exec(e);
    if (!a || a[3] && n.match(/[\p{L}\p{N}]/u))
      return;
    if (!(a[1] || a[2] || "") || !n || this.rules.inline.punctuation.exec(n)) {
      const l = [...a[0]].length - 1;
      let r, s, u = l, c = 0;
      const m = a[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (m.lastIndex = 0, t = t.slice(-1 * e.length + l); (a = m.exec(t)) != null; ) {
        if (r = a[1] || a[2] || a[3] || a[4] || a[5] || a[6], !r)
          continue;
        if (s = [...r].length, a[3] || a[4]) {
          u += s;
          continue;
        } else if ((a[5] || a[6]) && l % 3 && !((l + s) % 3)) {
          c += s;
          continue;
        }
        if (u -= s, u > 0)
          continue;
        s = Math.min(s, s + u + c);
        const d = [...a[0]][0].length, f = e.slice(0, l + a.index + d + s);
        if (Math.min(l, s) % 2) {
          const D = f.slice(1, -1);
          return {
            type: "em",
            raw: f,
            text: D,
            tokens: this.lexer.inlineTokens(D)
          };
        }
        const v = f.slice(2, -2);
        return {
          type: "strong",
          raw: f,
          text: v,
          tokens: this.lexer.inlineTokens(v)
        };
      }
    }
  }
  codespan(e) {
    const t = this.rules.inline.code.exec(e);
    if (t) {
      let n = t[2].replace(/\n/g, " ");
      const a = /[^ ]/.test(n), o = /^ /.test(n) && / $/.test(n);
      return a && o && (n = n.substring(1, n.length - 1)), n = Oe(n, !0), {
        type: "codespan",
        raw: t[0],
        text: n
      };
    }
  }
  br(e) {
    const t = this.rules.inline.br.exec(e);
    if (t)
      return {
        type: "br",
        raw: t[0]
      };
  }
  del(e) {
    const t = this.rules.inline.del.exec(e);
    if (t)
      return {
        type: "del",
        raw: t[0],
        text: t[2],
        tokens: this.lexer.inlineTokens(t[2])
      };
  }
  autolink(e) {
    const t = this.rules.inline.autolink.exec(e);
    if (t) {
      let n, a;
      return t[2] === "@" ? (n = Oe(t[1]), a = "mailto:" + n) : (n = Oe(t[1]), a = n), {
        type: "link",
        raw: t[0],
        text: n,
        href: a,
        tokens: [
          {
            type: "text",
            raw: n,
            text: n
          }
        ]
      };
    }
  }
  url(e) {
    var n;
    let t;
    if (t = this.rules.inline.url.exec(e)) {
      let a, o;
      if (t[2] === "@")
        a = Oe(t[0]), o = "mailto:" + a;
      else {
        let l;
        do
          l = t[0], t[0] = ((n = this.rules.inline._backpedal.exec(t[0])) == null ? void 0 : n[0]) ?? "";
        while (l !== t[0]);
        a = Oe(t[0]), t[1] === "www." ? o = "http://" + t[0] : o = t[0];
      }
      return {
        type: "link",
        raw: t[0],
        text: a,
        href: o,
        tokens: [
          {
            type: "text",
            raw: a,
            text: a
          }
        ]
      };
    }
  }
  inlineText(e) {
    const t = this.rules.inline.text.exec(e);
    if (t) {
      let n;
      return this.lexer.state.inRawBlock ? n = t[0] : n = Oe(t[0]), {
        type: "text",
        raw: t[0],
        text: n
      };
    }
  }
}
const Co = /^(?: *(?:\n|$))+/, So = /^( {4}[^\n]+(?:\n(?: *(?:\n|$))*)?)+/, To = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, cn = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, Bo = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, dl = /(?:[*+-]|\d{1,9}[.)])/, fl = K(/^(?!bull |blockCode|fences|blockquote|heading|html)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html))+?)\n {0,3}(=+|-+) *(?:\n+|$)/).replace(/bull/g, dl).replace(/blockCode/g, / {4}/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).getRegex(), pi = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, Io = /^[^\n]+/, hi = /(?!\s*\])(?:\\.|[^\[\]\\])+/, Ro = K(/^ {0,3}\[(label)\]: *(?:\n *)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n *)?| *\n *)(title))? *(?:\n+|$)/).replace("label", hi).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), Lo = K(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, dl).getRegex(), qn = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", mi = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, Oo = K("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n *)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$))", "i").replace("comment", mi).replace("tag", qn).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), pl = K(pi).replace("hr", cn).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", qn).getRegex(), qo = K(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", pl).getRegex(), gi = {
  blockquote: qo,
  code: So,
  def: Ro,
  fences: To,
  heading: Bo,
  hr: cn,
  html: Oo,
  lheading: fl,
  list: Lo,
  newline: Co,
  paragraph: pl,
  table: ln,
  text: Io
}, Hi = K("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", cn).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", qn).getRegex(), No = {
  ...gi,
  table: Hi,
  paragraph: K(pi).replace("hr", cn).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", Hi).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", qn).getRegex()
}, Mo = {
  ...gi,
  html: K(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", mi).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: ln,
  // fences not supported
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: K(pi).replace("hr", cn).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", fl).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
}, hl = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, Po = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, ml = /^( {2,}|\\)\n(?!\s*$)/, zo = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, _n = "\\p{P}\\p{S}", xo = K(/^((?![*_])[\spunctuation])/, "u").replace(/punctuation/g, _n).getRegex(), Uo = /\[[^[\]]*?\]\([^\(\)]*?\)|`[^`]*?`|<[^<>]*?>/g, Ho = K(/^(?:\*+(?:((?!\*)[punct])|[^\s*]))|^_+(?:((?!_)[punct])|([^\s_]))/, "u").replace(/punct/g, _n).getRegex(), Go = K("^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)[punct](\\*+)(?=[\\s]|$)|[^punct\\s](\\*+)(?!\\*)(?=[punct\\s]|$)|(?!\\*)[punct\\s](\\*+)(?=[^punct\\s])|[\\s](\\*+)(?!\\*)(?=[punct])|(?!\\*)[punct](\\*+)(?!\\*)(?=[punct])|[^punct\\s](\\*+)(?=[^punct\\s])", "gu").replace(/punct/g, _n).getRegex(), jo = K("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)[punct](_+)(?=[\\s]|$)|[^punct\\s](_+)(?!_)(?=[punct\\s]|$)|(?!_)[punct\\s](_+)(?=[^punct\\s])|[\\s](_+)(?!_)(?=[punct])|(?!_)[punct](_+)(?!_)(?=[punct])", "gu").replace(/punct/g, _n).getRegex(), Vo = K(/\\([punct])/, "gu").replace(/punct/g, _n).getRegex(), Wo = K(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), Zo = K(mi).replace("(?:-->|$)", "-->").getRegex(), Yo = K("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", Zo).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), In = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, Xo = K(/^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/).replace("label", In).replace("href", /<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), gl = K(/^!?\[(label)\]\[(ref)\]/).replace("label", In).replace("ref", hi).getRegex(), vl = K(/^!?\[(ref)\](?:\[\])?/).replace("ref", hi).getRegex(), Ko = K("reflink|nolink(?!\\()", "g").replace("reflink", gl).replace("nolink", vl).getRegex(), vi = {
  _backpedal: ln,
  // only used for GFM url
  anyPunctuation: Vo,
  autolink: Wo,
  blockSkip: Uo,
  br: ml,
  code: Po,
  del: ln,
  emStrongLDelim: Ho,
  emStrongRDelimAst: Go,
  emStrongRDelimUnd: jo,
  escape: hl,
  link: Xo,
  nolink: vl,
  punctuation: xo,
  reflink: gl,
  reflinkSearch: Ko,
  tag: Yo,
  text: zo,
  url: ln
}, Qo = {
  ...vi,
  link: K(/^!?\[(label)\]\((.*?)\)/).replace("label", In).getRegex(),
  reflink: K(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", In).getRegex()
}, ti = {
  ...vi,
  escape: K(hl).replace("])", "~|])").getRegex(),
  url: K(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])([\s\S]*?[^\s~])\1(?=[^~]|$)/,
  text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
}, Jo = {
  ...ti,
  br: K(ml).replace("{2,}", "*").getRegex(),
  text: K(ti.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
}, vn = {
  normal: gi,
  gfm: No,
  pedantic: Mo
}, Xt = {
  normal: vi,
  gfm: ti,
  breaks: Jo,
  pedantic: Qo
};
class lt {
  constructor(e) {
    ee(this, "tokens");
    ee(this, "options");
    ee(this, "state");
    ee(this, "tokenizer");
    ee(this, "inlineQueue");
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = e || Lt, this.options.tokenizer = this.options.tokenizer || new Bn(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
      inLink: !1,
      inRawBlock: !1,
      top: !0
    };
    const t = {
      block: vn.normal,
      inline: Xt.normal
    };
    this.options.pedantic ? (t.block = vn.pedantic, t.inline = Xt.pedantic) : this.options.gfm && (t.block = vn.gfm, this.options.breaks ? t.inline = Xt.breaks : t.inline = Xt.gfm), this.tokenizer.rules = t;
  }
  /**
   * Expose Rules
   */
  static get rules() {
    return {
      block: vn,
      inline: Xt
    };
  }
  /**
   * Static Lex Method
   */
  static lex(e, t) {
    return new lt(t).lex(e);
  }
  /**
   * Static Lex Inline Method
   */
  static lexInline(e, t) {
    return new lt(t).inlineTokens(e);
  }
  /**
   * Preprocessing
   */
  lex(e) {
    e = e.replace(/\r\n|\r/g, `
`), this.blockTokens(e, this.tokens);
    for (let t = 0; t < this.inlineQueue.length; t++) {
      const n = this.inlineQueue[t];
      this.inlineTokens(n.src, n.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(e, t = []) {
    this.options.pedantic ? e = e.replace(/\t/g, "    ").replace(/^ +$/gm, "") : e = e.replace(/^( *)(\t+)/gm, (r, s, u) => s + "    ".repeat(u.length));
    let n, a, o, l;
    for (; e; )
      if (!(this.options.extensions && this.options.extensions.block && this.options.extensions.block.some((r) => (n = r.call({ lexer: this }, e, t)) ? (e = e.substring(n.raw.length), t.push(n), !0) : !1))) {
        if (n = this.tokenizer.space(e)) {
          e = e.substring(n.raw.length), n.raw.length === 1 && t.length > 0 ? t[t.length - 1].raw += `
` : t.push(n);
          continue;
        }
        if (n = this.tokenizer.code(e)) {
          e = e.substring(n.raw.length), a = t[t.length - 1], a && (a.type === "paragraph" || a.type === "text") ? (a.raw += `
` + n.raw, a.text += `
` + n.text, this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.fences(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.heading(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.hr(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.blockquote(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.list(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.html(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.def(e)) {
          e = e.substring(n.raw.length), a = t[t.length - 1], a && (a.type === "paragraph" || a.type === "text") ? (a.raw += `
` + n.raw, a.text += `
` + n.raw, this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : this.tokens.links[n.tag] || (this.tokens.links[n.tag] = {
            href: n.href,
            title: n.title
          });
          continue;
        }
        if (n = this.tokenizer.table(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.lheading(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (o = e, this.options.extensions && this.options.extensions.startBlock) {
          let r = 1 / 0;
          const s = e.slice(1);
          let u;
          this.options.extensions.startBlock.forEach((c) => {
            u = c.call({ lexer: this }, s), typeof u == "number" && u >= 0 && (r = Math.min(r, u));
          }), r < 1 / 0 && r >= 0 && (o = e.substring(0, r + 1));
        }
        if (this.state.top && (n = this.tokenizer.paragraph(o))) {
          a = t[t.length - 1], l && a.type === "paragraph" ? (a.raw += `
` + n.raw, a.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : t.push(n), l = o.length !== e.length, e = e.substring(n.raw.length);
          continue;
        }
        if (n = this.tokenizer.text(e)) {
          e = e.substring(n.raw.length), a = t[t.length - 1], a && a.type === "text" ? (a.raw += `
` + n.raw, a.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : t.push(n);
          continue;
        }
        if (e) {
          const r = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(r);
            break;
          } else
            throw new Error(r);
        }
      }
    return this.state.top = !0, t;
  }
  inline(e, t = []) {
    return this.inlineQueue.push({ src: e, tokens: t }), t;
  }
  /**
   * Lexing/Compiling
   */
  inlineTokens(e, t = []) {
    let n, a, o, l = e, r, s, u;
    if (this.tokens.links) {
      const c = Object.keys(this.tokens.links);
      if (c.length > 0)
        for (; (r = this.tokenizer.rules.inline.reflinkSearch.exec(l)) != null; )
          c.includes(r[0].slice(r[0].lastIndexOf("[") + 1, -1)) && (l = l.slice(0, r.index) + "[" + "a".repeat(r[0].length - 2) + "]" + l.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (r = this.tokenizer.rules.inline.blockSkip.exec(l)) != null; )
      l = l.slice(0, r.index) + "[" + "a".repeat(r[0].length - 2) + "]" + l.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    for (; (r = this.tokenizer.rules.inline.anyPunctuation.exec(l)) != null; )
      l = l.slice(0, r.index) + "++" + l.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    for (; e; )
      if (s || (u = ""), s = !1, !(this.options.extensions && this.options.extensions.inline && this.options.extensions.inline.some((c) => (n = c.call({ lexer: this }, e, t)) ? (e = e.substring(n.raw.length), t.push(n), !0) : !1))) {
        if (n = this.tokenizer.escape(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.tag(e)) {
          e = e.substring(n.raw.length), a = t[t.length - 1], a && n.type === "text" && a.type === "text" ? (a.raw += n.raw, a.text += n.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.link(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.reflink(e, this.tokens.links)) {
          e = e.substring(n.raw.length), a = t[t.length - 1], a && n.type === "text" && a.type === "text" ? (a.raw += n.raw, a.text += n.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.emStrong(e, l, u)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.codespan(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.br(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.del(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.autolink(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (!this.state.inLink && (n = this.tokenizer.url(e))) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (o = e, this.options.extensions && this.options.extensions.startInline) {
          let c = 1 / 0;
          const m = e.slice(1);
          let d;
          this.options.extensions.startInline.forEach((f) => {
            d = f.call({ lexer: this }, m), typeof d == "number" && d >= 0 && (c = Math.min(c, d));
          }), c < 1 / 0 && c >= 0 && (o = e.substring(0, c + 1));
        }
        if (n = this.tokenizer.inlineText(o)) {
          e = e.substring(n.raw.length), n.raw.slice(-1) !== "_" && (u = n.raw.slice(-1)), s = !0, a = t[t.length - 1], a && a.type === "text" ? (a.raw += n.raw, a.text += n.text) : t.push(n);
          continue;
        }
        if (e) {
          const c = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(c);
            break;
          } else
            throw new Error(c);
        }
      }
    return t;
  }
}
class Rn {
  constructor(e) {
    ee(this, "options");
    this.options = e || Lt;
  }
  code(e, t, n) {
    var o;
    const a = (o = (t || "").match(/^\S*/)) == null ? void 0 : o[0];
    return e = e.replace(/\n$/, "") + `
`, a ? '<pre><code class="language-' + Oe(a) + '">' + (n ? e : Oe(e, !0)) + `</code></pre>
` : "<pre><code>" + (n ? e : Oe(e, !0)) + `</code></pre>
`;
  }
  blockquote(e) {
    return `<blockquote>
${e}</blockquote>
`;
  }
  html(e, t) {
    return e;
  }
  heading(e, t, n) {
    return `<h${t}>${e}</h${t}>
`;
  }
  hr() {
    return `<hr>
`;
  }
  list(e, t, n) {
    const a = t ? "ol" : "ul", o = t && n !== 1 ? ' start="' + n + '"' : "";
    return "<" + a + o + `>
` + e + "</" + a + `>
`;
  }
  listitem(e, t, n) {
    return `<li>${e}</li>
`;
  }
  checkbox(e) {
    return "<input " + (e ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph(e) {
    return `<p>${e}</p>
`;
  }
  table(e, t) {
    return t && (t = `<tbody>${t}</tbody>`), `<table>
<thead>
` + e + `</thead>
` + t + `</table>
`;
  }
  tablerow(e) {
    return `<tr>
${e}</tr>
`;
  }
  tablecell(e, t) {
    const n = t.header ? "th" : "td";
    return (t.align ? `<${n} align="${t.align}">` : `<${n}>`) + e + `</${n}>
`;
  }
  /**
   * span level renderer
   */
  strong(e) {
    return `<strong>${e}</strong>`;
  }
  em(e) {
    return `<em>${e}</em>`;
  }
  codespan(e) {
    return `<code>${e}</code>`;
  }
  br() {
    return "<br>";
  }
  del(e) {
    return `<del>${e}</del>`;
  }
  link(e, t, n) {
    const a = zi(e);
    if (a === null)
      return n;
    e = a;
    let o = '<a href="' + e + '"';
    return t && (o += ' title="' + t + '"'), o += ">" + n + "</a>", o;
  }
  image(e, t, n) {
    const a = zi(e);
    if (a === null)
      return n;
    e = a;
    let o = `<img src="${e}" alt="${n}"`;
    return t && (o += ` title="${t}"`), o += ">", o;
  }
  text(e) {
    return e;
  }
}
class bi {
  // no need for block level renderers
  strong(e) {
    return e;
  }
  em(e) {
    return e;
  }
  codespan(e) {
    return e;
  }
  del(e) {
    return e;
  }
  html(e) {
    return e;
  }
  text(e) {
    return e;
  }
  link(e, t, n) {
    return "" + n;
  }
  image(e, t, n) {
    return "" + n;
  }
  br() {
    return "";
  }
}
class ot {
  constructor(e) {
    ee(this, "options");
    ee(this, "renderer");
    ee(this, "textRenderer");
    this.options = e || Lt, this.options.renderer = this.options.renderer || new Rn(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.textRenderer = new bi();
  }
  /**
   * Static Parse Method
   */
  static parse(e, t) {
    return new ot(t).parse(e);
  }
  /**
   * Static Parse Inline Method
   */
  static parseInline(e, t) {
    return new ot(t).parseInline(e);
  }
  /**
   * Parse Loop
   */
  parse(e, t = !0) {
    let n = "";
    for (let a = 0; a < e.length; a++) {
      const o = e[a];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[o.type]) {
        const l = o, r = this.options.extensions.renderers[l.type].call({ parser: this }, l);
        if (r !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(l.type)) {
          n += r || "";
          continue;
        }
      }
      switch (o.type) {
        case "space":
          continue;
        case "hr": {
          n += this.renderer.hr();
          continue;
        }
        case "heading": {
          const l = o;
          n += this.renderer.heading(this.parseInline(l.tokens), l.depth, $o(this.parseInline(l.tokens, this.textRenderer)));
          continue;
        }
        case "code": {
          const l = o;
          n += this.renderer.code(l.text, l.lang, !!l.escaped);
          continue;
        }
        case "table": {
          const l = o;
          let r = "", s = "";
          for (let c = 0; c < l.header.length; c++)
            s += this.renderer.tablecell(this.parseInline(l.header[c].tokens), { header: !0, align: l.align[c] });
          r += this.renderer.tablerow(s);
          let u = "";
          for (let c = 0; c < l.rows.length; c++) {
            const m = l.rows[c];
            s = "";
            for (let d = 0; d < m.length; d++)
              s += this.renderer.tablecell(this.parseInline(m[d].tokens), { header: !1, align: l.align[d] });
            u += this.renderer.tablerow(s);
          }
          n += this.renderer.table(r, u);
          continue;
        }
        case "blockquote": {
          const l = o, r = this.parse(l.tokens);
          n += this.renderer.blockquote(r);
          continue;
        }
        case "list": {
          const l = o, r = l.ordered, s = l.start, u = l.loose;
          let c = "";
          for (let m = 0; m < l.items.length; m++) {
            const d = l.items[m], f = d.checked, v = d.task;
            let D = "";
            if (d.task) {
              const w = this.renderer.checkbox(!!f);
              u ? d.tokens.length > 0 && d.tokens[0].type === "paragraph" ? (d.tokens[0].text = w + " " + d.tokens[0].text, d.tokens[0].tokens && d.tokens[0].tokens.length > 0 && d.tokens[0].tokens[0].type === "text" && (d.tokens[0].tokens[0].text = w + " " + d.tokens[0].tokens[0].text)) : d.tokens.unshift({
                type: "text",
                text: w + " "
              }) : D += w + " ";
            }
            D += this.parse(d.tokens, u), c += this.renderer.listitem(D, v, !!f);
          }
          n += this.renderer.list(c, r, s);
          continue;
        }
        case "html": {
          const l = o;
          n += this.renderer.html(l.text, l.block);
          continue;
        }
        case "paragraph": {
          const l = o;
          n += this.renderer.paragraph(this.parseInline(l.tokens));
          continue;
        }
        case "text": {
          let l = o, r = l.tokens ? this.parseInline(l.tokens) : l.text;
          for (; a + 1 < e.length && e[a + 1].type === "text"; )
            l = e[++a], r += `
` + (l.tokens ? this.parseInline(l.tokens) : l.text);
          n += t ? this.renderer.paragraph(r) : r;
          continue;
        }
        default: {
          const l = 'Token with "' + o.type + '" type was not found.';
          if (this.options.silent)
            return console.error(l), "";
          throw new Error(l);
        }
      }
    }
    return n;
  }
  /**
   * Parse Inline Tokens
   */
  parseInline(e, t) {
    t = t || this.renderer;
    let n = "";
    for (let a = 0; a < e.length; a++) {
      const o = e[a];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[o.type]) {
        const l = this.options.extensions.renderers[o.type].call({ parser: this }, o);
        if (l !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(o.type)) {
          n += l || "";
          continue;
        }
      }
      switch (o.type) {
        case "escape": {
          const l = o;
          n += t.text(l.text);
          break;
        }
        case "html": {
          const l = o;
          n += t.html(l.text);
          break;
        }
        case "link": {
          const l = o;
          n += t.link(l.href, l.title, this.parseInline(l.tokens, t));
          break;
        }
        case "image": {
          const l = o;
          n += t.image(l.href, l.title, l.text);
          break;
        }
        case "strong": {
          const l = o;
          n += t.strong(this.parseInline(l.tokens, t));
          break;
        }
        case "em": {
          const l = o;
          n += t.em(this.parseInline(l.tokens, t));
          break;
        }
        case "codespan": {
          const l = o;
          n += t.codespan(l.text);
          break;
        }
        case "br": {
          n += t.br();
          break;
        }
        case "del": {
          const l = o;
          n += t.del(this.parseInline(l.tokens, t));
          break;
        }
        case "text": {
          const l = o;
          n += t.text(l.text);
          break;
        }
        default: {
          const l = 'Token with "' + o.type + '" type was not found.';
          if (this.options.silent)
            return console.error(l), "";
          throw new Error(l);
        }
      }
    }
    return n;
  }
}
class on {
  constructor(e) {
    ee(this, "options");
    this.options = e || Lt;
  }
  /**
   * Process markdown before marked
   */
  preprocess(e) {
    return e;
  }
  /**
   * Process HTML after marked is finished
   */
  postprocess(e) {
    return e;
  }
  /**
   * Process all tokens before walk tokens
   */
  processAllTokens(e) {
    return e;
  }
}
ee(on, "passThroughHooks", /* @__PURE__ */ new Set([
  "preprocess",
  "postprocess",
  "processAllTokens"
]));
var Rt, ni, bl;
class er {
  constructor(...e) {
    Li(this, Rt);
    ee(this, "defaults", fi());
    ee(this, "options", this.setOptions);
    ee(this, "parse", mn(this, Rt, ni).call(this, lt.lex, ot.parse));
    ee(this, "parseInline", mn(this, Rt, ni).call(this, lt.lexInline, ot.parseInline));
    ee(this, "Parser", ot);
    ee(this, "Renderer", Rn);
    ee(this, "TextRenderer", bi);
    ee(this, "Lexer", lt);
    ee(this, "Tokenizer", Bn);
    ee(this, "Hooks", on);
    this.use(...e);
  }
  /**
   * Run callback for every token
   */
  walkTokens(e, t) {
    var a, o;
    let n = [];
    for (const l of e)
      switch (n = n.concat(t.call(this, l)), l.type) {
        case "table": {
          const r = l;
          for (const s of r.header)
            n = n.concat(this.walkTokens(s.tokens, t));
          for (const s of r.rows)
            for (const u of s)
              n = n.concat(this.walkTokens(u.tokens, t));
          break;
        }
        case "list": {
          const r = l;
          n = n.concat(this.walkTokens(r.items, t));
          break;
        }
        default: {
          const r = l;
          (o = (a = this.defaults.extensions) == null ? void 0 : a.childTokens) != null && o[r.type] ? this.defaults.extensions.childTokens[r.type].forEach((s) => {
            const u = r[s].flat(1 / 0);
            n = n.concat(this.walkTokens(u, t));
          }) : r.tokens && (n = n.concat(this.walkTokens(r.tokens, t)));
        }
      }
    return n;
  }
  use(...e) {
    const t = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return e.forEach((n) => {
      const a = { ...n };
      if (a.async = this.defaults.async || a.async || !1, n.extensions && (n.extensions.forEach((o) => {
        if (!o.name)
          throw new Error("extension name required");
        if ("renderer" in o) {
          const l = t.renderers[o.name];
          l ? t.renderers[o.name] = function(...r) {
            let s = o.renderer.apply(this, r);
            return s === !1 && (s = l.apply(this, r)), s;
          } : t.renderers[o.name] = o.renderer;
        }
        if ("tokenizer" in o) {
          if (!o.level || o.level !== "block" && o.level !== "inline")
            throw new Error("extension level must be 'block' or 'inline'");
          const l = t[o.level];
          l ? l.unshift(o.tokenizer) : t[o.level] = [o.tokenizer], o.start && (o.level === "block" ? t.startBlock ? t.startBlock.push(o.start) : t.startBlock = [o.start] : o.level === "inline" && (t.startInline ? t.startInline.push(o.start) : t.startInline = [o.start]));
        }
        "childTokens" in o && o.childTokens && (t.childTokens[o.name] = o.childTokens);
      }), a.extensions = t), n.renderer) {
        const o = this.defaults.renderer || new Rn(this.defaults);
        for (const l in n.renderer) {
          if (!(l in o))
            throw new Error(`renderer '${l}' does not exist`);
          if (l === "options")
            continue;
          const r = l, s = n.renderer[r], u = o[r];
          o[r] = (...c) => {
            let m = s.apply(o, c);
            return m === !1 && (m = u.apply(o, c)), m || "";
          };
        }
        a.renderer = o;
      }
      if (n.tokenizer) {
        const o = this.defaults.tokenizer || new Bn(this.defaults);
        for (const l in n.tokenizer) {
          if (!(l in o))
            throw new Error(`tokenizer '${l}' does not exist`);
          if (["options", "rules", "lexer"].includes(l))
            continue;
          const r = l, s = n.tokenizer[r], u = o[r];
          o[r] = (...c) => {
            let m = s.apply(o, c);
            return m === !1 && (m = u.apply(o, c)), m;
          };
        }
        a.tokenizer = o;
      }
      if (n.hooks) {
        const o = this.defaults.hooks || new on();
        for (const l in n.hooks) {
          if (!(l in o))
            throw new Error(`hook '${l}' does not exist`);
          if (l === "options")
            continue;
          const r = l, s = n.hooks[r], u = o[r];
          on.passThroughHooks.has(l) ? o[r] = (c) => {
            if (this.defaults.async)
              return Promise.resolve(s.call(o, c)).then((d) => u.call(o, d));
            const m = s.call(o, c);
            return u.call(o, m);
          } : o[r] = (...c) => {
            let m = s.apply(o, c);
            return m === !1 && (m = u.apply(o, c)), m;
          };
        }
        a.hooks = o;
      }
      if (n.walkTokens) {
        const o = this.defaults.walkTokens, l = n.walkTokens;
        a.walkTokens = function(r) {
          let s = [];
          return s.push(l.call(this, r)), o && (s = s.concat(o.call(this, r))), s;
        };
      }
      this.defaults = { ...this.defaults, ...a };
    }), this;
  }
  setOptions(e) {
    return this.defaults = { ...this.defaults, ...e }, this;
  }
  lexer(e, t) {
    return lt.lex(e, t ?? this.defaults);
  }
  parser(e, t) {
    return ot.parse(e, t ?? this.defaults);
  }
}
Rt = new WeakSet(), ni = function(e, t) {
  return (n, a) => {
    const o = { ...a }, l = { ...this.defaults, ...o };
    this.defaults.async === !0 && o.async === !1 && (l.silent || console.warn("marked(): The async option was set to true by an extension. The async: false option sent to parse will be ignored."), l.async = !0);
    const r = mn(this, Rt, bl).call(this, !!l.silent, !!l.async);
    if (typeof n > "u" || n === null)
      return r(new Error("marked(): input parameter is undefined or null"));
    if (typeof n != "string")
      return r(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(n) + ", string expected"));
    if (l.hooks && (l.hooks.options = l), l.async)
      return Promise.resolve(l.hooks ? l.hooks.preprocess(n) : n).then((s) => e(s, l)).then((s) => l.hooks ? l.hooks.processAllTokens(s) : s).then((s) => l.walkTokens ? Promise.all(this.walkTokens(s, l.walkTokens)).then(() => s) : s).then((s) => t(s, l)).then((s) => l.hooks ? l.hooks.postprocess(s) : s).catch(r);
    try {
      l.hooks && (n = l.hooks.preprocess(n));
      let s = e(n, l);
      l.hooks && (s = l.hooks.processAllTokens(s)), l.walkTokens && this.walkTokens(s, l.walkTokens);
      let u = t(s, l);
      return l.hooks && (u = l.hooks.postprocess(u)), u;
    } catch (s) {
      return r(s);
    }
  };
}, bl = function(e, t) {
  return (n) => {
    if (n.message += `
Please report this to https://github.com/markedjs/marked.`, e) {
      const a = "<p>An error occurred:</p><pre>" + Oe(n.message + "", !0) + "</pre>";
      return t ? Promise.resolve(a) : a;
    }
    if (t)
      return Promise.reject(n);
    throw n;
  };
};
const It = new er();
function X(i, e) {
  return It.parse(i, e);
}
X.options = X.setOptions = function(i) {
  return It.setOptions(i), X.defaults = It.defaults, ul(X.defaults), X;
};
X.getDefaults = fi;
X.defaults = Lt;
X.use = function(...i) {
  return It.use(...i), X.defaults = It.defaults, ul(X.defaults), X;
};
X.walkTokens = function(i, e) {
  return It.walkTokens(i, e);
};
X.parseInline = It.parseInline;
X.Parser = ot;
X.parser = ot.parse;
X.Renderer = Rn;
X.TextRenderer = bi;
X.Lexer = lt;
X.lexer = lt.lex;
X.Tokenizer = Bn;
X.Hooks = on;
X.parse = X;
X.options;
X.setOptions;
X.use;
X.walkTokens;
X.parseInline;
ot.parse;
lt.lex;
const tr = /[\0-\x1F!-,\.\/:-@\[-\^`\{-\xA9\xAB-\xB4\xB6-\xB9\xBB-\xBF\xD7\xF7\u02C2-\u02C5\u02D2-\u02DF\u02E5-\u02EB\u02ED\u02EF-\u02FF\u0375\u0378\u0379\u037E\u0380-\u0385\u0387\u038B\u038D\u03A2\u03F6\u0482\u0530\u0557\u0558\u055A-\u055F\u0589-\u0590\u05BE\u05C0\u05C3\u05C6\u05C8-\u05CF\u05EB-\u05EE\u05F3-\u060F\u061B-\u061F\u066A-\u066D\u06D4\u06DD\u06DE\u06E9\u06FD\u06FE\u0700-\u070F\u074B\u074C\u07B2-\u07BF\u07F6-\u07F9\u07FB\u07FC\u07FE\u07FF\u082E-\u083F\u085C-\u085F\u086B-\u089F\u08B5\u08C8-\u08D2\u08E2\u0964\u0965\u0970\u0984\u098D\u098E\u0991\u0992\u09A9\u09B1\u09B3-\u09B5\u09BA\u09BB\u09C5\u09C6\u09C9\u09CA\u09CF-\u09D6\u09D8-\u09DB\u09DE\u09E4\u09E5\u09F2-\u09FB\u09FD\u09FF\u0A00\u0A04\u0A0B-\u0A0E\u0A11\u0A12\u0A29\u0A31\u0A34\u0A37\u0A3A\u0A3B\u0A3D\u0A43-\u0A46\u0A49\u0A4A\u0A4E-\u0A50\u0A52-\u0A58\u0A5D\u0A5F-\u0A65\u0A76-\u0A80\u0A84\u0A8E\u0A92\u0AA9\u0AB1\u0AB4\u0ABA\u0ABB\u0AC6\u0ACA\u0ACE\u0ACF\u0AD1-\u0ADF\u0AE4\u0AE5\u0AF0-\u0AF8\u0B00\u0B04\u0B0D\u0B0E\u0B11\u0B12\u0B29\u0B31\u0B34\u0B3A\u0B3B\u0B45\u0B46\u0B49\u0B4A\u0B4E-\u0B54\u0B58-\u0B5B\u0B5E\u0B64\u0B65\u0B70\u0B72-\u0B81\u0B84\u0B8B-\u0B8D\u0B91\u0B96-\u0B98\u0B9B\u0B9D\u0BA0-\u0BA2\u0BA5-\u0BA7\u0BAB-\u0BAD\u0BBA-\u0BBD\u0BC3-\u0BC5\u0BC9\u0BCE\u0BCF\u0BD1-\u0BD6\u0BD8-\u0BE5\u0BF0-\u0BFF\u0C0D\u0C11\u0C29\u0C3A-\u0C3C\u0C45\u0C49\u0C4E-\u0C54\u0C57\u0C5B-\u0C5F\u0C64\u0C65\u0C70-\u0C7F\u0C84\u0C8D\u0C91\u0CA9\u0CB4\u0CBA\u0CBB\u0CC5\u0CC9\u0CCE-\u0CD4\u0CD7-\u0CDD\u0CDF\u0CE4\u0CE5\u0CF0\u0CF3-\u0CFF\u0D0D\u0D11\u0D45\u0D49\u0D4F-\u0D53\u0D58-\u0D5E\u0D64\u0D65\u0D70-\u0D79\u0D80\u0D84\u0D97-\u0D99\u0DB2\u0DBC\u0DBE\u0DBF\u0DC7-\u0DC9\u0DCB-\u0DCE\u0DD5\u0DD7\u0DE0-\u0DE5\u0DF0\u0DF1\u0DF4-\u0E00\u0E3B-\u0E3F\u0E4F\u0E5A-\u0E80\u0E83\u0E85\u0E8B\u0EA4\u0EA6\u0EBE\u0EBF\u0EC5\u0EC7\u0ECE\u0ECF\u0EDA\u0EDB\u0EE0-\u0EFF\u0F01-\u0F17\u0F1A-\u0F1F\u0F2A-\u0F34\u0F36\u0F38\u0F3A-\u0F3D\u0F48\u0F6D-\u0F70\u0F85\u0F98\u0FBD-\u0FC5\u0FC7-\u0FFF\u104A-\u104F\u109E\u109F\u10C6\u10C8-\u10CC\u10CE\u10CF\u10FB\u1249\u124E\u124F\u1257\u1259\u125E\u125F\u1289\u128E\u128F\u12B1\u12B6\u12B7\u12BF\u12C1\u12C6\u12C7\u12D7\u1311\u1316\u1317\u135B\u135C\u1360-\u137F\u1390-\u139F\u13F6\u13F7\u13FE-\u1400\u166D\u166E\u1680\u169B-\u169F\u16EB-\u16ED\u16F9-\u16FF\u170D\u1715-\u171F\u1735-\u173F\u1754-\u175F\u176D\u1771\u1774-\u177F\u17D4-\u17D6\u17D8-\u17DB\u17DE\u17DF\u17EA-\u180A\u180E\u180F\u181A-\u181F\u1879-\u187F\u18AB-\u18AF\u18F6-\u18FF\u191F\u192C-\u192F\u193C-\u1945\u196E\u196F\u1975-\u197F\u19AC-\u19AF\u19CA-\u19CF\u19DA-\u19FF\u1A1C-\u1A1F\u1A5F\u1A7D\u1A7E\u1A8A-\u1A8F\u1A9A-\u1AA6\u1AA8-\u1AAF\u1AC1-\u1AFF\u1B4C-\u1B4F\u1B5A-\u1B6A\u1B74-\u1B7F\u1BF4-\u1BFF\u1C38-\u1C3F\u1C4A-\u1C4C\u1C7E\u1C7F\u1C89-\u1C8F\u1CBB\u1CBC\u1CC0-\u1CCF\u1CD3\u1CFB-\u1CFF\u1DFA\u1F16\u1F17\u1F1E\u1F1F\u1F46\u1F47\u1F4E\u1F4F\u1F58\u1F5A\u1F5C\u1F5E\u1F7E\u1F7F\u1FB5\u1FBD\u1FBF-\u1FC1\u1FC5\u1FCD-\u1FCF\u1FD4\u1FD5\u1FDC-\u1FDF\u1FED-\u1FF1\u1FF5\u1FFD-\u203E\u2041-\u2053\u2055-\u2070\u2072-\u207E\u2080-\u208F\u209D-\u20CF\u20F1-\u2101\u2103-\u2106\u2108\u2109\u2114\u2116-\u2118\u211E-\u2123\u2125\u2127\u2129\u212E\u213A\u213B\u2140-\u2144\u214A-\u214D\u214F-\u215F\u2189-\u24B5\u24EA-\u2BFF\u2C2F\u2C5F\u2CE5-\u2CEA\u2CF4-\u2CFF\u2D26\u2D28-\u2D2C\u2D2E\u2D2F\u2D68-\u2D6E\u2D70-\u2D7E\u2D97-\u2D9F\u2DA7\u2DAF\u2DB7\u2DBF\u2DC7\u2DCF\u2DD7\u2DDF\u2E00-\u2E2E\u2E30-\u3004\u3008-\u3020\u3030\u3036\u3037\u303D-\u3040\u3097\u3098\u309B\u309C\u30A0\u30FB\u3100-\u3104\u3130\u318F-\u319F\u31C0-\u31EF\u3200-\u33FF\u4DC0-\u4DFF\u9FFD-\u9FFF\uA48D-\uA4CF\uA4FE\uA4FF\uA60D-\uA60F\uA62C-\uA63F\uA673\uA67E\uA6F2-\uA716\uA720\uA721\uA789\uA78A\uA7C0\uA7C1\uA7CB-\uA7F4\uA828-\uA82B\uA82D-\uA83F\uA874-\uA87F\uA8C6-\uA8CF\uA8DA-\uA8DF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA954-\uA95F\uA97D-\uA97F\uA9C1-\uA9CE\uA9DA-\uA9DF\uA9FF\uAA37-\uAA3F\uAA4E\uAA4F\uAA5A-\uAA5F\uAA77-\uAA79\uAAC3-\uAADA\uAADE\uAADF\uAAF0\uAAF1\uAAF7-\uAB00\uAB07\uAB08\uAB0F\uAB10\uAB17-\uAB1F\uAB27\uAB2F\uAB5B\uAB6A-\uAB6F\uABEB\uABEE\uABEF\uABFA-\uABFF\uD7A4-\uD7AF\uD7C7-\uD7CA\uD7FC-\uD7FF\uE000-\uF8FF\uFA6E\uFA6F\uFADA-\uFAFF\uFB07-\uFB12\uFB18-\uFB1C\uFB29\uFB37\uFB3D\uFB3F\uFB42\uFB45\uFBB2-\uFBD2\uFD3E-\uFD4F\uFD90\uFD91\uFDC8-\uFDEF\uFDFC-\uFDFF\uFE10-\uFE1F\uFE30-\uFE32\uFE35-\uFE4C\uFE50-\uFE6F\uFE75\uFEFD-\uFF0F\uFF1A-\uFF20\uFF3B-\uFF3E\uFF40\uFF5B-\uFF65\uFFBF-\uFFC1\uFFC8\uFFC9\uFFD0\uFFD1\uFFD8\uFFD9\uFFDD-\uFFFF]|\uD800[\uDC0C\uDC27\uDC3B\uDC3E\uDC4E\uDC4F\uDC5E-\uDC7F\uDCFB-\uDD3F\uDD75-\uDDFC\uDDFE-\uDE7F\uDE9D-\uDE9F\uDED1-\uDEDF\uDEE1-\uDEFF\uDF20-\uDF2C\uDF4B-\uDF4F\uDF7B-\uDF7F\uDF9E\uDF9F\uDFC4-\uDFC7\uDFD0\uDFD6-\uDFFF]|\uD801[\uDC9E\uDC9F\uDCAA-\uDCAF\uDCD4-\uDCD7\uDCFC-\uDCFF\uDD28-\uDD2F\uDD64-\uDDFF\uDF37-\uDF3F\uDF56-\uDF5F\uDF68-\uDFFF]|\uD802[\uDC06\uDC07\uDC09\uDC36\uDC39-\uDC3B\uDC3D\uDC3E\uDC56-\uDC5F\uDC77-\uDC7F\uDC9F-\uDCDF\uDCF3\uDCF6-\uDCFF\uDD16-\uDD1F\uDD3A-\uDD7F\uDDB8-\uDDBD\uDDC0-\uDDFF\uDE04\uDE07-\uDE0B\uDE14\uDE18\uDE36\uDE37\uDE3B-\uDE3E\uDE40-\uDE5F\uDE7D-\uDE7F\uDE9D-\uDEBF\uDEC8\uDEE7-\uDEFF\uDF36-\uDF3F\uDF56-\uDF5F\uDF73-\uDF7F\uDF92-\uDFFF]|\uD803[\uDC49-\uDC7F\uDCB3-\uDCBF\uDCF3-\uDCFF\uDD28-\uDD2F\uDD3A-\uDE7F\uDEAA\uDEAD-\uDEAF\uDEB2-\uDEFF\uDF1D-\uDF26\uDF28-\uDF2F\uDF51-\uDFAF\uDFC5-\uDFDF\uDFF7-\uDFFF]|\uD804[\uDC47-\uDC65\uDC70-\uDC7E\uDCBB-\uDCCF\uDCE9-\uDCEF\uDCFA-\uDCFF\uDD35\uDD40-\uDD43\uDD48-\uDD4F\uDD74\uDD75\uDD77-\uDD7F\uDDC5-\uDDC8\uDDCD\uDDDB\uDDDD-\uDDFF\uDE12\uDE38-\uDE3D\uDE3F-\uDE7F\uDE87\uDE89\uDE8E\uDE9E\uDEA9-\uDEAF\uDEEB-\uDEEF\uDEFA-\uDEFF\uDF04\uDF0D\uDF0E\uDF11\uDF12\uDF29\uDF31\uDF34\uDF3A\uDF45\uDF46\uDF49\uDF4A\uDF4E\uDF4F\uDF51-\uDF56\uDF58-\uDF5C\uDF64\uDF65\uDF6D-\uDF6F\uDF75-\uDFFF]|\uD805[\uDC4B-\uDC4F\uDC5A-\uDC5D\uDC62-\uDC7F\uDCC6\uDCC8-\uDCCF\uDCDA-\uDD7F\uDDB6\uDDB7\uDDC1-\uDDD7\uDDDE-\uDDFF\uDE41-\uDE43\uDE45-\uDE4F\uDE5A-\uDE7F\uDEB9-\uDEBF\uDECA-\uDEFF\uDF1B\uDF1C\uDF2C-\uDF2F\uDF3A-\uDFFF]|\uD806[\uDC3B-\uDC9F\uDCEA-\uDCFE\uDD07\uDD08\uDD0A\uDD0B\uDD14\uDD17\uDD36\uDD39\uDD3A\uDD44-\uDD4F\uDD5A-\uDD9F\uDDA8\uDDA9\uDDD8\uDDD9\uDDE2\uDDE5-\uDDFF\uDE3F-\uDE46\uDE48-\uDE4F\uDE9A-\uDE9C\uDE9E-\uDEBF\uDEF9-\uDFFF]|\uD807[\uDC09\uDC37\uDC41-\uDC4F\uDC5A-\uDC71\uDC90\uDC91\uDCA8\uDCB7-\uDCFF\uDD07\uDD0A\uDD37-\uDD39\uDD3B\uDD3E\uDD48-\uDD4F\uDD5A-\uDD5F\uDD66\uDD69\uDD8F\uDD92\uDD99-\uDD9F\uDDAA-\uDEDF\uDEF7-\uDFAF\uDFB1-\uDFFF]|\uD808[\uDF9A-\uDFFF]|\uD809[\uDC6F-\uDC7F\uDD44-\uDFFF]|[\uD80A\uD80B\uD80E-\uD810\uD812-\uD819\uD824-\uD82B\uD82D\uD82E\uD830-\uD833\uD837\uD839\uD83D\uD83F\uD87B-\uD87D\uD87F\uD885-\uDB3F\uDB41-\uDBFF][\uDC00-\uDFFF]|\uD80D[\uDC2F-\uDFFF]|\uD811[\uDE47-\uDFFF]|\uD81A[\uDE39-\uDE3F\uDE5F\uDE6A-\uDECF\uDEEE\uDEEF\uDEF5-\uDEFF\uDF37-\uDF3F\uDF44-\uDF4F\uDF5A-\uDF62\uDF78-\uDF7C\uDF90-\uDFFF]|\uD81B[\uDC00-\uDE3F\uDE80-\uDEFF\uDF4B-\uDF4E\uDF88-\uDF8E\uDFA0-\uDFDF\uDFE2\uDFE5-\uDFEF\uDFF2-\uDFFF]|\uD821[\uDFF8-\uDFFF]|\uD823[\uDCD6-\uDCFF\uDD09-\uDFFF]|\uD82C[\uDD1F-\uDD4F\uDD53-\uDD63\uDD68-\uDD6F\uDEFC-\uDFFF]|\uD82F[\uDC6B-\uDC6F\uDC7D-\uDC7F\uDC89-\uDC8F\uDC9A-\uDC9C\uDC9F-\uDFFF]|\uD834[\uDC00-\uDD64\uDD6A-\uDD6C\uDD73-\uDD7A\uDD83\uDD84\uDD8C-\uDDA9\uDDAE-\uDE41\uDE45-\uDFFF]|\uD835[\uDC55\uDC9D\uDCA0\uDCA1\uDCA3\uDCA4\uDCA7\uDCA8\uDCAD\uDCBA\uDCBC\uDCC4\uDD06\uDD0B\uDD0C\uDD15\uDD1D\uDD3A\uDD3F\uDD45\uDD47-\uDD49\uDD51\uDEA6\uDEA7\uDEC1\uDEDB\uDEFB\uDF15\uDF35\uDF4F\uDF6F\uDF89\uDFA9\uDFC3\uDFCC\uDFCD]|\uD836[\uDC00-\uDDFF\uDE37-\uDE3A\uDE6D-\uDE74\uDE76-\uDE83\uDE85-\uDE9A\uDEA0\uDEB0-\uDFFF]|\uD838[\uDC07\uDC19\uDC1A\uDC22\uDC25\uDC2B-\uDCFF\uDD2D-\uDD2F\uDD3E\uDD3F\uDD4A-\uDD4D\uDD4F-\uDEBF\uDEFA-\uDFFF]|\uD83A[\uDCC5-\uDCCF\uDCD7-\uDCFF\uDD4C-\uDD4F\uDD5A-\uDFFF]|\uD83B[\uDC00-\uDDFF\uDE04\uDE20\uDE23\uDE25\uDE26\uDE28\uDE33\uDE38\uDE3A\uDE3C-\uDE41\uDE43-\uDE46\uDE48\uDE4A\uDE4C\uDE50\uDE53\uDE55\uDE56\uDE58\uDE5A\uDE5C\uDE5E\uDE60\uDE63\uDE65\uDE66\uDE6B\uDE73\uDE78\uDE7D\uDE7F\uDE8A\uDE9C-\uDEA0\uDEA4\uDEAA\uDEBC-\uDFFF]|\uD83C[\uDC00-\uDD2F\uDD4A-\uDD4F\uDD6A-\uDD6F\uDD8A-\uDFFF]|\uD83E[\uDC00-\uDFEF\uDFFA-\uDFFF]|\uD869[\uDEDE-\uDEFF]|\uD86D[\uDF35-\uDF3F]|\uD86E[\uDC1E\uDC1F]|\uD873[\uDEA2-\uDEAF]|\uD87A[\uDFE1-\uDFFF]|\uD87E[\uDE1E-\uDFFF]|\uD884[\uDF4B-\uDFFF]|\uDB40[\uDC00-\uDCFF\uDDF0-\uDFFF]/g, nr = Object.hasOwnProperty;
class Dl {
  /**
   * Create a new slug class.
   */
  constructor() {
    this.occurrences, this.reset();
  }
  /**
   * Generate a unique slug.
  *
  * Tracks previously generated slugs: repeated calls with the same value
  * will result in different slugs.
  * Use the `slug` function to get same slugs.
   *
   * @param  {string} value
   *   String of text to slugify
   * @param  {boolean} [maintainCase=false]
   *   Keep the current case, otherwise make all lowercase
   * @return {string}
   *   A unique slug string
   */
  slug(e, t) {
    const n = this;
    let a = ir(e, t === !0);
    const o = a;
    for (; nr.call(n.occurrences, a); )
      n.occurrences[o]++, a = o + "-" + n.occurrences[o];
    return n.occurrences[a] = 0, a;
  }
  /**
   * Reset - Forget all previous slugs
   *
   * @return void
   */
  reset() {
    this.occurrences = /* @__PURE__ */ Object.create(null);
  }
}
function ir(i, e) {
  return typeof i != "string" ? "" : (e || (i = i.toLowerCase()), i.replace(tr, "").replace(/ /g, "-"));
}
new Dl();
var Gi = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {}, ar = { exports: {} };
(function(i) {
  var e = typeof window < "u" ? window : typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope ? self : {};
  /**
   * Prism: Lightweight, robust, elegant syntax highlighting
   *
   * @license MIT <https://opensource.org/licenses/MIT>
   * @author Lea Verou <https://lea.verou.me>
   * @namespace
   * @public
   */
  var t = function(n) {
    var a = /(?:^|\s)lang(?:uage)?-([\w-]+)(?=\s|$)/i, o = 0, l = {}, r = {
      /**
       * By default, Prism will attempt to highlight all code elements (by calling {@link Prism.highlightAll}) on the
       * current page after the page finished loading. This might be a problem if e.g. you wanted to asynchronously load
       * additional languages or plugins yourself.
       *
       * By setting this value to `true`, Prism will not automatically highlight all code elements on the page.
       *
       * You obviously have to change this value before the automatic highlighting started. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.manual = true;
       * // add a new <script> to load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      manual: n.Prism && n.Prism.manual,
      /**
       * By default, if Prism is in a web worker, it assumes that it is in a worker it created itself, so it uses
       * `addEventListener` to communicate with its parent instance. However, if you're using Prism manually in your
       * own worker, you don't want it to do this.
       *
       * By setting this value to `true`, Prism will not add its own listeners to the worker.
       *
       * You obviously have to change this value before Prism executes. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.disableWorkerMessageHandler = true;
       * // Load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      disableWorkerMessageHandler: n.Prism && n.Prism.disableWorkerMessageHandler,
      /**
       * A namespace for utility methods.
       *
       * All function in this namespace that are not explicitly marked as _public_ are for __internal use only__ and may
       * change or disappear at any time.
       *
       * @namespace
       * @memberof Prism
       */
      util: {
        encode: function h(_) {
          return _ instanceof s ? new s(_.type, h(_.content), _.alias) : Array.isArray(_) ? _.map(h) : _.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\u00a0/g, " ");
        },
        /**
         * Returns the name of the type of the given value.
         *
         * @param {any} o
         * @returns {string}
         * @example
         * type(null)      === 'Null'
         * type(undefined) === 'Undefined'
         * type(123)       === 'Number'
         * type('foo')     === 'String'
         * type(true)      === 'Boolean'
         * type([1, 2])    === 'Array'
         * type({})        === 'Object'
         * type(String)    === 'Function'
         * type(/abc+/)    === 'RegExp'
         */
        type: function(h) {
          return Object.prototype.toString.call(h).slice(8, -1);
        },
        /**
         * Returns a unique number for the given object. Later calls will still return the same number.
         *
         * @param {Object} obj
         * @returns {number}
         */
        objId: function(h) {
          return h.__id || Object.defineProperty(h, "__id", { value: ++o }), h.__id;
        },
        /**
         * Creates a deep clone of the given object.
         *
         * The main intended use of this function is to clone language definitions.
         *
         * @param {T} o
         * @param {Record<number, any>} [visited]
         * @returns {T}
         * @template T
         */
        clone: function h(_, g) {
          g = g || {};
          var y, $;
          switch (r.util.type(_)) {
            case "Object":
              if ($ = r.util.objId(_), g[$])
                return g[$];
              y = /** @type {Record<string, any>} */
              {}, g[$] = y;
              for (var C in _)
                _.hasOwnProperty(C) && (y[C] = h(_[C], g));
              return (
                /** @type {any} */
                y
              );
            case "Array":
              return $ = r.util.objId(_), g[$] ? g[$] : (y = [], g[$] = y, /** @type {Array} */
              /** @type {any} */
              _.forEach(function(I, T) {
                y[T] = h(I, g);
              }), /** @type {any} */
              y);
            default:
              return _;
          }
        },
        /**
         * Returns the Prism language of the given element set by a `language-xxxx` or `lang-xxxx` class.
         *
         * If no language is set for the element or the element is `null` or `undefined`, `none` will be returned.
         *
         * @param {Element} element
         * @returns {string}
         */
        getLanguage: function(h) {
          for (; h; ) {
            var _ = a.exec(h.className);
            if (_)
              return _[1].toLowerCase();
            h = h.parentElement;
          }
          return "none";
        },
        /**
         * Sets the Prism `language-xxxx` class of the given element.
         *
         * @param {Element} element
         * @param {string} language
         * @returns {void}
         */
        setLanguage: function(h, _) {
          h.className = h.className.replace(RegExp(a, "gi"), ""), h.classList.add("language-" + _);
        },
        /**
         * Returns the script element that is currently executing.
         *
         * This does __not__ work for line script element.
         *
         * @returns {HTMLScriptElement | null}
         */
        currentScript: function() {
          if (typeof document > "u")
            return null;
          if ("currentScript" in document)
            return (
              /** @type {any} */
              document.currentScript
            );
          try {
            throw new Error();
          } catch (y) {
            var h = (/at [^(\r\n]*\((.*):[^:]+:[^:]+\)$/i.exec(y.stack) || [])[1];
            if (h) {
              var _ = document.getElementsByTagName("script");
              for (var g in _)
                if (_[g].src == h)
                  return _[g];
            }
            return null;
          }
        },
        /**
         * Returns whether a given class is active for `element`.
         *
         * The class can be activated if `element` or one of its ancestors has the given class and it can be deactivated
         * if `element` or one of its ancestors has the negated version of the given class. The _negated version_ of the
         * given class is just the given class with a `no-` prefix.
         *
         * Whether the class is active is determined by the closest ancestor of `element` (where `element` itself is
         * closest ancestor) that has the given class or the negated version of it. If neither `element` nor any of its
         * ancestors have the given class or the negated version of it, then the default activation will be returned.
         *
         * In the paradoxical situation where the closest ancestor contains __both__ the given class and the negated
         * version of it, the class is considered active.
         *
         * @param {Element} element
         * @param {string} className
         * @param {boolean} [defaultActivation=false]
         * @returns {boolean}
         */
        isActive: function(h, _, g) {
          for (var y = "no-" + _; h; ) {
            var $ = h.classList;
            if ($.contains(_))
              return !0;
            if ($.contains(y))
              return !1;
            h = h.parentElement;
          }
          return !!g;
        }
      },
      /**
       * This namespace contains all currently loaded languages and the some helper functions to create and modify languages.
       *
       * @namespace
       * @memberof Prism
       * @public
       */
      languages: {
        /**
         * The grammar for plain, unformatted text.
         */
        plain: l,
        plaintext: l,
        text: l,
        txt: l,
        /**
         * Creates a deep copy of the language with the given id and appends the given tokens.
         *
         * If a token in `redef` also appears in the copied language, then the existing token in the copied language
         * will be overwritten at its original position.
         *
         * ## Best practices
         *
         * Since the position of overwriting tokens (token in `redef` that overwrite tokens in the copied language)
         * doesn't matter, they can technically be in any order. However, this can be confusing to others that trying to
         * understand the language definition because, normally, the order of tokens matters in Prism grammars.
         *
         * Therefore, it is encouraged to order overwriting tokens according to the positions of the overwritten tokens.
         * Furthermore, all non-overwriting tokens should be placed after the overwriting ones.
         *
         * @param {string} id The id of the language to extend. This has to be a key in `Prism.languages`.
         * @param {Grammar} redef The new tokens to append.
         * @returns {Grammar} The new language created.
         * @public
         * @example
         * Prism.languages['css-with-colors'] = Prism.languages.extend('css', {
         *     // Prism.languages.css already has a 'comment' token, so this token will overwrite CSS' 'comment' token
         *     // at its original position
         *     'comment': { ... },
         *     // CSS doesn't have a 'color' token, so this token will be appended
         *     'color': /\b(?:red|green|blue)\b/
         * });
         */
        extend: function(h, _) {
          var g = r.util.clone(r.languages[h]);
          for (var y in _)
            g[y] = _[y];
          return g;
        },
        /**
         * Inserts tokens _before_ another token in a language definition or any other grammar.
         *
         * ## Usage
         *
         * This helper method makes it easy to modify existing languages. For example, the CSS language definition
         * not only defines CSS highlighting for CSS documents, but also needs to define highlighting for CSS embedded
         * in HTML through `<style>` elements. To do this, it needs to modify `Prism.languages.markup` and add the
         * appropriate tokens. However, `Prism.languages.markup` is a regular JavaScript object literal, so if you do
         * this:
         *
         * ```js
         * Prism.languages.markup.style = {
         *     // token
         * };
         * ```
         *
         * then the `style` token will be added (and processed) at the end. `insertBefore` allows you to insert tokens
         * before existing tokens. For the CSS example above, you would use it like this:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'cdata', {
         *     'style': {
         *         // token
         *     }
         * });
         * ```
         *
         * ## Special cases
         *
         * If the grammars of `inside` and `insert` have tokens with the same name, the tokens in `inside`'s grammar
         * will be ignored.
         *
         * This behavior can be used to insert tokens after `before`:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'comment', {
         *     'comment': Prism.languages.markup.comment,
         *     // tokens after 'comment'
         * });
         * ```
         *
         * ## Limitations
         *
         * The main problem `insertBefore` has to solve is iteration order. Since ES2015, the iteration order for object
         * properties is guaranteed to be the insertion order (except for integer keys) but some browsers behave
         * differently when keys are deleted and re-inserted. So `insertBefore` can't be implemented by temporarily
         * deleting properties which is necessary to insert at arbitrary positions.
         *
         * To solve this problem, `insertBefore` doesn't actually insert the given tokens into the target object.
         * Instead, it will create a new object and replace all references to the target object with the new one. This
         * can be done without temporarily deleting properties, so the iteration order is well-defined.
         *
         * However, only references that can be reached from `Prism.languages` or `insert` will be replaced. I.e. if
         * you hold the target object in a variable, then the value of the variable will not change.
         *
         * ```js
         * var oldMarkup = Prism.languages.markup;
         * var newMarkup = Prism.languages.insertBefore('markup', 'comment', { ... });
         *
         * assert(oldMarkup !== Prism.languages.markup);
         * assert(newMarkup === Prism.languages.markup);
         * ```
         *
         * @param {string} inside The property of `root` (e.g. a language id in `Prism.languages`) that contains the
         * object to be modified.
         * @param {string} before The key to insert before.
         * @param {Grammar} insert An object containing the key-value pairs to be inserted.
         * @param {Object<string, any>} [root] The object containing `inside`, i.e. the object that contains the
         * object to be modified.
         *
         * Defaults to `Prism.languages`.
         * @returns {Grammar} The new grammar object.
         * @public
         */
        insertBefore: function(h, _, g, y) {
          y = y || /** @type {any} */
          r.languages;
          var $ = y[h], C = {};
          for (var I in $)
            if ($.hasOwnProperty(I)) {
              if (I == _)
                for (var T in g)
                  g.hasOwnProperty(T) && (C[T] = g[T]);
              g.hasOwnProperty(I) || (C[I] = $[I]);
            }
          var M = y[h];
          return y[h] = C, r.languages.DFS(r.languages, function(N, j) {
            j === M && N != h && (this[N] = C);
          }), C;
        },
        // Traverse a language definition with Depth First Search
        DFS: function h(_, g, y, $) {
          $ = $ || {};
          var C = r.util.objId;
          for (var I in _)
            if (_.hasOwnProperty(I)) {
              g.call(_, I, _[I], y || I);
              var T = _[I], M = r.util.type(T);
              M === "Object" && !$[C(T)] ? ($[C(T)] = !0, h(T, g, null, $)) : M === "Array" && !$[C(T)] && ($[C(T)] = !0, h(T, g, I, $));
            }
        }
      },
      plugins: {},
      /**
       * This is the most high-level function in Prism’s API.
       * It fetches all the elements that have a `.language-xxxx` class and then calls {@link Prism.highlightElement} on
       * each one of them.
       *
       * This is equivalent to `Prism.highlightAllUnder(document, async, callback)`.
       *
       * @param {boolean} [async=false] Same as in {@link Prism.highlightAllUnder}.
       * @param {HighlightCallback} [callback] Same as in {@link Prism.highlightAllUnder}.
       * @memberof Prism
       * @public
       */
      highlightAll: function(h, _) {
        r.highlightAllUnder(document, h, _);
      },
      /**
       * Fetches all the descendants of `container` that have a `.language-xxxx` class and then calls
       * {@link Prism.highlightElement} on each one of them.
       *
       * The following hooks will be run:
       * 1. `before-highlightall`
       * 2. `before-all-elements-highlight`
       * 3. All hooks of {@link Prism.highlightElement} for each element.
       *
       * @param {ParentNode} container The root element, whose descendants that have a `.language-xxxx` class will be highlighted.
       * @param {boolean} [async=false] Whether each element is to be highlighted asynchronously using Web Workers.
       * @param {HighlightCallback} [callback] An optional callback to be invoked on each element after its highlighting is done.
       * @memberof Prism
       * @public
       */
      highlightAllUnder: function(h, _, g) {
        var y = {
          callback: g,
          container: h,
          selector: 'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'
        };
        r.hooks.run("before-highlightall", y), y.elements = Array.prototype.slice.apply(y.container.querySelectorAll(y.selector)), r.hooks.run("before-all-elements-highlight", y);
        for (var $ = 0, C; C = y.elements[$++]; )
          r.highlightElement(C, _ === !0, y.callback);
      },
      /**
       * Highlights the code inside a single element.
       *
       * The following hooks will be run:
       * 1. `before-sanity-check`
       * 2. `before-highlight`
       * 3. All hooks of {@link Prism.highlight}. These hooks will be run by an asynchronous worker if `async` is `true`.
       * 4. `before-insert`
       * 5. `after-highlight`
       * 6. `complete`
       *
       * Some the above hooks will be skipped if the element doesn't contain any text or there is no grammar loaded for
       * the element's language.
       *
       * @param {Element} element The element containing the code.
       * It must have a class of `language-xxxx` to be processed, where `xxxx` is a valid language identifier.
       * @param {boolean} [async=false] Whether the element is to be highlighted asynchronously using Web Workers
       * to improve performance and avoid blocking the UI when highlighting very large chunks of code. This option is
       * [disabled by default](https://prismjs.com/faq.html#why-is-asynchronous-highlighting-disabled-by-default).
       *
       * Note: All language definitions required to highlight the code must be included in the main `prism.js` file for
       * asynchronous highlighting to work. You can build your own bundle on the
       * [Download page](https://prismjs.com/download.html).
       * @param {HighlightCallback} [callback] An optional callback to be invoked after the highlighting is done.
       * Mostly useful when `async` is `true`, since in that case, the highlighting is done asynchronously.
       * @memberof Prism
       * @public
       */
      highlightElement: function(h, _, g) {
        var y = r.util.getLanguage(h), $ = r.languages[y];
        r.util.setLanguage(h, y);
        var C = h.parentElement;
        C && C.nodeName.toLowerCase() === "pre" && r.util.setLanguage(C, y);
        var I = h.textContent, T = {
          element: h,
          language: y,
          grammar: $,
          code: I
        };
        function M(j) {
          T.highlightedCode = j, r.hooks.run("before-insert", T), T.element.innerHTML = T.highlightedCode, r.hooks.run("after-highlight", T), r.hooks.run("complete", T), g && g.call(T.element);
        }
        if (r.hooks.run("before-sanity-check", T), C = T.element.parentElement, C && C.nodeName.toLowerCase() === "pre" && !C.hasAttribute("tabindex") && C.setAttribute("tabindex", "0"), !T.code) {
          r.hooks.run("complete", T), g && g.call(T.element);
          return;
        }
        if (r.hooks.run("before-highlight", T), !T.grammar) {
          M(r.util.encode(T.code));
          return;
        }
        if (_ && n.Worker) {
          var N = new Worker(r.filename);
          N.onmessage = function(j) {
            M(j.data);
          }, N.postMessage(JSON.stringify({
            language: T.language,
            code: T.code,
            immediateClose: !0
          }));
        } else
          M(r.highlight(T.code, T.grammar, T.language));
      },
      /**
       * Low-level function, only use if you know what you’re doing. It accepts a string of text as input
       * and the language definitions to use, and returns a string with the HTML produced.
       *
       * The following hooks will be run:
       * 1. `before-tokenize`
       * 2. `after-tokenize`
       * 3. `wrap`: On each {@link Token}.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @param {string} language The name of the language definition passed to `grammar`.
       * @returns {string} The highlighted HTML.
       * @memberof Prism
       * @public
       * @example
       * Prism.highlight('var foo = true;', Prism.languages.javascript, 'javascript');
       */
      highlight: function(h, _, g) {
        var y = {
          code: h,
          grammar: _,
          language: g
        };
        if (r.hooks.run("before-tokenize", y), !y.grammar)
          throw new Error('The language "' + y.language + '" has no grammar.');
        return y.tokens = r.tokenize(y.code, y.grammar), r.hooks.run("after-tokenize", y), s.stringify(r.util.encode(y.tokens), y.language);
      },
      /**
       * This is the heart of Prism, and the most low-level function you can use. It accepts a string of text as input
       * and the language definitions to use, and returns an array with the tokenized code.
       *
       * When the language definition includes nested tokens, the function is called recursively on each of these tokens.
       *
       * This method could be useful in other contexts as well, as a very crude parser.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @returns {TokenStream} An array of strings and tokens, a token stream.
       * @memberof Prism
       * @public
       * @example
       * let code = `var foo = 0;`;
       * let tokens = Prism.tokenize(code, Prism.languages.javascript);
       * tokens.forEach(token => {
       *     if (token instanceof Prism.Token && token.type === 'number') {
       *         console.log(`Found numeric literal: ${token.content}`);
       *     }
       * });
       */
      tokenize: function(h, _) {
        var g = _.rest;
        if (g) {
          for (var y in g)
            _[y] = g[y];
          delete _.rest;
        }
        var $ = new m();
        return d($, $.head, h), c(h, $, _, $.head, 0), v($);
      },
      /**
       * @namespace
       * @memberof Prism
       * @public
       */
      hooks: {
        all: {},
        /**
         * Adds the given callback to the list of callbacks for the given hook.
         *
         * The callback will be invoked when the hook it is registered for is run.
         * Hooks are usually directly run by a highlight function but you can also run hooks yourself.
         *
         * One callback function can be registered to multiple hooks and the same hook multiple times.
         *
         * @param {string} name The name of the hook.
         * @param {HookCallback} callback The callback function which is given environment variables.
         * @public
         */
        add: function(h, _) {
          var g = r.hooks.all;
          g[h] = g[h] || [], g[h].push(_);
        },
        /**
         * Runs a hook invoking all registered callbacks with the given environment variables.
         *
         * Callbacks will be invoked synchronously and in the order in which they were registered.
         *
         * @param {string} name The name of the hook.
         * @param {Object<string, any>} env The environment variables of the hook passed to all callbacks registered.
         * @public
         */
        run: function(h, _) {
          var g = r.hooks.all[h];
          if (!(!g || !g.length))
            for (var y = 0, $; $ = g[y++]; )
              $(_);
        }
      },
      Token: s
    };
    n.Prism = r;
    function s(h, _, g, y) {
      this.type = h, this.content = _, this.alias = g, this.length = (y || "").length | 0;
    }
    s.stringify = function h(_, g) {
      if (typeof _ == "string")
        return _;
      if (Array.isArray(_)) {
        var y = "";
        return _.forEach(function(M) {
          y += h(M, g);
        }), y;
      }
      var $ = {
        type: _.type,
        content: h(_.content, g),
        tag: "span",
        classes: ["token", _.type],
        attributes: {},
        language: g
      }, C = _.alias;
      C && (Array.isArray(C) ? Array.prototype.push.apply($.classes, C) : $.classes.push(C)), r.hooks.run("wrap", $);
      var I = "";
      for (var T in $.attributes)
        I += " " + T + '="' + ($.attributes[T] || "").replace(/"/g, "&quot;") + '"';
      return "<" + $.tag + ' class="' + $.classes.join(" ") + '"' + I + ">" + $.content + "</" + $.tag + ">";
    };
    function u(h, _, g, y) {
      h.lastIndex = _;
      var $ = h.exec(g);
      if ($ && y && $[1]) {
        var C = $[1].length;
        $.index += C, $[0] = $[0].slice(C);
      }
      return $;
    }
    function c(h, _, g, y, $, C) {
      for (var I in g)
        if (!(!g.hasOwnProperty(I) || !g[I])) {
          var T = g[I];
          T = Array.isArray(T) ? T : [T];
          for (var M = 0; M < T.length; ++M) {
            if (C && C.cause == I + "," + M)
              return;
            var N = T[M], j = N.inside, ke = !!N.lookbehind, ce = !!N.greedy, Ee = N.alias;
            if (ce && !N.pattern.global) {
              var pe = N.pattern.toString().match(/[imsuy]*$/)[0];
              N.pattern = RegExp(N.pattern.source, pe + "g");
            }
            for (var ie = N.pattern || N, Q = y.next, se = $; Q !== _.tail && !(C && se >= C.reach); se += Q.value.length, Q = Q.next) {
              var be = Q.value;
              if (_.length > h.length)
                return;
              if (!(be instanceof s)) {
                var k = 1, oe;
                if (ce) {
                  if (oe = u(ie, se, h, ke), !oe || oe.index >= h.length)
                    break;
                  var Te = oe.index, J = oe.index + oe[0].length, he = se;
                  for (he += Q.value.length; Te >= he; )
                    Q = Q.next, he += Q.value.length;
                  if (he -= Q.value.length, se = he, Q.value instanceof s)
                    continue;
                  for (var A = Q; A !== _.tail && (he < J || typeof A.value == "string"); A = A.next)
                    k++, he += A.value.length;
                  k--, be = h.slice(se, he), oe.index -= se;
                } else if (oe = u(ie, 0, be, ke), !oe)
                  continue;
                var Te = oe.index, Qe = oe[0], Dt = be.slice(0, Te), yt = be.slice(Te + Qe.length), wt = se + be.length;
                C && wt > C.reach && (C.reach = wt);
                var ft = Q.prev;
                Dt && (ft = d(_, ft, Dt), se += Dt.length), f(_, ft, k);
                var Je = new s(I, j ? r.tokenize(Qe, j) : Qe, Ee, Qe);
                if (Q = d(_, ft, Je), yt && d(_, Q, yt), k > 1) {
                  var et = {
                    cause: I + "," + M,
                    reach: wt
                  };
                  c(h, _, g, Q.prev, se, et), C && et.reach > C.reach && (C.reach = et.reach);
                }
              }
            }
          }
        }
    }
    function m() {
      var h = { value: null, prev: null, next: null }, _ = { value: null, prev: h, next: null };
      h.next = _, this.head = h, this.tail = _, this.length = 0;
    }
    function d(h, _, g) {
      var y = _.next, $ = { value: g, prev: _, next: y };
      return _.next = $, y.prev = $, h.length++, $;
    }
    function f(h, _, g) {
      for (var y = _.next, $ = 0; $ < g && y !== h.tail; $++)
        y = y.next;
      _.next = y, y.prev = _, h.length -= $;
    }
    function v(h) {
      for (var _ = [], g = h.head.next; g !== h.tail; )
        _.push(g.value), g = g.next;
      return _;
    }
    if (!n.document)
      return n.addEventListener && (r.disableWorkerMessageHandler || n.addEventListener("message", function(h) {
        var _ = JSON.parse(h.data), g = _.language, y = _.code, $ = _.immediateClose;
        n.postMessage(r.highlight(y, r.languages[g], g)), $ && n.close();
      }, !1)), r;
    var D = r.util.currentScript();
    D && (r.filename = D.src, D.hasAttribute("data-manual") && (r.manual = !0));
    function w() {
      r.manual || r.highlightAll();
    }
    if (!r.manual) {
      var F = document.readyState;
      F === "loading" || F === "interactive" && D && D.defer ? document.addEventListener("DOMContentLoaded", w) : window.requestAnimationFrame ? window.requestAnimationFrame(w) : window.setTimeout(w, 16);
    }
    return r;
  }(e);
  i.exports && (i.exports = t), typeof Gi < "u" && (Gi.Prism = t), t.languages.markup = {
    comment: {
      pattern: /<!--(?:(?!<!--)[\s\S])*?-->/,
      greedy: !0
    },
    prolog: {
      pattern: /<\?[\s\S]+?\?>/,
      greedy: !0
    },
    doctype: {
      // https://www.w3.org/TR/xml/#NT-doctypedecl
      pattern: /<!DOCTYPE(?:[^>"'[\]]|"[^"]*"|'[^']*')+(?:\[(?:[^<"'\]]|"[^"]*"|'[^']*'|<(?!!--)|<!--(?:[^-]|-(?!->))*-->)*\]\s*)?>/i,
      greedy: !0,
      inside: {
        "internal-subset": {
          pattern: /(^[^\[]*\[)[\s\S]+(?=\]>$)/,
          lookbehind: !0,
          greedy: !0,
          inside: null
          // see below
        },
        string: {
          pattern: /"[^"]*"|'[^']*'/,
          greedy: !0
        },
        punctuation: /^<!|>$|[[\]]/,
        "doctype-tag": /^DOCTYPE/i,
        name: /[^\s<>'"]+/
      }
    },
    cdata: {
      pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
      greedy: !0
    },
    tag: {
      pattern: /<\/?(?!\d)[^\s>\/=$<%]+(?:\s(?:\s*[^\s>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))|(?=[\s/>])))+)?\s*\/?>/,
      greedy: !0,
      inside: {
        tag: {
          pattern: /^<\/?[^\s>\/]+/,
          inside: {
            punctuation: /^<\/?/,
            namespace: /^[^\s>\/:]+:/
          }
        },
        "special-attr": [],
        "attr-value": {
          pattern: /=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+)/,
          inside: {
            punctuation: [
              {
                pattern: /^=/,
                alias: "attr-equals"
              },
              {
                pattern: /^(\s*)["']|["']$/,
                lookbehind: !0
              }
            ]
          }
        },
        punctuation: /\/?>/,
        "attr-name": {
          pattern: /[^\s>\/]+/,
          inside: {
            namespace: /^[^\s>\/:]+:/
          }
        }
      }
    },
    entity: [
      {
        pattern: /&[\da-z]{1,8};/i,
        alias: "named-entity"
      },
      /&#x?[\da-f]{1,8};/i
    ]
  }, t.languages.markup.tag.inside["attr-value"].inside.entity = t.languages.markup.entity, t.languages.markup.doctype.inside["internal-subset"].inside = t.languages.markup, t.hooks.add("wrap", function(n) {
    n.type === "entity" && (n.attributes.title = n.content.replace(/&amp;/, "&"));
  }), Object.defineProperty(t.languages.markup.tag, "addInlined", {
    /**
     * Adds an inlined language to markup.
     *
     * An example of an inlined language is CSS with `<style>` tags.
     *
     * @param {string} tagName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addInlined('style', 'css');
     */
    value: function(a, o) {
      var l = {};
      l["language-" + o] = {
        pattern: /(^<!\[CDATA\[)[\s\S]+?(?=\]\]>$)/i,
        lookbehind: !0,
        inside: t.languages[o]
      }, l.cdata = /^<!\[CDATA\[|\]\]>$/i;
      var r = {
        "included-cdata": {
          pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
          inside: l
        }
      };
      r["language-" + o] = {
        pattern: /[\s\S]+/,
        inside: t.languages[o]
      };
      var s = {};
      s[a] = {
        pattern: RegExp(/(<__[^>]*>)(?:<!\[CDATA\[(?:[^\]]|\](?!\]>))*\]\]>|(?!<!\[CDATA\[)[\s\S])*?(?=<\/__>)/.source.replace(/__/g, function() {
          return a;
        }), "i"),
        lookbehind: !0,
        greedy: !0,
        inside: r
      }, t.languages.insertBefore("markup", "cdata", s);
    }
  }), Object.defineProperty(t.languages.markup.tag, "addAttribute", {
    /**
     * Adds an pattern to highlight languages embedded in HTML attributes.
     *
     * An example of an inlined language is CSS with `style` attributes.
     *
     * @param {string} attrName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addAttribute('style', 'css');
     */
    value: function(n, a) {
      t.languages.markup.tag.inside["special-attr"].push({
        pattern: RegExp(
          /(^|["'\s])/.source + "(?:" + n + ")" + /\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))/.source,
          "i"
        ),
        lookbehind: !0,
        inside: {
          "attr-name": /^[^\s=]+/,
          "attr-value": {
            pattern: /=[\s\S]+/,
            inside: {
              value: {
                pattern: /(^=\s*(["']|(?!["'])))\S[\s\S]*(?=\2$)/,
                lookbehind: !0,
                alias: [a, "language-" + a],
                inside: t.languages[a]
              },
              punctuation: [
                {
                  pattern: /^=/,
                  alias: "attr-equals"
                },
                /"|'/
              ]
            }
          }
        }
      });
    }
  }), t.languages.html = t.languages.markup, t.languages.mathml = t.languages.markup, t.languages.svg = t.languages.markup, t.languages.xml = t.languages.extend("markup", {}), t.languages.ssml = t.languages.xml, t.languages.atom = t.languages.xml, t.languages.rss = t.languages.xml, function(n) {
    var a = /(?:"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n])*')/;
    n.languages.css = {
      comment: /\/\*[\s\S]*?\*\//,
      atrule: {
        pattern: RegExp("@[\\w-](?:" + /[^;{\s"']|\s+(?!\s)/.source + "|" + a.source + ")*?" + /(?:;|(?=\s*\{))/.source),
        inside: {
          rule: /^@[\w-]+/,
          "selector-function-argument": {
            pattern: /(\bselector\s*\(\s*(?![\s)]))(?:[^()\s]|\s+(?![\s)])|\((?:[^()]|\([^()]*\))*\))+(?=\s*\))/,
            lookbehind: !0,
            alias: "selector"
          },
          keyword: {
            pattern: /(^|[^\w-])(?:and|not|only|or)(?![\w-])/,
            lookbehind: !0
          }
          // See rest below
        }
      },
      url: {
        // https://drafts.csswg.org/css-values-3/#urls
        pattern: RegExp("\\burl\\((?:" + a.source + "|" + /(?:[^\\\r\n()"']|\\[\s\S])*/.source + ")\\)", "i"),
        greedy: !0,
        inside: {
          function: /^url/i,
          punctuation: /^\(|\)$/,
          string: {
            pattern: RegExp("^" + a.source + "$"),
            alias: "url"
          }
        }
      },
      selector: {
        pattern: RegExp(`(^|[{}\\s])[^{}\\s](?:[^{};"'\\s]|\\s+(?![\\s{])|` + a.source + ")*(?=\\s*\\{)"),
        lookbehind: !0
      },
      string: {
        pattern: a,
        greedy: !0
      },
      property: {
        pattern: /(^|[^-\w\xA0-\uFFFF])(?!\s)[-_a-z\xA0-\uFFFF](?:(?!\s)[-\w\xA0-\uFFFF])*(?=\s*:)/i,
        lookbehind: !0
      },
      important: /!important\b/i,
      function: {
        pattern: /(^|[^-a-z0-9])[-a-z0-9]+(?=\()/i,
        lookbehind: !0
      },
      punctuation: /[(){};:,]/
    }, n.languages.css.atrule.inside.rest = n.languages.css;
    var o = n.languages.markup;
    o && (o.tag.addInlined("style", "css"), o.tag.addAttribute("style", "css"));
  }(t), t.languages.clike = {
    comment: [
      {
        pattern: /(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,
        lookbehind: !0,
        greedy: !0
      },
      {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0,
        greedy: !0
      }
    ],
    string: {
      pattern: /(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,
      greedy: !0
    },
    "class-name": {
      pattern: /(\b(?:class|extends|implements|instanceof|interface|new|trait)\s+|\bcatch\s+\()[\w.\\]+/i,
      lookbehind: !0,
      inside: {
        punctuation: /[.\\]/
      }
    },
    keyword: /\b(?:break|catch|continue|do|else|finally|for|function|if|in|instanceof|new|null|return|throw|try|while)\b/,
    boolean: /\b(?:false|true)\b/,
    function: /\b\w+(?=\()/,
    number: /\b0x[\da-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,
    operator: /[<>]=?|[!=]=?=?|--?|\+\+?|&&?|\|\|?|[?*/~^%]/,
    punctuation: /[{}[\];(),.:]/
  }, t.languages.javascript = t.languages.extend("clike", {
    "class-name": [
      t.languages.clike["class-name"],
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$A-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\.(?:constructor|prototype))/,
        lookbehind: !0
      }
    ],
    keyword: [
      {
        pattern: /((?:^|\})\s*)catch\b/,
        lookbehind: !0
      },
      {
        pattern: /(^|[^.]|\.\.\.\s*)\b(?:as|assert(?=\s*\{)|async(?=\s*(?:function\b|\(|[$\w\xA0-\uFFFF]|$))|await|break|case|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally(?=\s*(?:\{|$))|for|from(?=\s*(?:['"]|$))|function|(?:get|set)(?=\s*(?:[#\[$\w\xA0-\uFFFF]|$))|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)\b/,
        lookbehind: !0
      }
    ],
    // Allow for all non-ASCII characters (See http://stackoverflow.com/a/2008444)
    function: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*(?:\.\s*(?:apply|bind|call)\s*)?\()/,
    number: {
      pattern: RegExp(
        /(^|[^\w$])/.source + "(?:" + // constant
        (/NaN|Infinity/.source + "|" + // binary integer
        /0[bB][01]+(?:_[01]+)*n?/.source + "|" + // octal integer
        /0[oO][0-7]+(?:_[0-7]+)*n?/.source + "|" + // hexadecimal integer
        /0[xX][\dA-Fa-f]+(?:_[\dA-Fa-f]+)*n?/.source + "|" + // decimal bigint
        /\d+(?:_\d+)*n/.source + "|" + // decimal number (integer or float) but no bigint
        /(?:\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\.\d+(?:_\d+)*)(?:[Ee][+-]?\d+(?:_\d+)*)?/.source) + ")" + /(?![\w$])/.source
      ),
      lookbehind: !0
    },
    operator: /--|\+\+|\*\*=?|=>|&&=?|\|\|=?|[!=]==|<<=?|>>>?=?|[-+*/%&|^!=<>]=?|\.{3}|\?\?=?|\?\.?|[~:]/
  }), t.languages.javascript["class-name"][0].pattern = /(\b(?:class|extends|implements|instanceof|interface|new)\s+)[\w.\\]+/, t.languages.insertBefore("javascript", "keyword", {
    regex: {
      pattern: RegExp(
        // lookbehind
        // eslint-disable-next-line regexp/no-dupe-characters-character-class
        /((?:^|[^$\w\xA0-\uFFFF."'\])\s]|\b(?:return|yield))\s*)/.source + // Regex pattern:
        // There are 2 regex patterns here. The RegExp set notation proposal added support for nested character
        // classes if the `v` flag is present. Unfortunately, nested CCs are both context-free and incompatible
        // with the only syntax, so we have to define 2 different regex patterns.
        /\//.source + "(?:" + /(?:\[(?:[^\]\\\r\n]|\\.)*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}/.source + "|" + // `v` flag syntax. This supports 3 levels of nested character classes.
        /(?:\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.)*\])*\])*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}v[dgimyus]{0,7}/.source + ")" + // lookahead
        /(?=(?:\s|\/\*(?:[^*]|\*(?!\/))*\*\/)*(?:$|[\r\n,.;:})\]]|\/\/))/.source
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        "regex-source": {
          pattern: /^(\/)[\s\S]+(?=\/[a-z]*$)/,
          lookbehind: !0,
          alias: "language-regex",
          inside: t.languages.regex
        },
        "regex-delimiter": /^\/|\/$/,
        "regex-flags": /^[a-z]+$/
      }
    },
    // This must be declared before keyword because we use "function" inside the look-forward
    "function-variable": {
      pattern: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*[=:]\s*(?:async\s*)?(?:\bfunction\b|(?:\((?:[^()]|\([^()]*\))*\)|(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)\s*=>))/,
      alias: "function"
    },
    parameter: [
      {
        pattern: /(function(?:\s+(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)?\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\))/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$a-z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*=>)/i,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*=>)/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /((?:\b|\s|^)(?!(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)(?![$\w\xA0-\uFFFF]))(?:(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*\s*)\(\s*|\]\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*\{)/,
        lookbehind: !0,
        inside: t.languages.javascript
      }
    ],
    constant: /\b[A-Z](?:[A-Z_]|\dx?)*\b/
  }), t.languages.insertBefore("javascript", "string", {
    hashbang: {
      pattern: /^#!.*/,
      greedy: !0,
      alias: "comment"
    },
    "template-string": {
      pattern: /`(?:\\[\s\S]|\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}|(?!\$\{)[^\\`])*`/,
      greedy: !0,
      inside: {
        "template-punctuation": {
          pattern: /^`|`$/,
          alias: "string"
        },
        interpolation: {
          pattern: /((?:^|[^\\])(?:\\{2})*)\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}/,
          lookbehind: !0,
          inside: {
            "interpolation-punctuation": {
              pattern: /^\$\{|\}$/,
              alias: "punctuation"
            },
            rest: t.languages.javascript
          }
        },
        string: /[\s\S]+/
      }
    },
    "string-property": {
      pattern: /((?:^|[,{])[ \t]*)(["'])(?:\\(?:\r\n|[\s\S])|(?!\2)[^\\\r\n])*\2(?=\s*:)/m,
      lookbehind: !0,
      greedy: !0,
      alias: "property"
    }
  }), t.languages.insertBefore("javascript", "operator", {
    "literal-property": {
      pattern: /((?:^|[,{])[ \t]*)(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*:)/m,
      lookbehind: !0,
      alias: "property"
    }
  }), t.languages.markup && (t.languages.markup.tag.addInlined("script", "javascript"), t.languages.markup.tag.addAttribute(
    /on(?:abort|blur|change|click|composition(?:end|start|update)|dblclick|error|focus(?:in|out)?|key(?:down|up)|load|mouse(?:down|enter|leave|move|out|over|up)|reset|resize|scroll|select|slotchange|submit|unload|wheel)/.source,
    "javascript"
  )), t.languages.js = t.languages.javascript, function() {
    if (typeof t > "u" || typeof document > "u")
      return;
    Element.prototype.matches || (Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector);
    var n = "Loading…", a = function(D, w) {
      return "✖ Error " + D + " while fetching file: " + w;
    }, o = "✖ Error: File does not exist or is empty", l = {
      js: "javascript",
      py: "python",
      rb: "ruby",
      ps1: "powershell",
      psm1: "powershell",
      sh: "bash",
      bat: "batch",
      h: "c",
      tex: "latex"
    }, r = "data-src-status", s = "loading", u = "loaded", c = "failed", m = "pre[data-src]:not([" + r + '="' + u + '"]):not([' + r + '="' + s + '"])';
    function d(D, w, F) {
      var h = new XMLHttpRequest();
      h.open("GET", D, !0), h.onreadystatechange = function() {
        h.readyState == 4 && (h.status < 400 && h.responseText ? w(h.responseText) : h.status >= 400 ? F(a(h.status, h.statusText)) : F(o));
      }, h.send(null);
    }
    function f(D) {
      var w = /^\s*(\d+)\s*(?:(,)\s*(?:(\d+)\s*)?)?$/.exec(D || "");
      if (w) {
        var F = Number(w[1]), h = w[2], _ = w[3];
        return h ? _ ? [F, Number(_)] : [F, void 0] : [F, F];
      }
    }
    t.hooks.add("before-highlightall", function(D) {
      D.selector += ", " + m;
    }), t.hooks.add("before-sanity-check", function(D) {
      var w = (
        /** @type {HTMLPreElement} */
        D.element
      );
      if (w.matches(m)) {
        D.code = "", w.setAttribute(r, s);
        var F = w.appendChild(document.createElement("CODE"));
        F.textContent = n;
        var h = w.getAttribute("data-src"), _ = D.language;
        if (_ === "none") {
          var g = (/\.(\w+)$/.exec(h) || [, "none"])[1];
          _ = l[g] || g;
        }
        t.util.setLanguage(F, _), t.util.setLanguage(w, _);
        var y = t.plugins.autoloader;
        y && y.loadLanguages(_), d(
          h,
          function($) {
            w.setAttribute(r, u);
            var C = f(w.getAttribute("data-range"));
            if (C) {
              var I = $.split(/\r\n?|\n/g), T = C[0], M = C[1] == null ? I.length : C[1];
              T < 0 && (T += I.length), T = Math.max(0, Math.min(T - 1, I.length)), M < 0 && (M += I.length), M = Math.max(0, Math.min(M, I.length)), $ = I.slice(T, M).join(`
`), w.hasAttribute("data-start") || w.setAttribute("data-start", String(T + 1));
            }
            F.textContent = $, t.highlightElement(F);
          },
          function($) {
            w.setAttribute(r, c), F.textContent = $;
          }
        );
      }
    }), t.plugins.fileHighlight = {
      /**
       * Executes the File Highlight plugin for all matching `pre` elements under the given container.
       *
       * Note: Elements which are already loaded or currently loading will not be touched by this method.
       *
       * @param {ParentNode} [container=document]
       */
      highlight: function(w) {
        for (var F = (w || document).querySelectorAll(m), h = 0, _; _ = F[h++]; )
          t.highlightElement(_);
      }
    };
    var v = !1;
    t.fileHighlight = function() {
      v || (console.warn("Prism.fileHighlight is deprecated. Use `Prism.plugins.fileHighlight.highlight` instead."), v = !0), t.plugins.fileHighlight.highlight.apply(this, arguments);
    };
  }();
})(ar);
Prism.languages.python = {
  comment: {
    pattern: /(^|[^\\])#.*/,
    lookbehind: !0,
    greedy: !0
  },
  "string-interpolation": {
    pattern: /(?:f|fr|rf)(?:("""|''')[\s\S]*?\1|("|')(?:\\.|(?!\2)[^\\\r\n])*\2)/i,
    greedy: !0,
    inside: {
      interpolation: {
        // "{" <expression> <optional "!s", "!r", or "!a"> <optional ":" format specifier> "}"
        pattern: /((?:^|[^{])(?:\{\{)*)\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}])+\})+\})+\}/,
        lookbehind: !0,
        inside: {
          "format-spec": {
            pattern: /(:)[^:(){}]+(?=\}$)/,
            lookbehind: !0
          },
          "conversion-option": {
            pattern: /![sra](?=[:}]$)/,
            alias: "punctuation"
          },
          rest: null
        }
      },
      string: /[\s\S]+/
    }
  },
  "triple-quoted-string": {
    pattern: /(?:[rub]|br|rb)?("""|''')[\s\S]*?\1/i,
    greedy: !0,
    alias: "string"
  },
  string: {
    pattern: /(?:[rub]|br|rb)?("|')(?:\\.|(?!\1)[^\\\r\n])*\1/i,
    greedy: !0
  },
  function: {
    pattern: /((?:^|\s)def[ \t]+)[a-zA-Z_]\w*(?=\s*\()/g,
    lookbehind: !0
  },
  "class-name": {
    pattern: /(\bclass\s+)\w+/i,
    lookbehind: !0
  },
  decorator: {
    pattern: /(^[\t ]*)@\w+(?:\.\w+)*/m,
    lookbehind: !0,
    alias: ["annotation", "punctuation"],
    inside: {
      punctuation: /\./
    }
  },
  keyword: /\b(?:_(?=\s*:)|and|as|assert|async|await|break|case|class|continue|def|del|elif|else|except|exec|finally|for|from|global|if|import|in|is|lambda|match|nonlocal|not|or|pass|print|raise|return|try|while|with|yield)\b/,
  builtin: /\b(?:__import__|abs|all|any|apply|ascii|basestring|bin|bool|buffer|bytearray|bytes|callable|chr|classmethod|cmp|coerce|compile|complex|delattr|dict|dir|divmod|enumerate|eval|execfile|file|filter|float|format|frozenset|getattr|globals|hasattr|hash|help|hex|id|input|int|intern|isinstance|issubclass|iter|len|list|locals|long|map|max|memoryview|min|next|object|oct|open|ord|pow|property|range|raw_input|reduce|reload|repr|reversed|round|set|setattr|slice|sorted|staticmethod|str|sum|super|tuple|type|unichr|unicode|vars|xrange|zip)\b/,
  boolean: /\b(?:False|None|True)\b/,
  number: /\b0(?:b(?:_?[01])+|o(?:_?[0-7])+|x(?:_?[a-f0-9])+)\b|(?:\b\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\B\.\d+(?:_\d+)*)(?:e[+-]?\d+(?:_\d+)*)?j?(?!\w)/i,
  operator: /[-+%=]=?|!=|:=|\*\*?=?|\/\/?=?|<[<=>]?|>[=>]?|[&|^~]/,
  punctuation: /[{}[\];(),.:]/
};
Prism.languages.python["string-interpolation"].inside.interpolation.inside.rest = Prism.languages.python;
Prism.languages.py = Prism.languages.python;
(function(i) {
  var e = /\\(?:[^a-z()[\]]|[a-z*]+)/i, t = {
    "equation-command": {
      pattern: e,
      alias: "regex"
    }
  };
  i.languages.latex = {
    comment: /%.*/,
    // the verbatim environment prints whitespace to the document
    cdata: {
      pattern: /(\\begin\{((?:lstlisting|verbatim)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
      lookbehind: !0
    },
    /*
     * equations can be between $$ $$ or $ $ or \( \) or \[ \]
     * (all are multiline)
     */
    equation: [
      {
        pattern: /\$\$(?:\\[\s\S]|[^\\$])+\$\$|\$(?:\\[\s\S]|[^\\$])+\$|\\\([\s\S]*?\\\)|\\\[[\s\S]*?\\\]/,
        inside: t,
        alias: "string"
      },
      {
        pattern: /(\\begin\{((?:align|eqnarray|equation|gather|math|multline)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
        lookbehind: !0,
        inside: t,
        alias: "string"
      }
    ],
    /*
     * arguments which are keywords or references are highlighted
     * as keywords
     */
    keyword: {
      pattern: /(\\(?:begin|cite|documentclass|end|label|ref|usepackage)(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    url: {
      pattern: /(\\url\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    /*
     * section or chapter headlines are highlighted as bold so that
     * they stand out more
     */
    headline: {
      pattern: /(\\(?:chapter|frametitle|paragraph|part|section|subparagraph|subsection|subsubparagraph|subsubsection|subsubsubparagraph)\*?(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0,
      alias: "class-name"
    },
    function: {
      pattern: e,
      alias: "selector"
    },
    punctuation: /[[\]{}&]/
  }, i.languages.tex = i.languages.latex, i.languages.context = i.languages.latex;
})(Prism);
(function(i) {
  var e = "\\b(?:BASH|BASHOPTS|BASH_ALIASES|BASH_ARGC|BASH_ARGV|BASH_CMDS|BASH_COMPLETION_COMPAT_DIR|BASH_LINENO|BASH_REMATCH|BASH_SOURCE|BASH_VERSINFO|BASH_VERSION|COLORTERM|COLUMNS|COMP_WORDBREAKS|DBUS_SESSION_BUS_ADDRESS|DEFAULTS_PATH|DESKTOP_SESSION|DIRSTACK|DISPLAY|EUID|GDMSESSION|GDM_LANG|GNOME_KEYRING_CONTROL|GNOME_KEYRING_PID|GPG_AGENT_INFO|GROUPS|HISTCONTROL|HISTFILE|HISTFILESIZE|HISTSIZE|HOME|HOSTNAME|HOSTTYPE|IFS|INSTANCE|JOB|LANG|LANGUAGE|LC_ADDRESS|LC_ALL|LC_IDENTIFICATION|LC_MEASUREMENT|LC_MONETARY|LC_NAME|LC_NUMERIC|LC_PAPER|LC_TELEPHONE|LC_TIME|LESSCLOSE|LESSOPEN|LINES|LOGNAME|LS_COLORS|MACHTYPE|MAILCHECK|MANDATORY_PATH|NO_AT_BRIDGE|OLDPWD|OPTERR|OPTIND|ORBIT_SOCKETDIR|OSTYPE|PAPERSIZE|PATH|PIPESTATUS|PPID|PS1|PS2|PS3|PS4|PWD|RANDOM|REPLY|SECONDS|SELINUX_INIT|SESSION|SESSIONTYPE|SESSION_MANAGER|SHELL|SHELLOPTS|SHLVL|SSH_AUTH_SOCK|TERM|UID|UPSTART_EVENTS|UPSTART_INSTANCE|UPSTART_JOB|UPSTART_SESSION|USER|WINDOWID|XAUTHORITY|XDG_CONFIG_DIRS|XDG_CURRENT_DESKTOP|XDG_DATA_DIRS|XDG_GREETER_DATA_DIR|XDG_MENU_PREFIX|XDG_RUNTIME_DIR|XDG_SEAT|XDG_SEAT_PATH|XDG_SESSION_DESKTOP|XDG_SESSION_ID|XDG_SESSION_PATH|XDG_SESSION_TYPE|XDG_VTNR|XMODIFIERS)\\b", t = {
    pattern: /(^(["']?)\w+\2)[ \t]+\S.*/,
    lookbehind: !0,
    alias: "punctuation",
    // this looks reasonably well in all themes
    inside: null
    // see below
  }, n = {
    bash: t,
    environment: {
      pattern: RegExp("\\$" + e),
      alias: "constant"
    },
    variable: [
      // [0]: Arithmetic Environment
      {
        pattern: /\$?\(\([\s\S]+?\)\)/,
        greedy: !0,
        inside: {
          // If there is a $ sign at the beginning highlight $(( and )) as variable
          variable: [
            {
              pattern: /(^\$\(\([\s\S]+)\)\)/,
              lookbehind: !0
            },
            /^\$\(\(/
          ],
          number: /\b0x[\dA-Fa-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:[Ee]-?\d+)?/,
          // Operators according to https://www.gnu.org/software/bash/manual/bashref.html#Shell-Arithmetic
          operator: /--|\+\+|\*\*=?|<<=?|>>=?|&&|\|\||[=!+\-*/%<>^&|]=?|[?~:]/,
          // If there is no $ sign at the beginning highlight (( and )) as punctuation
          punctuation: /\(\(?|\)\)?|,|;/
        }
      },
      // [1]: Command Substitution
      {
        pattern: /\$\((?:\([^)]+\)|[^()])+\)|`[^`]+`/,
        greedy: !0,
        inside: {
          variable: /^\$\(|^`|\)$|`$/
        }
      },
      // [2]: Brace expansion
      {
        pattern: /\$\{[^}]+\}/,
        greedy: !0,
        inside: {
          operator: /:[-=?+]?|[!\/]|##?|%%?|\^\^?|,,?/,
          punctuation: /[\[\]]/,
          environment: {
            pattern: RegExp("(\\{)" + e),
            lookbehind: !0,
            alias: "constant"
          }
        }
      },
      /\$(?:\w+|[#?*!@$])/
    ],
    // Escape sequences from echo and printf's manuals, and escaped quotes.
    entity: /\\(?:[abceEfnrtv\\"]|O?[0-7]{1,3}|U[0-9a-fA-F]{8}|u[0-9a-fA-F]{4}|x[0-9a-fA-F]{1,2})/
  };
  i.languages.bash = {
    shebang: {
      pattern: /^#!\s*\/.*/,
      alias: "important"
    },
    comment: {
      pattern: /(^|[^"{\\$])#.*/,
      lookbehind: !0
    },
    "function-name": [
      // a) function foo {
      // b) foo() {
      // c) function foo() {
      // but not “foo {”
      {
        // a) and c)
        pattern: /(\bfunction\s+)[\w-]+(?=(?:\s*\(?:\s*\))?\s*\{)/,
        lookbehind: !0,
        alias: "function"
      },
      {
        // b)
        pattern: /\b[\w-]+(?=\s*\(\s*\)\s*\{)/,
        alias: "function"
      }
    ],
    // Highlight variable names as variables in for and select beginnings.
    "for-or-select": {
      pattern: /(\b(?:for|select)\s+)\w+(?=\s+in\s)/,
      alias: "variable",
      lookbehind: !0
    },
    // Highlight variable names as variables in the left-hand part
    // of assignments (“=” and “+=”).
    "assign-left": {
      pattern: /(^|[\s;|&]|[<>]\()\w+(?:\.\w+)*(?=\+?=)/,
      inside: {
        environment: {
          pattern: RegExp("(^|[\\s;|&]|[<>]\\()" + e),
          lookbehind: !0,
          alias: "constant"
        }
      },
      alias: "variable",
      lookbehind: !0
    },
    // Highlight parameter names as variables
    parameter: {
      pattern: /(^|\s)-{1,2}(?:\w+:[+-]?)?\w+(?:\.\w+)*(?=[=\s]|$)/,
      alias: "variable",
      lookbehind: !0
    },
    string: [
      // Support for Here-documents https://en.wikipedia.org/wiki/Here_document
      {
        pattern: /((?:^|[^<])<<-?\s*)(\w+)\s[\s\S]*?(?:\r?\n|\r)\2/,
        lookbehind: !0,
        greedy: !0,
        inside: n
      },
      // Here-document with quotes around the tag
      // → No expansion (so no “inside”).
      {
        pattern: /((?:^|[^<])<<-?\s*)(["'])(\w+)\2\s[\s\S]*?(?:\r?\n|\r)\3/,
        lookbehind: !0,
        greedy: !0,
        inside: {
          bash: t
        }
      },
      // “Normal” string
      {
        // https://www.gnu.org/software/bash/manual/html_node/Double-Quotes.html
        pattern: /(^|[^\\](?:\\\\)*)"(?:\\[\s\S]|\$\([^)]+\)|\$(?!\()|`[^`]+`|[^"\\`$])*"/,
        lookbehind: !0,
        greedy: !0,
        inside: n
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/Single-Quotes.html
        pattern: /(^|[^$\\])'[^']*'/,
        lookbehind: !0,
        greedy: !0
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/ANSI_002dC-Quoting.html
        pattern: /\$'(?:[^'\\]|\\[\s\S])*'/,
        greedy: !0,
        inside: {
          entity: n.entity
        }
      }
    ],
    environment: {
      pattern: RegExp("\\$?" + e),
      alias: "constant"
    },
    variable: n.variable,
    function: {
      pattern: /(^|[\s;|&]|[<>]\()(?:add|apropos|apt|apt-cache|apt-get|aptitude|aspell|automysqlbackup|awk|basename|bash|bc|bconsole|bg|bzip2|cal|cargo|cat|cfdisk|chgrp|chkconfig|chmod|chown|chroot|cksum|clear|cmp|column|comm|composer|cp|cron|crontab|csplit|curl|cut|date|dc|dd|ddrescue|debootstrap|df|diff|diff3|dig|dir|dircolors|dirname|dirs|dmesg|docker|docker-compose|du|egrep|eject|env|ethtool|expand|expect|expr|fdformat|fdisk|fg|fgrep|file|find|fmt|fold|format|free|fsck|ftp|fuser|gawk|git|gparted|grep|groupadd|groupdel|groupmod|groups|grub-mkconfig|gzip|halt|head|hg|history|host|hostname|htop|iconv|id|ifconfig|ifdown|ifup|import|install|ip|java|jobs|join|kill|killall|less|link|ln|locate|logname|logrotate|look|lpc|lpr|lprint|lprintd|lprintq|lprm|ls|lsof|lynx|make|man|mc|mdadm|mkconfig|mkdir|mke2fs|mkfifo|mkfs|mkisofs|mknod|mkswap|mmv|more|most|mount|mtools|mtr|mutt|mv|nano|nc|netstat|nice|nl|node|nohup|notify-send|npm|nslookup|op|open|parted|passwd|paste|pathchk|ping|pkill|pnpm|podman|podman-compose|popd|pr|printcap|printenv|ps|pushd|pv|quota|quotacheck|quotactl|ram|rar|rcp|reboot|remsync|rename|renice|rev|rm|rmdir|rpm|rsync|scp|screen|sdiff|sed|sendmail|seq|service|sftp|sh|shellcheck|shuf|shutdown|sleep|slocate|sort|split|ssh|stat|strace|su|sudo|sum|suspend|swapon|sync|sysctl|tac|tail|tar|tee|time|timeout|top|touch|tr|traceroute|tsort|tty|umount|uname|unexpand|uniq|units|unrar|unshar|unzip|update-grub|uptime|useradd|userdel|usermod|users|uudecode|uuencode|v|vcpkg|vdir|vi|vim|virsh|vmstat|wait|watch|wc|wget|whereis|which|who|whoami|write|xargs|xdg-open|yarn|yes|zenity|zip|zsh|zypper)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    keyword: {
      pattern: /(^|[\s;|&]|[<>]\()(?:case|do|done|elif|else|esac|fi|for|function|if|in|select|then|until|while)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    // https://www.gnu.org/software/bash/manual/html_node/Shell-Builtin-Commands.html
    builtin: {
      pattern: /(^|[\s;|&]|[<>]\()(?:\.|:|alias|bind|break|builtin|caller|cd|command|continue|declare|echo|enable|eval|exec|exit|export|getopts|hash|help|let|local|logout|mapfile|printf|pwd|read|readarray|readonly|return|set|shift|shopt|source|test|times|trap|type|typeset|ulimit|umask|unalias|unset)(?=$|[)\s;|&])/,
      lookbehind: !0,
      // Alias added to make those easier to distinguish from strings.
      alias: "class-name"
    },
    boolean: {
      pattern: /(^|[\s;|&]|[<>]\()(?:false|true)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    "file-descriptor": {
      pattern: /\B&\d\b/,
      alias: "important"
    },
    operator: {
      // Lots of redirections here, but not just that.
      pattern: /\d?<>|>\||\+=|=[=~]?|!=?|<<[<-]?|[&\d]?>>|\d[<>]&?|[<>][&=]?|&[>&]?|\|[&|]?/,
      inside: {
        "file-descriptor": {
          pattern: /^\d/,
          alias: "important"
        }
      }
    },
    punctuation: /\$?\(\(?|\)\)?|\.\.|[{}[\];\\]/,
    number: {
      pattern: /(^|\s)(?:[1-9]\d*|0)(?:[.,]\d+)?\b/,
      lookbehind: !0
    }
  }, t.inside = i.languages.bash;
  for (var a = [
    "comment",
    "function-name",
    "for-or-select",
    "assign-left",
    "parameter",
    "string",
    "environment",
    "function",
    "keyword",
    "builtin",
    "boolean",
    "file-descriptor",
    "operator",
    "punctuation",
    "number"
  ], o = n.variable[1].inside, l = 0; l < a.length; l++)
    o[a[l]] = i.languages.bash[a[l]];
  i.languages.sh = i.languages.bash, i.languages.shell = i.languages.bash;
})(Prism);
new Dl();
const lr = (i) => {
  const e = {};
  for (let t = 0, n = i.length; t < n; t++) {
    const a = i[t];
    for (const o in a)
      e[o] ? e[o] = e[o].concat(a[o]) : e[o] = a[o];
  }
  return e;
}, or = [
  "abbr",
  "accept",
  "accept-charset",
  "accesskey",
  "action",
  "align",
  "alink",
  "allow",
  "allowfullscreen",
  "alt",
  "anchor",
  "archive",
  "as",
  "async",
  "autocapitalize",
  "autocomplete",
  "autocorrect",
  "autofocus",
  "autopictureinpicture",
  "autoplay",
  "axis",
  "background",
  "behavior",
  "bgcolor",
  "border",
  "bordercolor",
  "capture",
  "cellpadding",
  "cellspacing",
  "challenge",
  "char",
  "charoff",
  "charset",
  "checked",
  "cite",
  "class",
  "classid",
  "clear",
  "code",
  "codebase",
  "codetype",
  "color",
  "cols",
  "colspan",
  "compact",
  "content",
  "contenteditable",
  "controls",
  "controlslist",
  "conversiondestination",
  "coords",
  "crossorigin",
  "csp",
  "data",
  "datetime",
  "declare",
  "decoding",
  "default",
  "defer",
  "dir",
  "direction",
  "dirname",
  "disabled",
  "disablepictureinpicture",
  "disableremoteplayback",
  "disallowdocumentaccess",
  "download",
  "draggable",
  "elementtiming",
  "enctype",
  "end",
  "enterkeyhint",
  "event",
  "exportparts",
  "face",
  "for",
  "form",
  "formaction",
  "formenctype",
  "formmethod",
  "formnovalidate",
  "formtarget",
  "frame",
  "frameborder",
  "headers",
  "height",
  "hidden",
  "high",
  "href",
  "hreflang",
  "hreftranslate",
  "hspace",
  "http-equiv",
  "id",
  "imagesizes",
  "imagesrcset",
  "importance",
  "impressiondata",
  "impressionexpiry",
  "incremental",
  "inert",
  "inputmode",
  "integrity",
  "invisible",
  "ismap",
  "keytype",
  "kind",
  "label",
  "lang",
  "language",
  "latencyhint",
  "leftmargin",
  "link",
  "list",
  "loading",
  "longdesc",
  "loop",
  "low",
  "lowsrc",
  "manifest",
  "marginheight",
  "marginwidth",
  "max",
  "maxlength",
  "mayscript",
  "media",
  "method",
  "min",
  "minlength",
  "multiple",
  "muted",
  "name",
  "nohref",
  "nomodule",
  "nonce",
  "noresize",
  "noshade",
  "novalidate",
  "nowrap",
  "object",
  "open",
  "optimum",
  "part",
  "pattern",
  "ping",
  "placeholder",
  "playsinline",
  "policy",
  "poster",
  "preload",
  "pseudo",
  "readonly",
  "referrerpolicy",
  "rel",
  "reportingorigin",
  "required",
  "resources",
  "rev",
  "reversed",
  "role",
  "rows",
  "rowspan",
  "rules",
  "sandbox",
  "scheme",
  "scope",
  "scopes",
  "scrollamount",
  "scrolldelay",
  "scrolling",
  "select",
  "selected",
  "shadowroot",
  "shadowrootdelegatesfocus",
  "shape",
  "size",
  "sizes",
  "slot",
  "span",
  "spellcheck",
  "src",
  "srclang",
  "srcset",
  "standby",
  "start",
  "step",
  "style",
  "summary",
  "tabindex",
  "target",
  "text",
  "title",
  "topmargin",
  "translate",
  "truespeed",
  "trusttoken",
  "type",
  "usemap",
  "valign",
  "value",
  "valuetype",
  "version",
  "virtualkeyboardpolicy",
  "vlink",
  "vspace",
  "webkitdirectory",
  "width",
  "wrap"
], rr = [
  "accent-height",
  "accumulate",
  "additive",
  "alignment-baseline",
  "ascent",
  "attributename",
  "attributetype",
  "azimuth",
  "basefrequency",
  "baseline-shift",
  "begin",
  "bias",
  "by",
  "class",
  "clip",
  "clippathunits",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "cx",
  "cy",
  "d",
  "dx",
  "dy",
  "diffuseconstant",
  "direction",
  "display",
  "divisor",
  "dominant-baseline",
  "dur",
  "edgemode",
  "elevation",
  "end",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "filterunits",
  "flood-color",
  "flood-opacity",
  "font-family",
  "font-size",
  "font-size-adjust",
  "font-stretch",
  "font-style",
  "font-variant",
  "font-weight",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyph-name",
  "glyphref",
  "gradientunits",
  "gradienttransform",
  "height",
  "href",
  "id",
  "image-rendering",
  "in",
  "in2",
  "k",
  "k1",
  "k2",
  "k3",
  "k4",
  "kerning",
  "keypoints",
  "keysplines",
  "keytimes",
  "lang",
  "lengthadjust",
  "letter-spacing",
  "kernelmatrix",
  "kernelunitlength",
  "lighting-color",
  "local",
  "marker-end",
  "marker-mid",
  "marker-start",
  "markerheight",
  "markerunits",
  "markerwidth",
  "maskcontentunits",
  "maskunits",
  "max",
  "mask",
  "media",
  "method",
  "mode",
  "min",
  "name",
  "numoctaves",
  "offset",
  "operator",
  "opacity",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "paint-order",
  "path",
  "pathlength",
  "patterncontentunits",
  "patterntransform",
  "patternunits",
  "points",
  "preservealpha",
  "preserveaspectratio",
  "primitiveunits",
  "r",
  "rx",
  "ry",
  "radius",
  "refx",
  "refy",
  "repeatcount",
  "repeatdur",
  "restart",
  "result",
  "rotate",
  "scale",
  "seed",
  "shape-rendering",
  "specularconstant",
  "specularexponent",
  "spreadmethod",
  "startoffset",
  "stddeviation",
  "stitchtiles",
  "stop-color",
  "stop-opacity",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke",
  "stroke-width",
  "style",
  "surfacescale",
  "systemlanguage",
  "tabindex",
  "targetx",
  "targety",
  "transform",
  "transform-origin",
  "text-anchor",
  "text-decoration",
  "text-rendering",
  "textlength",
  "type",
  "u1",
  "u2",
  "unicode",
  "values",
  "viewbox",
  "visibility",
  "version",
  "vert-adv-y",
  "vert-origin-x",
  "vert-origin-y",
  "width",
  "word-spacing",
  "wrap",
  "writing-mode",
  "xchannelselector",
  "ychannelselector",
  "x",
  "x1",
  "x2",
  "xmlns",
  "y",
  "y1",
  "y2",
  "z",
  "zoomandpan"
], sr = [
  "accent",
  "accentunder",
  "align",
  "bevelled",
  "close",
  "columnsalign",
  "columnlines",
  "columnspan",
  "denomalign",
  "depth",
  "dir",
  "display",
  "displaystyle",
  "encoding",
  "fence",
  "frame",
  "height",
  "href",
  "id",
  "largeop",
  "length",
  "linethickness",
  "lspace",
  "lquote",
  "mathbackground",
  "mathcolor",
  "mathsize",
  "mathvariant",
  "maxsize",
  "minsize",
  "movablelimits",
  "notation",
  "numalign",
  "open",
  "rowalign",
  "rowlines",
  "rowspacing",
  "rowspan",
  "rspace",
  "rquote",
  "scriptlevel",
  "scriptminsize",
  "scriptsizemultiplier",
  "selection",
  "separator",
  "separators",
  "stretchy",
  "subscriptshift",
  "supscriptshift",
  "symmetric",
  "voffset",
  "width",
  "xmlns"
];
lr([
  Object.fromEntries(or.map((i) => [i, ["*"]])),
  Object.fromEntries(rr.map((i) => [i, ["svg:*"]])),
  Object.fromEntries(sr.map((i) => [i, ["math:*"]]))
]);
const {
  HtmlTagHydration: su,
  SvelteComponent: uu,
  attr: cu,
  binding_callbacks: _u,
  children: du,
  claim_element: fu,
  claim_html_tag: pu,
  detach: hu,
  element: mu,
  init: gu,
  insert_hydration: vu,
  noop: bu,
  safe_not_equal: Du,
  toggle_class: yu
} = window.__gradio__svelte__internal, { afterUpdate: wu, tick: Fu, onMount: $u } = window.__gradio__svelte__internal, {
  SvelteComponent: ku,
  attr: Eu,
  children: Au,
  claim_component: Cu,
  claim_element: Su,
  create_component: Tu,
  destroy_component: Bu,
  detach: Iu,
  element: Ru,
  init: Lu,
  insert_hydration: Ou,
  mount_component: qu,
  safe_not_equal: Nu,
  transition_in: Mu,
  transition_out: Pu
} = window.__gradio__svelte__internal, {
  SvelteComponent: zu,
  attr: xu,
  check_outros: Uu,
  children: Hu,
  claim_component: Gu,
  claim_element: ju,
  claim_space: Vu,
  create_component: Wu,
  create_slot: Zu,
  destroy_component: Yu,
  detach: Xu,
  element: Ku,
  empty: Qu,
  get_all_dirty_from_scope: Ju,
  get_slot_changes: ec,
  group_outros: tc,
  init: nc,
  insert_hydration: ic,
  mount_component: ac,
  safe_not_equal: lc,
  space: oc,
  toggle_class: rc,
  transition_in: sc,
  transition_out: uc,
  update_slot_base: cc
} = window.__gradio__svelte__internal, {
  SvelteComponent: _c,
  append_hydration: dc,
  attr: fc,
  children: pc,
  claim_component: hc,
  claim_element: mc,
  claim_space: gc,
  claim_text: vc,
  create_component: bc,
  destroy_component: Dc,
  detach: yc,
  element: wc,
  init: Fc,
  insert_hydration: $c,
  mount_component: kc,
  safe_not_equal: Ec,
  set_data: Ac,
  space: Cc,
  text: Sc,
  toggle_class: Tc,
  transition_in: Bc,
  transition_out: Ic
} = window.__gradio__svelte__internal, {
  SvelteComponent: ur,
  append_hydration: Cn,
  attr: vt,
  bubble: cr,
  check_outros: _r,
  children: ii,
  claim_component: dr,
  claim_element: ai,
  claim_space: ji,
  claim_text: fr,
  construct_svelte_component: Vi,
  create_component: Wi,
  create_slot: pr,
  destroy_component: Zi,
  detach: rn,
  element: li,
  get_all_dirty_from_scope: hr,
  get_slot_changes: mr,
  group_outros: gr,
  init: vr,
  insert_hydration: yl,
  listen: br,
  mount_component: Yi,
  safe_not_equal: Dr,
  set_data: yr,
  set_style: bn,
  space: Xi,
  text: wr,
  toggle_class: we,
  transition_in: Hn,
  transition_out: Gn,
  update_slot_base: Fr
} = window.__gradio__svelte__internal;
function Ki(i) {
  let e, t;
  return {
    c() {
      e = li("span"), t = wr(
        /*label*/
        i[1]
      ), this.h();
    },
    l(n) {
      e = ai(n, "SPAN", { class: !0 });
      var a = ii(e);
      t = fr(
        a,
        /*label*/
        i[1]
      ), a.forEach(rn), this.h();
    },
    h() {
      vt(e, "class", "svelte-qgco6m");
    },
    m(n, a) {
      yl(n, e, a), Cn(e, t);
    },
    p(n, a) {
      a & /*label*/
      2 && yr(
        t,
        /*label*/
        n[1]
      );
    },
    d(n) {
      n && rn(e);
    }
  };
}
function $r(i) {
  let e, t, n, a, o, l, r, s, u = (
    /*show_label*/
    i[2] && Ki(i)
  );
  var c = (
    /*Icon*/
    i[0]
  );
  function m(v, D) {
    return {};
  }
  c && (a = Vi(c, m()));
  const d = (
    /*#slots*/
    i[14].default
  ), f = pr(
    d,
    i,
    /*$$scope*/
    i[13],
    null
  );
  return {
    c() {
      e = li("button"), u && u.c(), t = Xi(), n = li("div"), a && Wi(a.$$.fragment), o = Xi(), f && f.c(), this.h();
    },
    l(v) {
      e = ai(v, "BUTTON", {
        "aria-label": !0,
        "aria-haspopup": !0,
        title: !0,
        class: !0
      });
      var D = ii(e);
      u && u.l(D), t = ji(D), n = ai(D, "DIV", { class: !0 });
      var w = ii(n);
      a && dr(a.$$.fragment, w), o = ji(w), f && f.l(w), w.forEach(rn), D.forEach(rn), this.h();
    },
    h() {
      vt(n, "class", "svelte-qgco6m"), we(
        n,
        "x-small",
        /*size*/
        i[4] === "x-small"
      ), we(
        n,
        "small",
        /*size*/
        i[4] === "small"
      ), we(
        n,
        "large",
        /*size*/
        i[4] === "large"
      ), we(
        n,
        "medium",
        /*size*/
        i[4] === "medium"
      ), e.disabled = /*disabled*/
      i[7], vt(
        e,
        "aria-label",
        /*label*/
        i[1]
      ), vt(
        e,
        "aria-haspopup",
        /*hasPopup*/
        i[8]
      ), vt(
        e,
        "title",
        /*label*/
        i[1]
      ), vt(e, "class", "svelte-qgco6m"), we(
        e,
        "pending",
        /*pending*/
        i[3]
      ), we(
        e,
        "padded",
        /*padded*/
        i[5]
      ), we(
        e,
        "highlight",
        /*highlight*/
        i[6]
      ), we(
        e,
        "transparent",
        /*transparent*/
        i[9]
      ), bn(e, "color", !/*disabled*/
      i[7] && /*_color*/
      i[11] ? (
        /*_color*/
        i[11]
      ) : "var(--block-label-text-color)"), bn(e, "--bg-color", /*disabled*/
      i[7] ? "auto" : (
        /*background*/
        i[10]
      ));
    },
    m(v, D) {
      yl(v, e, D), u && u.m(e, null), Cn(e, t), Cn(e, n), a && Yi(a, n, null), Cn(n, o), f && f.m(n, null), l = !0, r || (s = br(
        e,
        "click",
        /*click_handler*/
        i[15]
      ), r = !0);
    },
    p(v, [D]) {
      if (/*show_label*/
      v[2] ? u ? u.p(v, D) : (u = Ki(v), u.c(), u.m(e, t)) : u && (u.d(1), u = null), D & /*Icon*/
      1 && c !== (c = /*Icon*/
      v[0])) {
        if (a) {
          gr();
          const w = a;
          Gn(w.$$.fragment, 1, 0, () => {
            Zi(w, 1);
          }), _r();
        }
        c ? (a = Vi(c, m()), Wi(a.$$.fragment), Hn(a.$$.fragment, 1), Yi(a, n, o)) : a = null;
      }
      f && f.p && (!l || D & /*$$scope*/
      8192) && Fr(
        f,
        d,
        v,
        /*$$scope*/
        v[13],
        l ? mr(
          d,
          /*$$scope*/
          v[13],
          D,
          null
        ) : hr(
          /*$$scope*/
          v[13]
        ),
        null
      ), (!l || D & /*size*/
      16) && we(
        n,
        "x-small",
        /*size*/
        v[4] === "x-small"
      ), (!l || D & /*size*/
      16) && we(
        n,
        "small",
        /*size*/
        v[4] === "small"
      ), (!l || D & /*size*/
      16) && we(
        n,
        "large",
        /*size*/
        v[4] === "large"
      ), (!l || D & /*size*/
      16) && we(
        n,
        "medium",
        /*size*/
        v[4] === "medium"
      ), (!l || D & /*disabled*/
      128) && (e.disabled = /*disabled*/
      v[7]), (!l || D & /*label*/
      2) && vt(
        e,
        "aria-label",
        /*label*/
        v[1]
      ), (!l || D & /*hasPopup*/
      256) && vt(
        e,
        "aria-haspopup",
        /*hasPopup*/
        v[8]
      ), (!l || D & /*label*/
      2) && vt(
        e,
        "title",
        /*label*/
        v[1]
      ), (!l || D & /*pending*/
      8) && we(
        e,
        "pending",
        /*pending*/
        v[3]
      ), (!l || D & /*padded*/
      32) && we(
        e,
        "padded",
        /*padded*/
        v[5]
      ), (!l || D & /*highlight*/
      64) && we(
        e,
        "highlight",
        /*highlight*/
        v[6]
      ), (!l || D & /*transparent*/
      512) && we(
        e,
        "transparent",
        /*transparent*/
        v[9]
      ), D & /*disabled, _color*/
      2176 && bn(e, "color", !/*disabled*/
      v[7] && /*_color*/
      v[11] ? (
        /*_color*/
        v[11]
      ) : "var(--block-label-text-color)"), D & /*disabled, background*/
      1152 && bn(e, "--bg-color", /*disabled*/
      v[7] ? "auto" : (
        /*background*/
        v[10]
      ));
    },
    i(v) {
      l || (a && Hn(a.$$.fragment, v), Hn(f, v), l = !0);
    },
    o(v) {
      a && Gn(a.$$.fragment, v), Gn(f, v), l = !1;
    },
    d(v) {
      v && rn(e), u && u.d(), a && Zi(a), f && f.d(v), r = !1, s();
    }
  };
}
function kr(i, e, t) {
  let n, { $$slots: a = {}, $$scope: o } = e, { Icon: l } = e, { label: r = "" } = e, { show_label: s = !1 } = e, { pending: u = !1 } = e, { size: c = "small" } = e, { padded: m = !0 } = e, { highlight: d = !1 } = e, { disabled: f = !1 } = e, { hasPopup: v = !1 } = e, { color: D = "var(--block-label-text-color)" } = e, { transparent: w = !1 } = e, { background: F = "var(--block-background-fill)" } = e;
  function h(_) {
    cr.call(this, i, _);
  }
  return i.$$set = (_) => {
    "Icon" in _ && t(0, l = _.Icon), "label" in _ && t(1, r = _.label), "show_label" in _ && t(2, s = _.show_label), "pending" in _ && t(3, u = _.pending), "size" in _ && t(4, c = _.size), "padded" in _ && t(5, m = _.padded), "highlight" in _ && t(6, d = _.highlight), "disabled" in _ && t(7, f = _.disabled), "hasPopup" in _ && t(8, v = _.hasPopup), "color" in _ && t(12, D = _.color), "transparent" in _ && t(9, w = _.transparent), "background" in _ && t(10, F = _.background), "$$scope" in _ && t(13, o = _.$$scope);
  }, i.$$.update = () => {
    i.$$.dirty & /*highlight, color*/
    4160 && t(11, n = d ? "var(--color-accent)" : D);
  }, [
    l,
    r,
    s,
    u,
    c,
    m,
    d,
    f,
    v,
    w,
    F,
    n,
    D,
    o,
    a,
    h
  ];
}
class Er extends ur {
  constructor(e) {
    super(), vr(this, e, kr, $r, Dr, {
      Icon: 0,
      label: 1,
      show_label: 2,
      pending: 3,
      size: 4,
      padded: 5,
      highlight: 6,
      disabled: 7,
      hasPopup: 8,
      color: 12,
      transparent: 9,
      background: 10
    });
  }
}
const {
  SvelteComponent: Rc,
  append_hydration: Lc,
  attr: Oc,
  binding_callbacks: qc,
  children: Nc,
  claim_element: Mc,
  create_slot: Pc,
  detach: zc,
  element: xc,
  get_all_dirty_from_scope: Uc,
  get_slot_changes: Hc,
  init: Gc,
  insert_hydration: jc,
  safe_not_equal: Vc,
  toggle_class: Wc,
  transition_in: Zc,
  transition_out: Yc,
  update_slot_base: Xc
} = window.__gradio__svelte__internal, {
  SvelteComponent: Kc,
  append_hydration: Qc,
  attr: Jc,
  children: e_,
  claim_svg_element: t_,
  detach: n_,
  init: i_,
  insert_hydration: a_,
  noop: l_,
  safe_not_equal: o_,
  svg_element: r_
} = window.__gradio__svelte__internal, {
  SvelteComponent: s_,
  append_hydration: u_,
  attr: c_,
  children: __,
  claim_svg_element: d_,
  detach: f_,
  init: p_,
  insert_hydration: h_,
  noop: m_,
  safe_not_equal: g_,
  svg_element: v_
} = window.__gradio__svelte__internal, {
  SvelteComponent: b_,
  append_hydration: D_,
  attr: y_,
  children: w_,
  claim_svg_element: F_,
  detach: $_,
  init: k_,
  insert_hydration: E_,
  noop: A_,
  safe_not_equal: C_,
  svg_element: S_
} = window.__gradio__svelte__internal, {
  SvelteComponent: T_,
  append_hydration: B_,
  attr: I_,
  children: R_,
  claim_svg_element: L_,
  detach: O_,
  init: q_,
  insert_hydration: N_,
  noop: M_,
  safe_not_equal: P_,
  svg_element: z_
} = window.__gradio__svelte__internal, {
  SvelteComponent: x_,
  append_hydration: U_,
  attr: H_,
  children: G_,
  claim_svg_element: j_,
  detach: V_,
  init: W_,
  insert_hydration: Z_,
  noop: Y_,
  safe_not_equal: X_,
  svg_element: K_
} = window.__gradio__svelte__internal, {
  SvelteComponent: Q_,
  append_hydration: J_,
  attr: ed,
  children: td,
  claim_svg_element: nd,
  detach: id,
  init: ad,
  insert_hydration: ld,
  noop: od,
  safe_not_equal: rd,
  svg_element: sd
} = window.__gradio__svelte__internal, {
  SvelteComponent: ud,
  append_hydration: cd,
  attr: _d,
  children: dd,
  claim_svg_element: fd,
  detach: pd,
  init: hd,
  insert_hydration: md,
  noop: gd,
  safe_not_equal: vd,
  svg_element: bd
} = window.__gradio__svelte__internal, {
  SvelteComponent: Dd,
  append_hydration: yd,
  attr: wd,
  children: Fd,
  claim_svg_element: $d,
  detach: kd,
  init: Ed,
  insert_hydration: Ad,
  noop: Cd,
  safe_not_equal: Sd,
  svg_element: Td
} = window.__gradio__svelte__internal, {
  SvelteComponent: Bd,
  append_hydration: Id,
  attr: Rd,
  children: Ld,
  claim_svg_element: Od,
  detach: qd,
  init: Nd,
  insert_hydration: Md,
  noop: Pd,
  safe_not_equal: zd,
  svg_element: xd
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ud,
  append_hydration: Hd,
  attr: Gd,
  children: jd,
  claim_svg_element: Vd,
  detach: Wd,
  init: Zd,
  insert_hydration: Yd,
  noop: Xd,
  safe_not_equal: Kd,
  svg_element: Qd
} = window.__gradio__svelte__internal, {
  SvelteComponent: Jd,
  append_hydration: ef,
  attr: tf,
  children: nf,
  claim_svg_element: af,
  detach: lf,
  init: of,
  insert_hydration: rf,
  noop: sf,
  safe_not_equal: uf,
  svg_element: cf
} = window.__gradio__svelte__internal, {
  SvelteComponent: _f,
  append_hydration: df,
  attr: ff,
  children: pf,
  claim_svg_element: hf,
  detach: mf,
  init: gf,
  insert_hydration: vf,
  noop: bf,
  safe_not_equal: Df,
  svg_element: yf
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ar,
  append_hydration: jn,
  attr: He,
  children: Dn,
  claim_svg_element: yn,
  detach: Kt,
  init: Cr,
  insert_hydration: Sr,
  noop: Vn,
  safe_not_equal: Tr,
  set_style: it,
  svg_element: wn
} = window.__gradio__svelte__internal;
function Br(i) {
  let e, t, n, a;
  return {
    c() {
      e = wn("svg"), t = wn("g"), n = wn("path"), a = wn("path"), this.h();
    },
    l(o) {
      e = yn(o, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        version: !0,
        xmlns: !0,
        "xmlns:xlink": !0,
        "xml:space": !0,
        stroke: !0,
        style: !0
      });
      var l = Dn(e);
      t = yn(l, "g", { transform: !0 });
      var r = Dn(t);
      n = yn(r, "path", { d: !0, style: !0 }), Dn(n).forEach(Kt), r.forEach(Kt), a = yn(l, "path", { d: !0, style: !0 }), Dn(a).forEach(Kt), l.forEach(Kt), this.h();
    },
    h() {
      He(n, "d", "M18,6L6.087,17.913"), it(n, "fill", "none"), it(n, "fill-rule", "nonzero"), it(n, "stroke-width", "2px"), He(t, "transform", "matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"), He(a, "d", "M4.364,4.364L19.636,19.636"), it(a, "fill", "none"), it(a, "fill-rule", "nonzero"), it(a, "stroke-width", "2px"), He(e, "width", "100%"), He(e, "height", "100%"), He(e, "viewBox", "0 0 24 24"), He(e, "version", "1.1"), He(e, "xmlns", "http://www.w3.org/2000/svg"), He(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), He(e, "xml:space", "preserve"), He(e, "stroke", "currentColor"), it(e, "fill-rule", "evenodd"), it(e, "clip-rule", "evenodd"), it(e, "stroke-linecap", "round"), it(e, "stroke-linejoin", "round");
    },
    m(o, l) {
      Sr(o, e, l), jn(e, t), jn(t, n), jn(e, a);
    },
    p: Vn,
    i: Vn,
    o: Vn,
    d(o) {
      o && Kt(e);
    }
  };
}
class Ir extends Ar {
  constructor(e) {
    super(), Cr(this, e, null, Br, Tr, {});
  }
}
const {
  SvelteComponent: wf,
  append_hydration: Ff,
  attr: $f,
  children: kf,
  claim_svg_element: Ef,
  detach: Af,
  init: Cf,
  insert_hydration: Sf,
  noop: Tf,
  safe_not_equal: Bf,
  svg_element: If
} = window.__gradio__svelte__internal, {
  SvelteComponent: Rf,
  append_hydration: Lf,
  attr: Of,
  children: qf,
  claim_svg_element: Nf,
  detach: Mf,
  init: Pf,
  insert_hydration: zf,
  noop: xf,
  safe_not_equal: Uf,
  svg_element: Hf
} = window.__gradio__svelte__internal, {
  SvelteComponent: Gf,
  append_hydration: jf,
  attr: Vf,
  children: Wf,
  claim_svg_element: Zf,
  detach: Yf,
  init: Xf,
  insert_hydration: Kf,
  noop: Qf,
  safe_not_equal: Jf,
  svg_element: ep
} = window.__gradio__svelte__internal, {
  SvelteComponent: tp,
  append_hydration: np,
  attr: ip,
  children: ap,
  claim_svg_element: lp,
  detach: op,
  init: rp,
  insert_hydration: sp,
  noop: up,
  safe_not_equal: cp,
  svg_element: _p
} = window.__gradio__svelte__internal, {
  SvelteComponent: dp,
  append_hydration: fp,
  attr: pp,
  children: hp,
  claim_svg_element: mp,
  detach: gp,
  init: vp,
  insert_hydration: bp,
  noop: Dp,
  safe_not_equal: yp,
  svg_element: wp
} = window.__gradio__svelte__internal, {
  SvelteComponent: Fp,
  append_hydration: $p,
  attr: kp,
  children: Ep,
  claim_svg_element: Ap,
  detach: Cp,
  init: Sp,
  insert_hydration: Tp,
  noop: Bp,
  safe_not_equal: Ip,
  svg_element: Rp
} = window.__gradio__svelte__internal, {
  SvelteComponent: Lp,
  append_hydration: Op,
  attr: qp,
  children: Np,
  claim_svg_element: Mp,
  detach: Pp,
  init: zp,
  insert_hydration: xp,
  noop: Up,
  safe_not_equal: Hp,
  svg_element: Gp
} = window.__gradio__svelte__internal, {
  SvelteComponent: jp,
  append_hydration: Vp,
  attr: Wp,
  children: Zp,
  claim_svg_element: Yp,
  detach: Xp,
  init: Kp,
  insert_hydration: Qp,
  noop: Jp,
  safe_not_equal: eh,
  svg_element: th
} = window.__gradio__svelte__internal, {
  SvelteComponent: nh,
  append_hydration: ih,
  attr: ah,
  children: lh,
  claim_svg_element: oh,
  detach: rh,
  init: sh,
  insert_hydration: uh,
  noop: ch,
  safe_not_equal: _h,
  svg_element: dh
} = window.__gradio__svelte__internal, {
  SvelteComponent: fh,
  append_hydration: ph,
  attr: hh,
  children: mh,
  claim_svg_element: gh,
  detach: vh,
  init: bh,
  insert_hydration: Dh,
  noop: yh,
  safe_not_equal: wh,
  svg_element: Fh
} = window.__gradio__svelte__internal, {
  SvelteComponent: $h,
  append_hydration: kh,
  attr: Eh,
  children: Ah,
  claim_svg_element: Ch,
  detach: Sh,
  init: Th,
  insert_hydration: Bh,
  noop: Ih,
  safe_not_equal: Rh,
  svg_element: Lh
} = window.__gradio__svelte__internal, {
  SvelteComponent: Oh,
  append_hydration: qh,
  attr: Nh,
  children: Mh,
  claim_svg_element: Ph,
  detach: zh,
  init: xh,
  insert_hydration: Uh,
  noop: Hh,
  safe_not_equal: Gh,
  svg_element: jh
} = window.__gradio__svelte__internal, {
  SvelteComponent: Vh,
  append_hydration: Wh,
  attr: Zh,
  children: Yh,
  claim_svg_element: Xh,
  detach: Kh,
  init: Qh,
  insert_hydration: Jh,
  noop: em,
  safe_not_equal: tm,
  svg_element: nm
} = window.__gradio__svelte__internal, {
  SvelteComponent: im,
  append_hydration: am,
  attr: lm,
  children: om,
  claim_svg_element: rm,
  detach: sm,
  init: um,
  insert_hydration: cm,
  noop: _m,
  safe_not_equal: dm,
  svg_element: fm
} = window.__gradio__svelte__internal, {
  SvelteComponent: pm,
  append_hydration: hm,
  attr: mm,
  children: gm,
  claim_svg_element: vm,
  detach: bm,
  init: Dm,
  insert_hydration: ym,
  noop: wm,
  safe_not_equal: Fm,
  svg_element: $m
} = window.__gradio__svelte__internal, {
  SvelteComponent: km,
  append_hydration: Em,
  attr: Am,
  children: Cm,
  claim_svg_element: Sm,
  detach: Tm,
  init: Bm,
  insert_hydration: Im,
  noop: Rm,
  safe_not_equal: Lm,
  svg_element: Om
} = window.__gradio__svelte__internal, {
  SvelteComponent: qm,
  append_hydration: Nm,
  attr: Mm,
  children: Pm,
  claim_svg_element: zm,
  detach: xm,
  init: Um,
  insert_hydration: Hm,
  noop: Gm,
  safe_not_equal: jm,
  svg_element: Vm
} = window.__gradio__svelte__internal, {
  SvelteComponent: Wm,
  append_hydration: Zm,
  attr: Ym,
  children: Xm,
  claim_svg_element: Km,
  detach: Qm,
  init: Jm,
  insert_hydration: eg,
  noop: tg,
  safe_not_equal: ng,
  svg_element: ig
} = window.__gradio__svelte__internal, {
  SvelteComponent: ag,
  append_hydration: lg,
  attr: og,
  children: rg,
  claim_svg_element: sg,
  detach: ug,
  init: cg,
  insert_hydration: _g,
  noop: dg,
  safe_not_equal: fg,
  svg_element: pg
} = window.__gradio__svelte__internal, {
  SvelteComponent: hg,
  append_hydration: mg,
  attr: gg,
  children: vg,
  claim_svg_element: bg,
  detach: Dg,
  init: yg,
  insert_hydration: wg,
  noop: Fg,
  safe_not_equal: $g,
  svg_element: kg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Eg,
  append_hydration: Ag,
  attr: Cg,
  children: Sg,
  claim_svg_element: Tg,
  detach: Bg,
  init: Ig,
  insert_hydration: Rg,
  noop: Lg,
  safe_not_equal: Og,
  svg_element: qg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ng,
  append_hydration: Mg,
  attr: Pg,
  children: zg,
  claim_svg_element: xg,
  detach: Ug,
  init: Hg,
  insert_hydration: Gg,
  noop: jg,
  safe_not_equal: Vg,
  svg_element: Wg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Zg,
  append_hydration: Yg,
  attr: Xg,
  children: Kg,
  claim_svg_element: Qg,
  detach: Jg,
  init: e0,
  insert_hydration: t0,
  noop: n0,
  safe_not_equal: i0,
  svg_element: a0
} = window.__gradio__svelte__internal, {
  SvelteComponent: l0,
  append_hydration: o0,
  attr: r0,
  children: s0,
  claim_svg_element: u0,
  detach: c0,
  init: _0,
  insert_hydration: d0,
  noop: f0,
  safe_not_equal: p0,
  svg_element: h0
} = window.__gradio__svelte__internal, {
  SvelteComponent: m0,
  append_hydration: g0,
  attr: v0,
  children: b0,
  claim_svg_element: D0,
  detach: y0,
  init: w0,
  insert_hydration: F0,
  noop: $0,
  safe_not_equal: k0,
  svg_element: E0
} = window.__gradio__svelte__internal, {
  SvelteComponent: A0,
  append_hydration: C0,
  attr: S0,
  children: T0,
  claim_svg_element: B0,
  detach: I0,
  init: R0,
  insert_hydration: L0,
  noop: O0,
  safe_not_equal: q0,
  svg_element: N0
} = window.__gradio__svelte__internal, {
  SvelteComponent: M0,
  append_hydration: P0,
  attr: z0,
  children: x0,
  claim_svg_element: U0,
  detach: H0,
  init: G0,
  insert_hydration: j0,
  noop: V0,
  safe_not_equal: W0,
  svg_element: Z0
} = window.__gradio__svelte__internal, {
  SvelteComponent: Y0,
  append_hydration: X0,
  attr: K0,
  children: Q0,
  claim_svg_element: J0,
  detach: e1,
  init: t1,
  insert_hydration: n1,
  noop: i1,
  safe_not_equal: a1,
  svg_element: l1
} = window.__gradio__svelte__internal, {
  SvelteComponent: o1,
  append_hydration: r1,
  attr: s1,
  children: u1,
  claim_svg_element: c1,
  detach: _1,
  init: d1,
  insert_hydration: f1,
  noop: p1,
  safe_not_equal: h1,
  svg_element: m1
} = window.__gradio__svelte__internal, {
  SvelteComponent: g1,
  append_hydration: v1,
  attr: b1,
  children: D1,
  claim_svg_element: y1,
  detach: w1,
  init: F1,
  insert_hydration: $1,
  noop: k1,
  safe_not_equal: E1,
  svg_element: A1
} = window.__gradio__svelte__internal, {
  SvelteComponent: C1,
  append_hydration: S1,
  attr: T1,
  children: B1,
  claim_svg_element: I1,
  detach: R1,
  init: L1,
  insert_hydration: O1,
  noop: q1,
  safe_not_equal: N1,
  svg_element: M1
} = window.__gradio__svelte__internal, {
  SvelteComponent: P1,
  append_hydration: z1,
  attr: x1,
  children: U1,
  claim_svg_element: H1,
  detach: G1,
  init: j1,
  insert_hydration: V1,
  noop: W1,
  safe_not_equal: Z1,
  svg_element: Y1
} = window.__gradio__svelte__internal, {
  SvelteComponent: X1,
  append_hydration: K1,
  attr: Q1,
  children: J1,
  claim_svg_element: ev,
  detach: tv,
  init: nv,
  insert_hydration: iv,
  noop: av,
  safe_not_equal: lv,
  svg_element: ov
} = window.__gradio__svelte__internal, {
  SvelteComponent: rv,
  append_hydration: sv,
  attr: uv,
  children: cv,
  claim_svg_element: _v,
  detach: dv,
  init: fv,
  insert_hydration: pv,
  noop: hv,
  safe_not_equal: mv,
  svg_element: gv
} = window.__gradio__svelte__internal, {
  SvelteComponent: vv,
  append_hydration: bv,
  attr: Dv,
  children: yv,
  claim_svg_element: wv,
  detach: Fv,
  init: $v,
  insert_hydration: kv,
  noop: Ev,
  safe_not_equal: Av,
  set_style: Cv,
  svg_element: Sv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Tv,
  append_hydration: Bv,
  attr: Iv,
  children: Rv,
  claim_svg_element: Lv,
  detach: Ov,
  init: qv,
  insert_hydration: Nv,
  noop: Mv,
  safe_not_equal: Pv,
  svg_element: zv
} = window.__gradio__svelte__internal, {
  SvelteComponent: xv,
  append_hydration: Uv,
  attr: Hv,
  children: Gv,
  claim_svg_element: jv,
  detach: Vv,
  init: Wv,
  insert_hydration: Zv,
  noop: Yv,
  safe_not_equal: Xv,
  svg_element: Kv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Qv,
  append_hydration: Jv,
  attr: eb,
  children: tb,
  claim_svg_element: nb,
  detach: ib,
  init: ab,
  insert_hydration: lb,
  noop: ob,
  safe_not_equal: rb,
  svg_element: sb
} = window.__gradio__svelte__internal, {
  SvelteComponent: ub,
  append_hydration: cb,
  attr: _b,
  children: db,
  claim_svg_element: fb,
  detach: pb,
  init: hb,
  insert_hydration: mb,
  noop: gb,
  safe_not_equal: vb,
  svg_element: bb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Db,
  append_hydration: yb,
  attr: wb,
  children: Fb,
  claim_svg_element: $b,
  detach: kb,
  init: Eb,
  insert_hydration: Ab,
  noop: Cb,
  safe_not_equal: Sb,
  svg_element: Tb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Bb,
  append_hydration: Ib,
  attr: Rb,
  children: Lb,
  claim_svg_element: Ob,
  detach: qb,
  init: Nb,
  insert_hydration: Mb,
  noop: Pb,
  safe_not_equal: zb,
  svg_element: xb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ub,
  append_hydration: Hb,
  attr: Gb,
  children: jb,
  claim_svg_element: Vb,
  detach: Wb,
  init: Zb,
  insert_hydration: Yb,
  noop: Xb,
  safe_not_equal: Kb,
  svg_element: Qb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Jb,
  append_hydration: eD,
  attr: tD,
  children: nD,
  claim_svg_element: iD,
  detach: aD,
  init: lD,
  insert_hydration: oD,
  noop: rD,
  safe_not_equal: sD,
  svg_element: uD
} = window.__gradio__svelte__internal, {
  SvelteComponent: cD,
  append_hydration: _D,
  attr: dD,
  children: fD,
  claim_svg_element: pD,
  claim_text: hD,
  detach: mD,
  init: gD,
  insert_hydration: vD,
  noop: bD,
  safe_not_equal: DD,
  svg_element: yD,
  text: wD
} = window.__gradio__svelte__internal, {
  SvelteComponent: FD,
  append_hydration: $D,
  attr: kD,
  children: ED,
  claim_svg_element: AD,
  detach: CD,
  init: SD,
  insert_hydration: TD,
  noop: BD,
  safe_not_equal: ID,
  svg_element: RD
} = window.__gradio__svelte__internal, {
  SvelteComponent: LD,
  append_hydration: OD,
  attr: qD,
  children: ND,
  claim_svg_element: MD,
  detach: PD,
  init: zD,
  insert_hydration: xD,
  noop: UD,
  safe_not_equal: HD,
  svg_element: GD
} = window.__gradio__svelte__internal, {
  SvelteComponent: jD,
  append_hydration: VD,
  attr: WD,
  children: ZD,
  claim_svg_element: YD,
  detach: XD,
  init: KD,
  insert_hydration: QD,
  noop: JD,
  safe_not_equal: ey,
  svg_element: ty
} = window.__gradio__svelte__internal, {
  SvelteComponent: ny,
  append_hydration: iy,
  attr: ay,
  children: ly,
  claim_svg_element: oy,
  detach: ry,
  init: sy,
  insert_hydration: uy,
  noop: cy,
  safe_not_equal: _y,
  svg_element: dy
} = window.__gradio__svelte__internal, {
  SvelteComponent: fy,
  append_hydration: py,
  attr: hy,
  children: my,
  claim_svg_element: gy,
  detach: vy,
  init: by,
  insert_hydration: Dy,
  noop: yy,
  safe_not_equal: wy,
  svg_element: Fy
} = window.__gradio__svelte__internal, {
  SvelteComponent: $y,
  append_hydration: ky,
  attr: Ey,
  children: Ay,
  claim_svg_element: Cy,
  detach: Sy,
  init: Ty,
  insert_hydration: By,
  noop: Iy,
  safe_not_equal: Ry,
  svg_element: Ly
} = window.__gradio__svelte__internal, {
  SvelteComponent: Oy,
  append_hydration: qy,
  attr: Ny,
  children: My,
  claim_svg_element: Py,
  detach: zy,
  init: xy,
  insert_hydration: Uy,
  noop: Hy,
  safe_not_equal: Gy,
  svg_element: jy
} = window.__gradio__svelte__internal, {
  SvelteComponent: Vy,
  append_hydration: Wy,
  attr: Zy,
  children: Yy,
  claim_svg_element: Xy,
  claim_text: Ky,
  detach: Qy,
  init: Jy,
  insert_hydration: ew,
  noop: tw,
  safe_not_equal: nw,
  svg_element: iw,
  text: aw
} = window.__gradio__svelte__internal, {
  SvelteComponent: lw,
  append_hydration: ow,
  attr: rw,
  children: sw,
  claim_svg_element: uw,
  claim_text: cw,
  detach: _w,
  init: dw,
  insert_hydration: fw,
  noop: pw,
  safe_not_equal: hw,
  svg_element: mw,
  text: gw
} = window.__gradio__svelte__internal, {
  SvelteComponent: vw,
  append_hydration: bw,
  attr: Dw,
  children: yw,
  claim_svg_element: ww,
  claim_text: Fw,
  detach: $w,
  init: kw,
  insert_hydration: Ew,
  noop: Aw,
  safe_not_equal: Cw,
  svg_element: Sw,
  text: Tw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Bw,
  append_hydration: Iw,
  attr: Rw,
  children: Lw,
  claim_svg_element: Ow,
  detach: qw,
  init: Nw,
  insert_hydration: Mw,
  noop: Pw,
  safe_not_equal: zw,
  svg_element: xw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Uw,
  append_hydration: Hw,
  attr: Gw,
  children: jw,
  claim_svg_element: Vw,
  detach: Ww,
  init: Zw,
  insert_hydration: Yw,
  noop: Xw,
  safe_not_equal: Kw,
  svg_element: Qw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Jw,
  append_hydration: eF,
  attr: tF,
  children: nF,
  claim_svg_element: iF,
  detach: aF,
  init: lF,
  insert_hydration: oF,
  noop: rF,
  safe_not_equal: sF,
  svg_element: uF
} = window.__gradio__svelte__internal, {
  SvelteComponent: cF,
  append_hydration: _F,
  attr: dF,
  children: fF,
  claim_svg_element: pF,
  detach: hF,
  init: mF,
  insert_hydration: gF,
  noop: vF,
  safe_not_equal: bF,
  svg_element: DF
} = window.__gradio__svelte__internal, {
  SvelteComponent: yF,
  append_hydration: wF,
  attr: FF,
  children: $F,
  claim_svg_element: kF,
  detach: EF,
  init: AF,
  insert_hydration: CF,
  noop: SF,
  safe_not_equal: TF,
  svg_element: BF
} = window.__gradio__svelte__internal, {
  SvelteComponent: IF,
  append_hydration: RF,
  attr: LF,
  children: OF,
  claim_svg_element: qF,
  detach: NF,
  init: MF,
  insert_hydration: PF,
  noop: zF,
  safe_not_equal: xF,
  svg_element: UF
} = window.__gradio__svelte__internal, {
  SvelteComponent: HF,
  append_hydration: GF,
  attr: jF,
  children: VF,
  claim_svg_element: WF,
  detach: ZF,
  init: YF,
  insert_hydration: XF,
  noop: KF,
  safe_not_equal: QF,
  svg_element: JF
} = window.__gradio__svelte__internal, {
  SvelteComponent: e$,
  append_hydration: t$,
  attr: n$,
  children: i$,
  claim_svg_element: a$,
  detach: l$,
  init: o$,
  insert_hydration: r$,
  noop: s$,
  safe_not_equal: u$,
  svg_element: c$
} = window.__gradio__svelte__internal, Rr = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], Qi = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
Rr.reduce(
  (i, { color: e, primary: t, secondary: n }) => ({
    ...i,
    [e]: {
      primary: Qi[e][t],
      secondary: Qi[e][n]
    }
  }),
  {}
);
const {
  SvelteComponent: _$,
  claim_component: d$,
  create_component: f$,
  destroy_component: p$,
  init: h$,
  mount_component: m$,
  safe_not_equal: g$,
  transition_in: v$,
  transition_out: b$
} = window.__gradio__svelte__internal, { createEventDispatcher: D$ } = window.__gradio__svelte__internal, {
  SvelteComponent: y$,
  append_hydration: w$,
  attr: F$,
  check_outros: $$,
  children: k$,
  claim_component: E$,
  claim_element: A$,
  claim_space: C$,
  claim_text: S$,
  create_component: T$,
  destroy_component: B$,
  detach: I$,
  element: R$,
  empty: L$,
  group_outros: O$,
  init: q$,
  insert_hydration: N$,
  mount_component: M$,
  safe_not_equal: P$,
  set_data: z$,
  space: x$,
  text: U$,
  toggle_class: H$,
  transition_in: G$,
  transition_out: j$
} = window.__gradio__svelte__internal, {
  SvelteComponent: V$,
  attr: W$,
  children: Z$,
  claim_element: Y$,
  create_slot: X$,
  detach: K$,
  element: Q$,
  get_all_dirty_from_scope: J$,
  get_slot_changes: ek,
  init: tk,
  insert_hydration: nk,
  safe_not_equal: ik,
  toggle_class: ak,
  transition_in: lk,
  transition_out: ok,
  update_slot_base: rk
} = window.__gradio__svelte__internal, {
  SvelteComponent: sk,
  append_hydration: uk,
  attr: ck,
  check_outros: _k,
  children: dk,
  claim_component: fk,
  claim_element: pk,
  claim_space: hk,
  create_component: mk,
  destroy_component: gk,
  detach: vk,
  element: bk,
  empty: Dk,
  group_outros: yk,
  init: wk,
  insert_hydration: Fk,
  listen: $k,
  mount_component: kk,
  safe_not_equal: Ek,
  space: Ak,
  toggle_class: Ck,
  transition_in: Sk,
  transition_out: Tk
} = window.__gradio__svelte__internal, {
  SvelteComponent: Bk,
  attr: Ik,
  children: Rk,
  claim_element: Lk,
  create_slot: Ok,
  detach: qk,
  element: Nk,
  get_all_dirty_from_scope: Mk,
  get_slot_changes: Pk,
  init: zk,
  insert_hydration: xk,
  null_to_empty: Uk,
  safe_not_equal: Hk,
  transition_in: Gk,
  transition_out: jk,
  update_slot_base: Vk
} = window.__gradio__svelte__internal, {
  SvelteComponent: Wk,
  check_outros: Zk,
  claim_component: Yk,
  create_component: Xk,
  destroy_component: Kk,
  detach: Qk,
  empty: Jk,
  group_outros: eE,
  init: tE,
  insert_hydration: nE,
  mount_component: iE,
  noop: aE,
  safe_not_equal: lE,
  transition_in: oE,
  transition_out: rE
} = window.__gradio__svelte__internal, { createEventDispatcher: sE } = window.__gradio__svelte__internal;
function xt(i) {
  let e = ["", "k", "M", "G", "T", "P", "E", "Z"], t = 0;
  for (; i > 1e3 && t < e.length - 1; )
    i /= 1e3, t++;
  let n = e[t];
  return (Number.isInteger(i) ? i : i.toFixed(1)) + n;
}
function Sn() {
}
const wl = typeof window < "u";
let Ji = wl ? () => window.performance.now() : () => Date.now(), Fl = wl ? (i) => requestAnimationFrame(i) : Sn;
const Ht = /* @__PURE__ */ new Set();
function $l(i) {
  Ht.forEach((e) => {
    e.c(i) || (Ht.delete(e), e.f());
  }), Ht.size !== 0 && Fl($l);
}
function Lr(i) {
  let e;
  return Ht.size === 0 && Fl($l), { promise: new Promise((t) => {
    Ht.add(e = { c: i, f: t });
  }), abort() {
    Ht.delete(e);
  } };
}
const zt = [];
function Or(i, e = Sn) {
  let t;
  const n = /* @__PURE__ */ new Set();
  function a(l) {
    if (s = l, ((r = i) != r ? s == s : r !== s || r && typeof r == "object" || typeof r == "function") && (i = l, t)) {
      const u = !zt.length;
      for (const c of n) c[1](), zt.push(c, i);
      if (u) {
        for (let c = 0; c < zt.length; c += 2) zt[c][0](zt[c + 1]);
        zt.length = 0;
      }
    }
    var r, s;
  }
  function o(l) {
    a(l(i));
  }
  return { set: a, update: o, subscribe: function(l, r = Sn) {
    const s = [l, r];
    return n.add(s), n.size === 1 && (t = e(a, o) || Sn), l(i), () => {
      n.delete(s), n.size === 0 && t && (t(), t = null);
    };
  } };
}
function ea(i) {
  return Object.prototype.toString.call(i) === "[object Date]";
}
function oi(i, e, t, n) {
  if (typeof t == "number" || ea(t)) {
    const a = n - t, o = (t - e) / (i.dt || 1 / 60), l = (o + (i.opts.stiffness * a - i.opts.damping * o) * i.inv_mass) * i.dt;
    return Math.abs(l) < i.opts.precision && Math.abs(a) < i.opts.precision ? n : (i.settled = !1, ea(t) ? new Date(t.getTime() + l) : t + l);
  }
  if (Array.isArray(t)) return t.map((a, o) => oi(i, e[o], t[o], n[o]));
  if (typeof t == "object") {
    const a = {};
    for (const o in t) a[o] = oi(i, e[o], t[o], n[o]);
    return a;
  }
  throw new Error(`Cannot spring ${typeof t} values`);
}
function ta(i, e = {}) {
  const t = Or(i), { stiffness: n = 0.15, damping: a = 0.8, precision: o = 0.01 } = e;
  let l, r, s, u = i, c = i, m = 1, d = 0, f = !1;
  function v(w, F = {}) {
    c = w;
    const h = s = {};
    return i == null || F.hard || D.stiffness >= 1 && D.damping >= 1 ? (f = !0, l = Ji(), u = w, t.set(i = c), Promise.resolve()) : (F.soft && (d = 1 / (60 * (F.soft === !0 ? 0.5 : +F.soft)), m = 0), r || (l = Ji(), f = !1, r = Lr((_) => {
      if (f) return f = !1, r = null, !1;
      m = Math.min(m + d, 1);
      const g = { inv_mass: m, opts: D, settled: !0, dt: 60 * (_ - l) / 1e3 }, y = oi(g, u, i, c);
      return l = _, u = i, t.set(i = y), g.settled && (r = null), !g.settled;
    })), new Promise((_) => {
      r.promise.then(() => {
        h === s && _();
      });
    }));
  }
  const D = { set: v, update: (w, F) => v(w(c, i), F), subscribe: t.subscribe, stiffness: n, damping: a, precision: o };
  return D;
}
const {
  SvelteComponent: qr,
  append_hydration: Ge,
  attr: V,
  children: qe,
  claim_element: Nr,
  claim_svg_element: je,
  component_subscribe: na,
  detach: Le,
  element: Mr,
  init: Pr,
  insert_hydration: zr,
  noop: ia,
  safe_not_equal: xr,
  set_style: Fn,
  svg_element: Ve,
  toggle_class: aa
} = window.__gradio__svelte__internal, { onMount: Ur } = window.__gradio__svelte__internal;
function Hr(i) {
  let e, t, n, a, o, l, r, s, u, c, m, d;
  return {
    c() {
      e = Mr("div"), t = Ve("svg"), n = Ve("g"), a = Ve("path"), o = Ve("path"), l = Ve("path"), r = Ve("path"), s = Ve("g"), u = Ve("path"), c = Ve("path"), m = Ve("path"), d = Ve("path"), this.h();
    },
    l(f) {
      e = Nr(f, "DIV", { class: !0 });
      var v = qe(e);
      t = je(v, "svg", {
        viewBox: !0,
        fill: !0,
        xmlns: !0,
        class: !0
      });
      var D = qe(t);
      n = je(D, "g", { style: !0 });
      var w = qe(n);
      a = je(w, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), qe(a).forEach(Le), o = je(w, "path", { d: !0, fill: !0, class: !0 }), qe(o).forEach(Le), l = je(w, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), qe(l).forEach(Le), r = je(w, "path", { d: !0, fill: !0, class: !0 }), qe(r).forEach(Le), w.forEach(Le), s = je(D, "g", { style: !0 });
      var F = qe(s);
      u = je(F, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), qe(u).forEach(Le), c = je(F, "path", { d: !0, fill: !0, class: !0 }), qe(c).forEach(Le), m = je(F, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), qe(m).forEach(Le), d = je(F, "path", { d: !0, fill: !0, class: !0 }), qe(d).forEach(Le), F.forEach(Le), D.forEach(Le), v.forEach(Le), this.h();
    },
    h() {
      V(a, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), V(a, "fill", "#FF7C00"), V(a, "fill-opacity", "0.4"), V(a, "class", "svelte-43sxxs"), V(o, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), V(o, "fill", "#FF7C00"), V(o, "class", "svelte-43sxxs"), V(l, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), V(l, "fill", "#FF7C00"), V(l, "fill-opacity", "0.4"), V(l, "class", "svelte-43sxxs"), V(r, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), V(r, "fill", "#FF7C00"), V(r, "class", "svelte-43sxxs"), Fn(n, "transform", "translate(" + /*$top*/
      i[1][0] + "px, " + /*$top*/
      i[1][1] + "px)"), V(u, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), V(u, "fill", "#FF7C00"), V(u, "fill-opacity", "0.4"), V(u, "class", "svelte-43sxxs"), V(c, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), V(c, "fill", "#FF7C00"), V(c, "class", "svelte-43sxxs"), V(m, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), V(m, "fill", "#FF7C00"), V(m, "fill-opacity", "0.4"), V(m, "class", "svelte-43sxxs"), V(d, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), V(d, "fill", "#FF7C00"), V(d, "class", "svelte-43sxxs"), Fn(s, "transform", "translate(" + /*$bottom*/
      i[2][0] + "px, " + /*$bottom*/
      i[2][1] + "px)"), V(t, "viewBox", "-1200 -1200 3000 3000"), V(t, "fill", "none"), V(t, "xmlns", "http://www.w3.org/2000/svg"), V(t, "class", "svelte-43sxxs"), V(e, "class", "svelte-43sxxs"), aa(
        e,
        "margin",
        /*margin*/
        i[0]
      );
    },
    m(f, v) {
      zr(f, e, v), Ge(e, t), Ge(t, n), Ge(n, a), Ge(n, o), Ge(n, l), Ge(n, r), Ge(t, s), Ge(s, u), Ge(s, c), Ge(s, m), Ge(s, d);
    },
    p(f, [v]) {
      v & /*$top*/
      2 && Fn(n, "transform", "translate(" + /*$top*/
      f[1][0] + "px, " + /*$top*/
      f[1][1] + "px)"), v & /*$bottom*/
      4 && Fn(s, "transform", "translate(" + /*$bottom*/
      f[2][0] + "px, " + /*$bottom*/
      f[2][1] + "px)"), v & /*margin*/
      1 && aa(
        e,
        "margin",
        /*margin*/
        f[0]
      );
    },
    i: ia,
    o: ia,
    d(f) {
      f && Le(e);
    }
  };
}
function Gr(i, e, t) {
  let n, a;
  var o = this && this.__awaiter || function(f, v, D, w) {
    function F(h) {
      return h instanceof D ? h : new D(function(_) {
        _(h);
      });
    }
    return new (D || (D = Promise))(function(h, _) {
      function g(C) {
        try {
          $(w.next(C));
        } catch (I) {
          _(I);
        }
      }
      function y(C) {
        try {
          $(w.throw(C));
        } catch (I) {
          _(I);
        }
      }
      function $(C) {
        C.done ? h(C.value) : F(C.value).then(g, y);
      }
      $((w = w.apply(f, v || [])).next());
    });
  };
  let { margin: l = !0 } = e;
  const r = ta([0, 0]);
  na(i, r, (f) => t(1, n = f));
  const s = ta([0, 0]);
  na(i, s, (f) => t(2, a = f));
  let u;
  function c() {
    return o(this, void 0, void 0, function* () {
      yield Promise.all([r.set([125, 140]), s.set([-125, -140])]), yield Promise.all([r.set([-125, 140]), s.set([125, -140])]), yield Promise.all([r.set([-125, 0]), s.set([125, -0])]), yield Promise.all([r.set([125, 0]), s.set([-125, 0])]);
    });
  }
  function m() {
    return o(this, void 0, void 0, function* () {
      yield c(), u || m();
    });
  }
  function d() {
    return o(this, void 0, void 0, function* () {
      yield Promise.all([r.set([125, 0]), s.set([-125, 0])]), m();
    });
  }
  return Ur(() => (d(), () => u = !0)), i.$$set = (f) => {
    "margin" in f && t(0, l = f.margin);
  }, [l, n, a, r, s];
}
class jr extends qr {
  constructor(e) {
    super(), Pr(this, e, Gr, Hr, xr, { margin: 0 });
  }
}
const {
  SvelteComponent: Vr,
  append_hydration: Bt,
  attr: Ye,
  binding_callbacks: la,
  check_outros: ri,
  children: rt,
  claim_component: kl,
  claim_element: st,
  claim_space: Me,
  claim_text: ae,
  create_component: El,
  create_slot: Al,
  destroy_component: Cl,
  destroy_each: Sl,
  detach: q,
  element: ut,
  empty: ze,
  ensure_array_like: Ln,
  get_all_dirty_from_scope: Tl,
  get_slot_changes: Bl,
  group_outros: si,
  init: Wr,
  insert_hydration: P,
  mount_component: Il,
  noop: ui,
  safe_not_equal: Zr,
  set_data: xe,
  set_style: Ct,
  space: Pe,
  text: le,
  toggle_class: Ne,
  transition_in: Ze,
  transition_out: ct,
  update_slot_base: Rl
} = window.__gradio__svelte__internal, { tick: Yr } = window.__gradio__svelte__internal, { onDestroy: Xr } = window.__gradio__svelte__internal, { createEventDispatcher: Kr } = window.__gradio__svelte__internal, Qr = (i) => ({}), oa = (i) => ({}), Jr = (i) => ({}), ra = (i) => ({});
function sa(i, e, t) {
  const n = i.slice();
  return n[40] = e[t], n[42] = t, n;
}
function ua(i, e, t) {
  const n = i.slice();
  return n[40] = e[t], n;
}
function es(i) {
  let e, t, n, a, o = (
    /*i18n*/
    i[1]("common.error") + ""
  ), l, r, s;
  t = new Er({
    props: {
      Icon: Ir,
      label: (
        /*i18n*/
        i[1]("common.clear")
      ),
      disabled: !1
    }
  }), t.$on(
    "click",
    /*click_handler*/
    i[32]
  );
  const u = (
    /*#slots*/
    i[30].error
  ), c = Al(
    u,
    i,
    /*$$scope*/
    i[29],
    oa
  );
  return {
    c() {
      e = ut("div"), El(t.$$.fragment), n = Pe(), a = ut("span"), l = le(o), r = Pe(), c && c.c(), this.h();
    },
    l(m) {
      e = st(m, "DIV", { class: !0 });
      var d = rt(e);
      kl(t.$$.fragment, d), d.forEach(q), n = Me(m), a = st(m, "SPAN", { class: !0 });
      var f = rt(a);
      l = ae(f, o), f.forEach(q), r = Me(m), c && c.l(m), this.h();
    },
    h() {
      Ye(e, "class", "clear-status svelte-17v219f"), Ye(a, "class", "error svelte-17v219f");
    },
    m(m, d) {
      P(m, e, d), Il(t, e, null), P(m, n, d), P(m, a, d), Bt(a, l), P(m, r, d), c && c.m(m, d), s = !0;
    },
    p(m, d) {
      const f = {};
      d[0] & /*i18n*/
      2 && (f.label = /*i18n*/
      m[1]("common.clear")), t.$set(f), (!s || d[0] & /*i18n*/
      2) && o !== (o = /*i18n*/
      m[1]("common.error") + "") && xe(l, o), c && c.p && (!s || d[0] & /*$$scope*/
      536870912) && Rl(
        c,
        u,
        m,
        /*$$scope*/
        m[29],
        s ? Bl(
          u,
          /*$$scope*/
          m[29],
          d,
          Qr
        ) : Tl(
          /*$$scope*/
          m[29]
        ),
        oa
      );
    },
    i(m) {
      s || (Ze(t.$$.fragment, m), Ze(c, m), s = !0);
    },
    o(m) {
      ct(t.$$.fragment, m), ct(c, m), s = !1;
    },
    d(m) {
      m && (q(e), q(n), q(a), q(r)), Cl(t), c && c.d(m);
    }
  };
}
function ts(i) {
  let e, t, n, a, o, l, r, s, u, c = (
    /*variant*/
    i[8] === "default" && /*show_eta_bar*/
    i[18] && /*show_progress*/
    i[6] === "full" && ca(i)
  );
  function m(_, g) {
    if (
      /*progress*/
      _[7]
    ) return as;
    if (
      /*queue_position*/
      _[2] !== null && /*queue_size*/
      _[3] !== void 0 && /*queue_position*/
      _[2] >= 0
    ) return is;
    if (
      /*queue_position*/
      _[2] === 0
    ) return ns;
  }
  let d = m(i), f = d && d(i), v = (
    /*timer*/
    i[5] && fa(i)
  );
  const D = [ss, rs], w = [];
  function F(_, g) {
    return (
      /*last_progress_level*/
      _[15] != null ? 0 : (
        /*show_progress*/
        _[6] === "full" ? 1 : -1
      )
    );
  }
  ~(o = F(i)) && (l = w[o] = D[o](i));
  let h = !/*timer*/
  i[5] && Da(i);
  return {
    c() {
      c && c.c(), e = Pe(), t = ut("div"), f && f.c(), n = Pe(), v && v.c(), a = Pe(), l && l.c(), r = Pe(), h && h.c(), s = ze(), this.h();
    },
    l(_) {
      c && c.l(_), e = Me(_), t = st(_, "DIV", { class: !0 });
      var g = rt(t);
      f && f.l(g), n = Me(g), v && v.l(g), g.forEach(q), a = Me(_), l && l.l(_), r = Me(_), h && h.l(_), s = ze(), this.h();
    },
    h() {
      Ye(t, "class", "progress-text svelte-17v219f"), Ne(
        t,
        "meta-text-center",
        /*variant*/
        i[8] === "center"
      ), Ne(
        t,
        "meta-text",
        /*variant*/
        i[8] === "default"
      );
    },
    m(_, g) {
      c && c.m(_, g), P(_, e, g), P(_, t, g), f && f.m(t, null), Bt(t, n), v && v.m(t, null), P(_, a, g), ~o && w[o].m(_, g), P(_, r, g), h && h.m(_, g), P(_, s, g), u = !0;
    },
    p(_, g) {
      /*variant*/
      _[8] === "default" && /*show_eta_bar*/
      _[18] && /*show_progress*/
      _[6] === "full" ? c ? c.p(_, g) : (c = ca(_), c.c(), c.m(e.parentNode, e)) : c && (c.d(1), c = null), d === (d = m(_)) && f ? f.p(_, g) : (f && f.d(1), f = d && d(_), f && (f.c(), f.m(t, n))), /*timer*/
      _[5] ? v ? v.p(_, g) : (v = fa(_), v.c(), v.m(t, null)) : v && (v.d(1), v = null), (!u || g[0] & /*variant*/
      256) && Ne(
        t,
        "meta-text-center",
        /*variant*/
        _[8] === "center"
      ), (!u || g[0] & /*variant*/
      256) && Ne(
        t,
        "meta-text",
        /*variant*/
        _[8] === "default"
      );
      let y = o;
      o = F(_), o === y ? ~o && w[o].p(_, g) : (l && (si(), ct(w[y], 1, 1, () => {
        w[y] = null;
      }), ri()), ~o ? (l = w[o], l ? l.p(_, g) : (l = w[o] = D[o](_), l.c()), Ze(l, 1), l.m(r.parentNode, r)) : l = null), /*timer*/
      _[5] ? h && (si(), ct(h, 1, 1, () => {
        h = null;
      }), ri()) : h ? (h.p(_, g), g[0] & /*timer*/
      32 && Ze(h, 1)) : (h = Da(_), h.c(), Ze(h, 1), h.m(s.parentNode, s));
    },
    i(_) {
      u || (Ze(l), Ze(h), u = !0);
    },
    o(_) {
      ct(l), ct(h), u = !1;
    },
    d(_) {
      _ && (q(e), q(t), q(a), q(r), q(s)), c && c.d(_), f && f.d(), v && v.d(), ~o && w[o].d(_), h && h.d(_);
    }
  };
}
function ca(i) {
  let e, t = `translateX(${/*eta_level*/
  (i[17] || 0) * 100 - 100}%)`;
  return {
    c() {
      e = ut("div"), this.h();
    },
    l(n) {
      e = st(n, "DIV", { class: !0 }), rt(e).forEach(q), this.h();
    },
    h() {
      Ye(e, "class", "eta-bar svelte-17v219f"), Ct(e, "transform", t);
    },
    m(n, a) {
      P(n, e, a);
    },
    p(n, a) {
      a[0] & /*eta_level*/
      131072 && t !== (t = `translateX(${/*eta_level*/
      (n[17] || 0) * 100 - 100}%)`) && Ct(e, "transform", t);
    },
    d(n) {
      n && q(e);
    }
  };
}
function ns(i) {
  let e;
  return {
    c() {
      e = le("processing |");
    },
    l(t) {
      e = ae(t, "processing |");
    },
    m(t, n) {
      P(t, e, n);
    },
    p: ui,
    d(t) {
      t && q(e);
    }
  };
}
function is(i) {
  let e, t = (
    /*queue_position*/
    i[2] + 1 + ""
  ), n, a, o, l;
  return {
    c() {
      e = le("queue: "), n = le(t), a = le("/"), o = le(
        /*queue_size*/
        i[3]
      ), l = le(" |");
    },
    l(r) {
      e = ae(r, "queue: "), n = ae(r, t), a = ae(r, "/"), o = ae(
        r,
        /*queue_size*/
        i[3]
      ), l = ae(r, " |");
    },
    m(r, s) {
      P(r, e, s), P(r, n, s), P(r, a, s), P(r, o, s), P(r, l, s);
    },
    p(r, s) {
      s[0] & /*queue_position*/
      4 && t !== (t = /*queue_position*/
      r[2] + 1 + "") && xe(n, t), s[0] & /*queue_size*/
      8 && xe(
        o,
        /*queue_size*/
        r[3]
      );
    },
    d(r) {
      r && (q(e), q(n), q(a), q(o), q(l));
    }
  };
}
function as(i) {
  let e, t = Ln(
    /*progress*/
    i[7]
  ), n = [];
  for (let a = 0; a < t.length; a += 1)
    n[a] = da(ua(i, t, a));
  return {
    c() {
      for (let a = 0; a < n.length; a += 1)
        n[a].c();
      e = ze();
    },
    l(a) {
      for (let o = 0; o < n.length; o += 1)
        n[o].l(a);
      e = ze();
    },
    m(a, o) {
      for (let l = 0; l < n.length; l += 1)
        n[l] && n[l].m(a, o);
      P(a, e, o);
    },
    p(a, o) {
      if (o[0] & /*progress*/
      128) {
        t = Ln(
          /*progress*/
          a[7]
        );
        let l;
        for (l = 0; l < t.length; l += 1) {
          const r = ua(a, t, l);
          n[l] ? n[l].p(r, o) : (n[l] = da(r), n[l].c(), n[l].m(e.parentNode, e));
        }
        for (; l < n.length; l += 1)
          n[l].d(1);
        n.length = t.length;
      }
    },
    d(a) {
      a && q(e), Sl(n, a);
    }
  };
}
function _a(i) {
  let e, t = (
    /*p*/
    i[40].unit + ""
  ), n, a, o = " ", l;
  function r(c, m) {
    return (
      /*p*/
      c[40].length != null ? os : ls
    );
  }
  let s = r(i), u = s(i);
  return {
    c() {
      u.c(), e = Pe(), n = le(t), a = le(" | "), l = le(o);
    },
    l(c) {
      u.l(c), e = Me(c), n = ae(c, t), a = ae(c, " | "), l = ae(c, o);
    },
    m(c, m) {
      u.m(c, m), P(c, e, m), P(c, n, m), P(c, a, m), P(c, l, m);
    },
    p(c, m) {
      s === (s = r(c)) && u ? u.p(c, m) : (u.d(1), u = s(c), u && (u.c(), u.m(e.parentNode, e))), m[0] & /*progress*/
      128 && t !== (t = /*p*/
      c[40].unit + "") && xe(n, t);
    },
    d(c) {
      c && (q(e), q(n), q(a), q(l)), u.d(c);
    }
  };
}
function ls(i) {
  let e = xt(
    /*p*/
    i[40].index || 0
  ) + "", t;
  return {
    c() {
      t = le(e);
    },
    l(n) {
      t = ae(n, e);
    },
    m(n, a) {
      P(n, t, a);
    },
    p(n, a) {
      a[0] & /*progress*/
      128 && e !== (e = xt(
        /*p*/
        n[40].index || 0
      ) + "") && xe(t, e);
    },
    d(n) {
      n && q(t);
    }
  };
}
function os(i) {
  let e = xt(
    /*p*/
    i[40].index || 0
  ) + "", t, n, a = xt(
    /*p*/
    i[40].length
  ) + "", o;
  return {
    c() {
      t = le(e), n = le("/"), o = le(a);
    },
    l(l) {
      t = ae(l, e), n = ae(l, "/"), o = ae(l, a);
    },
    m(l, r) {
      P(l, t, r), P(l, n, r), P(l, o, r);
    },
    p(l, r) {
      r[0] & /*progress*/
      128 && e !== (e = xt(
        /*p*/
        l[40].index || 0
      ) + "") && xe(t, e), r[0] & /*progress*/
      128 && a !== (a = xt(
        /*p*/
        l[40].length
      ) + "") && xe(o, a);
    },
    d(l) {
      l && (q(t), q(n), q(o));
    }
  };
}
function da(i) {
  let e, t = (
    /*p*/
    i[40].index != null && _a(i)
  );
  return {
    c() {
      t && t.c(), e = ze();
    },
    l(n) {
      t && t.l(n), e = ze();
    },
    m(n, a) {
      t && t.m(n, a), P(n, e, a);
    },
    p(n, a) {
      /*p*/
      n[40].index != null ? t ? t.p(n, a) : (t = _a(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && q(e), t && t.d(n);
    }
  };
}
function fa(i) {
  let e, t = (
    /*eta*/
    i[0] ? `/${/*formatted_eta*/
    i[19]}` : ""
  ), n, a;
  return {
    c() {
      e = le(
        /*formatted_timer*/
        i[20]
      ), n = le(t), a = le("s");
    },
    l(o) {
      e = ae(
        o,
        /*formatted_timer*/
        i[20]
      ), n = ae(o, t), a = ae(o, "s");
    },
    m(o, l) {
      P(o, e, l), P(o, n, l), P(o, a, l);
    },
    p(o, l) {
      l[0] & /*formatted_timer*/
      1048576 && xe(
        e,
        /*formatted_timer*/
        o[20]
      ), l[0] & /*eta, formatted_eta*/
      524289 && t !== (t = /*eta*/
      o[0] ? `/${/*formatted_eta*/
      o[19]}` : "") && xe(n, t);
    },
    d(o) {
      o && (q(e), q(n), q(a));
    }
  };
}
function rs(i) {
  let e, t;
  return e = new jr({
    props: { margin: (
      /*variant*/
      i[8] === "default"
    ) }
  }), {
    c() {
      El(e.$$.fragment);
    },
    l(n) {
      kl(e.$$.fragment, n);
    },
    m(n, a) {
      Il(e, n, a), t = !0;
    },
    p(n, a) {
      const o = {};
      a[0] & /*variant*/
      256 && (o.margin = /*variant*/
      n[8] === "default"), e.$set(o);
    },
    i(n) {
      t || (Ze(e.$$.fragment, n), t = !0);
    },
    o(n) {
      ct(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Cl(e, n);
    }
  };
}
function ss(i) {
  let e, t, n, a, o, l = `${/*last_progress_level*/
  i[15] * 100}%`, r = (
    /*progress*/
    i[7] != null && pa(i)
  );
  return {
    c() {
      e = ut("div"), t = ut("div"), r && r.c(), n = Pe(), a = ut("div"), o = ut("div"), this.h();
    },
    l(s) {
      e = st(s, "DIV", { class: !0 });
      var u = rt(e);
      t = st(u, "DIV", { class: !0 });
      var c = rt(t);
      r && r.l(c), c.forEach(q), n = Me(u), a = st(u, "DIV", { class: !0 });
      var m = rt(a);
      o = st(m, "DIV", { class: !0 }), rt(o).forEach(q), m.forEach(q), u.forEach(q), this.h();
    },
    h() {
      Ye(t, "class", "progress-level-inner svelte-17v219f"), Ye(o, "class", "progress-bar svelte-17v219f"), Ct(o, "width", l), Ye(a, "class", "progress-bar-wrap svelte-17v219f"), Ye(e, "class", "progress-level svelte-17v219f");
    },
    m(s, u) {
      P(s, e, u), Bt(e, t), r && r.m(t, null), Bt(e, n), Bt(e, a), Bt(a, o), i[31](o);
    },
    p(s, u) {
      /*progress*/
      s[7] != null ? r ? r.p(s, u) : (r = pa(s), r.c(), r.m(t, null)) : r && (r.d(1), r = null), u[0] & /*last_progress_level*/
      32768 && l !== (l = `${/*last_progress_level*/
      s[15] * 100}%`) && Ct(o, "width", l);
    },
    i: ui,
    o: ui,
    d(s) {
      s && q(e), r && r.d(), i[31](null);
    }
  };
}
function pa(i) {
  let e, t = Ln(
    /*progress*/
    i[7]
  ), n = [];
  for (let a = 0; a < t.length; a += 1)
    n[a] = ba(sa(i, t, a));
  return {
    c() {
      for (let a = 0; a < n.length; a += 1)
        n[a].c();
      e = ze();
    },
    l(a) {
      for (let o = 0; o < n.length; o += 1)
        n[o].l(a);
      e = ze();
    },
    m(a, o) {
      for (let l = 0; l < n.length; l += 1)
        n[l] && n[l].m(a, o);
      P(a, e, o);
    },
    p(a, o) {
      if (o[0] & /*progress_level, progress*/
      16512) {
        t = Ln(
          /*progress*/
          a[7]
        );
        let l;
        for (l = 0; l < t.length; l += 1) {
          const r = sa(a, t, l);
          n[l] ? n[l].p(r, o) : (n[l] = ba(r), n[l].c(), n[l].m(e.parentNode, e));
        }
        for (; l < n.length; l += 1)
          n[l].d(1);
        n.length = t.length;
      }
    },
    d(a) {
      a && q(e), Sl(n, a);
    }
  };
}
function ha(i) {
  let e, t, n, a, o = (
    /*i*/
    i[42] !== 0 && us()
  ), l = (
    /*p*/
    i[40].desc != null && ma(i)
  ), r = (
    /*p*/
    i[40].desc != null && /*progress_level*/
    i[14] && /*progress_level*/
    i[14][
      /*i*/
      i[42]
    ] != null && ga()
  ), s = (
    /*progress_level*/
    i[14] != null && va(i)
  );
  return {
    c() {
      o && o.c(), e = Pe(), l && l.c(), t = Pe(), r && r.c(), n = Pe(), s && s.c(), a = ze();
    },
    l(u) {
      o && o.l(u), e = Me(u), l && l.l(u), t = Me(u), r && r.l(u), n = Me(u), s && s.l(u), a = ze();
    },
    m(u, c) {
      o && o.m(u, c), P(u, e, c), l && l.m(u, c), P(u, t, c), r && r.m(u, c), P(u, n, c), s && s.m(u, c), P(u, a, c);
    },
    p(u, c) {
      /*p*/
      u[40].desc != null ? l ? l.p(u, c) : (l = ma(u), l.c(), l.m(t.parentNode, t)) : l && (l.d(1), l = null), /*p*/
      u[40].desc != null && /*progress_level*/
      u[14] && /*progress_level*/
      u[14][
        /*i*/
        u[42]
      ] != null ? r || (r = ga(), r.c(), r.m(n.parentNode, n)) : r && (r.d(1), r = null), /*progress_level*/
      u[14] != null ? s ? s.p(u, c) : (s = va(u), s.c(), s.m(a.parentNode, a)) : s && (s.d(1), s = null);
    },
    d(u) {
      u && (q(e), q(t), q(n), q(a)), o && o.d(u), l && l.d(u), r && r.d(u), s && s.d(u);
    }
  };
}
function us(i) {
  let e;
  return {
    c() {
      e = le(" /");
    },
    l(t) {
      e = ae(t, " /");
    },
    m(t, n) {
      P(t, e, n);
    },
    d(t) {
      t && q(e);
    }
  };
}
function ma(i) {
  let e = (
    /*p*/
    i[40].desc + ""
  ), t;
  return {
    c() {
      t = le(e);
    },
    l(n) {
      t = ae(n, e);
    },
    m(n, a) {
      P(n, t, a);
    },
    p(n, a) {
      a[0] & /*progress*/
      128 && e !== (e = /*p*/
      n[40].desc + "") && xe(t, e);
    },
    d(n) {
      n && q(t);
    }
  };
}
function ga(i) {
  let e;
  return {
    c() {
      e = le("-");
    },
    l(t) {
      e = ae(t, "-");
    },
    m(t, n) {
      P(t, e, n);
    },
    d(t) {
      t && q(e);
    }
  };
}
function va(i) {
  let e = (100 * /*progress_level*/
  (i[14][
    /*i*/
    i[42]
  ] || 0)).toFixed(1) + "", t, n;
  return {
    c() {
      t = le(e), n = le("%");
    },
    l(a) {
      t = ae(a, e), n = ae(a, "%");
    },
    m(a, o) {
      P(a, t, o), P(a, n, o);
    },
    p(a, o) {
      o[0] & /*progress_level*/
      16384 && e !== (e = (100 * /*progress_level*/
      (a[14][
        /*i*/
        a[42]
      ] || 0)).toFixed(1) + "") && xe(t, e);
    },
    d(a) {
      a && (q(t), q(n));
    }
  };
}
function ba(i) {
  let e, t = (
    /*p*/
    (i[40].desc != null || /*progress_level*/
    i[14] && /*progress_level*/
    i[14][
      /*i*/
      i[42]
    ] != null) && ha(i)
  );
  return {
    c() {
      t && t.c(), e = ze();
    },
    l(n) {
      t && t.l(n), e = ze();
    },
    m(n, a) {
      t && t.m(n, a), P(n, e, a);
    },
    p(n, a) {
      /*p*/
      n[40].desc != null || /*progress_level*/
      n[14] && /*progress_level*/
      n[14][
        /*i*/
        n[42]
      ] != null ? t ? t.p(n, a) : (t = ha(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && q(e), t && t.d(n);
    }
  };
}
function Da(i) {
  let e, t, n, a;
  const o = (
    /*#slots*/
    i[30]["additional-loading-text"]
  ), l = Al(
    o,
    i,
    /*$$scope*/
    i[29],
    ra
  );
  return {
    c() {
      e = ut("p"), t = le(
        /*loading_text*/
        i[9]
      ), n = Pe(), l && l.c(), this.h();
    },
    l(r) {
      e = st(r, "P", { class: !0 });
      var s = rt(e);
      t = ae(
        s,
        /*loading_text*/
        i[9]
      ), s.forEach(q), n = Me(r), l && l.l(r), this.h();
    },
    h() {
      Ye(e, "class", "loading svelte-17v219f");
    },
    m(r, s) {
      P(r, e, s), Bt(e, t), P(r, n, s), l && l.m(r, s), a = !0;
    },
    p(r, s) {
      (!a || s[0] & /*loading_text*/
      512) && xe(
        t,
        /*loading_text*/
        r[9]
      ), l && l.p && (!a || s[0] & /*$$scope*/
      536870912) && Rl(
        l,
        o,
        r,
        /*$$scope*/
        r[29],
        a ? Bl(
          o,
          /*$$scope*/
          r[29],
          s,
          Jr
        ) : Tl(
          /*$$scope*/
          r[29]
        ),
        ra
      );
    },
    i(r) {
      a || (Ze(l, r), a = !0);
    },
    o(r) {
      ct(l, r), a = !1;
    },
    d(r) {
      r && (q(e), q(n)), l && l.d(r);
    }
  };
}
function cs(i) {
  let e, t, n, a, o;
  const l = [ts, es], r = [];
  function s(u, c) {
    return (
      /*status*/
      u[4] === "pending" ? 0 : (
        /*status*/
        u[4] === "error" ? 1 : -1
      )
    );
  }
  return ~(t = s(i)) && (n = r[t] = l[t](i)), {
    c() {
      e = ut("div"), n && n.c(), this.h();
    },
    l(u) {
      e = st(u, "DIV", { class: !0 });
      var c = rt(e);
      n && n.l(c), c.forEach(q), this.h();
    },
    h() {
      Ye(e, "class", a = "wrap " + /*variant*/
      i[8] + " " + /*show_progress*/
      i[6] + " svelte-17v219f"), Ne(e, "hide", !/*status*/
      i[4] || /*status*/
      i[4] === "complete" || /*show_progress*/
      i[6] === "hidden" || /*status*/
      i[4] == "streaming"), Ne(
        e,
        "translucent",
        /*variant*/
        i[8] === "center" && /*status*/
        (i[4] === "pending" || /*status*/
        i[4] === "error") || /*translucent*/
        i[11] || /*show_progress*/
        i[6] === "minimal"
      ), Ne(
        e,
        "generating",
        /*status*/
        i[4] === "generating" && /*show_progress*/
        i[6] === "full"
      ), Ne(
        e,
        "border",
        /*border*/
        i[12]
      ), Ct(
        e,
        "position",
        /*absolute*/
        i[10] ? "absolute" : "static"
      ), Ct(
        e,
        "padding",
        /*absolute*/
        i[10] ? "0" : "var(--size-8) 0"
      );
    },
    m(u, c) {
      P(u, e, c), ~t && r[t].m(e, null), i[33](e), o = !0;
    },
    p(u, c) {
      let m = t;
      t = s(u), t === m ? ~t && r[t].p(u, c) : (n && (si(), ct(r[m], 1, 1, () => {
        r[m] = null;
      }), ri()), ~t ? (n = r[t], n ? n.p(u, c) : (n = r[t] = l[t](u), n.c()), Ze(n, 1), n.m(e, null)) : n = null), (!o || c[0] & /*variant, show_progress*/
      320 && a !== (a = "wrap " + /*variant*/
      u[8] + " " + /*show_progress*/
      u[6] + " svelte-17v219f")) && Ye(e, "class", a), (!o || c[0] & /*variant, show_progress, status, show_progress*/
      336) && Ne(e, "hide", !/*status*/
      u[4] || /*status*/
      u[4] === "complete" || /*show_progress*/
      u[6] === "hidden" || /*status*/
      u[4] == "streaming"), (!o || c[0] & /*variant, show_progress, variant, status, translucent, show_progress*/
      2384) && Ne(
        e,
        "translucent",
        /*variant*/
        u[8] === "center" && /*status*/
        (u[4] === "pending" || /*status*/
        u[4] === "error") || /*translucent*/
        u[11] || /*show_progress*/
        u[6] === "minimal"
      ), (!o || c[0] & /*variant, show_progress, status, show_progress*/
      336) && Ne(
        e,
        "generating",
        /*status*/
        u[4] === "generating" && /*show_progress*/
        u[6] === "full"
      ), (!o || c[0] & /*variant, show_progress, border*/
      4416) && Ne(
        e,
        "border",
        /*border*/
        u[12]
      ), c[0] & /*absolute*/
      1024 && Ct(
        e,
        "position",
        /*absolute*/
        u[10] ? "absolute" : "static"
      ), c[0] & /*absolute*/
      1024 && Ct(
        e,
        "padding",
        /*absolute*/
        u[10] ? "0" : "var(--size-8) 0"
      );
    },
    i(u) {
      o || (Ze(n), o = !0);
    },
    o(u) {
      ct(n), o = !1;
    },
    d(u) {
      u && q(e), ~t && r[t].d(), i[33](null);
    }
  };
}
var _s = function(i, e, t, n) {
  function a(o) {
    return o instanceof t ? o : new t(function(l) {
      l(o);
    });
  }
  return new (t || (t = Promise))(function(o, l) {
    function r(c) {
      try {
        u(n.next(c));
      } catch (m) {
        l(m);
      }
    }
    function s(c) {
      try {
        u(n.throw(c));
      } catch (m) {
        l(m);
      }
    }
    function u(c) {
      c.done ? o(c.value) : a(c.value).then(r, s);
    }
    u((n = n.apply(i, e || [])).next());
  });
};
let $n = [], Wn = !1;
const ds = typeof window < "u", Ll = ds ? window.requestAnimationFrame : (i) => {
};
function fs(i) {
  return _s(this, arguments, void 0, function* (e, t = !0) {
    if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && t !== !0)) {
      if ($n.push(e), !Wn) Wn = !0;
      else return;
      yield Yr(), Ll(() => {
        let n = [0, 0];
        for (let a = 0; a < $n.length; a++) {
          const l = $n[a].getBoundingClientRect();
          (a === 0 || l.top + window.scrollY <= n[0]) && (n[0] = l.top + window.scrollY, n[1] = a);
        }
        window.scrollTo({ top: n[0] - 20, behavior: "smooth" }), Wn = !1, $n = [];
      });
    }
  });
}
function ps(i, e, t) {
  let n, { $$slots: a = {}, $$scope: o } = e;
  const l = Kr();
  let { i18n: r } = e, { eta: s = null } = e, { queue_position: u } = e, { queue_size: c } = e, { status: m } = e, { scroll_to_output: d = !1 } = e, { timer: f = !0 } = e, { show_progress: v = "full" } = e, { message: D = null } = e, { progress: w = null } = e, { variant: F = "default" } = e, { loading_text: h = "Loading..." } = e, { absolute: _ = !0 } = e, { translucent: g = !1 } = e, { border: y = !1 } = e, { autoscroll: $ } = e, C, I = !1, T = 0, M = 0, N = null, j = null, ke = 0, ce = null, Ee, pe = null, ie = !0;
  const Q = () => {
    t(0, s = t(27, N = t(19, k = null))), t(25, T = performance.now()), t(26, M = 0), I = !0, se();
  };
  function se() {
    Ll(() => {
      t(26, M = (performance.now() - T) / 1e3), I && se();
    });
  }
  function be() {
    t(26, M = 0), t(0, s = t(27, N = t(19, k = null))), I && (I = !1);
  }
  Xr(() => {
    I && be();
  });
  let k = null;
  function oe(A) {
    la[A ? "unshift" : "push"](() => {
      pe = A, t(16, pe), t(7, w), t(14, ce), t(15, Ee);
    });
  }
  const J = () => {
    l("clear_status");
  };
  function he(A) {
    la[A ? "unshift" : "push"](() => {
      C = A, t(13, C);
    });
  }
  return i.$$set = (A) => {
    "i18n" in A && t(1, r = A.i18n), "eta" in A && t(0, s = A.eta), "queue_position" in A && t(2, u = A.queue_position), "queue_size" in A && t(3, c = A.queue_size), "status" in A && t(4, m = A.status), "scroll_to_output" in A && t(22, d = A.scroll_to_output), "timer" in A && t(5, f = A.timer), "show_progress" in A && t(6, v = A.show_progress), "message" in A && t(23, D = A.message), "progress" in A && t(7, w = A.progress), "variant" in A && t(8, F = A.variant), "loading_text" in A && t(9, h = A.loading_text), "absolute" in A && t(10, _ = A.absolute), "translucent" in A && t(11, g = A.translucent), "border" in A && t(12, y = A.border), "autoscroll" in A && t(24, $ = A.autoscroll), "$$scope" in A && t(29, o = A.$$scope);
  }, i.$$.update = () => {
    i.$$.dirty[0] & /*eta, old_eta, timer_start, eta_from_start*/
    436207617 && (s === null && t(0, s = N), s != null && N !== s && (t(28, j = (performance.now() - T) / 1e3 + s), t(19, k = j.toFixed(1)), t(27, N = s))), i.$$.dirty[0] & /*eta_from_start, timer_diff*/
    335544320 && t(17, ke = j === null || j <= 0 || !M ? null : Math.min(M / j, 1)), i.$$.dirty[0] & /*progress*/
    128 && w != null && t(18, ie = !1), i.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    114816 && (w != null ? t(14, ce = w.map((A) => {
      if (A.index != null && A.length != null)
        return A.index / A.length;
      if (A.progress != null)
        return A.progress;
    })) : t(14, ce = null), ce ? (t(15, Ee = ce[ce.length - 1]), pe && (Ee === 0 ? t(16, pe.style.transition = "0", pe) : t(16, pe.style.transition = "150ms", pe))) : t(15, Ee = void 0)), i.$$.dirty[0] & /*status*/
    16 && (m === "pending" ? Q() : be()), i.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    20979728 && C && d && (m === "pending" || m === "complete") && fs(C, $), i.$$.dirty[0] & /*status, message*/
    8388624, i.$$.dirty[0] & /*timer_diff*/
    67108864 && t(20, n = M.toFixed(1));
  }, [
    s,
    r,
    u,
    c,
    m,
    f,
    v,
    w,
    F,
    h,
    _,
    g,
    y,
    C,
    ce,
    Ee,
    pe,
    ke,
    ie,
    k,
    n,
    l,
    d,
    D,
    $,
    T,
    M,
    N,
    j,
    o,
    a,
    oe,
    J,
    he
  ];
}
class hs extends Vr {
  constructor(e) {
    super(), Wr(
      this,
      e,
      ps,
      cs,
      Zr,
      {
        i18n: 1,
        eta: 0,
        queue_position: 2,
        queue_size: 3,
        status: 4,
        scroll_to_output: 22,
        timer: 5,
        show_progress: 6,
        message: 23,
        progress: 7,
        variant: 8,
        loading_text: 9,
        absolute: 10,
        translucent: 11,
        border: 12,
        autoscroll: 24
      },
      null,
      [-1, -1]
    );
  }
}
/*! @license DOMPurify 3.2.6 | (c) Cure53 and other contributors | Released under the Apache license 2.0 and Mozilla Public License 2.0 | github.com/cure53/DOMPurify/blob/3.2.6/LICENSE */
const {
  entries: Ol,
  setPrototypeOf: ya,
  isFrozen: ms,
  getPrototypeOf: gs,
  getOwnPropertyDescriptor: vs
} = Object;
let {
  freeze: Ce,
  seal: Ue,
  create: ql
} = Object, {
  apply: ci,
  construct: _i
} = typeof Reflect < "u" && Reflect;
Ce || (Ce = function(e) {
  return e;
});
Ue || (Ue = function(e) {
  return e;
});
ci || (ci = function(e, t, n) {
  return e.apply(t, n);
});
_i || (_i = function(e, t) {
  return new e(...t);
});
const kn = Se(Array.prototype.forEach), bs = Se(Array.prototype.lastIndexOf), wa = Se(Array.prototype.pop), Qt = Se(Array.prototype.push), Ds = Se(Array.prototype.splice), Tn = Se(String.prototype.toLowerCase), Zn = Se(String.prototype.toString), Fa = Se(String.prototype.match), Jt = Se(String.prototype.replace), ys = Se(String.prototype.indexOf), ws = Se(String.prototype.trim), We = Se(Object.prototype.hasOwnProperty), Ae = Se(RegExp.prototype.test), en = Fs(TypeError);
function Se(i) {
  return function(e) {
    e instanceof RegExp && (e.lastIndex = 0);
    for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), a = 1; a < t; a++)
      n[a - 1] = arguments[a];
    return ci(i, e, n);
  };
}
function Fs(i) {
  return function() {
    for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++)
      t[n] = arguments[n];
    return _i(i, t);
  };
}
function H(i, e) {
  let t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : Tn;
  ya && ya(i, null);
  let n = e.length;
  for (; n--; ) {
    let a = e[n];
    if (typeof a == "string") {
      const o = t(a);
      o !== a && (ms(e) || (e[n] = o), a = o);
    }
    i[a] = !0;
  }
  return i;
}
function $s(i) {
  for (let e = 0; e < i.length; e++)
    We(i, e) || (i[e] = null);
  return i;
}
function bt(i) {
  const e = ql(null);
  for (const [t, n] of Ol(i))
    We(i, t) && (Array.isArray(n) ? e[t] = $s(n) : n && typeof n == "object" && n.constructor === Object ? e[t] = bt(n) : e[t] = n);
  return e;
}
function tn(i, e) {
  for (; i !== null; ) {
    const n = vs(i, e);
    if (n) {
      if (n.get)
        return Se(n.get);
      if (typeof n.value == "function")
        return Se(n.value);
    }
    i = gs(i);
  }
  function t() {
    return null;
  }
  return t;
}
const $a = Ce(["a", "abbr", "acronym", "address", "area", "article", "aside", "audio", "b", "bdi", "bdo", "big", "blink", "blockquote", "body", "br", "button", "canvas", "caption", "center", "cite", "code", "col", "colgroup", "content", "data", "datalist", "dd", "decorator", "del", "details", "dfn", "dialog", "dir", "div", "dl", "dt", "element", "em", "fieldset", "figcaption", "figure", "font", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "i", "img", "input", "ins", "kbd", "label", "legend", "li", "main", "map", "mark", "marquee", "menu", "menuitem", "meter", "nav", "nobr", "ol", "optgroup", "option", "output", "p", "picture", "pre", "progress", "q", "rp", "rt", "ruby", "s", "samp", "section", "select", "shadow", "small", "source", "spacer", "span", "strike", "strong", "style", "sub", "summary", "sup", "table", "tbody", "td", "template", "textarea", "tfoot", "th", "thead", "time", "tr", "track", "tt", "u", "ul", "var", "video", "wbr"]), Yn = Ce(["svg", "a", "altglyph", "altglyphdef", "altglyphitem", "animatecolor", "animatemotion", "animatetransform", "circle", "clippath", "defs", "desc", "ellipse", "filter", "font", "g", "glyph", "glyphref", "hkern", "image", "line", "lineargradient", "marker", "mask", "metadata", "mpath", "path", "pattern", "polygon", "polyline", "radialgradient", "rect", "stop", "style", "switch", "symbol", "text", "textpath", "title", "tref", "tspan", "view", "vkern"]), Xn = Ce(["feBlend", "feColorMatrix", "feComponentTransfer", "feComposite", "feConvolveMatrix", "feDiffuseLighting", "feDisplacementMap", "feDistantLight", "feDropShadow", "feFlood", "feFuncA", "feFuncB", "feFuncG", "feFuncR", "feGaussianBlur", "feImage", "feMerge", "feMergeNode", "feMorphology", "feOffset", "fePointLight", "feSpecularLighting", "feSpotLight", "feTile", "feTurbulence"]), ks = Ce(["animate", "color-profile", "cursor", "discard", "font-face", "font-face-format", "font-face-name", "font-face-src", "font-face-uri", "foreignobject", "hatch", "hatchpath", "mesh", "meshgradient", "meshpatch", "meshrow", "missing-glyph", "script", "set", "solidcolor", "unknown", "use"]), Kn = Ce(["math", "menclose", "merror", "mfenced", "mfrac", "mglyph", "mi", "mlabeledtr", "mmultiscripts", "mn", "mo", "mover", "mpadded", "mphantom", "mroot", "mrow", "ms", "mspace", "msqrt", "mstyle", "msub", "msup", "msubsup", "mtable", "mtd", "mtext", "mtr", "munder", "munderover", "mprescripts"]), Es = Ce(["maction", "maligngroup", "malignmark", "mlongdiv", "mscarries", "mscarry", "msgroup", "mstack", "msline", "msrow", "semantics", "annotation", "annotation-xml", "mprescripts", "none"]), ka = Ce(["#text"]), Ea = Ce(["accept", "action", "align", "alt", "autocapitalize", "autocomplete", "autopictureinpicture", "autoplay", "background", "bgcolor", "border", "capture", "cellpadding", "cellspacing", "checked", "cite", "class", "clear", "color", "cols", "colspan", "controls", "controlslist", "coords", "crossorigin", "datetime", "decoding", "default", "dir", "disabled", "disablepictureinpicture", "disableremoteplayback", "download", "draggable", "enctype", "enterkeyhint", "face", "for", "headers", "height", "hidden", "high", "href", "hreflang", "id", "inputmode", "integrity", "ismap", "kind", "label", "lang", "list", "loading", "loop", "low", "max", "maxlength", "media", "method", "min", "minlength", "multiple", "muted", "name", "nonce", "noshade", "novalidate", "nowrap", "open", "optimum", "pattern", "placeholder", "playsinline", "popover", "popovertarget", "popovertargetaction", "poster", "preload", "pubdate", "radiogroup", "readonly", "rel", "required", "rev", "reversed", "role", "rows", "rowspan", "spellcheck", "scope", "selected", "shape", "size", "sizes", "span", "srclang", "start", "src", "srcset", "step", "style", "summary", "tabindex", "title", "translate", "type", "usemap", "valign", "value", "width", "wrap", "xmlns", "slot"]), Qn = Ce(["accent-height", "accumulate", "additive", "alignment-baseline", "amplitude", "ascent", "attributename", "attributetype", "azimuth", "basefrequency", "baseline-shift", "begin", "bias", "by", "class", "clip", "clippathunits", "clip-path", "clip-rule", "color", "color-interpolation", "color-interpolation-filters", "color-profile", "color-rendering", "cx", "cy", "d", "dx", "dy", "diffuseconstant", "direction", "display", "divisor", "dur", "edgemode", "elevation", "end", "exponent", "fill", "fill-opacity", "fill-rule", "filter", "filterunits", "flood-color", "flood-opacity", "font-family", "font-size", "font-size-adjust", "font-stretch", "font-style", "font-variant", "font-weight", "fx", "fy", "g1", "g2", "glyph-name", "glyphref", "gradientunits", "gradienttransform", "height", "href", "id", "image-rendering", "in", "in2", "intercept", "k", "k1", "k2", "k3", "k4", "kerning", "keypoints", "keysplines", "keytimes", "lang", "lengthadjust", "letter-spacing", "kernelmatrix", "kernelunitlength", "lighting-color", "local", "marker-end", "marker-mid", "marker-start", "markerheight", "markerunits", "markerwidth", "maskcontentunits", "maskunits", "max", "mask", "media", "method", "mode", "min", "name", "numoctaves", "offset", "operator", "opacity", "order", "orient", "orientation", "origin", "overflow", "paint-order", "path", "pathlength", "patterncontentunits", "patterntransform", "patternunits", "points", "preservealpha", "preserveaspectratio", "primitiveunits", "r", "rx", "ry", "radius", "refx", "refy", "repeatcount", "repeatdur", "restart", "result", "rotate", "scale", "seed", "shape-rendering", "slope", "specularconstant", "specularexponent", "spreadmethod", "startoffset", "stddeviation", "stitchtiles", "stop-color", "stop-opacity", "stroke-dasharray", "stroke-dashoffset", "stroke-linecap", "stroke-linejoin", "stroke-miterlimit", "stroke-opacity", "stroke", "stroke-width", "style", "surfacescale", "systemlanguage", "tabindex", "tablevalues", "targetx", "targety", "transform", "transform-origin", "text-anchor", "text-decoration", "text-rendering", "textlength", "type", "u1", "u2", "unicode", "values", "viewbox", "visibility", "version", "vert-adv-y", "vert-origin-x", "vert-origin-y", "width", "word-spacing", "wrap", "writing-mode", "xchannelselector", "ychannelselector", "x", "x1", "x2", "xmlns", "y", "y1", "y2", "z", "zoomandpan"]), Aa = Ce(["accent", "accentunder", "align", "bevelled", "close", "columnsalign", "columnlines", "columnspan", "denomalign", "depth", "dir", "display", "displaystyle", "encoding", "fence", "frame", "height", "href", "id", "largeop", "length", "linethickness", "lspace", "lquote", "mathbackground", "mathcolor", "mathsize", "mathvariant", "maxsize", "minsize", "movablelimits", "notation", "numalign", "open", "rowalign", "rowlines", "rowspacing", "rowspan", "rspace", "rquote", "scriptlevel", "scriptminsize", "scriptsizemultiplier", "selection", "separator", "separators", "stretchy", "subscriptshift", "supscriptshift", "symmetric", "voffset", "width", "xmlns"]), En = Ce(["xlink:href", "xml:id", "xlink:title", "xml:space", "xmlns:xlink"]), As = Ue(/\{\{[\w\W]*|[\w\W]*\}\}/gm), Cs = Ue(/<%[\w\W]*|[\w\W]*%>/gm), Ss = Ue(/\$\{[\w\W]*/gm), Ts = Ue(/^data-[\-\w.\u00B7-\uFFFF]+$/), Bs = Ue(/^aria-[\-\w]+$/), Nl = Ue(
  /^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp|matrix):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i
  // eslint-disable-line no-useless-escape
), Is = Ue(/^(?:\w+script|data):/i), Rs = Ue(
  /[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g
  // eslint-disable-line no-control-regex
), Ml = Ue(/^html$/i), Ls = Ue(/^[a-z][.\w]*(-[.\w]+)+$/i);
var Ca = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  ARIA_ATTR: Bs,
  ATTR_WHITESPACE: Rs,
  CUSTOM_ELEMENT: Ls,
  DATA_ATTR: Ts,
  DOCTYPE_NAME: Ml,
  ERB_EXPR: Cs,
  IS_ALLOWED_URI: Nl,
  IS_SCRIPT_OR_DATA: Is,
  MUSTACHE_EXPR: As,
  TMPLIT_EXPR: Ss
});
const nn = {
  element: 1,
  text: 3,
  // Deprecated
  progressingInstruction: 7,
  comment: 8,
  document: 9
}, Os = function() {
  return typeof window > "u" ? null : window;
}, qs = function(e, t) {
  if (typeof e != "object" || typeof e.createPolicy != "function")
    return null;
  let n = null;
  const a = "data-tt-policy-suffix";
  t && t.hasAttribute(a) && (n = t.getAttribute(a));
  const o = "dompurify" + (n ? "#" + n : "");
  try {
    return e.createPolicy(o, {
      createHTML(l) {
        return l;
      },
      createScriptURL(l) {
        return l;
      }
    });
  } catch {
    return console.warn("TrustedTypes policy " + o + " could not be created."), null;
  }
}, Sa = function() {
  return {
    afterSanitizeAttributes: [],
    afterSanitizeElements: [],
    afterSanitizeShadowDOM: [],
    beforeSanitizeAttributes: [],
    beforeSanitizeElements: [],
    beforeSanitizeShadowDOM: [],
    uponSanitizeAttribute: [],
    uponSanitizeElement: [],
    uponSanitizeShadowNode: []
  };
};
function Pl() {
  let i = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : Os();
  const e = (O) => Pl(O);
  if (e.version = "3.2.6", e.removed = [], !i || !i.document || i.document.nodeType !== nn.document || !i.Element)
    return e.isSupported = !1, e;
  let {
    document: t
  } = i;
  const n = t, a = n.currentScript, {
    DocumentFragment: o,
    HTMLTemplateElement: l,
    Node: r,
    Element: s,
    NodeFilter: u,
    NamedNodeMap: c = i.NamedNodeMap || i.MozNamedAttrMap,
    HTMLFormElement: m,
    DOMParser: d,
    trustedTypes: f
  } = i, v = s.prototype, D = tn(v, "cloneNode"), w = tn(v, "remove"), F = tn(v, "nextSibling"), h = tn(v, "childNodes"), _ = tn(v, "parentNode");
  if (typeof l == "function") {
    const O = t.createElement("template");
    O.content && O.content.ownerDocument && (t = O.content.ownerDocument);
  }
  let g, y = "";
  const {
    implementation: $,
    createNodeIterator: C,
    createDocumentFragment: I,
    getElementsByTagName: T
  } = t, {
    importNode: M
  } = n;
  let N = Sa();
  e.isSupported = typeof Ol == "function" && typeof _ == "function" && $ && $.createHTMLDocument !== void 0;
  const {
    MUSTACHE_EXPR: j,
    ERB_EXPR: ke,
    TMPLIT_EXPR: ce,
    DATA_ATTR: Ee,
    ARIA_ATTR: pe,
    IS_SCRIPT_OR_DATA: ie,
    ATTR_WHITESPACE: Q,
    CUSTOM_ELEMENT: se
  } = Ca;
  let {
    IS_ALLOWED_URI: be
  } = Ca, k = null;
  const oe = H({}, [...$a, ...Yn, ...Xn, ...Kn, ...ka]);
  let J = null;
  const he = H({}, [...Ea, ...Qn, ...Aa, ...En]);
  let A = Object.seal(ql(null, {
    tagNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    attributeNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    allowCustomizedBuiltInElements: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: !1
    }
  })), Te = null, Qe = null, Dt = !0, yt = !0, wt = !1, ft = !0, Je = !1, et = !0, pt = !1, Gt = !1, jt = !1, Ft = !1, qt = !1, Nt = !1, dn = !0, fn = !1;
  const Nn = "user-content-";
  let Vt = !0, St = !1, $t = {}, kt = null;
  const pn = H({}, ["annotation-xml", "audio", "colgroup", "desc", "foreignobject", "head", "iframe", "math", "mi", "mn", "mo", "ms", "mtext", "noembed", "noframes", "noscript", "plaintext", "script", "style", "svg", "template", "thead", "title", "video", "xmp"]);
  let b = null;
  const L = H({}, ["audio", "video", "img", "source", "image", "track"]);
  let W = null;
  const re = H({}, ["alt", "class", "for", "id", "label", "name", "pattern", "placeholder", "role", "summary", "title", "value", "style", "xmlns"]), Be = "http://www.w3.org/1998/Math/MathML", tt = "http://www.w3.org/2000/svg", Ie = "http://www.w3.org/1999/xhtml";
  let Et = Ie, Wt = !1, Tt = null;
  const ht = H({}, [Be, tt, Ie], Zn);
  let At = H({}, ["mi", "mo", "mn", "ms", "mtext"]), hn = H({}, ["annotation-xml"]);
  const Zl = H({}, ["title", "style", "font", "a", "script"]);
  let Zt = null;
  const Yl = ["application/xhtml+xml", "text/html"], Xl = "text/html";
  let me = null, Mt = null;
  const Kl = t.createElement("form"), yi = function(p) {
    return p instanceof RegExp || p instanceof Function;
  }, Mn = function() {
    let p = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    if (!(Mt && Mt === p)) {
      if ((!p || typeof p != "object") && (p = {}), p = bt(p), Zt = // eslint-disable-next-line unicorn/prefer-includes
      Yl.indexOf(p.PARSER_MEDIA_TYPE) === -1 ? Xl : p.PARSER_MEDIA_TYPE, me = Zt === "application/xhtml+xml" ? Zn : Tn, k = We(p, "ALLOWED_TAGS") ? H({}, p.ALLOWED_TAGS, me) : oe, J = We(p, "ALLOWED_ATTR") ? H({}, p.ALLOWED_ATTR, me) : he, Tt = We(p, "ALLOWED_NAMESPACES") ? H({}, p.ALLOWED_NAMESPACES, Zn) : ht, W = We(p, "ADD_URI_SAFE_ATTR") ? H(bt(re), p.ADD_URI_SAFE_ATTR, me) : re, b = We(p, "ADD_DATA_URI_TAGS") ? H(bt(L), p.ADD_DATA_URI_TAGS, me) : L, kt = We(p, "FORBID_CONTENTS") ? H({}, p.FORBID_CONTENTS, me) : pn, Te = We(p, "FORBID_TAGS") ? H({}, p.FORBID_TAGS, me) : bt({}), Qe = We(p, "FORBID_ATTR") ? H({}, p.FORBID_ATTR, me) : bt({}), $t = We(p, "USE_PROFILES") ? p.USE_PROFILES : !1, Dt = p.ALLOW_ARIA_ATTR !== !1, yt = p.ALLOW_DATA_ATTR !== !1, wt = p.ALLOW_UNKNOWN_PROTOCOLS || !1, ft = p.ALLOW_SELF_CLOSE_IN_ATTR !== !1, Je = p.SAFE_FOR_TEMPLATES || !1, et = p.SAFE_FOR_XML !== !1, pt = p.WHOLE_DOCUMENT || !1, Ft = p.RETURN_DOM || !1, qt = p.RETURN_DOM_FRAGMENT || !1, Nt = p.RETURN_TRUSTED_TYPE || !1, jt = p.FORCE_BODY || !1, dn = p.SANITIZE_DOM !== !1, fn = p.SANITIZE_NAMED_PROPS || !1, Vt = p.KEEP_CONTENT !== !1, St = p.IN_PLACE || !1, be = p.ALLOWED_URI_REGEXP || Nl, Et = p.NAMESPACE || Ie, At = p.MATHML_TEXT_INTEGRATION_POINTS || At, hn = p.HTML_INTEGRATION_POINTS || hn, A = p.CUSTOM_ELEMENT_HANDLING || {}, p.CUSTOM_ELEMENT_HANDLING && yi(p.CUSTOM_ELEMENT_HANDLING.tagNameCheck) && (A.tagNameCheck = p.CUSTOM_ELEMENT_HANDLING.tagNameCheck), p.CUSTOM_ELEMENT_HANDLING && yi(p.CUSTOM_ELEMENT_HANDLING.attributeNameCheck) && (A.attributeNameCheck = p.CUSTOM_ELEMENT_HANDLING.attributeNameCheck), p.CUSTOM_ELEMENT_HANDLING && typeof p.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements == "boolean" && (A.allowCustomizedBuiltInElements = p.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements), Je && (yt = !1), qt && (Ft = !0), $t && (k = H({}, ka), J = [], $t.html === !0 && (H(k, $a), H(J, Ea)), $t.svg === !0 && (H(k, Yn), H(J, Qn), H(J, En)), $t.svgFilters === !0 && (H(k, Xn), H(J, Qn), H(J, En)), $t.mathMl === !0 && (H(k, Kn), H(J, Aa), H(J, En))), p.ADD_TAGS && (k === oe && (k = bt(k)), H(k, p.ADD_TAGS, me)), p.ADD_ATTR && (J === he && (J = bt(J)), H(J, p.ADD_ATTR, me)), p.ADD_URI_SAFE_ATTR && H(W, p.ADD_URI_SAFE_ATTR, me), p.FORBID_CONTENTS && (kt === pn && (kt = bt(kt)), H(kt, p.FORBID_CONTENTS, me)), Vt && (k["#text"] = !0), pt && H(k, ["html", "head", "body"]), k.table && (H(k, ["tbody"]), delete Te.tbody), p.TRUSTED_TYPES_POLICY) {
        if (typeof p.TRUSTED_TYPES_POLICY.createHTML != "function")
          throw en('TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.');
        if (typeof p.TRUSTED_TYPES_POLICY.createScriptURL != "function")
          throw en('TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.');
        g = p.TRUSTED_TYPES_POLICY, y = g.createHTML("");
      } else
        g === void 0 && (g = qs(f, a)), g !== null && typeof y == "string" && (y = g.createHTML(""));
      Ce && Ce(p), Mt = p;
    }
  }, wi = H({}, [...Yn, ...Xn, ...ks]), Fi = H({}, [...Kn, ...Es]), Ql = function(p) {
    let E = _(p);
    (!E || !E.tagName) && (E = {
      namespaceURI: Et,
      tagName: "template"
    });
    const R = Tn(p.tagName), ne = Tn(E.tagName);
    return Tt[p.namespaceURI] ? p.namespaceURI === tt ? E.namespaceURI === Ie ? R === "svg" : E.namespaceURI === Be ? R === "svg" && (ne === "annotation-xml" || At[ne]) : !!wi[R] : p.namespaceURI === Be ? E.namespaceURI === Ie ? R === "math" : E.namespaceURI === tt ? R === "math" && hn[ne] : !!Fi[R] : p.namespaceURI === Ie ? E.namespaceURI === tt && !hn[ne] || E.namespaceURI === Be && !At[ne] ? !1 : !Fi[R] && (Zl[R] || !wi[R]) : !!(Zt === "application/xhtml+xml" && Tt[p.namespaceURI]) : !1;
  }, nt = function(p) {
    Qt(e.removed, {
      element: p
    });
    try {
      _(p).removeChild(p);
    } catch {
      w(p);
    }
  }, Pt = function(p, E) {
    try {
      Qt(e.removed, {
        attribute: E.getAttributeNode(p),
        from: E
      });
    } catch {
      Qt(e.removed, {
        attribute: null,
        from: E
      });
    }
    if (E.removeAttribute(p), p === "is")
      if (Ft || qt)
        try {
          nt(E);
        } catch {
        }
      else
        try {
          E.setAttribute(p, "");
        } catch {
        }
  }, $i = function(p) {
    let E = null, R = null;
    if (jt)
      p = "<remove></remove>" + p;
    else {
      const _e = Fa(p, /^[\r\n\t ]+/);
      R = _e && _e[0];
    }
    Zt === "application/xhtml+xml" && Et === Ie && (p = '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>' + p + "</body></html>");
    const ne = g ? g.createHTML(p) : p;
    if (Et === Ie)
      try {
        E = new d().parseFromString(ne, Zt);
      } catch {
      }
    if (!E || !E.documentElement) {
      E = $.createDocument(Et, "template", null);
      try {
        E.documentElement.innerHTML = Wt ? y : ne;
      } catch {
      }
    }
    const De = E.body || E.documentElement;
    return p && R && De.insertBefore(t.createTextNode(R), De.childNodes[0] || null), Et === Ie ? T.call(E, pt ? "html" : "body")[0] : pt ? E.documentElement : De;
  }, ki = function(p) {
    return C.call(
      p.ownerDocument || p,
      p,
      // eslint-disable-next-line no-bitwise
      u.SHOW_ELEMENT | u.SHOW_COMMENT | u.SHOW_TEXT | u.SHOW_PROCESSING_INSTRUCTION | u.SHOW_CDATA_SECTION,
      null
    );
  }, Pn = function(p) {
    return p instanceof m && (typeof p.nodeName != "string" || typeof p.textContent != "string" || typeof p.removeChild != "function" || !(p.attributes instanceof c) || typeof p.removeAttribute != "function" || typeof p.setAttribute != "function" || typeof p.namespaceURI != "string" || typeof p.insertBefore != "function" || typeof p.hasChildNodes != "function");
  }, Ei = function(p) {
    return typeof r == "function" && p instanceof r;
  };
  function mt(O, p, E) {
    kn(O, (R) => {
      R.call(e, p, E, Mt);
    });
  }
  const Ai = function(p) {
    let E = null;
    if (mt(N.beforeSanitizeElements, p, null), Pn(p))
      return nt(p), !0;
    const R = me(p.nodeName);
    if (mt(N.uponSanitizeElement, p, {
      tagName: R,
      allowedTags: k
    }), et && p.hasChildNodes() && !Ei(p.firstElementChild) && Ae(/<[/\w!]/g, p.innerHTML) && Ae(/<[/\w!]/g, p.textContent) || p.nodeType === nn.progressingInstruction || et && p.nodeType === nn.comment && Ae(/<[/\w]/g, p.data))
      return nt(p), !0;
    if (!k[R] || Te[R]) {
      if (!Te[R] && Si(R) && (A.tagNameCheck instanceof RegExp && Ae(A.tagNameCheck, R) || A.tagNameCheck instanceof Function && A.tagNameCheck(R)))
        return !1;
      if (Vt && !kt[R]) {
        const ne = _(p) || p.parentNode, De = h(p) || p.childNodes;
        if (De && ne) {
          const _e = De.length;
          for (let Re = _e - 1; Re >= 0; --Re) {
            const gt = D(De[Re], !0);
            gt.__removalCount = (p.__removalCount || 0) + 1, ne.insertBefore(gt, F(p));
          }
        }
      }
      return nt(p), !0;
    }
    return p instanceof s && !Ql(p) || (R === "noscript" || R === "noembed" || R === "noframes") && Ae(/<\/no(script|embed|frames)/i, p.innerHTML) ? (nt(p), !0) : (Je && p.nodeType === nn.text && (E = p.textContent, kn([j, ke, ce], (ne) => {
      E = Jt(E, ne, " ");
    }), p.textContent !== E && (Qt(e.removed, {
      element: p.cloneNode()
    }), p.textContent = E)), mt(N.afterSanitizeElements, p, null), !1);
  }, Ci = function(p, E, R) {
    if (dn && (E === "id" || E === "name") && (R in t || R in Kl))
      return !1;
    if (!(yt && !Qe[E] && Ae(Ee, E))) {
      if (!(Dt && Ae(pe, E))) {
        if (!J[E] || Qe[E]) {
          if (
            // First condition does a very basic check if a) it's basically a valid custom element tagname AND
            // b) if the tagName passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            // and c) if the attribute name passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.attributeNameCheck
            !(Si(p) && (A.tagNameCheck instanceof RegExp && Ae(A.tagNameCheck, p) || A.tagNameCheck instanceof Function && A.tagNameCheck(p)) && (A.attributeNameCheck instanceof RegExp && Ae(A.attributeNameCheck, E) || A.attributeNameCheck instanceof Function && A.attributeNameCheck(E)) || // Alternative, second condition checks if it's an `is`-attribute, AND
            // the value passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            E === "is" && A.allowCustomizedBuiltInElements && (A.tagNameCheck instanceof RegExp && Ae(A.tagNameCheck, R) || A.tagNameCheck instanceof Function && A.tagNameCheck(R)))
          ) return !1;
        } else if (!W[E]) {
          if (!Ae(be, Jt(R, Q, ""))) {
            if (!((E === "src" || E === "xlink:href" || E === "href") && p !== "script" && ys(R, "data:") === 0 && b[p])) {
              if (!(wt && !Ae(ie, Jt(R, Q, "")))) {
                if (R)
                  return !1;
              }
            }
          }
        }
      }
    }
    return !0;
  }, Si = function(p) {
    return p !== "annotation-xml" && Fa(p, se);
  }, Ti = function(p) {
    mt(N.beforeSanitizeAttributes, p, null);
    const {
      attributes: E
    } = p;
    if (!E || Pn(p))
      return;
    const R = {
      attrName: "",
      attrValue: "",
      keepAttr: !0,
      allowedAttributes: J,
      forceKeepAttr: void 0
    };
    let ne = E.length;
    for (; ne--; ) {
      const De = E[ne], {
        name: _e,
        namespaceURI: Re,
        value: gt
      } = De, Yt = me(_e), zn = gt;
      let ye = _e === "value" ? zn : ws(zn);
      if (R.attrName = Yt, R.attrValue = ye, R.keepAttr = !0, R.forceKeepAttr = void 0, mt(N.uponSanitizeAttribute, p, R), ye = R.attrValue, fn && (Yt === "id" || Yt === "name") && (Pt(_e, p), ye = Nn + ye), et && Ae(/((--!?|])>)|<\/(style|title)/i, ye)) {
        Pt(_e, p);
        continue;
      }
      if (R.forceKeepAttr)
        continue;
      if (!R.keepAttr) {
        Pt(_e, p);
        continue;
      }
      if (!ft && Ae(/\/>/i, ye)) {
        Pt(_e, p);
        continue;
      }
      Je && kn([j, ke, ce], (Ii) => {
        ye = Jt(ye, Ii, " ");
      });
      const Bi = me(p.nodeName);
      if (!Ci(Bi, Yt, ye)) {
        Pt(_e, p);
        continue;
      }
      if (g && typeof f == "object" && typeof f.getAttributeType == "function" && !Re)
        switch (f.getAttributeType(Bi, Yt)) {
          case "TrustedHTML": {
            ye = g.createHTML(ye);
            break;
          }
          case "TrustedScriptURL": {
            ye = g.createScriptURL(ye);
            break;
          }
        }
      if (ye !== zn)
        try {
          Re ? p.setAttributeNS(Re, _e, ye) : p.setAttribute(_e, ye), Pn(p) ? nt(p) : wa(e.removed);
        } catch {
          Pt(_e, p);
        }
    }
    mt(N.afterSanitizeAttributes, p, null);
  }, Jl = function O(p) {
    let E = null;
    const R = ki(p);
    for (mt(N.beforeSanitizeShadowDOM, p, null); E = R.nextNode(); )
      mt(N.uponSanitizeShadowNode, E, null), Ai(E), Ti(E), E.content instanceof o && O(E.content);
    mt(N.afterSanitizeShadowDOM, p, null);
  };
  return e.sanitize = function(O) {
    let p = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, E = null, R = null, ne = null, De = null;
    if (Wt = !O, Wt && (O = "<!-->"), typeof O != "string" && !Ei(O))
      if (typeof O.toString == "function") {
        if (O = O.toString(), typeof O != "string")
          throw en("dirty is not a string, aborting");
      } else
        throw en("toString is not a function");
    if (!e.isSupported)
      return O;
    if (Gt || Mn(p), e.removed = [], typeof O == "string" && (St = !1), St) {
      if (O.nodeName) {
        const gt = me(O.nodeName);
        if (!k[gt] || Te[gt])
          throw en("root node is forbidden and cannot be sanitized in-place");
      }
    } else if (O instanceof r)
      E = $i("<!---->"), R = E.ownerDocument.importNode(O, !0), R.nodeType === nn.element && R.nodeName === "BODY" || R.nodeName === "HTML" ? E = R : E.appendChild(R);
    else {
      if (!Ft && !Je && !pt && // eslint-disable-next-line unicorn/prefer-includes
      O.indexOf("<") === -1)
        return g && Nt ? g.createHTML(O) : O;
      if (E = $i(O), !E)
        return Ft ? null : Nt ? y : "";
    }
    E && jt && nt(E.firstChild);
    const _e = ki(St ? O : E);
    for (; ne = _e.nextNode(); )
      Ai(ne), Ti(ne), ne.content instanceof o && Jl(ne.content);
    if (St)
      return O;
    if (Ft) {
      if (qt)
        for (De = I.call(E.ownerDocument); E.firstChild; )
          De.appendChild(E.firstChild);
      else
        De = E;
      return (J.shadowroot || J.shadowrootmode) && (De = M.call(n, De, !0)), De;
    }
    let Re = pt ? E.outerHTML : E.innerHTML;
    return pt && k["!doctype"] && E.ownerDocument && E.ownerDocument.doctype && E.ownerDocument.doctype.name && Ae(Ml, E.ownerDocument.doctype.name) && (Re = "<!DOCTYPE " + E.ownerDocument.doctype.name + `>
` + Re), Je && kn([j, ke, ce], (gt) => {
      Re = Jt(Re, gt, " ");
    }), g && Nt ? g.createHTML(Re) : Re;
  }, e.setConfig = function() {
    let O = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    Mn(O), Gt = !0;
  }, e.clearConfig = function() {
    Mt = null, Gt = !1;
  }, e.isValidAttribute = function(O, p, E) {
    Mt || Mn({});
    const R = me(O), ne = me(p);
    return Ci(R, ne, E);
  }, e.addHook = function(O, p) {
    typeof p == "function" && Qt(N[O], p);
  }, e.removeHook = function(O, p) {
    if (p !== void 0) {
      const E = bs(N[O], p);
      return E === -1 ? void 0 : Ds(N[O], E, 1)[0];
    }
    return wa(N[O]);
  }, e.removeHooks = function(O) {
    N[O] = [];
  }, e.removeAllHooks = function() {
    N = Sa();
  }, e;
}
Pl();
const {
  HtmlTagHydration: uE,
  SvelteComponent: cE,
  add_render_callback: _E,
  append_hydration: dE,
  attr: fE,
  bubble: pE,
  check_outros: hE,
  children: mE,
  claim_component: gE,
  claim_element: vE,
  claim_html_tag: bE,
  claim_space: DE,
  claim_text: yE,
  create_component: wE,
  create_in_transition: FE,
  create_out_transition: $E,
  destroy_component: kE,
  detach: EE,
  element: AE,
  get_svelte_dataset: CE,
  group_outros: SE,
  init: TE,
  insert_hydration: BE,
  listen: IE,
  mount_component: RE,
  run_all: LE,
  safe_not_equal: OE,
  set_data: qE,
  space: NE,
  stop_propagation: ME,
  text: PE,
  toggle_class: zE,
  transition_in: xE,
  transition_out: UE
} = window.__gradio__svelte__internal, { createEventDispatcher: HE, onMount: GE } = window.__gradio__svelte__internal, {
  SvelteComponent: jE,
  append_hydration: VE,
  attr: WE,
  bubble: ZE,
  check_outros: YE,
  children: XE,
  claim_component: KE,
  claim_element: QE,
  claim_space: JE,
  create_animation: e2,
  create_component: t2,
  destroy_component: n2,
  detach: i2,
  element: a2,
  ensure_array_like: l2,
  fix_and_outro_and_destroy_block: o2,
  fix_position: r2,
  group_outros: s2,
  init: u2,
  insert_hydration: c2,
  mount_component: _2,
  noop: d2,
  safe_not_equal: f2,
  set_style: p2,
  space: h2,
  transition_in: m2,
  transition_out: g2,
  update_keyed_each: v2
} = window.__gradio__svelte__internal, {
  SvelteComponent: b2,
  attr: D2,
  children: y2,
  claim_element: w2,
  detach: F2,
  element: $2,
  empty: k2,
  init: E2,
  insert_hydration: A2,
  noop: C2,
  safe_not_equal: S2,
  set_style: T2
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ns,
  append_hydration: z,
  assign: Ms,
  attr: S,
  binding_callbacks: Ps,
  check_outros: zs,
  children: Y,
  claim_component: zl,
  claim_element: x,
  claim_space: de,
  claim_text: Xe,
  create_component: xl,
  destroy_block: Ul,
  destroy_component: Hl,
  destroy_each: Di,
  detach: B,
  element: U,
  empty: ue,
  ensure_array_like: _t,
  get_binding_group_value: xs,
  get_spread_object: Us,
  get_spread_update: Hs,
  get_svelte_dataset: Gl,
  group_outros: Gs,
  init: js,
  init_binding_group_dynamic: jl,
  insert_hydration: G,
  listen: te,
  mount_component: Vl,
  run_all: Ot,
  safe_not_equal: Vs,
  select_option: Ta,
  set_data: dt,
  set_input_value: $e,
  set_style: Ut,
  space: fe,
  stop_propagation: Ws,
  text: Ke,
  to_number: di,
  toggle_class: ve,
  transition_in: sn,
  transition_out: On,
  update_keyed_each: Wl
} = window.__gradio__svelte__internal, { onMount: Zs, tick: An } = window.__gradio__svelte__internal;
function Ba(i, e, t) {
  const n = i.slice();
  return n[62] = e[t], n[64] = t, n;
}
function Ia(i, e, t) {
  const n = i.slice();
  return n[65] = e[t], n[66] = e, n[67] = t, n;
}
function Ra(i, e, t) {
  const n = i.slice();
  return n[74] = e[t], n;
}
function La(i, e, t) {
  const n = i.slice();
  return n[74] = e[t], n;
}
function Oa(i, e, t) {
  const n = i.slice();
  return n[74] = e[t], n;
}
function Jn(i) {
  const e = i.slice(), t = (
    /*prop*/
    e[65].interactive_if
  );
  e[68] = t;
  const n = (
    /*prop*/
    e[65].visible_if
  );
  e[69] = n;
  const a = (
    /*i_condition*/
    e[68] ? (
      /*get_prop_value*/
      e[23](
        /*i_condition*/
        e[68].field
      )
    ) : null
  );
  e[70] = a;
  const o = (
    /*v_condition*/
    e[69] ? (
      /*get_prop_value*/
      e[23](
        /*v_condition*/
        e[69].field
      )
    ) : null
  );
  e[71] = o;
  const l = (
    /*interactive*/
    e[13] && (/*i_condition*/
    e[68] ? (
      /*i_condition*/
      e[68].value !== void 0 ? Array.isArray(
        /*i_condition*/
        e[68].value
      ) ? (
        /*i_condition*/
        e[68].value.includes(
          /*i_parent_value*/
          e[70]
        )
      ) : (
        /*i_parent_value*/
        e[70] === /*i_condition*/
        e[68].value
      ) : (
        /*i_condition*/
        e[68].neq !== void 0 ? (
          /*i_parent_value*/
          e[70] !== /*i_condition*/
          e[68].neq
        ) : !0
      )
    ) : !0)
  );
  e[72] = l;
  const r = (
    /*prop*/
    (e[65].visible ?? !0) && (/*v_condition*/
    e[69] ? (
      /*v_condition*/
      e[69].value !== void 0 ? Array.isArray(
        /*v_condition*/
        e[69].value
      ) ? (
        /*v_condition*/
        e[69].value.includes(
          /*v_parent_value*/
          e[71]
        )
      ) : (
        /*v_parent_value*/
        e[71] === /*v_condition*/
        e[69].value
      ) : (
        /*v_condition*/
        e[69].neq !== void 0 ? (
          /*v_parent_value*/
          e[71] !== /*v_condition*/
          e[69].neq
        ) : !0
      )
    ) : !0)
  );
  return e[73] = r, e;
}
function qa(i) {
  let e, t;
  const n = [
    {
      autoscroll: (
        /*gradio*/
        i[14].autoscroll
      )
    },
    { i18n: (
      /*gradio*/
      i[14].i18n
    ) },
    /*loading_status*/
    i[12]
  ];
  let a = {};
  for (let o = 0; o < n.length; o += 1)
    a = Ms(a, n[o]);
  return e = new hs({ props: a }), e.$on(
    "clear_status",
    /*clear_status_handler*/
    i[31]
  ), {
    c() {
      xl(e.$$.fragment);
    },
    l(o) {
      zl(e.$$.fragment, o);
    },
    m(o, l) {
      Vl(e, o, l), t = !0;
    },
    p(o, l) {
      const r = l[0] & /*gradio, loading_status*/
      20480 ? Hs(n, [
        l[0] & /*gradio*/
        16384 && {
          autoscroll: (
            /*gradio*/
            o[14].autoscroll
          )
        },
        l[0] & /*gradio*/
        16384 && { i18n: (
          /*gradio*/
          o[14].i18n
        ) },
        l[0] & /*loading_status*/
        4096 && Us(
          /*loading_status*/
          o[12]
        )
      ]) : {};
      e.$set(r);
    },
    i(o) {
      t || (sn(e.$$.fragment, o), t = !0);
    },
    o(o) {
      On(e.$$.fragment, o), t = !1;
    },
    d(o) {
      Hl(e, o);
    }
  };
}
function Na(i) {
  let e, t;
  return {
    c() {
      e = U("span"), t = Ke(
        /*label*/
        i[2]
      ), this.h();
    },
    l(n) {
      e = x(n, "SPAN", { class: !0 });
      var a = Y(e);
      t = Xe(
        a,
        /*label*/
        i[2]
      ), a.forEach(B), this.h();
    },
    h() {
      S(e, "class", "label");
    },
    m(n, a) {
      G(n, e, a), z(e, t);
    },
    p(n, a) {
      a[0] & /*label*/
      4 && dt(
        t,
        /*label*/
        n[2]
      );
    },
    d(n) {
      n && B(e);
    }
  };
}
function Ma(i) {
  let e, t = "▼";
  return {
    c() {
      e = U("span"), e.textContent = t, this.h();
    },
    l(n) {
      e = x(n, "SPAN", { class: !0, "data-svelte-h": !0 }), Gl(e) !== "svelte-zp2qne" && (e.textContent = t), this.h();
    },
    h() {
      S(e, "class", "accordion-icon svelte-1bp104d"), Ut(
        e,
        "transform",
        /*open*/
        i[1] ? "rotate(0)" : "rotate(-90deg)"
      );
    },
    m(n, a) {
      G(n, e, a);
    },
    p(n, a) {
      a[0] & /*open*/
      2 && Ut(
        e,
        "transform",
        /*open*/
        n[1] ? "rotate(0)" : "rotate(-90deg)"
      );
    },
    d(n) {
      n && B(e);
    }
  };
}
function Pa(i) {
  let e, t = Array.isArray(
    /*value*/
    i[0]
  ), n = t && za(i);
  return {
    c() {
      e = U("div"), n && n.c(), this.h();
    },
    l(a) {
      e = x(a, "DIV", { class: !0, style: !0 });
      var o = Y(e);
      n && n.l(o), o.forEach(B), this.h();
    },
    h() {
      S(e, "class", "container svelte-1bp104d"), Ut(
        e,
        "--show-group-name",
        /*value*/
        i[0].length > 1 || /*show_group_name_only_one*/
        i[3] && /*value*/
        i[0].length === 1 ? "none" : "1px solid var(--border-color-primary)"
      ), Ut(
        e,
        "--sheet-max-height",
        /*height*/
        i[11] ? `${/*height*/
        i[11]}px` : "none"
      );
    },
    m(a, o) {
      G(a, e, o), n && n.m(e, null);
    },
    p(a, o) {
      o[0] & /*value*/
      1 && (t = Array.isArray(
        /*value*/
        a[0]
      )), t ? n ? n.p(a, o) : (n = za(a), n.c(), n.m(e, null)) : n && (n.d(1), n = null), o[0] & /*value, show_group_name_only_one*/
      9 && Ut(
        e,
        "--show-group-name",
        /*value*/
        a[0].length > 1 || /*show_group_name_only_one*/
        a[3] && /*value*/
        a[0].length === 1 ? "none" : "1px solid var(--border-color-primary)"
      ), o[0] & /*height*/
      2048 && Ut(
        e,
        "--sheet-max-height",
        /*height*/
        a[11] ? `${/*height*/
        a[11]}px` : "none"
      );
    },
    d(a) {
      a && B(e), n && n.d();
    }
  };
}
function za(i) {
  let e = [], t = /* @__PURE__ */ new Map(), n, a = _t(
    /*value*/
    i[0]
  );
  const o = (l) => (
    /*group*/
    l[62].group_name
  );
  for (let l = 0; l < a.length; l += 1) {
    let r = Ba(i, a, l), s = o(r);
    t.set(s, e[l] = tl(s, r));
  }
  return {
    c() {
      for (let l = 0; l < e.length; l += 1)
        e[l].c();
      n = ue();
    },
    l(l) {
      for (let r = 0; r < e.length; r += 1)
        e[r].l(l);
      n = ue();
    },
    m(l, r) {
      for (let s = 0; s < e.length; s += 1)
        e[s] && e[s].m(l, r);
      G(l, n, r);
    },
    p(l, r) {
      r[0] & /*value, interactive, get_prop_value, initialValues, handle_reset_prop, dispatch_update, validationState, validate_prop, sliderElements, handle_dropdown_change, handle_multiselect_change, groupVisibility, toggleGroup, show_group_name_only_one*/
      265789449 && (a = _t(
        /*value*/
        l[0]
      ), e = Wl(e, r, o, 1, l, a, t, n.parentNode, Ul, tl, n, Ba));
    },
    d(l) {
      l && B(n);
      for (let r = 0; r < e.length; r += 1)
        e[r].d(l);
    }
  };
}
function xa(i) {
  let e, t, n = (
    /*group*/
    i[62].group_name + ""
  ), a, o, l, r = (
    /*groupVisibility*/
    i[15][
      /*group*/
      i[62].group_name
    ] ? "−" : "+"
  ), s, u, c;
  function m() {
    return (
      /*click_handler*/
      i[32](
        /*group*/
        i[62]
      )
    );
  }
  return {
    c() {
      e = U("button"), t = U("span"), a = Ke(n), o = fe(), l = U("span"), s = Ke(r), this.h();
    },
    l(d) {
      e = x(d, "BUTTON", { class: !0 });
      var f = Y(e);
      t = x(f, "SPAN", { class: !0 });
      var v = Y(t);
      a = Xe(v, n), v.forEach(B), o = de(f), l = x(f, "SPAN", { class: !0 });
      var D = Y(l);
      s = Xe(D, r), D.forEach(B), f.forEach(B), this.h();
    },
    h() {
      S(t, "class", "group-title"), S(l, "class", "group-toggle-icon"), S(e, "class", "group-header svelte-1bp104d");
    },
    m(d, f) {
      G(d, e, f), z(e, t), z(t, a), z(e, o), z(e, l), z(l, s), u || (c = te(e, "click", m), u = !0);
    },
    p(d, f) {
      i = d, f[0] & /*value*/
      1 && n !== (n = /*group*/
      i[62].group_name + "") && dt(a, n), f[0] & /*groupVisibility, value*/
      32769 && r !== (r = /*groupVisibility*/
      i[15][
        /*group*/
        i[62].group_name
      ] ? "−" : "+") && dt(s, r);
    },
    d(d) {
      d && B(e), u = !1, c();
    }
  };
}
function Ua(i) {
  let e, t = Array.isArray(
    /*group*/
    i[62].properties
  ), n, a = t && Ha(i);
  return {
    c() {
      e = U("div"), a && a.c(), n = fe(), this.h();
    },
    l(o) {
      e = x(o, "DIV", { class: !0 });
      var l = Y(e);
      a && a.l(l), n = de(l), l.forEach(B), this.h();
    },
    h() {
      S(e, "class", "properties-grid svelte-1bp104d");
    },
    m(o, l) {
      G(o, e, l), a && a.m(e, null), z(e, n);
    },
    p(o, l) {
      l[0] & /*value*/
      1 && (t = Array.isArray(
        /*group*/
        o[62].properties
      )), t ? a ? a.p(o, l) : (a = Ha(o), a.c(), a.m(e, n)) : a && (a.d(1), a = null);
    },
    d(o) {
      o && B(e), a && a.d();
    }
  };
}
function Ha(i) {
  let e = [], t = /* @__PURE__ */ new Map(), n, a = _t(
    /*group*/
    i[62].properties
  );
  const o = (l) => (
    /*prop*/
    l[65].name
  );
  for (let l = 0; l < a.length; l += 1) {
    let r = Ia(i, a, l), s = o(r);
    t.set(s, e[l] = el(s, r));
  }
  return {
    c() {
      for (let l = 0; l < e.length; l += 1)
        e[l].c();
      n = ue();
    },
    l(l) {
      for (let r = 0; r < e.length; r += 1)
        e[r].l(l);
      n = ue();
    },
    m(l, r) {
      for (let s = 0; s < e.length; s += 1)
        e[s] && e[s].m(l, r);
      G(l, n, r);
    },
    p(l, r) {
      r[0] & /*interactive, value, get_prop_value, initialValues, handle_reset_prop, dispatch_update, validationState, validate_prop, sliderElements, handle_dropdown_change, handle_multiselect_change*/
      261562369 && (a = _t(
        /*group*/
        l[62].properties
      ), e = Wl(e, r, o, 1, l, a, t, n.parentNode, Ul, el, n, Ia));
    },
    d(l) {
      l && B(n);
      for (let r = 0; r < e.length; r += 1)
        e[r].d(l);
    }
  };
}
function Ga(i) {
  let e, t = (
    /*is_visible*/
    i[73] && ja(i)
  );
  return {
    c() {
      t && t.c(), e = ue();
    },
    l(n) {
      t && t.l(n), e = ue();
    },
    m(n, a) {
      t && t.m(n, a), G(n, e, a);
    },
    p(n, a) {
      /*is_visible*/
      n[73] ? t ? t.p(n, a) : (t = ja(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && B(e), t && t.d(n);
    }
  };
}
function ja(i) {
  let e, t, n, a = (
    /*prop*/
    i[65].label + ""
  ), o, l, r, s, u, c, m, d = (
    /*prop*/
    i[65].help && Va(i)
  );
  function f(F, h) {
    if (
      /*prop*/
      F[65].component === "string"
    ) return iu;
    if (
      /*prop*/
      F[65].component === "password"
    ) return nu;
    if (
      /*prop*/
      F[65].component === "checkbox"
    ) return tu;
    if (
      /*prop*/
      F[65].component === "number_integer" || /*prop*/
      F[65].component === "number_float"
    ) return eu;
    if (
      /*prop*/
      F[65].component === "slider"
    ) return Js;
    if (
      /*prop*/
      F[65].component === "colorpicker"
    ) return Qs;
    if (
      /*prop*/
      F[65].component === "dropdown"
    ) return Ks;
    if (
      /*prop*/
      F[65].component === "radio"
    ) return Xs;
    if (
      /*prop*/
      F[65].component === "multiselect_checkbox"
    ) return Ys;
  }
  let v = f(i), D = v && v(i), w = (
    /*prop*/
    i[65].component !== "checkbox" && Ja(i)
  );
  return {
    c() {
      e = U("label"), t = U("div"), n = U("span"), o = Ke(a), l = fe(), d && d.c(), s = fe(), u = U("div"), D && D.c(), c = fe(), w && w.c(), m = fe(), this.h();
    },
    l(F) {
      e = x(F, "LABEL", { class: !0, for: !0 });
      var h = Y(e);
      t = x(h, "DIV", { class: !0 });
      var _ = Y(t);
      n = x(_, "SPAN", {});
      var g = Y(n);
      o = Xe(g, a), g.forEach(B), l = de(_), d && d.l(_), _.forEach(B), h.forEach(B), s = de(F), u = x(F, "DIV", { class: !0 });
      var y = Y(u);
      D && D.l(y), c = de(y), w && w.l(y), m = de(y), y.forEach(B), this.h();
    },
    h() {
      S(t, "class", "prop-label-wrapper svelte-1bp104d"), S(e, "class", "prop-label svelte-1bp104d"), S(e, "for", r = /*prop*/
      i[65].name), S(u, "class", "prop-control svelte-1bp104d");
    },
    m(F, h) {
      G(F, e, h), z(e, t), z(t, n), z(n, o), z(t, l), d && d.m(t, null), G(F, s, h), G(F, u, h), D && D.m(u, null), z(u, c), w && w.m(u, null), z(u, m);
    },
    p(F, h) {
      h[0] & /*value*/
      1 && a !== (a = /*prop*/
      F[65].label + "") && dt(o, a), /*prop*/
      F[65].help ? d ? d.p(F, h) : (d = Va(F), d.c(), d.m(t, null)) : d && (d.d(1), d = null), h[0] & /*value*/
      1 && r !== (r = /*prop*/
      F[65].name) && S(e, "for", r), v === (v = f(F)) && D ? D.p(F, h) : (D && D.d(1), D = v && v(F), D && (D.c(), D.m(u, c))), /*prop*/
      F[65].component !== "checkbox" ? w ? w.p(F, h) : (w = Ja(F), w.c(), w.m(u, m)) : w && (w.d(1), w = null);
    },
    d(F) {
      F && (B(e), B(s), B(u)), d && d.d(), D && D.d(), w && w.d();
    }
  };
}
function Va(i) {
  let e, t, n = "?", a, o, l = (
    /*prop*/
    i[65].help + ""
  ), r;
  return {
    c() {
      e = U("div"), t = U("span"), t.textContent = n, a = fe(), o = U("span"), r = Ke(l), this.h();
    },
    l(s) {
      e = x(s, "DIV", { class: !0 });
      var u = Y(e);
      t = x(u, "SPAN", { class: !0, "data-svelte-h": !0 }), Gl(t) !== "svelte-fzek5l" && (t.textContent = n), a = de(u), o = x(u, "SPAN", { class: !0 });
      var c = Y(o);
      r = Xe(c, l), c.forEach(B), u.forEach(B), this.h();
    },
    h() {
      S(t, "class", "tooltip-icon svelte-1bp104d"), S(o, "class", "tooltip-text svelte-1bp104d"), S(e, "class", "tooltip-container svelte-1bp104d");
    },
    m(s, u) {
      G(s, e, u), z(e, t), z(e, a), z(e, o), z(o, r);
    },
    p(s, u) {
      u[0] & /*value*/
      1 && l !== (l = /*prop*/
      s[65].help + "") && dt(r, l);
    },
    d(s) {
      s && B(e);
    }
  };
}
function Ys(i) {
  let e, t = Array.isArray(
    /*prop*/
    i[65].choices
  ), n = t && Wa(i);
  return {
    c() {
      e = U("div"), n && n.c(), this.h();
    },
    l(a) {
      e = x(a, "DIV", { class: !0 });
      var o = Y(e);
      n && n.l(o), o.forEach(B), this.h();
    },
    h() {
      S(e, "class", "multiselect-group svelte-1bp104d"), ve(e, "disabled", !/*is_interactive*/
      i[72]);
    },
    m(a, o) {
      G(a, e, o), n && n.m(e, null);
    },
    p(a, o) {
      o[0] & /*value*/
      1 && (t = Array.isArray(
        /*prop*/
        a[65].choices
      )), t ? n ? n.p(a, o) : (n = Wa(a), n.c(), n.m(e, null)) : n && (n.d(1), n = null), o[0] & /*interactive, value, get_prop_value*/
      8396801 && ve(e, "disabled", !/*is_interactive*/
      a[72]);
    },
    d(a) {
      a && B(e), n && n.d();
    }
  };
}
function Xs(i) {
  let e, t = Array.isArray(
    /*prop*/
    i[65].choices
  ), n, a, o = t && Ya(i);
  function l() {
    return (
      /*change_handler_7*/
      i[53](
        /*prop*/
        i[65]
      )
    );
  }
  return {
    c() {
      e = U("div"), o && o.c(), this.h();
    },
    l(r) {
      e = x(r, "DIV", { class: !0 });
      var s = Y(e);
      o && o.l(s), s.forEach(B), this.h();
    },
    h() {
      S(e, "class", "radio-group svelte-1bp104d"), ve(e, "disabled", !/*is_interactive*/
      i[72]);
    },
    m(r, s) {
      G(r, e, s), o && o.m(e, null), n || (a = te(e, "change", l), n = !0);
    },
    p(r, s) {
      i = r, s[0] & /*value*/
      1 && (t = Array.isArray(
        /*prop*/
        i[65].choices
      )), t ? o ? o.p(i, s) : (o = Ya(i), o.c(), o.m(e, null)) : o && (o.d(1), o = null), s[0] & /*interactive, value, get_prop_value*/
      8396801 && ve(e, "disabled", !/*is_interactive*/
      i[72]);
    },
    d(r) {
      r && B(e), o && o.d(), n = !1, a();
    }
  };
}
function Ks(i) {
  let e, t, n = Array.isArray(
    /*prop*/
    i[65].choices
  ), a, o, l, r, s, u, c = n && Ka(i);
  function m(...d) {
    return (
      /*change_handler_6*/
      i[50](
        /*prop*/
        i[65],
        ...d
      )
    );
  }
  return {
    c() {
      e = U("div"), t = U("select"), c && c.c(), l = fe(), r = U("div"), this.h();
    },
    l(d) {
      e = x(d, "DIV", { class: !0 });
      var f = Y(e);
      t = x(f, "SELECT", { class: !0 });
      var v = Y(t);
      c && c.l(v), v.forEach(B), l = de(f), r = x(f, "DIV", { class: !0 }), Y(r).forEach(B), f.forEach(B), this.h();
    },
    h() {
      t.disabled = a = !/*is_interactive*/
      i[72], S(t, "class", "svelte-1bp104d"), S(r, "class", "dropdown-arrow-icon svelte-1bp104d"), S(e, "class", "dropdown-wrapper svelte-1bp104d"), ve(e, "disabled", !/*is_interactive*/
      i[72]);
    },
    m(d, f) {
      G(d, e, f), z(e, t), c && c.m(t, null), Ta(
        t,
        /*prop*/
        i[65].value
      ), z(e, l), z(e, r), s || (u = te(t, "change", m), s = !0);
    },
    p(d, f) {
      i = d, f[0] & /*value*/
      1 && (n = Array.isArray(
        /*prop*/
        i[65].choices
      )), n ? c ? c.p(i, f) : (c = Ka(i), c.c(), c.m(t, null)) : c && (c.d(1), c = null), f[0] & /*interactive, value*/
      8193 && a !== (a = !/*is_interactive*/
      i[72]) && (t.disabled = a), f[0] & /*value*/
      1 && o !== (o = /*prop*/
      i[65].value) && Ta(
        t,
        /*prop*/
        i[65].value
      ), f[0] & /*interactive, value, get_prop_value*/
      8396801 && ve(e, "disabled", !/*is_interactive*/
      i[72]);
    },
    d(d) {
      d && B(e), c && c.d(), s = !1, u();
    }
  };
}
function Qs(i) {
  let e, t, n, a, o, l = (
    /*prop*/
    i[65].value + ""
  ), r, s, u;
  function c() {
    i[48].call(
      t,
      /*each_value_1*/
      i[66],
      /*prop_index*/
      i[67]
    );
  }
  function m() {
    return (
      /*change_handler_5*/
      i[49](
        /*prop*/
        i[65]
      )
    );
  }
  return {
    c() {
      e = U("div"), t = U("input"), a = fe(), o = U("span"), r = Ke(l), this.h();
    },
    l(d) {
      e = x(d, "DIV", { class: !0 });
      var f = Y(e);
      t = x(f, "INPUT", { type: !0, class: !0 }), a = de(f), o = x(f, "SPAN", { class: !0 });
      var v = Y(o);
      r = Xe(v, l), v.forEach(B), f.forEach(B), this.h();
    },
    h() {
      S(t, "type", "color"), S(t, "class", "color-picker-input svelte-1bp104d"), t.disabled = n = !/*is_interactive*/
      i[72], S(o, "class", "color-picker-value svelte-1bp104d"), S(e, "class", "color-picker-container svelte-1bp104d"), ve(e, "disabled", !/*is_interactive*/
      i[72]);
    },
    m(d, f) {
      G(d, e, f), z(e, t), $e(
        t,
        /*prop*/
        i[65].value
      ), z(e, a), z(e, o), z(o, r), s || (u = [
        te(t, "input", c),
        te(t, "change", m)
      ], s = !0);
    },
    p(d, f) {
      i = d, f[0] & /*interactive, value*/
      8193 && n !== (n = !/*is_interactive*/
      i[72]) && (t.disabled = n), f[0] & /*value*/
      1 && $e(
        t,
        /*prop*/
        i[65].value
      ), f[0] & /*value*/
      1 && l !== (l = /*prop*/
      i[65].value + "") && dt(r, l), f[0] & /*interactive, value, get_prop_value*/
      8396801 && ve(e, "disabled", !/*is_interactive*/
      i[72]);
    },
    d(d) {
      d && B(e), s = !1, Ot(u);
    }
  };
}
function Js(i) {
  let e, t, n, a, o, l, r = (
    /*prop*/
    i[65]
  ), s, u, c = (
    /*prop*/
    i[65].value + ""
  ), m, d, f;
  function v() {
    i[44].call(
      t,
      /*each_value_1*/
      i[66],
      /*prop_index*/
      i[67]
    );
  }
  const D = () => (
    /*input_binding*/
    i[45](t, r)
  ), w = () => (
    /*input_binding*/
    i[45](null, r)
  );
  function F() {
    return (
      /*input_handler_3*/
      i[46](
        /*prop*/
        i[65]
      )
    );
  }
  function h() {
    return (
      /*change_handler_4*/
      i[47](
        /*prop*/
        i[65]
      )
    );
  }
  return {
    c() {
      e = U("div"), t = U("input"), s = fe(), u = U("span"), m = Ke(c), this.h();
    },
    l(_) {
      e = x(_, "DIV", { class: !0 });
      var g = Y(e);
      t = x(g, "INPUT", {
        type: !0,
        min: !0,
        max: !0,
        step: !0,
        class: !0
      }), s = de(g), u = x(g, "SPAN", { class: !0 });
      var y = Y(u);
      m = Xe(y, c), y.forEach(B), g.forEach(B), this.h();
    },
    h() {
      S(t, "type", "range"), S(t, "min", n = /*prop*/
      i[65].minimum), S(t, "max", a = /*prop*/
      i[65].maximum), S(t, "step", o = /*prop*/
      i[65].step || 1), t.disabled = l = !/*is_interactive*/
      i[72], S(t, "class", "svelte-1bp104d"), S(u, "class", "slider-value svelte-1bp104d"), S(e, "class", "slider-container svelte-1bp104d"), ve(e, "disabled", !/*is_interactive*/
      i[72]);
    },
    m(_, g) {
      G(_, e, g), z(e, t), $e(
        t,
        /*prop*/
        i[65].value
      ), D(), z(e, s), z(e, u), z(u, m), d || (f = [
        te(t, "change", v),
        te(t, "input", v),
        te(t, "input", F),
        te(t, "change", h)
      ], d = !0);
    },
    p(_, g) {
      i = _, g[0] & /*value*/
      1 && n !== (n = /*prop*/
      i[65].minimum) && S(t, "min", n), g[0] & /*value*/
      1 && a !== (a = /*prop*/
      i[65].maximum) && S(t, "max", a), g[0] & /*value*/
      1 && o !== (o = /*prop*/
      i[65].step || 1) && S(t, "step", o), g[0] & /*interactive, value*/
      8193 && l !== (l = !/*is_interactive*/
      i[72]) && (t.disabled = l), g[0] & /*value*/
      1 && $e(
        t,
        /*prop*/
        i[65].value
      ), r !== /*prop*/
      i[65] && (w(), r = /*prop*/
      i[65], D()), g[0] & /*value*/
      1 && c !== (c = /*prop*/
      i[65].value + "") && dt(m, c), g[0] & /*interactive, value, get_prop_value*/
      8396801 && ve(e, "disabled", !/*is_interactive*/
      i[72]);
    },
    d(_) {
      _ && B(e), w(), d = !1, Ot(f);
    }
  };
}
function eu(i) {
  let e, t, n, a, o;
  function l() {
    i[41].call(
      e,
      /*each_value_1*/
      i[66],
      /*prop_index*/
      i[67]
    );
  }
  function r() {
    return (
      /*change_handler_3*/
      i[42](
        /*prop*/
        i[65]
      )
    );
  }
  function s() {
    return (
      /*input_handler_2*/
      i[43](
        /*prop*/
        i[65]
      )
    );
  }
  return {
    c() {
      e = U("input"), this.h();
    },
    l(u) {
      e = x(u, "INPUT", { type: !0, step: !0, class: !0 }), this.h();
    },
    h() {
      S(e, "type", "number"), S(e, "step", t = /*prop*/
      i[65].step || 1), e.disabled = n = !/*is_interactive*/
      i[72], S(e, "class", "svelte-1bp104d"), ve(
        e,
        "invalid",
        /*validationState*/
        i[17][
          /*prop*/
          i[65].name
        ] === !1
      ), ve(e, "disabled", !/*is_interactive*/
      i[72]);
    },
    m(u, c) {
      G(u, e, c), $e(
        e,
        /*prop*/
        i[65].value
      ), a || (o = [
        te(e, "input", l),
        te(e, "change", r),
        te(e, "input", s)
      ], a = !0);
    },
    p(u, c) {
      i = u, c[0] & /*value*/
      1 && t !== (t = /*prop*/
      i[65].step || 1) && S(e, "step", t), c[0] & /*interactive, value*/
      8193 && n !== (n = !/*is_interactive*/
      i[72]) && (e.disabled = n), c[0] & /*value*/
      1 && di(e.value) !== /*prop*/
      i[65].value && $e(
        e,
        /*prop*/
        i[65].value
      ), c[0] & /*validationState, value*/
      131073 && ve(
        e,
        "invalid",
        /*validationState*/
        i[17][
          /*prop*/
          i[65].name
        ] === !1
      ), c[0] & /*interactive, value, get_prop_value*/
      8396801 && ve(e, "disabled", !/*is_interactive*/
      i[72]);
    },
    d(u) {
      u && B(e), a = !1, Ot(o);
    }
  };
}
function tu(i) {
  let e, t, n, a;
  function o() {
    i[39].call(
      e,
      /*each_value_1*/
      i[66],
      /*prop_index*/
      i[67]
    );
  }
  function l() {
    return (
      /*change_handler_2*/
      i[40](
        /*prop*/
        i[65]
      )
    );
  }
  return {
    c() {
      e = U("input"), this.h();
    },
    l(r) {
      e = x(r, "INPUT", { type: !0, class: !0 }), this.h();
    },
    h() {
      S(e, "type", "checkbox"), e.disabled = t = !/*is_interactive*/
      i[72], S(e, "class", "svelte-1bp104d");
    },
    m(r, s) {
      G(r, e, s), e.checked = /*prop*/
      i[65].value, n || (a = [
        te(e, "change", o),
        te(e, "change", l)
      ], n = !0);
    },
    p(r, s) {
      i = r, s[0] & /*interactive, value*/
      8193 && t !== (t = !/*is_interactive*/
      i[72]) && (e.disabled = t), s[0] & /*value*/
      1 && (e.checked = /*prop*/
      i[65].value);
    },
    d(r) {
      r && B(e), n = !1, Ot(a);
    }
  };
}
function nu(i) {
  let e, t, n, a;
  function o() {
    i[36].call(
      e,
      /*each_value_1*/
      i[66],
      /*prop_index*/
      i[67]
    );
  }
  function l() {
    return (
      /*change_handler_1*/
      i[37](
        /*prop*/
        i[65]
      )
    );
  }
  function r() {
    return (
      /*input_handler_1*/
      i[38](
        /*prop*/
        i[65]
      )
    );
  }
  return {
    c() {
      e = U("input"), this.h();
    },
    l(s) {
      e = x(s, "INPUT", { type: !0, class: !0 }), this.h();
    },
    h() {
      S(e, "type", "password"), e.disabled = t = !/*is_interactive*/
      i[72], S(e, "class", "svelte-1bp104d");
    },
    m(s, u) {
      G(s, e, u), $e(
        e,
        /*prop*/
        i[65].value
      ), n || (a = [
        te(e, "input", o),
        te(e, "change", l),
        te(e, "input", r)
      ], n = !0);
    },
    p(s, u) {
      i = s, u[0] & /*interactive, value*/
      8193 && t !== (t = !/*is_interactive*/
      i[72]) && (e.disabled = t), u[0] & /*value*/
      1 && e.value !== /*prop*/
      i[65].value && $e(
        e,
        /*prop*/
        i[65].value
      );
    },
    d(s) {
      s && B(e), n = !1, Ot(a);
    }
  };
}
function iu(i) {
  let e, t, n, a;
  function o() {
    i[33].call(
      e,
      /*each_value_1*/
      i[66],
      /*prop_index*/
      i[67]
    );
  }
  function l() {
    return (
      /*change_handler*/
      i[34](
        /*prop*/
        i[65]
      )
    );
  }
  function r() {
    return (
      /*input_handler*/
      i[35](
        /*prop*/
        i[65]
      )
    );
  }
  return {
    c() {
      e = U("input"), this.h();
    },
    l(s) {
      e = x(s, "INPUT", { type: !0, class: !0 }), this.h();
    },
    h() {
      S(e, "type", "text"), e.disabled = t = !/*is_interactive*/
      i[72], S(e, "class", "svelte-1bp104d");
    },
    m(s, u) {
      G(s, e, u), $e(
        e,
        /*prop*/
        i[65].value
      ), n || (a = [
        te(e, "input", o),
        te(e, "change", l),
        te(e, "input", r)
      ], n = !0);
    },
    p(s, u) {
      i = s, u[0] & /*interactive, value*/
      8193 && t !== (t = !/*is_interactive*/
      i[72]) && (e.disabled = t), u[0] & /*value*/
      1 && e.value !== /*prop*/
      i[65].value && $e(
        e,
        /*prop*/
        i[65].value
      );
    },
    d(s) {
      s && B(e), n = !1, Ot(a);
    }
  };
}
function Wa(i) {
  let e, t = _t(
    /*prop*/
    i[65].choices
  ), n = [];
  for (let a = 0; a < t.length; a += 1)
    n[a] = Za(Ra(i, t, a));
  return {
    c() {
      for (let a = 0; a < n.length; a += 1)
        n[a].c();
      e = ue();
    },
    l(a) {
      for (let o = 0; o < n.length; o += 1)
        n[o].l(a);
      e = ue();
    },
    m(a, o) {
      for (let l = 0; l < n.length; l += 1)
        n[l] && n[l].m(a, o);
      G(a, e, o);
    },
    p(a, o) {
      if (o[0] & /*value, interactive, get_prop_value, handle_multiselect_change*/
      75505665) {
        t = _t(
          /*prop*/
          a[65].choices
        );
        let l;
        for (l = 0; l < t.length; l += 1) {
          const r = Ra(a, t, l);
          n[l] ? n[l].p(r, o) : (n[l] = Za(r), n[l].c(), n[l].m(e.parentNode, e));
        }
        for (; l < n.length; l += 1)
          n[l].d(1);
        n.length = t.length;
      }
    },
    d(a) {
      a && B(e), Di(n, a);
    }
  };
}
function Za(i) {
  let e, t, n, a, o = !1, l, r, s, u = (
    /*choice*/
    i[74] + ""
  ), c, m, d, f, v, D;
  function w() {
    i[54].call(
      t,
      /*each_value_1*/
      i[66],
      /*prop_index*/
      i[67],
      /*group_index*/
      i[64]
    );
  }
  return f = jl(
    /*$$binding_groups*/
    i[52][0],
    [
      /*prop_index*/
      i[67],
      /*group_index*/
      i[64]
    ]
  ), {
    c() {
      e = U("div"), t = U("input"), r = fe(), s = U("label"), c = Ke(u), d = fe(), this.h();
    },
    l(F) {
      e = x(F, "DIV", { class: !0 });
      var h = Y(e);
      t = x(h, "INPUT", { type: !0, id: !0, class: !0 }), r = de(h), s = x(h, "LABEL", { for: !0, class: !0 });
      var _ = Y(s);
      c = Xe(_, u), _.forEach(B), d = de(h), h.forEach(B), this.h();
    },
    h() {
      S(t, "type", "checkbox"), S(t, "id", n = /*prop*/
      i[65].name + "-" + /*choice*/
      i[74]), t.__value = a = /*choice*/
      i[74], $e(t, t.__value), t.disabled = l = !/*is_interactive*/
      i[72], S(t, "class", "svelte-1bp104d"), S(s, "for", m = /*prop*/
      i[65].name + "-" + /*choice*/
      i[74]), S(s, "class", "svelte-1bp104d"), S(e, "class", "multiselect-item svelte-1bp104d"), f.p(t);
    },
    m(F, h) {
      G(F, e, h), z(e, t), t.checked = ~/*prop*/
      (i[65].value || []).indexOf(t.__value), z(e, r), z(e, s), z(s, c), z(e, d), v || (D = [
        te(t, "change", w),
        te(
          t,
          "change",
          /*change_handler_8*/
          i[55]
        )
      ], v = !0);
    },
    p(F, h) {
      i = F, h[0] & /*value*/
      1 && n !== (n = /*prop*/
      i[65].name + "-" + /*choice*/
      i[74]) && S(t, "id", n), h[0] & /*value*/
      1 && a !== (a = /*choice*/
      i[74]) && (t.__value = a, $e(t, t.__value), o = !0), h[0] & /*interactive, value*/
      8193 && l !== (l = !/*is_interactive*/
      i[72]) && (t.disabled = l), (o || h[0] & /*value*/
      1) && (t.checked = ~/*prop*/
      (i[65].value || []).indexOf(t.__value)), h[0] & /*value*/
      1 && u !== (u = /*choice*/
      i[74] + "") && dt(c, u), h[0] & /*value*/
      1 && m !== (m = /*prop*/
      i[65].name + "-" + /*choice*/
      i[74]) && S(s, "for", m), h[0] & /*value*/
      1 && f.u([
        /*prop_index*/
        i[67],
        /*group_index*/
        i[64]
      ]);
    },
    d(F) {
      F && B(e), f.r(), v = !1, Ot(D);
    }
  };
}
function Ya(i) {
  let e, t = _t(
    /*prop*/
    i[65].choices
  ), n = [];
  for (let a = 0; a < t.length; a += 1)
    n[a] = Xa(La(i, t, a));
  return {
    c() {
      for (let a = 0; a < n.length; a += 1)
        n[a].c();
      e = ue();
    },
    l(a) {
      for (let o = 0; o < n.length; o += 1)
        n[o].l(a);
      e = ue();
    },
    m(a, o) {
      for (let l = 0; l < n.length; l += 1)
        n[l] && n[l].m(a, o);
      G(a, e, o);
    },
    p(a, o) {
      if (o[0] & /*value, interactive, get_prop_value*/
      8396801) {
        t = _t(
          /*prop*/
          a[65].choices
        );
        let l;
        for (l = 0; l < t.length; l += 1) {
          const r = La(a, t, l);
          n[l] ? n[l].p(r, o) : (n[l] = Xa(r), n[l].c(), n[l].m(e.parentNode, e));
        }
        for (; l < n.length; l += 1)
          n[l].d(1);
        n.length = t.length;
      }
    },
    d(a) {
      a && B(e), Di(n, a);
    }
  };
}
function Xa(i) {
  let e, t, n, a, o, l = !1, r, s, u, c = (
    /*choice*/
    i[74] + ""
  ), m, d, f, v, D, w;
  function F() {
    i[51].call(
      t,
      /*each_value_1*/
      i[66],
      /*prop_index*/
      i[67]
    );
  }
  return v = jl(
    /*$$binding_groups*/
    i[52][0],
    [
      /*prop_index*/
      i[67],
      /*group_index*/
      i[64]
    ]
  ), {
    c() {
      e = U("div"), t = U("input"), s = fe(), u = U("label"), m = Ke(c), f = fe(), this.h();
    },
    l(h) {
      e = x(h, "DIV", { class: !0 });
      var _ = Y(e);
      t = x(_, "INPUT", {
        type: !0,
        id: !0,
        name: !0,
        class: !0
      }), s = de(_), u = x(_, "LABEL", { for: !0, class: !0 });
      var g = Y(u);
      m = Xe(g, c), g.forEach(B), f = de(_), _.forEach(B), this.h();
    },
    h() {
      S(t, "type", "radio"), S(t, "id", n = /*prop*/
      i[65].name + "-" + /*choice*/
      i[74]), S(t, "name", a = /*prop*/
      i[65].name), t.__value = o = /*choice*/
      i[74], $e(t, t.__value), t.disabled = r = !/*is_interactive*/
      i[72], S(t, "class", "svelte-1bp104d"), S(u, "for", d = /*prop*/
      i[65].name + "-" + /*choice*/
      i[74]), S(u, "class", "svelte-1bp104d"), S(e, "class", "radio-item svelte-1bp104d"), v.p(t);
    },
    m(h, _) {
      G(h, e, _), z(e, t), t.checked = t.__value === /*prop*/
      i[65].value, z(e, s), z(e, u), z(u, m), z(e, f), D || (w = te(t, "change", F), D = !0);
    },
    p(h, _) {
      i = h, _[0] & /*value*/
      1 && n !== (n = /*prop*/
      i[65].name + "-" + /*choice*/
      i[74]) && S(t, "id", n), _[0] & /*value*/
      1 && a !== (a = /*prop*/
      i[65].name) && S(t, "name", a), _[0] & /*value*/
      1 && o !== (o = /*choice*/
      i[74]) && (t.__value = o, $e(t, t.__value), l = !0), _[0] & /*interactive, value*/
      8193 && r !== (r = !/*is_interactive*/
      i[72]) && (t.disabled = r), (l || _[0] & /*value*/
      1) && (t.checked = t.__value === /*prop*/
      i[65].value), _[0] & /*value*/
      1 && c !== (c = /*choice*/
      i[74] + "") && dt(m, c), _[0] & /*value*/
      1 && d !== (d = /*prop*/
      i[65].name + "-" + /*choice*/
      i[74]) && S(u, "for", d), _[0] & /*value*/
      1 && v.u([
        /*prop_index*/
        i[67],
        /*group_index*/
        i[64]
      ]);
    },
    d(h) {
      h && B(e), v.r(), D = !1, w();
    }
  };
}
function Ka(i) {
  let e, t = _t(
    /*prop*/
    i[65].choices
  ), n = [];
  for (let a = 0; a < t.length; a += 1)
    n[a] = Qa(Oa(i, t, a));
  return {
    c() {
      for (let a = 0; a < n.length; a += 1)
        n[a].c();
      e = ue();
    },
    l(a) {
      for (let o = 0; o < n.length; o += 1)
        n[o].l(a);
      e = ue();
    },
    m(a, o) {
      for (let l = 0; l < n.length; l += 1)
        n[l] && n[l].m(a, o);
      G(a, e, o);
    },
    p(a, o) {
      if (o[0] & /*value*/
      1) {
        t = _t(
          /*prop*/
          a[65].choices
        );
        let l;
        for (l = 0; l < t.length; l += 1) {
          const r = Oa(a, t, l);
          n[l] ? n[l].p(r, o) : (n[l] = Qa(r), n[l].c(), n[l].m(e.parentNode, e));
        }
        for (; l < n.length; l += 1)
          n[l].d(1);
        n.length = t.length;
      }
    },
    d(a) {
      a && B(e), Di(n, a);
    }
  };
}
function Qa(i) {
  let e, t = (
    /*choice*/
    i[74] + ""
  ), n, a, o, l;
  return {
    c() {
      e = U("option"), n = Ke(t), a = fe(), this.h();
    },
    l(r) {
      e = x(r, "OPTION", { class: !0 });
      var s = Y(e);
      n = Xe(s, t), a = de(s), s.forEach(B), this.h();
    },
    h() {
      e.__value = o = /*choice*/
      i[74], $e(e, e.__value), e.selected = l = /*prop*/
      i[65].value === /*choice*/
      i[74], S(e, "class", "svelte-1bp104d");
    },
    m(r, s) {
      G(r, e, s), z(e, n), z(e, a);
    },
    p(r, s) {
      s[0] & /*value*/
      1 && t !== (t = /*choice*/
      r[74] + "") && dt(n, t), s[0] & /*value*/
      1 && o !== (o = /*choice*/
      r[74]) && (e.__value = o, $e(e, e.__value)), s[0] & /*value*/
      1 && l !== (l = /*prop*/
      r[65].value === /*choice*/
      r[74]) && (e.selected = l);
    },
    d(r) {
      r && B(e);
    }
  };
}
function Ja(i) {
  let e, t, n, a, o;
  function l() {
    return (
      /*click_handler_1*/
      i[56](
        /*prop*/
        i[65]
      )
    );
  }
  return {
    c() {
      e = U("button"), t = Ke("↺"), this.h();
    },
    l(r) {
      e = x(r, "BUTTON", { class: !0, title: !0 });
      var s = Y(e);
      t = Xe(s, "↺"), s.forEach(B), this.h();
    },
    h() {
      S(e, "class", "reset-button-prop svelte-1bp104d"), S(e, "title", "Reset to default"), e.disabled = n = !/*is_interactive*/
      i[72], ve(
        e,
        "visible",
        /*initialValues*/
        i[18][
          /*prop*/
          i[65].name
        ] !== /*prop*/
        i[65].value
      );
    },
    m(r, s) {
      G(r, e, s), z(e, t), a || (o = te(e, "click", Ws(l)), a = !0);
    },
    p(r, s) {
      i = r, s[0] & /*interactive, value*/
      8193 && n !== (n = !/*is_interactive*/
      i[72]) && (e.disabled = n), s[0] & /*initialValues, value*/
      262145 && ve(
        e,
        "visible",
        /*initialValues*/
        i[18][
          /*prop*/
          i[65].name
        ] !== /*prop*/
        i[65].value
      );
    },
    d(r) {
      r && B(e), a = !1, o();
    }
  };
}
function el(i, e) {
  let t, n, a = (
    /*prop*/
    (e[65].visible ?? !0) && Ga(Jn(e))
  );
  return {
    key: i,
    first: null,
    c() {
      t = ue(), a && a.c(), n = ue(), this.h();
    },
    l(o) {
      t = ue(), a && a.l(o), n = ue(), this.h();
    },
    h() {
      this.first = t;
    },
    m(o, l) {
      G(o, t, l), a && a.m(o, l), G(o, n, l);
    },
    p(o, l) {
      e = o, /*prop*/
      e[65].visible ?? !0 ? a ? a.p(Jn(e), l) : (a = Ga(Jn(e)), a.c(), a.m(n.parentNode, n)) : a && (a.d(1), a = null);
    },
    d(o) {
      o && (B(t), B(n)), a && a.d(o);
    }
  };
}
function tl(i, e) {
  let t, n, a, o = (
    /*value*/
    (e[0].length > 1 || /*show_group_name_only_one*/
    e[3] && /*value*/
    e[0].length === 1) && xa(e)
  ), l = (
    /*groupVisibility*/
    e[15][
      /*group*/
      e[62].group_name
    ] && Ua(e)
  );
  return {
    key: i,
    first: null,
    c() {
      t = ue(), o && o.c(), n = fe(), l && l.c(), a = ue(), this.h();
    },
    l(r) {
      t = ue(), o && o.l(r), n = de(r), l && l.l(r), a = ue(), this.h();
    },
    h() {
      this.first = t;
    },
    m(r, s) {
      G(r, t, s), o && o.m(r, s), G(r, n, s), l && l.m(r, s), G(r, a, s);
    },
    p(r, s) {
      e = r, /*value*/
      e[0].length > 1 || /*show_group_name_only_one*/
      e[3] && /*value*/
      e[0].length === 1 ? o ? o.p(e, s) : (o = xa(e), o.c(), o.m(n.parentNode, n)) : o && (o.d(1), o = null), /*groupVisibility*/
      e[15][
        /*group*/
        e[62].group_name
      ] ? l ? l.p(e, s) : (l = Ua(e), l.c(), l.m(a.parentNode, a)) : l && (l.d(1), l = null);
    },
    d(r) {
      r && (B(t), B(n), B(a)), o && o.d(r), l && l.d(r);
    }
  };
}
function au(i) {
  let e, t, n, a, o, l, r, s, u = (
    /*loading_status*/
    i[12] && qa(i)
  ), c = (
    /*label*/
    i[2] && Na(i)
  ), m = !/*disable_accordion*/
  i[4] && Ma(i), d = (
    /*open*/
    i[1] && Pa(i)
  );
  return {
    c() {
      u && u.c(), e = fe(), t = U("button"), c && c.c(), n = fe(), m && m.c(), a = fe(), o = U("div"), d && d.c(), this.h();
    },
    l(f) {
      u && u.l(f), e = de(f), t = x(f, "BUTTON", { class: !0 });
      var v = Y(t);
      c && c.l(v), n = de(v), m && m.l(v), v.forEach(B), a = de(f), o = x(f, "DIV", { class: !0 });
      var D = Y(o);
      d && d.l(D), D.forEach(B), this.h();
    },
    h() {
      S(t, "class", "accordion-header svelte-1bp104d"), t.disabled = /*disable_accordion*/
      i[4], S(o, "class", "content-wrapper svelte-1bp104d"), ve(o, "closed", !/*open*/
      i[1]);
    },
    m(f, v) {
      u && u.m(f, v), G(f, e, v), G(f, t, v), c && c.m(t, null), z(t, n), m && m.m(t, null), G(f, a, v), G(f, o, v), d && d.m(o, null), l = !0, r || (s = te(
        t,
        "click",
        /*handle_toggle*/
        i[21]
      ), r = !0);
    },
    p(f, v) {
      /*loading_status*/
      f[12] ? u ? (u.p(f, v), v[0] & /*loading_status*/
      4096 && sn(u, 1)) : (u = qa(f), u.c(), sn(u, 1), u.m(e.parentNode, e)) : u && (Gs(), On(u, 1, 1, () => {
        u = null;
      }), zs()), /*label*/
      f[2] ? c ? c.p(f, v) : (c = Na(f), c.c(), c.m(t, n)) : c && (c.d(1), c = null), /*disable_accordion*/
      f[4] ? m && (m.d(1), m = null) : m ? m.p(f, v) : (m = Ma(f), m.c(), m.m(t, null)), (!l || v[0] & /*disable_accordion*/
      16) && (t.disabled = /*disable_accordion*/
      f[4]), /*open*/
      f[1] ? d ? d.p(f, v) : (d = Pa(f), d.c(), d.m(o, null)) : d && (d.d(1), d = null), (!l || v[0] & /*open*/
      2) && ve(o, "closed", !/*open*/
      f[1]);
    },
    i(f) {
      l || (sn(u), l = !0);
    },
    o(f) {
      On(u), l = !1;
    },
    d(f) {
      f && (B(e), B(t), B(a), B(o)), u && u.d(f), c && c.d(), m && m.d(), d && d.d(), r = !1, s();
    }
  };
}
function lu(i) {
  let e, t;
  return e = new bo({
    props: {
      visible: (
        /*visible*/
        i[5]
      ),
      elem_id: (
        /*elem_id*/
        i[6]
      ),
      elem_classes: (
        /*final_classes*/
        i[19]
      ),
      container: (
        /*container*/
        i[7]
      ),
      scale: (
        /*scale*/
        i[8]
      ),
      min_width: (
        /*min_width*/
        i[9]
      ),
      width: (
        /*width*/
        i[10]
      ),
      $$slots: { default: [au] },
      $$scope: { ctx: i }
    }
  }), {
    c() {
      xl(e.$$.fragment);
    },
    l(n) {
      zl(e.$$.fragment, n);
    },
    m(n, a) {
      Vl(e, n, a), t = !0;
    },
    p(n, a) {
      const o = {};
      a[0] & /*visible*/
      32 && (o.visible = /*visible*/
      n[5]), a[0] & /*elem_id*/
      64 && (o.elem_id = /*elem_id*/
      n[6]), a[0] & /*final_classes*/
      524288 && (o.elem_classes = /*final_classes*/
      n[19]), a[0] & /*container*/
      128 && (o.container = /*container*/
      n[7]), a[0] & /*scale*/
      256 && (o.scale = /*scale*/
      n[8]), a[0] & /*min_width*/
      512 && (o.min_width = /*min_width*/
      n[9]), a[0] & /*width*/
      1024 && (o.width = /*width*/
      n[10]), a[0] & /*open, value, show_group_name_only_one, height, interactive, initialValues, validationState, sliderElements, groupVisibility, disable_accordion, label, gradio, loading_status*/
      522271 | a[2] & /*$$scope*/
      524288 && (o.$$scope = { dirty: a, ctx: n }), e.$set(o);
    },
    i(n) {
      t || (sn(e.$$.fragment, n), t = !0);
    },
    o(n) {
      On(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Hl(e, n);
    }
  };
}
function nl(i, e) {
  var t, n;
  if (!e) return;
  const a = (t = i.minimum) !== null && t !== void 0 ? t : 0, o = (n = i.maximum) !== null && n !== void 0 ? n : 100, l = Number(i.value), r = l <= a ? 0 : (l - a) * 100 / (o - a);
  e.style.setProperty("--slider-progress", `${r}%`);
}
function ou(i, e, t) {
  let n;
  var a = this && this.__awaiter || function(b, L, W, re) {
    function Be(tt) {
      return tt instanceof W ? tt : new W(function(Ie) {
        Ie(tt);
      });
    }
    return new (W || (W = Promise))(function(tt, Ie) {
      function Et(ht) {
        try {
          Tt(re.next(ht));
        } catch (At) {
          Ie(At);
        }
      }
      function Wt(ht) {
        try {
          Tt(re.throw(ht));
        } catch (At) {
          Ie(At);
        }
      }
      function Tt(ht) {
        ht.done ? tt(ht.value) : Be(ht.value).then(Et, Wt);
      }
      Tt((re = re.apply(b, L || [])).next());
    });
  }, o;
  let { value: l = [] } = e, { label: r = void 0 } = e, { show_group_name_only_one: s = !0 } = e, { disable_accordion: u = !1 } = e, { visible: c = !0 } = e, { open: m = !0 } = e, { elem_id: d = "" } = e, { elem_classes: f = [] } = e, { container: v = !1 } = e, { scale: D = null } = e, { min_width: w = void 0 } = e, { width: F = void 0 } = e, { height: h = void 0 } = e, { loading_status: _ = void 0 } = e, { interactive: g = !0 } = e, { gradio: y } = e, $ = {}, C = {}, I = {}, T = null, M = !1, N = {};
  function j(b) {
    if (b.minimum === void 0 && b.maximum === void 0) {
      I[b.name] !== !0 && (t(17, I[b.name] = !0, I), t(17, I = Object.assign({}, I)));
      return;
    }
    const L = Number(b.value);
    let W = !0;
    b.minimum !== void 0 && L < b.minimum && (W = !1), b.maximum !== void 0 && L > b.maximum && (W = !1), I[b.name] !== W && (t(17, I[b.name] = W, I), t(17, I = Object.assign({}, I)));
  }
  function ke() {
    if (Array.isArray(l)) {
      for (const b of l)
        if (Array.isArray(b.properties))
          for (const L of b.properties)
            L.component === "slider" && C[L.name] && nl(L, C[L.name]);
    }
  }
  function ce() {
    t(1, m = !m), m ? y.dispatch("expand") : y.dispatch("collapse");
  }
  function Ee(b) {
    t(15, $[b] = !$[b], $);
  }
  function pe(b) {
    if (!(!Array.isArray(l) || !b))
      for (const L of l) {
        if (!Array.isArray(L.properties)) continue;
        const W = L.properties.find((re) => re.name === b);
        if (W)
          return W.value;
      }
  }
  function ie(b, L) {
    var W;
    if (I[L.name] === !1)
      return;
    const re = {};
    let Be = L.value;
    !((W = L.component) === null || W === void 0) && W.startsWith("number") || L.component === "slider" ? Be = Number(L.value) : L.component === "checkbox" && (Be = L.value), re[L.name] = Be, y.dispatch(b, re);
  }
  function Q(b, L) {
    return a(this, void 0, void 0, function* () {
      const W = b.target.value;
      t(0, l = l.map((re) => re.properties ? Object.assign(Object.assign({}, re), {
        properties: re.properties.map((Be) => Be.name === L.name ? Object.assign(Object.assign({}, Be), { value: W }) : Be)
      }) : re)), yield An(), y.dispatch("change", l);
    });
  }
  function se() {
    return a(this, void 0, void 0, function* () {
      yield An(), y.dispatch("change", l);
    });
  }
  function be(b) {
    if (M) return;
    if (M = !0, !(b in N)) {
      M = !1;
      return;
    }
    let L = l.map((W) => (W.properties && (W.properties = W.properties.map((re) => re.name === b ? Object.assign(Object.assign({}, re), { value: N[b] }) : re)), W));
    t(0, l = L), y.dispatch("undo", L), setTimeout(
      () => {
        M = !1;
      },
      100
    );
  }
  function k() {
    t(30, T = JSON.stringify(l)), Array.isArray(l) && l.forEach((b) => {
      Array.isArray(b.properties) && b.properties.forEach((L) => {
        t(18, N[L.name] = L.value, N);
      });
    }), setTimeout(ke, 50);
  }
  Zs(() => {
    k();
  });
  const oe = [[]], J = () => y.dispatch("clear_status"), he = (b) => Ee(b.group_name);
  function A(b, L) {
    b[L].value = this.value, t(0, l);
  }
  const Te = (b) => ie("change", b), Qe = (b) => ie("input", b);
  function Dt(b, L) {
    b[L].value = this.value, t(0, l);
  }
  const yt = (b) => ie("change", b), wt = (b) => ie("input", b);
  function ft(b, L) {
    b[L].value = this.checked, t(0, l);
  }
  const Je = (b) => ie("change", b);
  function et(b, L) {
    b[L].value = di(this.value), t(0, l);
  }
  const pt = (b) => ie("change", b), Gt = (b) => {
    j(b), ie("input", b);
  };
  function jt(b, L) {
    b[L].value = di(this.value), t(0, l);
  }
  function Ft(b, L) {
    Ps[b ? "unshift" : "push"](() => {
      C[L.name] = b, t(16, C);
    });
  }
  const qt = (b) => {
    j(b), nl(b, C[b.name]), ie("input", b);
  }, Nt = (b) => ie("change", b);
  function dn(b, L) {
    b[L].value = this.value, t(0, l);
  }
  const fn = (b) => ie("change", b), Nn = (b, L) => Q(L, b);
  function Vt(b, L) {
    b[L].value = this.__value, t(0, l);
  }
  const St = (b) => ie("change", b);
  function $t(b, L, W) {
    b[L].value = xs(oe[0][L][W], this.__value, this.checked), t(0, l);
  }
  const kt = () => se(), pn = (b) => be(b.name);
  return i.$$set = (b) => {
    "value" in b && t(0, l = b.value), "label" in b && t(2, r = b.label), "show_group_name_only_one" in b && t(3, s = b.show_group_name_only_one), "disable_accordion" in b && t(4, u = b.disable_accordion), "visible" in b && t(5, c = b.visible), "open" in b && t(1, m = b.open), "elem_id" in b && t(6, d = b.elem_id), "elem_classes" in b && t(28, f = b.elem_classes), "container" in b && t(7, v = b.container), "scale" in b && t(8, D = b.scale), "min_width" in b && t(9, w = b.min_width), "width" in b && t(10, F = b.width), "height" in b && t(11, h = b.height), "loading_status" in b && t(12, _ = b.loading_status), "interactive" in b && t(13, g = b.interactive), "gradio" in b && t(14, y = b.gradio);
  }, i.$$.update = () => {
    if (i.$$.dirty[0] & /*elem_classes*/
    268435456 && t(19, n = ["propertysheet-wrapper", ...f]), i.$$.dirty[0] & /*open, height*/
    2050, i.$$.dirty[0] & /*value, lastValue, groupVisibility, _a*/
    1610645505 && Array.isArray(l)) {
      if (JSON.stringify(l) !== T) {
        t(30, T = JSON.stringify(l));
        for (const b of l)
          $[b.group_name] === void 0 && t(15, $[b.group_name] = !0, $);
      }
      for (const b of l)
        if (Array.isArray(b.properties))
          for (const L of b.properties)
            (!(t(29, o = L.component) === null || o === void 0) && o.startsWith("number") || L.component === "slider") && j(L);
      An().then(ke);
    }
    i.$$.dirty[0] & /*open, groupVisibility*/
    32770 && m && $ && An().then(ke);
  }, [
    l,
    m,
    r,
    s,
    u,
    c,
    d,
    v,
    D,
    w,
    F,
    h,
    _,
    g,
    y,
    $,
    C,
    I,
    N,
    n,
    j,
    ce,
    Ee,
    pe,
    ie,
    Q,
    se,
    be,
    f,
    o,
    T,
    J,
    he,
    A,
    Te,
    Qe,
    Dt,
    yt,
    wt,
    ft,
    Je,
    et,
    pt,
    Gt,
    jt,
    Ft,
    qt,
    Nt,
    dn,
    fn,
    Nn,
    Vt,
    oe,
    St,
    $t,
    kt,
    pn
  ];
}
class B2 extends Ns {
  constructor(e) {
    super(), js(
      this,
      e,
      ou,
      lu,
      Vs,
      {
        value: 0,
        label: 2,
        show_group_name_only_one: 3,
        disable_accordion: 4,
        visible: 5,
        open: 1,
        elem_id: 6,
        elem_classes: 28,
        container: 7,
        scale: 8,
        min_width: 9,
        width: 10,
        height: 11,
        loading_status: 12,
        interactive: 13,
        gradio: 14
      },
      null,
      [-1, -1, -1]
    );
  }
}
export {
  B2 as default
};
