__version__ = "1.17"
__min_server_version__ = "2.6.0"  # matches installation.adoc
