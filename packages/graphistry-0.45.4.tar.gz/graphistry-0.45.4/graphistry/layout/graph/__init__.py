# DEPRECRATED: Non-vector operators over non-vectorized data

from .vertexBase import VertexBase
from .vertex import Vertex
from .edgeBase import EdgeBase
from .edge import Edge
from .graph import Graph
from .graphBase import GraphBase
