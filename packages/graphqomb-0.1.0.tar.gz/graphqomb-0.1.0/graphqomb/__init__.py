"""GraphQOMB library."""
