## License

- The source code is licensed under the MIT License.
- The Noto Sans font files included in this package are licensed under the SIL Open Font License (OFL) 1.1.
