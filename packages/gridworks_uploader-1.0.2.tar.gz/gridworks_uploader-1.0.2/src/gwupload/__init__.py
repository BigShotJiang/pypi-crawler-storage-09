"""Gridworks Uploader."""

__all__ = [
    "UploaderApp",
]

from gwupload.app import UploaderApp
