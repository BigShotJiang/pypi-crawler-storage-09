STUB_INGESTER_LONG_NAME: str = "stub_ingester"
