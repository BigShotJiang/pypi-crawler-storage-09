"""Executable types package."""
