guniflask = dict(
    cors=True,
)
