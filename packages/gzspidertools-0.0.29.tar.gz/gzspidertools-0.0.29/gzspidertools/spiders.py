from gzspidertools.scraper.spiders import AyuSpider
from gzspidertools.scraper.spiders.crawl import AyuCrawlSpider

__all__ = [
    "AyuCrawlSpider",
    "AyuSpider",
]
