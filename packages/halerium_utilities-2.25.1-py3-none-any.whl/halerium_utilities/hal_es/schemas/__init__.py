from halerium_utilities.hal_es.schemas.hal_e_data import HalEData, HalEPayload
