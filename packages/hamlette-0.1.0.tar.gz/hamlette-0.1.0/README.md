# hamlette

A Python library enriching Hamcrest with additional matchers and syntactic-sugars for more expressive, readable assertions.