# coding: utf-8

"""
    Harness NextGen Software Delivery Platform API Reference

    The Harness Software Delivery Platform uses OpenAPI Specification v3.0. Harness constantly improves these APIs. Please be aware that some improvements could cause breaking changes. # Introduction     The Harness API allows you to integrate and use all the services and modules we provide on the Harness Platform. If you use client-side SDKs, Harness functionality can be integrated with your client-side automation, helping you reduce manual efforts and deploy code faster.    For more information about how Harness works, read our [documentation](https://developer.harness.io/docs/getting-started) or visit the [Harness Developer Hub](https://developer.harness.io/).  ## How it works    The Harness API is a RESTful API that uses standard HTTP verbs. You can send requests in JSON, YAML, or form-data format. The format of the response matches the format of your request. You must send a single request at a time and ensure that you include your authentication key. For more information about this, go to [Authentication](#section/Introduction/Authentication).  ## Get started    Before you start integrating, get to know our API better by reading the following topics:    * [Harness key concepts](https://developer.harness.io/docs/getting-started/learn-harness-key-concepts/)   * [Authentication](#section/Introduction/Authentication)   * [Requests and responses](#section/Introduction/Requests-and-Responses)   * [Common Parameters](#section/Introduction/Common-Parameters-Beta)   * [Status Codes](#section/Introduction/Status-Codes)   * [Errors](#tag/Error-Response)   * [Versioning](#section/Introduction/Versioning-Beta)   * [Pagination](/#section/Introduction/Pagination-Beta)    The methods you need to integrate with depend on the functionality you want to use. Work with  your Harness Solutions Engineer to determine which methods you need.  ## Authentication  To authenticate with the Harness API, you need to:   1. Generate an API token on the Harness Platform.   2. Send the API token you generate in the `x-api-key` header in each request.  ### Generate an API token  To generate an API token, complete the following steps:   1. Go to the [Harness Platform](https://app.harness.io/).   2. On the left-hand navigation, click **My Profile**.   3. Click **+API Key**, enter a name for your key and then click **Save**.   4. Within the API Key tile, click **+Token**.   5. Enter a name for your token and click **Generate Token**. **Important**: Make sure to save your token securely. Harness does not store the API token for future reference, so make sure to save your token securely before you leave the page.  ### Send the API token in your requests  Send the token you created in the Harness Platform in the x-api-key header. For example:   `x-api-key: YOUR_API_KEY_HERE`  ## Requests and Responses    The structure for each request and response is outlined in the API documentation. We have examples in JSON and YAML for every request and response. You can use our online editor to test the examples.  ## Common Parameters [Beta]  | Field Name | Type    | Default | Description    | |------------|---------|---------|----------------| | identifier | string  | none    | URL-friendly version of the name, used to identify a resource within it's scope and so needs to be unique within the scope.                                                                                                            | | name       | string  | none    | Human-friendly name for the resource.                                                                                       | | org        | string  | none    | Limit to provided org identifiers.                                                                                                                     | | project    | string  | none    | Limit to provided project identifiers.                                                                                                                 | | description| string  | none    | More information about the specific resource.                                                                                    | | tags       | map[string]string  | none    | List of labels applied to the resource.                                                                                                                         | | order      | string  | desc    | Order to use when sorting the specified fields. Type: enum(asc,desc).                                                                                                                                     | | sort       | string  | none    | Fields on which to sort. Note: Specify the fields that you want to use for sorting. When doing so, consider the operational overhead of sorting fields. | | limit      | int     | 30      | Pagination: Number of items to return.                                                                                                                 | | page       | int     | 1       | Pagination page number strategy: Specify the page number within the paginated collection related to the number of items in each page.                  | | created    | int64   | none    | Unix timestamp that shows when the resource was created (in milliseconds).                                                               | | updated    | int64   | none    | Unix timestamp that shows when the resource was last edited (in milliseconds).                                                           |   ## Status Codes    Harness uses conventional HTTP status codes to indicate the status of an API request.    Generally, 2xx responses are reserved for success and 4xx status codes are reserved for failures. A 5xx response code indicates an error on the Harness server.    | Error Code  | Description |   |-------------|-------------|   | 200         |     OK      |   | 201         |   Created   |   | 202         |   Accepted  |   | 204         |  No Content |   | 400         | Bad Request |   | 401         | Unauthorized |   | 403         | Forbidden |   | 412         | Precondition Failed |   | 415         | Unsupported Media Type |   | 500         | Server Error |    To view our error response structures, go [here](#tag/Error-Response).  ## Versioning [Beta]  ### Harness Version   The current version of our Beta APIs is yet to be announced. The version number will use the date-header format and will be valid only for our Beta APIs.  ### Generation   All our beta APIs are versioned as a Generation, and this version is included in the path to every API resource. For example, v1 beta APIs begin with `app.harness.io/v1/`, where v1 is the API Generation.    The version number represents the core API and does not change frequently. The version number changes only if there is a significant departure from the basic underpinnings of the existing API. For example, when Harness performs a system-wide refactoring of core concepts or resources.  ## Pagination [Beta]  We use pagination to place limits on the number of responses associated with list endpoints. Pagination is achieved by the use of limit query parameters. The limit defaults to 30. Its maximum value is 100.  Following are the pagination headers supported in the response bodies of paginated APIs:   1. X-Total-Elements : Indicates the total number of entries in a paginated response.   2. X-Page-Number : Indicates the page number currently returned for a paginated response.   3. X-Page-Size : Indicates the number of entries per page for a paginated response.  For example:    ``` X-Total-Elements : 30 X-Page-Number : 0 X-Page-Size : 10   ```   # noqa: E501

    OpenAPI spec version: 1.0
    Contact: contact@harness.io
    Generated by: https://github.com/swagger-api/swagger-codegen.git
"""

from __future__ import absolute_import

import re  # noqa: F401

# python 2 and python 3 compatibility library
import six

from harness_open_api.api_client import ApiClient


class CloudCostPerspectivesApi(object):
    """NOTE: This class is auto generated by the swagger code generator program.

    Do not edit the class manually.
    Ref: https://github.com/swagger-api/swagger-codegen
    """

    def __init__(self, api_client=None):
        if api_client is None:
            api_client = ApiClient()
        self.api_client = api_client

    def create_perspective(self, body, account_identifier, clone, **kwargs):  # noqa: E501
        """Create a Perspective  # noqa: E501

        Create a Perspective. You can set the clone parameter as true to clone a Perspective.  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.create_perspective(body, account_identifier, clone, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param CEView body: Request body containing Perspective's CEView object (required)
        :param str account_identifier: Account Identifier for the Entity. (required)
        :param bool clone: Set the clone parameter as true to clone a Perspective. (required)
        :param bool update_total_cost:
        :return: ResponseDTOCEView
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.create_perspective_with_http_info(body, account_identifier, clone, **kwargs)  # noqa: E501
        else:
            (data) = self.create_perspective_with_http_info(body, account_identifier, clone, **kwargs)  # noqa: E501
            return data

    def create_perspective_with_http_info(self, body, account_identifier, clone, **kwargs):  # noqa: E501
        """Create a Perspective  # noqa: E501

        Create a Perspective. You can set the clone parameter as true to clone a Perspective.  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.create_perspective_with_http_info(body, account_identifier, clone, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param CEView body: Request body containing Perspective's CEView object (required)
        :param str account_identifier: Account Identifier for the Entity. (required)
        :param bool clone: Set the clone parameter as true to clone a Perspective. (required)
        :param bool update_total_cost:
        :return: ResponseDTOCEView
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['body', 'account_identifier', 'clone', 'update_total_cost']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method create_perspective" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'body' is set
        if ('body' not in params or
                params['body'] is None):
            raise ValueError("Missing the required parameter `body` when calling `create_perspective`")  # noqa: E501
        # verify the required parameter 'account_identifier' is set
        if ('account_identifier' not in params or
                params['account_identifier'] is None):
            raise ValueError("Missing the required parameter `account_identifier` when calling `create_perspective`")  # noqa: E501
        # verify the required parameter 'clone' is set
        if ('clone' not in params or
                params['clone'] is None):
            raise ValueError("Missing the required parameter `clone` when calling `create_perspective`")  # noqa: E501

        collection_formats = {}

        path_params = {}

        query_params = []
        if 'account_identifier' in params:
            query_params.append(('accountIdentifier', params['account_identifier']))  # noqa: E501
        if 'clone' in params:
            query_params.append(('clone', params['clone']))  # noqa: E501
        if 'update_total_cost' in params:
            query_params.append(('updateTotalCost', params['update_total_cost']))  # noqa: E501

        header_params = {}

        form_params = []
        local_var_files = {}

        body_params = None
        if 'body' in params:
            body_params = params['body']
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # HTTP header `Content-Type`
        header_params['Content-Type'] = self.api_client.select_header_content_type(  # noqa: E501
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['x-api-key']  # noqa: E501

        return self.api_client.call_api(
            '/ccm/api/perspective', 'POST',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='ResponseDTOCEView',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def delete_perspective(self, account_identifier, perspective_id, **kwargs):  # noqa: E501
        """Delete a Perspective  # noqa: E501

        Delete a Perspective for the given Perspective ID.  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.delete_perspective(account_identifier, perspective_id, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str account_identifier: Account Identifier for the Entity. (required)
        :param str perspective_id: Unique identifier for the Perspective (required)
        :return: ResponseDTOString
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.delete_perspective_with_http_info(account_identifier, perspective_id, **kwargs)  # noqa: E501
        else:
            (data) = self.delete_perspective_with_http_info(account_identifier, perspective_id, **kwargs)  # noqa: E501
            return data

    def delete_perspective_with_http_info(self, account_identifier, perspective_id, **kwargs):  # noqa: E501
        """Delete a Perspective  # noqa: E501

        Delete a Perspective for the given Perspective ID.  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.delete_perspective_with_http_info(account_identifier, perspective_id, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str account_identifier: Account Identifier for the Entity. (required)
        :param str perspective_id: Unique identifier for the Perspective (required)
        :return: ResponseDTOString
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['account_identifier', 'perspective_id']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method delete_perspective" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'account_identifier' is set
        if ('account_identifier' not in params or
                params['account_identifier'] is None):
            raise ValueError("Missing the required parameter `account_identifier` when calling `delete_perspective`")  # noqa: E501
        # verify the required parameter 'perspective_id' is set
        if ('perspective_id' not in params or
                params['perspective_id'] is None):
            raise ValueError("Missing the required parameter `perspective_id` when calling `delete_perspective`")  # noqa: E501

        collection_formats = {}

        path_params = {}

        query_params = []
        if 'account_identifier' in params:
            query_params.append(('accountIdentifier', params['account_identifier']))  # noqa: E501
        if 'perspective_id' in params:
            query_params.append(('perspectiveId', params['perspective_id']))  # noqa: E501

        header_params = {}

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['x-api-key']  # noqa: E501

        return self.api_client.call_api(
            '/ccm/api/perspective', 'DELETE',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='ResponseDTOString',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def get_all_perspectives(self, account_identifier, page_size, page_no, **kwargs):  # noqa: E501
        """Return details of all the Perspectives  # noqa: E501

        Return details of all the Perspectives for the given account ID.  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_all_perspectives(account_identifier, page_size, page_no, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str account_identifier: Account Identifier for the Entity. (required)
        :param int page_size: Number of perspectives to be shown (required)
        :param int page_no: Number of records to be skipped (required)
        :param str search_key: Characters in search bar
        :param str sort_type:  sorting filters in UI
        :param str sort_order: sorting order
        :param list[str] cloud_filters: filters for clouds and clusters
        :return: ResponseDTOPerspectiveData
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.get_all_perspectives_with_http_info(account_identifier, page_size, page_no, **kwargs)  # noqa: E501
        else:
            (data) = self.get_all_perspectives_with_http_info(account_identifier, page_size, page_no, **kwargs)  # noqa: E501
            return data

    def get_all_perspectives_with_http_info(self, account_identifier, page_size, page_no, **kwargs):  # noqa: E501
        """Return details of all the Perspectives  # noqa: E501

        Return details of all the Perspectives for the given account ID.  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_all_perspectives_with_http_info(account_identifier, page_size, page_no, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str account_identifier: Account Identifier for the Entity. (required)
        :param int page_size: Number of perspectives to be shown (required)
        :param int page_no: Number of records to be skipped (required)
        :param str search_key: Characters in search bar
        :param str sort_type:  sorting filters in UI
        :param str sort_order: sorting order
        :param list[str] cloud_filters: filters for clouds and clusters
        :return: ResponseDTOPerspectiveData
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['account_identifier', 'page_size', 'page_no', 'search_key', 'sort_type', 'sort_order', 'cloud_filters']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method get_all_perspectives" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'account_identifier' is set
        if ('account_identifier' not in params or
                params['account_identifier'] is None):
            raise ValueError("Missing the required parameter `account_identifier` when calling `get_all_perspectives`")  # noqa: E501
        # verify the required parameter 'page_size' is set
        if ('page_size' not in params or
                params['page_size'] is None):
            raise ValueError("Missing the required parameter `page_size` when calling `get_all_perspectives`")  # noqa: E501
        # verify the required parameter 'page_no' is set
        if ('page_no' not in params or
                params['page_no'] is None):
            raise ValueError("Missing the required parameter `page_no` when calling `get_all_perspectives`")  # noqa: E501

        collection_formats = {}

        path_params = {}

        query_params = []
        if 'account_identifier' in params:
            query_params.append(('accountIdentifier', params['account_identifier']))  # noqa: E501
        if 'page_size' in params:
            query_params.append(('pageSize', params['page_size']))  # noqa: E501
        if 'page_no' in params:
            query_params.append(('pageNo', params['page_no']))  # noqa: E501
        if 'search_key' in params:
            query_params.append(('searchKey', params['search_key']))  # noqa: E501
        if 'sort_type' in params:
            query_params.append(('sortType', params['sort_type']))  # noqa: E501
        if 'sort_order' in params:
            query_params.append(('sortOrder', params['sort_order']))  # noqa: E501
        if 'cloud_filters' in params:
            query_params.append(('cloudFilters', params['cloud_filters']))  # noqa: E501
            collection_formats['cloudFilters'] = 'multi'  # noqa: E501

        header_params = {}

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['x-api-key']  # noqa: E501

        return self.api_client.call_api(
            '/ccm/api/perspective/getAllPerspectives', 'GET',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='ResponseDTOPerspectiveData',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def get_last_period_cost1(self, account_identifier, perspective_id, start_time, period, **kwargs):  # noqa: E501
        """Get the last period cost for a Perspective  # noqa: E501

        Get last period cost for a Perspective  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_last_period_cost1(account_identifier, perspective_id, start_time, period, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str account_identifier: Account Identifier for the Entity. (required)
        :param str perspective_id: The Perspective identifier for which we want the cost (required)
        :param int start_time: The Start time (timestamp in millis) for the current period (required)
        :param str period: The period (DAILY, WEEKLY, MONTHLY, QUARTERLY, YEARLY) for which we want the cost (required)
        :return: ResponseDTODouble
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.get_last_period_cost1_with_http_info(account_identifier, perspective_id, start_time, period, **kwargs)  # noqa: E501
        else:
            (data) = self.get_last_period_cost1_with_http_info(account_identifier, perspective_id, start_time, period, **kwargs)  # noqa: E501
            return data

    def get_last_period_cost1_with_http_info(self, account_identifier, perspective_id, start_time, period, **kwargs):  # noqa: E501
        """Get the last period cost for a Perspective  # noqa: E501

        Get last period cost for a Perspective  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_last_period_cost1_with_http_info(account_identifier, perspective_id, start_time, period, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str account_identifier: Account Identifier for the Entity. (required)
        :param str perspective_id: The Perspective identifier for which we want the cost (required)
        :param int start_time: The Start time (timestamp in millis) for the current period (required)
        :param str period: The period (DAILY, WEEKLY, MONTHLY, QUARTERLY, YEARLY) for which we want the cost (required)
        :return: ResponseDTODouble
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['account_identifier', 'perspective_id', 'start_time', 'period']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method get_last_period_cost1" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'account_identifier' is set
        if ('account_identifier' not in params or
                params['account_identifier'] is None):
            raise ValueError("Missing the required parameter `account_identifier` when calling `get_last_period_cost1`")  # noqa: E501
        # verify the required parameter 'perspective_id' is set
        if ('perspective_id' not in params or
                params['perspective_id'] is None):
            raise ValueError("Missing the required parameter `perspective_id` when calling `get_last_period_cost1`")  # noqa: E501
        # verify the required parameter 'start_time' is set
        if ('start_time' not in params or
                params['start_time'] is None):
            raise ValueError("Missing the required parameter `start_time` when calling `get_last_period_cost1`")  # noqa: E501
        # verify the required parameter 'period' is set
        if ('period' not in params or
                params['period'] is None):
            raise ValueError("Missing the required parameter `period` when calling `get_last_period_cost1`")  # noqa: E501

        collection_formats = {}

        path_params = {}

        query_params = []
        if 'account_identifier' in params:
            query_params.append(('accountIdentifier', params['account_identifier']))  # noqa: E501
        if 'perspective_id' in params:
            query_params.append(('perspectiveId', params['perspective_id']))  # noqa: E501
        if 'start_time' in params:
            query_params.append(('startTime', params['start_time']))  # noqa: E501
        if 'period' in params:
            query_params.append(('period', params['period']))  # noqa: E501

        header_params = {}

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['x-api-key']  # noqa: E501

        return self.api_client.call_api(
            '/ccm/api/perspective/lastPeriodCost', 'GET',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='ResponseDTODouble',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def get_last_year_monthly_cost(self, account_identifier, perspective_id, start_time, period, type, breakdown, **kwargs):  # noqa: E501
        """Get the last twelve month cost for a Perspective  # noqa: E501

        Get last twelve month cost for a Perspective  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_last_year_monthly_cost(account_identifier, perspective_id, start_time, period, type, breakdown, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str account_identifier: Account Identifier for the Entity. (required)
        :param str perspective_id: The Perspective identifier for which we want the cost (required)
        :param int start_time: The Start time (timestamp in millis) for the current period (required)
        :param str period: Only support for YEARLY budget period (required)
        :param str type: Only support for PREVIOUS_PERIOD_SPEND budget type (required)
        :param str breakdown: Only support for MONTHLY breakdown (required)
        :return: ResponseDTOListValueDataPoint
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.get_last_year_monthly_cost_with_http_info(account_identifier, perspective_id, start_time, period, type, breakdown, **kwargs)  # noqa: E501
        else:
            (data) = self.get_last_year_monthly_cost_with_http_info(account_identifier, perspective_id, start_time, period, type, breakdown, **kwargs)  # noqa: E501
            return data

    def get_last_year_monthly_cost_with_http_info(self, account_identifier, perspective_id, start_time, period, type, breakdown, **kwargs):  # noqa: E501
        """Get the last twelve month cost for a Perspective  # noqa: E501

        Get last twelve month cost for a Perspective  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_last_year_monthly_cost_with_http_info(account_identifier, perspective_id, start_time, period, type, breakdown, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str account_identifier: Account Identifier for the Entity. (required)
        :param str perspective_id: The Perspective identifier for which we want the cost (required)
        :param int start_time: The Start time (timestamp in millis) for the current period (required)
        :param str period: Only support for YEARLY budget period (required)
        :param str type: Only support for PREVIOUS_PERIOD_SPEND budget type (required)
        :param str breakdown: Only support for MONTHLY breakdown (required)
        :return: ResponseDTOListValueDataPoint
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['account_identifier', 'perspective_id', 'start_time', 'period', 'type', 'breakdown']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method get_last_year_monthly_cost" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'account_identifier' is set
        if ('account_identifier' not in params or
                params['account_identifier'] is None):
            raise ValueError("Missing the required parameter `account_identifier` when calling `get_last_year_monthly_cost`")  # noqa: E501
        # verify the required parameter 'perspective_id' is set
        if ('perspective_id' not in params or
                params['perspective_id'] is None):
            raise ValueError("Missing the required parameter `perspective_id` when calling `get_last_year_monthly_cost`")  # noqa: E501
        # verify the required parameter 'start_time' is set
        if ('start_time' not in params or
                params['start_time'] is None):
            raise ValueError("Missing the required parameter `start_time` when calling `get_last_year_monthly_cost`")  # noqa: E501
        # verify the required parameter 'period' is set
        if ('period' not in params or
                params['period'] is None):
            raise ValueError("Missing the required parameter `period` when calling `get_last_year_monthly_cost`")  # noqa: E501
        # verify the required parameter 'type' is set
        if ('type' not in params or
                params['type'] is None):
            raise ValueError("Missing the required parameter `type` when calling `get_last_year_monthly_cost`")  # noqa: E501
        # verify the required parameter 'breakdown' is set
        if ('breakdown' not in params or
                params['breakdown'] is None):
            raise ValueError("Missing the required parameter `breakdown` when calling `get_last_year_monthly_cost`")  # noqa: E501

        collection_formats = {}

        path_params = {}

        query_params = []
        if 'account_identifier' in params:
            query_params.append(('accountIdentifier', params['account_identifier']))  # noqa: E501
        if 'perspective_id' in params:
            query_params.append(('perspectiveId', params['perspective_id']))  # noqa: E501
        if 'start_time' in params:
            query_params.append(('startTime', params['start_time']))  # noqa: E501
        if 'period' in params:
            query_params.append(('period', params['period']))  # noqa: E501
        if 'type' in params:
            query_params.append(('type', params['type']))  # noqa: E501
        if 'breakdown' in params:
            query_params.append(('breakdown', params['breakdown']))  # noqa: E501

        header_params = {}

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['x-api-key']  # noqa: E501

        return self.api_client.call_api(
            '/ccm/api/perspective/lastYearMonthlyCost', 'GET',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='ResponseDTOListValueDataPoint',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def get_perspective(self, account_identifier, perspective_id, **kwargs):  # noqa: E501
        """Fetch details of a Perspective  # noqa: E501

        Fetch details of a Perspective for the given Perspective ID.  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_perspective(account_identifier, perspective_id, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str account_identifier: Account Identifier for the Entity. (required)
        :param str perspective_id: Unique identifier for the Perspective (required)
        :return: ResponseDTOCEView
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.get_perspective_with_http_info(account_identifier, perspective_id, **kwargs)  # noqa: E501
        else:
            (data) = self.get_perspective_with_http_info(account_identifier, perspective_id, **kwargs)  # noqa: E501
            return data

    def get_perspective_with_http_info(self, account_identifier, perspective_id, **kwargs):  # noqa: E501
        """Fetch details of a Perspective  # noqa: E501

        Fetch details of a Perspective for the given Perspective ID.  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_perspective_with_http_info(account_identifier, perspective_id, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str account_identifier: Account Identifier for the Entity. (required)
        :param str perspective_id: Unique identifier for the Perspective (required)
        :return: ResponseDTOCEView
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['account_identifier', 'perspective_id']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method get_perspective" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'account_identifier' is set
        if ('account_identifier' not in params or
                params['account_identifier'] is None):
            raise ValueError("Missing the required parameter `account_identifier` when calling `get_perspective`")  # noqa: E501
        # verify the required parameter 'perspective_id' is set
        if ('perspective_id' not in params or
                params['perspective_id'] is None):
            raise ValueError("Missing the required parameter `perspective_id` when calling `get_perspective`")  # noqa: E501

        collection_formats = {}

        path_params = {}

        query_params = []
        if 'account_identifier' in params:
            query_params.append(('accountIdentifier', params['account_identifier']))  # noqa: E501
        if 'perspective_id' in params:
            query_params.append(('perspectiveId', params['perspective_id']))  # noqa: E501

        header_params = {}

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['x-api-key']  # noqa: E501

        return self.api_client.call_api(
            '/ccm/api/perspective', 'GET',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='ResponseDTOCEView',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def update_perspective(self, body, account_identifier, **kwargs):  # noqa: E501
        """Update a Perspective  # noqa: E501

        Update a Perspective. It accepts a CEView object and upserts it using the uuid mentioned in the definition.  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.update_perspective(body, account_identifier, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param CEView body: Perspective's CEView object (required)
        :param str account_identifier: Account Identifier for the Entity. (required)
        :param bool update_total_cost:
        :return: ResponseDTOCEView
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.update_perspective_with_http_info(body, account_identifier, **kwargs)  # noqa: E501
        else:
            (data) = self.update_perspective_with_http_info(body, account_identifier, **kwargs)  # noqa: E501
            return data

    def update_perspective_with_http_info(self, body, account_identifier, **kwargs):  # noqa: E501
        """Update a Perspective  # noqa: E501

        Update a Perspective. It accepts a CEView object and upserts it using the uuid mentioned in the definition.  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.update_perspective_with_http_info(body, account_identifier, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param CEView body: Perspective's CEView object (required)
        :param str account_identifier: Account Identifier for the Entity. (required)
        :param bool update_total_cost:
        :return: ResponseDTOCEView
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['body', 'account_identifier', 'update_total_cost']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method update_perspective" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'body' is set
        if ('body' not in params or
                params['body'] is None):
            raise ValueError("Missing the required parameter `body` when calling `update_perspective`")  # noqa: E501
        # verify the required parameter 'account_identifier' is set
        if ('account_identifier' not in params or
                params['account_identifier'] is None):
            raise ValueError("Missing the required parameter `account_identifier` when calling `update_perspective`")  # noqa: E501

        collection_formats = {}

        path_params = {}

        query_params = []
        if 'account_identifier' in params:
            query_params.append(('accountIdentifier', params['account_identifier']))  # noqa: E501
        if 'update_total_cost' in params:
            query_params.append(('updateTotalCost', params['update_total_cost']))  # noqa: E501

        header_params = {}

        form_params = []
        local_var_files = {}

        body_params = None
        if 'body' in params:
            body_params = params['body']
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # HTTP header `Content-Type`
        header_params['Content-Type'] = self.api_client.select_header_content_type(  # noqa: E501
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['x-api-key']  # noqa: E501

        return self.api_client.call_api(
            '/ccm/api/perspective', 'PUT',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='ResponseDTOCEView',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)
