# coding: utf-8

"""
    Harness NextGen Software Delivery Platform API Reference

    The Harness Software Delivery Platform uses OpenAPI Specification v3.0. Harness constantly improves these APIs. Please be aware that some improvements could cause breaking changes. # Introduction     The Harness API allows you to integrate and use all the services and modules we provide on the Harness Platform. If you use client-side SDKs, Harness functionality can be integrated with your client-side automation, helping you reduce manual efforts and deploy code faster.    For more information about how Harness works, read our [documentation](https://developer.harness.io/docs/getting-started) or visit the [Harness Developer Hub](https://developer.harness.io/).  ## How it works    The Harness API is a RESTful API that uses standard HTTP verbs. You can send requests in JSON, YAML, or form-data format. The format of the response matches the format of your request. You must send a single request at a time and ensure that you include your authentication key. For more information about this, go to [Authentication](#section/Introduction/Authentication).  ## Get started    Before you start integrating, get to know our API better by reading the following topics:    * [Harness key concepts](https://developer.harness.io/docs/getting-started/learn-harness-key-concepts/)   * [Authentication](#section/Introduction/Authentication)   * [Requests and responses](#section/Introduction/Requests-and-Responses)   * [Common Parameters](#section/Introduction/Common-Parameters-Beta)   * [Status Codes](#section/Introduction/Status-Codes)   * [Errors](#tag/Error-Response)   * [Versioning](#section/Introduction/Versioning-Beta)   * [Pagination](/#section/Introduction/Pagination-Beta)    The methods you need to integrate with depend on the functionality you want to use. Work with  your Harness Solutions Engineer to determine which methods you need.  ## Authentication  To authenticate with the Harness API, you need to:   1. Generate an API token on the Harness Platform.   2. Send the API token you generate in the `x-api-key` header in each request.  ### Generate an API token  To generate an API token, complete the following steps:   1. Go to the [Harness Platform](https://app.harness.io/).   2. On the left-hand navigation, click **My Profile**.   3. Click **+API Key**, enter a name for your key and then click **Save**.   4. Within the API Key tile, click **+Token**.   5. Enter a name for your token and click **Generate Token**. **Important**: Make sure to save your token securely. Harness does not store the API token for future reference, so make sure to save your token securely before you leave the page.  ### Send the API token in your requests  Send the token you created in the Harness Platform in the x-api-key header. For example:   `x-api-key: YOUR_API_KEY_HERE`  ## Requests and Responses    The structure for each request and response is outlined in the API documentation. We have examples in JSON and YAML for every request and response. You can use our online editor to test the examples.  ## Common Parameters [Beta]  | Field Name | Type    | Default | Description    | |------------|---------|---------|----------------| | identifier | string  | none    | URL-friendly version of the name, used to identify a resource within it's scope and so needs to be unique within the scope.                                                                                                            | | name       | string  | none    | Human-friendly name for the resource.                                                                                       | | org        | string  | none    | Limit to provided org identifiers.                                                                                                                     | | project    | string  | none    | Limit to provided project identifiers.                                                                                                                 | | description| string  | none    | More information about the specific resource.                                                                                    | | tags       | map[string]string  | none    | List of labels applied to the resource.                                                                                                                         | | order      | string  | desc    | Order to use when sorting the specified fields. Type: enum(asc,desc).                                                                                                                                     | | sort       | string  | none    | Fields on which to sort. Note: Specify the fields that you want to use for sorting. When doing so, consider the operational overhead of sorting fields. | | limit      | int     | 30      | Pagination: Number of items to return.                                                                                                                 | | page       | int     | 1       | Pagination page number strategy: Specify the page number within the paginated collection related to the number of items in each page.                  | | created    | int64   | none    | Unix timestamp that shows when the resource was created (in milliseconds).                                                               | | updated    | int64   | none    | Unix timestamp that shows when the resource was last edited (in milliseconds).                                                           |   ## Status Codes    Harness uses conventional HTTP status codes to indicate the status of an API request.    Generally, 2xx responses are reserved for success and 4xx status codes are reserved for failures. A 5xx response code indicates an error on the Harness server.    | Error Code  | Description |   |-------------|-------------|   | 200         |     OK      |   | 201         |   Created   |   | 202         |   Accepted  |   | 204         |  No Content |   | 400         | Bad Request |   | 401         | Unauthorized |   | 403         | Forbidden |   | 412         | Precondition Failed |   | 415         | Unsupported Media Type |   | 500         | Server Error |    To view our error response structures, go [here](#tag/Error-Response).  ## Versioning [Beta]  ### Harness Version   The current version of our Beta APIs is yet to be announced. The version number will use the date-header format and will be valid only for our Beta APIs.  ### Generation   All our beta APIs are versioned as a Generation, and this version is included in the path to every API resource. For example, v1 beta APIs begin with `app.harness.io/v1/`, where v1 is the API Generation.    The version number represents the core API and does not change frequently. The version number changes only if there is a significant departure from the basic underpinnings of the existing API. For example, when Harness performs a system-wide refactoring of core concepts or resources.  ## Pagination [Beta]  We use pagination to place limits on the number of responses associated with list endpoints. Pagination is achieved by the use of limit query parameters. The limit defaults to 30. Its maximum value is 100.  Following are the pagination headers supported in the response bodies of paginated APIs:   1. X-Total-Elements : Indicates the total number of entries in a paginated response.   2. X-Page-Number : Indicates the page number currently returned for a paginated response.   3. X-Page-Size : Indicates the number of entries per page for a paginated response.  For example:    ``` X-Total-Elements : 30 X-Page-Number : 0 X-Page-Size : 10   ```   # noqa: E501

    OpenAPI spec version: 1.0
    Contact: contact@harness.io
    Generated by: https://github.com/swagger-api/swagger-codegen.git
"""

from __future__ import absolute_import

import re  # noqa: F401

# python 2 and python 3 compatibility library
import six

from harness_open_api.api_client import ApiClient


class PoliciesApi(object):
    """NOTE: This class is auto generated by the swagger code generator program.

    Do not edit the class manually.
    Ref: https://github.com/swagger-api/swagger-codegen
    """

    def __init__(self, api_client=None):
        if api_client is None:
            api_client = ApiClient()
        self.api_client = api_client

    def policies_create(self, body, **kwargs):  # noqa: E501
        """policies_create  # noqa: E501

        Create a policy  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.policies_create(body, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param CreateRequestBody body: (required)
        :param str x_api_key: Harness PAT key used to perform authorization
        :param str account_identifier: Harness account ID
        :param str org_identifier: Harness organization ID
        :param str project_identifier: Harness project ID
        :param str git_commit_msg: The commit message used in git when creating the policy
        :param bool git_import: A flag to determine if the api should try and import and existing policy from git
        :param str git_branch: The git branch the policy will be created in
        :param bool git_is_new_branch: A flag to determine if the api should try and commit to a new branch
        :param str git_base_branch: If committing to a new branch, git_base_branch tells the api which branch to base the new branch from
        :return: PolicyManagementPolicy
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.policies_create_with_http_info(body, **kwargs)  # noqa: E501
        else:
            (data) = self.policies_create_with_http_info(body, **kwargs)  # noqa: E501
            return data

    def policies_create_with_http_info(self, body, **kwargs):  # noqa: E501
        """policies_create  # noqa: E501

        Create a policy  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.policies_create_with_http_info(body, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param CreateRequestBody body: (required)
        :param str x_api_key: Harness PAT key used to perform authorization
        :param str account_identifier: Harness account ID
        :param str org_identifier: Harness organization ID
        :param str project_identifier: Harness project ID
        :param str git_commit_msg: The commit message used in git when creating the policy
        :param bool git_import: A flag to determine if the api should try and import and existing policy from git
        :param str git_branch: The git branch the policy will be created in
        :param bool git_is_new_branch: A flag to determine if the api should try and commit to a new branch
        :param str git_base_branch: If committing to a new branch, git_base_branch tells the api which branch to base the new branch from
        :return: PolicyManagementPolicy
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['body', 'x_api_key', 'account_identifier', 'org_identifier', 'project_identifier', 'git_commit_msg', 'git_import', 'git_branch', 'git_is_new_branch', 'git_base_branch']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method policies_create" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'body' is set
        if ('body' not in params or
                params['body'] is None):
            raise ValueError("Missing the required parameter `body` when calling `policies_create`")  # noqa: E501

        collection_formats = {}

        path_params = {}

        query_params = []
        if 'account_identifier' in params:
            query_params.append(('accountIdentifier', params['account_identifier']))  # noqa: E501
        if 'org_identifier' in params:
            query_params.append(('orgIdentifier', params['org_identifier']))  # noqa: E501
        if 'project_identifier' in params:
            query_params.append(('projectIdentifier', params['project_identifier']))  # noqa: E501
        if 'git_commit_msg' in params:
            query_params.append(('git_commit_msg', params['git_commit_msg']))  # noqa: E501
        if 'git_import' in params:
            query_params.append(('git_import', params['git_import']))  # noqa: E501
        if 'git_branch' in params:
            query_params.append(('git_branch', params['git_branch']))  # noqa: E501
        if 'git_is_new_branch' in params:
            query_params.append(('git_is_new_branch', params['git_is_new_branch']))  # noqa: E501
        if 'git_base_branch' in params:
            query_params.append(('git_base_branch', params['git_base_branch']))  # noqa: E501

        header_params = {}
        if 'x_api_key' in params:
            header_params['x-api-key'] = params['x_api_key']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        if 'body' in params:
            body_params = params['body']
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json', 'application/vnd.goa.error'])  # noqa: E501

        # HTTP header `Content-Type`
        header_params['Content-Type'] = self.api_client.select_header_content_type(  # noqa: E501
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['x-api-key']  # noqa: E501

        return self.api_client.call_api(
            '/pm/api/v1/policies', 'POST',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='PolicyManagementPolicy',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def policies_delete(self, identifier, **kwargs):  # noqa: E501
        """policies_delete  # noqa: E501

        Delete a policy by identifier  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.policies_delete(identifier, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str identifier: Identifier of the policy (required)
        :param str account_identifier: Harness account ID
        :param str org_identifier: Harness organization ID
        :param str project_identifier: Harness project ID
        :param str x_api_key: Harness PAT key used to perform authorization
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.policies_delete_with_http_info(identifier, **kwargs)  # noqa: E501
        else:
            (data) = self.policies_delete_with_http_info(identifier, **kwargs)  # noqa: E501
            return data

    def policies_delete_with_http_info(self, identifier, **kwargs):  # noqa: E501
        """policies_delete  # noqa: E501

        Delete a policy by identifier  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.policies_delete_with_http_info(identifier, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str identifier: Identifier of the policy (required)
        :param str account_identifier: Harness account ID
        :param str org_identifier: Harness organization ID
        :param str project_identifier: Harness project ID
        :param str x_api_key: Harness PAT key used to perform authorization
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['identifier', 'account_identifier', 'org_identifier', 'project_identifier', 'x_api_key']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method policies_delete" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'identifier' is set
        if ('identifier' not in params or
                params['identifier'] is None):
            raise ValueError("Missing the required parameter `identifier` when calling `policies_delete`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'identifier' in params:
            path_params['identifier'] = params['identifier']  # noqa: E501

        query_params = []
        if 'account_identifier' in params:
            query_params.append(('accountIdentifier', params['account_identifier']))  # noqa: E501
        if 'org_identifier' in params:
            query_params.append(('orgIdentifier', params['org_identifier']))  # noqa: E501
        if 'project_identifier' in params:
            query_params.append(('projectIdentifier', params['project_identifier']))  # noqa: E501

        header_params = {}
        if 'x_api_key' in params:
            header_params['x-api-key'] = params['x_api_key']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json', 'application/vnd.goa.error'])  # noqa: E501

        # Authentication setting
        auth_settings = ['x-api-key']  # noqa: E501

        return self.api_client.call_api(
            '/pm/api/v1/policies/{identifier}', 'DELETE',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type=None,  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def policies_find(self, identifier, **kwargs):  # noqa: E501
        """policies_find  # noqa: E501

        Find a policy by identifier  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.policies_find(identifier, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str identifier: Identifier of the policy to retrieve (required)
        :param str account_identifier: Harness account ID
        :param str org_identifier: Harness organization ID
        :param str project_identifier: Harness project ID
        :param str git_branch: The git branch the policy resides in
        :param bool show_summary: Setting to true returns the metadata about the        requested policy including the information held about the status of this policy in the default branch.        git_branch is ignored as no git operation takes place.
        :param str x_api_key: Harness PAT key used to perform authorization
        :return: PolicyManagementPolicy
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.policies_find_with_http_info(identifier, **kwargs)  # noqa: E501
        else:
            (data) = self.policies_find_with_http_info(identifier, **kwargs)  # noqa: E501
            return data

    def policies_find_with_http_info(self, identifier, **kwargs):  # noqa: E501
        """policies_find  # noqa: E501

        Find a policy by identifier  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.policies_find_with_http_info(identifier, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str identifier: Identifier of the policy to retrieve (required)
        :param str account_identifier: Harness account ID
        :param str org_identifier: Harness organization ID
        :param str project_identifier: Harness project ID
        :param str git_branch: The git branch the policy resides in
        :param bool show_summary: Setting to true returns the metadata about the        requested policy including the information held about the status of this policy in the default branch.        git_branch is ignored as no git operation takes place.
        :param str x_api_key: Harness PAT key used to perform authorization
        :return: PolicyManagementPolicy
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['identifier', 'account_identifier', 'org_identifier', 'project_identifier', 'git_branch', 'show_summary', 'x_api_key']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method policies_find" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'identifier' is set
        if ('identifier' not in params or
                params['identifier'] is None):
            raise ValueError("Missing the required parameter `identifier` when calling `policies_find`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'identifier' in params:
            path_params['identifier'] = params['identifier']  # noqa: E501

        query_params = []
        if 'account_identifier' in params:
            query_params.append(('accountIdentifier', params['account_identifier']))  # noqa: E501
        if 'org_identifier' in params:
            query_params.append(('orgIdentifier', params['org_identifier']))  # noqa: E501
        if 'project_identifier' in params:
            query_params.append(('projectIdentifier', params['project_identifier']))  # noqa: E501
        if 'git_branch' in params:
            query_params.append(('git_branch', params['git_branch']))  # noqa: E501
        if 'show_summary' in params:
            query_params.append(('show_summary', params['show_summary']))  # noqa: E501

        header_params = {}
        if 'x_api_key' in params:
            header_params['x-api-key'] = params['x_api_key']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json', 'application/vnd.goa.error'])  # noqa: E501

        # Authentication setting
        auth_settings = ['x-api-key']  # noqa: E501

        return self.api_client.call_api(
            '/pm/api/v1/policies/{identifier}', 'GET',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='PolicyManagementPolicy',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def policies_list(self, **kwargs):  # noqa: E501
        """policies_list  # noqa: E501

        List all policies  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.policies_list(async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str account_identifier: Harness account ID
        :param str org_identifier: Harness organization ID
        :param str project_identifier: Harness project ID
        :param int per_page: Number of results per page
        :param int page: Page number (starting from 0)
        :param str identifier_filter: Comma separated List of Identifiers to filter on
        :param str search_term: Filter results by partial name match
        :param str sort: Sort order for results
        :param bool exclude_rego_from_response: Set to true to exclude Rego content from the response
        :param bool include_policy_set_count: Set to true to include the count of policy sets associated with each policy in the response
        :param str x_api_key: Harness PAT key used to perform authorization
        :return: list[PolicyManagementPolicy]
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.policies_list_with_http_info(**kwargs)  # noqa: E501
        else:
            (data) = self.policies_list_with_http_info(**kwargs)  # noqa: E501
            return data

    def policies_list_with_http_info(self, **kwargs):  # noqa: E501
        """policies_list  # noqa: E501

        List all policies  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.policies_list_with_http_info(async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str account_identifier: Harness account ID
        :param str org_identifier: Harness organization ID
        :param str project_identifier: Harness project ID
        :param int per_page: Number of results per page
        :param int page: Page number (starting from 0)
        :param str identifier_filter: Comma separated List of Identifiers to filter on
        :param str search_term: Filter results by partial name match
        :param str sort: Sort order for results
        :param bool exclude_rego_from_response: Set to true to exclude Rego content from the response
        :param bool include_policy_set_count: Set to true to include the count of policy sets associated with each policy in the response
        :param str x_api_key: Harness PAT key used to perform authorization
        :return: list[PolicyManagementPolicy]
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['account_identifier', 'org_identifier', 'project_identifier', 'per_page', 'page', 'identifier_filter', 'search_term', 'sort', 'exclude_rego_from_response', 'include_policy_set_count', 'x_api_key']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method policies_list" % key
                )
            params[key] = val
        del params['kwargs']

        collection_formats = {}

        path_params = {}

        query_params = []
        if 'account_identifier' in params:
            query_params.append(('accountIdentifier', params['account_identifier']))  # noqa: E501
        if 'org_identifier' in params:
            query_params.append(('orgIdentifier', params['org_identifier']))  # noqa: E501
        if 'project_identifier' in params:
            query_params.append(('projectIdentifier', params['project_identifier']))  # noqa: E501
        if 'per_page' in params:
            query_params.append(('per_page', params['per_page']))  # noqa: E501
        if 'page' in params:
            query_params.append(('page', params['page']))  # noqa: E501
        if 'identifier_filter' in params:
            query_params.append(('identifierFilter', params['identifier_filter']))  # noqa: E501
        if 'search_term' in params:
            query_params.append(('searchTerm', params['search_term']))  # noqa: E501
        if 'sort' in params:
            query_params.append(('sort', params['sort']))  # noqa: E501
        if 'exclude_rego_from_response' in params:
            query_params.append(('excludeRegoFromResponse', params['exclude_rego_from_response']))  # noqa: E501
        if 'include_policy_set_count' in params:
            query_params.append(('includePolicySetCount', params['include_policy_set_count']))  # noqa: E501

        header_params = {}
        if 'x_api_key' in params:
            header_params['x-api-key'] = params['x_api_key']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json', 'application/vnd.goa.error'])  # noqa: E501

        # Authentication setting
        auth_settings = ['x-api-key']  # noqa: E501

        return self.api_client.call_api(
            '/pm/api/v1/policies', 'GET',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='list[PolicyManagementPolicy]',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def policies_list_policy_sets(self, identifier, **kwargs):  # noqa: E501
        """policies_list_policy_sets  # noqa: E501

        List all policy sets that reference a specific policy  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.policies_list_policy_sets(identifier, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str identifier: Identifier for the policy (required)
        :param str account_identifier: Harness account ID
        :param str org_identifier: Harness organization ID
        :param str project_identifier: Harness project ID
        :param int per_page: Number of results per page
        :param int page: Page number (starting from 0)
        :param str search_term: Filter results by partial name match
        :param str sort: Sort order for results
        :param str x_api_key: Harness PAT key used to perform authorization
        :return: list[PolicyToPolicySet]
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.policies_list_policy_sets_with_http_info(identifier, **kwargs)  # noqa: E501
        else:
            (data) = self.policies_list_policy_sets_with_http_info(identifier, **kwargs)  # noqa: E501
            return data

    def policies_list_policy_sets_with_http_info(self, identifier, **kwargs):  # noqa: E501
        """policies_list_policy_sets  # noqa: E501

        List all policy sets that reference a specific policy  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.policies_list_policy_sets_with_http_info(identifier, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str identifier: Identifier for the policy (required)
        :param str account_identifier: Harness account ID
        :param str org_identifier: Harness organization ID
        :param str project_identifier: Harness project ID
        :param int per_page: Number of results per page
        :param int page: Page number (starting from 0)
        :param str search_term: Filter results by partial name match
        :param str sort: Sort order for results
        :param str x_api_key: Harness PAT key used to perform authorization
        :return: list[PolicyToPolicySet]
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['identifier', 'account_identifier', 'org_identifier', 'project_identifier', 'per_page', 'page', 'search_term', 'sort', 'x_api_key']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method policies_list_policy_sets" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'identifier' is set
        if ('identifier' not in params or
                params['identifier'] is None):
            raise ValueError("Missing the required parameter `identifier` when calling `policies_list_policy_sets`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'identifier' in params:
            path_params['identifier'] = params['identifier']  # noqa: E501

        query_params = []
        if 'account_identifier' in params:
            query_params.append(('accountIdentifier', params['account_identifier']))  # noqa: E501
        if 'org_identifier' in params:
            query_params.append(('orgIdentifier', params['org_identifier']))  # noqa: E501
        if 'project_identifier' in params:
            query_params.append(('projectIdentifier', params['project_identifier']))  # noqa: E501
        if 'per_page' in params:
            query_params.append(('per_page', params['per_page']))  # noqa: E501
        if 'page' in params:
            query_params.append(('page', params['page']))  # noqa: E501
        if 'search_term' in params:
            query_params.append(('searchTerm', params['search_term']))  # noqa: E501
        if 'sort' in params:
            query_params.append(('sort', params['sort']))  # noqa: E501

        header_params = {}
        if 'x_api_key' in params:
            header_params['x-api-key'] = params['x_api_key']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json', 'application/vnd.goa.error'])  # noqa: E501

        # Authentication setting
        auth_settings = ['x-api-key']  # noqa: E501

        return self.api_client.call_api(
            '/pm/api/v1/policies/{identifier}/policysets', 'GET',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='list[PolicyToPolicySet]',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def policies_update(self, body, identifier, **kwargs):  # noqa: E501
        """policies_update  # noqa: E501

        Update a policy by identifier  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.policies_update(body, identifier, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param UpdateRequestBody body: (required)
        :param str identifier: Identifier of the policy (required)
        :param str x_api_key: Harness PAT key used to perform authorization
        :param str git_commit_msg: The commit message used in git when creating the policy
        :param bool git_is_new_branch: A flag to determine if the api should try and commit to a new branch
        :param str git_base_branch: If committing to a new branch, git_base_branch tells the api which branch to base the new branch from
        :param str git_branch: The git branch the policy resides in
        :param str git_commit_sha: The existing commit sha of the file being updated
        :param str git_file_id: The existing file id of the file being updated, not required for bitbucket files
        :param str account_identifier: Harness account ID
        :param str org_identifier: Harness organization ID
        :param str project_identifier: Harness project ID
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.policies_update_with_http_info(body, identifier, **kwargs)  # noqa: E501
        else:
            (data) = self.policies_update_with_http_info(body, identifier, **kwargs)  # noqa: E501
            return data

    def policies_update_with_http_info(self, body, identifier, **kwargs):  # noqa: E501
        """policies_update  # noqa: E501

        Update a policy by identifier  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.policies_update_with_http_info(body, identifier, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param UpdateRequestBody body: (required)
        :param str identifier: Identifier of the policy (required)
        :param str x_api_key: Harness PAT key used to perform authorization
        :param str git_commit_msg: The commit message used in git when creating the policy
        :param bool git_is_new_branch: A flag to determine if the api should try and commit to a new branch
        :param str git_base_branch: If committing to a new branch, git_base_branch tells the api which branch to base the new branch from
        :param str git_branch: The git branch the policy resides in
        :param str git_commit_sha: The existing commit sha of the file being updated
        :param str git_file_id: The existing file id of the file being updated, not required for bitbucket files
        :param str account_identifier: Harness account ID
        :param str org_identifier: Harness organization ID
        :param str project_identifier: Harness project ID
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['body', 'identifier', 'x_api_key', 'git_commit_msg', 'git_is_new_branch', 'git_base_branch', 'git_branch', 'git_commit_sha', 'git_file_id', 'account_identifier', 'org_identifier', 'project_identifier']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method policies_update" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'body' is set
        if ('body' not in params or
                params['body'] is None):
            raise ValueError("Missing the required parameter `body` when calling `policies_update`")  # noqa: E501
        # verify the required parameter 'identifier' is set
        if ('identifier' not in params or
                params['identifier'] is None):
            raise ValueError("Missing the required parameter `identifier` when calling `policies_update`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'identifier' in params:
            path_params['identifier'] = params['identifier']  # noqa: E501

        query_params = []
        if 'git_commit_msg' in params:
            query_params.append(('git_commit_msg', params['git_commit_msg']))  # noqa: E501
        if 'git_is_new_branch' in params:
            query_params.append(('git_is_new_branch', params['git_is_new_branch']))  # noqa: E501
        if 'git_base_branch' in params:
            query_params.append(('git_base_branch', params['git_base_branch']))  # noqa: E501
        if 'git_branch' in params:
            query_params.append(('git_branch', params['git_branch']))  # noqa: E501
        if 'git_commit_sha' in params:
            query_params.append(('git_commit_sha', params['git_commit_sha']))  # noqa: E501
        if 'git_file_id' in params:
            query_params.append(('git_file_id', params['git_file_id']))  # noqa: E501
        if 'account_identifier' in params:
            query_params.append(('accountIdentifier', params['account_identifier']))  # noqa: E501
        if 'org_identifier' in params:
            query_params.append(('orgIdentifier', params['org_identifier']))  # noqa: E501
        if 'project_identifier' in params:
            query_params.append(('projectIdentifier', params['project_identifier']))  # noqa: E501

        header_params = {}
        if 'x_api_key' in params:
            header_params['x-api-key'] = params['x_api_key']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        if 'body' in params:
            body_params = params['body']
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json', 'application/vnd.goa.error'])  # noqa: E501

        # HTTP header `Content-Type`
        header_params['Content-Type'] = self.api_client.select_header_content_type(  # noqa: E501
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['x-api-key']  # noqa: E501

        return self.api_client.call_api(
            '/pm/api/v1/policies/{identifier}', 'PATCH',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type=None,  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)
