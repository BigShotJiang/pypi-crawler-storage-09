# coding: utf-8

"""
    Harness NextGen Software Delivery Platform API Reference

    The Harness Software Delivery Platform uses OpenAPI Specification v3.0. Harness constantly improves these APIs. Please be aware that some improvements could cause breaking changes. # Introduction     The Harness API allows you to integrate and use all the services and modules we provide on the Harness Platform. If you use client-side SDKs, Harness functionality can be integrated with your client-side automation, helping you reduce manual efforts and deploy code faster.    For more information about how Harness works, read our [documentation](https://developer.harness.io/docs/getting-started) or visit the [Harness Developer Hub](https://developer.harness.io/).  ## How it works    The Harness API is a RESTful API that uses standard HTTP verbs. You can send requests in JSON, YAML, or form-data format. The format of the response matches the format of your request. You must send a single request at a time and ensure that you include your authentication key. For more information about this, go to [Authentication](#section/Introduction/Authentication).  ## Get started    Before you start integrating, get to know our API better by reading the following topics:    * [Harness key concepts](https://developer.harness.io/docs/getting-started/learn-harness-key-concepts/)   * [Authentication](#section/Introduction/Authentication)   * [Requests and responses](#section/Introduction/Requests-and-Responses)   * [Common Parameters](#section/Introduction/Common-Parameters-Beta)   * [Status Codes](#section/Introduction/Status-Codes)   * [Errors](#tag/Error-Response)   * [Versioning](#section/Introduction/Versioning-Beta)   * [Pagination](/#section/Introduction/Pagination-Beta)    The methods you need to integrate with depend on the functionality you want to use. Work with  your Harness Solutions Engineer to determine which methods you need.  ## Authentication  To authenticate with the Harness API, you need to:   1. Generate an API token on the Harness Platform.   2. Send the API token you generate in the `x-api-key` header in each request.  ### Generate an API token  To generate an API token, complete the following steps:   1. Go to the [Harness Platform](https://app.harness.io/).   2. On the left-hand navigation, click **My Profile**.   3. Click **+API Key**, enter a name for your key and then click **Save**.   4. Within the API Key tile, click **+Token**.   5. Enter a name for your token and click **Generate Token**. **Important**: Make sure to save your token securely. Harness does not store the API token for future reference, so make sure to save your token securely before you leave the page.  ### Send the API token in your requests  Send the token you created in the Harness Platform in the x-api-key header. For example:   `x-api-key: YOUR_API_KEY_HERE`  ## Requests and Responses    The structure for each request and response is outlined in the API documentation. We have examples in JSON and YAML for every request and response. You can use our online editor to test the examples.  ## Common Parameters [Beta]  | Field Name | Type    | Default | Description    | |------------|---------|---------|----------------| | identifier | string  | none    | URL-friendly version of the name, used to identify a resource within it's scope and so needs to be unique within the scope.                                                                                                            | | name       | string  | none    | Human-friendly name for the resource.                                                                                       | | org        | string  | none    | Limit to provided org identifiers.                                                                                                                     | | project    | string  | none    | Limit to provided project identifiers.                                                                                                                 | | description| string  | none    | More information about the specific resource.                                                                                    | | tags       | map[string]string  | none    | List of labels applied to the resource.                                                                                                                         | | order      | string  | desc    | Order to use when sorting the specified fields. Type: enum(asc,desc).                                                                                                                                     | | sort       | string  | none    | Fields on which to sort. Note: Specify the fields that you want to use for sorting. When doing so, consider the operational overhead of sorting fields. | | limit      | int     | 30      | Pagination: Number of items to return.                                                                                                                 | | page       | int     | 1       | Pagination page number strategy: Specify the page number within the paginated collection related to the number of items in each page.                  | | created    | int64   | none    | Unix timestamp that shows when the resource was created (in milliseconds).                                                               | | updated    | int64   | none    | Unix timestamp that shows when the resource was last edited (in milliseconds).                                                           |   ## Status Codes    Harness uses conventional HTTP status codes to indicate the status of an API request.    Generally, 2xx responses are reserved for success and 4xx status codes are reserved for failures. A 5xx response code indicates an error on the Harness server.    | Error Code  | Description |   |-------------|-------------|   | 200         |     OK      |   | 201         |   Created   |   | 202         |   Accepted  |   | 204         |  No Content |   | 400         | Bad Request |   | 401         | Unauthorized |   | 403         | Forbidden |   | 412         | Precondition Failed |   | 415         | Unsupported Media Type |   | 500         | Server Error |    To view our error response structures, go [here](#tag/Error-Response).  ## Versioning [Beta]  ### Harness Version   The current version of our Beta APIs is yet to be announced. The version number will use the date-header format and will be valid only for our Beta APIs.  ### Generation   All our beta APIs are versioned as a Generation, and this version is included in the path to every API resource. For example, v1 beta APIs begin with `app.harness.io/v1/`, where v1 is the API Generation.    The version number represents the core API and does not change frequently. The version number changes only if there is a significant departure from the basic underpinnings of the existing API. For example, when Harness performs a system-wide refactoring of core concepts or resources.  ## Pagination [Beta]  We use pagination to place limits on the number of responses associated with list endpoints. Pagination is achieved by the use of limit query parameters. The limit defaults to 30. Its maximum value is 100.  Following are the pagination headers supported in the response bodies of paginated APIs:   1. X-Total-Elements : Indicates the total number of entries in a paginated response.   2. X-Page-Number : Indicates the page number currently returned for a paginated response.   3. X-Page-Size : Indicates the number of entries per page for a paginated response.  For example:    ``` X-Total-Elements : 30 X-Page-Number : 0 X-Page-Size : 10   ```   # noqa: E501

    OpenAPI spec version: 1.0
    Contact: contact@harness.io
    Generated by: https://github.com/swagger-api/swagger-codegen.git
"""

import pprint
import re  # noqa: F401

import six

class AbstractServiceLevelObjective(object):
    """NOTE: This class is auto generated by the swagger code generator program.

    Do not edit the class manually.
    """
    """
    Attributes:
      swagger_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    swagger_types = {
        'description': 'str',
        'error_budget_calculation_period': 'int',
        'error_budget_calculation_validity': 'int',
        'identifier': 'str',
        'name': 'str',
        'notification_rule_refs': 'list[NotificationRuleRefDTO]',
        'org_identifier': 'str',
        'project_identifier': 'str',
        'slo_target': 'SLOTargetDTO',
        'spec': 'ServiceLevelObjectiveSpec',
        'tags': 'dict(str, str)',
        'type': 'str',
        'user_journey_refs': 'list[str]'
    }

    attribute_map = {
        'description': 'description',
        'error_budget_calculation_period': 'errorBudgetCalculationPeriod',
        'error_budget_calculation_validity': 'errorBudgetCalculationValidity',
        'identifier': 'identifier',
        'name': 'name',
        'notification_rule_refs': 'notificationRuleRefs',
        'org_identifier': 'orgIdentifier',
        'project_identifier': 'projectIdentifier',
        'slo_target': 'sloTarget',
        'spec': 'spec',
        'tags': 'tags',
        'type': 'type',
        'user_journey_refs': 'userJourneyRefs'
    }

    def __init__(self, description=None, error_budget_calculation_period=None, error_budget_calculation_validity=None, identifier=None, name=None, notification_rule_refs=None, org_identifier=None, project_identifier=None, slo_target=None, spec=None, tags=None, type=None, user_journey_refs=None):  # noqa: E501
        """AbstractServiceLevelObjective - a model defined in Swagger"""  # noqa: E501
        self._description = None
        self._error_budget_calculation_period = None
        self._error_budget_calculation_validity = None
        self._identifier = None
        self._name = None
        self._notification_rule_refs = None
        self._org_identifier = None
        self._project_identifier = None
        self._slo_target = None
        self._spec = None
        self._tags = None
        self._type = None
        self._user_journey_refs = None
        self.discriminator = None
        if description is not None:
            self.description = description
        if error_budget_calculation_period is not None:
            self.error_budget_calculation_period = error_budget_calculation_period
        if error_budget_calculation_validity is not None:
            self.error_budget_calculation_validity = error_budget_calculation_validity
        self.identifier = identifier
        self.name = name
        if notification_rule_refs is not None:
            self.notification_rule_refs = notification_rule_refs
        if org_identifier is not None:
            self.org_identifier = org_identifier
        if project_identifier is not None:
            self.project_identifier = project_identifier
        self.slo_target = slo_target
        self.spec = spec
        if tags is not None:
            self.tags = tags
        self.type = type
        self.user_journey_refs = user_journey_refs

    @property
    def description(self):
        """Gets the description of this AbstractServiceLevelObjective.  # noqa: E501


        :return: The description of this AbstractServiceLevelObjective.  # noqa: E501
        :rtype: str
        """
        return self._description

    @description.setter
    def description(self, description):
        """Sets the description of this AbstractServiceLevelObjective.


        :param description: The description of this AbstractServiceLevelObjective.  # noqa: E501
        :type: str
        """

        self._description = description

    @property
    def error_budget_calculation_period(self):
        """Gets the error_budget_calculation_period of this AbstractServiceLevelObjective.  # noqa: E501


        :return: The error_budget_calculation_period of this AbstractServiceLevelObjective.  # noqa: E501
        :rtype: int
        """
        return self._error_budget_calculation_period

    @error_budget_calculation_period.setter
    def error_budget_calculation_period(self, error_budget_calculation_period):
        """Sets the error_budget_calculation_period of this AbstractServiceLevelObjective.


        :param error_budget_calculation_period: The error_budget_calculation_period of this AbstractServiceLevelObjective.  # noqa: E501
        :type: int
        """

        self._error_budget_calculation_period = error_budget_calculation_period

    @property
    def error_budget_calculation_validity(self):
        """Gets the error_budget_calculation_validity of this AbstractServiceLevelObjective.  # noqa: E501


        :return: The error_budget_calculation_validity of this AbstractServiceLevelObjective.  # noqa: E501
        :rtype: int
        """
        return self._error_budget_calculation_validity

    @error_budget_calculation_validity.setter
    def error_budget_calculation_validity(self, error_budget_calculation_validity):
        """Sets the error_budget_calculation_validity of this AbstractServiceLevelObjective.


        :param error_budget_calculation_validity: The error_budget_calculation_validity of this AbstractServiceLevelObjective.  # noqa: E501
        :type: int
        """

        self._error_budget_calculation_validity = error_budget_calculation_validity

    @property
    def identifier(self):
        """Gets the identifier of this AbstractServiceLevelObjective.  # noqa: E501


        :return: The identifier of this AbstractServiceLevelObjective.  # noqa: E501
        :rtype: str
        """
        return self._identifier

    @identifier.setter
    def identifier(self, identifier):
        """Sets the identifier of this AbstractServiceLevelObjective.


        :param identifier: The identifier of this AbstractServiceLevelObjective.  # noqa: E501
        :type: str
        """
        if identifier is None:
            raise ValueError("Invalid value for `identifier`, must not be `None`")  # noqa: E501

        self._identifier = identifier

    @property
    def name(self):
        """Gets the name of this AbstractServiceLevelObjective.  # noqa: E501


        :return: The name of this AbstractServiceLevelObjective.  # noqa: E501
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        """Sets the name of this AbstractServiceLevelObjective.


        :param name: The name of this AbstractServiceLevelObjective.  # noqa: E501
        :type: str
        """
        if name is None:
            raise ValueError("Invalid value for `name`, must not be `None`")  # noqa: E501

        self._name = name

    @property
    def notification_rule_refs(self):
        """Gets the notification_rule_refs of this AbstractServiceLevelObjective.  # noqa: E501


        :return: The notification_rule_refs of this AbstractServiceLevelObjective.  # noqa: E501
        :rtype: list[NotificationRuleRefDTO]
        """
        return self._notification_rule_refs

    @notification_rule_refs.setter
    def notification_rule_refs(self, notification_rule_refs):
        """Sets the notification_rule_refs of this AbstractServiceLevelObjective.


        :param notification_rule_refs: The notification_rule_refs of this AbstractServiceLevelObjective.  # noqa: E501
        :type: list[NotificationRuleRefDTO]
        """

        self._notification_rule_refs = notification_rule_refs

    @property
    def org_identifier(self):
        """Gets the org_identifier of this AbstractServiceLevelObjective.  # noqa: E501


        :return: The org_identifier of this AbstractServiceLevelObjective.  # noqa: E501
        :rtype: str
        """
        return self._org_identifier

    @org_identifier.setter
    def org_identifier(self, org_identifier):
        """Sets the org_identifier of this AbstractServiceLevelObjective.


        :param org_identifier: The org_identifier of this AbstractServiceLevelObjective.  # noqa: E501
        :type: str
        """

        self._org_identifier = org_identifier

    @property
    def project_identifier(self):
        """Gets the project_identifier of this AbstractServiceLevelObjective.  # noqa: E501


        :return: The project_identifier of this AbstractServiceLevelObjective.  # noqa: E501
        :rtype: str
        """
        return self._project_identifier

    @project_identifier.setter
    def project_identifier(self, project_identifier):
        """Sets the project_identifier of this AbstractServiceLevelObjective.


        :param project_identifier: The project_identifier of this AbstractServiceLevelObjective.  # noqa: E501
        :type: str
        """

        self._project_identifier = project_identifier

    @property
    def slo_target(self):
        """Gets the slo_target of this AbstractServiceLevelObjective.  # noqa: E501


        :return: The slo_target of this AbstractServiceLevelObjective.  # noqa: E501
        :rtype: SLOTargetDTO
        """
        return self._slo_target

    @slo_target.setter
    def slo_target(self, slo_target):
        """Sets the slo_target of this AbstractServiceLevelObjective.


        :param slo_target: The slo_target of this AbstractServiceLevelObjective.  # noqa: E501
        :type: SLOTargetDTO
        """
        if slo_target is None:
            raise ValueError("Invalid value for `slo_target`, must not be `None`")  # noqa: E501

        self._slo_target = slo_target

    @property
    def spec(self):
        """Gets the spec of this AbstractServiceLevelObjective.  # noqa: E501


        :return: The spec of this AbstractServiceLevelObjective.  # noqa: E501
        :rtype: ServiceLevelObjectiveSpec
        """
        return self._spec

    @spec.setter
    def spec(self, spec):
        """Sets the spec of this AbstractServiceLevelObjective.


        :param spec: The spec of this AbstractServiceLevelObjective.  # noqa: E501
        :type: ServiceLevelObjectiveSpec
        """
        if spec is None:
            raise ValueError("Invalid value for `spec`, must not be `None`")  # noqa: E501

        self._spec = spec

    @property
    def tags(self):
        """Gets the tags of this AbstractServiceLevelObjective.  # noqa: E501


        :return: The tags of this AbstractServiceLevelObjective.  # noqa: E501
        :rtype: dict(str, str)
        """
        return self._tags

    @tags.setter
    def tags(self, tags):
        """Sets the tags of this AbstractServiceLevelObjective.


        :param tags: The tags of this AbstractServiceLevelObjective.  # noqa: E501
        :type: dict(str, str)
        """

        self._tags = tags

    @property
    def type(self):
        """Gets the type of this AbstractServiceLevelObjective.  # noqa: E501


        :return: The type of this AbstractServiceLevelObjective.  # noqa: E501
        :rtype: str
        """
        return self._type

    @type.setter
    def type(self, type):
        """Sets the type of this AbstractServiceLevelObjective.


        :param type: The type of this AbstractServiceLevelObjective.  # noqa: E501
        :type: str
        """
        if type is None:
            raise ValueError("Invalid value for `type`, must not be `None`")  # noqa: E501
        allowed_values = ["Simple", "Composite"]  # noqa: E501
        if type not in allowed_values:
            raise ValueError(
                "Invalid value for `type` ({0}), must be one of {1}"  # noqa: E501
                .format(type, allowed_values)
            )

        self._type = type

    @property
    def user_journey_refs(self):
        """Gets the user_journey_refs of this AbstractServiceLevelObjective.  # noqa: E501


        :return: The user_journey_refs of this AbstractServiceLevelObjective.  # noqa: E501
        :rtype: list[str]
        """
        return self._user_journey_refs

    @user_journey_refs.setter
    def user_journey_refs(self, user_journey_refs):
        """Sets the user_journey_refs of this AbstractServiceLevelObjective.


        :param user_journey_refs: The user_journey_refs of this AbstractServiceLevelObjective.  # noqa: E501
        :type: list[str]
        """
        if user_journey_refs is None:
            raise ValueError("Invalid value for `user_journey_refs`, must not be `None`")  # noqa: E501

        self._user_journey_refs = user_journey_refs

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.swagger_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(AbstractServiceLevelObjective, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, AbstractServiceLevelObjective):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
