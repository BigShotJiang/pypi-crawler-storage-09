# coding: utf-8

"""
    Harness NextGen Software Delivery Platform API Reference

    The Harness Software Delivery Platform uses OpenAPI Specification v3.0. Harness constantly improves these APIs. Please be aware that some improvements could cause breaking changes. # Introduction     The Harness API allows you to integrate and use all the services and modules we provide on the Harness Platform. If you use client-side SDKs, Harness functionality can be integrated with your client-side automation, helping you reduce manual efforts and deploy code faster.    For more information about how Harness works, read our [documentation](https://developer.harness.io/docs/getting-started) or visit the [Harness Developer Hub](https://developer.harness.io/).  ## How it works    The Harness API is a RESTful API that uses standard HTTP verbs. You can send requests in JSON, YAML, or form-data format. The format of the response matches the format of your request. You must send a single request at a time and ensure that you include your authentication key. For more information about this, go to [Authentication](#section/Introduction/Authentication).  ## Get started    Before you start integrating, get to know our API better by reading the following topics:    * [Harness key concepts](https://developer.harness.io/docs/getting-started/learn-harness-key-concepts/)   * [Authentication](#section/Introduction/Authentication)   * [Requests and responses](#section/Introduction/Requests-and-Responses)   * [Common Parameters](#section/Introduction/Common-Parameters-Beta)   * [Status Codes](#section/Introduction/Status-Codes)   * [Errors](#tag/Error-Response)   * [Versioning](#section/Introduction/Versioning-Beta)   * [Pagination](/#section/Introduction/Pagination-Beta)    The methods you need to integrate with depend on the functionality you want to use. Work with  your Harness Solutions Engineer to determine which methods you need.  ## Authentication  To authenticate with the Harness API, you need to:   1. Generate an API token on the Harness Platform.   2. Send the API token you generate in the `x-api-key` header in each request.  ### Generate an API token  To generate an API token, complete the following steps:   1. Go to the [Harness Platform](https://app.harness.io/).   2. On the left-hand navigation, click **My Profile**.   3. Click **+API Key**, enter a name for your key and then click **Save**.   4. Within the API Key tile, click **+Token**.   5. Enter a name for your token and click **Generate Token**. **Important**: Make sure to save your token securely. Harness does not store the API token for future reference, so make sure to save your token securely before you leave the page.  ### Send the API token in your requests  Send the token you created in the Harness Platform in the x-api-key header. For example:   `x-api-key: YOUR_API_KEY_HERE`  ## Requests and Responses    The structure for each request and response is outlined in the API documentation. We have examples in JSON and YAML for every request and response. You can use our online editor to test the examples.  ## Common Parameters [Beta]  | Field Name | Type    | Default | Description    | |------------|---------|---------|----------------| | identifier | string  | none    | URL-friendly version of the name, used to identify a resource within it's scope and so needs to be unique within the scope.                                                                                                            | | name       | string  | none    | Human-friendly name for the resource.                                                                                       | | org        | string  | none    | Limit to provided org identifiers.                                                                                                                     | | project    | string  | none    | Limit to provided project identifiers.                                                                                                                 | | description| string  | none    | More information about the specific resource.                                                                                    | | tags       | map[string]string  | none    | List of labels applied to the resource.                                                                                                                         | | order      | string  | desc    | Order to use when sorting the specified fields. Type: enum(asc,desc).                                                                                                                                     | | sort       | string  | none    | Fields on which to sort. Note: Specify the fields that you want to use for sorting. When doing so, consider the operational overhead of sorting fields. | | limit      | int     | 30      | Pagination: Number of items to return.                                                                                                                 | | page       | int     | 1       | Pagination page number strategy: Specify the page number within the paginated collection related to the number of items in each page.                  | | created    | int64   | none    | Unix timestamp that shows when the resource was created (in milliseconds).                                                               | | updated    | int64   | none    | Unix timestamp that shows when the resource was last edited (in milliseconds).                                                           |   ## Status Codes    Harness uses conventional HTTP status codes to indicate the status of an API request.    Generally, 2xx responses are reserved for success and 4xx status codes are reserved for failures. A 5xx response code indicates an error on the Harness server.    | Error Code  | Description |   |-------------|-------------|   | 200         |     OK      |   | 201         |   Created   |   | 202         |   Accepted  |   | 204         |  No Content |   | 400         | Bad Request |   | 401         | Unauthorized |   | 403         | Forbidden |   | 412         | Precondition Failed |   | 415         | Unsupported Media Type |   | 500         | Server Error |    To view our error response structures, go [here](#tag/Error-Response).  ## Versioning [Beta]  ### Harness Version   The current version of our Beta APIs is yet to be announced. The version number will use the date-header format and will be valid only for our Beta APIs.  ### Generation   All our beta APIs are versioned as a Generation, and this version is included in the path to every API resource. For example, v1 beta APIs begin with `app.harness.io/v1/`, where v1 is the API Generation.    The version number represents the core API and does not change frequently. The version number changes only if there is a significant departure from the basic underpinnings of the existing API. For example, when Harness performs a system-wide refactoring of core concepts or resources.  ## Pagination [Beta]  We use pagination to place limits on the number of responses associated with list endpoints. Pagination is achieved by the use of limit query parameters. The limit defaults to 30. Its maximum value is 100.  Following are the pagination headers supported in the response bodies of paginated APIs:   1. X-Total-Elements : Indicates the total number of entries in a paginated response.   2. X-Page-Number : Indicates the page number currently returned for a paginated response.   3. X-Page-Size : Indicates the number of entries per page for a paginated response.  For example:    ``` X-Total-Elements : 30 X-Page-Number : 0 X-Page-Size : 10   ```   # noqa: E501

    OpenAPI spec version: 1.0
    Contact: contact@harness.io
    Generated by: https://github.com/swagger-api/swagger-codegen.git
"""

import pprint
import re  # noqa: F401

import six

class AllIssuesListRequestBody(object):
    """NOTE: This class is auto generated by the swagger code generator program.

    Do not edit the class manually.
    """
    """
    Attributes:
      swagger_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    swagger_types = {
        'artifact_fingerprints': 'list[str]',
        'issue_types': 'str',
        'page': 'int',
        'page_size': 'int',
        'scan_tools': 'str',
        'search': 'str',
        'severity_codes': 'str',
        'target_names': 'str',
        'target_types': 'str',
        'target_variants': 'list[TargetAndVariantNameRequired]'
    }

    attribute_map = {
        'artifact_fingerprints': 'artifactFingerprints',
        'issue_types': 'issueTypes',
        'page': 'page',
        'page_size': 'pageSize',
        'scan_tools': 'scanTools',
        'search': 'search',
        'severity_codes': 'severityCodes',
        'target_names': 'targetNames',
        'target_types': 'targetTypes',
        'target_variants': 'targetVariants'
    }

    def __init__(self, artifact_fingerprints=None, issue_types=None, page=0, page_size=30, scan_tools=None, search=None, severity_codes=None, target_names=None, target_types=None, target_variants=None):  # noqa: E501
        """AllIssuesListRequestBody - a model defined in Swagger"""  # noqa: E501
        self._artifact_fingerprints = None
        self._issue_types = None
        self._page = None
        self._page_size = None
        self._scan_tools = None
        self._search = None
        self._severity_codes = None
        self._target_names = None
        self._target_types = None
        self._target_variants = None
        self.discriminator = None
        if artifact_fingerprints is not None:
            self.artifact_fingerprints = artifact_fingerprints
        if issue_types is not None:
            self.issue_types = issue_types
        if page is not None:
            self.page = page
        if page_size is not None:
            self.page_size = page_size
        if scan_tools is not None:
            self.scan_tools = scan_tools
        if search is not None:
            self.search = search
        if severity_codes is not None:
            self.severity_codes = severity_codes
        if target_names is not None:
            self.target_names = target_names
        if target_types is not None:
            self.target_types = target_types
        if target_variants is not None:
            self.target_variants = target_variants

    @property
    def artifact_fingerprints(self):
        """Gets the artifact_fingerprints of this AllIssuesListRequestBody.  # noqa: E501

        Artifact fingerprints for lookup  # noqa: E501

        :return: The artifact_fingerprints of this AllIssuesListRequestBody.  # noqa: E501
        :rtype: list[str]
        """
        return self._artifact_fingerprints

    @artifact_fingerprints.setter
    def artifact_fingerprints(self, artifact_fingerprints):
        """Sets the artifact_fingerprints of this AllIssuesListRequestBody.

        Artifact fingerprints for lookup  # noqa: E501

        :param artifact_fingerprints: The artifact_fingerprints of this AllIssuesListRequestBody.  # noqa: E501
        :type: list[str]
        """

        self._artifact_fingerprints = artifact_fingerprints

    @property
    def issue_types(self):
        """Gets the issue_types of this AllIssuesListRequestBody.  # noqa: E501


        :return: The issue_types of this AllIssuesListRequestBody.  # noqa: E501
        :rtype: str
        """
        return self._issue_types

    @issue_types.setter
    def issue_types(self, issue_types):
        """Sets the issue_types of this AllIssuesListRequestBody.


        :param issue_types: The issue_types of this AllIssuesListRequestBody.  # noqa: E501
        :type: str
        """

        self._issue_types = issue_types

    @property
    def page(self):
        """Gets the page of this AllIssuesListRequestBody.  # noqa: E501

        Page number to fetch (starting from 0)  # noqa: E501

        :return: The page of this AllIssuesListRequestBody.  # noqa: E501
        :rtype: int
        """
        return self._page

    @page.setter
    def page(self, page):
        """Sets the page of this AllIssuesListRequestBody.

        Page number to fetch (starting from 0)  # noqa: E501

        :param page: The page of this AllIssuesListRequestBody.  # noqa: E501
        :type: int
        """

        self._page = page

    @property
    def page_size(self):
        """Gets the page_size of this AllIssuesListRequestBody.  # noqa: E501

        Number of results per page  # noqa: E501

        :return: The page_size of this AllIssuesListRequestBody.  # noqa: E501
        :rtype: int
        """
        return self._page_size

    @page_size.setter
    def page_size(self, page_size):
        """Sets the page_size of this AllIssuesListRequestBody.

        Number of results per page  # noqa: E501

        :param page_size: The page_size of this AllIssuesListRequestBody.  # noqa: E501
        :type: int
        """

        self._page_size = page_size

    @property
    def scan_tools(self):
        """Gets the scan_tools of this AllIssuesListRequestBody.  # noqa: E501


        :return: The scan_tools of this AllIssuesListRequestBody.  # noqa: E501
        :rtype: str
        """
        return self._scan_tools

    @scan_tools.setter
    def scan_tools(self, scan_tools):
        """Sets the scan_tools of this AllIssuesListRequestBody.


        :param scan_tools: The scan_tools of this AllIssuesListRequestBody.  # noqa: E501
        :type: str
        """

        self._scan_tools = scan_tools

    @property
    def search(self):
        """Gets the search of this AllIssuesListRequestBody.  # noqa: E501


        :return: The search of this AllIssuesListRequestBody.  # noqa: E501
        :rtype: str
        """
        return self._search

    @search.setter
    def search(self, search):
        """Sets the search of this AllIssuesListRequestBody.


        :param search: The search of this AllIssuesListRequestBody.  # noqa: E501
        :type: str
        """

        self._search = search

    @property
    def severity_codes(self):
        """Gets the severity_codes of this AllIssuesListRequestBody.  # noqa: E501


        :return: The severity_codes of this AllIssuesListRequestBody.  # noqa: E501
        :rtype: str
        """
        return self._severity_codes

    @severity_codes.setter
    def severity_codes(self, severity_codes):
        """Sets the severity_codes of this AllIssuesListRequestBody.


        :param severity_codes: The severity_codes of this AllIssuesListRequestBody.  # noqa: E501
        :type: str
        """

        self._severity_codes = severity_codes

    @property
    def target_names(self):
        """Gets the target_names of this AllIssuesListRequestBody.  # noqa: E501


        :return: The target_names of this AllIssuesListRequestBody.  # noqa: E501
        :rtype: str
        """
        return self._target_names

    @target_names.setter
    def target_names(self, target_names):
        """Sets the target_names of this AllIssuesListRequestBody.


        :param target_names: The target_names of this AllIssuesListRequestBody.  # noqa: E501
        :type: str
        """

        self._target_names = target_names

    @property
    def target_types(self):
        """Gets the target_types of this AllIssuesListRequestBody.  # noqa: E501


        :return: The target_types of this AllIssuesListRequestBody.  # noqa: E501
        :rtype: str
        """
        return self._target_types

    @target_types.setter
    def target_types(self, target_types):
        """Sets the target_types of this AllIssuesListRequestBody.


        :param target_types: The target_types of this AllIssuesListRequestBody.  # noqa: E501
        :type: str
        """

        self._target_types = target_types

    @property
    def target_variants(self):
        """Gets the target_variants of this AllIssuesListRequestBody.  # noqa: E501

        Target-variant pairs for lookup  # noqa: E501

        :return: The target_variants of this AllIssuesListRequestBody.  # noqa: E501
        :rtype: list[TargetAndVariantNameRequired]
        """
        return self._target_variants

    @target_variants.setter
    def target_variants(self, target_variants):
        """Sets the target_variants of this AllIssuesListRequestBody.

        Target-variant pairs for lookup  # noqa: E501

        :param target_variants: The target_variants of this AllIssuesListRequestBody.  # noqa: E501
        :type: list[TargetAndVariantNameRequired]
        """

        self._target_variants = target_variants

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.swagger_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(AllIssuesListRequestBody, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, AllIssuesListRequestBody):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
