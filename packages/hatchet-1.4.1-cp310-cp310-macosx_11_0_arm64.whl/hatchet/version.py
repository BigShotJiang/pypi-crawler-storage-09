# Copyright 2017-2025 Lawrence Livermore National Security, LLC and other
# Hatchet Project Developers. See the top-level LICENSE file for details.
#
# SPDX-License-Identifier: MIT

__version_info__ = ("1", "4", "1")
__version__ = ".".join(__version_info__)
