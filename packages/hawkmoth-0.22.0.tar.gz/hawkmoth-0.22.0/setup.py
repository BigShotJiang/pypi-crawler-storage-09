# SPDX-FileCopyrightText: 2023 Jani Nikula <jani@nikula.org>
# SPDX-License-Identifier: BSD-2-Clause

# setup.py is required for editable installs
import setuptools

setuptools.setup()
