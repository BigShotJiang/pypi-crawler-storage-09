I've found the Cursor rules to be a bit unreliable, so I've moved all of them to straight Markdown .md docs in `docs/`.

My current approach is to create lots of small rules and explicitly reference one or more of them explicitly, but I'm sure this will evolve over time.

e.g.

- Debug problem X, following @scientistic_detective_mode.mdc

- Do X, following `coding_principles.md`. Be in `sounding_board_mode.md`. See also `testing_python.md`

- Write a planning doc for X, following `WRITE_PLANNING_DOC.md`.