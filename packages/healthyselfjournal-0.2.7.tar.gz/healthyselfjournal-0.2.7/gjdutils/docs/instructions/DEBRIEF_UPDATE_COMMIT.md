# Debrief and Commit

Run @docs/instructions/DEBRIEF_PROGRESS.md .

Update the planning doc with your progress.

Then commit these changes, as per docs/instructions/GIT_COMMIT_CHANGES.md .