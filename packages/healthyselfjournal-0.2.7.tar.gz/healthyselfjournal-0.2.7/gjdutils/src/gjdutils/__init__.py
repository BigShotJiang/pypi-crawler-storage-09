"""
GJDutils - A collection of useful utility functions
"""

from gjdutils.__version__ import __version__
