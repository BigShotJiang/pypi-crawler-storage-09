# test_strings.py

# test that jinja_render raises an error if missing variables
