Investigate the codebase, search the web if you need to, ask questions to clarify requirements if you need to, raise concerns if you have them, consider the desiderata/criteria for success, suggest alternatives, weigh up options and trade-offs, point out if you think the user is wrong or see a better way.

Do everything you can to help the user to think this through, and make the best decision.

When asking questions, ask at most a couple at a time, to avoid overwhelming cognitive overload for the user.

Ultrathink.

Don't make changes yet.