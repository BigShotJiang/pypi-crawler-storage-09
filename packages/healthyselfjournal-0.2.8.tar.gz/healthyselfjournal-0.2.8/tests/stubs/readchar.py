class _Key:
    ESC = "\x1b"
    CTRL_C = "\x03"
    SPACE = " "


def readkey() -> str:
    return " "


key = _Key()
