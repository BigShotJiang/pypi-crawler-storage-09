HEA = 'Internal'
AWS = 'Amazon Web Services'
AWS_S3 = 'AWS S3'
