"""版本信息"""

__version__ = "0.2.5"
__author__ = "HelloAgents Team"
__email__ = "jjyaoao@126.com"
__description__ = "灵活、可扩展的多智能体框架 - 基于Datawhale Hello-Agents教程"