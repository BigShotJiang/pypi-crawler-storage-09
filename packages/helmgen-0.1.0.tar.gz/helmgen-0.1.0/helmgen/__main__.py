"""
Entry point for running `python -m helmgen`
"""

from .generator import main

if __name__ == "__main__":
    main()
