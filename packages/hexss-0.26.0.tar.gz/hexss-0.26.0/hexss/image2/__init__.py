import hexss

hexss.check_packages('numpy', 'opencv-python', auto_install=True)

from .im import Image
