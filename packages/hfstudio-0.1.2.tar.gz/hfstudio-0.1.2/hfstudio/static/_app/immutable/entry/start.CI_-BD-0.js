import{l as o,a as r}from"../chunks/CZ8RCiuE.js";export{o as load_css,r as start};
