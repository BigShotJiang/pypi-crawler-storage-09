Dynamic Graphs
==============

.. autofunction:: hgraph.map_

See also: :doc:`../concepts/tsd_map_node`

.. autofunction:: hgraph.reduce

.. autofunction:: hgraph.switch_

.. autofunction:: hgraph.mesh_

