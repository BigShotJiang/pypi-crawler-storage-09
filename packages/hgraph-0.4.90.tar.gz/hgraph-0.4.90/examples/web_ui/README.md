for this example to work you need to install the following packages in your conda environment:

```bash
pip install "perspective-python>=2.10.1" pandas tornado
npm install -g @finos/perspective@2.10.1 @finos/perspective-viewer-d3fc@2.10.1 @finos/perspective-viewer-datagrid@2.10.1 @finos/perspective-viewer@2.10.1 @finos/perspective-workspace@2.10.1 perspective-viewer-datagrid-norollups perspective-viewer-summary
```
