"""
Library specific information.
"""

__title__ = "hhru"
__description__ = "HH.ru API library for Python."
__url__ = "https://github.com/kirillzhosul/hhru"
__version__ = "0.1.3"
__author__ = "Kirill Zhosul"
__author_email__ = "kirillzhosul@yandex.com"
__license__ = "MIT"
__copyright__ = "Copyright 2024 Kirill Zhosul"
