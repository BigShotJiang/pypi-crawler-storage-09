API_TARGET_HOST = "https://api.hh.ru"
API_USER_AGENT = "hhru_python_lib / https://github.com/kirillzhosul/hhru"
