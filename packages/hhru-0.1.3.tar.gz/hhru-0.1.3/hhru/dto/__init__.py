from .vacancy import VacancyDTO

__all__ = ["VacancyDTO"]
