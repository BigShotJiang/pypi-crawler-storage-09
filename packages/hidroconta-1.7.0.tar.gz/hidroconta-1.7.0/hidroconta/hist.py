class Hist:
    
    def __init__(self, timestamp = 0, value = 0, position = 0, expansion = 0, type = None):
        self.timestamp=timestamp
        self.value=value
        self.position = position
        self.expansion = expansion
        self.type = type
