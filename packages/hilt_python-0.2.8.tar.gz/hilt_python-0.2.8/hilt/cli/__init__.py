"""HILT CLI package.

Intentionally empty to avoid exposing a `main` attribute that would shadow
the real `main()` function in hilt.cli.main (and break the console script).
"""

__all__ = []
