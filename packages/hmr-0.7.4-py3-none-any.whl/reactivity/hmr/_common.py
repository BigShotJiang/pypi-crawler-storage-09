from ..context import new_context

HMR_CONTEXT = new_context()
