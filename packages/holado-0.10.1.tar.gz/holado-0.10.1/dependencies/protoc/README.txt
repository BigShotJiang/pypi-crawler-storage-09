The protoc precompiled versions are downloadable from GitHub:
    https://github.com/protocolbuffers/protobuf/releases