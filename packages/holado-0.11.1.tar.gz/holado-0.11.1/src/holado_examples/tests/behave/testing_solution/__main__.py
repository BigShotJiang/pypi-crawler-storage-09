# -*- coding: utf-8 -*-


# This main is only needed to debug behave execution (and thus testing solution) with breakpoints

import re
import sys

from behave.__main__ import main

if __name__ == '__main__':
    sys.argv[0] = re.sub(r'(-script\.pyw?|\.exe)?$', '', sys.argv[0])
    sys.exit(main())
