class ReplyNotArrivedError(Exception):
    """Exception raised when a reply is not received in time."""

    pass
