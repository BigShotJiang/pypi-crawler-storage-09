from peak_utility.number import RepresentationalInt  # type: ignore


class Draw(RepresentationalInt):
    pass
