from enum import Enum


class RaceDistanceCategory(Enum):
    SPRINT = 1
    MILE = 2
    MIDDLE_DISTANCE = 3
    STAYING = 4
