"""Integration tests for the hotcore package.

These tests exercise more complex functionality but don't require
a real Redis server, using fakeredis instead.
"""
