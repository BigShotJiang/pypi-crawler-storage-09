"""Tests that require a real Redis server.

These tests are marked with @pytest.mark.redis_required and will be
skipped unless the USE_REAL_REDIS environment variable is set to true.
"""
