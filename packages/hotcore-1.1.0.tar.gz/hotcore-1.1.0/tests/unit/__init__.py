"""Unit tests for hotcore package."""
