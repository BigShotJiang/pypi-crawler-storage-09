from django.apps import AppConfig


class HtmxComponentsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "htmx_components"
