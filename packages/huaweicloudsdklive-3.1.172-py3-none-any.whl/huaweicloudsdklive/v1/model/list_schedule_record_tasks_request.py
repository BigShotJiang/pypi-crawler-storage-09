# coding: utf-8

import six

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListScheduleRecordTasksRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'start_time': 'int',
        'end_time': 'int',
        'domain': 'str',
        'app': 'str',
        'stream': 'str',
        'task_id': 'str',
        'offset': 'int',
        'limit': 'int'
    }

    attribute_map = {
        'start_time': 'start_time',
        'end_time': 'end_time',
        'domain': 'domain',
        'app': 'app',
        'stream': 'stream',
        'task_id': 'task_id',
        'offset': 'offset',
        'limit': 'limit'
    }

    def __init__(self, start_time=None, end_time=None, domain=None, app=None, stream=None, task_id=None, offset=None, limit=None):
        r"""ListScheduleRecordTasksRequest

        The model defined in huaweicloud sdk

        :param start_time: 查询任务开始时间，Unix 时间戳。设置时间不早于当前时间之前90天的时间，且查询时间跨度不超过一周。
        :type start_time: int
        :param end_time: 查询任务结束时间，Unix 时间戳。EndTime 必须大于 StartTime，设置时间不早于当前时间之前90天的时间，且查询时间跨度不超过一周。（任务开始结束时间必须在查询时间范围内）。
        :type end_time: int
        :param domain: 推流域名
        :type domain: str
        :param app: 应用名称，在domain有值的情况下生效
        :type app: str
        :param stream: 流名称，在domain和app有值的情况下生效
        :type stream: str
        :param task_id: 录制任务ID
        :type task_id: str
        :param offset: 分页场景下的偏移量，表示从此偏移量开始查询，offset大于等于0，缺省值为0，需要每次查询增加limit的值才能查询全部数据
        :type offset: int
        :param limit: 分页场景下的每页记录数，取值范围[1,100]，缺省值10
        :type limit: int
        """
        
        

        self._start_time = None
        self._end_time = None
        self._domain = None
        self._app = None
        self._stream = None
        self._task_id = None
        self._offset = None
        self._limit = None
        self.discriminator = None

        if start_time is not None:
            self.start_time = start_time
        self.end_time = end_time
        if domain is not None:
            self.domain = domain
        if app is not None:
            self.app = app
        if stream is not None:
            self.stream = stream
        if task_id is not None:
            self.task_id = task_id
        if offset is not None:
            self.offset = offset
        if limit is not None:
            self.limit = limit

    @property
    def start_time(self):
        r"""Gets the start_time of this ListScheduleRecordTasksRequest.

        查询任务开始时间，Unix 时间戳。设置时间不早于当前时间之前90天的时间，且查询时间跨度不超过一周。

        :return: The start_time of this ListScheduleRecordTasksRequest.
        :rtype: int
        """
        return self._start_time

    @start_time.setter
    def start_time(self, start_time):
        r"""Sets the start_time of this ListScheduleRecordTasksRequest.

        查询任务开始时间，Unix 时间戳。设置时间不早于当前时间之前90天的时间，且查询时间跨度不超过一周。

        :param start_time: The start_time of this ListScheduleRecordTasksRequest.
        :type start_time: int
        """
        self._start_time = start_time

    @property
    def end_time(self):
        r"""Gets the end_time of this ListScheduleRecordTasksRequest.

        查询任务结束时间，Unix 时间戳。EndTime 必须大于 StartTime，设置时间不早于当前时间之前90天的时间，且查询时间跨度不超过一周。（任务开始结束时间必须在查询时间范围内）。

        :return: The end_time of this ListScheduleRecordTasksRequest.
        :rtype: int
        """
        return self._end_time

    @end_time.setter
    def end_time(self, end_time):
        r"""Sets the end_time of this ListScheduleRecordTasksRequest.

        查询任务结束时间，Unix 时间戳。EndTime 必须大于 StartTime，设置时间不早于当前时间之前90天的时间，且查询时间跨度不超过一周。（任务开始结束时间必须在查询时间范围内）。

        :param end_time: The end_time of this ListScheduleRecordTasksRequest.
        :type end_time: int
        """
        self._end_time = end_time

    @property
    def domain(self):
        r"""Gets the domain of this ListScheduleRecordTasksRequest.

        推流域名

        :return: The domain of this ListScheduleRecordTasksRequest.
        :rtype: str
        """
        return self._domain

    @domain.setter
    def domain(self, domain):
        r"""Sets the domain of this ListScheduleRecordTasksRequest.

        推流域名

        :param domain: The domain of this ListScheduleRecordTasksRequest.
        :type domain: str
        """
        self._domain = domain

    @property
    def app(self):
        r"""Gets the app of this ListScheduleRecordTasksRequest.

        应用名称，在domain有值的情况下生效

        :return: The app of this ListScheduleRecordTasksRequest.
        :rtype: str
        """
        return self._app

    @app.setter
    def app(self, app):
        r"""Sets the app of this ListScheduleRecordTasksRequest.

        应用名称，在domain有值的情况下生效

        :param app: The app of this ListScheduleRecordTasksRequest.
        :type app: str
        """
        self._app = app

    @property
    def stream(self):
        r"""Gets the stream of this ListScheduleRecordTasksRequest.

        流名称，在domain和app有值的情况下生效

        :return: The stream of this ListScheduleRecordTasksRequest.
        :rtype: str
        """
        return self._stream

    @stream.setter
    def stream(self, stream):
        r"""Sets the stream of this ListScheduleRecordTasksRequest.

        流名称，在domain和app有值的情况下生效

        :param stream: The stream of this ListScheduleRecordTasksRequest.
        :type stream: str
        """
        self._stream = stream

    @property
    def task_id(self):
        r"""Gets the task_id of this ListScheduleRecordTasksRequest.

        录制任务ID

        :return: The task_id of this ListScheduleRecordTasksRequest.
        :rtype: str
        """
        return self._task_id

    @task_id.setter
    def task_id(self, task_id):
        r"""Sets the task_id of this ListScheduleRecordTasksRequest.

        录制任务ID

        :param task_id: The task_id of this ListScheduleRecordTasksRequest.
        :type task_id: str
        """
        self._task_id = task_id

    @property
    def offset(self):
        r"""Gets the offset of this ListScheduleRecordTasksRequest.

        分页场景下的偏移量，表示从此偏移量开始查询，offset大于等于0，缺省值为0，需要每次查询增加limit的值才能查询全部数据

        :return: The offset of this ListScheduleRecordTasksRequest.
        :rtype: int
        """
        return self._offset

    @offset.setter
    def offset(self, offset):
        r"""Sets the offset of this ListScheduleRecordTasksRequest.

        分页场景下的偏移量，表示从此偏移量开始查询，offset大于等于0，缺省值为0，需要每次查询增加limit的值才能查询全部数据

        :param offset: The offset of this ListScheduleRecordTasksRequest.
        :type offset: int
        """
        self._offset = offset

    @property
    def limit(self):
        r"""Gets the limit of this ListScheduleRecordTasksRequest.

        分页场景下的每页记录数，取值范围[1,100]，缺省值10

        :return: The limit of this ListScheduleRecordTasksRequest.
        :rtype: int
        """
        return self._limit

    @limit.setter
    def limit(self, limit):
        r"""Sets the limit of this ListScheduleRecordTasksRequest.

        分页场景下的每页记录数，取值范围[1,100]，缺省值10

        :param limit: The limit of this ListScheduleRecordTasksRequest.
        :type limit: int
        """
        self._limit = limit

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.openapi_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        if six.PY2:
            import sys
            reload(sys)
            sys.setdefaultencoding("utf-8")
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListScheduleRecordTasksRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
