# coding: utf-8

import six

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class CreateServerRequestClientCaCertificates:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []
    sensitive_list.append('content')

    openapi_types = {
        'name': 'str',
        'content': 'str'
    }

    attribute_map = {
        'name': 'name',
        'content': 'content'
    }

    def __init__(self, name=None, content=None):
        r"""CreateServerRequestClientCaCertificates

        The model defined in huaweicloud sdk

        :param name: 证书名
        :type name: str
        :param content: 证书内容
        :type content: str
        """
        
        

        self._name = None
        self._content = None
        self.discriminator = None

        if name is not None:
            self.name = name
        self.content = content

    @property
    def name(self):
        r"""Gets the name of this CreateServerRequestClientCaCertificates.

        证书名

        :return: The name of this CreateServerRequestClientCaCertificates.
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        r"""Sets the name of this CreateServerRequestClientCaCertificates.

        证书名

        :param name: The name of this CreateServerRequestClientCaCertificates.
        :type name: str
        """
        self._name = name

    @property
    def content(self):
        r"""Gets the content of this CreateServerRequestClientCaCertificates.

        证书内容

        :return: The content of this CreateServerRequestClientCaCertificates.
        :rtype: str
        """
        return self._content

    @content.setter
    def content(self, content):
        r"""Sets the content of this CreateServerRequestClientCaCertificates.

        证书内容

        :param content: The content of this CreateServerRequestClientCaCertificates.
        :type content: str
        """
        self._content = content

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.openapi_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        if six.PY2:
            import sys
            reload(sys)
            sys.setdefaultencoding("utf-8")
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CreateServerRequestClientCaCertificates):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
