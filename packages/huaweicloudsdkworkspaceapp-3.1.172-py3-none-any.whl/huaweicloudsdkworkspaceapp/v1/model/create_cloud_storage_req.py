# coding: utf-8

import six

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class CreateCloudStorageReq:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'project_config_ids': 'list[str]'
    }

    attribute_map = {
        'project_config_ids': 'project_config_ids'
    }

    def __init__(self, project_config_ids=None):
        r"""CreateCloudStorageReq

        The model defined in huaweicloud sdk

        :param project_config_ids: project_config_id,数量区间 [1, 50]。
        :type project_config_ids: list[str]
        """
        
        

        self._project_config_ids = None
        self.discriminator = None

        self.project_config_ids = project_config_ids

    @property
    def project_config_ids(self):
        r"""Gets the project_config_ids of this CreateCloudStorageReq.

        project_config_id,数量区间 [1, 50]。

        :return: The project_config_ids of this CreateCloudStorageReq.
        :rtype: list[str]
        """
        return self._project_config_ids

    @project_config_ids.setter
    def project_config_ids(self, project_config_ids):
        r"""Sets the project_config_ids of this CreateCloudStorageReq.

        project_config_id,数量区间 [1, 50]。

        :param project_config_ids: The project_config_ids of this CreateCloudStorageReq.
        :type project_config_ids: list[str]
        """
        self._project_config_ids = project_config_ids

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.openapi_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        if six.PY2:
            import sys
            reload(sys)
            sys.setdefaultencoding("utf-8")
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CreateCloudStorageReq):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
