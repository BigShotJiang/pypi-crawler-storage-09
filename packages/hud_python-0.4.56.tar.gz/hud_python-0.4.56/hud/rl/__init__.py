"""RL module for HUD."""
