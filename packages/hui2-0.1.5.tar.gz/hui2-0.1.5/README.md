# HUI2

HUI2 is an Android automation library with OCR support based on uiautomator2. It provides convenient methods for Android app testing and automation with built-in OCR capabilities.

## Installation

```bash
pip install hui2