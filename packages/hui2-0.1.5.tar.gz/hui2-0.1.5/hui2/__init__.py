"""
HUI2 - Android automation library with OCR support
"""

from .core import HDevice

__version__ = "0.1.5"
__author__ = "Your Name"
__email__ = "your.email@example.com"
__description__ = "Android automation library with OCR support based on uiautomator2"

__all__ = ["HDevice"]