# pdq

PDQ is an image perceptual hashing algorithm is by Meta.

The C++ implementation in this repo was also created by Meta.

The PDQ implementation is located here <https://github.com/facebook/ThreatExchange/tree/e58a463d92efc922ede01be3930e39b70197a219/pdq>
