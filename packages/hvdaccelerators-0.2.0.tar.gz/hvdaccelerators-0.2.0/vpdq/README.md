# vpdq

vpdq is a video perceptual hashing algorithm is by Meta.

The C++ implementation in this repo is a derivative of the one made by Meta.

The vPDQ implementation is located here <https://github.com/facebook/ThreatExchange/tree/e58a463d92efc922ede01be3930e39b70197a219/vpdq>
