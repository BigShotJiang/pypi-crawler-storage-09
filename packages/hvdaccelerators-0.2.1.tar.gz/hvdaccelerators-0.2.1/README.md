# hvdaccelerators

Python bindings for libraries used by Hydrus Video Deduplicator.

## Credits

PDQ by Meta

vPDQ by Meta
