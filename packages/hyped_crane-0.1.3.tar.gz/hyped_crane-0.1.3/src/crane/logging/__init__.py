"""Crane Logging Setup."""
