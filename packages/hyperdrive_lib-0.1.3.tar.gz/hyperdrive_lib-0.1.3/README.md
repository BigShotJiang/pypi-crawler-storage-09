# Внутренний python hyperdrive-lib с общим кодом



## hyper.utils
Общие утилиты




## Инструкция по публикации проекта
```
uv version --bump [patch|minor|major]
uv build .
uv publish --token {secret_token};
```