from typing import AsyncGenerator
from sqlalchemy.ext.asyncio import AsyncSession


async def provide_db_session() -> AsyncGenerator[AsyncSession, None]:
    pass