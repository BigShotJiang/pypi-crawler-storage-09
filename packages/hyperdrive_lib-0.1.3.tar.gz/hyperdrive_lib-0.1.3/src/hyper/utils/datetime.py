from datetime import UTC, datetime


__all__ = ["utc_now"]

def utc_now(with_timezone: bool = True) -> datetime:
    """Get the current UTC time."""
    from datetime import datetime

    dt = datetime.now(UTC)

    if not with_timezone:
        dt = dt.replace(tzinfo=None)

    return dt
