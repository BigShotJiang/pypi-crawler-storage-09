[DaisyUI](https://daisyui.com) components generated from [uilibspec-daisyui](https:/github.com/hyperflask/uilib-spec-daisyui) using [uilibspec](https:/github.com/hyperflask/uilib-spec)

This folder is auto-generated!