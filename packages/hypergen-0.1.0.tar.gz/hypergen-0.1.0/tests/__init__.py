"""Tests for hypergen."""
