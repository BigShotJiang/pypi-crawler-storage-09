from .otlp_collector_config import OTLPCollectorConfig

__all__ = [
    "OTLPCollectorConfig",
]
