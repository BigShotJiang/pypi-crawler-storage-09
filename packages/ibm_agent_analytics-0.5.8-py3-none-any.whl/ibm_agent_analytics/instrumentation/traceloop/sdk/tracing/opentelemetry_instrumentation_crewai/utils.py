def is_crew_kickoff(operation_name: str) -> bool:
    return "kickoff" in operation_name
