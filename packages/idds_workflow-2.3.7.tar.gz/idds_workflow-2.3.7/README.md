idds-workflow
====

idds-workflow subpackage implements basic workflow and a DAG(Directed Acyclic Graph) workflow.
