"""
specifically for test driven development for a new feature of ididi;
or for debug of the feature.
run test with: make feat
"""
