from .storage import Storage, StorageInterface
