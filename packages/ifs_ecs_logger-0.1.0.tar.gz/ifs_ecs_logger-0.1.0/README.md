# IFS ECS Logger

**IFS ECS Logger** is a lightweight Python library providing **IFS-compliant structured logging**  
based on the **Elastic Common Schema (ECS)**.  
It standardizes how logs are emitted across IFS CI/CD pipelines and automation scripts,  
ensuring consistent observability and easy ingestion into Elasticsearch, Kibana, or any ECS-aware platform.

---

## ✨ Features

- ✅ **IFS ECS compliance** — follows company formatting rules (e.g., `_timestamp`, `host.name`, structured `http` objects)
- 🧩 **ECS 1.6.0 compatible** — automatically includes ECS fields (`log.level`, `process.pid`, etc.)
- ⚙️ **Tekton & Kubernetes context injection** — adds pipeline, task, step, pod, and namespace automatically
- 💬 **Structured JSON output** — perfect for Elastic, Loki, Azure Monitor, and Fluent Bit ingestion
- 🔍 **Log levels supported:** `debug`, `info`, `warning`, `error`, `critical`
- 📦 **Zero configuration** — simple import and use

---

## 📦 Installation

Install from PyPI:

```bash
pip install ifs-ecs-logger
