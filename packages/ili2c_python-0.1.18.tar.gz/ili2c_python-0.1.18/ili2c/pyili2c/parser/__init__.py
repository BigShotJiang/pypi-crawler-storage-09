"""INTERLIS parser entry points."""

from .core import ParserSettings, parse  # noqa: F401

__all__ = ["ParserSettings", "parse"]
