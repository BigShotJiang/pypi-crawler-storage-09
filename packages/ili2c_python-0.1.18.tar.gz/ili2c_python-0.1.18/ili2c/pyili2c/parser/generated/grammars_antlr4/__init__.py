"""ANTLR generated grammar files for the INTERLIS parser."""

# Having an ``__init__`` file ensures that these generated modules and their
# ancillary data files are packaged inside wheels.
