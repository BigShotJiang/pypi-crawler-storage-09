"""Generated ANTLR parser package."""

# This module makes the ``generated`` directory a regular Python package so
# that the generated grammars can be included when building wheels.
