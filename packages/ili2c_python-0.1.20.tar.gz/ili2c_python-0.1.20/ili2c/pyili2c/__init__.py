"""Python implementation of the INTERLIS metamodel, parser and helpers."""

__all__ = ["mermaid", "metamodel", "parser"]
