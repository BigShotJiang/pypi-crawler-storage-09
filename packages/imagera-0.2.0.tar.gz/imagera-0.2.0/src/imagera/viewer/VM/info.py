from PyQt5.QtCore import QObject

class InfoVM(QObject):

    def __init__(self):
        super().__init__()


