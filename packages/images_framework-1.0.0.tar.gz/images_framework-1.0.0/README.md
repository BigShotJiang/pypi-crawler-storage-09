# Images framework

#### Requisites
- Numpy
- Scipy
- Opencv
- Rasterio
- Gdal
- Pillow
- Pascal-voc-writer
