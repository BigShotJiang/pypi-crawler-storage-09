# Images framework

#### Requisites
- Numpy
- Scipy
- Opencv
- Rasterio
- Pillow
- Pascal-voc-writer
