Directory with the output images.
