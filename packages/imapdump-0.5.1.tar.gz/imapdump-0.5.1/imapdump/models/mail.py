from datetime import datetime
from sqlalchemy import DateTime
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column
from sqlalchemy.sql import func
from .base import Base
import hashlib


class Mail(Base):
    __tablename__ = "mails"
    id: Mapped[str] = mapped_column(primary_key=True)
    uid: Mapped[str] = mapped_column()
    folder: Mapped[str] = mapped_column()
    title: Mapped[str] = mapped_column()
    size: Mapped[int] = mapped_column()
    date: Mapped[datetime] = mapped_column(DateTime, nullable=True)
    modified: Mapped[datetime] = mapped_column(
        DateTime, onupdate=func.now(), default=func.now()
    )
    created: Mapped[datetime] = mapped_column(DateTime, default=func.now())

    @staticmethod
    def generate_id(folder_name: str, message_id: str) -> str:
        h = hashlib.blake2b(digest_size=20)
        h.update(f"{folder_name}_{message_id}".encode())
        return h.hexdigest()
