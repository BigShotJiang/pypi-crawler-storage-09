"""Search module tests."""
