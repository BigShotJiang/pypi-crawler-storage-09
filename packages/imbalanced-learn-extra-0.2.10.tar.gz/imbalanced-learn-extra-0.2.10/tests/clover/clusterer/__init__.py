"""Tests for clusterer classes."""
