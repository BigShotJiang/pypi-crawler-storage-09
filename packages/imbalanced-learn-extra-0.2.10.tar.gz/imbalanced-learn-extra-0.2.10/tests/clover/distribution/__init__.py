"""Tests for distribution classes."""
