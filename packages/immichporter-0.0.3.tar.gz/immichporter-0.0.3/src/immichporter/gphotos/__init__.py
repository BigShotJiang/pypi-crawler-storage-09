"""Google Photos source module for immichporter."""
