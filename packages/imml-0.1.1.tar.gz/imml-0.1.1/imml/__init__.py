# License: BSD-3-Clause

__version__ = "0.1.1"