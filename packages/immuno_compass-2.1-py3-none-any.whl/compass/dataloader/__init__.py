from .data import TCGAData, GeneData, ITRPData
