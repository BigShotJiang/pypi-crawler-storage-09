from setuptools import setup, find_packages

setup(
    name="importer-utils",
    version="1.0.0", # تحديث الإصدار لتجنب التعارض
    packages=find_packages(),
)

