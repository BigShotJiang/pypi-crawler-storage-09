from dbt.adapters.sql.connections import SQLConnectionManager
from dbt.adapters.sql.impl import SQLAdapter
