"""IncariCLI - A simple and elegant task manager for your command line."""

__version__ = "0.1.0"
__author__ = "Paolo Bietolini"
__email__ = "chat@paolobietolini.com"

from .cli import main

__all__ = ["main"]
