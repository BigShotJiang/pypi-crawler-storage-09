"""Incept Eval - Educational Question Evaluation CLI"""
__version__ = "1.0.3"
