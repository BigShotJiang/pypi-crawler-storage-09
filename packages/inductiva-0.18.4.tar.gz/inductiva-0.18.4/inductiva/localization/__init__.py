# pylint: disable=missing-module-docstring
from .localization import translator
