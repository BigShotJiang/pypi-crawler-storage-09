::: inferno.datasets
    options:
        heading: datasets > Image Data
        toc_label: datasets > Image Data
        members:
        - CIFAR10
        - CIFAR10C
        - CIFAR100
        - CIFAR100C
        - MNIST
        - MNISTC
        - TinyImageNet
        - TinyImageNetC