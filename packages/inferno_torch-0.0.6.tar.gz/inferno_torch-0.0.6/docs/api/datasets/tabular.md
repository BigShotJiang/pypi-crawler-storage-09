::: inferno.datasets
    options:
        heading: datasets > Tabular Data
        toc_label: datasets > Tabular Data
        members:
        - ConcreteCompressiveStrength
        - ParkinsonsTelemonitoring
        - ProteinStructure
        - RoadNetwork
        - WineQuality