```{eval-rst}
.. _explanation-page:
```
# Explanation

```{eval-rst}
.. toctree::
    :maxdepth: 2
    :caption: Contents:

    system
    components
    time_series
    location
    serialization
```
