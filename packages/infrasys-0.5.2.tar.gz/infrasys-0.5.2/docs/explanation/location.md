# Location
Components can compose this class in order to specify its geographic location.

Refer to the [Location API](#location-api) for more information.
