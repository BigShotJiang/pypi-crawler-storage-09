
class AddressParserError(Exception):
    """Raised when the address parser fails to parse the address."""

    pass
