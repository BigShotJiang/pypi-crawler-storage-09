In these notebooks we provide examples for greedy and DBG methods, with and without plots.
