from __future__ import annotations
from typing import Literal

TOverflowEnum = Literal["visible", "hidden", "clip", "scroll", "auto"]
