import typing


TRouterHistoryMode = typing.Literal["web", "memory", "hash"]
