from typing import TypeVar
from abc import ABC

T = TypeVar("T")


class ElementBindingMixin(ABC):
    pass
