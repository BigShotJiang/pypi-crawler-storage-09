from abc import ABC


class ObservableMixin(ABC):
    pass
