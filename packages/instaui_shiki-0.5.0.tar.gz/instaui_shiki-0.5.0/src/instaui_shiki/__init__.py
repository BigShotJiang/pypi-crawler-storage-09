__all__ = ["__version__", "shiki"]

from .version import __version__
from ._shiki_code import Code as shiki
