from ._index import get_locale, get_locales, use_locale_dict


__all__ = ["get_locale", "get_locales", "use_locale_dict"]
