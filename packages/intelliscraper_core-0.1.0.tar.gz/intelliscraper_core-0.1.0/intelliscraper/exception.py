class HTMLParserInputError(ValueError):
    """Raised when the input provided to HTMLParser is invalid."""

    pass
