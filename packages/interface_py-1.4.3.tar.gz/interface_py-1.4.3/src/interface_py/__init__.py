from ._internals import interface, concrete


interface.__module__ = "interface_py"
concrete.__module__ = "interface_py"


__all__ = [
    "interface",
    "concrete"
]
