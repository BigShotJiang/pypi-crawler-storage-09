class InterfaceError(TypeError):
    """Interface violation error"""
    pass