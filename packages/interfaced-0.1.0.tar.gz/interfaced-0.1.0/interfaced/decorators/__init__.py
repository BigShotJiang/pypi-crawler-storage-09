from .interface import interface
from .implementation import ImplementationDecorator

implements = None  # define later

__all__ = ['interface', 'implements', 'ImplementationDecorator']