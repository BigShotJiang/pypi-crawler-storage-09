# -*- coding: utf-8 -*-
#
# This file is part of Invenio.
# Copyright (C) 2015-2018 CERN.
# Copyright (C) 2022 Graz University of Technology.
#
# Invenio is free software; you can redistribute it and/or modify it
# under the terms of the MIT License; see LICENSE file for more details.

# Quit on errors
set -o errexit

# Quit on unbound symbols
set -o nounset

python -m setup compile_catalog
python -m babel.messages.frontend compile -d tests/translations/
python -m check_manifest
python -m sphinx.cmd.build -qnNW docs docs/_build/html
python -m pytest
