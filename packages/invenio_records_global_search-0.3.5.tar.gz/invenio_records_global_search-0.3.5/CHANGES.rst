..
    Copyright (C) 2023-2025 Graz University of Technology.

    invenio-records-global-search is free software; you can redistribute it
    and/or modify it under the terms of the MIT License; see LICENSE file for
    more details.

Changes
=======

Version v0.3.5 (released 2025-10-21)

- search: workaround for version search bug
- search: fix for default app-rdm queries

Version v0.3.4 (release 2025-05-15)

- fix: setuptools require underscores instead of dashes
- refactor: additional removed in marshmallow>=4
- fix: naming of parameter


Version v0.3.3 (release 2025-01-24)

- setup: update ruff configuration


Version v0.3.2 (release 2024-11-14)

- fix: strip html tags


Version v0.3.1 (release 2024-07-11)

- fix: indexer_cls shared with rdm-records



Version v0.3.0 (release 2024-06-12)

- global: rely on finalize_app
- schema: allow empty rights.
  the license setting is not mondatory on the different datamodels
  therefore it can't be required on the global search



Version v0.2.3 (release 2024-02-14)

- search: change to rdm multi style
- fix: update should be allowed
- ruff: fix noqa v0.1.14


Version v0.2.2 (release 2024-01-07)

- fix: add missing permission


Version v0.2.1 (release 2023-11-23)

- translations: update
- facets: implement better wording for datamodel


Version v0.2.0 (release 2023-11-09)




Version v0.1.0 (release 2023-11-09)



