# -*- coding: utf-8 -*-
#
# Copyright (C) 2023 Graz University of Technology.
#
# invenio-records-global-search is free software; you can redistribute it and/or
# modify it under the terms of the MIT License; see LICENSE file for more
# details.

"""Invenio Global Search Record Resource serializers."""

from .serializer import GlobalSearchJSONSerializer

__all__ = ("GlobalSearchJSONSerializer",)
