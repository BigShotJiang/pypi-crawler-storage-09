# Invenio REST API Client

This is a (work in Progress) Python collection of client-side APIs to simplify the interaction with all the REST APIs that InvenioRDM exposes.

## Installation

```
pip install invenio-rest-api-client
```
