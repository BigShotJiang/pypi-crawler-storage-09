"""
Widgets from Development workflow category

"""
# ID = "orangecontrib.AAIT"

NAME = "Advanced Artificial Intelligence Tools"

# Category icon show in the menu
ICON = "icons/category.svg"

BACKGROUND = "light-green"

DESCRIPTION = ("Advanced Artificial Intelligence Tools is a package meant to develop and enable advanced AI "
               "functionalities in Orange Data Mining.")



# PRIORITY = 6