def _make_layout_columns(ndim):
    columns = [f"_ipx_layout_{i}" for i in range(ndim)]
    return columns
