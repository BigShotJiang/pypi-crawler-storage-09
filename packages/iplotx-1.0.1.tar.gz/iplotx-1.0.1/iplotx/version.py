"""
iplotx version information module.
"""

__version__ = "1.0.1"
