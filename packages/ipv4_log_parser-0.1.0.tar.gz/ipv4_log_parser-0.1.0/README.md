# IPv4 Log Parser - HIBA KHABAR

A simple log parser for IPv4 addresses in CIDR notation.

## Installation
```bash
pip install ipv4-log-parser