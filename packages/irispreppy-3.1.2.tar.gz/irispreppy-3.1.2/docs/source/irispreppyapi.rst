irispreppy API Documentation
============================

Submodules
----------

irispreppy.radcal.radcal module
-------------------------------

.. automodule:: irispreppy.radcal.radcal
    :members:
    :show-inheritance:

irispreppy.radcal.iris\_get\_response module
--------------------------------------------

.. automodule:: irispreppy.radcal.iris_get_response 
    :members:
    :show-inheritance:


irispreppy.radcal.calsave module
--------------------------------

.. automodule:: irispreppy.radcal.calsave
    :members:
    :show-inheritance:

irispreppy.psf.deconvolve module
--------------------------------

.. automodule:: irispreppy.psf.deconvolve
    :members:
    :show-inheritance:

irispreppy.psf.decsave module
-----------------------------

.. automodule:: irispreppy.psf.decsave
    :members:
    :show-inheritance:

