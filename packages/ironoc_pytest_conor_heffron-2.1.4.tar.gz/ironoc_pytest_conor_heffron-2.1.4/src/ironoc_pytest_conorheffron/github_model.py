class GithubModel():

    def __init__(self, login, id, url) -> None:
        self.login =  login 
        self.id = id 
        self.url = url
