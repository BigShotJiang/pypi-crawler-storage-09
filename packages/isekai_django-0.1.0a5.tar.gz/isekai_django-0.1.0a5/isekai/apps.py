from django.apps import AppConfig


class IsekaiConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "isekai"
    verbose_name = "Isekai"
