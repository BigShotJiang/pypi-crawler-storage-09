"""Manga Metadata Tool - Source package."""
