"""Mock objects for testing."""
