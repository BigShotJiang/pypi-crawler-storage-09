from . import diigo
from . import duolingo
from . import quora

