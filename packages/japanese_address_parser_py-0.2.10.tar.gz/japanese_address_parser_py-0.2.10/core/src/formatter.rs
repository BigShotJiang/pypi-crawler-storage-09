pub(crate) mod chome_with_arabic_numerals;
pub(crate) mod fullwidth_character;
pub(crate) mod halfwidth_character;
pub(crate) mod house_number;
pub(crate) mod informal_town_name_notation;
