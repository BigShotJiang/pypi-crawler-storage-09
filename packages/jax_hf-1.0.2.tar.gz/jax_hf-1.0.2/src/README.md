This is the source directory that contains the actual python package `jax_hf` (i.e., what gets loaded when you run `import jax_hf as jhf`).

For the full project readme see  `../README.md`. 