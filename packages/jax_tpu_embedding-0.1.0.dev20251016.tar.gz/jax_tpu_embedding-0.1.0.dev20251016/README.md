# jax_tpu_embedding

[![Unittests](https://github.com/jax-ml/jax-tpu-embedding/actions/workflows/build_and_test.yml/badge.svg)](https://github.com/jax-ml/jax-tpu-embedding/actions/workflows/build_and_test.yml)

Usage instructions coming soon!

*This is not an officially supported Google product.*
