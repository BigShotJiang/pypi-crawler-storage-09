"""Collection of stuff that's useful in general python programming"""

__version__ = "2.0.1"

__author_name__, __author_email__ = "Jaded Encoding Thaumaturgy", "jaded.encoding.thaumaturgy@gmail.com"
__maintainer_name__, __maintainer_email__ = __author_name__, __author_email__

__author__ = f"{__author_name__} <{__author_email__}>"
__maintainer__ = __author__

if __name__ == "__github__":
    print(__version__)
