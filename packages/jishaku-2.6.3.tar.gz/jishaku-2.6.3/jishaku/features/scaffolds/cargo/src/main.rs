fn main() {{
{content}
}}
