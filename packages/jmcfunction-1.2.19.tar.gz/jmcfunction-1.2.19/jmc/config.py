VERSION = "v1.2.19"
CONFIG_FILE_NAME = "jmc_config.json"
