Visualization
============

.. automodule:: jmstate.visualization
   :no-members:
   :no-undoc-members:
   :no-index:

.. autosummary::
   :toctree: generated/
   :recursive:

   plot_history