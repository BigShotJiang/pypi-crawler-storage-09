"""Visualization functions for the jmstate package."""

from ._plot import plot_history

__all__ = ["plot_history"]
