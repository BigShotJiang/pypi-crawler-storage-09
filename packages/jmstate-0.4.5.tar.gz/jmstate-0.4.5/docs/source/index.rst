Welcome to jmstate's Documentation!
===================================

This is a comprehensive guide to the jmstate package, a tool for multistate joint modeling with PyTorch.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   modules