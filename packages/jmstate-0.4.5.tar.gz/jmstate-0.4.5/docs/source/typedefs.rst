Typedefs
========

.. automodule:: jmstate.typedefs
   :no-members:
   :no-undoc-members:
   :no-index:

.. autosummary::
   :toctree: generated/
   :recursive:

   BaseHazardFn
   BucketData
   ClockMethod
   IndividualEffectsFn
   Info
   Job
   LinkFn
   MatRepr
   Metrics
   ModelData
   ModelDesign
   ModelParams
   RegressionFn
   SampleData