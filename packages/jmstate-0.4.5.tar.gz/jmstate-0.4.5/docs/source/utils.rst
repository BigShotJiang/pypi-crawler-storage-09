Utils
=====

.. automodule:: jmstate.utils
   :no-members:
   :no-undoc-members:
   :no-index:

.. autosummary::
   :toctree: generated/
   :recursive:

   build_buckets
   cov_from_repr
   get_dtype
   repr_from_cov
   set_dtype