"""
Author:  Jacek Kotlarski --<szumak@virthost.pl>
Created: 2023-10-29

Purpose: Provide configuration processing helpers.

This package exposes data and file processors that power the Config class.
"""
