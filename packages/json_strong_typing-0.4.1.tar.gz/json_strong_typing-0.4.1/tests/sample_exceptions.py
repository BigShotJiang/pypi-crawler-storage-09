class CustomException(Exception):
    pass
