# judex

Ferramenta para extração de dados jurídicos.
