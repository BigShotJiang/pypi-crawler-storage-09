"""Utility functions and helpers"""
