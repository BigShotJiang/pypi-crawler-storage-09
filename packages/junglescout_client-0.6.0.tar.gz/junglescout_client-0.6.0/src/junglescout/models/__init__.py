"""Package for models used throughout the project."""
