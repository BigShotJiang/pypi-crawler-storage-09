from junkie import junkie
from junkie.version import __version__

name = "junkie"

__all__ = [__version__, junkie.junkie]
