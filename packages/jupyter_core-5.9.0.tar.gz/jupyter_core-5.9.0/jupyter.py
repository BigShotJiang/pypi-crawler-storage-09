"""Launch the root jupyter command"""

from __future__ import annotations

if __name__ == "__main__":
    from jupyter_core.command import main

    main()
