"""Launch the root jupyter command"""

from __future__ import annotations

from .command import main

main()
