from __future__ import annotations

c.NbConvertApp.post_processors = []
