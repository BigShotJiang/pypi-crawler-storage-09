# Contributing

We follow the [Jupyter Contributing Guide](https://docs.jupyter.org/en/latest/contributing/content-contributor.html).

See the [README](https://github.com/jupyter/jupyter_core/blob/master/README.md) on how to set up a development environment.
