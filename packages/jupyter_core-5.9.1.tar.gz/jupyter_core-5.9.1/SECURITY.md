# Security Policy

## Reporting a Vulnerability

All IPython and Jupyter security are handled via security@ipython.org.
You can find more information on the Jupyter website. https://jupyter.org/security

## Tidelift

You can report security concerns for Jupyter-Core via the [Tidelift platform](https://tidelift.com/security).
