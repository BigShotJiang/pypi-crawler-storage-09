jupyter\_core package
=====================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   jupyter_core.utils

Submodules
----------


.. automodule:: jupyter_core.application
   :members:
   :show-inheritance:
   :undoc-members:


.. automodule:: jupyter_core.command
   :members:
   :show-inheritance:
   :undoc-members:


.. automodule:: jupyter_core.migrate
   :members:
   :show-inheritance:
   :undoc-members:


.. automodule:: jupyter_core.paths
   :members:
   :show-inheritance:
   :undoc-members:


.. automodule:: jupyter_core.troubleshoot
   :members:
   :show-inheritance:
   :undoc-members:


.. automodule:: jupyter_core.version
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: jupyter_core
   :members:
   :show-inheritance:
   :undoc-members:
