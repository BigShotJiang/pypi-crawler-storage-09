from __future__ import annotations

c.NotebookApp.open_browser = False
