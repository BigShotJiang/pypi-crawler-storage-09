"""Jupyter quant, a dockerized quant research environment."""

__version__="2510.1"
