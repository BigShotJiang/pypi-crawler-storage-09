# Fix Interface Descriptions

## Image

| No. | Rule ID           | Fix Interface                                                                                                                 |
| --- | ----------------- | ----------------------------------------------------------------------------------------------------------------------------- |
| 1a  | image-missing-alt | A text field where the user can type in alt-text. If image contains text, we fill the placeholder value to the detected text. |

---

## Heading

| No. | Rule ID                 | Fix Interface                                                           |
| --- | ----------------------- | ----------------------------------------------------------------------- |
| 2a  | heading-missing-h1      | A text field where the user can type in the h1.                         |
| 2b  | heading-multiple-h1     | None.                                                                   |
| 2c  | heading-duplicate-h2    | None.                                                                   |
| 2d  | heading-duplicate-h1-h2 | None.                                                                   |
| 2e  | heading-wrong-order     | A dropdown where the user can select from the possible heading options. |
| 2f  | heading-empty           | A text field where the user can type in the heading content.            |

---

## Table

| No. | Rule ID               | Fix Interface                                                                                  |
| --- | --------------------- | ---------------------------------------------------------------------------------------------- |
| 3a  | table-missing-header  | A dropdown where the user can select either to make the row, column or row and column headers. |
| 3b  | table-missing-caption | A text field where the user can type in table caption.                                         |
| 3c  | table-missing-scope   | An apply button that automatically sets the scope based on the header.                         |

---

## Color

| No. | Rule ID                      | Fix Interface |
| --- | ---------------------------- | ------------- |
| 4a  | color-insufficient-cc-normal | None.         |
| 4b  | color-insufficient-cc-large  | None.         |

---

## Link

| No. | Rule ID               | Fix Interface                                   |
| --- | --------------------- | ----------------------------------------------- |
| 5a  | link-discernible-text | A text field to update link text or aria-label. |
