# TODO

---

- Publish the theme to conda-forge repository

- Check toolbar mouse hovering theme
