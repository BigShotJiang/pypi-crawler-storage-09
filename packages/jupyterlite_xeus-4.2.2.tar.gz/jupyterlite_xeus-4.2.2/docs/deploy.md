(deploy)=

# Deploy your own

## On Github Pages

In order to make your own JupyterLite deployment, you can use the [xeus-python-demo repository template](https://github.com/jupyterlite/xeus-python-demo)
that allows you to easily make a JupyteLite deployment on Github pages with xeus-python as default kernel.

This template repository contains an `environment.yml` file where you can specify the packages you need. You can also add Notebooks to the `content` folder.

## In Sphinx documentation

You can make a JupyterLite deployment with xeus-python installed using the [jupyterlite-sphinx extension](https://github.com/jupyterlite/jupyterlite-sphinx)
