# Fenced code

## No language

```
# a generic code instruction
1 + 1
```

## Python

```python
1 + 1
```

## Bash

```python
echo Hi
```

# Code cells

```{code-cell} ipython3
# This code gets executed in notebooks
1 + 1
```
