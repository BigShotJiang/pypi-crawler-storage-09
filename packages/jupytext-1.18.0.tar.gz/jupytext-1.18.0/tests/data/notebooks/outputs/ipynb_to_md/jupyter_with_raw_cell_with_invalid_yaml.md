---
title: Exception: Test
jupyter:
  kernelspec:
    display_name: Python 3 (ipykernel)
    language: python
    name: python3
---

```python
1 + 2 + 3
```
