---
jupyter:
  kernelspec:
    display_name: Tcl
    language: tcl
    name: tcljupyter
---

# Assign Values

```tcl
set a 1
puts "a = $a"
```

# Loop

```tcl
for {set i 0} {$i < 10} {incr i} {
    puts "I inside first loop: $i"
}
```

```tcl

```
