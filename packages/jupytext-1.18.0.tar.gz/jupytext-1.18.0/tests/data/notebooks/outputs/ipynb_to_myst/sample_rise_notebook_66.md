---
kernelspec:
  display_name: Python 3
  language: python
  name: python3
---

+++ {"slideshow": {"slide_type": "slide"}}

A markdown cell

```{code-cell} ipython3
---
slideshow:
  slide_type: ''
---
1+1
```

+++ {"cell_style": "center", "slideshow": {"slide_type": "fragment"}}

Markdown cell two
