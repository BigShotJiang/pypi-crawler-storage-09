---
jupyter:
  kernelspec:
    display_name: R
    language: R
    name: ir
  nbformat: 4
  nbformat_minor: 2
---

::: {.cell .markdown}
This is a jupyter notebook that uses the IR kernel.
:::

::: {#cell-1 .cell .code}
``` R
sum(1:10)
```
:::

::: {#cell-2 .cell .code}
``` R
plot(cars)
```
:::

::: {#cell-3 .cell .code}
``` R
```
:::
