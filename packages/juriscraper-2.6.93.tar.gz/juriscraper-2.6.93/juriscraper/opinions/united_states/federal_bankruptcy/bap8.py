from juriscraper.opinions.united_states.federal_appellate import ca8


class Site(ca8.Site):
    is_bap_scraper = True
