from .jurispacy_tokenizer import JuriSpacyTokenizer
