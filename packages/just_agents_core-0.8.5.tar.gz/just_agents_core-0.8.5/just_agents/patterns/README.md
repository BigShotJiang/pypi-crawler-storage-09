## Agentic patterns ##

This package contains agentic patterns that can be used to create more complex agents.
It also contains implementations of Chain of Thought, Reflection and other patterns.