from .generator import GameMap
