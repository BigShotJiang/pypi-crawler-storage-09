"""Version information for Kagura AI"""

__version__ = "2.5.7"
