# cli/ui/__init__.py
from .console_manager import ConsoleManager

__all__ = ["ConsoleManager"]
