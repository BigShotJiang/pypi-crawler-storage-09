"""Memory systems showcase example."""
