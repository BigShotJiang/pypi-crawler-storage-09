from keras_hub.src.models.vae.vae_backbone import VAEBackbone
