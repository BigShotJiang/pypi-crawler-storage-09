# KerasNLP: Multi-framework NLP Models

KerasNLP has renamed to KerasHub! Read the announcement
[here](https://github.com/keras-team/keras-nlp/issues/1831).

This contains a shim package for `keras-nlp` so that the old style
`pip install keras-nlp` and `import keras_nlp` continue to work.
