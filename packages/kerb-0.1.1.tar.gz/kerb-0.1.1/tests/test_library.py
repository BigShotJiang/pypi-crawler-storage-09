"""Legacy placeholder test file.

This file is intentionally left without tests because the previous dummy
functions (hello_world, add_numbers, get_toolkit_info) were removed.
Pytest discovery is now limited to the dedicated tests/ directory via
pyproject.toml configuration. This file can be deleted in a future cleanup.
"""

# No tests or runtime code here.
