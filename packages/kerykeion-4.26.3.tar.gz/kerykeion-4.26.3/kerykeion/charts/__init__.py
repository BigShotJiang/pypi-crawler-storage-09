"""
This is part of Kerykeion (C) 2025 Giacomo Battaglia

This modules contains the charts logic for the Kerykeion project.
"""
