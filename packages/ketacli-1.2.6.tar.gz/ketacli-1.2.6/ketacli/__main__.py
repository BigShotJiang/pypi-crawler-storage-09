#!/usr/bin/env python3
"""
KetaCLI main entry point for module execution.
"""

from ketacli.ketacli import start

if __name__ == "__main__":
    start()