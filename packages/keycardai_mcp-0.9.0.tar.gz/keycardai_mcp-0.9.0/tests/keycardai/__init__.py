"""Tests for keycardai namespace."""
