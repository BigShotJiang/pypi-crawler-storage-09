class Config:
    BASE_PATH = "/home/data/kyfile/";