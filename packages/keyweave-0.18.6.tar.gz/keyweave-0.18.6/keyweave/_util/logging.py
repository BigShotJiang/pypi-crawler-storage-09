from logging import getLogger

keyweaveLogger = getLogger("keyweave")
