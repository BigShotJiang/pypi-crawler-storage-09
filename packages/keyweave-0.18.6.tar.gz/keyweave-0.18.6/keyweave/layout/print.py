from itertools import groupby
from typing import Any, Iterable
from keyweave.bindings import Binding
from keyweave.commanding import CommandMeta
from keyweave.key_types import KeySet
