from ..layout import KCLayout

demo = KCLayout("DEMO")
