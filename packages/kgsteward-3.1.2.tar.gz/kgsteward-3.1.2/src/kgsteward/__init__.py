"""Init module: launches the main kgsteward command."""

from . import kgsteward

def run_kgsteward():
    """Entry point for the application script"""
    kgsteward.main()
