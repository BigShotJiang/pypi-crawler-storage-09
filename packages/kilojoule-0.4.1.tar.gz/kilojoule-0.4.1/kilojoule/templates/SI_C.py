from kilojoule.templates.SI import *

T.set_units("degC")
