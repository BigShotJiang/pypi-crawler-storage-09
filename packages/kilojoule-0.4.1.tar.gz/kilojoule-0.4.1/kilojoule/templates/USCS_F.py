from kilojoule.templates.USCS_R import *

T.set_units("degF")
