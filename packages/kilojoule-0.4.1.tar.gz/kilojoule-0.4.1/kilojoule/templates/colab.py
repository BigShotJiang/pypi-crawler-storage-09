from kilojoule.templates.kSI import *
from kilojoule.templates.thermo import *
from kilojoule.templates.ht import *
from kilojoule.templates.fluids import *

global _in_colab_
_in_colab_ = True
