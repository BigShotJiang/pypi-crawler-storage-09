from kilojoule.templates.kSI import *

T.set_units("degC")
