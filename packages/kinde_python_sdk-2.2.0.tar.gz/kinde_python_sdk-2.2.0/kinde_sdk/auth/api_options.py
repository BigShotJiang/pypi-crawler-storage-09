class ApiOptions:
    def __init__(self, force_api: bool = False):
        self.force_api = force_api