"""Tests for gitdata.cli."""
