from kirin import ir

dialect = ir.Dialect(name="func")
