# KITECH Manufacturing Data Repository CLI

KITECH 제조 데이터 리포지토리를 위한 Python CLI 도구입니다.

## 기능

- 🖥️ **대화형 파일 관리자 (TUI)** - Textual 프레임워크 기반 현대적인 TUI
  - 리포지토리 선택 화면 (페이지네이션 지원)
  - 듀얼 패널 파일 관리자 (로컬 ↔ 원격)
  - 향상된 포커스 관리 (시각적 표시기)
  - 실시간 진행률 추적 (업로드/다운로드)
- 🔐 API Token 기반 인증 (시스템 키링에 안전 저장)
- ⬇️ 파일/폴더 다운로드 (SHA-256 무결성 검증)
- ⬆️ 파일/폴더 업로드 (MD5 무결성 검증)
- 📊 실시간 진행률 표시 (배치 작업 지원)

## 요구 사항

- Python 3.10 ~ 3.13
- pip

## 설치

```bash
pip install kitech-repository-dev
```

## 사용법

### 1. 초기 설정 (간단 버전)

단 한 번의 명령으로 서버 설정 + 로그인을 완료할 수 있습니다:

```bash
# 대화형으로 설정 (서버 URL과 Token을 순서대로 입력)
kitech-dev login

# 또는 직접 지정
kitech-dev login https://your-server.com
```

이 명령은 서버 주소를 설정하고 API Token 로그인까지 한 번에 처리합니다.

### 2. 파일 관리자 시작

```bash
kitech-dev start
```

실행하면 리포지토리 선택 화면이 먼저 나타납니다:

**1단계: 리포지토리 선택 화면**
- 모든 접근 가능한 리포지토리 목록 표시 (페이지네이션 지원)
- `↑/↓` 키로 리포지토리 선택
- `Enter` 키를 눌러 해당 리포지토리의 파일 관리자로 진입

**2단계: 듀얼 패널 파일 관리자**
- **왼쪽 패널 (원격)**: 선택한 리포지토리의 파일
- **오른쪽 패널 (로컬)**: 로컬 파일 시스템
- **하단 패널**: 파일 전송 진행률 표시

### 기본 사용 흐름

1. **파일 탐색**
   - `↑/↓` 키로 파일/폴더 선택
   - `Enter` 키로 폴더 열기 또는 파일 다운로드
   - `..` 항목을 선택하고 `Enter`를 눌러 상위 디렉토리로 이동
   - `Tab` 키로 왼쪽/오른쪽 패널 전환

2. **다운로드** (원격 → 로컬)
   - 왼쪽 패널(원격)에서 다운로드할 파일/폴더 선택
   - `Enter` 키 또는 `D` 키 누르기
   - `~/Downloads` 폴더에 다운로드됨
   - 실시간 진행률이 하단에 표시됨

3. **업로드** (로컬 → 원격)
   - 오른쪽 패널(로컬)에서 업로드할 파일/폴더 선택
   - `U` 키 누르기
   - 왼쪽 패널의 현재 경로에 업로드됨
   - 실시간 진행률이 하단에 표시됨

4. **종료**
   - `Ctrl+C` 또는 `Ctrl+Q` 키로 프로그램 종료
   - 터미널에서 `kitech-dev logout`으로 로그아웃

### 키보드 단축키

| 키 | 기능 |
|---|---|
| `↑/↓` | 파일/폴더 선택 |
| `Enter` | 폴더 열기 / 파일 다운로드 (원격 패널에서) |
| `Tab` | 왼쪽/오른쪽 패널 전환 |
| `D` | 선택한 항목 다운로드 (원격 → 로컬) |
| `U` | 선택한 항목 업로드 (로컬 → 원격) |
| `Ctrl+C` / `Ctrl+Q` | 프로그램 종료 |

## 명령어 참조

### 주요 명령어

```bash
# 로그인 (서버 설정 + 인증 한번에)
kitech-dev login [SERVER_URL]

# 파일 관리자 시작
kitech-dev start

# 연결 상태 확인
kitech-dev status

# 로그아웃
kitech-dev logout

# 버전 확인
kitech-dev version
```

### 고급 명령어

```bash
# 서버 URL 변경
kitech-dev server [NEW_URL]

# 현재 설정 확인
kitech-dev config

# 설정 초기화
kitech-dev config reset
```

### 저장 위치

- **설정 파일**: `~/.kitech/config.json` - 서버 URL, 청크 크기
- **인증 메타데이터**: `~/.kitech/auth_metadata.json` - 사용자 정보, 만료일
- **API 키**: 시스템 키링에 안전하게 암호화되어 저장 (macOS Keychain, Windows Credential Manager 등)

### 환경 변수 (선택사항)

명령어 대신 환경 변수로도 설정할 수 있습니다:

```bash
# 환경 변수로 설정
export KITECH_API_BASE_URL=https://your-api-server.com

# 또는 .env 파일에 작성
echo "KITECH_API_BASE_URL=https://your-api-server.com" > .env
```

**주의**: 베이스 URL만 입력하세요. API 버전(`/v1`)은 클라이언트가 런타임에 자동으로 추가합니다.

---

## 개발자를 위한 Library API

Python 프로그램에서 직접 사용할 수 있습니다:

```python
from kitech_repository import KitechClient

# 기본 사용 (v1 API)
client = KitechClient(token="kt_xxx")
repos = client.list_repositories()
client.download_file(repository_id=123, path="/data/file.csv")
client.upload_file(repository_id=123, file_path="local.csv")

# 다른 API 버전 사용
client_v2 = KitechClient(token="kt_xxx", api_version="v2")

# API 버전 없이 사용
client_no_version = KitechClient(token="kt_xxx", api_version="")
```

**API 버전 관리**:

- 기본값: `api_version="v1"`
- Config 파일에는 베이스 URL만 저장되며, API 버전은 클라이언트 생성 시 지정합니다
- 이를 통해 동일한 애플리케이션에서 여러 API 버전을 동시에 사용할 수 있습니다

## 라이센스

TBD
