"""
TCSS stylesheets for KITECH Repository Manager TUI.

Theme: Black background with yellow highlights and white text.
"""
