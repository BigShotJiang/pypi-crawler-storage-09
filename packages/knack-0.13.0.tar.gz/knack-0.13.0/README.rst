Knack
=====

.. image:: https://img.shields.io/pypi/v/knack.svg
    :target: https://pypi.python.org/pypi/knack

.. image:: https://img.shields.io/pypi/pyversions/knack.svg
    :target: https://pypi.python.org/pypi/knack

.. image:: https://dev.azure.com/azure-sdk/public/_apis/build/status/cli/microsoft.knack?branchName=dev
    :target: https://dev.azure.com/azure-sdk/public/_build/latest?definitionId=1643&branchName=dev


------------


::

    _                     _
   | | ___ __   __ _  ___| | __
   | |/ / '_ \ / _` |/ __| |/ /
   |   <| | | | (_| | (__|   <
   |_|\_\_| |_|\__,_|\___|_|\_\


**A Command-Line Interface framework**

Installation is easy via pip:

.. code-block:: bash

    pip install knack

Knack can be installed as a non-privileged user to your home directory by adding "--user" as below:

.. code-block:: bash

    pip install knack --user

------------

.. note:: The project is in `initial development phase <https://semver.org/#how-should-i-deal-with-revisions-in-the-0yz-initial-development-phase>`__. We recommend pinning to at least a specific minor version when marking **knack** as a dependency in your project.

------------


Usage
=====


.. code-block:: python

    import sys
    from collections import OrderedDict

    from knack import CLI, ArgumentsContext, CLICommandsLoader
    from knack.commands import CommandGroup


    def abc_str(length=3):
        import string
        return string.ascii_lowercase[:length]


    class MyCommandsLoader(CLICommandsLoader):
        def load_command_table(self, args):
            with CommandGroup(self, 'abc', '__main__#{}') as g:
                g.command('str', 'abc_str')
            return OrderedDict(self.command_table)

        def load_arguments(self, command):
            with ArgumentsContext(self, 'abc str') as ac:
                ac.argument('length', type=int)
            super(MyCommandsLoader, self).load_arguments(command)


    mycli = CLI(cli_name='mycli', commands_loader_cls=MyCommandsLoader)
    exit_code = mycli.invoke(sys.argv[1:])
    sys.exit(exit_code)

    # $ python mycli.py abc str
    # "abc"

    # $ python mycli.py abc str --length 5
    # "abcde"

    # $ python mycli.py abc str --length 100
    # "abcdefghijklmnopqrstuvwxyz"


More samples and snippets are available at `examples <https://github.com/Microsoft/knack/tree/dev/examples>`__.


Documentation
=============

Documentation is available at `docs <https://github.com/Microsoft/knack/tree/dev/docs>`__.

Developer Setup
===============

In a virtual environment, install the `requirements.txt` file.

.. code-block:: bash

    pip install -r requirements.txt
    pip install -e .

Run Automation
==============

This project supports running automation using `tox <https://tox.readthedocs.io/en/latest/>`__.

.. code-block:: bash

    pip install tox
    tox


Real-world uses
===============

- `Azure CLI <https://github.com/Azure/azure-cli/>`__: The Azure CLI 2.0 is Azure's new command line experience for managing Azure resources.
- `VSTS CLI <https://github.com/Microsoft/vsts-cli>`__: A command-line interface for Visual Studio Team Services (VSTS) and Team Foundation Server (TFS). With the VSTS CLI, you can manage and work with resources including pull requests, work items, builds, and more.
- `Service Fabric CLI <https://github.com/Azure/service-fabric-cli>`__: A command-line interface for interacting with Azure Service Fabric clusters and their related entities.

Do you use knack in your CLI as well? Open a pull request to include it here. We would love to have it in our list.


Release History
===============

See `GitHub Releases <https://github.com/Microsoft/knack/releases>`__.


Contribute Code
===============

This project has adopted the `Microsoft Open Source Code of Conduct <https://opensource.microsoft.com/codeofconduct/>`__.

For more information see the `Code of Conduct FAQ <https://opensource.microsoft.com/codeofconduct/faq/>`__ or contact `opencode@microsoft.com <mailto:opencode@microsoft.com>`__ with any additional questions or comments.

If you would like to become an active contributor to this project, please
follow the instructions provided in `Contribution License Agreement <https://cla.microsoft.com/>`__.


License
=======

Knack is licensed under `MIT <LICENSE>`__.
