# This is free and unencumbered software released into the public domain.

from .activity import Activity
from .airport import Airport
from .appointment import Appointment
from .audio_frame import AudioFrame
from .birth import Birth
from .birthday import Birthday
from .birthday_party import BirthdayParty
from .buddhist_temple import BuddhistTemple
from .cafe import Cafe
from .church import Church
from .class_ import Class
from .community import Community
from .company import Company
from .conference import Conference
from .congregation import Congregation
from .consortium import Consortium
from .corporation import Corporation
from .death import Death
from .event import Event
from .family import Family
from .file import File
from .government import Government
from .graduation import Graduation
from .group import Group
from .hindu_temple import HinduTemple
from .holiday import Holiday
from .hospital import Hospital
from .hotel import Hotel
from .image import Image
from .landmark import Landmark
from .link import Link
from .meeting import Meeting
from .meetup import Meetup
from .mosque import Mosque
from .nationality import Nationality
from .observation import Observation
from .organization import Organization
from .party import Party
from .percept import Percept, VisualPercept
from .person import Person
from .place import Place
from .pub import Pub
from .restaurant import Restaurant
from .school import School
from .synagogue import Synagogue
from .temple import Temple
from .thing import Thing
from .university import University
from .venue import Venue
from .wedding import Wedding


def load(data: dict[str, object]) -> Thing:
    if "@type" in data:
        type = data["@type"]
        if type == "AudioFrame":
            return AudioFrame(None, **data)
        elif type == "Image":
            return Image(None, **data)
        elif type == "Observation":
            return Observation(None, **data)
        elif type == "Percept":
            return Percept(None, **data)
        elif type == "VisualPercept":
            return VisualPercept(None, **data)
    return Thing(None, **data)
