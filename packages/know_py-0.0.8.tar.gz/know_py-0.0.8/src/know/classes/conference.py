# This is free and unencumbered software released into the public domain.

class Conference:
    pass
