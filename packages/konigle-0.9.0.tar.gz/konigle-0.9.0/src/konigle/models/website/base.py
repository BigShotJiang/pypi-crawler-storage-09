"""
Base models and mixins for website resources.

Note: SEOMeta has been moved to konigle.models.base for reuse across modules.
"""
