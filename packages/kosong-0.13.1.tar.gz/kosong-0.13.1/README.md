# Kosong

> Kosong is the emptiness.
