"""
This package holds the main types involved in the Kraken build system to represent a build context, its projects and
tasks.
"""
