

This example tests whether the `lint_enforced_directories` argument applies to Ruff and Mypy as expected by
intentionally leaving errors in the code that we can test for.
