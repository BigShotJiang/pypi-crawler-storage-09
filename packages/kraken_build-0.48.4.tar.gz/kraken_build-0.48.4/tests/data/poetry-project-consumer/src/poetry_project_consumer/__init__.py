from poetry_project import foo

foo()
