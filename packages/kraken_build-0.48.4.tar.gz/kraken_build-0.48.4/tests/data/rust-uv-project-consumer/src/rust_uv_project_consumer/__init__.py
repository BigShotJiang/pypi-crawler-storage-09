from rust_uv_project import sum_as_string

sum_as_string(1, 2)
