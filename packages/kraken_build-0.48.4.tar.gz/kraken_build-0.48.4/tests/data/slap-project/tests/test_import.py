def test_import() -> None:
    exec("from slap_project import *")
