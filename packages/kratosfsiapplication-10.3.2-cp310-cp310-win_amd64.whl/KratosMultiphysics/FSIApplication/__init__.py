from KratosMultiphysics import _ImportApplication
from KratosFSIApplication import *
application = KratosFSIApplication()
application_name = "KratosFSIApplication"

_ImportApplication(application, application_name)
