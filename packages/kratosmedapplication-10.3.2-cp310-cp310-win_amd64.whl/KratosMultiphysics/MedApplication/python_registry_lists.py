from typing import List

python_modelers_to_be_registered: List[str] = ["modelers.import_med_modeler.ImportMedModeler"]

python_operations_to_be_registered: List[str] = []

python_processes_to_be_registered: List[str] = []

python_stages_to_be_registered: List[str] = []

python_orchestrators_to_be_registered: List[str] = []
