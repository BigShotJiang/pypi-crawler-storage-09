python_modelers_to_be_registered = [
    "modelers.convert_linear_tetrahedra_to_quadratic_modeler.ConvertLinearTetrahedraToQuadraticModeler",
]

python_operations_to_be_registered = []

python_processes_to_be_registered = []

python_stages_to_be_registered = []

python_orchestrators_to_be_registered = []