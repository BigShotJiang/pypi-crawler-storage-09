from KratosMultiphysics import _ImportApplication
from KratosMPMApplication import *
application = KratosMPMApplication()
application_name = "KratosMPMApplication"

_ImportApplication(application, application_name)
