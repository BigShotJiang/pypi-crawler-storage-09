class AiType:
    KWAIPILLOT = "kwaipilot"
    OPENAI = "openai"
