# auto-generated: explicit re-exports; wrap dataclasses via loader()
# flake8: noqa
from k8s_models.loader import loader as __loader

from .v1 import UserInfo
from .v1beta1 import SelfSubjectReview, SelfSubjectReviewStatus

UserInfo = __loader(UserInfo)
SelfSubjectReview = __loader(SelfSubjectReview)
SelfSubjectReviewStatus = __loader(SelfSubjectReviewStatus)

__all__ = ['UserInfo', 'SelfSubjectReview', 'SelfSubjectReviewStatus']

