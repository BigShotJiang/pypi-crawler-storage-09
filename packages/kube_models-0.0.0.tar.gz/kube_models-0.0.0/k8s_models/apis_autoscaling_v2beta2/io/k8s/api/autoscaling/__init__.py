# auto-generated: explicit re-exports; wrap dataclasses via loader()
# flake8: noqa
from k8s_models.loader import loader as __loader

from .v2beta2 import ContainerResourceMetricSource, ContainerResourceMetricStatus, CrossVersionObjectReference, ExternalMetricSource, ExternalMetricStatus, HPAScalingPolicy, HPAScalingRules, HorizontalPodAutoscaler, HorizontalPodAutoscalerBehavior, HorizontalPodAutoscalerCondition, HorizontalPodAutoscalerList, HorizontalPodAutoscalerSpec, HorizontalPodAutoscalerStatus, MetricIdentifier, MetricSpec, MetricStatus, MetricTarget, MetricValueStatus, ObjectMetricSource, ObjectMetricStatus, PodsMetricSource, PodsMetricStatus, ResourceMetricSource, ResourceMetricStatus

ContainerResourceMetricSource = __loader(ContainerResourceMetricSource)
ContainerResourceMetricStatus = __loader(ContainerResourceMetricStatus)
CrossVersionObjectReference = __loader(CrossVersionObjectReference)
ExternalMetricSource = __loader(ExternalMetricSource)
ExternalMetricStatus = __loader(ExternalMetricStatus)
HPAScalingPolicy = __loader(HPAScalingPolicy)
HPAScalingRules = __loader(HPAScalingRules)
HorizontalPodAutoscaler = __loader(HorizontalPodAutoscaler)
HorizontalPodAutoscalerBehavior = __loader(HorizontalPodAutoscalerBehavior)
HorizontalPodAutoscalerCondition = __loader(HorizontalPodAutoscalerCondition)
HorizontalPodAutoscalerList = __loader(HorizontalPodAutoscalerList)
HorizontalPodAutoscalerSpec = __loader(HorizontalPodAutoscalerSpec)
HorizontalPodAutoscalerStatus = __loader(HorizontalPodAutoscalerStatus)
MetricIdentifier = __loader(MetricIdentifier)
MetricSpec = __loader(MetricSpec)
MetricStatus = __loader(MetricStatus)
MetricTarget = __loader(MetricTarget)
MetricValueStatus = __loader(MetricValueStatus)
ObjectMetricSource = __loader(ObjectMetricSource)
ObjectMetricStatus = __loader(ObjectMetricStatus)
PodsMetricSource = __loader(PodsMetricSource)
PodsMetricStatus = __loader(PodsMetricStatus)
ResourceMetricSource = __loader(ResourceMetricSource)
ResourceMetricStatus = __loader(ResourceMetricStatus)

__all__ = ['ContainerResourceMetricSource', 'ContainerResourceMetricStatus', 'CrossVersionObjectReference', 'ExternalMetricSource', 'ExternalMetricStatus', 'HPAScalingPolicy', 'HPAScalingRules', 'HorizontalPodAutoscaler', 'HorizontalPodAutoscalerBehavior', 'HorizontalPodAutoscalerCondition', 'HorizontalPodAutoscalerList', 'HorizontalPodAutoscalerSpec', 'HorizontalPodAutoscalerStatus', 'MetricIdentifier', 'MetricSpec', 'MetricStatus', 'MetricTarget', 'MetricValueStatus', 'ObjectMetricSource', 'ObjectMetricStatus', 'PodsMetricSource', 'PodsMetricStatus', 'ResourceMetricSource', 'ResourceMetricStatus']

