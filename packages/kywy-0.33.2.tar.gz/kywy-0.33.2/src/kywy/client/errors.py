class ConflictError(Exception):
    pass
