# 功能: 加密转发服务器
# 1.安装
```bash
pip install l0n0ltcp -U
```
# 2.本地服务器
```bash
l0n0ltransclient -h
正在使用uvloop
usage: l0n0ltransclient [-h] 监听地址 监听端口 服务器地址 服务器端口 密码

启动TCP加密转发客户端

positional arguments:
  监听地址        本地监听地址
  监听端口        本地监听端口
  服务器地址       远程服务器地址
  服务器端口       远程服务器端口
  密码          通信密码

options:
  -h, --help  show this help message and exit
```
# 3. 远端服务器

```bash
l0n0ltransserver -h
usage: l0n0ltransserver [-h] 监听地址 监听端口 服务器地址 服务器端口 密码

启动TCP加密转发服务器

positional arguments:
  监听地址        本地监听地址
  监听端口        本地监听端口
  服务器地址       远程服务器地址
  服务器端口       远程服务器端口
  密码          通信密码

options:
  -h, --help  show this help message and exit
```

# 4. socks5服务器
```bash
l0n0ltranssocks5 -h
usage: l0n0ltranssocks5 [-h] 本地监听地址 本地监听端口

socks5服务器

positional arguments:
  本地监听地址      本地监听地址
  本地监听端口      本地监听端口

options:
  -h, --help  show this help message and exit
```

# 5. 实例
比如远程服务器有一个`http服务器:A(192.168.1.2) `在服务器上监听`127.0.0.1:8080`.是不能被其他主机访问的.

我们还有主机 `B(192.168.1.3)`  是可以被其他主机访问的

* `A` `B` 均表示IP地址

## 5.1 在`A`上执行
```bash
l0n0ltransserver 0.0.0.0 11224 127.0.0.1 8080 123
```
## 5.2 在`B`上执行
```bash
l0n0ltransclient 0.0.0.0 11223 192.168.1.3 11224 123
```
## 5.3 在任意可以访问到`B`的主机上
```bash
curl http://192.168.1.3:11223
```
