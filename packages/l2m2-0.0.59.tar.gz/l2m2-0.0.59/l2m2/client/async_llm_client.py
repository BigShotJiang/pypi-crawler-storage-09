from l2m2.client.base_llm_client import BaseLLMClient


class AsyncLLMClient(BaseLLMClient):
    """A high-level interface for asynchronously interacting with L2M2's supported language models."""
