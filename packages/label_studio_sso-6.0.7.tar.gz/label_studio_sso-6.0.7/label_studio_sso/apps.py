from django.apps import AppConfig


class LabelStudioSsoConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "label_studio_sso"
    verbose_name = "Label Studio SSO"
