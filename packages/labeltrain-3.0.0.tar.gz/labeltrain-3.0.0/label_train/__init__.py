"""
LabelTrain - Lightweight Image Annotation Tool
-----------------------------------------------
This file marks 'label_train' as a Python package.
"""

__version__ = "3.0.1"
__author__ = "Mahdi Mirzakhani"
