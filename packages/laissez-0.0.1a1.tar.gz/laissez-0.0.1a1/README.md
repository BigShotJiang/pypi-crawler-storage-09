# Laissez

Agent spending you can trust


## Pre-Requisites

- Set `WALLET_PRIVATE_KEY` in `.env` equal to the private key for your EVM-compatible account




## Examples

### MCP

With Laissez you can:
* Monetise a FastMCP server by defining payments on tools
* Pay to use paid MCP server tools in your MCP client

See `examples/mcp` for more information