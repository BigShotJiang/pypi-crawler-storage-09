import lamindb as ln

ln.track()
