[![codecov](https://codecov.io/gh/laminlabs/lamindb-setup/branch/main/graph/badge.svg)](https://codecov.io/gh/laminlabs/lamindb-setup)

# lamindb-setup: Setting up `lamindb`

- User [docs](https://lamin.ai/docs)
- Developer [docs](https://lamindb-setup-htry.netlify.app/)
