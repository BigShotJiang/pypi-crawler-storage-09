from lamindb_setup import django


def test_django():
    django("sqlsequencereset", "lamindb")
