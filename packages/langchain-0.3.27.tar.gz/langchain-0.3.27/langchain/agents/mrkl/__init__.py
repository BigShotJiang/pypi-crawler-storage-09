"""Attempt to implement MRKL systems as described in arxiv.org/pdf/2205.00445.pdf."""
