"""LangChain integration for Chroma vector database."""

from langchain_chroma.vectorstores import Chroma

__all__ = [
    "Chroma",
]
