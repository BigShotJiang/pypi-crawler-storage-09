import pytest


@pytest.mark.compile
def test_placeholder() -> None:
    pass
