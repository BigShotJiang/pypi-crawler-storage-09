"""Nomic partner integration for LangChain."""

from langchain_nomic.embeddings import NomicEmbeddings

__all__ = ["NomicEmbeddings"]
