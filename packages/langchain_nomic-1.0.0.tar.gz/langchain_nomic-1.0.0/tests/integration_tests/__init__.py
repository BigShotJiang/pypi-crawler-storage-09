"""Integration tests for Nomic partner integration."""
