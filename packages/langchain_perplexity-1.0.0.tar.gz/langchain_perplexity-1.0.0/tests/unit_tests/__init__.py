import os

os.environ["PPLX_API_KEY"] = "test"
