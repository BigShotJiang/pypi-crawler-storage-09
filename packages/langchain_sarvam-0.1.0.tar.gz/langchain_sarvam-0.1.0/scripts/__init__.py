"""Scripts for Sarvam partner integration."""
