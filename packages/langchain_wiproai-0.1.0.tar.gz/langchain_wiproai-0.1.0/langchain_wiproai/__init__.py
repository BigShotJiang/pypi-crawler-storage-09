"""LangChain integration for Wipro AI."""

from langchain_wiproai.chat_models import ChatWiproAI

__version__ = "0.1.0"
__all__ = ["ChatWiproAI"]
