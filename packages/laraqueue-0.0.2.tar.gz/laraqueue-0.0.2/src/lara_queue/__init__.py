__version__ = "0.0.2"
from .queue import Queue

__all__ = ['Queue', '__version__']