"""Scripts for lattifai package installation."""
