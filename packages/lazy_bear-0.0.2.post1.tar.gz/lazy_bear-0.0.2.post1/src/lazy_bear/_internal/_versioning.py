from __future__ import annotations

from enum import IntEnum
from importlib.metadata import PackageNotFoundError, version
import re
from typing import Any, Literal, Self

from pydantic import BaseModel, Field

BumpType = Literal["major", "minor", "patch"]


class ExitCode(IntEnum):  # pragma: no cover
    """Enumeration for exit codes."""

    SUCCESS = 0
    FAILURE = 1


class VersionParts(IntEnum):  # pragma: no cover
    """Enumeration for version parts."""

    MAJOR = 0
    MINOR = 1
    PATCH = 2

    @classmethod
    def choices(cls) -> list[str]:
        """Return a list of valid version parts."""
        return [part.name for part in cls]

    @classmethod
    def parts(cls) -> int:
        """Return the total number of version parts."""
        return len(cls.choices())


class Parts[*P](tuple):  # pragma: no cover
    """A list subclass to represent version parts."""

    THREE_PARTS = 3
    FOUR_PARTS = 4

    @classmethod
    def split(cls, s: str, sep: str = ".") -> Parts[Any]:
        """A quick split method."""
        return Parts[int | str]([part for part in s.split(sep) if part][:4])

    @property
    def three(self) -> bool:
        """Check if the version has three parts."""
        return len(self) == self.THREE_PARTS

    @property
    def four(self) -> bool:
        """Check if the version has four parts."""
        return len(self) == self.FOUR_PARTS

    def to_three(self) -> Parts[int, int, int]:
        """Assert this is has three parts."""
        if self.three and self.is_valid:
            return Parts[int, int, int](self)
        raise ValueError("Has less or more than three parts.")

    def to_four(self) -> Parts[int, int, int, str]:
        """Assert this is has three parts."""
        if self.four and self.is_valid:
            return Parts[int, int, int, str](self)
        raise ValueError(f"Has less or more than four parts: {self}")

    def check_three_parts(self) -> bool:
        """Check that the first three parts are integers."""
        return len(self) >= self.THREE_PARTS and all(isinstance(int(part), int) for part in self[:3])

    def check_forth_part(self) -> bool:
        """Check that 4th part is a str."""
        return self.four and isinstance(str(self[3]), str)

    @property
    def is_valid(self) -> bool:
        """Check if the version parts are valid."""
        if self.three:
            return self.check_three_parts()
        if self.four:
            return self.check_three_parts() and self.check_forth_part()
        return False


class Version(BaseModel):  # pragma: no cover
    """Model to represent a version string."""

    major: int = 0
    """Major version number."""
    minor: int = 0
    """Minor version number."""
    patch: int = 0
    """Patch version number."""
    post: str | None = Field(default=None)
    """Post-release identifier."""

    def __repr__(self) -> str:
        """Return a string representation of the Version instance."""
        return (
            f"{self.major}.{self.minor}.{self.patch}.{self.post}"
            if self.post
            else f"{self.major}.{self.minor}.{self.patch}"
        )

    def __str__(self) -> str:
        """Return a string representation of the Version instance."""
        return self.__repr__()

    @classmethod
    def from_parts(cls, parts: Parts[Any]) -> Self:
        """Create a Version instance from individual parts."""
        if parts.three:
            int_parts: Parts[int, int, int] = parts.to_three()
            return cls(major=int_parts[0], minor=int_parts[1], patch=int_parts[2])
        if parts.four:
            full_parts: Parts[int, int, int, str] = parts.to_four()
            return cls(major=full_parts[0], minor=full_parts[1], patch=full_parts[2], post=full_parts[3])
        raise ValueError(f"Invalid number of parts. Expected 3 or 4 parts: {parts}")

    @classmethod
    def from_string(cls, version_str: str) -> Self:
        """Create a Version instance from a version string.

        Args:
            version_str: A version string in the format "major.minor.patch".

        Returns:
            A Version instance.

        Raises:
            ValueError: If the version string is not in the correct format.
        """
        if "-" in version_str:
            version_str = version_str.split("-")[0]
        if "+" in version_str:
            version_str = version_str.split("+")[0]
        version_str = re.sub(r"^[vV]", "", version_str)
        return cls.from_parts(Parts.split(version_str, "."))

    def increment(self, attr_name: str) -> None:
        """Increment the specified part of the version."""
        setattr(self, attr_name, getattr(self, attr_name) + 1)

    def default(self, part: str) -> None:
        """Clear the specified part of the version.

        Args:
            part: The part of the version to clear.
        """
        if hasattr(self, part):
            setattr(self, part, 0)

    def new_version(self, bump_type: str) -> Version:
        """Return a new version string based on the bump type."""
        bump_part: VersionParts = VersionParts[bump_type.upper()]
        self.increment(bump_part.name)
        for part in VersionParts:
            if part.value > bump_part.value:
                self.default(part.name)
        return self

    @classmethod
    def from_meta(cls, package_name: str) -> Self:
        """Create a Version instance from the current package version.

        Returns:
            A Version instance with the current package version.

        Raises:
            PackageNotFoundError: If the package is not found.
        """
        try:
            return cls.from_string(version(package_name))
        except PackageNotFoundError as e:
            raise PackageNotFoundError(f"Package '{package_name}' not found: {e}") from e


VALID_BUMP_TYPES: list[str] = VersionParts.choices()  # pragma: no cover
ALL_PARTS: int = VersionParts.parts()  # pragma: no cover


def bump_version(version: str, bump_type: BumpType) -> Version:  # pragma: no cover
    """Bump the version based on the specified type, mutating in place since there is no reason not to.

    Args:
        version: The current version string (e.g., "1.2.3").
        bump_type: The type of bump ("major", "minor", or "patch").

    Returns:
        The new version string.

    Raises:
        ValueError: If the version format is invalid or bump_type is unsupported.
    """
    return Version.from_string(version).new_version(bump_type)


def get_version(package_name: str) -> str:  # pragma: no cover
    """Get the version of the specified package.

    Args:
        package_name: The name of the package to get the version for.

    Returns:
        A Version instance representing the current version of the package.

    Raises:
        PackageNotFoundError: If the package is not found.
    """
    version: str | None = cli_get_version(package_name)
    if version is not None:
        return version
    raise ValueError("Not able to find package name.")


def cli_get_version(pkg_name: str) -> str | None:  # pragma: no cover
    """Get the version of the current package.

    Returns:
        The version of the package.
    """
    try:
        current_version: str = version(pkg_name)
    except PackageNotFoundError:
        print(f"Package '{pkg_name}' not found.")
        return None
    return current_version


def cli_bump(b: BumpType, p: str, v: str | tuple[int, int, int]) -> ExitCode:  # pragma: no cover
    """Bump the version of the current package.

    Args:
        b: The type of bump ("major", "minor", or "patch").
        p: The name of the package.
        v: The current version string or tuple of version parts.

    Returns:
        An ExitCode indicating success or failure.
    """
    if b not in VALID_BUMP_TYPES:
        print(f"Invalid argument '{b}'. Use one of: {', '.join(VALID_BUMP_TYPES)}.")
        return ExitCode.FAILURE

    if isinstance(v, tuple):
        try:
            parts: Parts[*tuple[Any, ...]] = Parts(v)
            version: Version = Version.from_parts(parts)
            new_version = version.new_version(b)
            print(str(new_version))
            return ExitCode.SUCCESS
        except ValueError:
            new_version = Version.from_meta(package_name=p).new_version(b)
            print(str(new_version))
            return ExitCode.SUCCESS
    try:
        new_version: Version = bump_version(version=v, bump_type=b)
        print(str(new_version))
        return ExitCode.SUCCESS
    except ValueError as e:
        print(f"Error: {e}")
        return ExitCode.FAILURE
    except Exception as e:
        print(f"Unexpected error: {e}")
        return ExitCode.FAILURE


__all__ = ["Parts", "Version", "VersionParts"]
