from .parallel.mpilop import MPILop # temporary alias (will be deleted later)
