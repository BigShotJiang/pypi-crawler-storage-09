from .is_power_of_two import is_power_of_two
