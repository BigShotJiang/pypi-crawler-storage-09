"""
Entry point for running lean_agent as a module.
Usage: python -m lean_dojo_v2.lean_agent
"""

from lean_dojo_v2.agent.lean_agent import main

if __name__ == "__main__":
    main()
