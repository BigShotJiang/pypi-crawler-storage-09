STATIC_INTERACT_MODE_ALIASES = ["static_ipywidgets", "panel"]
