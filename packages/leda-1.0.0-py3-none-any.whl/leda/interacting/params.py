import dataclasses
from typing import Any

import IPython

import leda.interacting.core


def get_param(
    name: str,
    dynamic_default: Any = dataclasses.MISSING,
    static_default: Any = dataclasses.MISSING,
    default: Any = dataclasses.MISSING,
) -> Any:
    ipython = IPython.get_ipython()
    assert ipython is not None  # For typing
    user_ns = ipython.user_ns
    if name in user_ns:
        return user_ns[name]

    dynamic_mode = leda.interacting.core.get_interact_mode().dynamic

    if default is not dataclasses.MISSING:
        return default
    elif dynamic_default is not dataclasses.MISSING and dynamic_mode:
        return dynamic_default
    elif static_default is not dataclasses.MISSING and not dynamic_mode:
        return static_default

    raise NameError(name)
