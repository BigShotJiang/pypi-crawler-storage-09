from enum import Enum


class CitraEnvironment(Enum):
    PRODUCTION = "prod"
    DEVELOPMENT = "dev"
