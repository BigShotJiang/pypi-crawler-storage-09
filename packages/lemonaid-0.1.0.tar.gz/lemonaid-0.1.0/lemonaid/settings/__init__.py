from lemonaid.settings._citra_client_settings import CitraClientSettings

CITRA_CLIENT_SETTINGS = CitraClientSettings()

__all__ = ["CITRA_CLIENT_SETTINGS"]
