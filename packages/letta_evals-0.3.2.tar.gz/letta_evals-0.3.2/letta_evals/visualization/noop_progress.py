from __future__ import annotations

from typing import Dict, Optional

from letta_evals.visualization.base import ProgressCallback


class NoOpProgress(ProgressCallback):
    """No-output progress callback (silent)."""

    async def sample_started(self, sample_id: int, model_name: Optional[str] = None) -> None:
        pass

    async def sample_completed(
        self,
        sample_id: int,
        passed: bool,
        score: Optional[float] = None,
        model_name: Optional[str] = None,
        metric_scores: Optional[Dict[str, float]] = None,
        metric_pass: Optional[Dict[str, bool]] = None,
        rationale: Optional[str] = None,
        metric_rationales: Optional[Dict[str, str]] = None,
    ) -> None:
        pass

    async def sample_error(self, sample_id: int, error: str, model_name: Optional[str] = None) -> None:
        pass
