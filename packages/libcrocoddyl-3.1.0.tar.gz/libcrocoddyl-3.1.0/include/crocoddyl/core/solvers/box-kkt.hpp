///////////////////////////////////////////////////////////////////////////////
// BSD 3-Clause License
//
// Copyright (C) 2019, LAAS-CNRS
// Copyright note valid unless otherwise stated in individual files.
// All rights reserved.
///////////////////////////////////////////////////////////////////////////////

#ifndef CROCODDYL_CORE_SOLVERS_BOX_KKT_HPP_
#define CROCODDYL_CORE_SOLVERS_BOX_KKT_HPP_

// TODO: SolverBoxKKT

#endif  // CROCODDYL_CORE_SOLVERS_BOX_KKT_HPP_
