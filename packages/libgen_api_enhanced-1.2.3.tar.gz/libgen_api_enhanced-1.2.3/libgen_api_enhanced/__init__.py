from .search_request import SearchRequest, SearchType, SearchTopic
from .libgen_search import LibgenSearch
