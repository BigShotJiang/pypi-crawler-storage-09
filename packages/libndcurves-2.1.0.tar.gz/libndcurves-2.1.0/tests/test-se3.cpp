#define EIGEN_RUNTIME_NO_MALLOC
#define BOOST_TEST_MODULE test_se3

#include <boost/test/included/unit_test.hpp>

#include "ndcurves/fwd.h"
#include "ndcurves/se3_curve.h"

using namespace ndcurves;

BOOST_AUTO_TEST_SUITE(BOOST_TEST_MODULE)

BOOST_AUTO_TEST_CASE(constructors) { BOOST_CHECK(true); }

BOOST_AUTO_TEST_SUITE_END()
