"""Initial revision

Revision ID: 3c4e800178ab
Revises:
Create Date: 2024-11-29 16:45:55.161495

"""

from typing import Sequence, Union

# revision identifiers, used by Alembic.
revision: str = "3c4e800178ab"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass
