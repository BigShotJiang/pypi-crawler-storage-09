class ResourceLinkState:
    ACTIVE = "active"
    RESIDUAL = "residual"
