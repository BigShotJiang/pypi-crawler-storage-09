class NoExtractorError(Exception):
    pass
