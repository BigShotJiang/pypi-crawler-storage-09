# libs5-python

`libs5-python` is a package with `Python` scripts, and helper classes which are used e.g. in `BEANS` software


## Installation

To install `libs5-python` type in the console:

```
pip install libs5-python
```

To upgrade `libs5-python` type in the console:

```
pip install libs5-python --upgrade
```

## Roadmap

There is no specific roadmap for `libs5-python`. New features are added if they are needed.

## Contributing

Feel free to contribute to this project by sending me your opinion, patches, or requesting some features through gitlab issue system.

## Links

Home page: https://gitlab.com/ahypki/libs5-python/
Issues   : https://gitlab.com/ahypki/libs5-python/-/issues/

## License

`libs5-python` is released under the MIT license.
