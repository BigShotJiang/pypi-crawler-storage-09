#ifndef TSID_CONTACTS_MEASURED_3DFORCE_HPP
#define TSID_CONTACTS_MEASURED_3DFORCE_HPP

#include "tsid/contacts/measured-3d-force.hpp"

#ifdef _MSC_VER
#pragma message( \
    "TSID DEPRECATED: Please update your includes from 'measured-3Dforce.hpp' to 'measured-3d-force.hpp'")
#else
#warning \
    "TSID DEPRECATED: Please update your includes from 'measured-3Dforce.hpp' to 'measured-3d-force.hpp'"
#endif

#endif  // TSID_CONTACTS_MEASURED_3DFORCE_HPP
