class LibXRInfo:
    COMMIT = 'bdc3a8e5545d3edacf35935d97906644ec2f8ec6'
