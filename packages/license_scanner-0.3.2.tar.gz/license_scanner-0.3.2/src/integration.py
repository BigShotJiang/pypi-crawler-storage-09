# %%
from license_scanner.cli import main

main()

# %%
from license_scanner import get_all_licenses

all_licenses = get_all_licenses()

# %%
