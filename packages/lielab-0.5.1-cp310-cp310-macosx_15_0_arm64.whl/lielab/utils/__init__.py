from .utils import opt_golden, newton

from ..cppLielab.utils import bernoulli

# Eigentools
from ..cppLielab.utils import concatenate, arange, repeat, tile, linspace, logspace, column_stack, vertical_stack, linear_interpolate

