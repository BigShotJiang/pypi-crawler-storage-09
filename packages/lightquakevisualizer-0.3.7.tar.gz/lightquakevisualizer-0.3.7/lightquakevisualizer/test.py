import os
a="a"
if a:
    print(True)
print(os.path.exists(""))
os.makedirs("")
