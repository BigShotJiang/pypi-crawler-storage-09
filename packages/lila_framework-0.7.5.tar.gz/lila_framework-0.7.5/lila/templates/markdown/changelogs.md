# {{ translate["changelogs"] }}

## 0.7.5 GZIP-ZSTD / TrustedHost
 {{ translate["support_gzip_or_zstd"] }}
 {{ translate["TrustedHost"] }}

## 0.7.4

### {{ translate["auth_scaffold"] }}
{{ translate["auth_scaffold_desc"] }}

**Command:**
```bash
python -m cli.auth
```

>{{ translate["auth_scaffold_features"] }}

---
## 0.7.2

### {{ translate["create_panel_admin"] }}
- {{ translate["create_panel_admin_desc"] }}
 -    python -m cli.create_panel_admin --password mypassword 

### {{ translate["create_admin"] }}
- {{ translate["create_admin_desc"] }}
 -    python -m cli.create_admin --password mypassword 

### {{ translate["pydantic_v2"] }}
- {{ translate["pydantic_v2_desc"] }}

### {{ translate["starlette_latest"] }}
- {{ translate["starlette_latest_desc"] }}

### {{ translate["psycopg2_latest"] }}
- {{ translate["psycopg2_latest_desc"] }}

### {{ translate["rest_crud_generate_html"] }}
-  {{ translate["rest_crud_generate_html_desc"] }}
- `generate_html: bool = True`  
- `rewrite_template: bool = False`  
-url: {model_sql}\view

### {{ translate["Minify_CLI"] }}
> {{ translate["We've improved the CLI for minifying"] }}

### {{ translate["Compress HTML"] }}
> {{ translate["now always compress response html  and always and minifyin"] }}
