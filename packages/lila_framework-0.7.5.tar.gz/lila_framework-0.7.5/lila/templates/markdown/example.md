# {{ translate["Welcome to My Website"] }}

This is a simple **Markdown** example. 

## {{ translate["features"] }}
- {{ translate["easy_write"] }}
- {{ translate["convert_html"] }}
- {{ translate["supports_links"] }}

### {{ translate["example_code"] }}

```
print("Hello, Markdown!")
```

