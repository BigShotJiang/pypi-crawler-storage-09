from enum import Enum


class YesNoOption(Enum):
    YES = "Y"
    NO = "N"
