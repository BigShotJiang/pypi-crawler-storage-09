class LineWorksException(Exception):
    pass


class LogicException(LineWorksException):
    pass


class LoginException(LineWorksException):
    pass
