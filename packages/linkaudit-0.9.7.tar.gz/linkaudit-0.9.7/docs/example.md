# Example Output

## Example of showlinks

The output of `linkaudit showlinks` to show all links is a `html` file.

Example `html` output file when `linkaudit` command is run on this documentation:

[ Click here to view an example](example_show.html)


## Example of checklinks

Example `html` output file when `linkaudit checklinks` command is run on this documentation:

[ Click here to view an example](example_check.html)


