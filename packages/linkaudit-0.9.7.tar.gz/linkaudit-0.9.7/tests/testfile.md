# Testset

This is some text with a URL: https://www.example.com and another one: http://anothersite.org/page?param=value.

No URLs here.

A URL in parentheses: (https://www.google.com/search?q=python) and one with special chars: https://example.com/page#section.

A markdown link: [Example](https://www.example.com) and a myst link: [Example](https://www.example.com).

URL with port: http://localhost:8000/api/data

[Jupyter Book](https://jupyterbook.org "JB Homepage") and [Another link](http://anothersite.com)

Mixed: https://google.com [Link1](https://example.net) text http://site.org/page [Link 2](https://anothersite.co.uk 'Title')

[Jupyter Book](https://jupyterbook.org)

[Jupyter Book](https://jupyterbook.org "JB Homepage")

https://jupyterbook.org

http://jupyterbook.org

[NOCX](nocomplexity.com)

pandas can be installed via pip from `PyPI <https://pypi.org/project/pandas>`__.

<https://ipycanvas.readthedocs.io/en/latest/>

repository_url: "https://gitlab.com/nocomplexity/simplepub"

