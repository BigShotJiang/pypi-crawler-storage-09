"""LinkGuard - Automated link validation for developers."""

__version__ = "1.0.1"
