"""Model package containing issue types and configuration structures."""
