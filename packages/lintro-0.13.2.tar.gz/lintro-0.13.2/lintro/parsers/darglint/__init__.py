"""Parsing utilities and types for Darglint output."""
