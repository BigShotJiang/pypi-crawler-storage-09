"""Hadolint parser module."""
