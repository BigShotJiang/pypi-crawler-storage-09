"""Utility package providing helpers for formatting and execution."""
