"""Core data models used across tool integrations."""
