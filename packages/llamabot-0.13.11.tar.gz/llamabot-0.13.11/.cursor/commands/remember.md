Take what you've just learned, or what I'm about to give you, and write it into AGENTS.md to remember for the future.
