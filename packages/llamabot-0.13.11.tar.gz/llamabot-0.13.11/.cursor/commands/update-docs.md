I'd like you to do a deep dive into the docs and the codebase and tell me where the docs are out-of-date.
