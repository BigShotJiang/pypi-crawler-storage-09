---
intents:
- Provide a tutorial (as defined by the Diataxis framework) on how to use the prime number function.
- Explain any optimizations made in the source code.
linked_files:
- tests/cli/assets/next_prime/source.py
---
