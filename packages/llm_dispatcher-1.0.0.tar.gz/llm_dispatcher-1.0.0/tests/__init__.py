"""
Test suite for LLM-Dispatcher package.

This module contains tests for all components of the LLM-Dispatcher package
including providers, switching engine, decorators, and utilities.
"""
