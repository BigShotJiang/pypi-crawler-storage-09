# Code of Conduct

## Our Pledge

We pledge to make participation in our project a harassment-free experience for everyone.

## Standards

- Be respectful and inclusive
- Accept constructive criticism
- Focus on what's best for the community

## Enforcement

Instances of unacceptable behavior may be reported to rohit.garuda1992@gmail.com
