# Quick and dirty black-box tests

TODO: clean them
