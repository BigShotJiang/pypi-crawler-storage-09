"""Configuration models for agent capabilities."""

from llmling_agent.config.capabilities import Capabilities

__all__ = ["Capabilities"]
