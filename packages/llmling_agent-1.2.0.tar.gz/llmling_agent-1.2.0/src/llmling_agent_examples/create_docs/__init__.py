"""Example showing agent collaboration for documentation generation."""

TITLE = "Create Docs"
ICON = "octicon:book-16"
