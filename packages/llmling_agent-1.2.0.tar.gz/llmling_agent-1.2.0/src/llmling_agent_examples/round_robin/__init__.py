"""Round Robin Example."""

TITLE = "Round-Robin Communication"
ICON = "octicon:sync-16"
