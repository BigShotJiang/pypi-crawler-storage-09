"""Textual input provider package."""

from __future__ import annotations

from llmling_agent_input.textual_provider.provider import TextualInputProvider

__all__ = ["TextualInputProvider"]
