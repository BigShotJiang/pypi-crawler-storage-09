"""Prompt template management."""
