#module for accessing variables across modules in workflow
#https://docs.python.org/3/faq/programming.html?highlight=global#how-do-i-share-global-variables-across-modules
channel = 0
time = 0 
#configure default logging level for use in packages; inherit from dock_widget or __main__.py
log_level = 10