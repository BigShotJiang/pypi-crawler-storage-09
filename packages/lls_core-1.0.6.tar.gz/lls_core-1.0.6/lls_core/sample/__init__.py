import importlib_resources

resources = importlib_resources.files(__name__)
