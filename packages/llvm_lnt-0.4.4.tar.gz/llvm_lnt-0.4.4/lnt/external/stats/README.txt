This directory contains some useful statistics modules from Gary Strangman. They
are more easily available inside SciPy, but we don't want to introduce a
dependency onto SciPy solely for this functionality.
