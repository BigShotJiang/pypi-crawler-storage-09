from .main import main  # noqa: F401  # LNT entrypoint
