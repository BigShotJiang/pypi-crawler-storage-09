"""
Test rule system. A simple rules, with one hook that can be run.
"""


def test():
    return "Foo."


post_test_hook = test
