This directory contains some "fake" compilers, they just respond to arguments in
a way to mimic what the actual compiler would do (for testing the
lnt.testing.util.compilers module).
