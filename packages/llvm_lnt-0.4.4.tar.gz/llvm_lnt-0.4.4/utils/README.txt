Utilities for the LNT project that aren't intended to be part of a source
distribution.
