This directory contains schema files describing test suites. You can copy them
or create symlinks to the schemas directory of an lnt instance to enable them.
