This is a dummy set of LLVM test-suite sources, just intended for use with
testing the 'lnt runtest test-suite' module.
