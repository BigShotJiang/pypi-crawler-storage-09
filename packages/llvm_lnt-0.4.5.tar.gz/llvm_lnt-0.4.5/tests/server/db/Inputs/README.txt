This directory contains instances of previous versions of LNT, used for
migration testing.

Currently the instances are:

  lnt_v0.4.0_basic_instance
    A LNT v0.4.0 instance just after 'lnt create'.

  lnt_v0.4.0_filled_instance
    A LNT v0.4.0 instance that has been populated with some data.
