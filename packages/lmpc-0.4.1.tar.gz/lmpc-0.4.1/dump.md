## This is the actual
```json
{
    "julia": "=1.11.5",
    "packages": {
        "LinearMPC": {
            "uuid": "82e1c212-e1a2-49d2-b26a-a31d6968e3bd", 
            "version": "0.3.0"
        }
    }
}
```
## Alternative
{
    "julia": "=1.11.5",
    "packages": {
        "LinearMPC": {
            "uuid": "82e1c212-e1a2-49d2-b26a-a31d6968e3bd", 
            "url": "https://github.com/darnstrom/LinearMPC.jl",
            "rev": "dev"
        }
    }
}
