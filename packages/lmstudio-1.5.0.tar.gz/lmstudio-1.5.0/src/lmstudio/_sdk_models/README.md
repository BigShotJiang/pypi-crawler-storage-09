lmstudio-js SDK Data Model
==========================

The Python data model class definitions in this folder are generated from
the lmstudio-js zod schema files rather than being maintained directly.

These files should NOT be modified: if the messaging protocol details
change, updates should be made in lmstudio-js first, and then exported
to the Python SDK via the automated code generation.

See the `sdk-schema` exporter folder for additional details.
