"""Async test cases that can be automatically converted to sync test cases."""
