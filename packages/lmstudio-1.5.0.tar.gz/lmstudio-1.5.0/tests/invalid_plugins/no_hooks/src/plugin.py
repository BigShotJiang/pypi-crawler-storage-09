# No hooks defined, runner will refuse to execute this plugin
