"""Sync test cases that are automatically generated from async test cases."""
