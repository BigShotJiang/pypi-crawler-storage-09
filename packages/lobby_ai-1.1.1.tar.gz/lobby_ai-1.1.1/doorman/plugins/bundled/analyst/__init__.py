"""Doorman agent plugin: analyst."""
