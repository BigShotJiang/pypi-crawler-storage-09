"""Doorman agent plugin: developer."""
