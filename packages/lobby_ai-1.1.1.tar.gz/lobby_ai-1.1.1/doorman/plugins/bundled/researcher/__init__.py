"""Doorman agent plugin: researcher."""
