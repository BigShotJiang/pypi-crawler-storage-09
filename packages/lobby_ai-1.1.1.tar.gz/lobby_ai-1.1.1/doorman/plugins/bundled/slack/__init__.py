"""Doorman tool plugin: slack."""
