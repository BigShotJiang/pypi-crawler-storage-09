"""Doorman agent plugin: writer."""
