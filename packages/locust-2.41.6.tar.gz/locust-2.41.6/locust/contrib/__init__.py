# This directory contains modules that are experimental.

# Generally they should not have any significant issues, but they may change without a major version bump for locust.

# Some modules may require optional dependencies, typically installed with `pip install locust[name-of-module]`.
