"""Tests for loppers library."""
