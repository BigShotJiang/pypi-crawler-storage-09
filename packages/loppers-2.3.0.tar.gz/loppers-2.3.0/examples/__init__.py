"""Examples for loppers library."""
