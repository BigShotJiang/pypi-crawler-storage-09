# setup.py

from setuptools import setup, find_packages

setup(
    name = 'lq-feishu-oapi',
    version = '0.0.1',
    packages = find_packages(),
    description = '飞书扩展库',
    author = '你的名字',
    author_email = 'you@example.com',
    url = 'https://gitee.com/my/my',  # 替换为你的GitHub仓库URL
    classifiers = [
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires = '>=3.6',
    install_requires = [],
)
