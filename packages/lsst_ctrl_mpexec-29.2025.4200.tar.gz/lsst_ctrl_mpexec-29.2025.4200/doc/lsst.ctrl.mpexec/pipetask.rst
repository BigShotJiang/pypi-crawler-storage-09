.. _pipetask-command:

.. click:: lsst.ctrl.mpexec.cli.pipetask:cli
    :prog: pipetask
    :show-nested:
