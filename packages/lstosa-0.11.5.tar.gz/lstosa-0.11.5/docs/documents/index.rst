.. _documents: 

Documents
*********

Publications
============

.. _adass2020:

ADASS XXX (2020):
 * Poster: https://adass2020.es/static/ftp/P8-138/P8-138.pdf
 * Proceedings: https://arxiv.org/abs/2101.09690