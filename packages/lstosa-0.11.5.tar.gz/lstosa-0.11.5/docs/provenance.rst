.. _provenance:

Provenance
==========

Module implemented by José Enrique Ruiz to capture the provenance of the LSTOSA analysis products.

Reference/API
+++++++++++++

.. automodapi:: osa.provenance.capture
.. automodapi:: osa.provenance.io
.. automodapi:: osa.provenance.utils