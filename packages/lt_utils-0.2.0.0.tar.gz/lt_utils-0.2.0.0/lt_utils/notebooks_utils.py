__all__ = ["show_audio", "show_image", "show_video"]
import numpy as np
from typing import Union, List, Any


def show_audio(
    audio_track: Union[np.ndarray, List],
    sample_rate: int = 24000,
):
    import IPython.display as iDisplay

    if not isinstance(audio_track, np.ndarray):
        audio_track = np.asanyarray(audio_track).squeeze()
    return iDisplay.display(iDisplay.Audio(audio_track, rate=sample_rate))


def show_image(image: Any):
    import IPython.display as iDisplay

    try:
        return iDisplay.display(iDisplay.Image(image))
    except Exception as e:
        try:
            return iDisplay.display(image)
        except:
            raise e


def display_video(video: Any):
    import IPython.display as iDisplay

    try:
        return iDisplay.display(iDisplay.Video(video))
    except Exception as e:
        try:
            return iDisplay.display(video)
        except:
            raise e
