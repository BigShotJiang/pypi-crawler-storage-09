
class ManipsMixin:

    def _init_manips(self):
        pass
    
