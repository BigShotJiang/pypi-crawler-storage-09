
# scope.py

class ScopeMixin:
    def _init_viewer(self):
        # wire viewer widgets here
        pass
