# Lyric — Coming Soon

**Lyric** is a statically typed, expressive programming language designed for clarity, creativity, and speed.  
This package is a **placeholder release** from **MiraNova Studios**, reserving the PyPI namespace `lyric-lang`.

When installed, it simply prints a message:

```bash
$ lyric
────────────────────────────────────────────────
           Lyric Programming Language
         © 2025 MiraNova Studios

    Lyric is coming soon.
    Visit http://miranova.studio/lyric.html
────────────────────────────────────────────────
```

# LICENSE

```
Lyric Language License (MIT with Source Attribution)

Copyright (c) 2025 MiraNova Studios

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

1. The above copyright notice and this permission notice shall be included in
   all copies or substantial portions of the Software.

2. Attribution to MiraNova Studios is required only when redistributing,
   modifying, or incorporating the Lyric source code into another software
   project. Attribution is not required for users who simply write, run,
   or distribute programs written in the Lyric programming language.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```
