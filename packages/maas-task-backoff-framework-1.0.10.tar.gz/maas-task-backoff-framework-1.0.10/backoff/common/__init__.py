#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""common模块初始化文件"""