

winget install Gyan.FFmpeg

