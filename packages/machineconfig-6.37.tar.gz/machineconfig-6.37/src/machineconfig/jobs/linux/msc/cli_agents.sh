#!/bin/bash


# Vscode extensions for AI-assisted coding.
# Github copilot
# Roo
# Cline
# Kilocode
# Continue
# CodeGPT
# qodo (and cli)

# Editors based on AI
# Kiro
# Cursor
# Warp
