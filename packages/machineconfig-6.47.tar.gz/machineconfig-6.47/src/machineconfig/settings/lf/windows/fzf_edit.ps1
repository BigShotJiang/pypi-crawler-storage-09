
nano.ps1 (fzfb)  # space use for presedence in execution.
# fzf --ansi --preview-window 'right:60%' --preview 'bat --color=always --style=numbers,grid,header --line-range :300 {}'
# & "C:\Program Files\Git\usr\bin\nano.exe" (fzf --ansi --preview-window 'right:60%' --preview 'bat --color=always --style=numbers,grid,header --line-range :300 {}')
# fzf | nano.ps1

