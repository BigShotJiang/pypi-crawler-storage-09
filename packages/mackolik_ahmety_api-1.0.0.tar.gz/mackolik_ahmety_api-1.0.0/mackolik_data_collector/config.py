"""
⚙️ CONFIGURATION
================

Veritabanı ve API ayarları - TEK YER!
"""

# Veritabanı bağlantı bilgileri
DB_CONFIG = {
    'host': '167.71.74.229',
    'port': 5432,
    'database': 'mackolik_db',
    'user': 'mackolik_user',
    'password': 'GucluSifre123!'
}

# Bağlantı string'i
DB_URL = f"postgresql://{DB_CONFIG['user']}:{DB_CONFIG['password']}@{DB_CONFIG['host']}:{DB_CONFIG['port']}/{DB_CONFIG['database']}"

# API ayarları
API_CONFIG = {
    'base_url': 'https://vd.mackolik.com/livedata',
    'headers': {
        'accept': '*/*',
        'origin': 'https://arsiv.mackolik.com',
        'user-agent': 'Mozilla/5.0'
    },
    'retry_count': 3,
    'retry_delay': 60  # saniye
}

# Tablo isimleri
TABLE_NAMES = {
    'results': 'results',
    'fixtures': 'fixtures'
}
