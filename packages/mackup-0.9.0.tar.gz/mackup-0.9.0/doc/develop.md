# Develop

```sh
# Install the tool for dependency management and packaging in Python
pipx install uv

# You can now edit files and see the impact of your changes
uv run mackup --version
make test
```
