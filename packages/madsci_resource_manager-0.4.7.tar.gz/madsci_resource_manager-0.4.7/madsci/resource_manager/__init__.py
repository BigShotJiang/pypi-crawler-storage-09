"""MADSci Resource Manager."""
