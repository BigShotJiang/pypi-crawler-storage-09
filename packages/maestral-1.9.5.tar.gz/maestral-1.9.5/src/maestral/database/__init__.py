"""
This module provides a light-weight ORM to map between Python objects and an SQLite
database. It is currently limited in functionality by what Maestral requires.
"""
