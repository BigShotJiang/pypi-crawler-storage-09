# -*- coding: utf-8 -*-

__author__ = "Sam Schott"
__version__ = "1.9.5"
__url__ = "https://maestral.app"
