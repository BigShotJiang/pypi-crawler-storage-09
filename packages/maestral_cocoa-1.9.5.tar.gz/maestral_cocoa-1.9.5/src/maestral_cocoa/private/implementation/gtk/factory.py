# -*- coding: utf-8 -*-

from toga_gtk.factory import *  # noqa: F401,F406
