[![PyPi Release](https://img.shields.io/pypi/v/maestral-qt.svg)](https://pypi.org/project/maestral-qt/)
[![Pyversions](https://img.shields.io/pypi/pyversions/maestral-qt.svg)](https://pypi.org/pypi/maestral-qt/)

# Maestral Qt <img src="https://raw.githubusercontent.com/SamSchott/maestral/master/src/maestral/resources/maestral.png" align="right" title="Maestral" width="110" height="110">

A Qt user interface for the [Maestral Daemon](https://www.github.com/samschott/maestral-dropbox).
