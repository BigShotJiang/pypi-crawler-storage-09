VERSION = "0.1.3"
__version__ = VERSION
APP_NAME = "Magentic-UI"
