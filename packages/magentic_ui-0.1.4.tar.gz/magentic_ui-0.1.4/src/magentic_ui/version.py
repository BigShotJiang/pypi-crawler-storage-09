VERSION = "0.1.4"
__version__ = VERSION
APP_NAME = "Magentic-UI"
