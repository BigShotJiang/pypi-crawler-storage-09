"""magic-class widgets using external packages."""
