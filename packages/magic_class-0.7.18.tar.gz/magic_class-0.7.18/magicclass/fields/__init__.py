from ._fields import (
    field,
    vfield,
    widget_property,
    MagicField,
    MagicValueField,
    method_as_getter,
)
from ._group import HasFields, FieldGroup, dataclass_gui
from ._property import magicproperty

__all__ = [
    "field",
    "vfield",
    "widget_property",
    "MagicField",
    "MagicValueField",
    "method_as_getter",
    "HasFields",
    "FieldGroup",
    "dataclass_gui",
    "magicproperty",
]
