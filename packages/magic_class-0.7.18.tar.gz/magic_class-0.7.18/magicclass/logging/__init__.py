from logging import *  # noqa
from .core import (
    getLogger,
    debug,
    info,
    warning,
    error,
    fatal,
    critical,
)
