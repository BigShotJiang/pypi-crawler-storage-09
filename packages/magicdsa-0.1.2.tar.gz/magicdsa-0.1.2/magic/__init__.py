# __init__.py

"""
AlgoScope 🧠
A complete algorithm explorer package.
"""

from .algorithms import show  # Import the main function
