"""collection class"""

# pylint: disable=too-many-lines
# pylint: disable=redefined-builtin
# pylint: disable=import-outside-toplevel
# pylint: disable=too-many-positional-arguments
# pylint: disable=arguments-differ

from collections import Counter

import numpy as np

from magpylib._src.defaults.defaults_utility import validate_style_keys
from magpylib._src.exceptions import MagpylibBadUserInput
from magpylib._src.fields.field_BH import _getBH_level2
from magpylib._src.input_checks import check_format_input_obj
from magpylib._src.obj_classes.class_BaseDisplayRepr import BaseDisplayRepr
from magpylib._src.obj_classes.class_BaseGeo import BaseGeo
from magpylib._src.obj_classes.class_BaseProperties import (
    BaseDipoleMoment,
    BaseVolume,
)
from magpylib._src.utility import format_obj_input, rec_obj_remover


def _repr_obj(obj, format="type+id+label"):
    """Return a string that describes the object depending on the chosen tag format."""
    # pylint: disable=protected-access
    show_type = "type" in format
    show_label = "label" in format
    show_id = "id" in format

    tag = ""
    if show_type:
        tag += f"{type(obj).__name__}"

    if show_label:
        if show_type:
            tag += " "
        label = getattr(getattr(obj, "style", None), "label", None)
        if label is None:
            label = "nolabel" if show_type else f"{type(obj).__name__}"
        tag += label

    if show_id:
        if show_type or show_label:
            tag += " "
        tag += f"(id={id(obj)})"
    return tag


def _collection_tree_generator(
    obj,
    format="type+id+label",
    max_elems=20,
    prefix="",
    space="    ",
    branch="│   ",
    tee="├── ",
    last="└── ",
):
    """Return generator that will yield a visual tree structure of
    a collection object and all its children.
    """
    # pylint: disable=protected-access

    # store children and properties of this branch
    contents = []

    children = getattr(obj, "children", [])
    if len(children) > max_elems:  # replace with counter if too many
        counts = Counter([type(c).__name__ for c in children])
        children = [f"{v}x {k}s" for k, v in counts.items()]

    props = []
    view_props = "properties" in format
    if view_props:
        desc = getattr(obj, "_get_description", False)
        if desc:
            desc_out = desc(
                exclude=(
                    "children",
                    "parent",
                    "style",
                    "field_func",
                    "sources",
                    "sensors",
                    "collections",
                    "children_all",
                    "sources_all",
                    "sensors_all",
                    "collections_all",
                )
            )
            props = [d.strip() for d in desc_out[1:]]

    contents.extend(props)
    contents.extend(children)

    # generate and store "pointer" structure for this branch
    pointers = [tee] * (len(contents) - 1) + [last]
    pointers[: len(props)] = [branch if children else space] * len(props)

    # create branch entries
    for pointer, child in zip(pointers, contents, strict=False):
        child_repr = child if isinstance(child, str) else _repr_obj(child, format)
        yield prefix + pointer + child_repr

        # recursion
        has_child = getattr(child, "children", False)
        if has_child or (view_props and desc):
            # space because last, └── , above so no more |
            extension = branch if pointer == tee else space

            yield from _collection_tree_generator(
                child,
                format=format,
                max_elems=max_elems,
                prefix=prefix + extension,
                space=space,
                branch=branch,
                tee=tee,
                last=last,
            )


class BaseCollection(BaseDisplayRepr):
    """Collection base class without BaseGeo properties"""

    get_trace = None

    def __init__(self, *children, override_parent=False):
        BaseDisplayRepr.__init__(self)

        self._children = []
        self._sources = []
        self._sensors = []
        self._collections = []
        self.add(*children, override_parent=override_parent)

    # Properties
    @property
    def children(self):
        """Ordered list of top level child objects."""
        return self._children

    @children.setter
    def children(self, children):
        """Set collection children.

        Parameters
        ----------
        children : list | Source | Sensor | Collection
            New top-level children. Existing top-level children are removed.
        """
        # pylint: disable=protected-access
        for child in self._children:
            child._parent = None
        self._children = []
        self.add(*children, override_parent=True)

    @property
    def children_all(self):
        """Ordered list of all child objects in the collection tree."""
        return check_format_input_obj(self, "collections+sensors+sources")

    @property
    def sources(self):
        """Ordered list of top level source objects."""
        return self._sources

    @sources.setter
    def sources(self, sources):
        """Set collection sources.

        Parameters
        ----------
        sources : list | Source
            New top-level sources. Existing top-level sources are removed.
        """
        # pylint: disable=protected-access
        new_children = []
        for child in self._children:
            if child in self._sources:
                child._parent = None
            else:
                new_children.append(child)
        self._children = new_children
        src_list = format_obj_input(sources, allow="sources")
        self.add(*src_list, override_parent=True)

    @property
    def sources_all(self):
        """Ordered list of all source objects in the collection tree."""
        return check_format_input_obj(self, "sources")

    @property
    def sensors(self):
        """Ordered list of top level sensor objects."""
        return self._sensors

    @sensors.setter
    def sensors(self, sensors):
        """Set collection sensors.

        Parameters
        ----------
        sensors : list | Sensor
            New top-level sensors. Existing top-level sensors are removed.
        """
        # pylint: disable=protected-access
        new_children = []
        for child in self._children:
            if child in self._sensors:
                child._parent = None
            else:
                new_children.append(child)
        self._children = new_children
        sens_list = format_obj_input(sensors, allow="sensors")
        self.add(*sens_list, override_parent=True)

    @property
    def sensors_all(self):
        """Ordered list of all sensor objects in the collection tree."""
        return check_format_input_obj(self, "sensors")

    @property
    def collections(self):
        """Ordered list of top level collection objects."""
        return self._collections

    @collections.setter
    def collections(self, collections):
        """Set collection child collections.

        Parameters
        ----------
        collections : list | Collection
            New top-level child collections. Existing top-level child collections are
            removed.
        """
        # pylint: disable=protected-access
        new_children = []
        for child in self._children:
            if child in self._collections:
                child._parent = None
            else:
                new_children.append(child)
        self._children = new_children
        coll_list = format_obj_input(collections, allow="collections")
        self.add(*coll_list, override_parent=True)

    @property
    def collections_all(self):
        """Ordered list of all collection objects in the collection tree."""
        return check_format_input_obj(self, "collections")

    # Dunders
    def __iter__(self):
        yield from self._children

    def __getitem__(self, i):
        return self._children[i]

    def __len__(self):
        return len(self._children)

    def _repr_html_(self):
        lines = []
        lines.append(_repr_obj(self))
        for line in _collection_tree_generator(
            self,
            format="type+label+id",
            max_elems=10,
        ):
            lines.append(line)
        return f"""<pre>{"<br>".join(lines)}</pre>"""

    def describe(self, format="type+label+id", max_elems=10, return_string=False):
        # pylint: disable=arguments-differ
        """Return or print a tree view of the collection.

        Parameters
        ----------
        format : str, default 'type+label+id'
            Object description in tree view. Can be any combination of ``'type'``, ``'label'``
            and ``'id'`` and ``'properties'``.
        max_elems : int, default 10
            If number of children at any level is higher than ``max_elems``, elements are
            replaced by counters.
        return_string : bool, default False
            If ``False`` print description with stdout, if ``True`` return as string.

        Returns
        -------
        str | None
            Tree view string if ``return_string=True``, else ``None``.
        """
        tree = _collection_tree_generator(
            self,
            format=format,
            max_elems=max_elems,
        )
        output = [_repr_obj(self, format)]
        for t in tree:
            output.append(t)
        output = "\n".join(output)

        if return_string:
            return output
        print(output)  # noqa: T201
        return None

    def add(self, *children, override_parent=False):
        """Add sources, sensors or collections to the collection.

        Parameters
        ----------
        *children : Source | Sensor | Collection
            Add arbitrary sources, sensors or other collections to this collection.
        override_parent : bool, default False
            If ``False``, do not accept objects as children that already have parents.
            If ``True`` automatically remove such objects from previous parent collection.

        Returns
        -------
        Self
            Self (allows chaining).

        Examples
        --------
        In this example we add a sensor object to a collection:

        >>> import magpylib as magpy
        >>> x1 = magpy.Sensor(style_label='x1')
        >>> coll = magpy.Collection(x1, style_label='coll')
        >>> coll.describe(format='label')
        coll
        └── x1

        >>> x2 = magpy.Sensor(style_label='x2')
        >>> coll.add(x2)
        Collection(id=...)
        >>> coll.describe(format='label')
        coll
        ├── x1
        └── x2
        """
        # pylint: disable=protected-access

        # allow flat lists as input
        if len(children) == 1 and isinstance(children[0], list | tuple):
            children = children[0]

        # check and format input
        obj_list = check_format_input_obj(
            children,
            allow="sensors+sources+collections",
            recursive=False,
            typechecks=True,
        )

        # assign parent
        for obj in obj_list:
            # no need to check recursively with `collections_all` if obj is already self
            if isinstance(obj, Collection) and (
                obj is self or self in obj.collections_all
            ):
                msg = f"Cannot add {obj!r} because a Collection must not reference itself."
                raise MagpylibBadUserInput(msg)
            if obj._parent is None:
                obj._parent = self
            elif override_parent:
                obj._parent.remove(obj)
                obj._parent = self
            else:
                msg = (
                    f"Cannot add {obj!r} to {self!r} because it already has a parent. "
                    "Consider using override_parent=True."
                )
                raise MagpylibBadUserInput(msg)

        # set attributes
        self._children += obj_list
        self._update_src_and_sens()

        return self

    def _update_src_and_sens(self):
        """updates sources, sensors and collections attributes from children"""
        # pylint: disable=protected-access
        from magpylib._src.obj_classes.class_BaseExcitations import BaseSource  # noqa: I001, PLC0415
        from magpylib._src.obj_classes.class_Sensor import Sensor  # noqa: PLC0415

        self._sources = [obj for obj in self._children if isinstance(obj, BaseSource)]
        self._sensors = [obj for obj in self._children if isinstance(obj, Sensor)]
        self._collections = [
            obj for obj in self._children if isinstance(obj, Collection)
        ]

    def remove(self, *children, recursive=True, errors="raise"):
        """Remove children from the collection tree.

        Parameters
        ----------
        *children : Source | Sensor | Collection
            Remove the given children from the collection.
        recursive : bool, default True
            Remove children also when they are in child collections.
        errors : {'raise', 'ignore'}, default 'raise'
            Toggle error output when child is
            not found for removal.

        Returns
        -------
        Self
            Self (allows chaining).

        Examples
        --------
        In this example we remove a child from a collection:

        >>> import magpylib as magpy
        >>> x1 = magpy.Sensor(style_label='x1')
        >>> x2 = magpy.Sensor(style_label='x2')
        >>> col = magpy.Collection(x1, x2, style_label='col')
        >>> col.describe(format='label')
        col
        ├── x1
        └── x2

        >>> col.remove(x1)
        Collection(id=...)
        >>> col.describe(format='label')
        col
        └── x2
        """
        # pylint: disable=protected-access

        # allow flat lists as input
        if len(children) == 1 and isinstance(children[0], list | tuple):
            children = children[0]

        # check and format input
        remove_objects = check_format_input_obj(
            children,
            allow="sensors+sources+collections",
            recursive=False,
            typechecks=True,
        )
        self_objects = check_format_input_obj(
            self,
            allow="sensors+sources+collections",
            recursive=recursive,
        )
        for child in remove_objects:
            if child in self_objects:
                rec_obj_remover(self, child)
                child._parent = None
            else:
                if errors == "raise":
                    msg = f"Cannot find and remove {child!r} from {self!r}."
                    raise MagpylibBadUserInput(msg)
                if errors != "ignore":
                    msg = (
                        "Input errors must be one of {'raise', 'ignore'}; "
                        f"instead received {errors!r}."
                    )
                    raise MagpylibBadUserInput(msg)
        return self

    def set_children_styles(self, arg=None, recursive=True, _validate=True, **kwargs):
        """Set display style of all children in the collection.

        Only matching properties will be applied.

        Parameters
        ----------
        arg : dict | str | None, default None
            Style arguments to be applied in the form of a style dictionary or style underscore
            magic input.
        recursive : bool, default True
            Apply styles also to children of child collections.

        Returns
        -------
        Self
            Self (allows chaining).

        Examples
        --------
        In this example we start by creating a collection from three sphere magnets:

        >>> import magpylib as magpy
        >>>
        >>> col = magpy.Collection(
        ...     [
        ...         magpy.magnet.Sphere(position=(i, 0, 0), diameter=1, polarization=(0, 0, 0.1))
        ...         for i in range(3)
        ...     ]
        ... )
        >>> # We apply styles using underscore magic for magnetization vector size and a style
        >>> # dictionary for the color.
        >>>
        >>> col.set_children_styles(magnetization_size=0.5)
        Collection(id=...)
        >>> col.set_children_styles({'color': 'g'})
        Collection(id=...)
        >>>
        >>> # Finally we create a separate sphere magnet and show both the collection
        >>> # and the separate magnet with Matplotlib:
        >>>
        >>> src = magpy.magnet.Sphere(position=(3, 0, 0), diameter=1, polarization=(0, 0, 0.1))
        >>> magpy.show(col, src) # doctest: +SKIP
        >>> # graphic output
        """
        # pylint: disable=protected-access

        if arg is None:
            arg = {}
        if kwargs:
            arg.update(kwargs)
        style_kwargs = arg
        if _validate:
            style_kwargs = validate_style_keys(arg)

        for child in self._children:
            # match properties false will try to apply properties from kwargs only if it finds it
            # without throwing an error
            if isinstance(child, Collection) and recursive:
                self.__class__.set_children_styles(child, style_kwargs, _validate=False)
            style_kwargs_specific = {
                k: v
                for k, v in style_kwargs.items()
                if k.split("_")[0] in child.style.as_dict()
            }
            child.style.update(**style_kwargs_specific, _match_properties=True)
        return self

    def _validate_getBH_inputs(self, *inputs):
        """Select correct sources and observers for getBHJM_level2"""
        # pylint: disable=protected-access
        # pylint: disable=too-many-branches
        # pylint: disable=possibly-used-before-assignment
        current_sources = format_obj_input(self, allow="sources")
        current_sensors = format_obj_input(self, allow="sensors")

        # if collection includes source and observer objects, select itself as
        #   source and observer in gethBH
        if current_sensors and current_sources:
            sources, sensors = self, self
            if inputs:
                msg = (
                    "Collections with sensors and sources do not allow collection.getB() inputs."
                    "Consider using magpy.getB() instead."
                )
                raise MagpylibBadUserInput(msg)
        # if collection has no sources, *inputs must be the sources
        elif not current_sources:
            sources, sensors = inputs, self

        # if collection has no sensors, *inputs must be the observers
        elif not current_sensors:
            if len(inputs) == 1:
                sources, sensors = self, inputs[0]
            else:
                sources, sensors = self, inputs

        return sources, sensors

    def getB(
        self,
        *inputs,
        sumup=False,
        squeeze=True,
        pixel_agg=None,
        output="ndarray",
        in_out="auto",
    ):
        """Return B-field (T) at o observers generated by s sources.

        SI units are used for all inputs and outputs.

        Parameters
        ----------
        *inputs : Source | Sensor | array-like, shape (o1, o2, ..., 3)
            Can be observers if the collection contains sources. In this case the
            collection behaves like a single source.
            Can be sources if the collection contains sensors. In this case the
            collection behaves like a list of all its sensors.
        sumup : bool, default False
            If ``True``, sum the fields from all sources when the collection is used as
            ``observer`` input. If ``False``, keep the source axis.
        squeeze : bool, default True
            If ``True`` squeeze singleton axes (e.g. a single source or a single sensor).
        pixel_agg : str | None, default None
            Name of a NumPy aggregation function (e.g. ``'mean'``, ``'min'``) applied over the
            pixel axis of each sensor. Allows mixing sensors with different pixel shapes.
        output : {'ndarray', 'dataframe'}, default 'ndarray'
            Output container type. 'dataframe' returns a pandas DataFrame.
        in_out : {'auto', 'inside', 'outside'}, default 'auto'
            Assumption about observer locations relative to magnet bodies. ``'auto'`` detects per
            observer (safest, slower). ``'inside'`` treats all inside (faster). ``'outside'`` treats
            all outside (faster).

        Returns
        -------
        ndarray | DataFrame
            B-field (T) with squeezed shape (s, p, o, o1, o2, ..., 3) where s is the number of
            sources when the collection functions as observer, p is the path length, and
            o is the number of observers with pixel shape (o1, o2, ...) when the collection
            functions as source.

        Examples
        --------
        In this example we create a collection from two sources and two sensors:

        >>> import numpy as np
        >>> import magpylib as magpy
        >>> # Create Collection with two sensors and two magnets
        >>> src1 = magpy.magnet.Sphere(polarization=(0, 0, 1), diameter=1)
        >>> src2 = src1.copy()
        >>> sens1 = magpy.Sensor(position=(0, 0, 0.6))
        >>> sens2 = sens1.copy()
        >>> col = src1 + src2 + sens1 + sens2
        >>> # The following computations all give the same result
        >>> B = col.getB()
        >>> B = magpy.getB(col, col)
        >>> B = magpy.getB(col, [sens1, sens2])
        >>> B = magpy.getB([src1, src2], col)
        >>> B = magpy.getB([src1, src2], [sens1, sens2])
        >>> with np.printoptions(precision=3):
        ...     print(B)
        [[[0.    0.    0.386]
          [0.    0.    0.386]]
        <BLANKLINE>
         [[0.    0.    0.386]
          [0.    0.    0.386]]]
        """

        sources, sensors = self._validate_getBH_inputs(*inputs)
        return _getBH_level2(
            sources,
            sensors,
            field="B",
            sumup=sumup,
            squeeze=squeeze,
            pixel_agg=pixel_agg,
            output=output,
            in_out=in_out,
        )

    def getH(
        self,
        *inputs,
        sumup=False,
        squeeze=True,
        pixel_agg=None,
        output="ndarray",
        in_out="auto",
    ):
        """Return H-field (A/m) at o observers generated by s sources.

        SI units are used for all inputs and outputs.

        Parameters
        ----------
        *inputs : Source | Sensor | array-like, shape (o1, o2, ..., 3)
            Can be observers if the collection contains sources. In this case the
            collection behaves like a single source.
            Can be sources if the collection contains sensors. In this case the
            collection behaves like a list of all its sensors.
        sumup : bool, default False
            If ``True``, sum the fields from all sources when the collection is used as
            ``observer`` input. If ``False``, keep the source axis.
        squeeze : bool, default True
            If ``True`` squeeze singleton axes (e.g. a single source or a single sensor).
        pixel_agg : str | None, default None
            Name of a NumPy aggregation function (e.g. ``'mean'``, ``'min'``) applied over the
            pixel axis of each sensor. Allows mixing sensors with different pixel shapes.
        output : {'ndarray', 'dataframe'}, default 'ndarray'
            Output container type. 'dataframe' returns a pandas DataFrame.
        in_out : {'auto', 'inside', 'outside'}, default 'auto'
            Assumption about observer locations relative to magnet bodies. ``'auto'`` detects per
            observer (safest, slower). ``'inside'`` treats all inside (faster). ``'outside'`` treats
            all outside (faster).

        Returns
        -------
        ndarray | DataFrame
            H-field (A/m) with squeezed shape (s, p, o, o1, o2, ..., 3) where s is the number of
            sources when the collection functions as observer, p is the path length, and
            o is the number of observers with pixel shape (o1, o2, ...) when the collection
            functions as source.

        Examples
        --------
        In this example we create a collection from two sources and two sensors:

        >>> import numpy as np
        >>> import magpylib as magpy
        >>> # Create Collection with two sensors and two magnets
        >>> src1 = magpy.magnet.Sphere(polarization=(0, 0, 1.0), diameter=1)
        >>> src2 = src1.copy()
        >>> sens1 = magpy.Sensor(position=(0, 0, 1))
        >>> sens2 = sens1.copy()
        >>> col = src1 + src2 + sens1 + sens2
        >>> # The following computations all give the same result
        >>> H = col.getH()
        >>> H = magpy.getH(col, col)
        >>> H = magpy.getH(col, [sens1, sens2])
        >>> H = magpy.getH([src1, src2], col)
        >>> H = magpy.getH([src1, src2], [sens1, sens2])
        >>> with np.printoptions(precision=3):
        ...    print(H)
        [[[    0.       0.   66314.56]
          [    0.       0.   66314.56]]
        <BLANKLINE>
         [[    0.       0.   66314.56]
          [    0.       0.   66314.56]]]
        """

        sources, sensors = self._validate_getBH_inputs(*inputs)

        return _getBH_level2(
            sources,
            sensors,
            field="H",
            sumup=sumup,
            squeeze=squeeze,
            pixel_agg=pixel_agg,
            output=output,
            in_out=in_out,
        )

    def getM(
        self,
        *inputs,
        sumup=False,
        squeeze=True,
        pixel_agg=None,
        output="ndarray",
        in_out="auto",
    ):
        """Return magnetization (A/m) at o observers generated by s sources.

        SI units are used for all inputs and outputs.

        Parameters
        ----------
        *inputs : Source | Sensor | array-like, shape (o1, o2, ..., 3)
            Can be observers if the collection contains sources. In this case the
            collection behaves like a single source.
            Can be sources if the collection contains sensors. In this case the
            collection behaves like a list of all its sensors.
        sumup : bool, default False
            If ``True``, sum the fields from all sources when the collection is used as
            ``observer`` input. If ``False``, keep the source axis.
        squeeze : bool, default True
            If ``True`` squeeze singleton axes (e.g. a single source or a single sensor).
        pixel_agg : str | None, default None
            Name of a NumPy aggregation function (e.g. ``'mean'``, ``'min'``) applied over the
            pixel axis of each sensor. Allows mixing sensors with different pixel shapes.
        output : {'ndarray', 'dataframe'}, default 'ndarray'
            Output container type. 'dataframe' returns a pandas DataFrame.
        in_out : {'auto', 'inside', 'outside'}, default 'auto'
            Assumption about observer locations relative to magnet bodies. ``'auto'`` detects per
            observer (safest, slower). ``'inside'`` treats all inside (faster). ``'outside'`` treats
            all outside (faster).

        Returns
        -------
        ndarray | DataFrame
            Magnetization (A/m) with squeezed shape (s, p, o, o1, o2, ..., 3) where s is the number of
            sources when the collection functions as observer, p is the path length, and
            o is the number of observers with pixel shape (o1, o2, ...) when the collection
            functions as source.

        Examples
        --------
        >>> import numpy as np
        >>> import magpylib as magpy
        >>> cube = magpy.magnet.Cuboid(
        ...     dimension=(10, 1, 1),
        ...     polarization=(1, 0, 0)
        ... ).rotate_from_angax(45, 'z')
        >>> coll = magpy.Collection(cube)
        >>> M = coll.getM((3, 3, 0))
        >>> with np.printoptions(precision=0):
        ...    print(M)
        [562698. 562698.      0.]
        """

        sources, sensors = self._validate_getBH_inputs(*inputs)

        return _getBH_level2(
            sources,
            sensors,
            field="M",
            sumup=sumup,
            squeeze=squeeze,
            pixel_agg=pixel_agg,
            output=output,
            in_out=in_out,
        )

    def getJ(
        self,
        *inputs,
        sumup=False,
        squeeze=True,
        pixel_agg=None,
        output="ndarray",
        in_out="auto",
    ):
        """Return magnetic polarization (T) at o observers generated by s sources.

        Parameters
        ----------
        *inputs : Source | Sensor | array-like, shape (o1, o2, ..., 3)
            Can be observers if the collection contains sources. In this case the
            collection behaves like a single source.
            Can be sources if the collection contains sensors. In this case the
            collection behaves like a list of all its sensors.
        sumup : bool, default False
            If ``True``, sum the fields from all sources when the collection is used as
            ``observer`` input. If ``False``, keep the source axis.
        squeeze : bool, default True
            If ``True`` squeeze singleton axes (e.g. a single source or a single sensor).
        pixel_agg : str | None, default None
            Name of a NumPy aggregation function (e.g. ``'mean'``, ``'min'``) applied over the
            pixel axis of each sensor. Allows mixing sensors with different pixel shapes.
        output : {'ndarray', 'dataframe'}, default 'ndarray'
            Output container type. 'dataframe' returns a pandas DataFrame.
        in_out : {'auto', 'inside', 'outside'}, default 'auto'
            Assumption about observer locations relative to magnet bodies. ``'auto'`` detects per
            observer (safest, slower). ``'inside'`` treats all inside (faster). ``'outside'`` treats
            all outside (faster).

        Returns
        -------
        ndarray | DataFrame
            Polarization (T) with squeezed shape (s, p, o, o1, o2, ..., 3) where s is the number of
            sources when the collection functions as observer, p is the path length, and
            o is the number of observers with pixel shape (o1, o2, ...) when the collection
            functions as source.

        Examples
        --------
        >>> import numpy as np
        >>> import magpylib as magpy
        >>> cube = magpy.magnet.Cuboid(
        ...     dimension=(10, 1, 1),
        ...     polarization=(1, 0, 0)
        ... ).rotate_from_angax(45, 'z')
        >>> coll = magpy.Collection(cube)
        >>> J = coll.getJ((3, 3, 0))
        >>> with np.printoptions(precision=3):
        ...    print(J)
        [0.707 0.707 0.   ]
        """

        sources, sensors = self._validate_getBH_inputs(*inputs)

        return _getBH_level2(
            sources,
            sensors,
            field="J",
            sumup=sumup,
            squeeze=squeeze,
            pixel_agg=pixel_agg,
            output=output,
            in_out=in_out,
        )

    @property
    def _default_style_description(self):
        """Default style description text"""
        items = []
        if self.children_all:
            nums = {
                "sensor": len(self.sensors_all),
                "source": len(self.sources_all),
            }
            for name, num in nums.items():
                if num > 0:
                    items.append(f"{num} {name}{'s'[: num ^ 1]}")
        else:
            items.append("no children")
        return ", ".join(items)


class Collection(BaseGeo, BaseCollection, BaseVolume, BaseDipoleMoment):
    """Group multiple children in a collection for common manipulation.

    Children can be sources (magnets, currents, misc), sensors, and other
    collections.

    Collections span a local reference frame. All children are moved with
    that reference frame when an operation (e.g. move, rotate, setter, ...) is applied
    to the collection.

    Collections can be used as source, observer, and target input for magnetic
    field and force computation. For the computation, a collection that
    contains sources/targets functions like a single source/target. When the collection
    contains sensors it functions like a list of all its sensors.

    Parameters
    ----------
    *children : Source | Sensor | Collection
        Sources, sensors, or collections that should be added to this collection.
    position : array-like, shape (3,) or (p, 3), default (0, 0, 0)
        Object position(s) in global coordinates in units (m). ``position`` and
        ``orientation`` attributes define the object path.
    orientation : Rotation | None, default None
        Object orientation(s) in global coordinates as a scipy Rotation. Rotation can
        have length 1 or p. ``None`` generates a unit-rotation.
    override_parent : bool, default False
        If ``False`` thrown an error when an attempt is made to add an object that has
        already a parent to a Collection. If ``True``, allow adding the object and
        override the objects parent attribute thus removing it from its previous
        collection.
    style : dict | None, default None
        Object style inputs must be in dictionary form, e.g. ``{'color': 'red'}`` or using
        style underscore magic, e.g. ``style_color='red'``.

    Attributes
    ----------
    position : ndarray, shape (3,) or (p, 3)
        Same as constructor parameter ``position``.
    orientation : Rotation
        Same as constructor parameter ``orientation``.
    children : list
        Ordered list of children in the collection top level.
    children_all : list
        Read-only. Ordered list of children in the collection including nested collections.
    parent : Collection | None
        Parent collection of the object.
    sensors : list
        Ordered list of sensor objects in the collection top level.
    sensors_all : list
        Read-only. Ordered list of sensor objects in the collection including nested collections.
    sources : list
        Ordered list of source objects in the collection top level.
    sources_all : list
        Read-only. Ordered list of source objects in the collection including nested collections.
    collections : list
        Ordered list of collection objects in the collection top level.
    collections_all : list
        Read-only. Ordered list of collection objects in the collection including nested collections.
    centroid : ndarray, shape (3,) or (p, 3)
        Read-only. Collection centroid in units (m) computed as the volume-weighted average of all
        child centroids. Can be a path.
    volume : float
        Read-only. Total Collection volume (m³) of all magnets. Overlapping objects may lead
        to double counting.
    dipole_moment : ndarray, shape (3,)
        Read-only. Total Collection dipole moment (A·m²) computed from the sum of all child
        dipole moments.
    style : dict
        Style dictionary defining the visual properties of the collection objects.

    Examples
    --------
    Collections function as groups of multiple Magpylib objects. In this example
    we create a collection with two sources and move the whole collection:

    >>> import numpy as np
    >>> import magpylib as magpy
    >>> src1 = magpy.magnet.Sphere(position=(2, 0, 0), diameter=1, polarization=(0.1, 0.2, 0.3))
    >>> src2 = magpy.current.Circle(position=(-2, 0, 0), diameter=1, current=1)
    >>> col = magpy.Collection(src1, src2)
    >>> col.move((0, 0, 2))
    Collection(id=...)
    >>> print(src1.position)
    [2. 0. 2.]
    >>> print(src2.position)
    [-2.  0.  2.]
    >>> print(col.position)
    [0. 0. 2.]

    We can still directly access individual objects by name and by index:

    >>> src1.move((2, 0, 0))
    Sphere(id=...)
    >>> col[1].move((-2, 0, 0))
    Circle(id=...)
    >>> print(src1.position)
    [4. 0. 2.]
    >>> print(src2.position)
    [-4.  0.  2.]
    >>> print(col.position)
    [0. 0. 2.]

    The field can be computed at position (0, 0, 0) as if the collection was a single source:

    >>> B = col.getB((0, 0, 0))
    >>> print(B)
    [ 2.32922681e-04 -9.31694991e-05 -3.44484717e-10]

    We add a sensor at position (0, 0, 0) to the collection:

    >>> sens = magpy.Sensor()
    >>> col.add(sens)
    Collection(id=...)
    >>> print(col.children)
    [Sphere(id=...), Circle(id=...), Sensor(id=...)]

    and can compute the field of the sources in the collection seen by the sensor with
    a single command:

    >>> B = col.getB()
    >>> with np.printoptions(precision=3):
    ...    print(B)
    [ 2.329e-04 -9.317e-05 -3.445e-10]
    """

    def __init__(
        self,
        *children,
        position=(0, 0, 0),
        orientation=None,
        override_parent=False,
        style=None,
        **kwargs,
    ):
        BaseGeo.__init__(
            self,
            position=position,
            orientation=orientation,
            style=style,
            **kwargs,
        )
        BaseCollection.__init__(self, *children, override_parent=override_parent)

    # Abstract methods implementation
    def _get_volume(self):
        """Return volume of all objects (m³)."""
        return sum(getattr(child, "volume", 0.0) for child in self.children_all)

    def _get_centroid(self):
        """Return centroid of collection weighted by children volumes (m)."""
        total_volume = 0.0
        weighted_centroid = np.array([0.0, 0.0, 0.0])

        for child in self.children_all:
            child_volume = getattr(child, "volume", 0.0)
            if child_volume > 0:
                child_centroid = child.centroid
                weighted_centroid += child_centroid * child_volume
                total_volume += child_volume

        if total_volume > 0:
            return weighted_centroid / total_volume
        return self.position

    def _get_dipole_moment(self):
        """Return magnetic dipole moment of object (A·m²)."""
        return np.sum(
            [
                getattr(child, "dipole_moment", np.zeros(3))
                for child in self.children_all
            ],
            axis=0,
        )
