class Model:
    integration = "dsl.Model"
