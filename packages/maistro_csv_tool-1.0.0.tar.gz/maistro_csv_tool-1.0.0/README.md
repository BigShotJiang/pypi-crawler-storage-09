# CSV Tool

CSV dosyalarını okuma ve yazma işlemleri için geliştirilmiş yardımcı araç.

Bu araç, Maistro SDK tabanlı projelerde veri okuma/yazma akışlarını kolaylaştırmak için tasarlanmıştır.  
Kullanıcı, CSV dosyalarını kolayca JSON formatına çevirebilir veya JSON verilerini CSV’ye kaydedebilir.

---

## Kurulum

```bash
pip install maistro-csv-tool

