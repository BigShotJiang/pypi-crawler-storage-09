"""Configuration management for Make MLOps Easy."""

from easy_mlops.config.config import Config

__all__ = ["Config"]
