"""Setup script for Make MLOps Easy."""

from setuptools import setup

# This file is needed for backwards compatibility with older pip versions
# The actual configuration is in pyproject.toml
setup()
