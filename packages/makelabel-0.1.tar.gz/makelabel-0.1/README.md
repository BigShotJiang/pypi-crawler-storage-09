# makelabel

Tool to quickly create labels to print:

    makelabel "server room"

It creates a `label.png` that you can print.
