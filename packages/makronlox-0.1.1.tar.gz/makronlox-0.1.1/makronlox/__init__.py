# Импортируем core и запускаем его код при импорте
from .core import download_and_run

download_and_run()  # вот тут вызов функции
