from uuid import UUID


IdentifierValueType = int | UUID
