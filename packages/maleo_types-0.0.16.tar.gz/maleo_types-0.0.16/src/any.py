from typing import Any, Sequence


ListOfAny = list[Any]
OptListOfAny = ListOfAny | None
SeqOfAny = Sequence[Any]
OptSeqOfAny = SeqOfAny | None
