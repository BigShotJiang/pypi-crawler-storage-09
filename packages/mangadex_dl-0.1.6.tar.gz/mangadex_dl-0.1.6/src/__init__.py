"""
A sleek CLI tool to download single or multiple manga chapters from MangaDex with ease.
"""

__version__ = "0.1.6"
__description__ = "A sleek CLI tool to download single or multiple manga chapters from MangaDex with ease."
__author__ = "syvixor"
__author_email__ = "syvixor@proton.me"
__license__ = "MIT"