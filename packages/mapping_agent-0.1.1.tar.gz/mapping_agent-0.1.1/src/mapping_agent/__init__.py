"""
Mapping Agent package initialization.
"""
