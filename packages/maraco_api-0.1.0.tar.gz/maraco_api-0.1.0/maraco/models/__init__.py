"""
Model storage module for MarACO API
"""
