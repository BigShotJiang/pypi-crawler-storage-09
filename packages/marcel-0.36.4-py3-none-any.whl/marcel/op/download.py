# This file is part of Marcel.
# 
# Marcel is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation, either version 3 of the License, (or at your
# option) any later version.
# 
# Marcel is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
# FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
# for more details.
# 
# You should have received a copy of the GNU General Public License
# along with Marcel.  If not, see <https://www.gnu.org/licenses/>.

import pathlib

import marcel.argsparser
import marcel.core
import marcel.exception
import marcel.main
import marcel.object.file
import marcel.opmodule
import marcel.op.bash
import marcel.op.filenames
import marcel.op.forkmanager
import marcel.pipeline
import marcel.util

File = marcel.object.file.File

HELP = '''
{L,wrap=F}download DIR CLUSTER FILENAME ...

{L,indent=4:28}{r:DIR}                     The local directory to which files will be downloaded.

{L,indent=4:28}{r:CLUSTER}                 The cluster from which files will be downloaded.

{L,indent=4:28}{r:FILENAME}                A remote filename or glob pattern.

Copies remote files from each node of a cluster, to a local directory. The output stream is empty.

{r:DIR} must be a pre-exising directory.

{r:CLUSTER} must be configured for marcel, (run {n:help cluster} for
information on configuring clusters).

The files to be copied are specified by one or more {r:FILENAME}s. Each
{r:FILENAME} is a file name or a glob pattern, and must be an absolute path, (i.e., it must start with /).
Files from host {n:H} will be downloaded to the directory {n:DIR/H}. 
'''


def download(dir, cluster, *paths):
    return Download(), [dir, cluster] + list(paths)


class DownloadArgsParser(marcel.argsparser.ArgsParser):

    def __init__(self, env):
        super().__init__('download', env)
        self.add_anon('dir', convert=self.check_str_or_file, target='dir_arg')
        self.add_anon('cluster', convert=self.cluster)
        self.add_anon_list('filenames', convert=self.check_str_or_file, target='filenames_arg')
        self.validate()


class Download(marcel.core.Op):

    def __init__(self):
        super().__init__()
        self.dir_arg = None
        self.dir = None
        self.cluster = None
        self.filenames_arg = None
        self.filenames = None
        self.fork_manager = None
        self.pipeline = None

    def __repr__(self):
        return f'download({self.dir_arg} <- {self.cluster} {self.filenames_arg})'

    def setup(self, env):
        self.dir = self.eval_function(env,
                                      'dir_arg',
                                      str, pathlib.Path, pathlib.PosixPath, File)
        self.dir = pathlib.Path(self.dir)
        self.dir = marcel.op.filenames.Filenames(env, [self.dir]).normalize()
        if len(self.dir) == 0:
            raise marcel.exception.KillCommandException(f'Target directory does not exist: {self.dir_arg}')
        else:
            self.dir = self.dir[0]
        self.filenames = self.eval_function(env,
                                            'filenames_arg',
                                            str, pathlib.Path, pathlib.PosixPath, File)
        if len(self.filenames) == 0:
            raise marcel.exception.KillCommandException('No remote files specified')
        for filename in self.filenames:
            if not filename.startswith('/'):
                raise marcel.exception.KillCommandException(f'Remote filenames must be absolute: {filename}')
        # Empty pipelines will be filled in by fork customizer
        self.pipeline = marcel.pipeline.Pipeline.create_empty_pipeline(env)
        self.fork_manager = marcel.op.forkmanager.ForkManager(op=self,
                                                              thread_ids=self.cluster.hosts,
                                                              pipeline=self.pipeline,
                                                              max_pipeline_args=0)
        self.fork_manager.setup(env, fork_customizer=self.fork_customizer)
        self.ensure_node_directories_exist()

    def run(self, env):
        self.fork_manager.run(env)

    @staticmethod
    def scp_command(sources, host, dest):
        cluster = host.cluster
        buffer = []
        if cluster.password:
            buffer.append(f'sshpass -p "{cluster.password}"')
        buffer.append('scp -Cpqr')
        if cluster.identity:
            buffer.extend(['-i', cluster.identity])
        if cluster.password:
            buffer.append(f'-P {cluster.password}')
        for source in sources:
            buffer.append(f'{cluster.user}@{host.addr}:{marcel.util.quote_files(source)}')
        node_dir = dest / host.name
        buffer.append(node_dir.as_posix())
        scp_command = ' '.join(buffer)
        return scp_command

    def fork_customizer(self, env, pipeline, host):
        return pipeline.append_immutable(
            marcel.opmodule.create_op(env,
                                      'bash',
                                      Download.scp_command(self.filenames, host, self.dir)))

    def ensure_node_directories_exist(self):
        for host in self.cluster:
            host_dir = self.dir / host.name
            host_dir.mkdir(exist_ok=True)
