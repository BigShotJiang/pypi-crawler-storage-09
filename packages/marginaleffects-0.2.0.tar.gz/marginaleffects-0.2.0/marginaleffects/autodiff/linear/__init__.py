# Linear model implementations

from . import predictions as predictions
from . import comparisons as comparisons
