"""
Title           : Mars24 Sunclock Algorithm Functions
Description     : Functions inspired by the Mars24 Sunclock algorithm (see references below)
Author          : Victorien Guyon (victorien.guyon@protonmail.com)
Date            : May 2024

Company         : Paneureka
Address          : 17 rue du lac Saint-André 73370 Le Bourget-du-lac, France


Copyright       : (c) 2024 Victorien Guyon. All rights reserved.
License         : This work is licensed under CC BY-NC-SA 4.0

Reference       :
1. Allison, M. Accurate analytic representations of solar time and seasons on Mars with applications to
the Pathfinder/Surveyor missions Geophys. Res. Lett., 24, 1967-1970 1997
2. Allison, M., and M. McEwen A post-Pathfinder evaluation of aerocentric solar coordinates with
improved timing recipes for Mars seasonal/diurnal climate studies Planet. Space Sci., 48, 215-235
2000
3. NASA Goddard Institute for Space Studies Mars24 Sunclock — Time on Mars, Algorithm and
Worked Examples https://www.giss.nasa.gov/tools/mars24/help/algorithm.html 2023
4. Michael Allison, Robert Schmunk Technical Notes on Mars Solar Time as Adopted by the Mars24
Sunclock https://www.giss.nasa.gov/tools/mars24/help/notes.html 2023

Remarks         : This script is intended for academic research purposes and as been created in the context of an
internship at Paneureka under the supervision of Dr. Luca Montabone, PhD (lmontabone@paneureka.org).
"""

import numpy as np


# SELECTED FUNCTIONS FROM THE MARS24 SUNCLOCK ALGORITHM #
# https://www.giss.nasa.gov/tools/mars24/help/algorithm.html

def get_mars_mean_anomaly(t_offset_J2000: float) -> float:
    """
    Calculate the mean anomaly of Mars.
    :param t_offset_J2000: Days Since J2000 Epoch (TT).
    :return: Mean anomaly of Mars in degrees.
    """
    return 19.3871 + 0.52402073 * t_offset_J2000


def get_angle_FMS(t_offset_J2000: float) -> float:
    """
    Calculate the angle of the ficticious mean Sun in the context of Mars's planetocentric solar coordinates.
    :param t_offset_J2000: Days Since J2000 Epoch (TT).
    :return: Angle of the ficticious mean Sun.
    """
    return 270.3871 + 0.524038496 * t_offset_J2000


def get_PBS(t_offset_J2000: float) -> float:
    """
    Calculate the sum of the angular perturbations in longitude.
    A contains the amplitudes, tau the periods and phi the phases of the planetary perturbations.
    :param t_offset_J2000: Days Since J2000 Epoch (TT).
    :return: Sum of the angular perturbations in longitude.
    """
    A = np.array([0.0071, 0.0057, 0.0039, 0.0037, 0.0021, 0.0020, 0.0018])

    tau = np.array([2.2353, 2.7543, 1.1177, 15.7866, 2.1354, 2.4694, 32.8493])

    phi = np.array([49.409, 168.173, 191.837, 21.736, 15.704, 95.528, 49.095])

    return np.sum(A * np.cos(np.deg2rad((360 / 365.25) * t_offset_J2000 / tau + phi)))


def get_EoC(t_offset_J2000: float, mars_mean_anomaly: float, PBS: float) -> float:
    """
    Calculate the Equation of Time.
    :param t_offset_J2000: Days Since J2000 Epoch (TT).
    :param mars_mean_anomaly: Mean anomaly of Mars in degrees.
    :param PBS: Sum of the angular perturbations in longitude.
    :return: The true anomaly minus the mean anomaly of Mars.
    """
    mars_mean_anomaly_rad = np.deg2rad(mars_mean_anomaly)
    return (10.691 + 3e-7 * t_offset_J2000) * np.sin(mars_mean_anomaly_rad) + 0.623 * np.sin(
        2 * mars_mean_anomaly_rad) + 0.050 * np.sin(3 * mars_mean_anomaly_rad) + 0.005 * np.sin(
        4 * mars_mean_anomaly_rad) + 0.0005 * np.sin(5 * mars_mean_anomaly_rad) + PBS


def get_EoT(areocentric_Ls: float, EoC: float) -> float:
    """
    Calculate the Equation of Time.
    :param areocentric_Ls: Areocentric solar longitude, in degrees.
    :param EoC: Equation of center.
    :return: Equation of time, in degrees.
    """
    Ls_rad = np.deg2rad(areocentric_Ls)
    return 2.861 * np.sin(2 * Ls_rad) - 0.071 * np.sin(4 * Ls_rad) + 0.002 * np.sin(6 * Ls_rad) - EoC


def get_MST(jd_tt: float) -> float:
    """
    Calculate the martian mean solar time.
    :param jd_tt: Julian Date (TT)
    :return: Number of hour in mean solar time.
    """
    return (24 * ((jd_tt - 2451549.5) / 1.0274912517 + 44796.0 - 0.0009626)) % 24


def get_LMST(MST: float, longitude: float) -> float:
    """
    Calculate the martian local mean solar time.
    :param MST: Mean solar time, in number of hours.
    :param longitude: Planetographic longitude, in degrees west.
    :return: Local mean solar time, in number of hours.
    """
    return (MST - longitude * (1 / 15)) % 24


def get_LTST(LMST: float, EoT: float) -> float:
    """
    Calculate the martian local true solar time.
    :param LMST: Number of hour in mean local solar time.
    :param EoT: Equation of time.
    :return: Local true solar time, in number of hours.
    """
    return LMST + EoT * (1 / 15)
