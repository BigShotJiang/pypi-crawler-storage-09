"""
Title : Martian Time Conversion Algorithm Functions (Beta Version)
Description : Functions for the time conversion algorithm linked to the sol based calendar (Beta Version)
Author : Victorien Guyon (victorien.guyon@protonmail.com)
Date : May 2024

Company : PANEUREKA
Address : 17 rue du lac Saint-Andre, 73370, Le Bourget-du-lac, France
Reference point : Luca Montabone (lmontabone@paneureka.org)


This license governs the use of the beta version of the "Martian Time Conversion Algorithm Functions" (the "Software")
provided to CNES and LMD by PANEUREKA/Victorien Guyon.

1. Copyright Ownership
PANEUREKA retains all rights, title, and interest in and to the Software, including all intellectual property rights. Authorship credit is attributed to Victorien Guyon, who developed the Software in the context of an internship and subsequent apprenticeship at PANEUREKA under the supervision of Dr. Luca Montabone.

2. Permitted Use
a. CNES and LMD are granted a non-exclusive, non-transferable, royalty-free license to use, modify, and evaluate the Software internally for research,
testing, and operational purposes only.
b. Redistribution, sublicensing, or commercial deployment of the Software is prohibited without prior written consent from PANEUREKA.

3. Restrictions
a. The Software may not be distributed, sublicensed, or otherwise made available to third parties in any form.
b. Any modifications to the Software must retain authorship attribution to Victorien Guyon and a copyright notice for PANEUREKA.
b. The Software may not be used in production environments or for commercial purposes.

4. Liability Limitation
a. The Software is provided "as is" without warranty of any kind, express or implied, including but not limited to the warranties of merchantability,
fitness for a particular purpose, or non-infringement.
b. PANEUREKA and Victorien Guyon shall not be held liable for any damages, losses, or issues arising from the use or misuse of the Software,
including, but not limited to, direct, indirect, incidental, consequential, or special damages, whether in contract, tort, or otherwise.
c. The users of the Software (including CNES and LMD) are solely responsible for ensuring that the Software is used in compliance
with all applicable laws, regulations, and ethical standards.

5. Future Licensing
A finalized version of the Software will be released under a separate license that may allow for broader distribution and use.
This beta license shall remain in effect until superseded by the finalized version.

6. Governing Law
This license shall be governed by the laws of France.

By using this Software, CNES and LMD agree to abide by the terms of this license.
"""

# Packages #############################################################################################################

import datetime
from . import Mars24
import scipy
from . import piqueux
import numpy as np

from astropy.time import Time
from astropy.time import TimeDelta
from typing import *

# Removing the ERFA warnings ###########################################################################################

import warnings

warnings.filterwarnings('ignore', category=UserWarning, module='erfa')


# Correction functions (SolCal to Corrected SolCal) ####################################################################

def id(MY_SC: int) -> int: # todo : Put in a better place + use it in the functions conversions
    """
    Return the SolCal MY index in his cycle, from the end of the cycle if the MY is negative, from the beginning of the
    cycle if the MY is positive.
    :param MY_SC: Solcal MY, non-zero integer.
    :return: The index of MY_SC in its cycle, integer from 1 to 5.
    """
    MY_SC = int(MY_SC)
    if MY_SC > 0:
        return ((MY_SC - 1) % 5) + 1
    else:
        return 5 - ((abs(MY_SC) - 1) % 5)


def delta_plus(MY_SC: int, DP: int) -> int:
    """
    Returns the number of MY between the beginning of the Solcal MY DP and the beginning of the SolCal MY MY_SC.
    Used in the case when DP <= MY_SC.
    :param MY_SC: Solcal MY, non-zero integer.
    :param DP: Solcal MY, non-zero integer, its beginning is the starting point of the correction eras.
    :return: The number of MY between the beginning of PD and the beginning of MY_SC, positive integer.
    """
    if DP < 0:
        if MY_SC < 0:
            return abs(DP) - abs(MY_SC)
        else:
            return abs(DP) + MY_SC - 1
    else:
        return MY_SC - DP


def delta_minus(MY_SC: int, DP: int) -> int:
    """
    Returns the number of MY between the end of the Solcal MY DP and the end of the SolCal MY MY_SC.
    Used in the case when PD > MY_SC.
    :param MY_SC: Solcal MY, non-zero integer.
    :param DP: Solcal MY, non-zero integer, its beginning is the starting point of the correction eras.
    :return: The number of MY between the end of PD and the end of MY_SC as a positive integer.
    """
    if DP > 0:
        if MY_SC > 0:
            return DP - MY_SC - 1
        else:
            return abs(MY_SC + 1) + DP - 1
    else:
        return abs(MY_SC + 1) - abs(DP)


def correction_forward(MY_SC: int, SOY_SC: int, n: int, DP: int, p: int) -> tuple:
    """
    Function that apply n correction forward in the future. Correspond to the case when the MY DP is before or equal to
    the MY MY_SC. In this case we subtract n sols depending on the era MY_SC is in.
    :param MY_SC: SolCal MY, non-zero integer.
    :param SOY_SC: Sol Of the Year of MY_SC, integer from 1 to 668 or 669 depending on the position of MY_SC in its cycle.
    :param n: Number of sols to deduct in the forwards correction. Positive integer.
    :param DP: Solcal MY, non-zero integer, its beginning is the starting point of the correction eras.
    :param p: Length of an era in number of MY, non-zero positive integer.
    :return: The corrected part of the SolCal date, tuple of the corrected MY and SOY.
    """
    # Copy of variables to modify :
    MY_new, MY_old, SOY_prime = MY_SC, MY_SC - 1, SOY_SC

    # While the number of correction is not finished :
    while n > 0:

        # If we are in a new MY, we update the associated parameters :
        if MY_new != MY_old:
            delta_plus_MY = delta_plus(MY_new, DP=DP)
            id_MY = id(MY_new)
            nb_sol_MY = int(668.5 + (-1) ** (id_MY + 1) / 2)
            MY_old = MY_new

        # If we are just before the last sol at the end of an era we apply two corrections :
        if SOY_prime == nb_sol_MY and (delta_plus_MY + 1) % p == 0:
            SOY_prime = 1
            if MY_new == -1:
                MY_new = 1
            else:
                MY_new += 1
            n -= 1

        # Normal case (only one correction) :
        else:
            if SOY_prime == nb_sol_MY:
                if MY_new == -1:
                    MY_new = 1
                else:
                    MY_new += 1
                SOY_prime = 1
            else:
                SOY_prime += 1
            n -= 1

    return MY_new, SOY_prime


def correction_backward(MY_SC: int, SOY_SC: int, n: int, DP: int, p: int) -> tuple:
    """
    Function that apply n correction backwards in the past. Correspond to the case when the MY DP is after the MY MY_SC.
    In this case we add n sols depending on the era MY_SC is in.
    :param MY_SC: SolCal MY, non-zero integer.
    :param SOY_SC: Sol Of the Year of MY_SC, integer from 1 to 668 or 669 depending on the position of MY_SC in its cycle.
    :param n: Number of sols to add in the backward correction. Positive integer.
    :param DP: Solcal MY, non-zero integer, its beginning is the starting point of the correction eras.
    :param p: Length of an era in number of MY, non-zero positive integer.
    :return: The corrected part of the SolCal date, tuple of the MY and the SOY.
    """
    # Copy of variables to modify :
    MY_new, MY_old, SOY_prime = MY_SC, MY_SC - 1, SOY_SC

    # While the number of correction is not finished :
    while n > 0:

        # If we are in a new MY, we update the associated parameters :
        if MY_new != MY_old:
            delta_minus_MY = delta_minus(MY_new, DP=DP)
            MY_old = MY_new

        # If we are just at the first sol at the beginning of an era we apply two corrections :
        if SOY_prime == 1 and (delta_minus_MY + 1) % p == 0:
            if MY_new == 1:
                MY_new = -1
            else:
                MY_new -= 1
            id_MY = id(MY_new)
            nb_sol_MY = int(668.5 + (-1) ** (id_MY + 1) / 2)
            SOY_prime = nb_sol_MY - 1
            n -= 1

        # Normal case : only one correction :
        else:
            if SOY_prime == 1:
                if MY_new == 1:
                    MY_new = -1
                else:
                    MY_new -= 1
                id_MY = id(MY_new)
                nb_sol_MY = int(668.5 + (-1) ** (id_MY + 1) / 2)
                SOY_prime = nb_sol_MY
            else:
                SOY_prime -= 1
            n -= 1
    return MY_new, SOY_prime


def correction(MY_SC: int, SOY_SC: int, DP: int, p: int) -> tuple:
    """
    Correction function for the SolCal, transforms a SolCal date in a corrected SolCal date.
    :param MY_SC: SolCal MY, non-zero integer.
    :param SOY_SC: Sol Of the Year of MY_SC, integer from 1 to 668 or 669 depending on the position of MY_SC in its cycle.
    :param DP: Solcal MY, non-zero integer, its beginning is the starting point of the correction eras.
    :param p: Length of an era in number of MY, non-zero positive integer.
    :return: The corrected part of the SolCal date, tuple of the corrected MY and SOY.
    """
    # If MY_SC is after the beginning of the eras, we apply the forward correction :
    if DP <= MY_SC:
        delta_plus_MY = delta_plus(MY_SC, DP=DP)
        num_era = (delta_plus_MY // p) + 1
        return correction_forward(MY_SC, SOY_SC, num_era - 1, DP, p)  # num_era - 1 because the era 1 has no correction

    # If MY_SC is before, we apply the backward correction :
    else:
        delta_minus_MY = delta_minus(MY_SC, DP=DP)
        num_era = (delta_minus_MY // p) + 1

        return correction_backward(MY_SC, SOY_SC, num_era, DP, p)


## EoT and Ls calculating functions from Mars24 ########################################################################

def Ls_MARS24(delta_t_J2000: float) -> float:
    """
    Function of the MARS24 Sunclock algorithm that calculate the cumulated areocentric solar longitude from the number
    of days since J2000 Epoch (TT).
    :param delta_t_J2000: Days Since J2000 Epoch (TT).
    :return: The cumulated areocentric solar longitude since J2000 Epoch (TT), in degrees.
    """
    # Mars mean anomaly :
    mars_mean_anomaly = Mars24.get_mars_mean_anomaly(delta_t_J2000)

    # Angle of the fictitious mean Sun :
    angle_FMS = Mars24.get_angle_FMS(delta_t_J2000)

    # Perturbers :
    PBS = Mars24.get_PBS(delta_t_J2000)

    # Equation of center :
    EoC = Mars24.get_EoC(delta_t_J2000, mars_mean_anomaly, PBS)

    return angle_FMS + EoC


def EoT_Mars24(jd_tt: float, piqueuxEtAl: bool = False) -> float:
    """
    Calculate the Equation of time from a given JD (TT).
    :param jd_tt: Julian date (TT).
    :param piqueuxEtAl: If True, the function will use the equation from Piqueux et al. for the Ls calculation, if not
    the ones from Mars24.
    :return: Corresponding equation of time.
    """
    # time since J2000 (TT) :
    t_offset_J2000 = jd_tt_to_t_elapsed_J2000(jd_tt)

    # Areocentric Ls :
    if piqueuxEtAl:
        Ls = piqueux.Ls_function(t_offset_J2000)
    else:
        Ls = Ls_MARS24(t_offset_J2000)

    # Mean anomaly:
    M = Mars24.get_mars_mean_anomaly(t_offset_J2000)

    # PBS :
    PBS = Mars24.get_PBS(t_offset_J2000)

    # Equation of center :
    EoC = Mars24.get_EoC(t_offset_J2000, M, PBS)

    # Equation of time :
    EoT = Mars24.get_EoT(Ls, EoC)

    return EoT


## Datetime (UTC), JD (TT), t since J2000 (TT) conversion functions ####################################################

def datetime_utc_to_t_elapsed_J2000(date: datetime.datetime) -> float:
    """
    Transforms an Earth date in datetime format (UTC) to time elapsed in days since epoch J2000 (TT) using
    astropy.time.Time object timescale conversion.
    :param date: Earth date (UTC)
    :return: Time offset from epoch J2000 in julian days.
    """
    # Earth date time scale conversion to TT :
    t = Time(date, format='datetime', scale='utc')
    t_tt = t.copy()
    t_tt = t_tt.tt

    # Time offset from J2000 epoch (TT) :
    t_j2000_epoch_tt = Time('2000-01-01T12:00:00', scale='tt')

    # Time elapsed :
    t_elapsed = t_tt - t_j2000_epoch_tt

    # Returns time elapsed in days :
    return t_elapsed.jd


def jd_tt_to_datetime_utc(jd_tt: float) -> datetime.datetime:
    """
    Convert a Julian date (TT) to datetime (UTC).
    :param jd_tt: Julian date (TT).
    :return: Corresponding Earth date (UTC).
    """
    # Conversion to UTC :
    t_tt = Time(jd_tt, format='jd', scale='tt')
    t_utc = t_tt.copy()
    t_utc = t_utc.utc

    # Equivalent datetime :
    return t_utc.to_datetime(leap_second_strict='silent')


def datetime_utc_to_jd_tt(dtime: datetime.datetime) -> float:
    """
    Convert a datetime (UTC) to Julian date (TT).
    :param dtime: Earth date (UTC).
    :return: Corresponding Julian date (TT).
    """
    # Conversion to TT :
    t_utc = Time(dtime, format='datetime', scale='utc')

    t_tt = t_utc.copy()
    t_tt = t_tt.tt

    # Conversion to JD :
    jd_tt = t_tt.jd

    return jd_tt


def jd_tt_to_t_elapsed_J2000(jd_tt: float) -> float:
    """
    Calculate the time elapsed in days since epoch J2000 (TT) from a julian date (TT).
    :param jd_tt: Julian date (TT).
    :return: Time since epoch J2000 (TT) in julian days.
    """
    # Time offset from J2000 epoch (TT) :
    t_j2000_epoch_tt = Time('2000-01-01T12:00:00', scale='tt')

    # Time elapsed :
    t_elapsed = jd_tt - t_j2000_epoch_tt.jd

    # Return time elapsed in days :
    return t_elapsed


## datetime.time, number of hours, number of days conversion ###########################################################

def nb_hours_to_time(nb_hours: float) -> datetime.time:
    """
    Convert a number of hours to a datetime.time format.
    :param nb_hours: Number of hours.
    :return: Corresponding time in a datetime.time format.
    """
    if nb_hours < 0:
        nb_hours = nb_hours + 24

    hours = int(nb_hours)

    nb_minutes = (nb_hours - hours) * 60
    minutes = int(nb_minutes)

    nb_seconds = (nb_minutes - minutes) * 60
    seconds = int(nb_seconds)

    nb_microseconds = (nb_seconds - seconds) * 1e6
    microseconds = int(nb_microseconds)

    return datetime.time(hours % 24, minutes, seconds, microseconds)


def time_to_nb_days(time: datetime.time) -> float:
    """
    Convert an object datetime.time to the equivalent number of days.
    :param time: Time in a datetime.time format.
    :return: Equivalent number of days.
    """
    hours = time.hour
    minutes = time.minute
    seconds = time.second
    microseconds = time.microsecond
    return (hours + minutes / 60 + seconds / 3600 + microseconds / 3600000000) / 24


## Martian solar time functions ########################################################################################

def get_MMST_from_ED(date: datetime.datetime) -> datetime.time:
    """
    Gives the Martian Mean Solar Time at Mars's prime meridian at an Earth date (UTC).
    :param date: Earth date (UTC).
    :return: Corresponding Martian Mean Solar Time.
    """
    # Conversion in JD(TT) :
    t_utc = Time(date, format='datetime', scale='utc')
    t_tt = t_utc.copy()
    t_tt = t_tt.tt
    jd_tt = t_tt.jd

    # Mean solar time calculation :
    MST = Mars24.get_MST(jd_tt)

    return nb_hours_to_time(MST)


def get_MTST_from_ED(date: datetime.datetime) -> datetime.time:
    """
    Gives the Martian True Solar Time at Mars's prime meridian at an Earth date (UTC).
    :param date: datetime.datetime object, Earth date (UTC).
    :return: datetime.time object, corresponding Martian True Solar Time.
    """
    # Conversion to JD (TT) :
    t_utc = Time(date, format='datetime', scale='utc')
    t_tt = t_utc.copy()
    t_tt = t_tt.tt
    jd_tt = t_tt.jd

    # time since J2000 (TT) :
    t_offset_J2000 = datetime_utc_to_t_elapsed_J2000(date)

    # Mean anomaly:
    M = Mars24.get_mars_mean_anomaly(t_offset_J2000)

    # PBS :
    PBS = Mars24.get_PBS(t_offset_J2000)

    # Equation of center :
    EoC = Mars24.get_EoC(t_offset_J2000, M, PBS)

    # Angle of the FMS :
    angle_FMS = Mars24.get_angle_FMS(t_offset_J2000)

    # Areocentric Ls :
    Ls = (angle_FMS + EoC) % 360

    # Equation of time :
    EoT = Mars24.get_EoT(Ls, EoC)

    # Mean solar time at the prime meridian :
    MST = Mars24.get_MST(jd_tt)

    # True solar time at Mars's prime meridian :
    TST = Mars24.get_LTST(MST, EoT)

    return nb_hours_to_time(TST)


# float or datetime.datetime or np.float64

def MMST_MARS24(inputDate: Union[float, datetime.datetime, np.float64], giveHour=True) -> float:
    """
    Gives the Martian Mean Solar Time at Mars's prime meridian at a JD (TT). With or without the modulo 24.
    :param inputDate: Julian date (TT) or a datetime.datetime object (UTC). Automatic detection.
    :param giveHour: Indicates whether to apply the modulo 24 or not.
    :return: Number of SolCal hours.
    """
    if isinstance(inputDate, datetime.datetime):
        jd_tt = datetime_utc_to_jd_tt(inputDate)
    elif isinstance(inputDate, (float, np.float64)):
        jd_tt = inputDate
    else:
        raise ValueError("Input must either be 'jd_tt' or 'datetime.time'")

    if giveHour:
        return (24 * ((jd_tt - 2451549.5) / 1.0274912517 + 44796.0 - 0.0009626)) % 24
    else:
        return 24 * ((jd_tt - 2451549.5) / 1.0274912517 + 44796.0 - 0.0009626)


def Mars_LTST(inputDate: Union[float, datetime.datetime, np.float64], planeto_longitude: float = 0,
              degree_west: bool = True, giveHour: bool = True, timeFormat: bool = False, piqueuxEtAl: bool = False) -> \
        Union[datetime.time, float]:
    """
    Gives the Martian True Solar Time at position planeto_longitude on the planet at an input Earth Date.
    :param inputDate: Julian date (TT) or a datetime.datetime object (UTC). Automatic detection.
    :param planeto_longitude: Planetographic longitude, in degree west or east depending on the value of
    degree_west.
    :param degree_west: Indicates whether planeto_longitude is in degree west or not.
    :param giveHour: Indicates whether to apply the modulo 24 or not.
    :param timeFormat: If True the output is given in a datetime.time format, if not is given in a number of
    martian hours.
    :param piqueuxEtAl: If True uses the Ls calculation method from Piqueux et al. (2015) else uses the one from
    the Mars24 Sunclock algorithm.
    :return: Number of martian hours or a datetime.time format.
    """
    # Gives the MST and the EoTT depending on the input format, Julian Date (TT) or datetime.time object (UTC) :
    if isinstance(inputDate, (float, np.float64)):
        MST = (24 * ((inputDate - 2451549.5) / 1.0274912517 + 44796.0 - 0.0009626))
        EoT = EoT_Mars24(inputDate, piqueuxEtAl=piqueuxEtAl)
    elif isinstance(inputDate, datetime.datetime):
        MST = (24 * ((datetime_utc_to_jd_tt(inputDate) - 2451549.5) / 1.0274912517 + 44796.0 - 0.0009626))
        EoT = EoT_Mars24(datetime_utc_to_jd_tt(inputDate), piqueuxEtAl=piqueuxEtAl)
    else:
        raise ValueError("Input must either be 'jd_tt' or 'datetime.time'")

    # 24 h format or cumulated number of hours :
    if giveHour:
        # If in degree west or east :
        if degree_west:
            MTST = ((MST - planeto_longitude * 24 / 360) % 24) + EoT / 15
        else:
            MTST = ((MST + planeto_longitude * 24 / 360) % 24) + EoT / 15
        # Time format :
        if timeFormat:
            return nb_hours_to_time(MTST)
        else:
            return MTST
    else:
        if degree_west:
            MTST = (MST - planeto_longitude * 24 / 360) + EoT / 15
        else:
            MTST = (MST + planeto_longitude * 24 / 360) + EoT / 15
        return MTST


## Beginning of the martian tropical calendar (according to Mars24 Ls equation) ########################################

# date_0 = Time(datetime.datetime(1955, 4, 11, 10, 58, 16, 258284), format='datetime', scale='utc')

# TEST WARNING ERFA # todo : A enlever quand les tests sont terminé
date_0 = Time(datetime.datetime(1955, 4, 11, 10, 58, 16, 258284), format='datetime', scale='tt')

## Value of the coefficients of the MMST_MARS24 function ###############################################################

a = 24 / 1.0274912517
b = 24 * (- 2451549.5 / 1.0274912517 + 44796.0 - 0.0009626)


## Roots of the MMST function (with modulo) ############################################################################

def roots_MMST(k: int) -> float:
    """
    Gives the kth root of the MMST_MARS24 function.
    :param k: Integer index of the root.
    :return: Root.
    """
    return (24 * k - b) / a


## Beginning of the SolCal #############################################################################################

date_0_jd_tt = datetime_utc_to_jd_tt(date_0.to_datetime())

k_inf = np.floor(MMST_MARS24(date_0_jd_tt, giveHour=False) / 24)
k_sup = np.ceil(MMST_MARS24(date_0_jd_tt, giveHour=False) / 24)

midn_inf_jd_tt = roots_MMST(k_inf)
midn_inf_date_utc = jd_tt_to_datetime_utc(midn_inf_jd_tt)

midn_sup_jd_tt = roots_MMST(k_sup)
midn_sup_date_utc = jd_tt_to_datetime_utc(midn_sup_jd_tt)

# Closest MMST midnight to date_0 :
SCdate_0 = Time(midn_sup_date_utc, format='datetime', scale='utc')


## Custom sign function ################################################################################################

def signe(x: float) -> Literal[-1, 1]:
    """
    Custom sign function, if x >= 0 returns 1, else returns -1.
    :param x: Float.
    :return: Integer, 1 or -1.
    """
    if x >= 0:
        return 1
    else:
        return -1


## Earth date (UTC) and (Ls, MY_trop) conversion #######################################################################

# Earth date (UTC) -> (Ls, MY_trop) :

def get_Ls_MTY_from_Earth_date_utc(date: datetime.datetime, piqueuxEtAl: bool = False) -> tuple:
    """
    Calculate the martian tropical date corresponding to an Earth date (UTC).
    :param date: Earth date (UTC)
    :param piqueuxEtAl: if True the Ls is calculated with the formula from Piqueux et al. (2015), if not by the formula
    from the Mars24 algorithm.
    :return: The areocentric solar longitude and martian tropical year.
    """
    # Time offset from J2000 epoch in timescale (TT) :
    t_offset_J2000 = datetime_utc_to_t_elapsed_J2000(date)

    # Mars mean anomaly :
    mars_mean_anomaly = Mars24.get_mars_mean_anomaly(t_offset_J2000)

    # Angle of the fictitious mean Sun :
    angle_FMS = Mars24.get_angle_FMS(t_offset_J2000)

    # Perturbers :
    PBS = Mars24.get_PBS(t_offset_J2000)

    # Equation of center :
    EoC = Mars24.get_EoC(t_offset_J2000, mars_mean_anomaly, PBS)

    # Cumulated Ls since nye MY_trop = 24 :
    if piqueuxEtAl:
        Ls_since_24 = piqueux.Ls_function(t_offset_J2000)
    else:
        Ls_since_24 = Ls_MARS24(t_offset_J2000)

    # Determination of the tropical martian year :
    if date >= date_0:
        MY_trop = int(24 + np.floor(Ls_since_24 / 360))
    else:
        MY_trop = int(23 + np.floor(Ls_since_24 / 360))

    # Ls determination :
    if piqueuxEtAl:
        Ls = Ls_since_24 % 360
    else:
        Ls = (angle_FMS + EoC) % 360

    return Ls, MY_trop


# (Ls, MY_trop) -> Earth date (UTC) :

def f(delta_t_J2000: float, delta_Ls_J2000: float, piqueuxEtAl: bool = False) -> float:
    """
    Function to find to zero to, equivalent of finding the time offset from J2000 epoch corresponding to the value of
    the cumulated Ls since the beginning of the tropical martian year 24.
    :param delta_t_J2000: float, Julian date (TT) representing the time offset from J2000 epoch.
    :param delta_Ls_J2000: Given value of the cumulated areocentric solar longitude since the beginning of the
    tropical martian year 24.
    :param piqueuxEtAl: Indicates if the way of calculate the Ls is from Piqueux et al. (2015) or the Mars24 algorithm.
    :return: Difference between the cumulated Ls at delta_t_J2000 and the reference value delta_Ls_J2000.
    """
    if piqueuxEtAl:
        return piqueux.Ls_function(delta_t_J2000) - delta_Ls_J2000
    else:
        return Ls_MARS24(delta_t_J2000) - delta_Ls_J2000


def get_Earth_date_utc_from_Ls_MTY(Ls: float, MY_trop: int, piqueuxEtAl: bool = False) -> datetime.datetime:
    """
    Calculate the corresponding Earth date (UTC) of a tropical date.
    :param Ls: Areocentric solar longitude, in degrees in the range [0, 360).
    :param MY_trop: Martian tropical year, non-zero integer.
    :return: Corresponding Earth date (UTC).
    """
    # Determination of the path of the Ls since the beginning of the tropical martian year 24 :
    if MY_trop >= 1:
        Ls_path_since_24 = Ls + 360 * (MY_trop - 24)
    else:
        Ls_path_since_24 = Ls + 360 * (MY_trop - 23)

    # Time elapsed in days since J2000 (TT) corresponding to the cumulated Ls since the beginning of the tropical
    # martian year 24 :
    if piqueuxEtAl:
        t_elapsed_J2000 = scipy.optimize.newton(f, 0, args=(Ls_path_since_24, True,))
    else:
        t_elapsed_J2000 = scipy.optimize.newton(f, 0, args=(Ls_path_since_24,))

    # Finding the corresponding Earth date in astropy.Time format (TT) :
    t_j2000_epoch_tt = Time('2000-01-01T12:00:00', scale='tt')
    t_tt = t_j2000_epoch_tt + TimeDelta(t_elapsed_J2000, format='jd')

    # UTC conversion :
    t_utc = t_tt.copy()
    t_utc = t_utc.utc

    # Datetime don't take into account leap seconds, leap_second_strict='warn' to not stop the calculations but just
    # warn of the leap seconds presence :
    return t_utc.to_datetime(leap_second_strict='warn')


## Earth date (UTC) and SolCal date (MUT) conversion ##################################################################

# Earth date (UTC) -> SolCal date (MUT) :

def get_SolCal_from_Earth_date_utc(ED_UTC: datetime.datetime, corr: bool = False) -> tuple[int, int, datetime.time]:
    """
    Calculate the SolCal date (MUT) corresponding to an Earth date (UTC).
    :param ED_UTC: Earth date (UTC).
    :param corr: Indicates if we want a corrected SolCal date.
    :return: SolCal date (MUT), corrected or not.
    """
    # Conversion of the Earth date into the equivalent Julian date (TT) :
    jd_tt = datetime_utc_to_jd_tt(ED_UTC)

    # JD(TT) conversion of the beginning of SolCaL :
    beginCal_time_utc = SCdate_0
    beginCal_time_tt = beginCal_time_utc.tt
    jd_tt_0 = beginCal_time_tt.jd

    # Number of sols we have to add or deduct to go from SCdate0 to the Earth date(UTC) of Midn_ED :
    k_now = np.floor(MMST_MARS24(jd_tt, giveHour=False) / 24)
    k_0 = np.floor(MMST_MARS24(jd_tt_0, giveHour=False) / 24)
    delta_sols_0_now = k_now - k_0

    # Number of comleted 5-year cycles in a |delta_sols_0_now| sol period :
    if delta_sols_0_now < 0 and (abs(delta_sols_0_now) % 3343 == 0):
        nb_cycles_0_now = (abs(delta_sols_0_now) // 3343) - 1
    else:
        nb_cycles_0_now = abs(delta_sols_0_now) // 3343

    # Number of past sols elapsed either from the beginning or the end of the current cycle :
    nb_sols_cycle_now = abs(delta_sols_0_now) - 3343 * nb_cycles_0_now

    # Determination of the number of sols from the beginning or the end of the martian year and of the index year
    # from the end of the cycle or from the end :
    nb_sols_MY_now = nb_sols_cycle_now
    n_year = 1

    if delta_sols_0_now >= 0:
        while nb_sols_MY_now + 1 > (668.5 + np.power(-1, 1 + n_year) / 2):  # or nb_sols_MY_now >= 669:
            nb_sols_MY_now -= 668.5 + np.power(-1, 1 + n_year) / 2
            n_year += 1
    else:
        while nb_sols_MY_now > (668.5 + np.power(-1, 1 + n_year) / 2):  # or nb_sols_MY_now >= 669:
            nb_sols_MY_now -= 668.5 + np.power(-1, 1 + n_year) / 2
            n_year += 1

    # SOY (SolCal) determination :
    if delta_sols_0_now < 0:
        # SOY_SC = [669, 668, 669, 668, 669][5 - ((5 - n_year) % 5) - 1] - nb_sols_MY_now + 1
        SOY_SC = [669, 668, 669, 668, 669][int(n_year) - 1] - nb_sols_MY_now + 1
    else:
        SOY_SC = nb_sols_MY_now + 1

    # Martian year (SolCal) determination :
    MY_SC = signe(delta_sols_0_now) * (nb_cycles_0_now * 5 + n_year)

    # MUT determination :
    MUT = nb_hours_to_time(MMST_MARS24(jd_tt))

    # Correction (Optional) :
    if corr:
        MY_SC, SOY_SC = correction(MY_SC, SOY_SC, DP=-35, p=105)

    return int(MY_SC), int(SOY_SC), MUT


# SolCal date (MMST) -> Earth date (UTC) :

def get_Earth_date_utc_from_SolCal(MY_SC: int, SOY_SC: int, MUT: datetime.time) -> datetime.datetime:
    """
    Calculate the Earth date (UTC) corresponding to an SolCal date (MUT).
    :param MY_SC: SolCal MY, non-zero integer.
    :param SOY_SC: Sol Of The Year, integer between 1 and 669 or 668 depending on the position of MY_SC in its cycle.
    :param MUT: Martian mean solar time at the prime meridian.
    :return: Corresponding Earth date (UTC).
    """
    # SolCal date values verifications :
    num_year_cycle = abs(MY_SC) - ((abs(MY_SC) - 1) // 5) * 5
    SOY_MY = 668.5 + ((-1) ** (1 + num_year_cycle)) / 2

    if MY_SC == 0:
        raise ValueError("As a year number, MY_SC cannot be equal to zero.")

    if SOY_SC < 1 or SOY_SC > SOY_MY:
        raise ValueError(f"The sol of the year SOY_SC of the SolCal MY{MY_SC} must be between 1 and {SOY_MY}.")

    # Number of sols between the beginning of the SolCal and the beginning or the end of the 5 SolCal year cycle
    # containing My_SC :
    nb_sols_0_abs_cycle = ((abs(MY_SC) - 1) // 5) * 3343

    # MY_SC index in its cycle :
    n_year = id(MY_SC)

    # Number of sols between the beginning of the SolCal and the beginning or the end of MY_SC :
    nb_sols_0_MY = nb_sols_0_abs_cycle + np.sum([669, 668, 669, 668, 669][:n_year - 1])

    # Number of past sols from the beginning or the end of the SolCal date :
    if MY_SC < 0:
        nb_sols_MY_now = [669, 668, 669, 668, 669][n_year - 1] - SOY_SC + 1
    else:
        nb_sols_MY_now = SOY_SC - 1

    # Sol number (signed) of the beginning or the end of the SOY_SC in respect to the beginning of the SolCal :
    delta_sols_0_now = signe(MY_SC) * (nb_sols_0_MY + nb_sols_MY_now)

    # Calculation of the MUT midnight index of Midn_ED :
    beginCal_time_utc = SCdate_0
    beginCal_time_tt = beginCal_time_utc.tt
    jd_tt_0 = beginCal_time_tt.jd
    k_0 = np.floor(MMST_MARS24(jd_tt_0, giveHour=False) / 24)
    k_now = delta_sols_0_now + k_0

    # MUT in hours :.
    t_MUT = time_to_nb_days(MUT) * 24

    return jd_tt_to_datetime_utc((t_MUT + 24 * k_now - b) / a)


## (Ls, MY_trop) and SolCal date (MMST) conversion #####################################################################

# (Ls, MY_trop) -> SolCal date (MMST) :

def get_SolCal_from_Ls_MTY(Ls: float, MY_trop: int, piqueuxEtAl: bool = False, corr: bool = False) -> tuple[
    int, int, datetime.time]:
    """
    Calculate the SolCal date (MUT) from a martian tropical date.
    :param Ls: Areocentric Ls, in degrees in the range [0, 360).
    :param MY_trop: Tropical martian year, non-zero integer.
    :param piqueuxEtAl: Indicates if we want to use the Ls formula from Piqueux et al. (2015) or from the Mars24
    Sunclock algorithm to convert the tropical date to an Earth date (UTC).
    :param corr: Indicates if we want a corrected SolCal date.
    :return: SolCal date (MUT), corrected or not.
    """
    # Conversion of the tropical date to a Earth date :
    date = get_Earth_date_utc_from_Ls_MTY(Ls, MY_trop, piqueuxEtAl=piqueuxEtAl)

    # Conversion of the Earth date to a SolCal date :
    return get_SolCal_from_Earth_date_utc(date, corr=corr)


# SolCal date (MMST) -> (Ls, MY_trop) :

def get_Ls_MTY_from_SolCal(MY_SC: int, SOY_SC: int, MUT: datetime.time, piqueuxEtAl: bool = False) -> tuple:
    """
    Calculate the martian tropical date from a SolCal date (MUT).
    :param MY_SC: Martian SolCal year, non-zero integer.
    :param SOY_SC: SolCal Sol Of the Year, integer from 1 to 669 or 668 depending on the position of MY_SC in its cycle.
    :param MUT: Martian mean solar time at prime meridian.
    :param piqueuxEtAl: Indicates if we want to calculate the tropical date using the Piqueux et al. (2015) formulas or
    ones from the Mars24 algorithm.
    :return: The corresponding tropical date.
    """
    # Conversion of the SolCal date to an Earth date :
    date = get_Earth_date_utc_from_SolCal(MY_SC, SOY_SC, MUT)

    # Conversion of the Earth date to a tropical date :
    return get_Ls_MTY_from_Earth_date_utc(date, piqueuxEtAl=piqueuxEtAl)

########################################################################################################################
