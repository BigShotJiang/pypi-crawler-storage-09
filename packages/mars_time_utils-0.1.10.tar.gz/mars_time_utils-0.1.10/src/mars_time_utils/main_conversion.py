"""
Title : Martian Time Conversion Main Interface Function (Beta Version)
Description : Function that unify all the conversion functions of the SolCalTimeConversion.py file (Beta Version)
Author : Victorien Guyon (victorien.guyon@protonmail.com)
Date : February 2025

Company : PANEUREKA
Address : 17 rue du lac Saint-Andre, 73370, Le Bourget-du-lac, France
Reference point : Luca Montabone (lmontabone@paneureka.org)


This license governs the use of the beta version of the "Martian Time Conversion Algorithm Functions" (the "Software")
provided to CNES and LMD by PANEUREKA/Victorien Guyon.

1. Copyright Ownership
PANEUREKA retains all rights, title, and interest in and to the Software, including all intellectual property rights. Authorship credit is attributed to Victorien Guyon, who developed the Software in the context of an internship and subsequent apprenticeship at PANEUREKA under the supervision of Dr. Luca Montabone.

2. Permitted Use
a. CNES and LMD are granted a non-exclusive, non-transferable, royalty-free license to use, modify, and evaluate the Software internally for research,
testing, and operational purposes only.
b. Redistribution, sublicensing, or commercial deployment of the Software is prohibited without prior written consent from PANEUREKA.

3. Restrictions
a. The Software may not be distributed, sublicensed, or otherwise made available to third parties in any form.
b. Any modifications to the Software must retain authorship attribution to Victorien Guyon and a copyright notice for PANEUREKA.
b. The Software may not be used in production environments or for commercial purposes.

4. Liability Limitation
a. The Software is provided "as is" without warranty of any kind, express or implied, including but not limited to the warranties of merchantability,
fitness for a particular purpose, or non-infringement.
b. PANEUREKA and Victorien Guyon shall not be held liable for any damages, losses, or issues arising from the use or misuse of the Software,
including, but not limited to, direct, indirect, incidental, consequential, or special damages, whether in contract, tort, or otherwise.
c. The users of the Software (including CNES and LMD) are solely responsible for ensuring that the Software is used in compliance
with all applicable laws, regulations, and ethical standards.

5. Future Licensing
A finalized version of the Software will be released under a separate license that may allow for broader distribution and use.
This beta license shall remain in effect until superseded by the finalized version.

6. Governing Law
This license shall be governed by the laws of France.

By using this Software, CNES and LMD agree to abide by the terms of this license.
"""

import numpy as np

from .SolCalTimeConversion import *
import random


# Conversion functions between SolCal with month and SolCal with no month ##############################################

def conv_SC_to_SCmonth(dateSC: tuple[int, int, datetime.time]) -> tuple[int, int, int, datetime.time]:
    """
    Convert a typical SolCal date to a SolCal date with month.
    :param dateSC: (MY_SC, SOY_SC, MUT)
    :return: (MY_SC, month, sol, MUT), with month the martian month and sol the sol number in the month.
    """
    # Extraction of the dates components :
    MY, SOY, MUT = dateSC

    # MY index in its cycle :
    n_year = id(MY)

    # Number of sols in the MY :
    nbSOY_MY = [669, 668, 669, 668, 669][n_year - 1]

    # Number of sols in  each Martian month :
    nbSOY_month = [56, 55, 56, 55, 56, 56, 55, 56, 55, 56, 56, [56, 57][668 == nbSOY_MY]]

    # sol and month determination :
    sol = SOY
    month = 1

    while sol > nbSOY_month[month - 1]:
        sol -= nbSOY_month[month - 1]
        month += 1

    return int(MY), int(month), int(sol), MUT


def conv_SCmonth_to_SC(dateSC_month: tuple[int, int, int, datetime.time]) -> tuple[int, int, datetime.time]:
    """
    Converts a SolCal date with month to a typical SolCal date.
    :param dateSC_month: (MY_SC, month, sol, MUT), with month the martian month and sol the sol number in the month.
    :return: (MY_SC, SOY, MUT)
    """

    # Components extraction :
    MY, month, sol, MUT = dateSC_month

    # MY index in its cycle :
    n_year = id(MY)

    # Number of sols in MY :
    nbSOY_MY = [669, 668, 669, 668, 669][n_year - 1]

    # Number of sols in each month of the MY :
    nbSOY_month = [56, 55, 56, 55, 56, 56, 55, 56, 55, 56, 56, [56, 57][668 == nbSOY_MY]]

    # SOY determination:
    SOY = sum(nbSOY_month[:month - 1]) + sol

    return int(MY), int(SOY), MUT


# Main function ########################################################################################################

def __analyse_input(input: Union[
    datetime.datetime, float, np.float64, tuple[float, float, datetime.time], tuple[float, int]]) -> str:
    """
    Determines the type of date in input from the type of the object. Returns None if confronted with unrecognised type.
    :param input: Input date.
    :return: String representing the detected input date : 'ed_dt' for an Earth date in datetime.datetime format,
    'ed_jd' for an Earth date expressed in julian days (TT), 'tropical' for a tropical date and 'solcal' for a SolCal
    date.
    """
    inputType = None
    if isinstance(input, datetime.datetime):
        inputType = "ed_dt"
    elif isinstance(input, (float, np.float64)):
        inputType = "ed_jd"
    elif isinstance(input, tuple):
        if len(input) == 2:
            inputType = "tropical"
        elif len(input) == 3:
            inputType = "solcal"
        elif len(input) == 4:
            inputType = "solcal_m"
    return inputType


def __calendarConversionUnit(
        inputTime: Union[datetime.datetime, np.float64, float, tuple[float, float, datetime.time], tuple[float, int]],
        conv: str, piqueuxEtAl: bool = False, corr: bool = False, giveMUT: bool = False, giveLTST: bool = False,
        planeto_longitude: float = 0, degree_west: bool = True) -> Union[
    datetime.datetime, np.float64, tuple[float, float, datetime.time], tuple[float, int]]:
    """
    Universal date conversion function. Adapted to process only one date at a time.
    :param inputTime: Date to convert.
    :param conv: String representing the detected input date : 'ed_dt' for an Earth date in datetime.datetime format,
    'ed_jd' for an Earth date expressed in julian days (TT), 'tropical' for a tropical date and 'solcal' for a SolCal
    date.
    :param piqueuxEtAl: If True uses the Ls calculation method from Piqueux et al. (2015) else uses the one from
    the Mars24 Sunclock algorithm.
    :param corr: If True in the case of a SolCal output, gives the corrected SolCal date.
    :param giveMUT: If True and if the desired output is not a SolCal date, gives the MUT along with the output.
    :param giveLTST: If True, gives the LTST along with the output.
    :param planeto_longitude: Planetographic longitude, in degree west or east depending on the value of
    degree_west.
    :param degree_west: Indicates whether planeto_longitude is in degree west or not.
    :return: Converted Date.
    """
    # conv value checking :
    if conv not in {"ed_dt", "ed_jd", "tropical", "solcal", "solcal_m"}:
        raise ValueError("Unknown conversion.")

    # Input type information recovery :
    inputType = __analyse_input(inputTime)
    if inputType is None:
        raise ValueError("Unknown input type")

    output = None

    # Conversions depending on the cases :
    if conv == inputType:
        output = inputTime
    elif conv == "ed_dt":
        if inputType == "solcal":
            output = get_Earth_date_utc_from_SolCal(inputTime[0], inputTime[1], inputTime[2])
        elif inputType == "ed_jd":
            output = jd_tt_to_datetime_utc(inputTime)
        elif inputType == "tropical":
            output = get_Earth_date_utc_from_Ls_MTY(inputTime[0], inputTime[1], piqueuxEtAl=piqueuxEtAl)
        elif inputType == "solcal_m":
            inputModif = conv_SCmonth_to_SC(inputTime)
            output = get_Earth_date_utc_from_SolCal(inputModif[0], inputModif[1], inputModif[2])
    elif conv == "ed_jd":
        if inputType == "ed_dt":
            output = datetime_utc_to_jd_tt(inputTime)
        elif inputType == "tropical":
            output = datetime_utc_to_jd_tt(
                get_Earth_date_utc_from_Ls_MTY(inputTime[0], inputTime[1], piqueuxEtAl=piqueuxEtAl))
        elif inputType == "solcal":
            output = datetime_utc_to_jd_tt(get_Earth_date_utc_from_SolCal(inputTime[0], inputTime[1], inputTime[2]))
        elif inputType == "solcal_m":
            inputModif = conv_SCmonth_to_SC(inputTime)
            output = datetime_utc_to_jd_tt(get_Earth_date_utc_from_SolCal(inputModif[0], inputModif[1], inputModif[2]))
    elif conv == "tropical":
        if inputType == "ed_dt":
            output = get_Ls_MTY_from_Earth_date_utc(inputTime, piqueuxEtAl=piqueuxEtAl)
        elif inputType == "ed_jd":
            output = get_Ls_MTY_from_Earth_date_utc(jd_tt_to_datetime_utc(inputTime), piqueuxEtAl=piqueuxEtAl)
        elif inputType == "solcal":
            output = get_Ls_MTY_from_SolCal(inputTime[0], inputTime[1], inputTime[2], piqueuxEtAl=piqueuxEtAl)
        elif inputType == "solcal_m":
            inputModif = conv_SCmonth_to_SC(inputTime)
            output = get_Ls_MTY_from_SolCal(inputModif[0], inputModif[1], inputModif[2])
    elif conv == "solcal":
        if inputType == "ed_dt":
            output = get_SolCal_from_Earth_date_utc(inputTime, corr=corr)
        elif inputType == "ed_jd":
            output = get_SolCal_from_Earth_date_utc(jd_tt_to_datetime_utc(inputTime), corr=corr)
        elif inputType == "tropical":
            output = get_SolCal_from_Ls_MTY(inputTime[0], inputTime[1], piqueuxEtAl=piqueuxEtAl, corr=corr)
        elif inputType == "solcal_m":
            output = conv_SCmonth_to_SC(inputTime)
    elif conv == "solcal_m":
        if inputType == "ed_dt":
            output = conv_SC_to_SCmonth(get_SolCal_from_Earth_date_utc(inputTime, corr=corr))
        elif inputType == "ed_jd":
            output = conv_SC_to_SCmonth(get_SolCal_from_Earth_date_utc(jd_tt_to_datetime_utc(inputTime), corr=corr))
        elif inputType == "tropical":
            output = conv_SC_to_SCmonth(
                get_SolCal_from_Ls_MTY(inputTime[0], inputTime[1], piqueuxEtAl=piqueuxEtAl, corr=corr))
        elif inputType == "solcal":
            output = conv_SC_to_SCmonth(inputTime)

    if giveMUT:
        if conv not in {"solcal", "solcal_m"}:
            if inputType in {"ed_dt", "ed_jd"}:
                MUT_out = MMST_MARS24(inputTime)
            elif inputType == "tropical":
                MUT_out = MMST_MARS24(
                    get_Earth_date_utc_from_Ls_MTY(inputTime[0], inputTime[1], piqueuxEtAl=piqueuxEtAl))
            elif inputType == "solcal_m":
                inputModif = conv_SCmonth_to_SC(inputTime)
                MUT_out = MMST_MARS24(get_Earth_date_utc_from_SolCal(inputModif[0], inputModif[1], inputModif[2]))
            elif inputType == "solcal":
                MUT_out = MMST_MARS24(get_Earth_date_utc_from_SolCal(inputTime[0], inputTime[1], inputTime[2]))
            output = (*output, MUT_out) if isinstance(output, tuple) else (output, MUT_out)

    if giveLTST:
        if inputType in {"ed_dt", "ed_jd"}:
            LTST_out = Mars_LTST(inputTime, planeto_longitude=planeto_longitude, degree_west=degree_west,
                                 piqueuxEtAl=piqueuxEtAl)
        elif inputType == "tropical":
            LTST_out = Mars_LTST(get_Earth_date_utc_from_Ls_MTY(inputTime[0], inputTime[1], piqueuxEtAl=piqueuxEtAl),
                                 planeto_longitude=planeto_longitude, degree_west=degree_west, piqueuxEtAl=piqueuxEtAl)
        elif inputType == "solcal_m":
            inputModif = conv_SCmonth_to_SC(inputTime)
            LTST_out = Mars_LTST(get_Earth_date_utc_from_SolCal(inputModif[0], inputModif[1], inputModif[2]),
                                 planeto_longitude=planeto_longitude, degree_west=degree_west, piqueuxEtAl=piqueuxEtAl)
        elif inputType == "solcal":
            LTST_out = Mars_LTST(get_Earth_date_utc_from_SolCal(inputTime[0], inputTime[1], inputTime[2]),
                                 planeto_longitude=planeto_longitude, degree_west=degree_west, piqueuxEtAl=piqueuxEtAl)
        output = (*output, LTST_out) if isinstance(output, tuple) else (output, LTST_out)

    return output


def calendarConversion(inputTime: Union[
    list, datetime.datetime, np.float64, float, tuple[float, float, datetime.time], tuple[float, int]], conv: str,
        piqueuxEtAl: bool = False, corr: bool = False, giveMUT: bool = False, giveLTST: bool = False,
        planeto_longitude: float = 0, degree_west: bool = True) -> Union[
    list, datetime.datetime, np.float64, tuple[float, float, datetime.time], tuple[float, int]]:
    """
    Universal date conversion function. For one date or a list of dates.
    :param inputTime: Input date or list of input dates to convert.
    :param conv: Type de conversion : String representing the detected output date(s) : 'ed_dt' for Earth dates in datetime.datetime format,
    'ed_jd' for Earth dates expressed in julian days (TT), 'tropical' for tropical dates, 'solcal' for a SolCal and 'solcal_m' for a SolCal dates with month.
    date.
    :param piqueuxEtAl: If True uses the Ls calculation method from Piqueux et al. (2015) else uses the one from
    the Mars24 Sunclock algorithm.
    :param corr: If True in the case of a SolCal output, gives the corrected SolCal date.
    :param giveMUT: If True and if the desired output is not a SolCal date, gives the MUT along with the output.
    :param giveLTST: If True, gives the LTST along with the output.
    :param planeto_longitude: Planetographic longitude, in degree west or east depending on the value of
    degree_west.
    :param degree_west: Indicates whether planeto_longitude is in degree west or not.
    :return: Converted date or list of converted dates.
    """
    # conv value checking :
    if conv not in {"ed_dt", "ed_jd", "tropical", "solcal", "solcal_m"}:
        raise ValueError("Unknown conversion.")

    # Input type information recovery :
    inputType = __analyse_input(inputTime)
    if inputType is None and not isinstance(inputTime, list):
        raise ValueError("Unknown input type.")

    # Case of a list of dates :
    if isinstance(inputTime, list):
        # If the list is empty :
        if len(inputTime) == 0:
            return []
        else:
            # Elements type and homogeneity in the list :
            typeFirstInput = __analyse_input(inputTime[0])
            for date in inputTime:
                elemType = __analyse_input(date)
                if elemType is None:
                    raise ValueError(f"Unknown input type {type(elemType)}")
                if elemType != typeFirstInput:
                    raise Exception("All dates in the list must be from the same calendar")

            # Conversion of the date in the list :
            res = []
            for date in inputTime:
                res.append(__calendarConversionUnit(date, conv, piqueuxEtAl, corr, giveMUT, giveLTST, planeto_longitude,
                                                    degree_west))
            return res
    # Case of a single date :
    else:
        return __calendarConversionUnit(inputTime, conv, piqueuxEtAl, corr, giveMUT, giveLTST, planeto_longitude,
                                        degree_west)


# Functions to generate random dates ###################################################################################

def random_SC_dates(n: int, beginMY: int, endMY: int, withMonth: bool = False) -> list:
    """
    Generates a list of n random SolCal dates between MY beginMY and MY endMY included.
    :param n: Number of dates to generate.
    :param beginMY: non-zero integer.
    :param endMY: non-zero integer.
    :param withMonth: If true, returns SoCal dates with Martian months. If False, returns typical SolCal dates.
    :return: list of n SolCal dates.
    """
    listRandSCDates = []

    while len(listRandSCDates) < n:

        # Random MY :
        randMY = 0
        while randMY == 0:
            randMY = random.randint(beginMY, endMY)

        # Number of sols in the randMY :
        randSOY = random.randint(1, [669, 668, 669, 668, 669][id(randMY) - 1])

        # Random MUT:
        randMicroSec = random.randint(0, 24 * 60 * 60 * 1000000)
        randHour, randMicroSec = divmod(randMicroSec, 60 * 60 * 1000000)
        randMin, randMicroSec = divmod(randMicroSec, 60 * 1000000)
        randSec, randMicroSec = divmod(randMicroSec, 1000000)

        randMUT = datetime.time(randHour, randMin, randSec, randMicroSec)

        listRandSCDates.append(
            conv_SC_to_SCmonth((randMY, randSOY, randMUT)) if withMonth else (randMY, randSOY, randMUT))

    return listRandSCDates


def random_ED_dates(n: int, beginY: int, endY: int) -> list:
    """
    Generates a list of random Earth dates (UTC) in datetime format.
    :param n: Number of dates to generate.
    :param beginY: non-zero integer.
    :param endY: non-zero integer.
    :return: list of n Earth dates (UTC).
    """
    listRandED = []

    while len(listRandED) < n:

        # Random year :
        randY = 0
        while randY == 0:
            randY = random.randint(beginY, endY)

        # Random month :
        randMonth = random.randint(1, 12)

        # Random day :
        randDay = random.randint(1,
                                 [31, [28, 29][(randY % 4 == 0 and randY % 100 != 0) or randY % 400 == 0], 31, 30, 31,
                                  30, 31, 31, 30, 31, 30, 31][randMonth - 1])

        # Random hour in the day :
        randMicroSec = random.randint(0, 24 * 60 * 60 * 1000000)
        randHour, randMicroSec = divmod(randMicroSec, 60 * 60 * 1000000)
        randMin, randMicroSec = divmod(randMicroSec, 60 * 1000000)
        randSec, randMicroSec = divmod(randMicroSec, 1000000)

        listRandED.append(datetime.datetime(randY, randMonth, randDay, randHour, randMin, randSec, randMicroSec))
    return listRandED


def random_trop_dates(n: int, beginMY: int, endMY: int, pres: Union[int, list[int]] = 15) -> list:
    """
    Generates a list of random Martian tropical dates between MY beginMY and MY endMY included.
    With pres decimal significant digits for all the random dates or a list of decimal significant digits for each of the
    random dates.
    places (significant decimal digits) for the Ls.
    :param n: Number of dates to generate.
    :param beginMY: Non-zero integer.
    :param endMY: Non-zero integer.
    :param pres: Positive integer or list of positive integers, number of significant decimal digits
    :return: List of random tropical dates.
    """

    # Check if precision in list format
    listPres = isinstance(pres, list)

    # If precision in list format : check the length
    if listPres and len(pres) != n:
        raise ValueError("List of significant digits pres must be at the same size as the date list output n")

    # Iterator for list precision :
    i = 0

    listTrop = []

    while len(listTrop) < n:
        randMY = 0
        while randMY == 0:
            randMY = random.randint(beginMY, endMY)

            Ls = random.random() * 360

            if listPres:
                Ls = round(Ls, pres[i])
                i += 1
            else:
                Ls = round(Ls, pres)

            listTrop.append((Ls, randMY))
    return listTrop
