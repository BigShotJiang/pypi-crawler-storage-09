"""
Formulas from Piqueux et al. (2015).
For more information see the References at the top of the SolCalTimeConversion.py file.
"""

import astropy.time
import numpy as np


def jd_tt_to_julian_centuries(jd_tt: float, fromJ2000: bool = True) -> float:
    """
    Convert a julian date to julian century from epoch J2000.
    :param jd_tt: julian date from epoch J2000 or not depending on the fromJ2000 flag.
    :param fromJ2000: True if the input julian date (TT) is the number of days since epoch J2000. False if not.
    :return: Julian century from epoch J2000.
    """
    if fromJ2000:
        return jd_tt / 36525.0
    else:
        jd_tt_J2000 = astropy.time.Time('2000-01-01T12:00:00', scale='tt').jd
        return (jd_tt - jd_tt_J2000) / 36525.0


def linear_rate_angle(t: float, T: float) -> float:
    """
    Calculate the linear-rate angle based on the tropical year similar to the right ascension of the FMS in the Mars24
    Sunclock algorithm.
    :param t: Ephemeris time from J2000.0 in days.
    :param T: Julian centuries from epoch J2000.
    :return: Mars's linear rate angle in degrees.
    """
    return 270.389001822 + 0.52403850205 * t - 0.000565452 * (T ** 2)


def mean_anomaly(t: float) -> float:
    """
    Calculate Mars's mean anomaly.
    :param t: Ephemeris time from J2000.0 in days.
    :return: Mars's mean anomaly in radians.
    """
    return 19.38028331517 + 0.52402076345 * t


def eccentricity(T: float) -> float:
    """
    Calculate Mars's orbit eccentricity.
    :param T: Julian centuries from epoch J2000.
    :return: Mars's eccentricity in radians.
    """
    return 0.093402202 + 0.000091406 * T


def equation_of_center(e: float, M: float) -> float:
    """
    Calculate Mars's equation of center from its eccentricity and mean anomaly.
    :param e: Mars's orbit eccentricity.
    :param M: Mars's mean anomaly.
    :return: Equation of center, true anomaly minus the mean anomaly. In radians.
    """
    coef1 = 2 * e - (e ** 3 / 4) + 5 * (e ** 5 / 96)
    coef2 = 5 * (e ** 2 / 4) - 11 * (e ** 4 / 24) + 17 * (e ** 6 / 192)
    coef3 = 13 * (e ** 3 / 12) - 43 * (e ** 5 / 64)
    coef4 = 103 * (e ** 4 / 96) - 451 * (e ** 6 / 480)
    coef5 = 1097 * (e ** 5 / 960)
    coef6 = 1223 * (e ** 5 / 960)

    # Mean anomaly radian conversion :
    M = np.radians(M)

    return coef1 * np.sin(M) + coef2 * np.sin(2 * M) + coef3 * np.sin(3 * M) + coef4 * np.sin(4 * M) + coef5 * np.sin(
        5 * M) + coef6 * np.sin(6 * M)


# Planetary perturbations :
tau = [816.3755210, 1005.8002614, 408.1877605, 5765.3098103, 779.9286472, 901.9431281, 11980.9332471, 2882.1147,
       4332.2204, 373.07883, 1069.3231, 343.49194, 1309.9410, 450.69255, 256.06036, 228.99145]

A = np.array(
    [7.0591, 6.0890, 4.4462, 3.8947, 2.4328, 2.0400, 1.7746, 1.34607, 1.03438, 0.88180, 0.72350, 0.65555, 0.81460,
     0.74578, 0.58359, 0.42864]) / 1000

phi = [48.48944, 167.55418, 188.35480, 19.97295, 12.03224, 95.98253, 49.00256, 288.7737, 37.9378, 65.3160, 175.4911,
       98.8644, 186.2253, 202.9323, 212.1853, 32.1227]


def perturbations(t: float) -> float:
    """
    Determine the angular perturbations by other planets.
    :param t: Ephemeris time from J2000.0 in days.
    :return: Perturbations, in degrees
    """
    sum = 0
    for A_i, tau_i, phi_i in zip(A, tau, phi):
        sum += A_i * np.cos(2 * np.pi * t / tau_i + np.pi * phi_i / 180)
    return sum


def solar_longitude(alpha: float, delta: float, PPs: float) -> float:
    """
    Areocentric solar longitude calculation.
    :param alpha: Mars's linear rate angle
    :param delta: Mars's equation of center
    :param PPs: Perturbations by other planets.
    :return: Areocentric solar longitude in degrees.
    """
    return alpha + (180 / np.pi) * delta + PPs


def Ls_function(delta_t_J2000: float) -> float:
    """
    Calculate the areocentric solar longitude from the number of julian days since epoch J2000.
    :param delta_t_J2000: Number of days since epoch J2000.
    :return: Areocentric solar longitude, in degrees.
    """
    T = jd_tt_to_julian_centuries(delta_t_J2000)
    t = delta_t_J2000
    alpha = linear_rate_angle(t, T)
    M = mean_anomaly(t)
    e = eccentricity(T)
    delta = equation_of_center(e, M)
    PPs = perturbations(t)
    return solar_longitude(alpha, delta, PPs)
