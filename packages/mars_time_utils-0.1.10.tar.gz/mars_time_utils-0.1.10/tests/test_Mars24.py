"""
Unit tests for Mars24.py
"""
import pytest
import numpy as np
from mars_time_utils.Mars24 import (
    get_mars_mean_anomaly,
    get_angle_FMS,
    get_PBS,
    get_EoC,
    get_EoT,
    get_MST,
    get_LMST,
    get_LTST
)


class TestMarsOrbitalFunctions:
    """Tests for Mars orbital functions"""
    
    def test_get_mars_mean_anomaly_at_J2000(self):
        """Test mean anomaly at J2000 epoch"""
        result = get_mars_mean_anomaly(0.0)
        assert result == pytest.approx(19.3871, rel=1e-6)
    
    def test_get_mars_mean_anomaly_positive_time(self):
        """Test with positive time"""
        result = get_mars_mean_anomaly(100.0)
        expected = 19.3871 + 0.52402073 * 100.0
        assert result == pytest.approx(expected, rel=1e-6)
    
    def test_get_mars_mean_anomaly_increases(self):
        """Test that anomaly increases with time"""
        result1 = get_mars_mean_anomaly(0.0)
        result2 = get_mars_mean_anomaly(100.0)
        assert result2 > result1
    
    def test_get_angle_FMS_at_J2000(self):
        """Test fictitious mean Sun angle at J2000"""
        result = get_angle_FMS(0.0)
        assert result == pytest.approx(270.3871, rel=1e-6)
    
    def test_get_angle_FMS_positive_time(self):
        """Test with positive time"""
        result = get_angle_FMS(100.0)
        expected = 270.3871 + 0.524038496 * 100.0
        assert result == pytest.approx(expected, rel=1e-6)


class TestPerturbations:
    """Tests for planetary perturbations"""
    
    def test_get_PBS_at_zero(self):
        """Test PBS at t=0"""
        result = get_PBS(0.0)
        assert isinstance(result, (float, np.floating))
        assert -1 < result < 1
    
    def test_get_PBS_range(self):
        """Test that PBS stays in a reasonable range"""
        for t in [0, 100, 1000]:
            result = get_PBS(t)
            assert abs(result) < 0.05  # PBS is generally small


class TestEquationOfCenter:
    """Tests for the equation of center"""
    
    def test_get_EoC_returns_float(self):
        """Test that EoC returns a number"""
        result = get_EoC(0.0, 19.3871, 0.0)
        assert isinstance(result, (float, np.floating))
    
    def test_get_EoC_with_realistic_values(self):
        """Test with realistic values"""
        t = 1000.0
        M = get_mars_mean_anomaly(t)
        PBS = get_PBS(t)
        result = get_EoC(t, M, PBS)
        assert isinstance(result, (float, np.floating))


class TestEquationOfTime:
    """Tests for the equation of time"""
    
    def test_get_EoT_returns_float(self):
        """Test that EoT returns a number"""
        result = get_EoT(0.0, 0.0)
        assert isinstance(result, (float, np.floating))
    
    def test_get_EoT_range(self):
        """Test that EoT stays in a reasonable range"""
        for Ls in [0, 90, 180, 270]:
            result = get_EoT(Ls, 0.0)
            assert abs(result) < 100  # EoT in degrees


class TestSolarTime:
    """Tests for Martian solar time"""
    
    def test_get_MST_returns_valid_hours(self):
        """Test that MST returns valid hours"""
        jd_tt = 2451545.0  # Approximately J2000
        result = get_MST(jd_tt)
        assert 0 <= result < 24
    
    def test_get_MST_different_times(self):
        """Test MST at different times"""
        jd1 = 2451545.0
        jd2 = 2451546.0  # One day later
        result1 = get_MST(jd1)
        result2 = get_MST(jd2)
        assert result1 != result2
    
    def test_get_LMST_at_prime_meridian(self):
        """Test LMST at the prime meridian"""
        MST = 12.0
        result = get_LMST(MST, 0.0)
        assert result == pytest.approx(12.0, rel=1e-6)
    
    def test_get_LMST_west_longitude(self):
        """Test LMST with west longitude"""
        MST = 12.0
        longitude = 15.0  # 15° west
        result = get_LMST(MST, longitude)
        expected = (12.0 - 1.0) % 24  # 1 hour offset
        assert result == pytest.approx(expected, rel=1e-6)
    
    def test_get_LMST_range(self):
        """Test that LMST stays in [0, 24)"""
        for lon in [0, 90, 180, 270]:
            result = get_LMST(12.0, lon)
            assert 0 <= result < 24
    
    def test_get_LTST_no_correction(self):
        """Test LTST without equation of time"""
        LMST = 12.0
        result = get_LTST(LMST, 0.0)
        assert result == pytest.approx(12.0, rel=1e-6)
    
    def test_get_LTST_with_EoT(self):
        """Test LTST with equation of time"""
        LMST = 12.0
        EoT = 15.0  # 15° equation of time
        result = get_LTST(LMST, EoT)
        expected = 12.0 + 15.0 * (1/15)  # 1° = 1/15 hour
        assert result == pytest.approx(expected, rel=1e-6)
