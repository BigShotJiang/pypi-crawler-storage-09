"""
Unit tests for SolCalTimeConversion.py (complex file, partial tests)
"""
import pytest
import datetime
import numpy as np
from mars_time_utils.SolCalTimeConversion import (
    id,
    delta_plus,
    delta_minus,
    datetime_utc_to_jd_tt,
    jd_tt_to_datetime_utc,
    nb_hours_to_time,
    time_to_nb_days,
    get_MMST_from_ED,
    get_MTST_from_ED
)


class TestIDFunction:
    """Tests for the id function"""
    
    def test_id_positive_MY(self):
        """Test id with positive MY"""
        assert id(1) == 1
        assert id(2) == 2
        assert id(5) == 5
        assert id(6) == 1  # Cycle restarts
    
    def test_id_negative_MY(self):
        """Test id with negative MY"""
        assert id(-1) == 5
        assert id(-5) == 1
        assert id(-6) == 5
    
    def test_id_cycle_pattern(self):
        """Test the cycle pattern"""
        for i in range(1, 11):
            result = id(i)
            assert 1 <= result <= 5


class TestDeltaFunctions:
    """Tests for delta_plus and delta_minus"""
    
    def test_delta_plus_same_MY(self):
        """Test delta_plus when DP == MY_SC"""
        result = delta_plus(10, 10)
        assert result == 0
    
    def test_delta_plus_positive_MYs(self):
        """Test delta_plus with positive MYs"""
        result = delta_plus(10, 5)
        assert result == 5
    
    def test_delta_plus_negative_DP(self):
        """Test delta_plus with negative DP"""
        result = delta_plus(5, -5)
        assert result > 0
    
    def test_delta_minus_positive_difference(self):
        """Test delta_minus with positive difference"""
        result = delta_minus(5, 10)
        assert result >= 0


class TestTimeConversions:
    """Tests for time conversions"""
    
    def test_datetime_utc_to_jd_tt_J2000(self):
        """Test conversion at J2000 epoch"""
        date = datetime.datetime(2000, 1, 1, 12, 0, 0)
        result = datetime_utc_to_jd_tt(date)
        # JD at J2000 is approximately 2451545
        assert 2451544 < result < 2451546
    
    def test_jd_tt_to_datetime_utc_roundtrip(self):
        """Test roundtrip conversion JD <-> datetime"""
        original_date = datetime.datetime(2025, 10, 22, 15, 0, 0)
        jd = datetime_utc_to_jd_tt(original_date)
        back_date = jd_tt_to_datetime_utc(jd)
        # Tolerance of a few seconds due to conversions
        assert abs((back_date - original_date).total_seconds()) < 10
    
    def test_nb_hours_to_time_midnight(self):
        """Test conversion of 0 hours"""
        result = nb_hours_to_time(0.0)
        assert result == datetime.time(0, 0, 0, 0)
    
    def test_nb_hours_to_time_noon(self):
        """Test conversion of 12 hours"""
        result = nb_hours_to_time(12.0)
        assert result == datetime.time(12, 0, 0, 0)
    
    def test_nb_hours_to_time_with_minutes(self):
        """Test with hours and minutes"""
        result = nb_hours_to_time(12.5)
        assert result == datetime.time(12, 30, 0, 0)
    
    def test_nb_hours_to_time_negative(self):
        """Test with negative value (should wrap around)"""
        result = nb_hours_to_time(-1.0)
        assert result == datetime.time(23, 0, 0, 0)
    
    def test_time_to_nb_days_midnight(self):
        """Test conversion of midnight"""
        result = time_to_nb_days(datetime.time(0, 0, 0))
        assert result == pytest.approx(0.0, abs=1e-9)
    
    def test_time_to_nb_days_noon(self):
        """Test conversion of noon"""
        result = time_to_nb_days(datetime.time(12, 0, 0))
        assert result == pytest.approx(0.5, rel=1e-6)
    
    def test_time_to_nb_days_full_day(self):
        """Test that 24h cannot be represented (max 23:59:59)"""
        result = time_to_nb_days(datetime.time(23, 59, 59))
        assert 0.999 < result < 1.0


class TestMartianSolarTime:
    """Tests for Martian solar time"""
    
    def test_get_MMST_from_ED_returns_time(self):
        """Test that MMST returns a datetime.time"""
        date = datetime.datetime(2025, 10, 22, 15, 0, 0)
        result = get_MMST_from_ED(date)
        assert isinstance(result, datetime.time)
    
    def test_get_MMST_from_ED_valid_range(self):
        """Test that MMST is in [0, 24) hours"""
        date = datetime.datetime(2025, 10, 22, 15, 0, 0)
        result = get_MMST_from_ED(date)
        total_seconds = result.hour * 3600 + result.minute * 60 + result.second
        assert 0 <= total_seconds < 24 * 3600
    
    def test_get_MTST_from_ED_returns_time(self):
        """Test that MTST returns a datetime.time"""
        date = datetime.datetime(2025, 10, 22, 15, 0, 0)
        result = get_MTST_from_ED(date)
        assert isinstance(result, datetime.time)
    
    def test_get_MTST_from_ED_different_from_MMST(self):
        """Test that MTST differs from MMST (equation of time)"""
        date = datetime.datetime(2025, 10, 22, 15, 0, 0)
        mmst = get_MMST_from_ED(date)
        mtst = get_MTST_from_ED(date)
        # MMST and MTST should generally differ
        # (except at specific times when EoT = 0)
        assert isinstance(mmst, datetime.time)
        assert isinstance(mtst, datetime.time)


class TestEdgeCases:
    """Tests for edge cases"""
    
    def test_nb_hours_to_time_boundary_24(self):
        """Test the 24-hour boundary"""
        result = nb_hours_to_time(24.0)
        assert result.hour == 0  # Should wrap to 0
    
    def test_nb_hours_to_time_large_value(self):
        """Test with a value > 24"""
        result = nb_hours_to_time(36.0)
        assert result.hour == 12  # 36 % 24 = 12
    
    @pytest.mark.parametrize("my_value", [1, 5, 10, -1, -5, -10])
    def test_id_various_values(self, my_value):
        """Test id with various values"""
        result = id(my_value)
        assert 1 <= result <= 5
