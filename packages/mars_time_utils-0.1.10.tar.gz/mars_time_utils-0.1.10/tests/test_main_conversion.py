"""
Unit tests for main_conversion.py
"""
import pytest
import datetime
import numpy as np
from mars_time_utils.main_conversion import (
    conv_SC_to_SCmonth,
    conv_SCmonth_to_SC,
    calendarConversion,
    random_SC_dates,
    random_ED_dates,
    random_trop_dates
)


class TestSolCalMonthConversions:
    """Tests for SolCal conversions with and without months"""
    
    def test_conv_SC_to_SCmonth_basic(self):
        """Test conversion from SolCal to SolCal with month"""
        # First sol of the first month
        result = conv_SC_to_SCmonth((1, 1, datetime.time(0, 0, 0)))
        assert result[0] == 1  # MY
        assert result[1] == 1  # month
        assert result[2] == 1  # sol
        assert result[3] == datetime.time(0, 0, 0)  # MUT
    
    def test_conv_SC_to_SCmonth_second_month(self):
        """Test conversion for the second month"""
        # Sol 57 should be the first sol of month 2
        result = conv_SC_to_SCmonth((1, 57, datetime.time(12, 0, 0)))
        assert result[0] == 1
        assert result[1] == 2  # second month
        assert result[2] == 1  # first sol of the month
    
    def test_conv_SCmonth_to_SC_basic(self):
        """Test conversion from SolCal with month to SolCal"""
        result = conv_SCmonth_to_SC((1, 1, 1, datetime.time(0, 0, 0)))
        assert result[0] == 1  # MY
        assert result[1] == 1  # SOY
        assert result[2] == datetime.time(0, 0, 0)  # MUT
    
    def test_conv_SCmonth_to_SC_second_month(self):
        """Test conversion from the second month"""
        result = conv_SCmonth_to_SC((1, 2, 1, datetime.time(12, 0, 0)))
        assert result[0] == 1
        assert result[1] == 57  # 56 sols from first month + 1
        assert result[2] == datetime.time(12, 0, 0)
    
    def test_roundtrip_conversion(self):
        """Test roundtrip conversion"""
        original = (1, 100, datetime.time(10, 30, 45))
        with_month = conv_SC_to_SCmonth(original)
        back = conv_SCmonth_to_SC(with_month)
        assert back == original


class TestCalendarConversion:
    """Tests for the universal conversion function"""
    
    def test_conversion_ed_dt_to_ed_jd(self):
        """Test conversion from datetime to julian date"""
        date_utc = datetime.datetime(2000, 1, 1, 12, 0, 0)
        result = calendarConversion(date_utc, conv="ed_jd")
        assert isinstance(result, (float, np.float64))
        assert result > 0
    
    def test_conversion_ed_dt_to_tropical(self):
        """Test conversion from datetime to tropical date"""
        date_utc = datetime.datetime(2000, 1, 1, 12, 0, 0)
        result = calendarConversion(date_utc, conv="tropical")
        assert isinstance(result, tuple)
        assert len(result) == 2
        assert 0 <= result[0] < 360  # Ls between 0 and 360
        assert isinstance(result[1], (int, float))  # tropical MY
    
    def test_conversion_ed_dt_to_solcal(self):
        """Test conversion from datetime to SolCal"""
        date_utc = datetime.datetime(2000, 1, 1, 12, 0, 0)
        result = calendarConversion(date_utc, conv="solcal")
        assert isinstance(result, tuple)
        assert len(result) == 3
        assert isinstance(result[0], int)  # MY_SC
        assert isinstance(result[1], int)  # SOY_SC
        assert isinstance(result[2], datetime.time)  # MUT
    
    def test_conversion_with_list_input(self):
        """Test conversion with a list of dates"""
        dates = [
            datetime.datetime(2000, 1, 1, 12, 0, 0),
            datetime.datetime(2001, 1, 1, 12, 0, 0)
        ]
        result = calendarConversion(dates, conv="ed_jd")
        assert isinstance(result, list)
        assert len(result) == 2
        assert all(isinstance(r, (float, np.float64)) for r in result)
    
    def test_conversion_empty_list(self):
        """Test conversion of an empty list"""
        result = calendarConversion([], conv="ed_jd")
        assert result == []
    
    def test_conversion_unknown_type_raises_error(self):
        """Test that unknown type raises an error"""
        with pytest.raises(ValueError, match="Unknown conversion"):
            calendarConversion(datetime.datetime.now(), conv="invalid_type")
    
    def test_conversion_same_input_output(self):
        """Test that identical conversion returns the input"""
        date = datetime.datetime(2000, 1, 1, 12, 0, 0)
        result = calendarConversion(date, conv="ed_dt")
        assert result == date


class TestRandomDateGenerators:
    """Tests for random date generators"""
    
    def test_random_SC_dates_count(self):
        """Test that the correct number of dates is generated"""
        dates = random_SC_dates(10, 1, 5)
        assert len(dates) == 10
    
    def test_random_SC_dates_structure(self):
        """Test the structure of generated SolCal dates"""
        dates = random_SC_dates(5, 1, 5)
        for date in dates:
            assert isinstance(date, tuple)
            assert len(date) == 3
            assert isinstance(date[0], int)  # MY
            assert isinstance(date[1], int)  # SOY
            assert isinstance(date[2], datetime.time)  # MUT
    
    def test_random_SC_dates_with_month(self):
        """Test generation with Martian months"""
        dates = random_SC_dates(5, 1, 5, withMonth=True)
        for date in dates:
            assert len(date) == 4
            assert 1 <= date[1] <= 12  # month between 1 and 12
    
    def test_random_ED_dates_count(self):
        """Test that the correct number of Earth dates is generated"""
        dates = random_ED_dates(10, 2000, 2010)
        assert len(dates) == 10
    
    def test_random_ED_dates_structure(self):
        """Test the structure of Earth dates"""
        dates = random_ED_dates(5, 2000, 2010)
        for date in dates:
            assert isinstance(date, datetime.datetime)
            assert 2000 <= date.year <= 2010
    
    def test_random_trop_dates_count(self):
        """Test generation of tropical dates"""
        dates = random_trop_dates(10, 1, 5)
        assert len(dates) == 10
    
    def test_random_trop_dates_structure(self):
        """Test the structure of tropical dates"""
        dates = random_trop_dates(5, 1, 5)
        for date in dates:
            assert isinstance(date, tuple)
            assert len(date) == 2
            assert 0 <= date[0] <= 360  # Ls
            assert isinstance(date[1], int)  # tropical MY
    
    def test_random_trop_dates_precision(self):
        """Test Ls precision"""
        dates = random_trop_dates(5, 1, 5, pres=2)
        for date in dates:
            # Check that Ls has at most 2 decimal places
            ls_str = str(date[0])
            if '.' in ls_str:
                decimals = len(ls_str.split('.')[1])
                assert decimals <= 2
    
    def test_random_trop_dates_precision_list_wrong_size(self):
        """Test that an error is raised if precision list is wrong size"""
        with pytest.raises(ValueError, match="same size"):
            random_trop_dates(5, 1, 5, pres=[1, 2])
