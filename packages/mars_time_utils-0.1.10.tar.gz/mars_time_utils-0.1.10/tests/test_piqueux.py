"""
Unit tests for piqueux.py
"""
import pytest
import numpy as np
from mars_time_utils.piqueux import (
    jd_tt_to_julian_centuries,
    linear_rate_angle,
    mean_anomaly,
    eccentricity,
    equation_of_center,
    perturbations,
    solar_longitude,
    Ls_function
)


class TestJulianConversions:
    """Tests for julian date conversions"""
    
    def test_jd_tt_to_julian_centuries_from_J2000(self):
        """Test conversion to julian centuries from J2000"""
        result = jd_tt_to_julian_centuries(36525.0, fromJ2000=True)
        assert result == pytest.approx(1.0, rel=1e-6)
    
    def test_jd_tt_to_julian_centuries_zero(self):
        """Test with J2000 date"""
        result = jd_tt_to_julian_centuries(0.0, fromJ2000=True)
        assert result == pytest.approx(0.0, rel=1e-6)
    
    def test_jd_tt_to_julian_centuries_not_from_J2000(self):
        """Test conversion without J2000 reference"""
        # JD of J2000 is approximately 2451545.0
        jd_j2000 = 2451545.0
        result = jd_tt_to_julian_centuries(jd_j2000, fromJ2000=False)
        assert result == pytest.approx(0.0, rel=1e-3)


class TestMarsOrbitalParameters:
    """Tests for Mars orbital parameters"""
    
    def test_linear_rate_angle_at_zero(self):
        """Test angle at t=0"""
        result = linear_rate_angle(0.0, 0.0)
        assert result == pytest.approx(270.389001822, rel=1e-6)
    
    def test_linear_rate_angle_positive_time(self):
        """Test with positive time"""
        result = linear_rate_angle(100.0, 0.0)
        assert isinstance(result, float)
        assert result > 270
    
    def test_mean_anomaly_at_zero(self):
        """Test mean anomaly at t=0"""
        result = mean_anomaly(0.0)
        assert result == pytest.approx(19.38028331517, rel=1e-6)
    
    def test_mean_anomaly_increases_with_time(self):
        """Test that mean anomaly increases with time"""
        result1 = mean_anomaly(0.0)
        result2 = mean_anomaly(100.0)
        assert result2 > result1
    
    def test_eccentricity_at_zero(self):
        """Test eccentricity at T=0"""
        result = eccentricity(0.0)
        assert result == pytest.approx(0.093402202, rel=1e-6)
    
    def test_eccentricity_range(self):
        """Test that eccentricity stays in a reasonable range"""
        for T in [0, 1, 10]:
            result = eccentricity(T)
            assert 0 < result < 0.2  # Eccentricity must be positive and < 0.2


class TestEquationOfCenter:
    """Tests for the equation of center"""
    
    def test_equation_of_center_returns_float(self):
        """Test that the function returns a float"""
        e = 0.093
        M = 45.0
        result = equation_of_center(e, M)
        assert isinstance(result, (float, np.floating))
    
    def test_equation_of_center_zero_eccentricity(self):
        """Test with zero eccentricity"""
        result = equation_of_center(0.0, 45.0)
        assert result == pytest.approx(0.0, abs=1e-6)
    
    def test_equation_of_center_realistic_values(self):
        """Test with realistic values"""
        e = 0.093
        M = 180.0
        result = equation_of_center(e, M)
        assert isinstance(result, (float, np.floating))


class TestPerturbations:
    """Tests for planetary perturbations"""
    
    def test_perturbations_at_zero(self):
        """Test perturbations at t=0"""
        result = perturbations(0.0)
        assert isinstance(result, float)
    
    def test_perturbations_range(self):
        """Test that perturbations stay in a reasonable range"""
        for t in [0, 100, 1000, 10000]:
            result = perturbations(t)
            assert -1 < result < 1  # Perturbations are in degrees
    
    def test_perturbations_periodic(self):
        """Test that perturbations are periodic (approximate)"""
        result1 = perturbations(0.0)
        result2 = perturbations(10000.0)
        # Values should be different but in the same order of magnitude
        assert abs(result1) < 1 and abs(result2) < 1


class TestSolarLongitude:
    """Tests for solar longitude"""
    
    def test_solar_longitude_basic(self):
        """Test basic Ls calculation"""
        alpha = 270.0
        delta = 10.0
        PPs = 0.5
        result = solar_longitude(alpha, delta, PPs)
        expected = alpha + (180 / np.pi) * delta + PPs
        assert result == pytest.approx(expected, rel=1e-6)
    
    def test_solar_longitude_zero_perturbations(self):
        """Test Ls without perturbations"""
        result = solar_longitude(270.0, 0.0, 0.0)
        assert result == pytest.approx(270.0, rel=1e-6)
    
    def test_Ls_function_at_zero(self):
        """Test Ls_function at t=0 (J2000 start)"""
        result = Ls_function(0.0)
        assert isinstance(result, float)
        assert 0 <= result % 360 < 360
    
    def test_Ls_function_range(self):
        """Test that Ls stays in a consistent range"""
        for delta_t in [0, 100, 686, 1372]:  # 686 days ≈ 1 Martian year
            result = Ls_function(delta_t)
            assert isinstance(result, float)
    
    def test_Ls_function_increases_with_time(self):
        """Test that Ls increases overall with time"""
        ls1 = Ls_function(0.0)
        ls2 = Ls_function(100.0)
        # Ls should have increased (modulo 360)
        assert ls2 != ls1
