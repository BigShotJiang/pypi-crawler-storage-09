"""
Mashrur Facebook Scrapper
A powerful Facebook scraper with intelligent scrolling optimization

Usage:
    from mashrur_facebook_scrapper import scrape_facebook_posts
    posts = scrape_facebook_posts(email, password, page_url, num_posts=5)
"""

__version__ = "1.0.0"
__author__ = "Mashrur Rahman"
__email__ = "mashrur950@gmail.com"

from .runner import scrape_facebook_posts

# Main export - only the simple function
__all__ = [
    'scrape_facebook_posts'
]