#!/usr/bin/env python3
"""
Facebook Scraper Runner
Simple interface to run the Facebook scraper with custom inputs
"""

from .scraper import FacebookScraper
import sys


def run_interactive_scraper():
    """Main function to run the scraper with user inputs"""

    # Get user inputs
    try:

        email = input("📧 Facebook Email: ").strip()
        if not email:
            return

        password = input("🔒 Facebook Password: ").strip()
        if not password:
            return

        page_url = input("🔗 Facebook Page/Profile URL: ").strip()
        if not page_url:
            return

        # Validate URL
        if not ("facebook.com" in page_url and ("http://" in page_url or "https://" in page_url)):
            return

        while True:
            try:
                num_posts = int(input("📊 Number of posts to fetch: ").strip())
                if num_posts <= 0:
                    continue
                break
            except ValueError:
                pass

        # Initialize scraper
        scraper = FacebookScraper(email, password)

        # Run scraping process
        scraper.initialize_driver()
        scraper.login()
        scraper.navigate_to_profile(page_url)

        # Scrape posts
        posts_data = scraper.scrape_posts_graphql(num_posts=num_posts, output_filename=output_filename)

        # Display results
        if posts_data:
            scraper.print_posts(posts_data)

            # Save to timestamped file
            filename = scraper.save_to_json(posts_data)

        else:
            pass

    except KeyboardInterrupt:
        pass
    except Exception as e:
        import traceback
        traceback.print_exc()
    finally:
        # Clean up
        try:
            scraper.close()
        except:
            pass


def scrape_facebook_posts(email, password, page_url, num_posts=5, output_filename='graphql_organized_data.json'):
    """
    Programmatic function to scrape Facebook posts

    Args:
        email (str): Facebook email
        password (str): Facebook password
        page_url (str): Facebook page/profile URL
        num_posts (int): Number of posts to fetch
        output_filename (str): Custom filename for JSON output (default: 'graphql_organized_data.json')

    Returns:
        list: List of scraped posts
    """
    scraper = None
    try:
        # Initialize scraper
        scraper = FacebookScraper(email, password)

        # Run scraping process
        scraper.initialize_driver()
        scraper.login()
        scraper.navigate_to_profile(page_url)

        # Scrape posts
        posts_data = scraper.scrape_posts_graphql(num_posts=num_posts, output_filename=output_filename)

        return posts_data

    except Exception as e:
        raise
    finally:
        # Clean up
        if scraper:
            try:
                scraper.close()
            except:
                pass


if __name__ == "__main__":
    run_interactive_scraper()