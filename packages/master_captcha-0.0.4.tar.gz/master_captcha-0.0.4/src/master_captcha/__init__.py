from master_captcha.master_captcha import CaptchaManager

__author__ = "Limby"
__email__ = "bogo44tor@gmail.com"

__all__ = [
    "CaptchaManager",
]