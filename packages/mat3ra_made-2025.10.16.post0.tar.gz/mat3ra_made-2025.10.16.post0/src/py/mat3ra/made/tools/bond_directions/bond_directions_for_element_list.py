from typing import List

from ...bond_directions.bond_directions_templates_for_element import BondDirectionsTemplatesForElement


class BondDirectionsForElementList(List[BondDirectionsTemplatesForElement]):
    pass
