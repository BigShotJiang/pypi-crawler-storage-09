
class MCCLIException(BaseException):
    pass

class MissingRemoteException(BaseException):
    pass

class MultipleRemoteException(BaseException):
    pass

class NoDefaultRemoteException(BaseException):
    pass
