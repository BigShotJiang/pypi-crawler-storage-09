MatInverse is a code for multiphysics Topology optimization written in JAX

To install:

```bash

  pip install matinverse

```
