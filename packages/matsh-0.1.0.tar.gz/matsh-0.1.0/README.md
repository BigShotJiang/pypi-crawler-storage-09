# Matsh Library

Простая библиотека для работы с DeepSeek через OpenRouter.

## Установка

```bash
pip install matsh