max\_ble\_hci.ble\_hci
======================

.. automodule:: max_ble_hci.ble_hci
    :members:
    :undoc-members:
    :show-inheritance: