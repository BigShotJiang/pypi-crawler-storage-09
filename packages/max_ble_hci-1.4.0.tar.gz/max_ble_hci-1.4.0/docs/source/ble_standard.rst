max\_ble\_hci.ble\_standard\_cmds
=================================

.. automodule:: max_ble_hci.ble_standard_cmds
    :members:
    :undoc-members:
    :show-inheritance: