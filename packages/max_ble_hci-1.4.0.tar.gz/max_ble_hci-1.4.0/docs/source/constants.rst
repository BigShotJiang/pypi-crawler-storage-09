max\_ble\_hci.constants
=======================

.. automodule:: max_ble_hci.constants
    :members:
    :undoc-members:
    :show-inheritance: