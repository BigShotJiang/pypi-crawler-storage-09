max\_ble\_hci.data\_params
==========================

.. automodule:: max_ble_hci.data_params
    :members:
    :undoc-members:
    :show-inheritance: