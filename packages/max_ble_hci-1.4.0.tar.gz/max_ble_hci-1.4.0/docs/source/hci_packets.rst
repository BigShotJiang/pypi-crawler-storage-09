max\_ble\_hci.hci\_packets
==========================

.. automodule:: max_ble_hci.hci_packets
    :members:
    :undoc-members:
    :show-inheritance: