.. MAX BLE HCI documentation master file, created by
   sphinx-quickstart on Thu Jan 11 17:10:54 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to the MAX BLE HCI documentation!
=========================================

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   overview
   installation
   examples
   modules
   hci_reference


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
