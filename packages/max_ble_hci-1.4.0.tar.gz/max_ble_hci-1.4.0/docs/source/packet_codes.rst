max\_ble\_hci.packet\_codes
===========================

.. automodule:: max_ble_hci.packet_codes
    :members:
    :undoc-members:
    :show-inheritance: