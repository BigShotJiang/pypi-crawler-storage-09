max\_ble\_hci.packet\_defs
==========================

.. automodule:: max_ble_hci.packet_defs
    :members:
    :undoc-members:
    :show-inheritance: