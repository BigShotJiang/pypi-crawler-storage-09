max\_ble\_hci.utils
===================

.. automodule:: max_ble_hci.utils
    :members:
    :undoc-members:
    :show-inheritance: