max\_ble\_hci.vendor\_spec\_cmds
================================

.. automodule:: max_ble_hci.vendor_spec_cmds
    :members:
    :undoc-members:
    :show-inheritance: