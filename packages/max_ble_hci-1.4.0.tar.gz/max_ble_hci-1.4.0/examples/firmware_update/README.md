# Description

This is an example to show how to update the firmware through HCI script. The detailed instruction for how to run the example is in `msdk/BLE_HCI_DFU` repository. 

`firmware_update.py` shows how to update the firmware using script. 

hello_world.bin is a program which will print the following result: 
```
Second Application: Hello World!
```
