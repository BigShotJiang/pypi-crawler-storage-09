# Copyright (c) 2024 Analog Devices, Inc.
# SPDX-License-Identifier: Apache-2.0
"""
The package `utils` contails HCI packet decoding utilities, including
HCI-specific type definitions and packet parameter structures.

"""
