"""
Shared utility code.
"""
