from rich.console import Console

CONSOLE = Console()  # TODO: Rich width for slides should be 72
