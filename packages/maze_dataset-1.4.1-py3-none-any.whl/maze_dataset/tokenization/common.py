"common code for various tokenizers"


class TokenError(ValueError):
	"""error for tokenization"""

	pass
