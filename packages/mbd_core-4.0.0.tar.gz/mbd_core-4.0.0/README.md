# Introduction

This repository defines mbd unified data schema such that all the data sources from different protocols can be merged/combined into a same data schema. 
- items
- users
- interactions
