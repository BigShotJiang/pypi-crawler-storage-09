"""Top-level package for ."""

__author__ = """Yassine Landa"""
__email__ = "yl@mbd.xyz"
__version__ = "0.1.2"
