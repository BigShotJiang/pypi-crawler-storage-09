<a id="{id}" class="docs-object-method">&nbsp;</a> 
```python
{decorator}{name}{signature}: 
```
{include$:'includes/source_links.md'}
{description}
{include$:'includes/parameters.md'}