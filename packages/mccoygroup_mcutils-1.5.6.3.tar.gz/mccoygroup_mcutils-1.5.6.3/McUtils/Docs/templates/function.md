# <a id="{id}">{name}</a>


```python
{name}{signature}: 
```
{description}{parameters} 

{details}

{examples}{tests}