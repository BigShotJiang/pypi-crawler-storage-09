class Pack:
    def __init__(self, information: dict):
        self.information: dict = information
