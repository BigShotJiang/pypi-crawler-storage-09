TextLike = str | list | dict
