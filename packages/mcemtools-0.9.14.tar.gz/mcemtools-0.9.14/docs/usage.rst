=====
Usage
=====

To use mcemtools in a project::

    import mcemtools
