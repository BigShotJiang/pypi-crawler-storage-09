import click


@click.group(name="wakatime")
def wakatime():
    """WakaTime commands"""
    pass


if __name__ == "__main__":
    wakatime()
