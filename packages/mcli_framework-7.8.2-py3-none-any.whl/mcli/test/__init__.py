"""Test commands for mcli."""
