"""
Video processing commands for mcli.
"""

from .video import *
