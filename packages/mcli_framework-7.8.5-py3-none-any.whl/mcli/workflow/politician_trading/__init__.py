"""
Politician Trading Data Workflow
Tracks publicly available trading information for US and EU politicians
"""
