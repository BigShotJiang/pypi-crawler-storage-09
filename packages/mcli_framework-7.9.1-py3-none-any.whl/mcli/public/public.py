from mcli.lib.logger.logger import get_logger

logger = get_logger()
logger.info("Loading mcli.public.public.py")
