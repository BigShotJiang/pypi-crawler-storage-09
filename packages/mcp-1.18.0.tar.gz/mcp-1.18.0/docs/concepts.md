# Concepts

!!! warning "Under Construction"

    This page is currently being written. Check back soon for complete documentation.

<!--
  - Server vs Client
  - Three primitives (tools, resources, prompts)
  - Transports (stdio, SSE, streamable HTTP)
  - Context and sessions
  - Lifecycle and state
 -->
