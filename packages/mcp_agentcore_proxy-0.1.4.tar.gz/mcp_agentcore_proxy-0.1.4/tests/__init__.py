"""Unit tests for mcp-agentcore-proxy."""
