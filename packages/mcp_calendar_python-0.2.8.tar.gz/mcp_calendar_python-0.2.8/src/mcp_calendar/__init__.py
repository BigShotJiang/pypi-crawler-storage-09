"""MCP server for Google Calendar integration."""

from .server import main

__version__ = "0.2.8"
