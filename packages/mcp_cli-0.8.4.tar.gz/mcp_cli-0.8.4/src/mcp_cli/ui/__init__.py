# src/mcp_cli/ui/__init__.py
