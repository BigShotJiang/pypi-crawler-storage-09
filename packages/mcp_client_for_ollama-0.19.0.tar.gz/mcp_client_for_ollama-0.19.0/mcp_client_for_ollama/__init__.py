"""MCP Client for Ollama package."""

__version__ = "0.19.0"
