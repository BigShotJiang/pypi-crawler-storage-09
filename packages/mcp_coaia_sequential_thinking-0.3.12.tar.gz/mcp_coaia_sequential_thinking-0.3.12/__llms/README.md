# Various Guillaume's Isabelle LLMS

Gist URL: https://gist.github.com/jgwill/23adc41724854a151b7a9199daa7ffb5




