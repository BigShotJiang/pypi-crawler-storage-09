pie&>/dev/null;(cd ..;geminiflash )
