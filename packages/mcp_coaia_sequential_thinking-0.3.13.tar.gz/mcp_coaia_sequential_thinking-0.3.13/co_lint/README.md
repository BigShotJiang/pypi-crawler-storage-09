# CO-Lint

Creative Orientation Linter.

This tool validates repository documentation against a set of rules to enforce Creative Orientation governance.

## Integrations

- [Pre-commit Integration](./docs/pre-commit-integration.md)
- [GitHub Actions Integration](./docs/github-actions-integration.md)
