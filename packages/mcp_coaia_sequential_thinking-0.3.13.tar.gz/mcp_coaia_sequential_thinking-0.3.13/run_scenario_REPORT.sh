

gemini "use miadi to scan 'Workspace.miadisabelle.mcp-coaia-sequential-thinking:12:*report*' and observe all reports"


