"""Test utilities for MCP-NixOS tests."""

# This file intentionally left minimal as the refactored server
# doesn't need the complex test base classes from the old implementation
