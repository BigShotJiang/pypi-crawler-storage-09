import ClientFooter from './ClientFooter';

export default function Footer() {
  return <ClientFooter />;
}