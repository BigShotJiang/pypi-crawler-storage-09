"""
HTTP Transport Layer for MCP OpenProject Server

Provides HTTP transport support using fastapi_mcp library.
Minimal implementation that reuses existing stdio logic.
"""