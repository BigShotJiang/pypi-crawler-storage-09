# MCP Server Organized - Main Source Module
"""
Servidor MCP organizado con arquitectura modular.
Este módulo contiene todos los componentes del servidor MCP.
"""

__version__ = "1.0.0"
__author__ = "MCP RAG Team" 