def main():
    print("Hello from mcp-seniverse-weather!")


if __name__ == "__main__":
    main()
