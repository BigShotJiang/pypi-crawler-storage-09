from mcp_seniverse_weather import main
main()