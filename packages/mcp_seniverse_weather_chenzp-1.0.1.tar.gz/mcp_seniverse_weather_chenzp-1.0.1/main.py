def main():
    print("Hello from mcp-seniverse-weather-chenzp!")


if __name__ == "__main__":
    main()
