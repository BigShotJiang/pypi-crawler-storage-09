from mcp_seniverse_weather_chenzp import main
main()