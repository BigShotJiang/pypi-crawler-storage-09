# mcp-server-svn

[![PyPI version](https://badge.fury.io/py/mcp-server-svn.svg)](https://pypi.org/project/mcp-server-svn/)

An **MCP server integration for SVN**. This project exposes core Subversion (SVN) version control operations as MCP tools, enabling seamless automation and integration with the Model Context Protocol (MCP) framework.

## Features

- Status, diff, log, update, add, commit, and checkout for SVN repositories
- Branching operations: list, create, and delete branches/tags
- Integration via the [fastmcp](https://github.com/modelcontextprotocol/fastmcp) library as a first-class MCP server
- Easily connects SVN workflows to automated agent ecosystems

## Requirements

- Python >= 3.10
- Subversion (SVN) command-line client should be installed and available in PATH.

## Installation

```bash
pip install mcp-server-svn
```

## Usage

Start the server (available after install via entry point):

```bash
mcp-server-svn
```

The server will launch and register the following MCP tools:
- `svn_status`
- `svn_diff`
- `svn_commit`
- `svn_update`
- `svn_log`
- `svn_add`
- `svn_checkout`
- `svn_switch`
- `svn_list_branches`
- `svn_create_branch`
- `svn_delete_branch`

You can also run directly via Python:

```bash
python -m mcp_server_svn
```

## Development

- All code is PEP8-compliant and type-hinted.
- Contributions are welcome. Please open an issue for bugs/feature requests.

## Author

© Manav Desai ([manav27202@gmail.com](mailto:manav27202@gmail.com))
