# mcp-server-svn

[![PyPI version](https://badge.fury.io/py/mcp-server-svn.svg)](https://badge.fury.io/py/mcp-server-svn)
[![Python Versions](https://img.shields.io/pypi/pyversions/mcp-server-svn.svg)](https://pypi.org/project/mcp-server-svn/)


A modern [Model Context Protocol (MCP)](https://github.com/modelcontextprotocol/mcp) server for [SVN (Subversion)](https://subversion.apache.org/). Exposes core SVN operations as automated MCP tools for agent-driven workflows, seamless automation, and version control integration.

---

## Features

- Automates SVN repositories through the MCP agent and tool system
- Exposes high-level SVN commands (status, diff, log, update, add, commit, checkout, branch ops) as callables
- Compatible with [fastmcp](https://github.com/modelcontextprotocol/fastmcp)
- Python 3.10+ and modern build/packaging standards

---

## Installation

```bash
pip install mcp-server-svn
```

- Requires SVN (`svn` CLI) in your PATH.
- [fastmcp](https://github.com/modelcontextprotocol/fastmcp) installed automatically as a dependency.

---

## Supported MCP Tools

| Tool                | Description                             |
|---------------------|-----------------------------------------|
| `svn_status`        | Show working copy/repo status           |
| `svn_diff`          | Show working copy or revision differences|
| `svn_commit`        | Commit changes with a message           |
| `svn_update`        | Bring working copy up to date           |
| `svn_log`           | Show repository log entries             |
| `svn_add`           | Add files/directories to version control|
| `svn_checkout`      | Checkout a full SVN repo to disk        |
| `svn_switch`        | Switch working copy to branch/tag       |
| `svn_list_branches` | List branches/tags in the repo          |
| `svn_create_branch` | Create branch/tag from trunk            |
| `svn_delete_branch` | Delete branch/tag                       |

---

## Quickstart

Start the MCP server (after installation):

```bash
mcp-server-svn
```

Or using the Python module:

```bash
python -m mcp_server_svn
```



---

## Requirements

- Python 3.10+
- [fastmcp](https://github.com/modelcontextprotocol/fastmcp) (auto-installed)
- SVN command-line client (`svn`) installed and accessible from your PATH

---

## Usage with cline

To use `mcp-server-svn` as an MCP tool server in [cline](https://github.com/saoudrizwan/cline), add an entry to your cline configuration:

```json
"svn": {
  "autoApprove": [
    "svn_status",
    "svn_diff",
    "svn_update",
    "svn_log",
    "svn_add",
    "svn_checkout"
  ],
  "timeout": 30,
  "type": "stdio",
  "command": "/usr/bin/python3.11",
  "args": [
    "-m",
    "mcp_server_svn"
  ]
}
```

Adjust `"command"` as needed (e.g., `"python3"` or your virtualenv path). See the [cline documentation](https://github.com/saoudrizwan/cline) for details.

---

## Author

**Manav Desai**  
Email: [manav27202@gmail.com](mailto:manav27202@gmail.com)
