from .mcp_server_svn import main

if __name__ == "__main__":
    main()
