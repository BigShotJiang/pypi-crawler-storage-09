"""Whisper MCP server package."""

from .server import main

__version__ = "1.1.0"
__all__ = ["main"]
