"""Utility functions for MCP Server Whisper."""

from .text_utils import split_text_for_tts

__all__ = [
    "split_text_for_tts",
]
