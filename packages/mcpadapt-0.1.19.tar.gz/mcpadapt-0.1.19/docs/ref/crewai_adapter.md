# `CrewAI Adapter`

::: mcpadapt.crewai_adapter