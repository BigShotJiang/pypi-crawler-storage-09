# `Smolagents Adapter`

::: mcpadapt.smolagents_adapter
