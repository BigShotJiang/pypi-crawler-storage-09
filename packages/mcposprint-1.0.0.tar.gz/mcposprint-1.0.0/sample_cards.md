## Morning Routine
- *Get dressed
- Brush teeth
- Make coffee
- Check calendar

## Work Tasks
- *Review emails
- Update project status
- *Prepare for 2pm meeting
- Submit timesheet

## Evening Tasks
- Grocery shopping
- *Take medication
- Plan tomorrow
- Read for 30 minutes