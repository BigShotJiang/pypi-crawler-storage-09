"""md-hierarchy: Split and merge markdown files based on heading hierarchy."""

__version__ = "0.2.0"
