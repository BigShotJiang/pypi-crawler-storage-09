__all__ = [
    "DSSP",
    "assign",
    "translate",
]

from .dssp import DSSP, assign, translate
