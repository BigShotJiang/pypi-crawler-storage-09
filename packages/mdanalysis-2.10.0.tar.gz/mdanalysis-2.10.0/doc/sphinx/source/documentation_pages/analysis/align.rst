.. automodule:: MDAnalysis.analysis.align

