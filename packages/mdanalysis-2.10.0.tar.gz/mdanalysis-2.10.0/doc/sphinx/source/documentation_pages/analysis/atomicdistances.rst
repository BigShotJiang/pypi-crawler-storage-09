.. automodule:: MDAnalysis.analysis.atomicdistances
   :members:
