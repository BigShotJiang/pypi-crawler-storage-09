.. automodule:: MDAnalysis.analysis.base
   :members:
   :private-members:

