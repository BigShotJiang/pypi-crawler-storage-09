.. automodule:: MDAnalysis.analysis.contacts

