.. automodule:: MDAnalysis.analysis.data.filenames
   :members:
