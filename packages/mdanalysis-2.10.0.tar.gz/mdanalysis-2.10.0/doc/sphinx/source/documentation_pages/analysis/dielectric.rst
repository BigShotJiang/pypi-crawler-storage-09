.. automodule:: MDAnalysis.analysis.dielectric
   :members:

