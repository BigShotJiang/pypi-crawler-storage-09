.. automodule:: MDAnalysis.analysis.diffusionmap
