.. automodule:: MDAnalysis.analysis.encore.bootstrap
   :members:
