.. automodule:: MDAnalysis.analysis.encore.confdistmatrix
   :members:
