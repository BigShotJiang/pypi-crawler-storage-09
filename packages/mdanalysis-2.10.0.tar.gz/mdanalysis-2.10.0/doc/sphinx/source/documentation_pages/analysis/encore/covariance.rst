.. automodule:: MDAnalysis.analysis.encore.covariance
   :members:
