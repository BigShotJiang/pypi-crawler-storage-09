.. automodule:: MDAnalysis.analysis.encore.similarity
   :members:
