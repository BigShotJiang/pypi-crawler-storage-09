==============================
 Utility functions for ENCORE
==============================

.. deprecated:: 2.8.0
   This module is deprecated in favour of the 
   MDAKit `mdaencore <https://mdanalysis.org/mdaencore/>`_ and will be removed
   in MDAnalysis 3.0.0.

.. automodule:: MDAnalysis.analysis.encore.utils
   :members:

.. autofunction:: MDAnalysis.analysis.encore.cutils.PureRMSD
