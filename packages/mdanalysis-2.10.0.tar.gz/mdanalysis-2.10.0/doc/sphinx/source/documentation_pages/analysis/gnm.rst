.. automodule:: MDAnalysis.analysis.gnm
