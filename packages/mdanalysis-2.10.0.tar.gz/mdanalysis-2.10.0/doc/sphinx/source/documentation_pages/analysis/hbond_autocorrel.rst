.. automodule:: MDAnalysis.analysis.hydrogenbonds.hbond_autocorrel
