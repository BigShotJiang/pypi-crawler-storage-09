.. automodule:: MDAnalysis.analysis.hbonds.hbond_autocorrel
