.. automodule:: MDAnalysis.analysis.hydrogenbonds.hbond_analysis
