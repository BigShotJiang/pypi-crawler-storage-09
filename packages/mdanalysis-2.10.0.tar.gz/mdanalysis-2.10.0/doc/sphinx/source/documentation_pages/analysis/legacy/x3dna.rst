.. automodule:: MDAnalysis.analysis.legacy.x3dna
