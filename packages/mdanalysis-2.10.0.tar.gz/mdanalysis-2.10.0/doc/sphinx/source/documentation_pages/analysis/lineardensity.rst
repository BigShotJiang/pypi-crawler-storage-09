.. automodule:: MDAnalysis.analysis.lineardensity
   :members:

