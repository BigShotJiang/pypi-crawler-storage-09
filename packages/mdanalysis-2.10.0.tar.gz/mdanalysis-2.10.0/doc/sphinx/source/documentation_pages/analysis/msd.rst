.. automodule:: MDAnalysis.analysis.msd
