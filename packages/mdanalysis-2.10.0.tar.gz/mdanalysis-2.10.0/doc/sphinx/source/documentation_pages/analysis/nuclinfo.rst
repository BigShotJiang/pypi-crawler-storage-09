.. automodule:: MDAnalysis.analysis.nuclinfo

