.. automodule:: MDAnalysis.analysis.pca
