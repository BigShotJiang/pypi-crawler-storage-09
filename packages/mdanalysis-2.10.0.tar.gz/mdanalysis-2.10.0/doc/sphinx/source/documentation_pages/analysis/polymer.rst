.. automodule:: MDAnalysis.analysis.polymer
   :members:
   :inherited-members:
