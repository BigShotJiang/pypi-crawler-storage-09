.. automodule:: MDAnalysis.analysis.hydrogenbonds.wbridge_analysis
