.. automodule:: MDAnalysis.auxiliary.EDR
