.. automodule:: MDAnalysis.auxiliary.core

