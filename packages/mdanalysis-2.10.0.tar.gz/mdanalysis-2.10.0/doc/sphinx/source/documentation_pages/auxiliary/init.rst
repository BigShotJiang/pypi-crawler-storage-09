.. automodule:: MDAnalysis.auxiliary.__init__

