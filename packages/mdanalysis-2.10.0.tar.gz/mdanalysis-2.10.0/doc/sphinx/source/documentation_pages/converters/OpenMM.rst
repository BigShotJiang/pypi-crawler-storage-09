.. automodule:: MDAnalysis.converters.OpenMMParser

.. automodule:: MDAnalysis.converters.OpenMM
