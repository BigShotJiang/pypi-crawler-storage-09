.. automodule:: MDAnalysis.converters.ParmEdParser

.. automodule:: MDAnalysis.converters.ParmEd
