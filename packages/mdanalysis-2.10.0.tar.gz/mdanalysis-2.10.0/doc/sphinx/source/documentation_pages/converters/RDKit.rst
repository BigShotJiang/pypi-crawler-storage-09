.. automodule:: MDAnalysis.converters.RDKitParser

.. automodule:: MDAnalysis.converters.RDKit

.. automodule:: MDAnalysis.converters.RDKitInferring
