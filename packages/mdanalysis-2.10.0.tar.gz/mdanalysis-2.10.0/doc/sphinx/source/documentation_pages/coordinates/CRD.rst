.. automodule:: MDAnalysis.coordinates.CRD
   :members:
