.. automodule:: MDAnalysis.coordinates.DLPoly
   :members:
