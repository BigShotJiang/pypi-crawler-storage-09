.. automodule:: MDAnalysis.coordinates.DMS
   :members:
