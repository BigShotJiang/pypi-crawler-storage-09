.. automodule:: MDAnalysis.coordinates.FHIAIMS

