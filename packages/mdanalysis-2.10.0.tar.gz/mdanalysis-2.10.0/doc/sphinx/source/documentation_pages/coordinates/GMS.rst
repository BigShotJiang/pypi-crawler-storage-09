.. automodule:: MDAnalysis.coordinates.GMS

