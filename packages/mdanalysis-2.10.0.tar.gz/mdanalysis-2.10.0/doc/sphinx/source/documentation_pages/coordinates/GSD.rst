.. automodule:: MDAnalysis.coordinates.GSD
