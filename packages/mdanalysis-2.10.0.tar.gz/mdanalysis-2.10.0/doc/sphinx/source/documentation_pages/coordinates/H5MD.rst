.. automodule:: MDAnalysis.coordinates.H5MD
