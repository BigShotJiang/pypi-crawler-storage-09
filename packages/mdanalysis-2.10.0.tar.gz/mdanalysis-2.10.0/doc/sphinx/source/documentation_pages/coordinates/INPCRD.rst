.. automodule:: MDAnalysis.coordinates.INPCRD
