.. automodule:: MDAnalysis.coordinates.MMTF

