.. automodule:: MDAnalysis.coordinates.MOL2

