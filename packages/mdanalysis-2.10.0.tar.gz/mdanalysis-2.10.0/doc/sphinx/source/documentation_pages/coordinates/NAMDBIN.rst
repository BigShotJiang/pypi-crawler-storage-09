.. automodule:: MDAnalysis.coordinates.NAMDBIN
