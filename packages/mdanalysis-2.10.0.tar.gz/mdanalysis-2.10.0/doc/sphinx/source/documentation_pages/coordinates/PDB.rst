.. automodule:: MDAnalysis.coordinates.PDB

