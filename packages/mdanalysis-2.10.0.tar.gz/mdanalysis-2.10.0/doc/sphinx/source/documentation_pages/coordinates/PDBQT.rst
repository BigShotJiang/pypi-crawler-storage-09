.. automodule:: MDAnalysis.coordinates.PDBQT
   :members:
