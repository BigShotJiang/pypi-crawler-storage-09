.. automodule:: MDAnalysis.coordinates.PQR
   :members:
