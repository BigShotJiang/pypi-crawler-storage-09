.. automodule:: MDAnalysis.coordinates.TNG
    :members:
