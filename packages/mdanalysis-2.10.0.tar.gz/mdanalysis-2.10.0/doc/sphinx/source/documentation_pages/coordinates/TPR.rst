.. automodule:: MDAnalysis.coordinates.TPR
