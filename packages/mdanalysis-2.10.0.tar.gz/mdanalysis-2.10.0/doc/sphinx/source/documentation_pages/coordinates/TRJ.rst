.. automodule:: MDAnalysis.coordinates.TRJ

