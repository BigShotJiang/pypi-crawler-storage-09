.. automodule:: MDAnalysis.coordinates.TRR
   :members:
   :inherited-members:
