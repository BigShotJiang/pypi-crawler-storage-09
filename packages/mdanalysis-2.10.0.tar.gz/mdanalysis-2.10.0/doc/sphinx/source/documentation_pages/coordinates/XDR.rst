.. automodule:: MDAnalysis.coordinates.XDR
   :members:
   :inherited-members:
