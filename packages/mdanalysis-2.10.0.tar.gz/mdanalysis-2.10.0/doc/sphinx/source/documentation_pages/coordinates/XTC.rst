.. automodule:: MDAnalysis.coordinates.XTC
   :members:
   :inherited-members:
