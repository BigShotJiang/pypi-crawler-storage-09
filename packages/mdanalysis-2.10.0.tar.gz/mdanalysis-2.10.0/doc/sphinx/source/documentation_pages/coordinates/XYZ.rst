.. automodule:: MDAnalysis.coordinates.XYZ
   :members:
