.. automodule:: MDAnalysis.coordinates.__init__

