.. automodule:: MDAnalysis.coordinates.memory
