.. automodule:: MDAnalysis.core.groups
