.. automodule:: MDAnalysis.core.__init__

