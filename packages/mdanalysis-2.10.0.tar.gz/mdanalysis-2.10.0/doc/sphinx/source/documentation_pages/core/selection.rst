.. automodule:: MDAnalysis.core.selection
   :members:
