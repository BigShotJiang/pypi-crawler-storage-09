.. automodule:: MDAnalysis.core.topology
