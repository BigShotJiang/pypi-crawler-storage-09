.. automodule:: MDAnalysis.core.topologyattrs
   :members:
