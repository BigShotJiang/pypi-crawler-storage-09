.. automodule:: MDAnalysis.core.topologyobjects
   :members:
