.. automodule:: MDAnalysis.core.universe
