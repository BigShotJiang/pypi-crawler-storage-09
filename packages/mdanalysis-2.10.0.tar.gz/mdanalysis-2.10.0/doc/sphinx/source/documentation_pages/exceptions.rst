.. automodule:: MDAnalysis.exceptions
   :members:
