.. automodule:: MDAnalysis.guesser.base
