.. automodule:: MDAnalysis.guesser.__init__
