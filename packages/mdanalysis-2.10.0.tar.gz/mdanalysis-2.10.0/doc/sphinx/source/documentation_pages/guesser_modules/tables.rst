.. automodule:: MDAnalysis.guesser.tables
