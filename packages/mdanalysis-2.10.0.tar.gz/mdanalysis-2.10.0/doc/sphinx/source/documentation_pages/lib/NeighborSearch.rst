.. automodule:: MDAnalysis.lib.NeighborSearch
   :members:
