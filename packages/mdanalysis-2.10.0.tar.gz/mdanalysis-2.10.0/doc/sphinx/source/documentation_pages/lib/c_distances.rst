.. automodule:: MDAnalysis.lib.c_distances
   :members:
