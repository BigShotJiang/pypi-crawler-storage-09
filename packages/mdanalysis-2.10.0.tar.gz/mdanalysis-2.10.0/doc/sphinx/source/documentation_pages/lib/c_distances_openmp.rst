.. automodule:: MDAnalysis.lib.c_distances_openmp
   :members:
