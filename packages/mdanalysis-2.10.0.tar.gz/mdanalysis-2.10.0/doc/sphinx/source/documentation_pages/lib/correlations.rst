.. automodule:: MDAnalysis.lib.correlations

	Autocorrelation Function
	------------------------
	.. autofunction:: MDAnalysis.lib.correlations.autocorrelation

	Intermittency Function
	----------------------
	.. autofunction:: MDAnalysis.lib.correlations.correct_intermittency