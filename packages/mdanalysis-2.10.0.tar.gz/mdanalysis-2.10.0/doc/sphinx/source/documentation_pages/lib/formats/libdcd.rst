.. automodule:: MDAnalysis.lib.formats.libdcd
   :members:
   :inherited-members:
