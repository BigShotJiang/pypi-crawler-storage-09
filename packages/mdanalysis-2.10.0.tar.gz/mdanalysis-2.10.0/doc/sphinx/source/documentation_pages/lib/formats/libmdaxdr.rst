.. automodule:: MDAnalysis.lib.formats.libmdaxdr
   :members:
   :inherited-members:
