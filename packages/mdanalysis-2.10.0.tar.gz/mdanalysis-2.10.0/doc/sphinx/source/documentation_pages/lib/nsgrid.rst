.. automodule:: MDAnalysis.lib.nsgrid
   :members: