.. automodule:: MDAnalysis.lib.picklable_file_io
