.. automodule:: MDAnalysis.lib.pkdtree
   :members:
