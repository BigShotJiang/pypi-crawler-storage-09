.. automodule:: MDAnalysis.selections.base
