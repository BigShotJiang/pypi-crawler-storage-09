.. automodule:: MDAnalysis.selections.charmm

