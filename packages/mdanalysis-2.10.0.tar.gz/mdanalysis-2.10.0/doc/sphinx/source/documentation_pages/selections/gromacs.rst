.. automodule:: MDAnalysis.selections.gromacs
