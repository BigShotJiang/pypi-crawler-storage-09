.. automodule:: MDAnalysis.selections.jmol
