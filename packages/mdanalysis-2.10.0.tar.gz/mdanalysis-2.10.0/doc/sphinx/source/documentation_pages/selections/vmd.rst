.. automodule:: MDAnalysis.selections.vmd

