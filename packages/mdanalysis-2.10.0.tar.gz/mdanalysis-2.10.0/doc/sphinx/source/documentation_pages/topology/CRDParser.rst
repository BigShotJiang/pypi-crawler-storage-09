.. automodule:: MDAnalysis.topology.CRDParser
