.. automodule:: MDAnalysis.topology.ExtendedPDBParser
