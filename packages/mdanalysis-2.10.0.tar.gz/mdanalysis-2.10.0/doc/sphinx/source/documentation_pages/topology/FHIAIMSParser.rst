.. automodule:: MDAnalysis.topology.FHIAIMSParser

