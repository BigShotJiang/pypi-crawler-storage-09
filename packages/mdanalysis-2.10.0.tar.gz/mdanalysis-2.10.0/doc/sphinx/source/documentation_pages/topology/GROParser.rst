.. automodule:: MDAnalysis.topology.GROParser
