.. automodule:: MDAnalysis.topology.HoomdXMLParser
