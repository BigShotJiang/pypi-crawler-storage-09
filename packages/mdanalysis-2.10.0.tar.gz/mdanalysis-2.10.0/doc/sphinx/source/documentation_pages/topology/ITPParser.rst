.. automodule:: MDAnalysis.topology.ITPParser
