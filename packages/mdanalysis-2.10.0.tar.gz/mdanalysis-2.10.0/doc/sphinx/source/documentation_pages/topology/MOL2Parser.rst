.. automodule:: MDAnalysis.topology.MOL2Parser

