.. automodule:: MDAnalysis.topology.PQRParser

