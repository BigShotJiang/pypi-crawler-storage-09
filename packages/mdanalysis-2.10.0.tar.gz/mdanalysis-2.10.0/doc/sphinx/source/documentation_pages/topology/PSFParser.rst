.. automodule:: MDAnalysis.topology.PSFParser

