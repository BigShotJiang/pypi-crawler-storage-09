.. automodule:: MDAnalysis.topology.TOPParser

