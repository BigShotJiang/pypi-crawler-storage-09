.. automodule:: MDAnalysis.topology.TPRParser

