.. automodule:: MDAnalysis.topology.TXYZParser

