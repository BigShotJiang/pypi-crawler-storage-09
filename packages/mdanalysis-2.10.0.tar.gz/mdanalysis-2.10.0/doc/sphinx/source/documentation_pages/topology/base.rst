.. automodule:: MDAnalysis.topology.base

