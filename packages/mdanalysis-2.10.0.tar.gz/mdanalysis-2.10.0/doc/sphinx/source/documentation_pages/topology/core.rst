.. core.rst uses automatic listing of members at the moment; all the
.. other ones have the classes and functions explicitly listed in the
.. reST doc string.

.. automodule:: MDAnalysis.topology.core
   :members:
