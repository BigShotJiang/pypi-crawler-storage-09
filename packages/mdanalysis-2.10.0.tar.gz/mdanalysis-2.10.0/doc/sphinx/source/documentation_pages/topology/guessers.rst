.. automodule:: MDAnalysis.topology.guessers
   :members:
