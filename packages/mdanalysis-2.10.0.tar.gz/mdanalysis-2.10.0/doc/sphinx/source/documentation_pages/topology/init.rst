.. automodule:: MDAnalysis.topology.__init__
