.. automodule:: MDAnalysis.transformations.boxdimensions
