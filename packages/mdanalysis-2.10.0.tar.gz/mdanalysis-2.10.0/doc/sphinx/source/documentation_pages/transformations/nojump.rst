.. automodule:: MDAnalysis.transformations.nojump
