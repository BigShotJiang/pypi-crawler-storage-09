.. automodule:: MDAnalysis.transformations.positionaveraging
