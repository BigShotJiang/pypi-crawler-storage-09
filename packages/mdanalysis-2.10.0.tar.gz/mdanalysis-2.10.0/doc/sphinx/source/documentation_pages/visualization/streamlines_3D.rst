.. automodule:: MDAnalysis.visualization.streamlines_3D
    
