"""Entry point for the package."""
from . import main

if __name__ == "__main__":
    main()