#!/usr/bin/env python

"""Tests for `MDTerp` package."""


import unittest


class TestMdterp(unittest.TestCase):
    """Tests for `MDTerp` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
