::: imgtools.autopipeline
