::: imgtools.autopipeline_utils
