::: imgtools.coretypes.base_medimage
