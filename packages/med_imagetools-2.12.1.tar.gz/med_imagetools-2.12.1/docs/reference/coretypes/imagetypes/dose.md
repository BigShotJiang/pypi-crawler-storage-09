::: imgtools.coretypes.imagetypes.dose
