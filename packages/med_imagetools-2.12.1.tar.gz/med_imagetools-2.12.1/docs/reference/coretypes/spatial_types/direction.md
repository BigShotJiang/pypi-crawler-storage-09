::: imgtools.coretypes.spatial_types.direction
