::: imgtools.dicom.dicom_metadata.modality_utils.seg_utils
