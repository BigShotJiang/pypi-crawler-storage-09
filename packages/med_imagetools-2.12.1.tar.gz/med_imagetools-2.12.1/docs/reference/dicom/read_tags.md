::: imgtools.dicom.read_tags
