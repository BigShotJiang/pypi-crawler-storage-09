::: imgtools.dicom.sort.exceptions
