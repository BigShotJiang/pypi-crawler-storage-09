::: imgtools.dicom.sort.sort_method
