::: imgtools.dicom.sort.sorter_base
