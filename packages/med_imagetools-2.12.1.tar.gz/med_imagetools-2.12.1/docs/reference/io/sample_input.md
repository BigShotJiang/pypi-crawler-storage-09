::: imgtools.io.sample_input
