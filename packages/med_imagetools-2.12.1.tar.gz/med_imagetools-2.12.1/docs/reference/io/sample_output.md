::: imgtools.io.sample_output
