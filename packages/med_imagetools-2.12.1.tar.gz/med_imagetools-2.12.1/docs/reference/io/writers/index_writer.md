::: imgtools.io.writers.index_writer
