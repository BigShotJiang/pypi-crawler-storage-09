::: imgtools.transforms.intensity_transforms
