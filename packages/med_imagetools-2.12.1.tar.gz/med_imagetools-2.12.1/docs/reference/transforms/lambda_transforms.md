::: imgtools.transforms.lambda_transforms
