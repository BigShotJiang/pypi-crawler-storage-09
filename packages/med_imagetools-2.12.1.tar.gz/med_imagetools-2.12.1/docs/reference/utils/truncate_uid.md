::: imgtools.utils.truncate_uid
