
import importlib.metadata 
import logging
mediawiki_to_pdf_logger = logging.getLogger(__name__)

__version__ =  importlib.metadata.version('mediawiki_to_pdf') 

