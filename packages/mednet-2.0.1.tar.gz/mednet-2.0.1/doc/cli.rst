.. Copyright © 2022 Idiap Research Institute <contact@idiap.ch>
..
.. SPDX-License-Identifier: GPL-3.0-or-later

.. _mednet.cli:

========================
 Command-line Interface
========================

This section contains an overview of command-line applications shipped with
this package.


.. click:: mednet.scripts.cli:cli
   :prog: mednet
   :nested: full


.. include:: links.rst
