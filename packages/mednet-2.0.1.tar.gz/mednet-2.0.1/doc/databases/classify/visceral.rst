.. SPDX-FileCopyrightText: Copyright © 2024 Idiap Research Institute <contact@idiap.ch>
..
.. SPDX-License-Identifier: GPL-3.0-or-later

.. _mednet.databases.classify.visceral:

==========
 Visceral
==========

* DataModule and support code: :py:mod:`.data.classify.visceral`
* Splits:

  .. list-table::
     :align: left

     * - Config. key
       - Module
     * - ``visceral``
       - :py:mod:`.config.classify.data.visceral.default`
