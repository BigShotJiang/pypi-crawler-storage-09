.. SPDX-FileCopyrightText: Copyright © 2024 Idiap Research Institute <contact@idiap.ch>
..
.. SPDX-License-Identifier: GPL-3.0-or-later

.. _mednet.databases.segment.cxr8:

=======
 CXR-8
=======

* DataModule and support code: :py:mod:`.data.segment.cxr8`
* Splits:

  .. list-table::
     :align: left

     * - Config. key
       - Module
     * - ``cxr8``
       - :py:mod:`.config.segment.data.cxr8.default`
