## `Index` Usage

The `Index` uses blocking methods, and and should be used when using the `Client`. When you create
a new index with the `Client` it will create an `Index` instance.

## `Index` API

::: meilisearch_python_sdk.index.Index
