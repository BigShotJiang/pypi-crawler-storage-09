"""Azure state store."""
