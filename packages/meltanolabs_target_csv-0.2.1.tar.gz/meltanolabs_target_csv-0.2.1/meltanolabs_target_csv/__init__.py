"""A CSV target for Singer, made with the Meltano SDK for Taps and Targets."""
