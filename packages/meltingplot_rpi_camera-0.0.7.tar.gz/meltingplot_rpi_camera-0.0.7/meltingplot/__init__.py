"""Initialize the meltingplot package."""
