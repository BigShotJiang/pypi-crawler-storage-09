# mendelbrot

A pedigree parser, and a pypi packaging experiment

This is a simple pedigree parser, which provides a simple, minimal-dependency interface for parsing a Pedigree file.

This was developed as part of the broader [Talos](https://github.com/populationgenomics/talos) project, and as such can
support standard 6-column pedigree files, as well as 7-column pedigree files which pack HPO terms into the final column. 
See the [Usage documentation](docs/Pedigree.md) for more details