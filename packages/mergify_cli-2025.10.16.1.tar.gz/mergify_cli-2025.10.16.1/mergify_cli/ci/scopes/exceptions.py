class ScopesError(Exception):
    pass
