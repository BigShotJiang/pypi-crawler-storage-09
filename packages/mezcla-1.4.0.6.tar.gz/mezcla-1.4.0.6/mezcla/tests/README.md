## Test overview

In addition to pytest-based unit tests, there are command-line tests using
BatsPP (see https://github.com/LimaBD/batspp).

## Style tips

Don't use black without permission: it is too opinionated!

See main README under root dir (../..).

