#! /usr/bin/env python3
#
# Dummy module for test_mezcla_to_standard.py
#

"""Dummy module for testing purposes"""

def func(*_args):
    """Dummy function with variable number of _ARGS"""
    return
func2 = func3 = func4 = func1 = func
