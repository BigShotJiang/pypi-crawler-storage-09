See ../tfidf/tests for the TF/IDF tests.
