# Compatible Pyodide versions

The following versions of micropip and Pyodide are tested in CI.
Other versions may work, however we make no guarantees.

| micropip    | Tested Pyodide versions |
| ----------- | ----------------------- |
| main branch | 0.24.1, 0.25.0          |
| 0.6.0       | 0.24.1, 0.25.0          |
| 0.5.0       | 0.22.1, 0.23.4, 0.24.0  |
