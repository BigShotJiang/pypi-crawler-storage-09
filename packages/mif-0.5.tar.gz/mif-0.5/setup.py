#!/usr/bin/env python3
from os import path

from setuptools import find_packages, setup

# read our README
this_directory = path.abspath(path.dirname(__file__))
with open(path.join(this_directory, 'README.md'), encoding='utf-8') as f:
    long_description = f.read()

setup(
    name='mif',
    url='https://github.com/agrif/mif/',
    description='reading and writing MIF files',
    long_description=long_description,
    long_description_content_type='text/markdown',
    author='Aaron Griffith',
    author_email='aargri@gmail.com',
    license='MIT',
    platforms=['any'],

    project_urls={
        'Source': 'https://github.com/agrif/mif/',
        'Documentation': 'https://mif.readthedocs.io/en/latest/',
    },

    keywords='memory mif quartus',
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'Topic :: Software Development :: Libraries :: Python Modules',

        'Topic :: Scientific/Engineering :: '
        'Electronic Design Automation (EDA)',

        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
    ],

    setup_requires=[
        'setuptools_git >= 0.3',
        'bad-setuptools-git-version >= 1.0.12',
    ],
    extras_require={
        'docs': ['mkdocs >= 1.2, < 1.3', 'mkautodoc >= 0.2.0'],
    },
    version_config={
        'template': '{tag}',
        'starting_version': '0.1',
    },

    packages=find_packages(exclude=['tests', 'tests.*']),
    install_requires=[
        'numpy >= 1.17.0',
        'lark-parser >= 0.8.0',
        'importlib-resources >= 5.12, < 6.0',
    ],
    python_requires='>=3.5',
    include_package_data=True,
    test_suite='tests',
)
