from mignonFramework import LoguruPlus



log = LoguruPlus()


