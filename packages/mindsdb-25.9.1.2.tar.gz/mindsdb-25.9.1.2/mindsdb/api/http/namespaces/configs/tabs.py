from flask_restx import Namespace

ns_conf = Namespace('tabs', description='Save/load data from WebUI tabs')
