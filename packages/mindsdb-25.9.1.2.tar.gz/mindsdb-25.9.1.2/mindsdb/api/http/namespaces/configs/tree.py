from flask_restx import Namespace

ns_conf = Namespace('tree', description='API for getting project structure')
