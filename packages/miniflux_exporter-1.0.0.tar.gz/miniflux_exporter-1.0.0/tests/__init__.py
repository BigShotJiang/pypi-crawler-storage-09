"""
Tests for Miniflux Exporter.
"""

__all__ = []
