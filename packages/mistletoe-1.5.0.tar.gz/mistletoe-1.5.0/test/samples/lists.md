## Basic list

* fruit
    * apple
    * orange
      * Note: Orange is also a color.
    * lemon

## Spaced list

* vegetable

    * carrot

    * cucumber

## Combined list

1. firstly
2. secondly
    * s-first

      another paragraph in s-first

      > line quote in s-first
      
    * s-second
      ```
      with some code block in s-second
      ```
3. thirdly

Another paragraph.
