from .commonmark import main

main()
