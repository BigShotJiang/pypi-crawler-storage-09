# mjaf


[![PyPI Downloads](https://img.shields.io/pypi/dm/mjaf.svg?label=PyPI%20downloads)](
https://pypi.org/project/mjaf)
