# Changelog

All notable changes to this project will be documented in this file.

## [Unreleased]

### Added

- Lorem ipsum (#23).
- Dolor sit (#42).

### Changed

- Amet (#1337).

### Removed

- Consectetur adipiscing elit (#666).

## [1.0.1] - 2023-03-05

### Added

- Lorem ipsum (#23).
- Dolor sit (#42).

### Changed

- Amet (#1337).

### Removed

- Consectetur adipiscing elit (#666).

## [1.0] - 2019-02-15

### Added

- Lorem ipsum (#23).
- Dolor sit (#42).

### Changed

- Amet (#1337).

### Removed

- Consectetur adipiscing elit (#666).

[unreleased]: https://git.example.org/foo/bar/compare/1.0.1...HEAD
[1.0.1]: https://git.example.org/foo/bar/compare/1.0...1.0.1
[1.0]: https://git.example.org/foo/bar/releases/tag/1.0
