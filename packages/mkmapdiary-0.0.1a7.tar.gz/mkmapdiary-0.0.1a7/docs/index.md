# Mkmapdiary

Welcome to the `mkmapdiary` documentation. Currently there is not much to see (yet).