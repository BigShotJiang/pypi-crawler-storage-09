"""Information/Metadata- related classes."""
