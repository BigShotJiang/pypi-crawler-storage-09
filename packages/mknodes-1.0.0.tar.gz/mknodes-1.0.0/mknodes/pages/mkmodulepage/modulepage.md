## Class info

{% if klasses %}
### Classes

{{ klasses | MkClassTable }}
{% endif %}

### 🛈 DocStrings

{{ module | MkDocStrings }}
