"""Classes and helpers for trees."""

from __future__ import annotations

from .node import Node

__all__ = ["Node"]
