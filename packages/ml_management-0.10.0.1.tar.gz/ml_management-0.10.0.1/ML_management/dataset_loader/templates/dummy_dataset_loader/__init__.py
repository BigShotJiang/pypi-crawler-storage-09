from .dummy_dataset import DummyDataWrapper


def get_object():
    return DummyDataWrapper()
