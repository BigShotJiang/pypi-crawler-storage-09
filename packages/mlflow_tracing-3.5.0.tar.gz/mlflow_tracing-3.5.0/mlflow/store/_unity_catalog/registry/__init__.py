from mlflow.store._unity_catalog.registry import (
    rest_store as rest_store,
)
from mlflow.store._unity_catalog.registry import (
    uc_oss_rest_store as uc_oss_rest_store,
)
