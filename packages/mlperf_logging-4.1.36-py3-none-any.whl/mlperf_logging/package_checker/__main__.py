from . import package_checker

package_checker.main()
