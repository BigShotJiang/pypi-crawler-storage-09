# Referencia API

::: mlschema
    options:
      heading_level: 2
      show_root_heading: true
      show_source: false

::: mlschema.core
    options:
      heading_level: 2
      show_root_heading: true
      show_source: false

::: mlschema.strategies
    options:
      heading_level: 2
      show_root_heading: true
      show_source: false
