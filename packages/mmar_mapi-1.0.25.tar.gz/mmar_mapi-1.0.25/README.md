# mmar-mapi

Multimodal architectures Maestro API
