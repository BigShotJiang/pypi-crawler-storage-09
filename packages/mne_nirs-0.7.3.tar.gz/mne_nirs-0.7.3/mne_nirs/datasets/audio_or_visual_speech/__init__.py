"""**fNIRS dataset with audio or visual speech**"""

from ._audio_or_visual_speech import data_path
