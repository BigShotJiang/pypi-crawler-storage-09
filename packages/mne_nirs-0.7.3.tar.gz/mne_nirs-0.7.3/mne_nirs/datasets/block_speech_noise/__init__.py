"""**fNIRS dataset with auditory speech and noise**"""

from ._block_speech_noise import data_path
