"""**CAMH KF fNIRS Fingertapping Dataset**"""

from .camh_kf_fnirs_fingertapping import data_path
