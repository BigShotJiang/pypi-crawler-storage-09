"""**fNIRS dataset with finger tapping task**"""

from .fnirs_motor_group import data_path
