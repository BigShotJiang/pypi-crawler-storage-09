"""**fNIRS dataset with finger tapping task**"""

from .snirf_with_aux import data_path
