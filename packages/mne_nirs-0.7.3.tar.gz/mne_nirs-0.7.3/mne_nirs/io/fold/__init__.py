# Author: Robert Luke <mail@robertluke.net>
#
# License: BSD (3-clause)

from ._fold import fold_landmark_specificity, fold_channel_specificity
