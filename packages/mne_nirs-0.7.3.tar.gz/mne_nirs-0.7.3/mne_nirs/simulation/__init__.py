# Authors: Robert Luke <mail@robertluke.net>
#
# License: BSD (3-clause)

from ._simulation import simulate_nirs_raw
