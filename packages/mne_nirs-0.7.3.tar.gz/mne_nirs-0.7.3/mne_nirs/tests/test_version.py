# Authors: Robert Luke <mail@robertluke.net>
#
# License: BSD (3-clause)

import mne_nirs


def test_version():
    print(mne_nirs.__version__)
