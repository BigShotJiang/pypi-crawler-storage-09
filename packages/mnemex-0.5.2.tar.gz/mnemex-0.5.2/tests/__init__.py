"""Tests for Mnemex."""
