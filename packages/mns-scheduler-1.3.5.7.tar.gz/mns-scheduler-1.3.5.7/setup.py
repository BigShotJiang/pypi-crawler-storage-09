from setuptools import setup, find_packages

setup(
    name='mns-scheduler',
    version='1.3.5.7',
    packages=find_packages(),
    install_requires=[],  # 如果有依赖项，可以在这里列出
)
