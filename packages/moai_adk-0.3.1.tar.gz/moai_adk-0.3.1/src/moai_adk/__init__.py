# @CODE:PY314-001 | SPEC: SPEC-PY314-001.md | TEST: tests/unit/test_foundation.py
"""MoAI Agentic Development Kit

SPEC-First TDD Framework with Alfred SuperAgent
"""

__version__ = "0.3.1"
__all__ = ["__version__"]
