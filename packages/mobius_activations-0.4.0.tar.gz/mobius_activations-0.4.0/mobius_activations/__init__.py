# mobius_activations/__init__.py
__version__ = "0.3.2"
