# Export directly from the notebook File > Save and export notebook as > HTML
