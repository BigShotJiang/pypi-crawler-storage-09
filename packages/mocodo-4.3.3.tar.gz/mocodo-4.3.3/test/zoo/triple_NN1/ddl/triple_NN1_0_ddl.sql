CREATE TABLE GERER (
  PRIMARY KEY (ingenieur, projet),
  ingenieur   VARCHAR(42) NOT NULL,
  projet      VARCHAR(42) NOT NULL,
  responsable VARCHAR(42) NOT NULL
);
