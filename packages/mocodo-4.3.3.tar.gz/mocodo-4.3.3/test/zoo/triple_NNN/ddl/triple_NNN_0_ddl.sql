CREATE TABLE APPLIQUER (
  PRIMARY KEY (employe, projet, competence),
  employe    VARCHAR(42) NOT NULL,
  projet     VARCHAR(42) NOT NULL,
  competence VARCHAR(42) NOT NULL
);
