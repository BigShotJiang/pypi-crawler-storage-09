CREATE TABLE EXEMPLAIRE (
  PRIMARY KEY (oeuvre, exemplaire),
  oeuvre     VARCHAR(42) NOT NULL,
  exemplaire VARCHAR(42) NOT NULL,
  foobar     VARCHAR(42)
);
