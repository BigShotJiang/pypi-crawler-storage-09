DEFAULT_BASE_URL = "https://api.modelsignature.com"
DEFAULT_TIMEOUT = 30
