"""Module in lower package for auto-mount testing."""

x = 11
