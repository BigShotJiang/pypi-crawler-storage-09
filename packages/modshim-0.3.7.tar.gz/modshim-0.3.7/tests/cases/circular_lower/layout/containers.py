"""Containers module for layout package."""

from ..application.current import get_app

_ = get_app


class Container:
    """Container class used in the application."""
