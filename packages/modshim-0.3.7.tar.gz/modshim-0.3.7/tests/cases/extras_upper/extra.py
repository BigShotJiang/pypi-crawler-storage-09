"""Extra module in extras_b package."""

y = 1
