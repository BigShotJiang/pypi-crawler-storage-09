---
hide:
  - navigation
---

<!-- prettier-ignore -->
::: mkdocs-click
    :module: module_qc_data_tools.cli.main
    :command: typer_click_object
    :prog_name: mqdt
    :depth: 0
    :style: table
    :list_subcommands: true
