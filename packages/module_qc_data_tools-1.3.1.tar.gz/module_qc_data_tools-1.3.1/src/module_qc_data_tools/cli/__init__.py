from module_qc_data_tools.cli.main import app

__all__ = ("app",)
