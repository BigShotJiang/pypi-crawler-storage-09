from __future__ import annotations

import module_qc_data_tools as m


def test_version():
    assert m.__version__
