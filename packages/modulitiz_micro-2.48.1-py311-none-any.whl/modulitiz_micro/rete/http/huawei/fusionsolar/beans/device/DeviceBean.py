from dataclasses import dataclass

@dataclass
class DeviceBean:
	idDevice: int
	idType: int
