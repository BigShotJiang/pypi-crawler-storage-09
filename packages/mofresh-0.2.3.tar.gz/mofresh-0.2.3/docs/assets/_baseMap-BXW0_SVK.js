import{b as r}from"./_baseEach-DHNYGtOc.js";import{x as a}from"./index-D3XtisvU.js";function n(n,o){var t=-1,s=a(n)?Array(n.length):[];return r(n,(function(r,a,n){s[++t]=o(r,a,n)})),s}export{n as b};
