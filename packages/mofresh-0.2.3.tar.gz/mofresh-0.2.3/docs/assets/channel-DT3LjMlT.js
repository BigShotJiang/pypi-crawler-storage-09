import{U as a,C as r}from"./mermaid-BGnxfgCD.js";const s=(s,o)=>a.lang.round(r.parse(s)[o]);export{s as c};
