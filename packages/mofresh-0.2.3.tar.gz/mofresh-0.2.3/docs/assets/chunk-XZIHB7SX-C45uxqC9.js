var t;import{_ as i}from"./mermaid-BGnxfgCD.js";var r=(i(t=class{constructor(t){this.init=t,this.records=this.init()}reset(){this.records=this.init()}},"ImperativeState"),t);export{r as I};
