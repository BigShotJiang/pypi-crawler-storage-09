import{b as r}from"./_baseUniq-BlNMZyiw.js";function n(n){return r(n,4)}export{n as c};
