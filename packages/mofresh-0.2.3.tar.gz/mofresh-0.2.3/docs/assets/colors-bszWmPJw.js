function r(r){for(var e=r.length/6|0,n=new Array(e),t=0;t<e;)n[t]="#"+r.slice(6*t,6*++t);return n}export{r as c};
