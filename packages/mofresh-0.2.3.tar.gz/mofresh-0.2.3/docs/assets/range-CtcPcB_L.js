function r(r,a,t){r=+r,a=+a,t=(n=arguments.length)<2?(a=r,r=0,1):n<3?1:+t;for(var e=-1,n=0|Math.max(0,Math.ceil((a-r)/t)),h=new Array(n);++e<n;)h[e]=r+e*t;return h}export{r};
