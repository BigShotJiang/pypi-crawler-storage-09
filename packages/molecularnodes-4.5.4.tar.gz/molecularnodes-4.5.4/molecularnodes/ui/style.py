STYLE_ITEMS = (
    ("spheres", "Spheres", "Space-filling atoms style."),
    ("cartoon", "Cartoon", "Secondary structure cartoons"),
    ("surface", "Surface", "Solvent-accsible surface."),
    ("ribbon", "Ribbon", "Continuous backbone ribbon."),
    ("sticks", "Sticks", "Sticks for each bond."),
    ("ball_and_stick", "Ball and Stick", "Spheres for atoms, sticks for bonds"),
    ("preset_1", "Preset 1", "A pre-made combination of different styles"),
    ("preset_2", "Preset 2", "A pre-made combination of different styles"),
    ("preset_3", "Preset 3", "A pre-made combination of different styles"),
    ("preset_4", "Preset 4", "A pre-made combination of different styles"),
)
