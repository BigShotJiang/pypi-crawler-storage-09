---
hide:
  - navigation
---

# Help Monkay

Do you like **Monkay** and would like to help Monkay, other user and the author?

## ⭐ Star **Monkay** on GitHub

Giving a star to Monkay is very simple and helps promoting the work across the developers around the world.

The button is located at the top right.

[https://github.com/dymmond/monkay](https://github.com/dymmond/monkay).

This will help spreading the word about the tool and how helpful has been.

## 👀 Follow the GitHub repo

Following the GitHub repo will allow you to "watch" for any new release of Monkay and be always up to date.

You can click on "***watch***" and select "***custom***" -> "***Releases***"or any other you may find particular
interesting to you.

## 💬 Join the official Edgy discord channel

Our official chat is on discord, we find it very useful and free for people to discuss issues, helping and contributing
in a more organised manner.

<a href="https://discord.gg/eMrM9sWWvu" target="_blank">Monkay discord channel</a>. Join us! 🗸

## 🔥 Sponsor the author

The author built this framework with all of his heart and dedication and will continue to do it so but that also
requires time and resources and when they are limited, the process still gets there but takes a bit longer.

You can financially help and support the author though [GitHub sponsors](https://github.com/sponsors/tarsil)

He can afterwards go for a coffee☕, on him, to say thanks🙏.
