# SPDX-FileCopyrightText: 2024-present alex <devkral@web.de>
#
# SPDX-License-Identifier: BSD-3 Clauses
