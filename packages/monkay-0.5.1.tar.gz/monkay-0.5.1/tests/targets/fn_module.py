def bar():
    return "bar"


def bar2():
    return "bar2"


def deprecated():
    return "deprecated"


__all__ = ["bar", "bar2", "deprecated"]
