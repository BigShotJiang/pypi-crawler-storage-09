def load():
    from . import module_full_preloaded1_fn  # noqa
