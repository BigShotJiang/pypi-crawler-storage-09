from monkay import Monkay

monkay = Monkay(
    globals(),
)
