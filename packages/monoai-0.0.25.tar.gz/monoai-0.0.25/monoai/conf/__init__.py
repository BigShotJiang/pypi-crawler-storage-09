from .conf import Conf

__all__ = ["Conf"]
