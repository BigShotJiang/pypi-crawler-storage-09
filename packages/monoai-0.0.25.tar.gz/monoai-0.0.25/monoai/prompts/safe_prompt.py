# TODO: Implement safe prompt

