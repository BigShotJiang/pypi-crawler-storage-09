"""Mortality model related modules."""
