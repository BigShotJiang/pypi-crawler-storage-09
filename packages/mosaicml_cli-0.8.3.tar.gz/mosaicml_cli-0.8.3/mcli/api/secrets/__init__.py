"""API calls for secrets management"""
# pylint: disable=useless-import-alias
from mcli.api.secrets.api_create_secret import create_secret as create_secret
from mcli.api.secrets.api_delete_secrets import delete_secrets as delete_secrets
from mcli.api.secrets.api_get_secrets import get_secrets as get_secrets
