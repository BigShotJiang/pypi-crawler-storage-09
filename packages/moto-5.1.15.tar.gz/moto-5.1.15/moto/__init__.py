from moto.core.decorator import mock_aws as mock_aws  # noqa: E402

__title__ = "moto"
__version__ = "5.1.15"
