def fake_version(params):
    return "99"
