## Contributing to Mplcanvas

Welcome to the developer side of Mplcanvas!

Contributions are always welcome.
This includes reporting bugs or other issues, submitting pull requests, requesting new features, etc.

If you need help with using Mplcanvas or contributing to it, have a look at the GitHub [discussions](https://github.com/scipp/mplcanvas/discussions) and start a new [Q&A discussion](https://github.com/scipp/mplcanvas/discussions/categories/q-a) if you can't find what you are looking for.

For bug reports and other problems, please open an [issue](https://github.com/scipp/mplcanvas/issues/new) in GitHub.

You are welcome to submit pull requests at any time.
But to avoid having to make large modifications during review or even have your PR rejected, please first open an issue first to discuss your idea!

Check out the subsections of the [Developer documentation](https://scipp.github.io/mplcanvas/developer/index.html) for details on how Mplcanvas is developed.

## Code of conduct

This project is a community effort, and everyone is welcome to contribute.
Everyone within the community is expected to abide by our [code of conduct](https://github.com/scipp/mplcanvas/blob/main/CODE_OF_CONDUCT.md).
