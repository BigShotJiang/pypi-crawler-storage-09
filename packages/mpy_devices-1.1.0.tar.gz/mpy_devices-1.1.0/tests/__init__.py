"""Tests for mpy-devices."""
