<!--- This file has been generated from an external template. Please do not modify it directly. -->
<!--- Changes should be contributed to https://github.com/munich-quantum-toolkit/templates. -->

# Contributing

Thank you for your interest in contributing to MQT Bench!
An extensive contribution guide is available in our [documentation](https://mqt.readthedocs.io/projects/bench/en/latest/CONTRIBUTING.html).
