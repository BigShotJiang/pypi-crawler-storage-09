#!/bin/bash

set -e

exec "$@"
