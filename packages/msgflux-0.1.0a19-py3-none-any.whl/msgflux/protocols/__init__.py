"""Protocol integrations for msgflux."""
