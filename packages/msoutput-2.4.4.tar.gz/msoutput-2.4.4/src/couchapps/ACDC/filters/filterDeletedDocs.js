function(doc, req) {
    return !doc._deleted;
}