//import common scripts
WMStats.Globals.importScripts(["js/ViewModels/WMStats.ViewModel.js"]);