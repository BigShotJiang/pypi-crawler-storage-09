WMStats.Globals.importScripts([
    "js/Views/Graphs/WMStats.SiteHistoryGraph.js"
]);
