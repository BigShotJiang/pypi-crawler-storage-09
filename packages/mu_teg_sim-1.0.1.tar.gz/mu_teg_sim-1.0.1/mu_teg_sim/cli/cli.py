def main():
    from mu_teg_sim.gui.main_frame import MainFrame
    app = MainFrame()
    app.mainloop()
