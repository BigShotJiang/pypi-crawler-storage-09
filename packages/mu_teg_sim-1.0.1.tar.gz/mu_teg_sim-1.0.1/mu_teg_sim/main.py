from mu_teg_sim.gui.main_frame import MainFrame

if __name__ == "__main__":
    app = MainFrame()
    app.mainloop()
