export { default as ActorHeader } from "./ActorHeader";
export type { ActorHeaderProps } from "./ActorHeader";
