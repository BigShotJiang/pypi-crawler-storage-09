# mugeshcalcu

Simple Python library created by Mugesh for performing **addition** and **multiplication**.

## Installation

From your project folder:

```bash
pip install -e .
