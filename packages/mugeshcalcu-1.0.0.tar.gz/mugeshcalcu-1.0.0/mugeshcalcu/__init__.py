"""mugeshcalcu - Simple calculator library by Mugesh."""

from .calculator import add, multiply

__all__ = ["add", "multiply"]
__version__ = "1.0.0"
