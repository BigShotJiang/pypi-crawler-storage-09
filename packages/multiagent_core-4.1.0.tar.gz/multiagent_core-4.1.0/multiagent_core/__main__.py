"""Entry point for python -m multiagent_core execution."""

from .cli import main

if __name__ == "__main__":
    main()