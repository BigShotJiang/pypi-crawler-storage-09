# Refactoring Templates

Templates for generating refactoring reports and comparisons.

## Templates in this directory:

- `refactoring-report.md.template` - Analysis report template
- `before-after-comparison.md.template` - Code comparison template
