"""Schema specific to MDIO v1."""

from mdio.builder.schemas.v1.dataset import Dataset

__all__ = ["Dataset"]
