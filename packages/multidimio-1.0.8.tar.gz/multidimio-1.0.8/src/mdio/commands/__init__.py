"""Plugins for MDIO CLI commands.

Default Plugins:

* SEG-Y: CLI commands to ingest / export SEG-Y.
"""
