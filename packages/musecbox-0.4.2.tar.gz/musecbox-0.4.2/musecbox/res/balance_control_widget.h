#ifndef BALANCEWIDGET_H_INCLUDED
#define BALANCEWIDGET_H_INCLUDED

#include <QtWidgets/QWidget>

class BalanceControlWidget : public QWidget
{
public:
    BalanceControlWidget(QWidget* const parent)
        : QWidget(parent) {}
};

#endif // BALANCEWIDGET_H_INCLUDED
