# Copyright: (c) 2024, Dell Technologies
"""__init__.py."""

# pylint: disable=invalid-name

__title__ = "PyPowerStore"
__version__ = "3.4.1.0"
__author__ = "Dell Technologies or its subsidiaries"
__copyright__ = "Copyright 2024 Dell Technologies"
