# Copyright: (c) 2024, Dell Technologies
"""__init__.py."""

__title__ = "PyPowerStore"
__version__ = "3.4.0.0"
__author__ = "Dell Technologies or its subsidiaries"
__copyright__ = "Copyright 2024 Dell Technologies"
