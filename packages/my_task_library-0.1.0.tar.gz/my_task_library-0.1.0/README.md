# My Task Library

This half of the example contains just one Flyte task but is built as a library for others to use.

```bash
flyte run --local src/my_task_library/flyte_entities.py library_parent_task
```

To build and push this wheel:
