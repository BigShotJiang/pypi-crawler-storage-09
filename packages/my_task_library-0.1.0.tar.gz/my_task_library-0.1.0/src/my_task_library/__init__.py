def hello() -> str:
    return "Hello from my-task-library!"
