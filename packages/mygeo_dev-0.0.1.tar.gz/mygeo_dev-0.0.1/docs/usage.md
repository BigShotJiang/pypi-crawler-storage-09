# Usage

To use mygeo_dev in a project:

```
import mygeo_dev
```
