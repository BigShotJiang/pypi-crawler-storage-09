"""Top-level package for mygeo_dev."""

__author__ = """VanKhanh"""
__email__ = "dvkhanh@ute.udn.vn"
__version__ = "0.0.1"
