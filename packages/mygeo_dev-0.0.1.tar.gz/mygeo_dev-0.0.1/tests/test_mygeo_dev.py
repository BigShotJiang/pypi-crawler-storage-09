#!/usr/bin/env python

"""Tests for `mygeo_dev` package."""


import unittest

from mygeo_dev import mygeo_dev


class TestMygeo_dev(unittest.TestCase):
    """Tests for `mygeo_dev` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
