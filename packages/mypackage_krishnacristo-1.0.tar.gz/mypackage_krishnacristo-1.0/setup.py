from setuptools import setup, find_packages

setup(
    name='mypackage_krishnacristo',
    version='1.0',
    packages=['mypackage_krishnacristo'],
    include_package_data=True,
)

