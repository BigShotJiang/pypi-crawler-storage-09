"""Database utilities for DuckDB"""

from .duckdb_manager import BaseDuckDBManager

__all__ = ["BaseDuckDBManager"]
