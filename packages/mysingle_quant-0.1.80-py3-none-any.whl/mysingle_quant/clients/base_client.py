"""
Base Service Client

모든 마이크로서비스 HTTP 클라이언트의 베이스 클래스
공통 기능: 인증, 로깅, 에러 핸들링, 컨텍스트 매니저
"""

from __future__ import annotations

import os
from typing import Any, Dict

import httpx

from mysingle_quant.core.logging_config import get_logger

logger = get_logger(__name__)


class BaseServiceClient:
    """
    마이크로서비스 HTTP 클라이언트 베이스 클래스

    Features:
        - JWT 토큰 인증 자동 처리
        - 비동기 컨텍스트 매니저 지원
        - 공통 에러 핸들링
        - 로깅 표준화
        - 환경별 URL 설정 (Docker 내부 vs 외부)

    Usage:
        ```python
        class MyServiceClient(BaseServiceClient):
            def __init__(self, auth_token: str | None = None):
                super().__init__(
                    service_name="my-service",
                    default_port=8001,
                    auth_token=auth_token,
                )

            async def get_data(self) -> dict:
                return await self._request("GET", "/api/v1/data")

        # 사용
        async with MyServiceClient(auth_token="jwt_token") as client:
            data = await client.get_data()
        ```
    """

    def __init__(
        self,
        service_name: str,
        default_port: int,
        base_url: str | None = None,
        auth_token: str | None = None,
        timeout: float = 60.0,
        follow_redirects: bool = True,
        **kwargs: Any,
    ):
        """
        Args:
            service_name: 서비스 이름 (예: "strategy-service", "market-data-service")
            default_port: 기본 포트 (예: 8001, 8002)
            base_url: 명시적 base URL (없으면 자동 결정)
            auth_token: JWT 인증 토큰 (optional)
            timeout: 요청 타임아웃 (초)
            follow_redirects: 리다이렉트 자동 처리 여부
            **kwargs: httpx.AsyncClient 추가 인자
        """
        self.service_name = service_name
        self.default_port = default_port
        self.auth_token = auth_token

        # Base URL 결정
        if base_url is None:
            base_url = self._determine_base_url()

        self.base_url = base_url

        # HTTP 헤더 설정
        headers = kwargs.pop("headers", {})
        if auth_token:
            headers["Authorization"] = f"Bearer {auth_token}"

        # httpx AsyncClient 초기화
        self.client = httpx.AsyncClient(
            base_url=self.base_url,
            timeout=timeout,
            follow_redirects=follow_redirects,
            headers=headers,
            **kwargs,
        )

        logger.info(
            f"{self.__class__.__name__} initialized: {self.base_url} "
            f"(auth={'enabled' if auth_token else 'disabled'})"
        )

    def _determine_base_url(self) -> str:
        """
        실행 환경에 따라 적절한 base URL 결정

        Returns:
            base URL (Docker 내부 또는 localhost)

        Note:
            - Docker 내부: service-name:8000 (컨테이너 이름)
            - 외부/개발: localhost:default_port
        """
        # 환경 변수로 명시적 URL 제공 가능
        env_var = f"{self.service_name.upper().replace('-', '_')}_URL"
        if url := os.getenv(env_var):
            return url

        # Docker 내부 여부 확인 (간단한 휴리스틱)
        is_docker = os.path.exists("/.dockerenv") or os.getenv("DOCKER_ENV") == "true"

        if is_docker:
            # Docker 내부: 서비스 이름으로 접근 (Docker Compose 네트워크)
            # 모든 서비스는 컨테이너 내부에서 8000 포트 사용
            return f"http://{self.service_name}:8000"
        else:
            # 외부/개발 환경: localhost + 각 서비스별 포트
            return f"http://localhost:{self.default_port}"

    async def _request(
        self,
        method: str,
        path: str,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        """
        HTTP 요청 수행 (공통 에러 핸들링 포함)

        Args:
            method: HTTP 메서드 (GET, POST, PUT, DELETE 등)
            path: API 경로 (예: "/api/v1/data")
            **kwargs: httpx request 인자 (json, params, headers 등)

        Returns:
            응답 JSON 데이터

        Raises:
            httpx.HTTPError: HTTP 오류 발생 시
        """
        try:
            response = await self.client.request(method, path, **kwargs)
            response.raise_for_status()
            return response.json()
        except httpx.HTTPStatusError as e:
            logger.error(
                f"{self.service_name} HTTP {e.response.status_code} error: "
                f"{method} {path} - {e.response.text[:200]}"
            )
            raise
        except httpx.RequestError as e:
            logger.error(f"{self.service_name} request failed: {method} {path} - {e}")
            raise
        except Exception as e:
            logger.error(f"{self.service_name} unexpected error: {method} {path} - {e}")
            raise

    async def health_check(self) -> Dict[str, Any]:
        """
        서비스 Health Check (모든 서비스 공통)

        Returns:
            Health check 응답
        """
        try:
            response = await self._request("GET", "/health")
            logger.info(f"{self.service_name} health check passed")
            return response
        except Exception as e:
            logger.error(f"{self.service_name} health check failed: {e}")
            return {"status": "error", "message": str(e)}

    async def close(self):
        """클라이언트 종료"""
        await self.client.aclose()
        logger.info(f"{self.__class__.__name__} closed")

    async def __aenter__(self):
        """비동기 컨텍스트 매니저 진입"""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """비동기 컨텍스트 매니저 종료"""
        await self.close()

    def set_auth_token(self, token: str):
        """
        인증 토큰 동적 설정/변경

        Args:
            token: 새로운 JWT 토큰
        """
        self.auth_token = token
        self.client.headers["Authorization"] = f"Bearer {token}"
        logger.debug(f"{self.__class__.__name__} auth token updated")

    def remove_auth_token(self):
        """인증 토큰 제거"""
        self.auth_token = None
        self.client.headers.pop("Authorization", None)
        logger.debug(f"{self.__class__.__name__} auth token removed")
