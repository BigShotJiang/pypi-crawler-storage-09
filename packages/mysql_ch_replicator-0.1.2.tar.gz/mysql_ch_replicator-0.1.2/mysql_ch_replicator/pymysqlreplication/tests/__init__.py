from pymysqlreplication.tests.test_basic import *
from pymysqlreplication.tests.test_data_type import *
from pymysqlreplication.tests.test_data_objects import *
import unittest

if __name__ == "__main__":
    unittest.main()
