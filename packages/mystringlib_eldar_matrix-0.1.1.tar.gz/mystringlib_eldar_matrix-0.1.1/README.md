# MyStringLib

A simple Python package for string-based game functions.
