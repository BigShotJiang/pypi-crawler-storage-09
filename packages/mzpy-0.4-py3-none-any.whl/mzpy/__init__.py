__version__ = '0.4'

def main():
    print("mzpy core CLI is working.")