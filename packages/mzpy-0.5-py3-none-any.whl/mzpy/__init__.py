__version__ = '0.5'

def main():
    print("mzpy core CLI is working.")