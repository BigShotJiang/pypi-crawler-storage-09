__version__ = '0.5.1'

def main():
    print("mzpy core CLI is working.")