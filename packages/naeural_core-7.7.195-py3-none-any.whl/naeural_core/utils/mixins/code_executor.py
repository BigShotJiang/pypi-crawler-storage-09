from ratio1 import BaseCodeChecker

class _CodeExecutorMixin(BaseCodeChecker):
  """
  IMPORTANT: this class must be a mixin 
  """
  def __init__(self):
    super(_CodeExecutorMixin, self).__init__()
    return
  