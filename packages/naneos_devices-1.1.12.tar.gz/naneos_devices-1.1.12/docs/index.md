# Welcome to naneos-devices docs

This documentation is currently being built.
In the API Reference section, you will find the generated documentation based on the source code.

## Build this documentation locally

* `mkdocs serve` - Start the live-reloading docs server.
* `mkdocs build` - Build the documentation site.

## Coming soon
lorem ipsen ...