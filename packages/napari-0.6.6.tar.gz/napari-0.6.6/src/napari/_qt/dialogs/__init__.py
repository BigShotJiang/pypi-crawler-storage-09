"""Custom dialogs that inherit from QDialog."""
