from napari._qt.layer_controls.widgets._shapes.qt_edge_color import (
    QtEdgeColorControl,
)
from napari._qt.layer_controls.widgets._shapes.qt_edge_width_slider import (
    QtEdgeWidthSliderControl,
)

__all__ = ['QtEdgeColorControl', 'QtEdgeWidthSliderControl']
