from .results import ResultsWidget
