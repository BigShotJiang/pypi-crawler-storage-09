from .stitching import StitchingWidget

