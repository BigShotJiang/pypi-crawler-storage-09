# import numpy as np

# from napari_ome_zarr_navigator.img_browser import (
#     ImgBrowser,
# )


# def test_image_threshold_widget(make_napari_viewer):
#     viewer = make_napari_viewer()
#     layer = viewer.add_image(np.random.random((100, 100)))
#     my_widget = ImgBrowser(viewer)
