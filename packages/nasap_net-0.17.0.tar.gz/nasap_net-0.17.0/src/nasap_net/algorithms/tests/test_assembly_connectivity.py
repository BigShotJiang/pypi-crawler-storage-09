import pytest

from nasap_net import extract_connected_assemblies


def test_extract_connected_assemblies():
    pass


if __name__ == '__main__':
    pytest.main(['-vv', __file__])
