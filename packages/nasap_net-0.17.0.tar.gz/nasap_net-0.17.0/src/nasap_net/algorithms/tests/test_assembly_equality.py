import pytest

from nasap_net import assemblies_equal


def test_assemblies_equal():
    pass


if __name__ == '__main__':
    pytest.main(['-vv', __file__])
