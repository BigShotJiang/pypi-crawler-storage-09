import pytest

from nasap_net.bondset_enumeration import apply_symmetry_operation


def test_apply_symmetry_operation():
    pass


if __name__ == '__main__':
    pytest.main(['-vv', __file__])
