import pytest

from nasap_net.classes.component import check_bindsites_of_aux_edges_exists


def test_check_bindsites_of_aux_edges_exists():
    pass


if __name__ == '__main__':
    pytest.main(['-vv', __file__])
