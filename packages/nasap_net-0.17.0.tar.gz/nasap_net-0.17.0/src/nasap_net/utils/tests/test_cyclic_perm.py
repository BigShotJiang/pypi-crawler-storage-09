import pytest

from nasap_net.utils.cyclic_perm import cyclic_perm_to_map, cyclic_perms_to_map


def test_cyclic_perm_to_map():
    pass


def test_cyclic_perms_to_map():
    pass


if __name__ == '__main__':
    pytest.main(['-vv', __file__])
