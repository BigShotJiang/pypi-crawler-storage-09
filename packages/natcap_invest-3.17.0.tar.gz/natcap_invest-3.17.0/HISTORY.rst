..
  Changes should be grouped under headings for readability.

  InVEST model names:
  - Annual Water Yield
  - Carbon Storage and Sequestration
  - Coastal Blue Carbon
  - Coastal Vulnerability
  - Crop Pollination
  - Crop Production
  - DelineateIt
  - Forest Carbon Edge Effect
  - Globio
  - Habitat Quality
  - HRA
  - NDR
  - RouteDEM
  - Scenario Generator
  - Scenic Quality
  - SDR
  - Seasonal Water Yield
  - Urban Cooling
  - Urban Flood Risk
  - Urban Nature Access
  - Urban Stormwater Retention
  - Visitation: Recreation and Tourism
  - Wave Energy
  - Wind Energy

  Workbench fixes/enhancements:
  - Workbench

  Everything else:
  - General

  Updates worth drawing extra attention to (minor/major releases only):
  - Highlights

  Each release section has a heading underlined with ``---``.
  Within a release section, underline group headings with ``===``.

  For example:

  Unreleased Changes
  ------------------
  General
  =======
  * Updated something.

  Wind Energy
  ===========
  * Fixed something.

  The order of groups should be as follows:
  1. Highlights
  2. General
  3. Workbench
  4. Plugins
  5. InVEST model A
  6. ...
  7. InVEST model Z (model names should be sorted A-Z)


..
  Unreleased Changes
  ------------------

3.17.0 (2025-10-16)
-------------------

Highlights
==========
* InVEST now supports remote path inputs for publicly accessible data. When a
  geospatial remote path is input into an InVEST model the model will stream
  only the necessary extents. Supporting remote paths across InVEST required
  the following model changes:

  * **Wave Energy** now expects the base data to be provided as a CSV table
    that points to the vector and binary filepaths, rather than a directory.
  * **SWY** replaced the model inputs ``et0_dir`` and ``precip_dir`` with
    CSV inputs.
  * **Crop Production** now takes multiple CSV tables instead of a model
    data directory. These tables map each crop name to the corresponding
    data input.
* The Wind Energy model now requires an AOI, land polygon, and minimum and
  maximum distance values. This greatly simplifies the User Interface
  experience and the model code.
* Each InVEST model's ``execute`` function now returns a dictionary summarizing all
  output files produced by the model. This is standardized by each model
  using the new ``FileRegistry`` class to create and track the filepaths
  of their outputs, as defined in the ``ModelSpec``. This may be used to
  access model results programmatically for subsequent data processing.

General
=======
* Added support for remote paths to raster, vector, and CSVs inputs. URI
  schemes like ``https://``, ``gs://``, ``s3://`` are mapped to GDAL VSI
  handlers. Archive schemes (zip, gzip, tar) can be prefixed onto the scheme
  with a ``+``, for instance, ``zip+https://``. Input paths get converted to
  GDAL-compatible VSI paths (e.g. ``/vsizip//vsicurl/``) before validating
  or executing the model.
  (`#2077 <https://github.com/natcap/invest/issues/2077>`_)
* Added a ``ModelSpec.get_output`` method to access items in ``ModelSpec.outputs``
  using the ``id`` property of the ``Output``.
  (`#2138 <https://github.com/natcap/invest/issues/2138>`_)
* A new module ``natcap.invest.file_registry`` exposes the ``FileRegistry`` class.
  All models now use this to create and track the filepaths of their outputs.
  (`#2124 <https://github.com/natcap/invest/issues/2124>`_)
* The ``execute`` function of each invest model now returns a dictionary
  summarizing all output files produced by the model. It maps output IDs (found
  in the model's ``MODEL_SPEC``) to the absolute paths where those outputs were
  created. This may be used to access model results programmatically for subsequent
  data processing. (`#2124 <https://github.com/natcap/invest/issues/2124>`_)
* Fixed a bug where datastacks missing the ``invest_version`` attribute could not be
  opened. Additionally, new datastacks created with InVEST will no longer include
  an ``invest_version``, since tying a datastack to a specific version of InVEST is
  unnecessary. (`#2092 <https://github.com/natcap/invest/issues/2092>`_)
* Added a ``ModelSpec.setup`` method which performs boilerplate setup and
  preprocessing before a model run. This method is now used in every model's
  ``execute`` function. (`#1451 <https://github.com/natcap/invest/issues/1451>`_)
* Added a ``preprocess`` method to each ``spec.Input`` class, which preprocesses
  values of that type in a standard way.
  (`#1451 <https://github.com/natcap/invest/issues/1451>`_)
* Added ``ModelSpec.execute`` that calls the model's ``execute`` function and
  then optionally performs the setup and post-processing that is done when a
  model is executed via the CLI. This is to make that functionality (such as
  setting up a log file in the workspace, and generating metadata for results)
  available to python API users without going through the CLI.
  (`#1451 <https://github.com/natcap/invest/issues/1451>`_)
* Added a page to the API documentation describing how to run InVEST through
  the supplied docker container, and also through Apptainer/Singularity.
  (`#2171 <https://github.com/natcap/invest/issues/2171>`_)

Plugins
=======
* Fixed bugs where some errors during plugin installation would crash
  the Workbench. Specifically, if the plugin was installed but could not
  import. (`#2071 <https://github.com/natcap/invest/issues/2071>`_)
  (`#2207 <https://github.com/natcap/invest/issues/2207>`_)
* If plugin installation fails, the Workbench now cleans up any
  leftover, unusable micromamba environments.
  (`#2104 <https://github.com/natcap/invest/issues/2104>`_)
* In the Workbench, Python log messages emitted by a plugin model will receive
  the same styling as core invest models.
  (`#2130 <https://github.com/natcap/invest/issues/2130>`_)

Annual Water Yield
==================
* The discount rate parameter was previously incorrectly restricted to the
  range [0, 100]. Now there is no minimum or maximum value.
  (`#2160 <https://github.com/natcap/invest/issues/2160>`_)

Carbon
======
* The discount rate and price change parameters were previously incorrectly
  restricted to the range [0, 100]. Now there is no minimum or maximum value.
  (`#2160 <https://github.com/natcap/invest/issues/2160>`_)

Coastal Blue Carbon
===================
* The intermediate outputs ``aligned-lulc-baseline-[YEAR].tif`` and
  ``aligned-lulc-snapshot-[YEAR].tif`` have been renamed to ``aligned-lulc-[YEAR].tif``.
* The discount rate and price change parameters were previously incorrectly
  restricted to the range [0, 100]. Now there is no minimum or maximum value.
  (`#2160 <https://github.com/natcap/invest/issues/2160>`_)

Coastal Vulnerability
=====================
* The WWIII ``v10pct_[SECTOR]`` field was incorrectly documented as a unitless
  percent; this has been corrected to show that it is a numeric input with
  units of meters/second.

Crop Production
===============
* The inputs to both Crop Production models have changed in order to support
  remote datasets. Instead of a Model Data Directory, the models now expect
  multiple tables, each of which maps each crop name to its corresponding
  climate bin raster, observed yield raster, nutrient table, percentile yield
  table, or regression yield table.
  (`#2095 <https://github.com/natcap/invest/issues/2095>`_)
* The ``crop`` column headers in both models' result tables have been renamed
  to ``crop_name`` for consistency with model inputs.
  (`#2095 <https://github.com/natcap/invest/issues/2095>`_)

Habitat Quality
===============
* The aligned LULC outputs are no longer named after the original LULC files.
  Instead they are named ``lulc_cur_aligned``, ``lulc_fut_aligned``, and
  ``lulc_bas_aligned``. This is consistent with other models and simplifies the
  model spec and documentation. (`#2127 <https://github.com/natcap/invest/issues/2127>`_)

NDR
===
* Clarified about text documentation for ``load_type_n|p``.
  (`#2116 <https://github.com/natcap/invest/issues/2116>`_).

Seasonal Water Yield
====================
* Replaced the model inputs ``et0_dir`` and ``precip_dir`` with CSV inputs.
  These CSVs must have the columns ``month`` and ``path``, mapping month indexes
  (1-12) to raster paths.
  (`#2096 <https://github.com/natcap/invest/issues/2096>`_)
* Documentation has been updated to reflect that curve number values must be
  greater than 0 and less than or equal to 100.
  (`#2164 <https://github.com/natcap/invest/issues/2164>`_)

Urban Flood Risk Mitigation
===========================
* Documentation has been updated to reflect that curve number values must be
  greater than 0 and less than or equal to 100.
  (`#2164 <https://github.com/natcap/invest/issues/2164>`_)
* Fixed a bug where ``s_max`` would be set to 0 if the curve number was 0,
  causing high runoff values, when a low curve number should indicate lower
  runoff potential. Now setting ``s_max`` to a very high value (100000) when
  curve number is 0 to reflect infinite potential retention so that runoff
  will be 0.
  (`#2165 <https://github.com/natcap/invest/issues/2165>`_)

Visitation: Recreation and Tourism
==================================
* The intermediate predictor JSON outputs now include the file suffix, if provided.

Wave Energy
===========
* The model now expects the base data to be provided as a CSV table that points
  to the vector and binary filepaths, rather than a directory. The sample data
  has been updated to include this table.
  (`#2166 <https://github.com/natcap/invest/issues/2166>`_)

Wind Energy
===========
* Updated Wind Energy model to always require an AOI, Land Polygon, and Minimum
  and Maximum Distance values. Since model outputs should only be provided for valid
  wind farm locations, distance-from-shore constraints should always be taken into
  account. (`#1944 <https://github.com/natcap/invest/issues/1944>`_)
* Fixed units for Turbine Rated Power, which were incorrectly listed as kilowatt when
  the model expected megwatt. (`#1944 <https://github.com/natcap/invest/issues/1944>`_)

3.16.2 (2025-08-13)
-------------------

General
=======
* Updated readme to fix broken links, and also add links to repositories
  containing older source code and downloads, for future reference.
  (`#2029 <https://github.com/natcap/invest/issues/2029>`_)
* Fixed a bug in ``build_datastack_archive`` where the raster filepath
  included in a datastack JSON for an ArcGIS GRID would be unusable.
  (`#2103 <https://github.com/natcap/invest/issues/2103>`_)

Workbench
=========
* Fixed a bug where the Workbench showed the incorrect status of a recently
  completed model run. (`#2072 <https://github.com/natcap/invest/issues/2072>`_)
* Fixed a bug where parameter sets containing an argument with a value of 0
  weren't populating the model's UI for that argument.
  (`#2075 <https://github.com/natcap/invest/issues/2075>`_)
* Fixed a bug where there was no visual indication for an invalid switch
  toggle state, which would prohibit running the model. NDR and
  Scenario Generator were the only affected models.
  (`#2074 <https://github.com/natcap/invest/issues/2074>`_)

Urban Cooling
=============
* Model validation now requires that the "UHI effect" is >= 0 degrees Celsius,
  meaning that the urban air temperature is greater than the rural reference
  temperature. (`#2076 <https://github.com/natcap/invest/issues/2076>`_)
* Fixed a bug where ``NoData`` in ``cc`` was not correctly set if the Cooling
  Capacity Calculation Method was set to ``intensity``
  (`#2079 <https://github.com/natcap/invest/issues/2079>`_).

3.16.1 (2025-07-01)
-------------------

General
=======
* Fixed a bug where the ``invest`` CLI could raise a circular
  ``ImportError`` while trying to discover available plugins.
  (`#2012 <https://github.com/natcap/invest/issues/2012>`_).
* Pull requests into the InVEST repository now verify that committers to
  the PR have signed the InVEST Contributor License Agreement, with the results
  viewable as a check alongside the tests that normally execute on GitHub
  Actions. To review and sign the CLA, please visit https://natcap.github.io/invest-cla/.
  (`#1593 <https://github.com/natcap/invest/issues/1593>`_)

Workbench
=========
* Fixed a bug where recent jobs from models that no longer exist, or from
  plugins that are no longer installed, could appear in the Recent Jobs list
  (`#2028 <https://github.com/natcap/invest/issues/2028>`_).
* Fixed a bug where recent jobs from a plugin would remain in the Recent Jobs
  list after the plugin was uninstalled
  (`#1977 <https://github.com/natcap/invest/issues/1977>`_).

Plugins
=======
* The plugin package version is now queried programatically using
  ``importlib`` rather than being read directly from the ``pyproject.toml``
  (`#2025 <https://github.com/natcap/invest/issues/2025>`_).
* Plugin environments are now created using the conda-forge channel only.
  The default channel is excluded (`#1802 <https://github.com/natcap/invest/issues/1802>`_).

NDR
===
* Fixed a bug where model outputs in D8 mode had some nodata holes resulting
  from an incorrect nodata check (`#2055 <https://github.com/natcap/invest/issues/2055>`_).

Pollination
===========
* Fixed a bug where pollination in multiple seasons would not
  use the appropriate pollinator abundance for each season when
  calculating farm results.
  (`#2038 <https://github.com/natcap/invest/issues/2038>`_).

Visitation: Recreation and Tourism
==================================
* Fixed a bug which caused the recreation model to error when using
  numpy>=2.3.0 (`#2032 <https://github.com/natcap/invest/issues/2032>`_).

3.16.0 (2025-06-04)
-------------------

Highlights
==========
* InVEST now supports plugins. The plugins framework allows users to develop
  their own models that can be loaded into the workbench and run like regular
  InVEST models. For more information, see the
  `InVEST API documentation <https://invest.readthedocs.io/en/latest/index.html>`_.
* As part of the plugin release we developed two of our own plugin models.
  One is a wrapper around a python library for spatial downscaling of CMIP6
  climate data (`InVEST GCM Downscaling <https://github.com/natcap/invest-gcm-downscaling>`_).
  The other is a version of the SDR model that takes in the landcover crop
  coefficient input as a spatial raster layer
  (`Sediment Delivery Ratio with USLE C Raster Input <https://github.com/natcap/invest-sdr-usle-c-raster>`_).
* Added a feature to the NDR model that allows the nutrient load to be entered
  as an application rate or as an "extensive"/export measured value.
  Previously, the model's biophysical table expected the ``load_n`` and ``load_p``
  columns to be an "extensive"/export measured value. Now, new columns for both
  nitrogen and phosphorous, ``load_type_n`` and ``load_type_p``, are required
  with expected values of either application-rate or measured-runoff. See the
  `Data Needs section <https://storage.googleapis.com/releases.naturalcapitalproject.org/invest-userguide/latest/en/ndr.html#data-needs>`_ of the NDR User Guide for more details.
* The Wind Energy model no longer returns results as rasters; instead, values
  are written to the output ``wind_energy_points`` shapefile for each point.
  For more details on this check out the Any Decision Record (ADR):
  `ADR-0004: Remove Wind Energy Raster Outputs <https://github.com/natcap/invest/blob/main/doc/decision-records/ADR-0004-Remove-Wind-Energy-Raster-Outputs.md>`_

General
=======
* The workbench and the natcap.invest python package now support plugins.
* Fixed a micromamba command bug in 3.16.0a1 that was calling micromamba
  directly, instead of using the path to the executable
  (`#1965 <https://github.com/natcap/invest/issues/1965>`_). This was
  mistakenly not actually released in 3.16.0a2.
* InVEST now has a file, CITATION.cff, which includes information needed for a
  citation, including a DOI for the 3.16.0 release,
  https://doi.org/10.60793/natcap-invest-3.16.0.
  (`#1548 <https://github.com/natcap/invest/issues/1548>`_)

Workbench
=========
* Fixed a bug where extracting and loading parameters from a datastack archive
  would overwrite data in the extraction location. Now, a new directory
  will be created in the chosen extraction location.
  (`#1996 <https://github.com/natcap/invest/issues/1996>`_)
* Fixed a bug where the "Open" button on the home page would not
  open archived datastacks (.tgz) files.
  (`#1993 <https://github.com/natcap/invest/issues/1993>`_)
* Metadata is now generated for files when creating a datastack (with any
  existing user-added metadata preserved)
  (`#1774 <https://github.com/natcap/invest/issues/1774>`_).

Coastal Blue Carbon
===================
* Updated the Coastal Blue Carbon documentation to clarify what happens when a
  class transitions from a state of accumulation or decay to a No Carbon Change
  ("NCC") state. (`#671 <https://github.com/natcap/invest/issues/671>`_).

HRA
===
* The intermediate simplified vectors will now inherit their geometry type from
  the input vectors, rather than using ``ogr.wkbUnknown``
  (`#1881 <https://github.com/natcap/invest/issues/1881>`_).

NDR
===
* Fixed a bug in the effective retention calculation where nodata pour point
  pixels were mistakenly used as real data. The effect of this change is most
  pronounced along stream edges and should not affect the overall pattern of
  results. (`#1845 <https://github.com/natcap/invest/issues/1845>`_)
* ``stream.tif`` is now saved in the main output folder rather than the
  intermediate folder (`#1864 <https://github.com/natcap/invest/issues/1864>`_).
* Added a feature that allows the nutrient load to be entered as an
  application rate or as an "extensive"/export measured value.
  Previously, the model's biophysical table expected the ``load_[n|p]``
  column to be an "extensive"/export measured value. Now, a new
  column for both nitrogen and phosphorous, ``load_type_[n|p]``, is
  required with expected values of either ``application-rate`` or
  ``measured-runoff``. See the Data Needs section of the NDR User
  Guide for more details.
  (`#1044 <https://github.com/natcap/invest/issues/1044>`_).
* Fixed a bug where input rasters (e.g. LULC) without a defined nodata value could
  cause an OverflowError. (`#1904 <https://github.com/natcap/invest/issues/1904>`_).

Seasonal Water Yield
====================
* ``stream.tif`` is now saved in the main output folder rather than the
  intermediate folder (`#1864 <https://github.com/natcap/invest/issues/1864>`_).

Urban Flood Risk
================
* The raster output ``Runoff_retention.tif`` has been renamed
  ``Runoff_retention_index.tif`` to clarify the difference between it and
  ``Runoff_retention_m3.tif``
  (`#1837 <https://github.com/natcap/invest/issues/1837>`_).

Visitation: Recreation and Tourism
==================================
* user-day variables ``pr_PUD``, ``pr_TUD``, and ``avg_pr_UD`` are calculated
  and written to ``regression_data.gpkg`` even if the Compute Regression
  option is not selected.
  (`#1893 <https://github.com/natcap/invest/issues/1893>`_).

Wind Energy
===========
* The model no longer returns results as rasters; instead, values are
  written to the output ``wind_energy_points`` shapefile for each point
  (`#1698 <https://github.com/natcap/invest/issues/1698>`_).
  Any Decision Record (ADR): `ADR-0004: Remove Wind Energy Raster Outputs <https://github.com/natcap/invest/blob/main/doc/decision-records/ADR-0004-Remove-Wind-Energy-Raster-Outputs.md>`_
* The output ``wind_energy_points.shp`` no longer returns Harvested or
  Valuation-related values for points that are invalid wind farm locations
  due to depth or distance constraints
  (`#1699 <https://github.com/natcap/invest/issues/1699>`_).


3.16.0a2 (2025-05-28)
---------------------

General
=======
* Fixed a micromamba command bug in 3.16.0a1 that was calling micromamba
  directly, instead of using the path to the executable
  (`#1965 <https://github.com/natcap/invest/issues/1965>`_).


3.16.0a1 (2025-05-28)
---------------------

General
=======
* The workbench and the natcap.invest python package now support plugins.

Workbench
=========
* Metadata is now generated for files when creating a datastack (with any
  existing user-added metadata preserved)
  (`#1774 <https://github.com/natcap/invest/issues/1774>`_).

Coastal Blue Carbon
===================
* Updated the Coastal Blue Carbon documentation to clarify what happens when a
  class transitions from a state of accumulation or decay to a No Carbon Change
  ("NCC") state. (`#671 <https://github.com/natcap/invest/issues/671>`_).

HRA
===
* The intermediate simplified vectors will now inherit their geometry type from
  the input vectors, rather than using ``ogr.wkbUnknown``
  (`#1881 <https://github.com/natcap/invest/issues/1881>`_).

NDR
===
* Fixed a bug in the effective retention calculation where nodata pour point
  pixels were mistakenly used as real data. The effect of this change is most
  pronounced along stream edges and should not affect the overall pattern of
  results. (`#1845 <https://github.com/natcap/invest/issues/1845>`_)
* ``stream.tif`` is now saved in the main output folder rather than the
  intermediate folder (`#1864 <https://github.com/natcap/invest/issues/1864>`_).
* Added a feature that allows the nutrient load to be entered as an
  application rate or as an "extensive"/export measured value.
  Previously, the model's biophysical table expected the ``load_[n|p]``
  column to be an "extensive"/export measured value. Now, a new
  column for both nitrogen and phosphorous, ``load_type_[n|p]``, is
  required with expected values of either ``application-rate`` or
  ``measured-runoff``. See the Data Needs section of the NDR User
  Guide for more details.
  (`#1044 <https://github.com/natcap/invest/issues/1044>`_).
* Fixed a bug where input rasters (e.g. LULC) without a defined nodata value could
  cause an OverflowError. (`#1904 <https://github.com/natcap/invest/issues/1904>`_).

Seasonal Water Yield
====================
* ``stream.tif`` is now saved in the main output folder rather than the
  intermediate folder (`#1864 <https://github.com/natcap/invest/issues/1864>`_).

Urban Flood Risk
================
* The raster output ``Runoff_retention.tif`` has been renamed
  ``Runoff_retention_index.tif`` to clarify the difference between it and
  ``Runoff_retention_m3.tif``
  (`#1837 <https://github.com/natcap/invest/issues/1837>`_).

Visitation: Recreation and Tourism
==================================
* user-day variables ``pr_PUD``, ``pr_TUD``, and ``avg_pr_UD`` are calculated
  and written to ``regression_data.gpkg`` even if the Compute Regression
  option is not selected.
  (`#1893 <https://github.com/natcap/invest/issues/1893>`_).

Wind Energy
===========
* The model no longer returns results as rasters; instead, values are
  written to the output ``wind_energy_points`` shapefile for each point
  (`#1698 <https://github.com/natcap/invest/issues/1698>`_).
  Any Decision Record (ADR): `ADR-0004: Remove Wind Energy Raster Outputs <https://github.com/natcap/invest/blob/main/doc/decision-records/ADR-0004-Remove-Wind-Energy-Raster-Outputs.md>`_
* The output ``wind_energy_points.shp`` no longer returns Harvested or
  Valuation-related values for points that are invalid wind farm locations
  due to depth or distance constraints
  (`#1699 <https://github.com/natcap/invest/issues/1699>`_).


3.15.1 (2025-05-06)
-------------------

General
=======
* Handle exceptions that can arise during ``validation.check_spatial_overlap``
  when a layer's bounding box cannot be transformed to EPSG:4326.
  (`#1849 <https://github.com/natcap/invest/issues/1849>`_).

Workbench
=========
* Fixed a bug that did not allow users to select a folder as the location
  to extract a datastack archive.
  (`#1879 <https://github.com/natcap/invest/issues/1879>`_).
* When a parameter from a previous model run is changed, the model status
  indicator (e.g., the "Model Complete" notice) is cleared to help prevent
  confusion about which parameters went into the most recent model run
  (`#1655 <https://github.com/natcap/invest/issues/1655>`_).

Crop Production
===============
* Both the Percentile and Regression models now issue a warning if any LULC
  code in the LULC raster is not present in the landcover to crop table, or if
  any LULC code in the landcover to crop table is not present in the LULC
  raster (`#925 <https://github.com/natcap/invest/issues/925>`_).
* The Regression model now correctly validates crop names against the existence
  of a corresponding regression yield table
  (`#1723 <https://github.com/natcap/invest/issues/1723>`_).

Seasonal Water Yield
====================
* Fixed bug in quickflow calculation where `NoData` values in precipitation
  were being incorrectly converted to 0's
  (`#1592 <https://github.com/natcap/invest/issues/1592>`_).

Wind Energy
===========
* Fixed a bug where the model would error if no AOI was provided when run from
  the workbench or from a datastack file where the value for 'aoi_vector_path'
  was an empty string. (`#1900 <https://github.com/natcap/invest/issues/1900>`_)


3.15.0 (2025-04-03)
-------------------
Highlights
==========
* Multiple models now use **per-hectare** units in their raster outputs. Prior
  to this update, these rasters reported **per-pixel** values. This change
  affects the following models:

  * Carbon
  * Crop Production
  * Forest Carbon Edge Effect
  * NDR
  * SDR
* NDR, SDR, and Seasonal Water Yield now support the D8 routing algorithm
  in addition to MFD.
* Visitation: Recreation and Tourism model now includes Twitter data.
* InVEST model outputs now include metadata. Open the '.yml' files
  in a text editor to read and add to the metadata.

General
=======
* Fixed an issue where a user's PROJ_DATA environment variable could
  trigger a RuntimeError about a missing proj.db file.
  https://github.com/natcap/invest/issues/1742
* Now testing and building against Python 3.13.
  No longer testing and building with Python 3.8, which reached EOL.
  https://github.com/natcap/invest/issues/1755
* All InVEST model output data now include metadata sidecar files.
  These are '.yml' files with the same basename as the dataset they
  describe. https://github.com/natcap/invest/issues/1662
* InVEST's Windows binaries are now distributed once again with a valid
  signature, signed by Stanford University.
  https://github.com/natcap/invest/issues/1580
* InVEST's macOS disk image is now distributed once again with a valid
  signature, signed by Stanford University.
  https://github.com/natcap/invest/issues/1784
* The natcap.invest python package now officially supports linux.
  manylinux wheels will be available on PyPI.
  (`#1730 <https://github.com/natcap/invest/issues/1730>`_)
* Removed the warning about ``gdal.UseExceptions()``.
  Python API users should still call ``gdal.UseExceptions()``, but no
  longer need to do so before importing ``natcap.invest``.
  https://github.com/natcap/invest/issues/1702

Workbench
=========
* Auto-scrolling of log output is halted on user-initiated scrolling,
  enabling easier inspection of log output while a model is running
  (`InVEST #1533 <https://github.com/natcap/invest/issues/1533>`_).
* Fixed a bug where toggle inputs would fail to respond if multiple tabs
  of the same model were open.
  https://github.com/natcap/invest/issues/1842

Annual Water Yield
==================
* Fixed an issue where the model would crash if the valuation table was
  provided, but the demand table was not.  Validation will now warn about
  this, and the ``MODEL_SPEC`` has been improved to reflect that this table
  is now required when doing valuation.
  https://github.com/natcap/invest/issues/1769

Carbon
======
* Updated styling of the HTML report generated by the carbon model, for
  visual consistency with the Workbench (`InVEST #1732
  <https://github.com/natcap/invest/issues/1732>`_).
* Raster outputs that previously contained per-pixel values (e.g., t/pixel)
  now contain per-hectare values (e.g., t/ha). (`InVEST #1270
  <https://github.com/natcap/invest/issues/1270>`_).
* Removed the REDD scenario and updated the naming of the Current and
  Future scenarios to Baseline and Alternate, respectively, to better
  indicate that users are not limited to comparing present and future.
  (`InVEST #1758 <https://github.com/natcap/invest/issues/1758>`_).
* Changed output filename prefixes from ``tot_c`` to ``c_storage`` and
  ``delta`` to ``c_change``. (`InVEST #1825
  <https://github.com/natcap/invest/issues/1825>`_).
* Fixed bug where discount rate and annual price change were incorrectly
  treated as ratios instead of percentages. (`InVEST #1827
  <https://github.com/natcap/invest/issues/1827>`_).

Coastal Blue Carbon
===================
* The ``code`` column in the model's biophysical table input, as well as
  the ``code`` column in the preprocessor's LULC lookup table input and
  ``carbon_pool_transient_template`` output, have been renamed ``lucode``,
  for consistency with other InVEST models (`InVEST #1249
  <https://github.com/natcap/invest/issues/1249>`_).

Crop Production
===============
* Raster outputs that previously contained per-pixel values (e.g., t/pixel)
  now contain per-hectare values (e.g., t/ha). This change affects both
  the Percentile and Regression models (`InVEST #1270
  <https://github.com/natcap/invest/issues/1270>`_).

Forest Carbon Edge Effect
=========================
* Raster outputs that previously contained per-pixel values (e.g., t/pixel)
  now contain per-hectare values (e.g., t/ha). (`InVEST #1270
  <https://github.com/natcap/invest/issues/1270>`_).

Habitat Quality
===============
* The ``lulc`` column in the sensitivity table input, and the ``lulc_code``
  column in the rarity table outputs, have been renamed ``lucode``, for
  consistency with other InVEST models (`InVEST #1249
  <https://github.com/natcap/invest/issues/1249>`_).
* The model now expects the maximum threat distance (``max_dist`` in the
  threats table) to be specified in ``m`` instead of ``km`` (`InVEST #1252
  <https://github.com/natcap/invest/issues/1252>`_).
* Adjusted total habitat degradation calculation to calculate degradation
  for each threat and create intermediate degradation rasters. Total
  degradation is now calculated using these individual threat degradation
  rasters.
  https://github.com/natcap/invest/issues/1100

NDR
===
* Align rasters to the grid of the DEM raster
  (`#1488 <https://github.com/natcap/invest/issues/1488>`_).
* Raster outputs that previously contained per-pixel values (e.g., kg/pixel)
  now contain per-hectare values (e.g., kg/ha). (`InVEST #1270
  <https://github.com/natcap/invest/issues/1270>`_).
* Made the runoff proxy index calculation more robust by allowing users to
  specify the average runoff proxy, preventing normalization issues across
  different climate scenarios and watershed selections.
  https://github.com/natcap/invest/issues/1741
* D8 routing is now supported in addition to MFD
  (`#1440 <https://github.com/natcap/invest/issues/1440>`_).

Scenario Generator
==================
* Updated the output CSV columns: Renamed `lucode` column `original lucode`
  to clarify that it contains the original, to-be-converted, value(s). Added
  `replacement lucode` column, containing the LULC code to which habitat was
  converted during the model run.
  https://github.com/natcap/invest/issues/1295

Scenic Quality
==============
* Fixed a bug where the visibility raster could be incorrectly set to 1
  ('visible') if the DEM value was within floating point imprecision of the
  DEM nodata value (`#1859 <https://github.com/natcap/invest/issues/1859>`_).

SDR
===
* Raster outputs that previously contained per-pixel values (e.g., t/pixel)
  now contain per-hectare values (e.g., t/ha). (`InVEST #1270
  <https://github.com/natcap/invest/issues/1270>`_).
* D8 routing is now supported in addition to MFD
  (`#1440 <https://github.com/natcap/invest/issues/1440>`_).

Seasonal Water Yield
====================
* D8 routing is now supported in addition to MFD
  (`#1440 <https://github.com/natcap/invest/issues/1440>`_).

Urban Cooling
=============
* Align rasters to the grid of the LULC raster, rather than the ET0 raster
  (`#1488 <https://github.com/natcap/invest/issues/1488>`_).
* Updated the documentation for the ``mean_t_air`` attribute of the
  ``buildings_with_stats.shp`` output to clarify how the value is
  calculated.  https://github.com/natcap/invest/issues/1746
* Fixed bug in the calculation of Cooling Capacity (CC) provided by parks,
  where the CC Index was not being properly incorporated.
  https://github.com/natcap/invest/issues/1726

Urban Stormwater Retention
==========================
* Fixed a bug causing ``inf`` values in volume outputs because nodata
  values were not being set correctly (`InVEST #1850
  <https://github.com/natcap/invest/issues/1850>`_).

Visitation: Recreation and Tourism
==================================
* Added a database of geotagged tweets to support calculating
  twitter-user-days (TUD) as proxy for visitation rates. The model now calculates
  photo-user-days (PUD) and TUD and uses their average as the response
  variable in the regression model. Please refer to the User's Guide for
  more details on the regression model.
* Output data were updated to support the new TUD results, and vector outputs
  are now in GeoPackage format instead of ESRI Shapefile.
* Regression coefficients are still listed in a summary text file, and are now
  also included in a tabular output: "regression_coefficients.csv".

Wind Energy
===========
* Fixed a bug that could cause the Workbench to crash when running the Wind
  Energy model with ``Taskgraph`` logging set to ``DEBUG`` (`InVEST #1497
  <https://github.com/natcap/invest/issues/1497>`_).


3.14.3 (2024-12-19)
-------------------
* General
    * InVEST has been updated to build against numpy 2.
      https://github.com/natcap/invest/issues/1641
    * Updating validation to handle a change in exceptions raised by GDAL in
      ``pygeoprocessing.get_raster_info`` and
      ``pygeoprocessing.get_vector_info``.
      https://github.com/natcap/invest/issues/1645
    * The scripting page of the InVEST API documentation has been updated to
      reflect changes in how InVEST is installed on modern systems, and also to
      include images of the InVEST workbench instead of just broken links.
      https://github.com/natcap/invest/issues/1660
    * Updated translations for Spanish and Chinese
    * natcap.invest now works with (and requires) ``gdal.UseExceptions``. A
      ``FutureWarning`` is raised on import if GDAL exceptions are not enabled.
    * Fixed an issue on Windows where GDAL fails to find its DLLs due to
      an interfering GDAL installation on the PATH, such as from anaconda.
      https://github.com/natcap/invest/issues/1643
    * Improved error handling of NA values in raster reclassification to provide
      a more descriptive message.
* Workbench
    * Several small updates to the model input form UI to improve usability
      and visual consistency (https://github.com/natcap/invest/issues/912).
    * Fixed a bug that caused the application to crash when attempting to
      open a workspace without a valid logfile
      (https://github.com/natcap/invest/issues/1598).
    * Fixed a bug that was allowing readonly workspace directories on Windows
      (https://github.com/natcap/invest/issues/1599).
    * Fixed a bug that, in certain scenarios, caused a datastack to be saved
      with relative paths when the Relative Paths checkbox was left unchecked
      (https://github.com/natcap/invest/issues/1609).
    * Improved error handling when a datastack cannot be saved with relative
      paths across drives (https://github.com/natcap/invest/issues/1608).
    * The InVEST changelog now displays in the Workbench the first time a new
      version is launched (https://github.com/natcap/invest/issues/1368).
* Coastal Vulnerability
    * Fixed a regression where an AOI with multiple features could raise a
      TypeError after intersecting with the landmass polygon.
      https://github.com/natcap/invest/issues/1657
* Forest Carbon Edge Effects
    * Updating vector reprojection to allow partial reprojection.  Related to
      https://github.com/natcap/invest/issues/1645
* Habitat Quality
    * Access raster is now generated from the reprojected access vector
      (https://github.com/natcap/invest/issues/1615).
    * Rarity values are now output in CSV format (as well as in raster format)
      (https://github.com/natcap/invest/issues/721).
    * Improved error handling when there is a missing LULC value in the
      sensitivity table (https://github.com/natcap/invest/issues/1671).
* Pollination
    * Fixed an issue with nodata handling that was causing some outputs to be
      filled either with the float32 value for positive infinity, or else with
      a value very close to it. https://github.com/natcap/invest/issues/1635
    * While working on https://github.com/natcap/invest/issues/1635, we also
      updated the stated dtype of most pollination model outputs to be float32
      instead of the float64 dtype that was being assumed previously.  This
      will result in smaller output filesizes with minimal loss of precision.
* Seasonal Water Yield
    * Added support for zero padding in month numbers in ET and precipitation
      file names (i.e., users can now name their file Precip_01.tif).
      (https://github.com/natcap/invest/issues/1166)
    * Fixed a bug where ``numpy.nan`` pixel values would not be correctly
      detected as nodata in local recharge and baseflow routing functions.
      (https://github.com/natcap/invest/issues/1705)
* Urban Flood Risk
    * Fields present on the input AOI vector are now retained in the output.
      (https://github.com/natcap/invest/issues/1600)
* Urban Nature Access
    * The model now works as expected when the user provides an LULC raster
      that does not have a nodata value defined.
      https://github.com/natcap/invest/issues/1293

3.14.2 (2024-05-29)
-------------------
* General
    * Validation now covers file paths contained in CSVs. CSV validation
      will fail if the files listed in a CSV fail to validate.
      https://github.com/natcap/invest/issues/327
    * We have updated validation in several ways that will improve the
      developer experience of working with InVEST models, and we hope will also
      improve the user experience:

      * Symbols in conditional requirement expressions now represent the values
        of parameters instead of whether the value of the parameter is
        sufficient.  If a symbol is not present in ``args`` as a key, the
        symbol will have a value of ``False``.  This allows for value-based
        comparisons, which is useful in models that have overlapping modes of
        operation. https://github.com/natcap/invest/issues/1509
      * Vector fields, CSV rows/columns and the 1st level of directory
        contents may now all be conditionally required based on a python
        expression.
      * Under certain circumstances, validation may return more warnings than
        before. This specifically applies to model inputs that have conditional
        requirement expressions where their expression evaluates to ``False``,
        and the user has provided a value for this parameter.  Previous
        versions of InVEST would skip these parameters' type-specific
        validation. Now, these parameters will be validated with their
        type-specific validation checks.
    * Add support for latest GDAL versions; remove test-specific constraint on
      GDAL versions from invest requirements.
      https://github.com/natcap/invest/issues/916
    * Updated to Cython 3 (https://github.com/natcap/invest/issues/556)
* Annual Water Yield
    * Added the results_suffix to a few intermediate files where it was
      missing. https://github.com/natcap/invest/issues/1517
* Coastal Blue Carbon
    * Updated model validation to prevent the case where a user provides only
      one snapshot year and no analysis year
      (`#1534 <https://github.com/natcap/invest/issues/1534>`_).
      Also enforces that the analysis year, if provided, is greater than the
      latest snapshot year. An analysis year equal to the latest snapshot year
      is no longer allowed.
* Coastal Vulnerability
    * Fixed a bug in handling ``nan`` as the nodata value of the bathymetry
      raster. ``nan`` pixels will now be propertly ignored before calculating
      mean depths along fetch rays.
      https://github.com/natcap/invest/issues/1528
* HRA
    * Fixed a bug where habitat and stressor vectors were not being rasterized
      with the `ALL_TOUCHED=TRUE` setting.
* Scenic Quality
    * Fixed an issue with viewshed calculations where some slight numerical
      error was introduced on M1 Macs, but not on x86-based computers. This
      numerical error was leading to slightly different visibility results.
      https://github.com/natcap/invest/issues/1562
* SDR
    * Fixed an issue encountered in the sediment deposition function where
      rasters with more than 2^32 pixels would raise a cryptic error relating
      to negative dimensions. https://github.com/natcap/invest/issues/1431
    * Optimized the creation of the summary vector by minimizing the number of
      times the target vector needs to be rasterized.
* Seasonal Water Yield
    * Fixed an issue with the precip directory units. Units for these input
      rasters are now correctly stated as mm/month.
      https://github.com/natcap/invest/issues/1571
    * Fixed an issue where the monthly quickflow values were being summed over
      a block area and not summed pixelwise. This caused the quickflow
      output ``QF.tif`` to have malformed values.
      https://github.com/natcap/invest/issues/1541
* Wind Energy
    * Fixed a bug where some number inputs were not being properly cast to
      ``float`` or ``int`` types. If the inputs happened to be passed as
      a ``str`` this caused unintended side effects such as a concatenation
      error. (https://github.com/natcap/invest/issues/1498)
* Urban Nature Access
    * Fixed a ``NameError`` that occurred when running the model using
      search radii defined per population group with an exponential search
      kernel. https://github.com/natcap/invest/issues/1502
    * Fixed an issue where Urban Nature Access would crash if an administrative
      boundary geometry did not overlap any people in the population raster.
      https://github.com/natcap/invest/issues/1503
    * Fixed an issue where validation was failing to catch missing values in
      the uniform search radius args key when using uniform search radii.
      https://github.com/natcap/invest/issues/1509
    * Fixed an issue where the output administrative units vector's
      ``Pund_adm`` and ``Povr_adm`` fields representing undersupplied and
      oversupplied populations, respectively, had values of 0 when running the
      model with search radii defined per population group.  The output
      administrative units vector now has the correct values for these fields,
      consistent with the user's guide chapter.
      https://github.com/natcap/invest/issues/1512
    * Fixed an issue where certain nodata values were not being handled
      correctly, leading to pixel values of +/- infinity in the urban nature
      balance output raster.  https://github.com/natcap/invest/issues/1519
    * Fixed an issue where an LULC raster without a nodata value would
      always raise in exception during reclassification.
      https://github.com/natcap/invest/issues/1539

3.14.1 (2023-12-18)
-------------------
* General
    * In advance of the numpy 2.0 release, function calls to ``numpy.product``
      have been replaced with ``numpy.prod``.
      https://github.com/natcap/invest/issues/1410
    * Add support for python 3.11 (`#1103 <https://github.com/natcap/invest/issues/1103>`_)
    * Adding a docker container that is built on each commit where a change to
      model code, requirements, or the docker configuration has been made.
      https://github.com/natcap/invest/issues/1115
    * Vector geometry types will now be validated for all models
      (`#1374 <https://github.com/natcap/invest/issues/1374>`_)
    * Datastack archives will now be correctly extracted
      (`#1308 <https://github.com/natcap/invest/issues/1308>`_)
    * Validation of tables has been improved and standardized, which should
      result in more readable validation errors.
      (`#1379 <https://github.com/natcap/invest/issues/1379>`_)
    * Updated to ``pygeoprocessing`` 2.4.2. This includes an update to
      ``pygeoprocessing.zonal_statistics``, which is now more correct on certain
      edge cases. Aggregated model results may change slightly.
    * Removed the ``utils`` functions ``array_equals_nodata``,
      ``exponential_decay_kernel_raster``, and ``gaussian_decay_kernel_raster``,
      which were obsoleted by new ``pygeoprocessing`` features.
    * Version metadata at import time is now fetched with
      ``importlib.metadata`` instead of ``pkg_resources``.
      (`#1442 <https://github.com/natcap/invest/issues/1442>`_)
    * The API docs logo has been updated to use the latest version of the
      InVEST logo. (`#1463 <https://github.com/natcap/invest/issues/1463>`_)
* Workbench
    * Fixed a broken "Find my logfiles" button on MacOS.
      https://github.com/natcap/invest/issues/1452
* Coastal Vulnerability
    * Fixed a bug where the model would crash when processing a float type
      bathymetry raster with no nodata value.
      https://github.com/natcap/invest/issues/992
* Habitat Quality
    * Updated the threat table column description to clarify that the threat
      table columns: ``cur_path``, ``fut_path``, and ``base_path`` are meant
      to be file system path strings.
      https://github.com/natcap/invest/issues/1455
* HRA
    * Fixed an issue preventing the HRA criteria table from loading when the
      table was UTF-8 encoded with a Byte-Order Marker.
      https://github.com/natcap/invest/issues/1460
    * Fixed an issue with the cross-OS loading of InVEST datastack files.
      https://github.com/natcap/invest/issues/1065
    * Fixed an issue where habitats and stressors in the criteria table were
      not being lowercased causing a comparison issue against values from the
      info table that were being lowercased.
      https://github.com/natcap/invest/issues/1467
* NDR
    * Fixing an issue where minor geometric issues in the watersheds input
      (such as a ring self-intersection) would raise an error in the model.
      https://github.com/natcap/invest/issues/1412
    * Fixed a task dependency issue where NDR would crash because of a race
      condition when run with ``n_workers > 0``.
      https://github.com/natcap/invest/issues/1426
    * Fixed an issue in NDR's effective retention where, on rasters with more
      than 2^31 pixels, the model would crash with an error relating to a
      negative (overflowed) index. https://github.com/natcap/invest/issues/1431
* Pollination
    * Fixed a regression where nodata values were not being properly compared.
      This was only an issue in some development builds after 3.14.0.
      (`#1458 <https://github.com/natcap/invest/issues/1458>`_)
    * Replaced custom kernel implementation with ``pygeoprocessing.kernels``.
      Convolution results may be slightly different (more accurate).
* SDR
    * Fixed an issue with SDR's sediment deposition where large regions would
      become nodata in cases where the DEM has valid data but other inputs
      (LULC, erosivity, erodibility) did not have valid pixels.  Now, all
      raster inputs are mutually masked so that only those pixel stacks
      continue through to the model where all pixels in the stack are
      non-nodata. (`#911 <https://github.com/natcap/invest/issues/911>`_)
    * RKLS, USLE, avoided erosion, and avoided export rasters will now have
      nodata in streams (`#1415 <https://github.com/natcap/invest/issues/1415>`_)
    * Fixed an issue in SDR's sediment deposition where, on rasters with more
      than 2^31 pixels, the model would crash with an error relating to a
      negative (overflowed) index. https://github.com/natcap/invest/issues/1431
* Seasonal Water Yield
    * Fixed an issue in Seasonal Water Yield's baseflow routing and local
      recharge functions where, on rasters with more than 2^31 pixels, the
      model would crash with an error relating to a negative (overflowed)
      index. https://github.com/natcap/invest/issues/1431
* Urban Cooling
    * Fixed a bug where model would error out if any feature in the buildings
      vector was missing a geometry; now they will be skipped
      (`#1401 <https://github.com/natcap/invest/issues/1401>`_)
* Wind Energy
    * Fixed a bug where model would error when the grid points path was empty
      (`#1417 <https://github.com/natcap/invest/issues/1417>`_)


3.14.0 (2023-09-08)
-------------------
* General
    * Fixed a bug in the CLI where ``invest getspec --json`` failed on
      non-json-serializable objects such as ``pint.Unit``.
      https://github.com/natcap/invest/issues/1280
    * A new directory at `./doc/decision-records` has been created for
      "Architecture/Any Decision Records", which will serve as a record of
      nontrivial decisions that were made to InVEST and why.  This is
      intended for reference by our science and software teams, and also by
      the community at large when inquiring about a nontrivial change.
      https://github.com/natcap/invest/issues/1079
    * Updated the package installation instructions in the API docs for clarity
      and also to highlight the ease of installation through ``conda-forge``.
      https://github.com/natcap/invest/issues/1256
    * ``utils.build_lookup_from_csv`` has been deprecated and its functionality
      has been merged into ``utils.read_csv_to_dataframe``
      (`#1319 <https://github.com/natcap/invest/issues/1319>`_),
      (`#1327 <https://github.com/natcap/invest/issues/1327>`_)
    * Standardized on keeping the ``execute`` and ``validate`` functions
      orthogonal. Now no models call ``validate`` from ``execute``. This
      affected AWY, CV, UFRM, Wave Energy, and Wind Energy.
      (`#1373 <https://github.com/natcap/invest/issues/1373>`_)
    * Improved the validation message that is returned when not all spatial
      inputs overlap (`#502 <https://github.com/natcap/invest/issues/502>`_)
    * Standardized the name and location of the taskgraph cache directory for
      all models. It is now called ``taskgraph_cache`` and located in the top
      level of the workspace directory.
      (`#1230 <https://github.com/natcap/invest/issues/1230>`_)
    * InVEST is now distributed under the Apache 2.0 License.
* Workbench
    * Fixed a bug where sampledata downloads failed silently (and progress bar
      became innacurate) if the Workbench did not have write permission to
      the download location. https://github.com/natcap/invest/issues/1070
    * The workbench app is now distributed with a valid code signature
      (`#727 <https://github.com/natcap/invest/issues/727>`_)
    * Changing the language setting will now cause the app to relaunch
      (`#1168 <https://github.com/natcap/invest/issues/1168>`_)
    * Closing the main window will now close any user's guide windows that are
      open. Fixed a bug where the app could not be reopened after closing.
      (`#1258 <https://github.com/natcap/invest/issues/1258>`_)
    * Fixed a bug where invalid metadata for a recent run would result
      in an uncaught exception.
      (`#1286 <https://github.com/natcap/invest/issues/1286>`_)
    * Middle clicking an InVEST model tab was opening a blank window. Now
      middle clicking will close that tab as expected.
      (`#1261 <https://github.com/natcap/invest/issues/1261>`_)
    * Updated InVEST logo to use new version with registered trademark symbol.
      (`InVEST TM and Logo Use Policy
      <https://naturalcapitalproject.stanford.edu/invest-trademark-and-logo-use-policy>`_)
    * InVEST is licensed using a permissive open source license. But we have
      decided to add back the license and agreement step to the installer to
      be upfront and explicit about how InVEST is licensed.
* Coastal Blue Carbon
    * Added validation for the transition table, raising a validation error if
      unexpected values are encountered.
      (`#729 <https://github.com/natcap/invest/issues/729>`_)
* Forest Carbon
    * The biophysical table is now case-insensitive.
* HRA
    * Fixed a bug in HRA where the model would error when all exposure and
      consequence criteria were skipped for a single habitat. The model now
      correctly handles this case. https://github.com/natcap/invest/issues/1250
    * Tables in the .xls format are no longer supported. This format was
      deprecated by ``pandas``.
      (`#1271 <https://github.com/natcap/invest/issues/1271>`_)
    * Fixed a bug where vector inputs could be rasterized onto a grid that is
      not exactly aligned with other raster inputs.
      (`#1312 <https://github.com/natcap/invest/issues/1312>`_)
    * Dropped support for Excel (.xlsx) files
      (`#1391 <https://github.com/natcap/invest/issues/1391>`_)
* NDR
    * The contents of the output ``cache_dir`` have been consolidated into
      ``intermediate_outputs``.
    * Fixed a bug where results were calculated incorrectly if the runoff proxy
      raster (or the DEM or LULC) had no nodata value
      (`#1005 <https://github.com/natcap/invest/issues/1005>`_)
* Pollination
    * Several exceptions have been tidied up so that only fieldnames are
      printed instead of the python data structures representing the whole
      table.  https://github.com/natcap/invest/issues/1283
* RouteDEM
    * RouteDEM now allows the user to calculate Strahler Stream Orders, which
      will be written to a new vector in the user's workspace. This stream
      order vector is dependent on the user's Threshold Flow Accumulation value
      and is only available for the D8 routing model.
      https://github.com/natcap/invest/issues/884
    * RouteDEM now allows the user to create a vector of subwatersheds, which
      are written to a new vector in the user's workspace.  This vector is
      dependent on the calculation of Strahler Stream Orders and is only
      available for the D8 routing model. https://github.com/natcap/invest/issues/349
* Scenic Quality
    * The Scenic Quality model will now raise an error when it encounters a
      geometry that is not a simple Point.  This is in line with the user's
      guide chapter.  https://github.com/natcap/invest/issues/1245
    * The Scenic Quality model now supports both uppercase and lowercase
      fieldnames. Leading and trailing spaces are now also stripped for the
      user's convenience. https://github.com/natcap/invest/issues/1276
* SDR
    * Fixed an issue with sediment deposition progress logging that was
      causing the "percent complete" indicator to not progress linearly.
      https://github.com/natcap/invest/issues/1262
    * The contents of the output ``churn_dir_not_for_humans`` have been
      consolidated into ``intermediate_outputs``.
    * We implemented two major functional changes to the InVEST LS Factor
      that significantly affect most outputs of SDR and will bring the LS
      factor output more in line with the outputs of SAGA-GIS's LS Factor.
      A discussion of differences between these two implementations can be
      viewed at https://github.com/natcap/invest/tree/main/doc/decision-records/ADR-0001-Update-SDR-LS-Factor.md.
      The two specific changes implemented are:

        * The LS Factor's on-pixel aspect length is now calculated as
          ``abs(sin(slope)) + abs(cos(slope))``.
        * The LS Factor's upstream contributing area is now calculated as
          an estimate for the specific catchment area, calculated by
          ``sqrt(n_pixels_upstream * pixel_area)``.
* Seasonal Water Yield
    * Fixed a bug where monthy quickflow nodata pixels were not being passed
      on to the total quickflow raster, which could result in negative values
      on the edges (`#1105 <https://github.com/natcap/invest/issues/1105>`_)
    * Removed the GDAL cache size limit on this model, which means that, by
      default, the model will use up to 5% of installed memory.
      https://github.com/natcap/invest/issues/1320
    * Monthly quick flow nodata values will now be preserved instead of being
      set to 0. The old behavior was not well documented and caused some
      confusion when nodata pixels did not line up. It's safer not to fill in
      unknown data. (`#1317 <https://github.com/natcap/invest/issues/1317>`_)
    * Negative monthly quickflow values will now be set to 0. This is because
      very small negative values occasionally result from valid data, but they
      should be interpreted as 0.
      (`#1318 <https://github.com/natcap/invest/issues/1318>`_)
    * In the monthly quickflow calculation, QF_im will be set to 0 on any pixel
      where s_i / a_im > 100. This is done to avoid overflow errors when
      calculating edge cases where the result would round down to 0 anyway.
      (`#1318 <https://github.com/natcap/invest/issues/1318>`_)
    * The contents of the output ``cache_dir`` have been consolidated into
      ``intermediate_outputs``.
* Urban Flood Risk
    * Fixed a bug where the model incorrectly raised an error if the
      biophysical table contained a row of all 0s.
      (`#1123 <https://github.com/natcap/invest/issues/1123>`_)
    * The contents of the output ``temp_working_dir_not_for_humans`` have been
      consolidated into ``intermediate_files``.
    * Biophysical table Workbench validation now warns if there is a missing
      curve number value.
      (`#1346 <https://github.com/natcap/invest/issues/1346>`_)
* Urban Nature Access
    * Urban nature supply outputs have been renamed to add ``percapita`` to the
      filename.

        * In uniform search radius mode, ``urban_nature_supply.tif`` has been
          renamed to ``urban_nature_supply_percapita.tif``.
        * When defining search radii by urban nature class,
          ``urban_nature_supply_lucode_[LUCODE].tif`` has been renamed to
          ``urban_nature_supply_percapita_lucode_[LUCODE].tif``.
        * When defining search radii by population groups,
          ``urban_nature_supply_to_[POP_GROUP].tif`` has been renamed to
          ``urban_nature_supply_percapita_to_[POP_GROUP].tif``.

    * A new output for "Accessible Urban Nature" is created, indicating the
      area of accessible greenspace available to people within the search
      radius, weighted by the selected decay function.  The outputs vary
      slightly depending on the selected execution mode.

        * In uniform search radius mode, a single new output is created,
          ``accessible_urban_nature.tif``.
        * When defining search radii by urban nature class, one new
          output raster is created for each class of urban nature.  These files
          are named ``accessible_urban_nature_lucode_[LUCODE].tif``.
        * When defining search radii for population groups, one new output
          raster is created for each population group.  These files are named
          ``accessible_urban_nature_to_[POP_GROUP].tif``.

    * Urban nature classes can now be defined to occupy a proportion of a
      pixel, such as a park that is semi-developed. This proportion is
      provided through user input as a proportion (0-1) in the
      ``urban_nature`` column of the LULC Attribute Table.  A value of ``0``
      indicates that there is no urban nature in this class, ``0.333``
      indicates that a third of the area of this LULC class is urban nature,
      and ``1`` would indicate that the entire LULC class's area is urban
      nature.  https://github.com/natcap/invest/issues/1180
    * Fixed an issue where, under certain circumstances, the model would raise
      a cryptic ``TypeError`` when creating the summary vector.
      https://github.com/natcap/invest/issues/1350
* Visitation: Recreation and Tourism
    * Fixed a bug where overlapping predictor polygons would be double-counted
      in ``polygon_area_coverage`` and ``polygon_percent_coverage``
      calculations. (`#1310 <https://github.com/natcap/invest/issues/1310>`_)
    * Changed the calculation of ``point_nearest_distance`` metric to match
      the description in the User's Guide. Values are now the distance to the
      centroid of the AOI polygon instead of the distance to the nearest
      edge of the AOI polygon.
      (`#1347 <https://github.com/natcap/invest/issues/1347>`_)
* Wind Energy
    * Updated a misleading error message that is raised when the AOI does
      not spatially overlap another input.
      (`#1054 <https://github.com/natcap/invest/issues/1054>`_)

3.13.0 (2023-03-17)
-------------------
* General
    * During builds of the InVEST documentation, the packages
      ``sphinx-rtd-theme`` and ``sphinx-reredirects`` will be pulled from
      conda-forge instead of PyPI.
      (`#1151 <https://github.com/natcap/invest/issues/1151>`_)
    * The ``invest`` command-line-interface no longer opens a graphical
      interface to InVEST. (`#755 <https://github.com/natcap/invest/issues/755>`_)
    * The classic InVEST user-interface has been removed in favor of the Workbench.
    * Replace the ``ARGS_SPEC`` with ``MODEL_SPEC`` which describes all model
      outputs as well as inputs in a structured format
      (`#596 <https://github.com/natcap/invest/issues/596>`_)
* Workbench
    * Added tooltips to the model tabs so that they can be identified even when
      several tabs are open (`#1071 <https://github.com/natcap/invest/issues/1088>`_)
    * Options' display names will now be shown in dropdown menus
      (`#1217 <https://github.com/natcap/invest/issues/1217>`_)
    * Represent boolean inputs with a toggle switch rather than radio buttons.
    * Includes local versions of the User Guide in English, Spanish, & Chinese.
      https://github.com/natcap/invest/issues/851
* DelineateIt
    * DelineateIt now uses ``pygeoprocessing.routing.extract_streams_d8`` for D8
      stream thresholding. https://github.com/natcap/invest/issues/1143
* Habitat Quality
    * The model now uses an euclidean distance implementation for decaying
      threat rasters both linearly and exponentially. Since InVEST 3.3.0 a
      convolution implementation has been used, which reflected how
      the density of a threat or surrounding threat pixels could have an
      even greater, cumulative impact and degradation over space. However, this
      was never properly documented in the User's Guide and is not the approach
      taken in the publication. The convolution implementation also produced
      degradation and quality outputs that were difficult to interpret.
    * There should be a noticeable runtime improvement from calculating
      euclidean distances vs convolutions.
* HRA
    * Fixed an issue where a cryptic exception was being thrown if the criteria
      table's sections were not spelled exactly as expected.  There is now a
      much more readable error if a section is obviously missing.  Leading and
      trailing whitespace is also now removed from all string fields in the
      criteria table, which should also help reduce the chance of errors.
      https://github.com/natcap/invest/issues/1191
* GLOBIO
    * Deprecated the GLOBIO model
      (`#1131 <https://github.com/natcap/invest/issues/1131>`_)
* RouteDEM
    * RouteDEM now uses ``pygeoprocessing.routing.extract_streams_d8`` for D8
      stream thresholding. https://github.com/natcap/invest/issues/1143
* Scenic Quality
    * Any points over nodata (and therefore excluded from the viewshed
      analysis) will now correctly have their FID reported in the logging.
      https://github.com/natcap/invest/issues/1188
    * Clarifying where the visual quality calculations' disk-based sorting
      cache should be located, which addresses an interesting crash experienced
      by some users on Windows. https://github.com/natcap/invest/issues/1189
* SDR
    * The ``ws_id`` field is no longer a required field in the watershed vector.
      https://github.com/natcap/invest/issues/1201
* Seasonal Water Yield
    * If a soil group raster contains any pixels that are not in the set of
      allowed soil groups (anything other than 1, 2, 3 or 4), a human readable
      exception will now be raised. https://github.com/natcap/invest/issues/1193
* Urban Nature Access
    * Added the Urban Nature Access model to InVEST. The model for urban
      nature access provides a measure of both the supply of urban nature
      and the demand for nature by the urban population, ultimately
      calculating the balance between supply and demand. See the corresponding
      User's Guide chapter for documentation.
* Visitation: Recreation and Tourism
    * Fixed a ``FutureWarning`` when reading in CSVs. This fix does not
      otherwise affect model behavior. https://github.com/natcap/invest/issues/1202


3.12.1 (2022-12-16)
-------------------
* General
    * Fixed a possible path traversal vulnerability when working with datastack
      archives.  This patches CVE-2007-4559, reported to us by Trellix.
      https://github.com/natcap/invest/issues/1113
    * Added Spanish and Chinese translations of user-facing text and an interface
      to switch languages in the workbench UI.
    * Updating descriptions for LULC about text and biophysical table for
      clarity in model specs. https://github.com/natcap/invest/issues/1077
* Workbench
    * Fixed a bug where the Workbench would become unresponsive during an
      InVEST model run if the model emitted a very high volume of log messages.
    * Fixed a bug where the Workbench could crash if there was too much
      standard error emitted from an invest model.
    * Added a new "Save as" dialog window to handle different save options, and
      allow the option to use relative paths in a JSON datastack
      (`#1088 <https://github.com/natcap/invest/issues/1088>`_)
    * Fixed a bug where uncaught exceptions in the React tree would result in
      a blank browser window.
      (`#1119 <https://github.com/natcap/invest/issues/1119>`_)
* Habitat Quality
    * All spatial inputs including the access vector and threat rasters are
      now reprojected to the ``lulc_cur_path`` raster. This fixes a bug where
      rasters with a different SRS would appear to not intersect the
      ``lulc_cur_path`` even if they did. (https://github.com/natcap/invest/issues/1093)
    * Paths in the threats table may now be either absolute or relative to the
      threats table.
* HRA
    * Fixed a regression relative to InVEST 3.9.0 outputs where spatial
      criteria vectors were being rasterized with the ``ALL_TOUCHED=TRUE``
      flag, leading to a perceived buffering of spatial criteria in certain
      cases.  In InVEST 3.9.0, these were rasterized with ``ALL_TOUCHED=FALSE``.
      https://github.com/natcap/invest/issues/1120
    * Fixed an issue with the results table, ``SUMMARY_STATISTICS.csv`` where
      the percentages of high, medium and low risk classifications were not
      correctly reported.
    * Added a column to the ``SUMMARY_STATISTICS.csv`` output table to also
      report the percentage of pixels within each subregion that have no risk
      classification (a risk classification of 0).
* Urban Stormwater Retention
    * Added validation to check that the input soil groups raster has an
      integer data type
* Urban Cooling
    * Updated the text for the ``building_intensity`` column in the biophysical
      table to clarify that the values of this column should be normalized
      relative to one another to be between 0 and 1.



3.12.0 (2022-08-31)
-------------------
* General
    * Update python packaging settings to exclude a few config files and the
      workbench from source distributions and wheels
    * Updating SDR test values due to an update in GDAL's mode resampling
      algorithm. See https://github.com/natcap/invest/issues/905
    * Updated our ``scipy`` requirement to fix a bug where invest crashed
      if a Windows user had a non-Latin character in their Windows username.
* Workbench
    * Fixed a bug where some model runs would not generate a new item
      in the list of recent runs.
    * Enhanced model input forms so that text boxes always show the
      rightmost end of the filepath when they overflow the box.
* Coastal Blue Carbon
    * Fixed a bug where using unaligned rasters in the preprocessor would cause
      an error.  The preprocessor will now correctly align input landcover
      rasters and determine transitions from the aligned rasters.
* Habitat Quality
    * Removed a warning about an undefined nodata value in threat rasters
      because it is okay for a threat raster to have an undefined nodata value.
* HRA
    * Fixed an issue with risk calculations where risk values would be much
      lower than they should be.  Risk values are now correctly calculated.
    * Fixed an issue with risk reclassifications where most pixels would end up
      classified as medium risk.
    * Added an input field to the model to indicate the number of overlapping
      stressors to use in risk reclassification calculations.  This input
      affects the numerical boundaries between high, medium and low risk
      classifications.
    * Various improvements to the model have resulted in a modest (~33%)
      speedup in runtime.
* Coastal Vulnerability
    * Fixed a bug where redundant vertices in the landmass polygon could
      raise an error during shore point creation.
* NDR
    * Added parameters to the sample data to support nitrogen calculations.
    * Effective retention calculations have been reworked so that the source
      code more closely matches the mathematical definition in the NDR User's
      Guide.  There should be no difference in outputs.
* SDR
    * We have made a significant update to the SDR model's outputs described
      here: https://github.com/natcap/peps/blob/main/pep-0010.md.

        * Legacy outputs ``sed_retention_index.tif`` and ``sed_retention.tif``
          have been removed from the model.
        * Two new output rasters have been added, specifically
            * ``avoided_export.tif``, indicating vegetation's contribution to
              reducing erosion on a pixel, as well as trapping of sediment
              originating upslope of the pixel, so that neither of these
              proceed downslope to enter a stream.
            * ``avoided_erosion.tif``, vegetation’s contribution to reducing
              erosion from a pixel.
        * The summary watersheds vector no longer includes the ``sed_retent``
          field and two fields have been added:

            * ``avoid_exp`` representing the sum of avoided export in the
              watershed.
            * ``avoid_eros`` representing the sum of avoided erosion in the
              watershed.
        * Sediment deposition, ``sed_deposition.tif``, has been clarified to
          indicate the sediment that erodes from a pixel goes into the next
          downstream pixel(s) where it is either trapped or exported.  This
          update removes a form of double-counting.
* Urban Flood Risk
    * Validation of the curve number table will now catch missing ``CN_*``
      columns and warn the user about the missing column.


3.11.0 (2022-05-24)
-------------------
* General
    * InVEST Workbench released! A new desktop interface for InVEST models.
    * Add support for python 3.10, and drop support for python 3.7.
    * Fixed a bug where the model window would fail to open when using the
      ``natcap.invest`` package with python 3.9.0 - 3.9.3.
    * ``spec_utils.ETO`` has been renamed to ``spec_utils.ET0`` (with a zero).
    * Updating the ``pyinstaller`` requirement to ``>=4.10`` to support the new
      ``universal2`` wheel architecture offered by ``scipy>=1.8.0``.
    * Now removing leading / trailing whitespaces from table input values as
      well as columns in most InVEST models.
    * Fixing a small bug where drag-and-drop events in the Qt UI were not being
      handled correctly and were being ignored by the UI.
    * Expose taskgraph logging level for the cli with
      ``--taskgraph-log-level``.
    * Fixed bug in validation of ``results_suffix`` so that special characters
      like path separators, etc, are not allowed.
    * Fixed a bug in validation where a warning about non-overlapping spatial
      layers was missing info about the offending bounding boxes.
    * Fixed an issue with usage logging that caused SSL errors to appear in the
      Qt interface logging window.
* Annual Water Yield
    * Fixed a bug where the model would error when the watersheds/subwatersheds
      input was in geopackage format.
* Crop Production
    * Fixed a bug in both crop production models where the model would error if
      an observed yield raster had no nodata value.
* Coastal Vulnerability
    * Fixed a bug that would cause an error if the user's bathymetry layer did
      not have a defined nodata value.  The user's bathymetry layer should now
      be correctly preprocessed with or without a nodata value.
* DelineateIt
    * Watersheds delineated with this tool will now always have a ``ws_id``
      column containing integer watershed IDs for easier use within the routed
      InVEST models.  Existing ``ws_id`` field values in the outlets vector
      will be overwritten if they are present.
* RouteDEM
    * Rename the arg ``calculate_downstream_distance`` to
      ``calculate_downslope_distance``. This is meant to clarify that it
      applies to pixels that are not part of a stream.
* SDR
    * Fixed an issue with SDR where ``f.tif`` might not be recalculated if the
      file is modified or deleted after execution.
    * Fixed an issue in ``sed_deposition.tif`` and ``f.tif`` where pixel values
      could have very small, negative values for ``r_i`` and ``f_i``.  These
      values are now clamped to 0.
    * Added basic type-checking for the ``lucode`` column of the biophysical
      table. This avoids cryptic numpy errors later in runtime.
* Seasonal Water Yield
    * Added an output to the model representing total annual precipitation.
    * Fixed an issue with the documentation for ET0 and Precip directories,
      where a module-specific informational string was being overridden by a
      default value.

3.10.2 (2022-02-08)
-------------------
* General
    * The minimum ``setuptools_scm`` version has been increased to 6.4.0 in
      order to bypass calling ``setup.py`` for version information.  The
      version of this project can now be retrieved by calling ``python -m
      setuptools_scm`` from the project root.
    * Fixed an issue where datastack archives would not include any spatial
      datasets that were linked to in CSV files.  This now works for all models
      except HRA.  If an HRA datastack archive is requested,
      ``NotImplementedError`` will be raised.  A fix for HRA is pending.
    * Pinned ``numpy`` versions in ``pyproject.toml`` to the lowest compatible
      version for each supported python version. This prevents issues when
      ``natcap.invest`` is used in an environment with a lower numpy version
      than it was built with (https://github.com/cython/cython/issues/4452).
* DelineateIt
    * When snapping points to streams, if a point is equally near to more than
      one stream pixel, it will now snap to the stream pixel with a higher
      flow accumulation value. Before, it would snap to the stream pixel
      encountered first in the raster (though this was not guaranteed).
* GLOBIO
    * Gaussian decay kernels are now always tiled, which should result in a
      minor improvement in model runtime when large decay distances are used.
* Habitat Quality:
    * Linear decay kernels are now always tiled, which should result in a minor
      improvement in model runtime, particularly with large decay distances.
* HRA
    * Fixed a bug with how a pandas dataframe was instantiated. This bug did
      not effect outputs though some might notice less trailing zeros in the
      ``SUMMARY_STATISTICS.csv`` output.
* NDR
    * Changed some model inputs and outputs to clarify that subsurface
      phosphorus is not modeled.

        * Removed the inputs ``subsurface_critical_length_p`` and
          ``subsurface_eff_p``
        * Removed the output ``sub_ndr_p.tif``. The model no longer calculates
          subsurface NDR for phosphorus.
        * Removed the output ``sub_load_p.tif``. All pixels in this raster were
          always 0, because the model assumed no subsurface phosphorus movement.
        * Renamed the output ``p_export.tif`` to ``p_surface_export.tif`` to
          clarify that it only models the surface export of phosphorus.
        * Renamed the output ``n_export.tif`` to ``n_total_export.tif`` to
          clarify that it is the total of surface and subsurface nitrogen export.
        * Added the new outputs ``n_surface_export.tif`` and
          ``n_subsurface_export.tif``, showing the surface and subsurface
          components of the total nitrogen export.
        * The aggregate vector output ``watershed_results_ndr.shp`` was changed to
          a geopackage ``watershed_results_ndr.gpkg``.
        * The aggregate vector fields were given more descriptive names, and
          updated corresponding to the changed raster outputs:

            * ``surf_p_ld`` was renamed to ``p_surface_load``
            * ``surf_n_ld`` was renamed to ``n_surface_load``
            * ``p_exp_tot`` was renamed to ``p_surface_export``
            * ``sub_n_ld`` was renamed to ``n_subsurface_load``
            * ``n_exp_tot`` was renamed to ``n_total_export``
            * Added a new field ``n_surface_export``, representing the sum of
              ``n_surface_export.tif``
            * Added a new field ``n_subsurface_export``, representing the sum
              of ``n_subsurface_export.tif``
            * Removed the field ``sub_p_ld``, since ``sub_load_p.tif`` was removed.
* Wind Energy
    * Fixed a bug where distance was masking by pixel distance instead of
      euclidean distance.
    * Renamed the foundation cost label and help info to reflect it is no
      longer measured in Millions of US dollars.
    * Fixed a bug where running valuation with TaskGraph in asynchronous mode
      would cause the model to error.

3.10.1 (2022-01-06)
-------------------
* Urban Stormwater Retention
    * Fixed a bug where this model's sample data was not available via the
      Windows installer.


3.10.0 (2022-01-04)
-------------------
* General
    * Add a ``--language`` argument to the command-line interface, which will
      translate model names, specs, and validation messages.
    * Accept a ``language`` query parameter at the UI server endpoints, which
      will translate model names, specs, and validation messages.
    * Added ``invest serve`` entry-point to the CLI. This launches a Flask app
      and server on the localhost, to support the workbench.
    * Major updates to each model's ``ARGS_SPEC`` (and some related validation)
      to facilitate re-use & display in the Workbench and User's Guide.
    * Standardized and de-duplicated text in ``ARGS_SPEC`` ``about`` and
      ``name`` strings.
    * Update to FontAwesome 5 icons in the QT interface.
    * In response to the deprecation of ``setup.py``-based commands in Python
      3.10, the recommended way to build python distributions of
      ``natcap.invest`` is now with the ``build`` package, and installation
      should be done via ``pip``.  The ``README`` has been updated to reflect
      this change, and this should only be noticeable for those installing
      ``natcap.invest`` from source.
    * A bug has been fixed in ``make install`` so that now the current version
      of ``natcap.invest`` is built and installed.  The former (buggy) version
      of ``make install`` would install whatever the latest version was in your
      ``dist`` folder.
    * Updating the ``taskgraph`` requirement to ``0.11.0`` to resolve an issue
      where modifying a file within a roughly 2-second window would fool
      ``taskgraph`` into believing that the file had not been modified.
    * Fixed a bug where some input rasters with NaN nodata values would go
      undetected as nodata and yield unexpected behavior.
* Annual Water Yield
    * Renamed the Windows start menu shortcut from "Water Yield" to
      "Annual Water Yield".
* Coastal Vulnerability
    * Fixed bug where shore points were created on interior landmass holes
      (i.e. lakes).
    * Added feature to accept raster (in addition to vector) habitat layers.
    * Changed one intermediate output (geomorphology) from SHP to GPKG.
    * Fixed bug where output vectors had coordinates with an unnecessary
      z-dimension. Output vectors now have 2D geometry.
* Crop Pollination
    * Renamed the Windows start menu shortcut from "Pollination" to
      "Crop Pollination".
* Fisheries and Fisheries HST
    * The Fisheries models were deprecated due to lack of use,
      lack of scientific support staff, and maintenance costs.
* Finfish
    * The Finfish model was deprecated due to lack of use,
      lack of scientific support staff, and maintenance costs.
* Habitat Quality
    * Changed how Habitat Rarity outputs are calculated to be less confusing.
      Values now represent a 0 to 1 index where before there could be
      negative values. Now values of 0 indicate current/future LULC not
      represented in baseline LULC; values 0 to 0.5 indicate more
      abundance in current/future LULC and therefore less rarity; values
      of 0.5 indicate same abundance between baseline and current/future
      LULC; values 0.5 to 1 indicate less abundance in current/future LULC
      and therefore higher rarity.
* NDR
    * Added a new raster to the model's workspace,
      ``intermediate_outputs/what_drains_to_stream[suffix].tif``.  This raster
      has pixel values of 1 where DEM pixels flow to an identified stream, and
      0 where they do not.
* Scenario Generator
    * Changed an args key from ``replacment_lucode`` to ``replacement_lucode``.
* Scenic Quality
    * Simplify the ``valuation_function`` arg options. The options are now:
      ``linear``, ``logarithmic``, ``exponential``. The names displayed in the
      UI dropdown will stay the same as before. Datastacks or scripts will need
      to be updated to use the new option values.
    * Renamed the model title from
      "Unobstructed Views: Scenic Quality Provision" to "Scenic Quality".
* SDR
    * Added a new raster to the model's workspace,
      ``intermediate_outputs/what_drains_to_stream[suffix].tif``.  This raster
      has pixel values of 1 where DEM pixels flow to an identified stream, and
      0 where they do not.
* Urban Flood Risk:
    * Fixed broken documentation link in the user interface.
* Urban Stormwater Retention
    * Added this new model
* Visitation: Recreation and Tourism
    * Renamed the Windows start menu shortcut from "Recreation" to
      "Visitation: Recreation and Tourism".
* Wave Energy
    * Rename the ``analysis_area_path`` arg to ``analysis_area``, since it is
      not a path but an option string.
    * Simplify the ``analysis_area`` arg options. The options are now:
      ``westcoast``, ``eastcoast``, ``northsea4``, ``northsea10``,
      ``australia``, ``global``. The names displayed in the UI dropdown will
      stay the same as before. Datastacks and scripts will need to be updated
      to use the new option values.
* Wind Energy
    * No model inputs or outputs are measured in "millions of" currency units
      any more. Specifically:
    * The ``mw_coef_ac`` and ``mw_coef_dc`` values in the Global Wind Energy
      Parameters table were in millions of currency units per MW; now they
      should be provided in currency units per MW.
    * The ``infield_cable_cost``, ``cable_coef_ac``, and ``cable_coef_dc``
      values in the Global Wind Energy Parameters table were in millions of
      currency units per km; now they should be provided in currency units per km.
    * The ``turbine_cost`` value in the Turbine Parameters table was in
      millions of currency units; now it should be provided in currency units.
    * The ``foundation_cost`` parameter was in millions of currency units; now
      it should be provided in currency units.
    * The NPV output, formerly ``npv_US_millions.tif``, is now ``npv.tif``.
      It is now in currency units, not millions of currency units.

3.9.2 (2021-10-29)
------------------
* General:
    * Improving our binary build by including a data file needed for the
      ``charset-normalizer`` python package.  This eliminates a warning that
      was printed to stdout on Windows.
    * The Annual Water Yield model name is now standardized throughout InVEST.
      This model has been known in different contexts as Hydropower, Hydropower
      Water Yield, or Annual Water Yield. This name was chosen to emphasize
      that the model can be used for purposes other than hydropower (though the
      valuation component is hydropower-specific) and to highlight its
      difference from the Seasonal Water Yield model. The corresponding python
      module, formerly ``natcap.invest.hydropower.hydropower_water_yield``, is
      now ``natcap.invest.annual_water_yield``.
    * Minor changes to some other models' display names.
    * Update and expand on the instructions in the API docs for installing
      the ``natcap.invest`` package.
    * The InVEST binaries on Windows now no longer inspect the ``%PATH%``
      when looking for GDAL DLLs.  This fixes an issue where InVEST would not
      launch on computers where the ``%PATH%`` either contained other
      environment variables or was malformed.
    * invest processes announce their logfile path at a very high logging level
      that cannot be filtered out by the user.
    * JSON sample data parameter sets are now included in the complete sample
      data archives.
* Seasonal Water Yield
    * Fixed a bug in validation where providing the monthly alpha table would
      cause a "Spatial file <monthly alpha table> has no projection" error.
      The montly alpha table was mistakenly being validated as a spatial file.
* Crop Production Regression
    * Corrected a misspelled column name. The fertilization rate table column
      must now be named ``phosphorus_rate``, not ``phosphorous_rate``.
* Habitat Quality
    * Fixed a bug where optional input Allow Accessibility to Threats could
      not be passed as an empty string argument. Now handles falsey values.
* Urban Flood Risk
    * Fixed a bug where lucodes present in the LULC raster but missing from
      the biophysical table would either raise a cryptic IndexError or silently
      apply invalid curve numbers. Now a helpful ValueError is raised.

3.9.1 (2021-09-22)
------------------
* General:
    * Added error-handling for when ``pandas`` fails to decode a non-utf8
      encoded CSV.
    * Moved the sample data JSON files out of the root sample_data folder and
      into their respective model folders.
    * Updated documentation on installing InVEST from source.
    * Restructured API reference docs and removed outdated and redundant pages.
    * Include logger name in the logging format. This is helpful for the cython
      modules, which can't log module, function, or line number info.
    * Fixed a bug in makefile that prevented ``make env`` from working properly.
    * Fixed an issue with the InVEST application launching on Mac OS X 11
      "Big Sur".  When launching the InVEST ``.app`` bundle, the environment
      variable ``QT_MAC_WANTS_LAYER`` is defined.  If running InVEST through
      python, this environment variable may need to be defined by hand like
      so: ``QT_MAC_WANTS_LAYER=1 python -m natcap.invest``.  A warning will
      be raised if this environment variable is not present on mac.
    * Fixing an issue on Mac OS X where saving the InVEST application to a
      filepath containing spaces would prevent the application from launching.
    * Fixed an issue on Mac OS when certain models would loop indefinitely and
      never complete.  This was addressed by bumping the ``taskgraph``
      requirement version to ``0.10.3``
    * Allow Windows users to install for all users or current user. This allows
      non-admin users to install InVEST locally.
    * Fixed a bug where saving a datastack parameter set with relative paths
      would not convert Windows separators to linux style.
    * Provide a better validation error message when an overview '.ovr' file
      is input instead of a valid raster.
    * Removed internal references to ``TaskGraph``
      ``copy_duplicate_artifact`` calls in anticipation from that feature
      being removed from ``TaskGraph``. User facing changes include
      slightly faster initial runtimes for the Coastal Vulnerability,
      Coastal Blue Carbon, SDR, DelineateIt, and Seasonal Water Yield models.
      These models will no longer attempt to copy intermediate artifacts that
      could have been computed by previous runs.
    * Validation now returns a more helpful message when a spatial input has
      no projection defined.
    * Updated to pygeoprocessing 2.3.2
    * Added support for GDAL 3.3.1 and above
    * Added some logging to ``natcap.invest.utils._log_gdal_errors`` to aid in
      debugging some hard-to-reproduce GDAL logging errors that occasionally
      cause InVEST models to crash.  If GDAL calls ``_log_gdal_errors`` with an
      incorrect set of arguments, this is now logged.
    * Improved the reliability and consistency of log messages across the
      various ways that InVEST models can be run.  Running InVEST in
      ``--headless`` mode, for example, will now have the same logging behavior,
      including with exceptions, as the UI would produce.
    * The default log level for the CLI has been lowered from
      ``logging.CRITICAL`` to ``logging.ERROR``.  This ensures that exceptions
      should always be written to the correct logging streams.
* Carbon
    * Fixed a bug where, if rate change and discount rate were set to 0, the
      valuation results were in $/year rather than $, too small by a factor of
      ``lulc_fut_year - lulc_cur_year``.
    * Improved UI to indicate that Calendar Year inputs are only required for
      valuation, not also for sequestration.
    * Increasing the precision of ``numpy.sum`` from Float32 to Float64 when
      aggregating raster values for the HTML report.
* DelineateIt:
    * The DelineateIt UI has been updated so that the point-snapping options
      will always be interactive.
    * DelineateIt's point-snapping routine has been updated to snap
      ``MULTIPOINT`` geometries with 1 component point as well as primitive
      ``POINT`` geometries.  All other geometric types will not be snapped.
      When a geometry cannot be snapped, a log message is now recorded with the
      feature ID, the geometry type and the number of component geometries.
      Features with empty geometries are now also skipped.
* Fisheries Habitat Scenario Tool
    * Fixed divide-by-zero bug that was causing a RuntimeWarning in the logs.
      This bug did not affect the output.
* HRA
    * Fixed bugs that allowed zeros in DQ & Weight columns of criteria
      table to raise DivideByZero errors.
* NDR
    * Fixed a bug that allowed SDR to be calculated in areas that don't drain
      to any stream. Now all outputs that depend on distance to stream (
      ``d_dn``, ``dist_to_channel``, ``ic``, ``ndr_n``, ``ndr_p``,
      ``sub_ndr_n``, ``sub_ndr_p``, ``n_export``, ``p_export``) are only
      defined for pixels that drain to a stream. They have nodata everywhere
      else.
* Pollination
    * Updated so that the ``total_pollinator_abundance_[season].tif`` outputs
      are always created. Before, they weren't created if a farm vector was
      not supplied, even though they are independent.
* Recreation
    * Fixed some incorrectly formatted log and error messages
* Seasonal Water Yield
    * Fixed a bug where ``qf.tif`` outputs weren't properly masking nodata
      values and could show negative numbers.
* SDR
    * Fixed a bug in validation that did not warn against different coordinate
      systems (all SDR inputs must share a common coordinate system).
    * Fixed a bug that was incorrectly using a factor of 0.0986 rather than
      0.0896. This would have a minor effect on end-user results.
    * Changed how SDR thresholds its L factor to allow direct thresholding
      rather than based off of upstream area. Exposed this parameter as
      ``l_max`` in the ``args`` input and in the user interface.
    * Fixed a bug that allowed SDR to be calculated in areas that don't drain
      to any stream. Now all outputs that depend on distance to stream (
      ``d_dn``, ``d_dn_bare``, ``ic``, ``ic_bare``, ``sdr``, ``sdr_bare``,
      ``e_prime``, ``sed_retention``, ``sed_retention_index``,
      ``sed_deposition``, ``sed_export``) are only defined for pixels that
      drain to a stream. They have nodata everywhere else.
* Urban Flood Risk
    * Fixed a bug where a String ``Type`` column in the infrastructure vector
      would cause the aggregation step of the model to crash, even with the
      correct integer value in the column.
* Wind Energy
    * Raising ValueError when AOI does not intersect Wind Data points.

3.9.0 (2020-12-11)
------------------
* General:
    * Deprecating GDAL 2 and adding support for GDAL 3.
    * Adding function in utils.py to handle InVEST coordindate transformations.
    * Making InVEST compatible with Pygeoprocessing 2.0 by updating:
        * ``convolve_2d()`` keyword ``ignore_nodata`` to
          ``ignore_nodata_and_edges``.
        * ``get_raster_info()`` / ``get_vector_info()`` keyword ``projection``
          to ``projection_wkt``.
    * Improve consistency and context for error messages related to raster
      reclassification across models by using ``utils.reclassify_raster``.
    * Fixed bug that was causing a TypeError when certain input rasters had an
      undefined nodata value. Undefined nodata values should now work
      everywhere.
    * Include logging in python script generated from
      "Save to python script..." in the "Development" menu. Now logging
      messages from the model execution will show up when you run the script.
    * InVEST is now a 64-bit binary built against Python 3.7.
    * Adding Python 3.8 support for InVEST testing.
    * Add warning message to installer for 32-bit computers about installing
      64-bit software.
    * Stop running validation extra times when model inputs autofill, saving
      a small but noticeable amount of time in launching a model.
    * The number of files included in the python source distribution has been
      reduced to just those needed to install the python package and run tests.
    * Code-sign the macOS distribution, and switch to a DMG distribution format.
    * No longer include the HTML docs or HISTORY.rst in the macOS distribution.
    * Bumped the ``shapely`` requirements to ``>=1.7.1`` to address a library
      import issue on Mac OS Big Sur.
    * Fixing model local documentation links for Windows and Mac binaries.
    * The InVEST binary builds now launch on Mac OS 11 "Big Sur".  This was
      addressed by defining the ``QT_MAC_WANTS_LAYER`` environment variable.
    * Fixed the alphabetical ordering of Windows Start Menu shortcuts.
* Annual Water Yield:
    * Fixing bug that limited ``rsupply`` result when ``wyield_mn`` or
      ``consump_mn`` was 0.
* Coastal Blue Carbon
    * Refactor of Coastal Blue Carbon that implements TaskGraph for task
      management across the model and fixes a wide range of issues with the model
      that were returning incorrect results in all cases.
    * Corrected an issue with the model where available memory would be exhausted
      on a large number of timesteps.
    * In addition to the ``execute`` entrypoint, another entrypoint,
      ``execute_transition_analysis`` has been added that allows access to the
      transition analysis timeseries loop at a lower level.  This will enable
      users comfortable with python to provide spatially-explicit maps of
      accumulation rates, half lives and other parameters that can only be
      provided via tables to ``execute``.
    * Snapshot years and rasters, including the baseline year/raster, are now all
      provided via a table mapping snapshot years to the path to a raster on
      disk.  The baseline year is the earliest year of these.
    * The model's "initial" and "lulc lookup" and "transient" tables have been
      combined into a single "biophysical" table, indexed by LULC code/LULC class
      name, that includes all of the columns from all of these former tables.
    * The "analysis year" is now a required input that must be >= the final
      snapshot year in the snapshots CSV.
    * Litter can now accumulate at an annual rate if desired.
    * The model now produces many more files, which allows for greater
      flexibility in post-processing of model outputs.
* Coastal Vulnerability
    * 'shore_points_missing_geomorphology.gpkg' output file name now includes
      the suffix if any, and its one layer now is renamed from
      'missing_geomorphology' to be the same as the file name
      (including suffix).
    * Fixed a memory bug that occurred during shore point interpolation when
      dealing with very large landmass vectors.
* Delineateit
    * The layer in the 'preprocessed_geometries.gpkg' output is renamed from
      'verified_geometries' to be the same as the file name (including suffix).
    * The layer in the 'snapped_outlets.gpkg' output is renamed from
      'snapped' to be the same as the file name (including suffix).
    * The layer in the 'watersheds.gpkg' output has been renamed from
      'watersheds' to match the name of the vector file (including the suffix).
    * Added pour point detection option as an alternative to providing an
      outlet features vector.
* Finfish
    * Fixed a bug where the suffix input was not being used for output paths.
* Forest Carbon Edge Effect
    * Fixed a broken link to the local User's Guide
    * Fixed bug that was causing overflow errors to appear in the logs when
      running with the sample data.
    * Mask out nodata areas of the carbon map output. Now there should be no
      output data outside of the input LULC rasater area.
* GLOBIO
    * Fixing a bug with how the ``msa`` results were masked and operated on
      that could cause bad results in the ``msa`` outputs.
* Habitat Quality:
    * Refactor of Habitat Quality that implements TaskGraph
    * Threat files are now indicated in the Threat Table csv input under
      required columns: ``BASE_PATH``, ``CUR_PATH``, ``FUT_PATH``.
    * Threat and Sensitivity column names are now case-insensitive.
    * Sensitivity threat columns now match threat names from Threat Table
      exactly, without the need for ``L_``. ``L_`` prefix is deprecated.
    * Threat raster input folder has been removed.
    * Validation enhancements that check whether threat raster paths are valid.
    * HQ update to User's Guide.
    * Changing sample data to reflect Threat Table csv input changes and
      bumping revision.
    * More comprehensive testing for Habitat Quality and validation.
    * Checking if Threat raster values are between 0 and 1 range, raising
      ValueError if not. No longer snapping values less than 0 to 0 and greater
      than 1 to 1.
    * Fixing bug that was setting Threat raster values to 1 even if they were
      floats between 0 and 1.
    * Updating how threats are decayed across distance. Before, nodata edges
      were ignored causing values on the edges to maintain a higher threat
      value. Now, the decay does not ignore those nodata edges causing values
      on the edges to decay more quickly. The area of study should have
      adequate boundaries to account for these edge effects.
    * Update default half saturation value for sample data to 0.05 from 0.1.
* Seasonal Water Yield
    * Fixed a bug where precip or eto rasters of ``GDT_Float64`` with values
      greater than 32-bit would overflow to ``-inf``.
* SDR:
    * Fixing an issue where the LS factor should be capped to an upstream area
      of 333^2 m^2. In previous versions the LS factor was erroneously capped
      to "333" leading to high export spikes in some pixels.
    * Fixed an issue where sediment deposition progress logging was not
      progressing linearly.
    * Fixed a task dependency bug that in rare cases could cause failure.
* Urban Cooling
    * Split energy savings valuation and work productivity valuation into
      separate UI options.
* Urban Flood Risk
    * Changed output field names ``aff.bld`` and ``serv.blt`` to ``aff_bld``
      and ``serv_blt`` respectively to fix an issue where ArcGIS would not
      display properly.

3.8.9 (2020-09-15)
------------------
* Hydropower
    * Fixed bug that prevented validation from ever passing for this model.
      Validation will allow extra keys in addition to those in the ARGS_SPEC.
* Urban Flood Mitigation
    * Fixed incorrect calculation of total quickflow volume.

3.8.8 (2020-09-04)
------------------
* Coastal Vulnerability
    * Improved handling of invalid AOI geometries to avoid crashing and instead
      fix the geometry when possible and skip it otherwise.
    * Added validation check that shows a warning if the SLR vector is not
      a point or multipoint geometry.
* Urban Cooling
    * Energy units are now (correctly) expressed in kWh.  They were previously
      (incorrectly) expressed in kW.
    * Energy savings calculations now require that consumption is in units of
      kWh/degree C/m^2 for each building class.
    * Fixing an issue where blank values of the Cooling Coefficient weights
      (shade, albedo, ETI) would raise an error.  Now, a default value for the
      coefficient is assumed if any single value is left blank.
* HRA
    * Raise ValueError if habitat or stressor inputs are not projected.
    * Make sample data rating filepaths work on Mac. If not on Windows and a rating
      filepath isn't found, try replacing all backslashes with forward slashes.
* Seasonal Water Yield
    * Updated output file name from aggregated_results.shp to aggregated_results_swy.shp
      for consistency with NDR and SDR
* Datastack
    * Saved datastack archives now use helpful identifying names for spatial input folders
* Validation
    * Fixed bug that caused fields activated by a checkbox to make validation fail,
      even when the checkbox was unchecked.
* General
    * Input table column headers are now insensitive to leading/trailing whitespace in
      most places.
    * Modified the script that produces a conda environment file from InVEST's python
      requirements file so that it includes the ``conda-forge`` channel in the file
      itself.
* Recreation
    * Validate values in the type column of predictor tables early in execution. Raise
      a ValueError if a type value isn't valid (leading/trailing whitespace is okay).
* Validation
    * Set a 5-second timeout on validation functions that access a file. This will raise
      a warning and prevent validation from slowing down the UI too much.

3.8.7 (2020-07-17)
------------------
* General
    * Fixed an issue where some users would be unable to launch InVEST binaries
      on Windows.  This crash was due to a configuration issue in
      ``PySide2==5.15.0`` that will be fixed in a future release of PySide2.
* GLOBIO
    * Fix a bug that mishandled combining infrastructure data when only one
      infrastructure data was present.
* Urban Flood Risk
    * The output vector ``flood_risk_service.shp`` now includes a field,
      ``flood_vol`` that is the sum of the modeled flood volume (from
      ``Q_m3.tif``) within the AOI.
    * Fieldnames in ``flood_risk_service.shp`` have been updated to more
      closely match the variables they match as documented in the User's Guide
      chapter.  Specifically, ``serv_bld`` is now ``serv.blt`` and ``aff_bld``
      is now ``aff.bld``.
    * ``Q_mm.tif`` has been moved from the intermediate directory into the
      workspace.
    * Fixed a bug in the flood volume (``Q_m3.tif``) calculations that was
      producing incorrect values in all cases.
    * Fixed a bug where input rasters with nodata values of 0 were not handled
      properly.

3.8.6 (2020-07-03)
------------------
* Crop Production
    * Fixed critical bug in crop regression that caused incorrect yields in
      all cases.

3.8.5 (2020-06-26)
------------------
* General
    * Fix bug in ``utils.build_lookup_from_csv`` that was allowing
      ``key_field`` to be non unique and overwriting values.
    * Fix bug in ``utils.build_lookup_from_csv`` where trailing commas caused
      returned values to be malformed.
    * Add optional argument ``column_list`` to ``utils.build_lookup_from_csv``
      that takes a list of column names and only returns those in the
      dictionary.
    * Remove ``warn_if_missing`` argument from ``utils.build_lookup_from_csv``
      and warning by default.
* Scenic Quality
    * Fixing an issue in Scenic Quality where the creation of the weighted sum
      of visibility rasters could cause "Too Many Open Files" errors and/or
      ``MemoryError`` when the model is run with many viewpoints.
    * Progress logging has been added to several loops that may take a longer
      time when the model is run with thousands of points at a time.
    * A major part of the model's execution was optimized for speed,
      particularly when the model is run with many, many points.
* SDR:
    * Removed the unused parameter ``args['target_pixel_size']`` from the SDR
      ``execute`` docstring.
* Urban Flood Risk Mitigation
    * Fixed an issue where the output vector ``flood_risk_service.shp`` would
      only be created when the built infrastructure vector was provided.  Now,
      the ``flood_risk_service.shp`` vector is always created, but the fields
      created differ depending on whether the built infrastructure input is
      present during the model run.
    * Fixed an issue where the model would crash if an infrastructure geometry
      were invalid or absent.  Such features are now skipped.

3.8.4 (2020-06-05)
------------------
* General:
    * Advanced the ``Taskgraph`` version requirement to fix a bug where workspace
      directories created by InVEST versions <=3.8.0 could not be re-used by more
      recent InVEST versions.
* NDR:
    * The Start Menu shortcut on Windows and launcher label on Mac now have
      consistent labels for NDR: "NDR: Nutrient Delivery Ratio".
* SDR:
    * The Start Menu shortcut on Windows and launcher label on Mac now have
      consistent labels for SDR: "SDR: Sediment Delivery Ratio".

3.8.3 (2020-05-29)
------------------
* SDR
    * SDR's compiled core now defines its own ``SQRT2`` instead of relying on an
      available standard C library definition. This new definition helps to avoid
      some compiler issues on Windows.

3.8.2 (2020-05-15)
------------------
* InVEST's CSV encoding requirements are now described in the validation
  error message displayed when a CSV cannot be opened.

3.8.1 (2020-05-08)
------------------
* Fixed a compilation issue on Mac OS X Catalina.
* Fixed an issue with NDR's raster normalization function so that Float64
  nodata values are now correctly cast to Float32.  This issue was affecting
  the summary vector, where the ``surf_n``, ``sub_n`` and ``n_export_tot``
  columns would contain values of ``-inf``.
* Fixed minor bug in Coastal Vulnerability shore point creation. Also added a
  check to fail fast when zero shore points are found within the AOI.
* The Finfish Aquaculture model no longer generates histograms for
  uncertainty analysis due to issues with matplotlib that make InVEST
  unstable. See https://github.com/natcap/invest/issues/87 for more.
* Corrected the Urban Cooling Model's help text for the "Cooling Capacity
  Calculation Method" in the User Interface.
* Fixing an issue with SDR's ``LS`` calculations.  The ``x`` term is now
  the weighted mean of proportional flow from the current pixel into its
  neighbors.  Note that for ease of debugging, this has been implemented as a
  separate raster and is now included in ``RKLS`` calculations instead of in
  the ``LS`` calculations.
* Fixed a bug in validation where checking for spatial overlap would be skipped
  entirely in cases where optional model arguments were not used.
* Bumping the ``psutil`` dependency requirement to ``psutil>=5.6.6`` to address
  a double-free vulnerability documented in CVE-2019-18874.
* Adding a GitHub Actions workflow for building python wheels for Mac and Windows
  as well as a source distribution.
* Updating links in ``setup.py``, ``README.rst`` and ``README_PYTHON.rst`` to
  refer to the repository's new home on github.
* Binary builds for Windows and Mac OS X have been moved to GitHub Actions from
  AppVeyor.  All AppVeyor-specific configuration has been removed.
* Fixing an issue with the InVEST Makefile where ``make deploy`` was
  attempting to synchronize nonexistent sample data zipfiles with a storage
  bucket on GCP.  Sample data zipfiles are only built on Windows, and so
  ``make deploy`` will only attempt to upload them when running on Windows.
* Fixed a bug in CLI logging where logfiles created by the CLI were
  incompatible with the ``natcap.invest.datastack`` operation that
  allows the UI to load model arguments from logfiles.
* Added error-handling in Urban Flood Risk Mitigation to tell users to
  "Check that the Soil Group raster does not contain values other than
  (1, 2, 3, 4)" when a ``ValueError`` is raised from ``_lu_to_cn_op``.
* Updated the ``Makefile`` to use the new git location of the InVEST User's
  Guide repository at https://github.com/natcap/invest.users-guide
* Automated tests are now configured to use Github Actions for 32- and 64-bit
  build targets for Python 3.6 and 3.7 on Windows.  We are still using
  AppVeyor for our binary builds for the time being.
* Makefile has been updated to fetch the version string from ``git`` rather
  than ``hg``.  A mercurial client is still needed in order to clone the
  InVEST User's Guide.
* Removing Python 2 compatibility code such as ``future``, ``pyqt4``,
  ``basestring``, ``unicode``, ``six``, unicode casting, etc...
* Update api-docs conf file to mock sdr.sdr_core and to use updated unittest
  mock

3.8.0 (2020-02-07)
------------------
* Created a sub-directory for the sample data in the installation directory.
* Fixed minor bug in HRA that was duplicating the ``results_suffix`` in some
  output filenames.
* Updated the DelineateIt UI to improve the language around what the model
  should do when it encounters invalid geometry.  The default is now
  that it should skip invalid geometry.
* Updating how threat rasters are handled in Habitat Quality to address a few
  related and common usability issues for the model.  First, threat
  rasters are now aligned to the LULC instead of the intersection of the whole
  stack.  This means that the model now handles threat inputs that do not all
  completely overlap the LULC (they must all still be in the same projection).
  Second, nodata values in threat rasters are converted to a threat value of 0.
  Any threat pixel values other than 0 or nodata are interpreted as a threat
  value of 1.
* Updating the ``psutil`` requirement to avoid a possible import issue when
  building binaries under WINE.  Any version of ``psutil`` should work
  except for ``5.6.0``.
* InVEST sample data was re-organized to simply have one folder per model.
  New datastacks were added for SDR, NDR, Seasonal Water Yield,
  Annual Water Yield, DelineateIt, and Coastal Vulnerability.
* Fixed an issue with NDR where the model was not properly checking for the
  bounds of the raster, which could in some cases lead to exceptions being
  printed to the command-line.  The model now correctly checks for these
  raster boundaries.
* Habitat Risk Assessment model supports points and lines -- in addition to
  previously supported polygons and rasters -- for habitats or stressors.
* Updated raster percentile algorithms in Scenic Quality and Wave Energy
  models to use a more efficient and reliable raster percentile function
  from pygeoprocessing.
* InVEST is now compatible with pygeoprocessing 1.9.1.
* All InVEST models now have an ``ARGS_SPEC`` object that contains metadata
  about the model and describes the model's arguments.  Validation has been
  reimplemented across all models to use these ``ARGS_SPEC`` objects.
* The results suffix key for the Wave Energy and Wind Energy models has been
  renamed ``results_suffix`` (was previously ``suffix``).  This is for
  consistency across InVEST models.
* Speed and memory optimization of raster processing in the Recreation model.
* Removed a constraint in Coastal Vulnerability so the AOI polygon no longer
  needs to intersect the continental shelf contour line. So the AOI can now be
  used exclusively to delineate the coastal area of interest.
* Improved how Coastal Vulnerability calculates local wind-driven waves.
  This requires a new bathymetry raster input and implements equation 10
  of the User Guide. Also minor updates to fields in intermediate outputs,
  notably a 'shore_id' field is now the unique ID for joining tables and
  FIDs are no longer used.
* Added a status message to the UI if a datastack file fails to load,
  instead of staying silent.
* Correcting an issue with repository fetching in the InVEST ``Makefile``.
  Managed repositories will now be fetched and updated to the expected revision
  even if the repository already exists.
* Fixed the duplicate ``results_suffix`` input in Wave Energy UI.
* Added a human-friendly message on NDR model ``KeyError``.
* Adding a check to Annual Water Yield to ensure that the ``LULC_veg`` column
  has correct values.
* Improved how Seasonal Water Yield handles nodata values when processing
  floating-point precipitation and quickflow rasters.
* Add SDR feature to model sediment deposition across the landscape.
* Fixed an issue that would cause an exception if SDR landcover map was masked
  out if the original landcover map had no-nodata value defined.
* Fixed an issue in the SDR model that could cause reported result vector
  values to not correspond with known input vectors if the input watershed
  vector was not an ESRI Shapefile.
* Fixed issue in Seasonal Water Yield model that would cause an unhandled
  exception when input rasters had areas of a valid DEM but nodata in other
  input layers that overlap that dem.
* Fixed an issue in the NDR model that would cause an exception if the critical
  length of a landcover field was set to 0.
* Implemented PEP518-compatible build system definition in the file
  ``pyproject.toml``.  This should make it easier to install ``natcap.invest``
  from a source distribution.
* Fixed a ``TypeError`` issue in Seasonal Water Yield that would occur when
  the Land-Use/Land-Cover raster did not have a defined nodata value.  This
  case is now handled correctly.
* The binary build process for InVEST on Windows (which includes binaries
  based on PyInstaller and an NSIS Installer package) has been migrated
  to 32-bit Python 3.7.  The build itself is taking place on AppVeyor, and
  the configuration for this is contained within ``appveyor.yml``.
  Various python scripts involved in the distribution and release processes
  have been updated for compatibility with python 3.7 as a part of this
  migration.
* Fixed an ``IndexError`` issue in Wave Energy encountered in runs using
  the global wave energy dataset.  This error was the result of an incorrect
  spatial query of points and resulted in some wave energy points being
  double-counted.
* Fixed taskgraph-related issues with Habitat Risk Assessment where
  1) asynchronous mode was failing due to missing task dependencies and
  2) avoided recomputation was confounded by two tasks modifying the same files.
* Fixed an issue with Habitat Quality where the model was incorrectly
  expecting the sensitivity table to have a landcover code of 0.
* The InVEST CLI has been completely rebuilt to divide
  functionality into various topic-specific subcommands.  The various internal
  consumers of this API have been updated accordingly.  ``invest --help`` will
  contain details of the new interface.
* Updated the InVEST Launcher to list the human-readable model names rather
  than the internal model identifiers.
* Updated Coastal Vulnerability Model with significant speedups including
  ~40x speedup for geomorphology process and ~3x speedup for wind exposure process.
  Also saving an intermediate vector with wave energy values and a geomorphology
  vector with points that were assigned the ``geomorphology_fill_value``.
* Updated trove classifiers to indicate support for python versions 2.7, 3.6
  and 3.7.
* Updated all InVEST models to be compatible with a Python 2.7 or a Python 3.6
  environment. Also tested all models against GDAL versions 2.2.4 and 2.4.1.
* Fixed an issue with Habitat Quality where convolutions over threat rasters
  were not excluding nodata values, leading to incorrect outputs.  Nodata values
  are now handled correctly and excluded from the convolution entirely.
* Updated the subpackage ``natcap.invest.ui`` to work with python 3.6 and later
  and also to support the PySide2 bindings to Qt5.
* InVEST Coastal Blue Carbon model now writes out a net present value
  raster for the year of the current landcover, each transition year,
  and the final analysis year (if provided).
* Correcting an issue with InVEST Coastal Blue Carbon where incorrect
  configuration of a nodata value would result in ``-inf`` values in
  output rasters.  Now, any values without a defined reclassification
  rule that make it past validation will be written out as nodata.
* DelineateIt has been reimplemented using the latest version of
  pygeoprocessing (and the watershed delineation routine it provides) and now
  uses ``taskgraph`` for avoiding unnecessary recomputation.
* Fixed a bug in Recreation Model that was causing server-side code
  to execute twice for every client-side call.
* Fixed a bug in Recreation model that did not apply ``results_suffix`` to
  the monthly_table.csv output.
* Various fixes in Coastal Vulnerability Model. CSV output files now
  have FID column for joining to vector outputs. ``results_suffix`` can be
  used without triggering task re-execution. Raster processing maintains original
  resolution of the input raster so long as it is projected. Otherwise resamples
  to ``model_resolution``.
* Fixed a bug in Coastal Vulnerability model's task graph that sometimes
  caused an early task to re-execute when it should be deemed pre-calculated.
* Fixed a bug in the pollination model that would cause outputs to be all 0
  rasters if all the ``relative_abundance`` fields in the guild table were
  integers.
* Fixed a file cache flushing issue observed on Debian in
  ``utils.exponential_decay_kernel_raster`` that would cause an exponential
  kernel raster to contain random values rather than expected value.
* Added a new InVEST model: Urban Flood Risk Mitigation.
* Fixed an issue in the SDR model that would cause an unhandled exception
  if either the erosivity or erodibility raster had an undefined nodata value.
* Added a new InVEST model: Urban Cooling Model.

3.7.0 (2019-05-09)
------------------
* Refactoring Coastal Vulnerability (CV) model. CV now uses TaskGraph and
  Pygeoprocessing >=1.6.1. The model is now largely vector-based instead of
  raster-based. Fewer input datasets are required for the same functionality.
  Runtime in sycnhronous mode is similar to previous versions, but runtime can
  be reduced with multiprocessing. CV also supports avoided recomputation for
  successive runs in the same workspace, even if a different file suffix is
  used. Output vector files are in CSV and geopackage formats.
* Model User Interface 'Report an Issue' link points to our new
  community.naturalcapitalproject.org
* Correcting an issue with the Coastal Blue Carbon preprocessor where
  using misaligned landcover rasters would cause an exception to be raised.
* Correcting an issue with RouteDEM where runs of the tool with Flow Direction
  enabled would cause the tool to crash if ``n_workers > 0``.
* Correcting an issue with Habitat Quality's error checking where nodata values
  in landcover rasters were not being taken into account.
* Valuation is now an optional component of the InVEST Scenic Quality model.
* Fixing a bug in the percentiles algorithm used by Scenic Quality that
  would result in incorrect visual quality outputs.
* Carbon Model and Crop Production models no longer crash if user-input
  rasters do not have a nodata value defined. In this case these models
  treat all pixel values as valid data.
* Adding bitbucket pipelines and AppVeyor build configurations.
* Refactoring Recreation Model client to use taskgraph and the latest
  pygeoprocessing. Avoided re-computation from taskgraph means that
  successive model runs with the same AOI and gridding option can re-use PUD
  results and avoid server communication entirely. Successive runs with the
  same predictor data will re-use intermediate geoprocessing results.
  Multiprocessing offered by taskgraph means server-side PUD calculations
  and client-side predictor data processing can happen in parallel. Some
  output filenames have changed.
* Upgrading to SDR to use new PyGeoprocessing multiflow routing, DEM pit
  filling, contiguous stream extraction, and TaskGraph integration. This
  also includes a new TaskGraph feature that avoids recomputation by copying
  results from previous runs so long as the expected result would be
  identical. To use this feature, users must execute successive runs of SDR
  in the same workspace but use a different file suffix. This is useful when
  users need to do a parameter study or run scenarios with otherwise minor
  changes to inputs.
* Refactoring Habitat Risk Assessment (HRA) Model to use TaskGraph >= 0.8.2 and
  Pygeoprocessing >= 1.6.1. The HRA Proprocessor is removed and its previous
  functionality was simplified and merged into the HRA model itself.
  The model will no longer generate HTML plots and tables.
* Adding a software update notification button, dialog, and a link to the
  download page on the User Interface when a new InVEST version is available.
* Migrating the subversion sample and test data repositories to Git LFS
  repositories on BitBucket. Update the repository URL and fetch commands on
  Makefile accordingly.
* Fixing a bug in Habitat Quality UI where the absence of the required
  half_saturation_constant variable did not raise an exception.
* Adding encoding='utf-8-sig' to pandas.read_csv() to support
  utils.build_lookup_from_csv() to read CSV files encoded with UTF-8 BOM
  (byte-order mark) properly.

3.6.0 (2019-01-30)
------------------
* Correcting an issue with the InVEST Carbon Storage and Sequestration model
  where filepaths containing non-ASCII characters would cause the model's
  report generation to crash.  The output report is now a UTF-8 document.
* Refactoring RouteDEM to use taskgraph and the latest pygeoprocessing
  (``>=1.5.0``).  RouteDEM now fills hydrological sinks and users have the
  option to use either of the D8 or Multiple Flow Direction (MFD) routing
  algorithms.
* Adding a new input to the InVEST Settings window to allow users to customize
  the value that should be used for the ``n_workers`` parameter in
  taskgraph-enabled models.  This change involves removing the "Number of
  Parallel Workers" input from the model inputs pane for some models in
  favor of this new location.  The default value for this setting is ``-1``,
  indicating synchronous (non-threaded, non-multiprocessing) execution of
  tasks.
* Removing Scenario Generator: Rule-based model.
* Fixing a bug in Hydropower model where watershed aggregations would be incorrect
  if a watershed is partially covering nodata raster values. Nodata values are now
  ignored in zonal statistics. Numerical results change very slightly in the
  case where a watershed only includes a few nodata pixels.
* Adding TaskGraph functionality to GLOBIO model.
* Adding some TaskGraph functionality to Scenario Generator: Proximity.
* Fixing an issue with the InVEST Fisheries model that would prevent the model
  from batch-processing a directory of population tables.  The model will now
  process these files as expected.
* Reimplementing Crop Production models using taskgraph.
* Fixing an issue with Crop Production Regression's result_table.csv where the
  'production_modeled' and '<nutrient>_modeled' values calculated for each crop
  were done so using the same crop raster (e.g. wheat, soybean, and barley values
  were all based on soybean data).
* Hydropower subwatershed results now include all the same metrics as the
  watershed results, with the exception of economic valuation metrics.
* Reimplementing the Hydropower model using taskgraph.
* Reimplementing the Carbon model using taskgraph.
* Fixing an issue with Coastal Blue Carbon validation to allow column names to
  ignore case.
* Updating core carbon forest edge regression data coefficient to drop
  impossible negative coefficients.
* Fixing an issue with the Scenario Generator: Proximity model that would
  raise an exception if no AOI were passed in even though the AOI is optional.
* Removing Overlap Analysis and Overlap Analysis: Management Zones.
* Removing Habitat Suitability.
* Added comprehensive error checking to hydropower model to test for the VERY
  common errors of missing biophysical, demand, and valuation coefficients in
  their respective tables.
* Fixing an issue with Hydropower Water Yield ("Annual Water Yield") where
  valuation would never be triggered when running the model through the User
  Interface. And a related issue where the model would crash if a valuation table
  was provided but a demand table was not. The UI no longer validates that config.
* Fixing an issue with how logging is captured when a model is run through the
  InVEST User Interface.  Now, logging from any thread started by the executor
  thread will be written to the log file, which we expect to aid in debugging.
* Fixing an issue with Scenic Quality where viewpoints outside of the AOI
  were not being properly excluded.  Viewpoints are now excluded correctly.
* The crop production model has been refactored to drop the "aggregate ID"
  concept when summarizing results across an aggregate polygon. The model now
  uses the polygon FIDs internally and externally when producing the result
  summary table.
* Correcting the rating instructions in the criteria rating instructions on how
  the data quality (DQ) and weight should be rated in the HRA Preprocessor.
  A DQ score of 1 should represent better data quality whereas the score of 3 is
  worse data quality. A weight score of 1 is more important, whereas that of 3
  is less important.
* Fixing a case where a zero discount rate and rate of change in the carbon
  model would cause a divide by zero error.

3.5.0 (2018-08-14)
------------------
* Bumped pygeoprocessing requirement to ``pygeoprocessing>=1.2.3``.
* Bumped taskgraph requirement to ``taskgraph>=0.6.1``.
* Reimplemented the InVEST Scenic Quality model.  This new version removes the
  'population' and 'overlap' postprocessing steps, updates the available
  valuation functions and greatly improves the runtime and memory-efficiency of
  the model.  See the InVEST User's Guide chapter for more information.
* Updated Recreation server's database to include metadata from photos taken
  from 2005-2017 (previous range was 2005-2014). The new range is reflected
  in the UI.
* Fixed an issue with the InVEST binary build where binaries on Windows would
  crash with an error saying Python27.dll could not be loaded.
* Fixed an issue in the Rule-Based Scenario Generator UI where vector column
  names from override and constraint layers were not being loaded.  This bug
  caused the field 'UNKNOWN' to be passed to the model, causing an error.
* Fixed an issue with the InVEST UI (all models), where attempting to
  drag-and-drop a directory onto a model input would cause the application to
  crash.
* Coastal Vulnerability UI now specifies a number of reasonable defaults for
  some numeric inputs.
* Fixed an issue with the Fisheries UI where alpha and beta parameter inputs
  were incorrectly disabled for the Ricker recruitment function.
* InVEST now uses a Makefile to automate the build processes.  GNU Make is
  required to use the Makefile.  See ``README.rst`` for instructions on
  building InVEST.  This replaces the old ``pavement.py`` build entrypoint,
  which has been removed.
* Fixed an issue with the InVEST UI (all models), where attempting to
  drag-and-drop a directory onto a model input would cause the application to
  crash.
* Fixed an issue with Forest Carbon Edge Effect where the UI layer was always
  causing the model to run with only the aboveground carbon pool
* Added functionality to the InVEST UI so that ``Dropdown`` inputs can now map
  dropdown values to different output values.
* Fixed an issue in the Crop Production Percentile model that would treat the
  optional AOI vector field as a filename and crash on a run if it were empty.
* Fixing an issue in the Pollination Model that would cause occasional crashes
  due to a missing dependent task; it had previously been patched by setting
  taskgraph to operate in single thread mode. This restores multithreading
  in the pollination model.
* Fixed an issue in the water yield / hydropower model that would skip
  calculation of water demand tables when "water scarcity" was enabled.
* Fixed an issue in the model data of the crop production model where some
  crops were using incorrect climate bin rasters. Since the error was in the
  data and not the code, users will need to download the most recent version
  of InVEST's crop model data during the installation step to get the fix.

3.4.4 (2018-03-26)
------------------
* InVEST now requires GDAL 2.0.0 and has been tested up to GDAL 2.2.3. Any API users of InVEST will need to use GDAL version >= 2.0. When upgrading GDAL we noticed slight numerical differences in our test suite in both numerical raster differences, geometry transforms, and occasionally a single pixel difference when using `gdal.RasterizeLayer`. Each of these differences in the InVEST test suite is within a reasonable numerical tolerance and we have updated our regression test suite appropriately. Users comparing runs between previous versions of InVEST may also notice reasonable numerical differences between runs.
* Added a UI keyboard shortcut for showing documentation. On Mac OSX, this will be Command-?. On Windows, GNOME and KDE, this will be F1.
* Patching an issue in NDR that was using the nitrogen subsurface retention efficiency for both nitrogen and phosphorous.
* Fixed an issue with the Seasonal Water Yield model that incorrectly required a rain events table when the climate zone mode was in use.
* Fixed a broken link to local and online user documentation from the Seasonal Water Yield model from the model's user interface.

3.4.3 (2018-03-26)
------------------
* Fixed a critical issue in the carbon model UI that would incorrectly state the user needed a "REDD Priority Raster" when none was required.
* Fixed an issue in annual water yield model that required subwatersheds even though it is an optional field.
* Fixed an issue in wind energy UI that was incorrectly validating most of the inputs.

3.4.2 (2017-12-15)
------------------
* Fixed a cross-platform issue with the UI where logfiles could not be dropped onto UI windows.
* Model arguments loaded from logfiles are now cast to their correct literal value.  This addresses an issue where some models containing boolean inputs could not have their parameters loaded from logfiles.
* Fixed an issue where the Pollination Model's UI required a farm polygon. It should have been optional and now it is.
* Fixing an issue with the documentation and forums links on the InVEST model windows.  The links now correctly link to the documentation page or forums as needed.
* Fixing an issue with the ``FileSystemRunDialog`` where pressing the 'X' button in the corner of the window would close the window, but not reset its state.  The window's state is now reset whenever the window is closed (and the window cannot be closed when the model is running)

3.4.1 (2017-12-11)
------------------
* In the Coastal Blue Carbon model, the ``interest_rate`` parameter has been renamed to ``inflation_rate``.
* Fixed issues with sample parameter sets for InVEST Habitat Quality, Habitat Risk Assessment, Coastal Blue Carbon, and Coastal Blue Carbon Preprocessors.  All sample parameter sets now have the correct paths to the model's input files, and correctly note the name of the model that they apply to.
* Added better error checking to the SDR model for missing `ws_id` and invalid `ws_id` values such as `None` or some non-integer value. Also added tests for the `SDR` validation module.

3.4.0 (2017-12-03)
------------------
* Fixed an issue with most InVEST models where the suffix was not being reflected in the output filenames.  This was due to a bug in the InVEST UI, where the suffix args key was assumed to be ``'suffix'``.  Instances of ``InVESTModel`` now accept a keyword argument to defined the suffix args key.
* Fixed an issue/bug in Seasonal Water Yield that would occur when a user provided a datastack that had nodata values overlapping with valid DEM locations. Previously this would generate an NaN for various biophysical values at that pixel and cascade it downslope. Now any question of nodata on a valid DEM pixel is treated as "0". This will make serious visual artifacts on the output, but should help users pinpoint the source of bad data rather than crash.
* Refactored all but routing components of SDR to use PyGeoprocessing 0.5.0 and laid a consistent raster floating point type of 'float32'. This will cause numerically insignificant differences between older versions of SDR and this one. But differences are well within the tolerance of the overall error of the model and expected error rate of data. Advantages are smaller disk footprint per run, cleaner and more maintainable design, and a slight performance increase.
* Bug fixed in SDR that would align the output raster stack to match with the landcover pixel stack even though the rest of the rasters are scaled and clipped to the DEM.
* When loading parameters from a datastack, parameter set or logfile, the UI will check that the model that created the file being loaded matches the name of the model that is currently running.  If there is a mismatch, a dialog is presented for the user to confirm or cancel the loading of parameters. Logfiles from IUI (which do not have clearly-recorded modelname or InVEST version information) can still have their arguments parsed, but the resulting model name and InVEST version will be set to ``"UNKNOWN"``.
* Data Stack files (``*.invest.json``, ``*.invest.tar.gz``) can now be dragged and dropped on an InVEST model window, which will prompt the UI to load that parameter set.
* Spatial inputs to Coastal Blue Carbon are now aligned as part of the model. This resolves a longstanding issue with the model where inputs would need to perfectly overlap (even down to pixel indices), or else the model would yield strange results.
* The InVEST UI now contains a submenu for opening a recently-opened datastack.  This submenu is automatically populated with the 10 most recently-opened datastacks for the current model.
* Removed vendored ``natcap.invest.dbfpy`` subpackage.
* Removed deprecated ``natcap.invest.fileio`` module.
* Removed ``natcap.invest.iui`` UI subpackage in favor of a new UI framework found at ``natcap.invest.ui``. This new UI features a greatly improved API, good test coverage, support for Qt4 and Qt5, and includes updates to all InVEST models to support validation of model arguments from a python script, independent of the UI.
* Updated core model of seasonal water yield to allow for negative `L_avail`.
* Updated RouteDEM to allow for file suffixes, finer control over what DEM routing algorithms to run, and removal of the multiple stepped stream threshold classification.
* Redesign/refactor of pollination model. Long term bugs in the model are resolved, managed pollinators added, and many simplifications to the end user's experience.  The updated user's guide chapter is available here: http://data.naturalcapitalproject.org/nightly-build/invest-users-guide/html/croppollination.html
* Scenario Generator - Rule Based now has an optional input to define a seed.
  This input is used to seed the random shuffling of parcels that have equal
  priorities.
* InVEST on mac is now distributed as a single application bundle, allowing InVEST to run as expected on mac OSX Sierra.  Individual models are selected and launched from a new launcher window.
* The InVEST CLI now has a GUI model launcher:  ``$ invest launcher``
* Updated the Coastal Blue Carbon model to improve handling of blank lines in input CSV tables and improve memory efficiency of the current implementation.
* Improved the readability of a cryptic error message in Coastal Vulnerability that is normally raised when the depth threshold is too high or the exposure proportion is too low to detect any shoreline segments.
* Adding InVEST HTML documentation to the Mac disk image distribution.
* Upgrading dependency of PyGeoprocessing to 0.3.3.  This fixes a memory leak associated with any model that aggregates rasters over complicated overlapping polygons.
* Adding sample data to Blue Carbon model that were missing.
* Deprecating the InVEST Marine Water Quality model.  This also removes InVEST's dependancy on the pyamg package which has been removed from REQUIREMENTS.TXT.
* Deprecating the ArcGIS-based Coastal Protection model and ArcGIS-based data-preprocessing scripts.  The toolbox and scripts may still be found at https://bitbucket.org/natcap/invest.arcgis.
* Fixing an issue in the carbon edge effect model that caused output values in the shapefile to be rounded to the nearest integer.
* Fixing issue in SDR model that would occasionally cause users to see errors about field widths in the output shapefile generation.
* Updated the erodibility sample raster that ships with InVEST for the SDR model.  The old version was in US units, in this version we convert to SI units as the model requires, and clipped the raster to the extents of the other stack to save disk space.

3.3.3 (2017-02-06)
------------------
* Fixed an issue in the UI where the carbon model wouldn't accept negative numbers in the price increase of carbon.
* RouteDEM no longer produces a "tiled_dem.tif" file since that functionality is being deprecated in PyGeoprocessing.
* Fixing an issue in SDR where the optional drainage layer would not be used in most of the SDR biophysical calculations.
* Refactoring so water yield pixels with Kc and et0 equal to be 0 now yields a 0.0 value of water yield on that pixel rather than nodata.
* Light optimization refactor of wind energy model that improves runtimes in some cases by a factor of 2-3.
* Performance optimizations to HRA that improve runtimes by approximately 30%.
* Fixed a broken UI link to Seasonal Water Yield's user's guide.
* Fixed an issue with DelineateIT that caused ArcGIS users to see both the watershed and inverse watershed polygons when viewing the output of the tool.
* Upgrading dependency to PyGeoprocessing 0.3.2.
* Fixed an issue with SDR that caused the LS factor to be an order of magnitue too high in areas where the slope was greater than 9%.  In our sample case this caused sediment export estimates to be about 6% too high, but in cases where analyses are run over steep slopes the error would have been greater.
* ``paver check`` now warns if the ``PYTHONHOME`` environment variable is set.
* API docs now correctly reflect installation steps needed for python development headers on linux.
* Fixed a side effect in the InVEST user interface that would cause ``tempfile.tempdir`` to be set and then not be reset after a model run is finished.
* The InVEST user interface will now record GDAL/OGR log messages in the log messages window and in the logfile written to the workspace.
* Updated branding and usability of the InVEST installer for Windows, and the Mac Disk Image (.dmg).


3.3.2 (2016-10-17)
------------------
* Partial test coverage for HRA model.
* Full test coverage for Overlap Analysis model.
* Full test coverage for Finfish Aquaculture.
* Full test coverage for DelineateIT.
* Full test coverage for RouteDEM.
* Fixed an issue in Habitat Quality where an error in the sample table or malformed threat raster names would display a confusing message to the user.
* Full test coverage for scenario generator proximity model.
* Patching an issue in seasonal water yield that causes an int overflow error if the user provides a floating point landcover map and the nodata value is outside of the range of an int64.
* Full test coverage for the fisheries model.
* Patched an issue that would cause the Seasonal Water Edge model to crash when the curve number was 100.
* Patching a critical issue with forest carbon edge that would give incorrect results for edge distance effects.
* Patching a minor issue with forest carbon edge that would cause the model to crash if only one  interpolation point were selected.
* Full test coverage for pollination model.
* Removed "farms aggregation" functionality from the InVEST pollination model.
* Full test coverage for the marine water quality model.
* Full test coverage for GLOBIO model.
* Full test coverage for carbon forest edge model.
* Upgraded SciPy dependancy to 0.16.1.
* Patched bug in NDR that would cause a phosphorus density to be reported per pixel rather than total amount of phosporous in a pixel.
* Corrected an issue with the uses of buffers in the euclidean risk function of Habitat Risk Assessment.  (issue #3564)
* Complete code coverage tests for Habitat Quality model.
* Corrected an issue with the ``Fisheries_Inputs.csv`` sample table used by Overlap Analysis.  (issue #3548)
* Major modifications to Terrestrial Carbon model to include removing the harvested wood product pool, uncertainty analysis, and updated efficient raster calculations for performance.
* Fixed an issue in GLOBIO that would cause model runs to crash if the AOI marked as optional was not present.
* Removed the deprecated and incomplete Nearshore Wave and Erosion model (``natcap.invest.nearshore_wave_and_erosion``).
* Removed the deprecated Timber model (``natcap.invest.timber``).
* Fixed an issue where seasonal water yield would raise a divide by zero error if a watershed polygon didn't cover a valid data region.  Now sets aggregation quantity to zero and reports a warning in the log.
* ``natcap.invest.utils.build_file_registry`` now raises a ``ValueError`` if a path is not a string or list of strings.
* Fixed issues in NDR that would indicate invalid values were being processed during runtimes by skipping the invalid calculations in the first place rather than calculating them and discarding after the fact.
* Complete code coverage tests for NDR model.
* Minor (~10% speedup) performance improvements to NDR.
* Added functionality to recreation model so that the `monthly_table.csv` file now receives a file suffix if one is provided by the user.
* Fixed an issue in SDR where the m exponent was calculated incorrectly in many situations resulting in an error of about 1% in total export.
* Fixed an issue in SDR that reported runtime overflow errors during normal processing even though the model completed without other errors.

3.3.1 (2016-06-13)
------------------
* Refactored API documentation for readability, organization by relevant topics, and to allow docs to build on `invest.readthedocs.io <http://invest.readthedocs.io>`_,
* Installation of ``natcap.invest`` now requires ``natcap.versioner``.  If this is not available on the system at runtime, setuptools will make it available at runtime.
* InVEST Windows installer now includes HISTORY.rst as the changelog instead of the old ``InVEST_Updates_<version>`` files.
* Habitat suitability model is generalized and released as an API only accessible model.  It can be found at ``natcap.invest.habitat_suitability.execute``.  This model replaces the oyster habitat suitability model.
    * The refactor of this model requires an upgrade to ``numpy >= 1.11.0``.
* Fixed a crash in the InVEST CLI where calling ``invest`` without a parameter would raise an exception on linux-based systems.  (Issue `#3528 <https://bitbucket.org/natcap/invest/issues/3515>`_)
* Patched an issue in Seasonal Water Yield model where a nodata value in the landcover map that was equal to ``MAX_INT`` would cause an overflow error/crash.
* InVEST NSIS installer will now optionally install the Microsoft Visual C++ 2008 redistributable on Windows 7 or earlier.  This addresses a known issue on Windows 7 systems when importing GDAL binaries (Issue `#3515 <https://bitbucket.org/natcap/invest/issues/3515>`_).  Users opting to install this redistributable agree to abide by the terms and conditions therein.
* Removed the deprecated subpackage ``natcap.invest.optimization``.
* Updated the InVEST license to legally define the Natural Capital Project.
* Corrected an issue in Coastal Vulnerability where an output shapefile was being recreated for each row, and where field values were not being stored correctly.
* Updated Scenario Generator model to add basic testing, file registry support, PEP8 and PEP257 compliance, and to fix several bugs.
* Updated Crop Production model to add a simplified UI, faster runtime, and more testing.

3.3.0 (2016-03-14)
------------------
* Refactored Wind Energy model to use a CSV input for wind data instead of a Binary file.
* Redesigned InVEST recreation model for a single input streamlined interface, advanced analytics, and refactored outputs.  While the model is still based on "photo user days" old model runs are not backward compatable with the new model or interface. See the Recreation Model user's guide chapter for details.
    * The refactor of this model requires an upgrade to ``GDAL >=1.11.0 <2.0`` and ``numpy >= 1.10.2``.
* Removed nutrient retention (water purification) model from InVEST suite and replaced it with the nutrient delivery ratio (NDR) model.  NDR has been available in development relseases, but has now officially been added to the set of Windows Start Menu models and the "under development" tag in its users guide has been removed.  See the InVEST user's guide for details between the differences and advantages of NDR over the old nutrient model.
* Modified NDR by adding a required "Runoff Proxy" raster to the inputs.  This allows the model to vary the relative intensity of nutrient runoff based on varying precipitation variability.
* Fixed a bug in the Area Change rule of the Rule-Based Scenario Generator, where units were being converted incorrectly. (Issue `#3472 <https://bitbucket.org/natcap/invest/issues/3472>`_) Thanks to Fosco Vesely for this fix.
* InVEST Seasonal Water Yield model released.
* InVEST Forest Carbon Edge Effect model released.
* InVEST Scenario Generator: Proximity Based model released and renamed the previous "Scenario Generator" to "Scenario Generator: Rule Based".
* Implemented a blockwise exponential decay kernel generation function, which is now used in the Pollination and Habitat Quality models.
* GLOBIO now uses an intensification parameter and not a map to average all agriculture across the GLOBIO 8 and 9 classes.
* GLOBIO outputs modified so core outputs are in workspace and intermediate outputs are in a subdirectory called 'intermediate_outputs'.
* Fixed a crash with the NDR model that could occur if the DEM and landcover maps were different resolutions.
* Refactored all the InVEST model user interfaces so that Workspace defaults to the user's home "Documents" directory.
* Fixed an HRA bug where stessors with a buffer of zero were being buffered by 1 pixel
* HRA enhancement which creates a common raster to burn all input shapefiles onto, ensuring consistent alignment.
* Fixed an issue in SDR model where a landcover map that was smaller than the DEM would create extraneous "0" valued cells.
* New HRA feature which allows for "NA" values to be entered into the "Ratings" column for a habitat / stressor pair in the Criteria Ratings CSV. If ALL ratings are set to NA, the habitat / stressor will be treated as having no interaction. This means in the model, that there will be no overlap between the two sources. All rows parameters with an NA rating will not be used in calculating results.
* Refactored Coastal Blue Carbon model for greater speed, maintainability and clearer documentation.
* Habitat Quality bug fix when given land cover rasters with different pixel sizes than threat rasters. Model would use the wrong pixel distance for the convolution kernel.
* Light refactor of Timber model. Now using CSV input attribute file instead of DBF file.
* Fixed clipping bug in Wave Energy model that was not properly clipping polygons correctly. Found when using global data.
* Made the following changes / updates to the coastal vulnerability model:
    * Fixed a bug in the model where the geomorphology ranks were not always being used correctly.
    * Removed the HTML summary results output and replaced with a link to a dashboard that helps visualize and interpret CV results.
    * Added a point shapefile output: 'outputs/coastal_exposure.shp' that is a shapefile representation of the corresponding CSV table.
    * The model UI now requires the 'Relief' input. No longer optional.
    * CSV outputs and Shapefile outputs based on rasters now have x, y coorinates of the center of the pixel instead of top left of the pixel.
* Turning setuptools' zip_safe to False for consistency across the Natcap Namespace.
* GLOBIO no longer requires user to specify a keyfield in the AOI.
* New feature to GLOBIO to summarize MSA by AOI.
* New feature to GLOBIO to use a user defined MSA parameter table to do the MSA thresholds for infrastructure, connectivity, and landuse type
* Documentation to the GLOBIO code base including the large docstring for 'execute'.

3.2.0 (2015-05-31)
------------------
InVEST 3.2.0 is a major release with the addition of several experimental models and tools as well as an upgrade to the PyGeoprocessing core:

* Upgrade to PyGeoprocessing v0.3.0a1 for miscelaneous performance improvements to InVEST's core geoprocessing routines.
* An alpha unstable build of the InVEST crop production model is released with partial documentation and sample data.
* A beta build of the InVEST fisheries model is released with documentation and sample data.
* An alpha unstable build of the nutrient delivery ratio (NDR) model is available directly under InVEST's instalation directory at  ``invest-x86/invest_ndr.exe``; eventually this model will replace InVEST's current "Nutrient" model.  It is currently undocumented and unsupported but inputs are similar to that of InVEST's SDR model.
* An alpha unstable build of InVEST's implementation of GLOBIO is available directly under InVEST's instalation directory at ``invest-x86/invest_globio.exe``.  It is currently undocumented but sample data are provided.
* DelinateIT, a watershed delination tool based on PyGeoprocessing's d-infinity flow algorithm is released as a standalone tool in the InVEST repository with documentation and sample data.
* Miscelaneous performance patches and bug fixes.

3.1.3 (2015-04-23)
------------------
InVEST 3.1.3 is a hotfix release patching a memory blocking issue resolved in PyGeoprocessing version 0.2.1.  Users might have experienced slow runtimes on SDR or other routed models.

3.1.2 (2015-04-15)
------------------
InVEST 3.1.2 is a minor release patching issues mostly related to the freshwater routing models and signed GDAL Byte datasets.

* Patching an issue where some projections were not regognized and InVEST reported an UnprojectedError.
* Updates to logging that make it easier to capture logging messages when scripting InVEST.
* Shortened water yield user interface height so it doesn't waste whitespace.
* Update PyGeoprocessing dependency to version 0.2.0.
* Fixed an InVEST wide issue related to bugs stemming from the use of signed byte raster inputs that resulted in nonsensical outputs or KeyErrors.
* Minor performance updates to carbon model.
* Fixed an issue where DEMS with 32 bit ints and INT_MAX as the nodata value nodata value incorrectly treated the nodata value in the raster as a very large DEM value ultimately resulting in rasters that did not drain correctly and empty flow accumulation rasters.
* Fixed an issue where some reservoirs whose edges were clipped to the edge of the watershed created large plateaus with no drain except off the edge of the defined raster.  Added a second pass in the plateau drainage algorithm to test for these cases and drains them to an adjacent nodata area if they occur.
* Fixed an issue in the Fisheries model where the Results Suffix input was invariably initializing to an empty string.
* Fixed an issue in the Blue Carbon model that prevented the report from being generated in the outputs file.

3.1.1 (2015-03-13)
------------------
InVEST 3.1.1 is a major performance and memory bug patch to the InVEST toolsuite.  We recommend all users upgrade to this version.

* Fixed an issue surrounding reports of SDR or Nutrient model outputs of zero values, nodata holes, excessive runtimes, or out of memory errors.  Some of those problems happened to be related to interesting DEMs that would break the flat drainage algorithm we have inside RouteDEM that adjusted the heights of those regions to drain away from higher edges and toward lower edges, and then pass the height adjusted dem to the InVEST model to do all its model specific calculations.  Unfortunately this solution was not amenable to some degenerate DEM cases and we have now adjusted the algorithm to treat each plateau in the DEM as its own separate region that is processed independently from the other regions. This decreases memory use so we never effectively run out of memory at a minor hit to overall runtime.  We also now adjust the flow direction directly instead of adjust the dem itself.  This saves us from having to modify the DEM and potentially get it into a state where a drained plateau would be higher than its original pixel neighbors that used to drain into it.

There are side effects that result in sometimes large changes to un calibrated runs of SDR or nutrient.  These are related to slightly different flow directions across the landscape and a bug fix on the distance to stream calculation.

* InVEST geoprocessing now uses the PyGeoprocessing package (v0.1.4) rather than the built in functionality that used to be in InVEST.  This will not affect end users of InVEST but may be of interest to users who script InVEST calls who want a standalone Python processing package for raster stack math and hydrological routing.  The project is hosted at https://bitbucket.org/richpsharp/pygeoprocessing.

* Fixed an marine water quality issue where users could input AOIs that were unprojected, but output pixel sizes were specified in meters.  Really the output pixel size should be in the units of the polygon and are now specified as such.  Additionally an exception is raised if the pixel size is too small to generate a numerical solution that is no longer a deep scipy error.

* Added a suffix parameter to the timber and marine water quality models that append a user defined string to the output files; consistent with most of the other InVEST models.

* Fixed a user interface issue where sometimes the InVEST model run would not open a windows explorer to the user's workspace.  Instead it would open to C:\User[..]\My Documents.  This would often happen if there were spaces in the the workspace name or "/" characters in the path.

* Fixed an error across all InVEST models where a specific combination of rasters of different cell sizes and alignments and unsigned data types could create errors in internal interpolation of the raster stacks.  Often these would appear as 'KeyError: 0' across a variety of contexts.  Usually the '0' was an erroneous value introduced by a faulty interpolation scheme.

* Fixed a MemoryError that could occur in the pollination and habitat quality models when the the base landcover map was large and the biophysical properties table allowed the effect to be on the order of that map.  Now can use any raster or range values with only a minor hit to runtime performance.

* Fixed a serious bug in the plateau resolution algorithm that occurred on DEMs with large plateau areas greater than 10x10 in size.  The underlying 32 bit floating point value used to record small height offsets did not have a large enough precision to differentiate between some offsets thus creating an undefined flow direction and holes in the flow accumulation algorithm.

* Minor performance improvements in the routing core, in some cases decreasing runtimes by 30%.

* Fixed a minor issue in DEM resolution that occurred when a perfect plateau was encountered.  Rather that offset the height so the plateau would drain, it kept the plateau at the original height.  This occurred because the uphill offset was nonexistent so the algorithm assumed no plateau resolution was needed.  Perfect plateaus now drain correctly.  In practice this kind of DEM was encountered in areas with large bodies of water where the remote sensing algorithm would classify the center of a lake 1 meter higher than the rest of the lake.

* Fixed a serious routing issue where divergent flow directions were not getting accumulated 50% of the time. Related to a division speed optimization that fell back on C-style modulus which differs from Python.

* InVEST SDR model thresholded slopes in terms of radians, not percent thus clipping the slope tightly between 0.001 and 1%.  The model now only has a lower threshold of 0.00005% for the IC_0 factor, and no other thresholds.  We believe this was an artifact left over from an earlier design of the model.


* Fixed a potential memory inefficiency in Wave Energy Model when computing the percentile rasters. Implemented a new memory efficient percentile algorithm and updated the outputs to reflect the new open source framework of the model. Now outputting csv files that describe the ranges and meaning of the percentile raster outputs.

* Fixed a bug in Habitat Quality where the future output "quality_out_f.tif" was not reflecting the habitat value given in the sensitivity table for the specified landcover types.


3.1.0 (2014-11-19)
------------------
InVEST 3.1.0 (http://www.naturalcapitalproject.org/download.html) is a major software and science milestone that includes an overhauled sedimentation model, long awaited fixes to exponential decay routines in habitat quality and pollination, and a massive update to the underlying hydrological routing routines.  The updated sediment model, called SDR (sediment delivery ratio), is part of our continuing effort to improve the science and capabilities of the InVEST tool suite.  The SDR model inputs are backwards comparable with the InVEST 3.0.1 sediment model with two additional global calibration parameters and removed the need for the retention efficiency parameter in the biophysical table; most users can run SDR directly with the data they have prepared for previous versions.  The biophysical differences between the models are described in a section within the SDR user's guide and represent a superior representation of the hydrological connectivity of the watershed, biophysical parameters that are independent of cell size, and a more accurate representation of sediment retention on the landscape.  Other InVEST improvements to include standard bug fixes, performance improvements, and usability features which in part are described below:

* InVEST Sediment Model has been replaced with the InVEST Sediment Delivery Ratio model.  See the SDR user's guide chapter for the difference between the two.
* Fixed an issue in the pollination model where the exponential decay function decreased too quickly.
* Fixed an issue in the habitat quality model where the exponential decay function decreased too quickly and added back linear decay as an option.
* Fixed an InVEST wide issue where some input rasters that were signed bytes did not correctly map to their negative nodata values.
* Hydropower input rasters have been normalized to the LULC size so sampling error is the same for all the input watersheds.
* Adding a check to make sure that input biophysical parameters to the water yield model do not exceed invalid scientific ranges.
* Added a check on nutrient retention in case the upstream water yield was less than 1 so that the log value did not go negative.  In that case we clamp upstream water yield to 0.
* A KeyError issue in hydropower was resolved that occurred when the input rasters were at such a coarse resolution that at least one pixel was completely contained in each watershed.  Now a value of -9999 will be reported for watersheds that don't contain any valid data.
* An early version of the monthly water yield model that was erroneously included in was in the installer; it was removed in this version.
* Python scripts necessary for running the ArcGIS version of Coastal Protection were missing.  They've since been added back to the distribution.
* Raster calculations are now processed by raster block sizes.  Improvements in raster reads and writes.
* Fixed an issue in the routing core where some wide DEMs would cause out of memory errors.
* Scenario generator marked as stable.
* Fixed bug in HRA where raster extents of shapefiles were not properly encapsulating the whole AOI.
* Fixed bug in HRA where any number of habitats over 4 would compress the output plots. Now extends the figure so that all plots are correctly scaled.
* Fixed a bug in HRA where the AOI attribute 'name' could not be an int. Should now accept any type.
* Fixed bug in HRA which re-wrote the labels if it was run immediately without closing the UI.
* Fixed nodata masking bug in Water Yield when raster extents were less than that covered by the watershed.
* Removed hydropower calibration parameter form water yield model.
* Models that had suffixes used to only allow alphanumeric characters.  Now all suffix types are allowed.
* A bug in the core platform that would occasionally cause routing errors on irregularly pixel sized rasters was fixed.  This often had the effect that the user would see broken streams and/or nodata values scattered through sediment or nutrient results.
* Wind Energy:
        * Added new framework for valuation component. Can now input a yearly price table that spans the lifetime of the wind farm. Also if no price table is made, can specify a price for energy and an annual rate of change.
        * Added new memory efficient distance transform functionality
        * Added ability to leave out 'landing points' in 'grid connection points' input. If not landing points are found, it will calculate wind farm directly to grid point distances
* Error message added in Wave Energy if clip shape has no intersection
* Fixed an issue where the data type of the nodata value in a raster might be different than the values in the raster.  This was common in the case of 64 bit floating point values as nodata when the underlying raster was 32 bit.  Now nodata values are cast to the underlying types which improves the reliability of many of the InVEST models.


3.0.1 (2014-05-19)
------------------
* Blue Carbon model released.

* HRA UI now properly reflects that the Resolution of Analysis is in meters, not meters squared, and thus will be applied as a side length for a raster pixel.

* HRA now accepts CSVs for ratings scoring that are semicolon separated as well as comma separated.

* Fixed a minor bug in InVEST's geoprocessing aggregate core that now consistently outputs correct zonal stats from the underlying pixel level hydro outputs which affects the water yield, sediment, and nutrient models.

* Added compression to InVEST output geotiff files.  In most cases this reduces output disk usage by a factor of 5.

* Fixed an issue where CSVs in the sediment model weren't open in universal line read mode.

* Fixed an issue where approximating whether pixel edges were the same size was not doing an approximately equal function.

* Fixed an issue that made the CV model crash when the coastline computed from the landmass didn't align perfectly with that defined in the geomorphology layer.

* Fixed an issue in the CV model where the intensity of local wave exposure was very low, and yielded zero local wave power for the majority of coastal segments.

* Fixed an issue where the CV model crashes if a coastal segment is at the edge of the shore exposure raster.

* Fixed the exposure of segments surrounded by land that appeared as exposed when their depth was zero.

* Fixed an issue in the CV model where the natural habitat values less than 5 were one unit too low, leading to negative habitat values in some cases.

* Fixed an exponent issue in the CV model where the coastal vulnerability index was raised to a power that was too high.

* Fixed a bug in the Scenic Quality model that prevented it from starting, as well as a number of other issues.

* Updated the pollination model to conform with the latest InVEST geoprocessing standards, resulting in an approximately 33% speedup.

* Improved the UI's ability to remember the last folder visited, and to have all file and folder selection dialogs have access to this information.

* Fixed an issue in Marine Water Quality where the UV points were supposed to be optional, but instead raised an exception when not passed in.

3.0.0 (2014-03-23)
------------------
The 3.0.0 release of InVEST represents a shift away from the ArcGIS to the InVEST standalone computational platform.  The only exception to this shift is the marine coastal protection tier 1 model which is still supported in an ArcGIS toolbox and has no InVEST 3.0 standalone at the moment.  Specific changes are detailed below

* A standalone version of the aesthetic quality model has been developed and packaged along with this release.  The standalone outperforms the ArcGIS equivalent and includes a valuation component.  See the user's guide for details.

* The core water routing algorithms for the sediment and nutrient models have been overhauled.  The routing algorithms now correctly adjust flow in plateau regions, address a bug that would sometimes not route large sections of a DEM, and has been optimized for both run time and memory performance.  In most cases the core d-infinity flow accumulation algorithm out performs TauDEM.  We have also packaged a simple interface to these algorithms in a standalone tool called RouteDEM; the functions can also be referenced from the scripting API in the invest_natcap.routing package.

* The sediment and nutrient models are now at a production level release.  We no longer support the ArcGIS equivalent of these models.

* The sediment model has had its outputs simplified with major changes including the removal of the 'pixel mean' outputs, a direct output of the pixel level export and retention maps, and a single output shapefile whose attribute table contains aggregations of sediment output values.  Additionally all inputs to the sediment biophysical table including p, c, and retention coefficients are now expressed as a proportion between 0 and 1; the ArcGIS model had previously required those inputs were integer values between 0 and 1000.  See the "Interpreting Results" section of sediment model for full details on the outputs.

* The nutrient model has had a similar overhaul to the sediment model including a simplified output structure with many key outputs contained in the attribute table of the shapefile.  Retention coefficients are also expressed in proportions between 0 and 1.  See the "Interpreting Results" section of nutrient model for full details on the outputs.

* Fixed a bug in Habitat Risk Assessment where the HRA module would incorrectly error if a criteria with a 0 score (meant to be removed from the assessment) had a 0 data quality or weight.

* Fixed a bug in Habitat Risk Assessment where the average E/C/Risk values across the given subregion were evaluating to negative numbers.

* Fixed a bug in Overlap Analysis where Human Use Hubs would error if run without inter-activity weighting, and Intra-Activity weighting would error if run without Human Use Hubs.

* The runtime performance of the hydropower water yield model has been improved.

* Released InVEST's implementation of the D-infinity flow algorithm in a tool called RouteDEM available from the start menu.

* Unstable version of blue carbon available.

* Unstable version of scenario generator available.

* Numerous other minor bug fixes and performance enhacnements.



2.6.0 (2013-12-16)
------------------
The 2.6.0 release of InVEST removes most of the old InVEST models from the Arc toolbox in favor of the new InVEST standalone models.  While we have been developing standalone equivalents for the InVEST Arc models since version 2.3.0, this is the first release in which we removed support for the deprecated ArcGIS versions after an internal review of correctness, performance, and stability on the standalones.  Additionally, this is one of the last milestones before the InVEST 3.0.0 release later next year which will transition InVEST models away from strict ArcGIS dependence to a standalone form.

Specifically, support for the following models have been moved from the ArcGIS toolbox to their Windows based standalones: (1) hydropower/water yield, (2) finfish aquaculture, (3) coastal protection tier 0/coastal vulnerability, (4) wave energy, (5) carbon, (6) habitat quality/biodiversity, (7) pollination, (8) timber, and (9) overlap analysis.  Additionally, documentation references to ArcGIS for those models have been replaced with instructions for launching standalone InVEST models from the Windows start menu.

This release also addresses minor bugs, documentation updates, performance tweaks, and new functionality to the toolset, including:

*  A Google doc to provide guidance for scripting the InVEST standalone models: https://docs.google.com/document/d/158WKiSHQ3dBX9C3Kc99HUBic0nzZ3MqW3CmwQgvAqGo/edit?usp=sharing

* Fixed a bug in the sample data that defined Kc as a number between 0 and 1000 instead of a number between 0 and 1.

* Link to report an issue now takes user to the online forums rather than an email address.

* Changed InVEST Sediment model standalone so that retention values are now between 0 and 1 instead of 0 and 100.

* Fixed a bug in Biodiversity where if no suffix were entered output filenames would have a trailing underscore (_) behind them.

* Added documentation to the water purification/nutrient retention model documentation about the standalone outputs since they differ from the ArcGIS version of the model.

* Fixed an issue where the model would try to move the logfile to the workspace after the model run was complete and Windows would erroneously report that the move failed.

* Removed the separation between marine and freshwater terrestrial models in the user's guide.  Now just a list of models.

* Changed the name of InVEST "Biodiversity" model to "Habitat Quality" in the module names, start menu, user's guide, and sample data folders.

* Minor bug fixes, performance enhancements, and better error reporting in the internal infrastructure.

* HRA risk in the unstable standalone is calculated differently from the last release. If there is no spatial overlap within a cell, there is automatically a risk of 0. This also applies to the E and C intermediate files for a given pairing. If there is no spatial overlap, E and C will be 0 where there is only habitat. However, we still create a recovery potential raster which has habitat- specific risk values, even without spatial overlap of a stressor. HRA shapefile outputs for high, medium, low risk areas are now calculated using a user-defined maximum number of overlapping stressors, rather than all potential stressors. In the HTML subregion averaged output, we now attribute what portion of risk to a habitat comes from each habitat-stressor pairing. Any pairings which don't overlap will have an automatic risk of 0.

* Major changes to Water Yield : Reservoir Hydropower Production. Changes include an alternative equation for calculating Actual Evapotranspiration (AET) for non-vegetated land cover types including wetlands. This allows for a more accurate representation of processes on land covers such as urban, water, wetlands, where root depth values aren't applicable. To differentiate between the two equations a column 'LULC_veg' has been added to the Biophysical table in Hydropower/input/biophysical_table.csv. In this column a 1 indicates vegetated and 0 indicates non-vegetated.

* The output structure and outputs have also change in Water Yield : Reservoir Hydropower Production. There is now a folder 'output' that contains all output files including a sub directory 'per_pixel' which has three pixel raster outputs. The subwatershed results are only calculated for the water yield portion and those results can be found as a shapefile, 'subwatershed_results.shp', and CSV file, 'subwatershed_results.csv'. The watershed results can be found in similar files: watershed_results.shp and watershed_results.csv. These two files for the watershed outputs will aggregate the Scarcity and Valuation results as well.

* The evapotranspiration coefficients for crops, Kc, has been changed to a decimal input value in the biophysical table. These values used to be multiplied by 1000 so that they were in integer format, that pre processing step is no longer necessary.

* Changing support from richsharp@stanford.edu to the user support forums at http://ncp-yamato.stanford.edu/natcapforums.

2.5.6 (2013-09-06)
------------------
The 2.5.6 release of InVEST that addresses minor bugs, performance
tweaks, and new functionality of the InVEST standalone models.
Including:

* Change the changed the Carbon biophysical table to use code field
  name from LULC to lucode so it is consistent with the InVEST water
  yield biophysical table.

* Added Monte Carlo uncertainty analysis and documentation to finfish
  aquaculture model.

* Replaced sample data in overlap analysis that was causing the model
  to crash.

* Updates to the overlap analysis user's guide.

* Added preprocessing toolkit available under
  C:\{InVEST install directory}\utils

* Biodiversity Model now exits gracefully if a threat raster is not
  found in the input folder.

* Wind Energy now uses linear (bilinear because its over 2D space?)
  interpolation.

* Wind Energy has been refactored to current API.

* Potential Evapotranspiration input has been properly named to
  Reference Evapotranspiration.

* PET_mn for Water Yield is now Ref Evapotranspiration times Kc
  (evapotranspiration coefficient).

* The soil depth field has been renamed 'depth to root restricting
  layer' in both the hydropower and nutrient retention models.

* ETK column in biophysical table for Water Yield is now Kc.

* Added help text to Timber model.

* Changed the behavior of nutrient retention to return nodata values
  when the mean runoff index is zero.

* Fixed an issue where the hydropower model didn't use the suffix
  inputs.

* Fixed a bug in Biodiversity that did not allow for numerals in the
  threat names and rasters.

* Updated routing algorithm to use a modern algorithm for plateau
  direction resolution.

* Fixed an issue in HRA where individual risk pixels weren't being
  calculated correctly.

* HRA will now properly detect in the preprocessed CSVs when criteria
  or entire habitat-stressor pairs are not desired within an
  assessment.

* Added an infrastructure feature so that temporary files are created
  in the user's workspace rather than at the system level
  folder.  This lets users work in a secondary workspace on a USB
  attached hard drive and use the space of that drive, rather than the
  primary operating system drive.

2.5.5 (2013-08-06)
------------------
The 2.5.5 release of InVEST that addresses minor bugs, performance
tweaks, and new functionality of the InVEST standalone models.  Including:

 * Production level release of the 3.0 Coastal Vulnerability model.
    - This upgrades the InVEST 2.5.4 version of the beta standalone CV
      to a full release with full users guide.  This version of the
      CV model should be used in all cases over its ArcGIS equivalent.

 * Production level release of the Habitat Risk Assessment model.
    - This release upgrades the InVEST 2.5.4 beta version of the
      standalone habitat risk assessment model. It should be used in
      all cases over its ArcGIS equivalent.

 * Uncertainty analysis in Carbon model (beta)
    - Added functionality to assess uncertainty in sequestration and
      emissions given known uncertainty in carbon pool stocks.  Users
      can now specify standard  deviations of carbon pools with
      normal distributions as well as desired uncertainty levels.
      New outputs include masks for regions which both sequester and
      emit carbon with a high probability of confidence.  Please see
      the "Uncertainty Analysis" section of the carbon user's guide
      chapter for more information.

 * REDD+ Scenario Analysis in Carbon model (beta)
    - Additional functionality to assist users evaluating REDD
      and REDD+ scenarios in the carbon model.  The uncertainty analysis
      functionality can also be used with these scenarios.
      Please see the "REDD Scenario Analysis" section of the
      carbon user's guide chapter for more information.

 * Uncertainty analysis in Finfish Aquaculture model (beta)
    - Additionally functionality to account for uncertainty in
      alpha and beta growth parameters as well as histogram
      plots showing the distribution of harvest weights and
      net present value.   Uncertainty analysis is performed
      through Monte Carlo runs that normally sample the
      growth parameters.

 * Streamlined Nutrient Retention model functionality
    - The nutrient retention module no longer requires users to explicitly
      run the water yield model.  The model now seamlessly runs water yield
      during execution.

 * Beta release of the recreation model
    - The recreation is available for beta use with limited documentation.

 * Full release of the wind energy model
    - Removing the 'beta' designation on the wind energy model.


Known Issues:

 * Flow routing in the standalone sediment and nutrient models has a
   bug that prevents routing in some (not all) landscapes.  This bug is
   related to resolving d-infinity flow directions across flat areas.
   We are implementing the solution in Garbrecht and Martx (1997).
   In the meanwhile the sediment and nutrient models are still marked
   as beta until this issue is resolved.

2.5.4 (2013-06-07)
------------------
This is a minor release of InVEST that addresses numerous minor bugs and performance tweaks in the InVEST 3.0 models.  Including:

 * Refactor of Wave Energy Model:
    - Combining the Biophysical and Valuation modules into one.
    - Adding new data for the North Sea and Australia
    - Fixed a bug where elevation values that were equal to or greater than zero
      were being used in calculations.
    - Fixed memory issues when dealing with large datasets.
    - Updated core functions to remove any use of depracated functions

 * Performance updates to the carbon model.

 * Nodata masking fix for rarity raster in Biodiversity Model.
    - When computing rarity from a base landuse raster and current or future
      landuse raster, the intersection of the two was not being properly taken.

 * Fixes to the flow routing algorithms in the sediment and nutrient
   retention models in cases where stream layers were burned in by ArcGIS
   hydro tools.  In those cases streams were at the same elevation and caused
   routing issues.

 * Fixed an issue that affected several InVEST models that occured
   when watershed polygons were too small to cover a pixel.  Excessively
   small watersheds are now handled correctly

 * Arc model deprecation.  We are deprecating the following ArcGIS versions
   of our InVEST models in the sense we recommend ALL users use the InVEST
   standalones over the ArcGIS versions, and the existing ArcGIS versions
   of these models will be removed entirely in the next release.

        * Timber
        * Carbon
        * Pollination
        * Biodiversity
        * Finfish Aquaculture

Known Issues:

 * Flow routing in the standalone sediment and nutrient models has a
   bug that prevents routing in several landscapes.  We're not
   certain of the nature of the bug at the moment, but we will fix by
   the next release.  Thus, sediment and nutrient models are marked
   as (beta) since in some cases the DEM routes correctly.

2.5.3 (2013-03-21)
------------------
This is a minor release of InVEST that fixes an issue with the HRA model that caused ArcGIS versions of the model to fail when calculating habitat maps for risk hotspots. This upgrade is strongly recommended for users of InVEST 2.5.1 or 2.5.2.

2.5.2 (2013-03-17)
------------------
This is a minor release of InVEST that fixes an issue with the HRA sample data that caused ArcGIS versions of the model to fail on the training data.  There is no need to upgrade for most users unless you are doing InVEST training.

2.5.1 (2013-03-12)
------------------
This is a minor release of InVEST that does not add any new models, but
does add additional functionality, stability, and increased performance to
one of the InVEST 3.0 standalones:

  - Pollination 3.0 Beta:
        - Fixed a bug where Windows users of InVEST could run the model, but
          most raster outputs were filled with nodata values.

Additionally, this minor release fixes a bug in the InVEST user interface where
collapsible containers became entirely non-interactive.

2.5.0 (2013-03-08)
------------------
This a major release of InVEST that includes new standalone versions (ArcGIS
is not required) our models as well as additional functionality, stability,
and increased performance to many of the existing models.  This release is
timed to support our group's annual training event at Stanford University.
We expect to release InVEST 2.5.1 a couple of weeks after to address any
software issues that arise during the training.  See the release notes
below for details of the release, and please contact richsharp@stanford.edu
for any issues relating to software:

  - *new* Sediment 3.0 Beta:
      - This is a standalone model that executes an order of magnitude faster
        than the original ArcGIS model, but may have memory issues with
        larger datasets. This fix is scheduled for the 2.5.1 release of InVEST.
      - Uses a d-infinity flow algorithm (ArcGIS version uses D8).
      - Includes a more accurate LS factor.
      - Outputs are now summarized by polygon rather than rasterized polygons.
        Users can view results directly as a table rather than sampling a
        GIS raster.
  - *new* Nutrient 3.0 Beta:
      - This is a standalone model that executes an order of magnitude faster
        than the original ArcGIS model, but may have memory issues with
        larger datasets. This fix is scheduled for the 2.5.1 release of InVEST.
      - Uses a d-infinity flow algorithm (ArcGIS version uses D8).
      - Includes a more accurate LS factor.
      - Outputs are now summarized by polygon rather than rasterized polygons.
        Users can view results directly as a table rather than sampling a
        GIS raster.
  - *new* Wind Energy:
      - A new offshore wind energy model.  This is a standalone-only model
        available under the windows start menu.
  - *new* Recreation Alpha:
      - This is a working demo of our soon to be released future land and near
        shore recreation model.  The model itself is incomplete and should only
        be used as a demo or by NatCap partners that know what they're doing.
  - *new* Habitat Risk Assessment 3.0 Alpha:
      - This is a working demo of our soon to be released 3.0 version of habitat
        risk assessment.  The model itself is incomplete and should only
        be used as a demo or by NatCap partners that know what they're doing.
        Users that need to use the habitat risk assessment should use the
        ArcGIS version of this model.

  - Improvements to the InVEST 2.x ArcGIS-based toolset:
      - Bug fixes to the ArcGIS based Coastal Protection toolset.

  - Removed support for the ArcGIS invest_VERSION.mxd map.  We expect to
    transition the InVEST toolset exclusive standalone tools in a few months.  In
    preparation of this we are starting to deprecate parts of our old ArcGIS
    toolset including this ArcMap document.  The InVEST ArcToolbox is still
    available in C:\InVEST_2_5_0\invest_250.tbx.

  - Known issues:

    - The InVEST 3.0 standalones generate open source GeoTiffs as
      outputs rather than the proprietary ESRI Grid format.  ArcGIS 9.3.1
      occasionally displays these rasters incorrectly.  We have found
      that these layers can be visualized in ArcGIS 9.3.1 by following
      convoluted steps: Right Click on the layer and select Properties; click on
      the Symbology tab; select Stretch, agree to calculate a histogram (this will
      create an .aux file that Arc can use for visualization), click "Ok", remove
      the raster from the layer list, then add it back. As an alternative, we
      suggest using an open source GIS Desktop Tool like Quantum GIS or ArcGIS
      version 10.0 or greater.

   - The InVEST 3.0 carbon model will generate inaccurate sequestration results
     if the extents of the current and future maps don't align.  This will be
     fixed in InVEST 2.5.1; in the meanwhile a workaround is to clip both LULCs
     so they have identical overlaps.

   - A user reported an unstable run of InVEST 3.0 water yield.  We are not
     certain what is causing the issue, but we do have a fix that will go out
     in InVEST 2.5.1.

   - At the moment the InVEST standalones do not run on Windows XP.  This appears
     to be related to an incompatibility between Windows XP and GDAL, the an open
     source gis library we use to create and read GIS data.  At the moment we are
     uncertain if we will be able to fix this bug in future releases, but will
     pass along more information in the future.

2.4.5 (2013-02-01)
------------------
This is a minor release of InVEST that does not add any new models, but
does add additional functionality, stability, and increased performance to
many of the InVEST 3.0 standalones:

  - Pollination 3.0 Beta:
      - Greatly improved memory efficiency over previous versions of this model.
      - 3.0 Beta Pollination Biophysical and Valuation have been merged into a
        single tool, run through a unified user interface.
      - Slightly improved runtime through the use of newer core InVEST GIS libraries.
      - Optional ability to weight different species individually.  This feature
        adds a column to the Guilds table that allows the user to specify a
        relative weight for each species, which will be used before combining all
        species supply rasters.
      - Optional ability to aggregate pollinator abundances at specific points
        provided by an optional points shapefile input.
      - Bugfix: non-agricultural pixels are set to a value of 0.0 to indicate no
        value on the farm value output raster.
      - Bugfix: sup_val_<beename>_<scenario>.tif rasters are now saved to the
        intermediate folder inside the user's workspace instead of the output
        folder.
  - Carbon Biophysical 3.0 Beta:
        * Tweaked the user interface to require the user to
          provide a future LULC raster when the 'Calculate Sequestration' checkbox
          is checked.
        * Fixed a bug that restricted naming of harvest layers.  Harvest layers are
          now selected simply by taking the first available layer.
  - Better memory efficiency in hydropower model.
  - Better support for unicode filepaths in all 3.0 Beta user interfaces.
  - Improved state saving and retrieval when loading up previous-run parameters
    in all 3.0 Beta user interfaces.
  - All 3.0 Beta tools now report elapsed time on completion of a model.
  - All 3.0 Beta tools now provide disk space usage reports on completion of a
    model.
  - All 3.0 Beta tools now report arguments at the top of each logfile.
  - Biodiversity 3.0 Beta: The half-saturation constant is now allowed to be a
    positive floating-point number.
  - Timber 3.0 Beta: Validation has been added to the user interface for this
    tool for all tabular and shapefile inputs.
  - Fixed some typos in Equation 1 in the Finfish Aquaculture user's guide.
  - Fixed a bug where start menu items were not getting deleted during an InVEST
    uninstall.
  - Added a feature so that if the user selects to download datasets but the
    datasets don't successfully download the installation alerts the user and
    continues normally.
  - Fixed a typo with tau in aquaculture guide, originally said 0.8, really 0.08.

  - Improvements to the InVEST 2.x ArcGIS-based toolset:
      - Minor bugfix to Coastal Vulnerability, where an internal unit of
        measurements was off by a couple digits in the Fetch Calculator.
      - Minor fixes to various helper tools used in InVEST 2.x models.
      - Outputs for Hargreaves are now saved as geoTIFFs.
      - Thornwaite allows more flexible entering of hours of sunlight.

2.4.4 (2012-10-24)
------------------
- Fixes memory errors experienced by some users in the Carbon Valuation 3.0 Beta model.
- Minor improvements to logging in the InVEST User Interface
- Fixes an issue importing packages for some officially-unreleased InVEST models.

2.4.3 (2012-10-19)
------------------
- Fixed a minor issue with hydropower output vaulation rasters whose statistics were not pre-calculated.  This would cause the range in ArcGIS to show ther rasters at -3e38 to 3e38.
- The InVEST installer now saves a log of the installation process to InVEST_<version>\install_log.txt
- Fixed an issue with Carbon 3.0 where carbon output values were incorrectly calculated.
- Added a feature to Carbon 3.0 were total carbon stored and sequestered is output as part of the running log.
- Fixed an issue in Carbon 3.0 that would occur when users had text representations of floating point numbers in the carbon pool dbf input file.
- Added a feature to all InVEST 3.0 models to list disk usage before and after each run and in most cases report a low free space error if relevant.

2.4.2 (2012-10-15)
------------------
- Fixed an issue with the ArcMap document where the paths to default data were not saved as relative paths.  This caused the default data in the document to not be found by ArcGIS.
- Introduced some more memory-efficient processing for Biodiversity 3.0 Beta.  This fixes an out-of-memory issue encountered by some users when using very large raster datasets as inputs.

2.4.1 (2012-10-08)
------------------
- Fixed a compatibility issue with ArcGIS 9.3 where the ArcMap and ArcToolbox were unable to be opened by Arc 9.3.

2.4.0 (2012-10-05)
------------------
Changes in InVEST 2.4.0

General:

This is a major release which releases two additional beta versions of the
InVEST models in the InVEST 3.0 framework.  Additionally, this release
introduces start menu shortcuts for all available InVEST 3.0 beta models.
Existing InVEST 2.x models can still be found in the included Arc toolbox.

Existing InVEST models migrated to the 3.0 framework in this release
include:

- Biodiversity 3.0 Beta
    - Minor bug fixes and usability enhancements
    - Runtime decreased by a factor of 210
- Overlap Analysis 3.0 Beta
    - In most cases runtime decreased by at least a factor of 15
    - Minor bug fixes and usability enhancements
    - Split into two separate tools:
        * Overlap Analysis outputs rasters with individually-weighted pixels
        * Overlap Analysis: Management Zones produces a shapefile output.
    - Updated table format for input activity CSVs
    - Removed the "grid the seascape" step

Updates to ArcGIS models:

- Coastal vulnerability
    - Removed the "structures" option
    - Minor bug fixes and usability enhancements
- Coastal protection (erosion protection)
    - Incorporated economic valuation option
    - Minor bug fixes and usability enhancements

Additionally there are a handful of minor fixes and feature
enhancements:

- InVEST 3.0 Beta standalones (identified by a new InVEST icon) may be run
  from the Start Menu (on windows navigate to
  Start Menu -> All Programs -> InVEST 2.4.0
- Bug fixes for the calculation of raster statistics.
- InVEST 3.0 wave energy no longer requires an AOI for global runs, but
  encounters memory issues on machines with less than 4GB of RAM.  This
  is a known issue that will be fixed in a minor release.
- Minor fixes to several chapters in the user's guide.
- Minor bug fix to the 3.0 Carbon model: harvest maps are no longer required
  inputs.
- Other minor bug fixes and runtime performance tweaks in the 3.0 framework.
- Improved installer allows users to remove InVEST from the Windows Add/Remove
  programs menu.
- Fixed a visualization bug with wave energy where output rasters did not have the min/max/stdev calculations on them.  This made the default visualization in arc be a gray blob.

2.3.0 (2012-08-02)
------------------
Changes in InVEST 2.3.0

General:

This is a major release which releases several beta versions of the
InVEST models in the InVEST 3.0 framework.  These models run as
standalones, but a GIS platform is needed to edit and view the data
inputs and outputs.  Until InVEST 3.0 is released the original ArcGIS
based versions of these tools will remain the release.

Existing InVEST models migrated to the 3.0 framework in this release
include:

- Reservoir Hydropower Production 3.0 beta
    - Minor bug fixes.
- Finfish Aquaculture
    - Minor bug fixes and usability enhancements.
- Wave Energy 3.0 beta
    - Runtimes for non-global runs decreased by a factor of 7
    - Minor bugs in interpolation that exist in the 2.x model is fixed in
      3.0 beta.
- Crop Pollination 3.0 beta
    - Runtimes decreased by a factor of over 10,000

This release also includes the new models which only exist in the 3.0
framework:

- Marine Water Quality 3.0 alpha with a preliminary  user's guide.

InVEST models in the 3.0 framework from previous releases that now
have a standalone executable include:

- Managed Timber Production Model
- Carbon Storage and Sequestration

Additionally there are a handful of other minor fixes and feature
enhancements since the previous release:

- Minor bug fix to 2.x sedimentation model that now correctly
  calculates slope exponentials.
- Minor fixes to several chapters in the user's guide.
- The 3.0 version of the Carbon model now can value the price of carbon
  in metric tons of C or CO2.
- Other minor bug fixes and runtime performance tweaks in the 3.0 framework.

2.2.2 (2012-03-03)
------------------
Changes in InVEST 2.2.2

General:

This is a minor release which fixes the following defects:

-Fixed an issue with sediment retention model where large watersheds
 allowed loading per cell was incorrectly rounded to integer values.

-Fixed bug where changing the threshold didn't affect the retention output
 because function was incorrectly rounded to integer values.

-Added total water yield in meters cubed to to output table by watershed.

-Fixed bug where smaller than default (2000) resolutions threw an error about
 not being able to find the field in "unitynew".  With non-default resolution,
 "unitynew" was created without an attribute table, so one was created by
 force.

-Removed mention of beta state and ecoinformatics from header of software
 license.

-Modified overlap analysis toolbox so it reports an error directly in the
 toolbox if the workspace name is too long.

2.2.1 (2012-01-26)
------------------
Changes in InVEST 2.2.1

General:

This is a minor release which fixes the following defects:

-A variety of miscellaneous bugs were fixed that were causing crashes of the Coastal Protection model in Arc 9.3.
-Fixed an issue in the Pollination model that was looking for an InVEST1005 directory.
-The InVEST "models only" release had an entry for the InVEST 3.0 Beta tools, but was missing the underlying runtime.  This has been added to the models only 2.2.1 release at the cost of a larger installer.
-The default InVEST ArcMap document wouldn't open in ArcGIS 9.3.  It can now be opened by Arc 9.3 and above.
-Minor updates to the Coastal Protection user's guide.

2.2.0 (2011-12-22)
------------------
In this release we include updates to the habitat risk assessment
model, updates to Coastal Vulnerability Tier 0 (previously named
Coastal Protection), and a new tier 1 Coastal Vulnerability tool.
Additionally, we are releasing a beta version of our 3.0 platform that
includes the terrestrial timber and carbon models.

See the "Marine Models" and "InVEST 3.0 Beta" sections below for more details.

**Marine Models**

1. Marine Python Extension Check

   This tool has been updated to include extension requirements for the new
   Coastal Protection T1 model.  It also reflects changes to the Habitat Risk
   Assessment and Coastal Protection T0 models, as they no longer require the
   PythonWin extension.

2. Habitat Risk Assessment (HRA)

   This model has been updated and is now part of three-step toolset.  The
   first step is a new Ratings Survey Tool which eliminates the need for
   Microsoft Excel when users are providing habitat-stressor ratings.  This
   Survey Tool now allows users to up- and down-weight the importance of
   various criteria.  For step 2, a copy of the Grid the Seascape tool has been
   placed in the HRA toolset.  In the last step, users will run the HRA model
   which includes the following updates:

   - New habitat outputs classifying risk as low, medium, and high
   - Model run status updates (% complete) in the message window
   - Improved habitat risk plots embedded in the output HTML

3. Coastal Protection

   This module is now split into sub-models, each with two parts.  The first
   sub-model is Coastal Vulnerability (Tier 0) and the new addition is Coastal
   Protection (Tier 1).

   Coastal Vulnerability (T0)
   Step 1) Fetch Calculator - there are no updates to this tool.
   Step 2) Vulnerability Index

   - Wave Exposure: In this version of the model, we define wave exposure for
     sites facing the open ocean as the maximum of the weighted average of
     wave's power coming from the ocean or generated by local winds.  We
     weight wave power coming from each of the 16 equiangular sector by the
     percent of time that waves occur in that sector, and based on whether or
     not fetch in that sector exceeds 20km.  For sites that are sheltered, wave
     exposure is the average of wave power generated by the local storm winds
     weighted by the percent occurrence of those winds in each sector.  This
     new method takes into account the seasonality of wind and wave patterns
     (storm waves generally come from a preferential direction), and helps
     identify regions that are not exposed to powerful waves although they are
     open to the ocean (e.g. the leeside of islands).

   - Natural Habitats: The ranking is now computed using the rank of all
     natural habitats present in front of a segment, and we weight the lowest
     ranking habitat 50% more than all other habitats.  Also, rankings and
     protective distance information are to be provided by CSV file instead of
     Excel.  With this new method, shoreline segments that have more habitats
     than others will have a lower risk of inundation and/or erosion during
     storms.

   - Structures: The model has been updated to now incorporate the presence of
     structures by decreasing the ranking of shoreline segments that adjoin
     structures.

   Coastal Protection (T1) - This is a new model which plots the amount of
   sandy beach erosion or consolidated bed scour that backshore regions
   experience in the presence or absence of natural habitats.  It is composed
   of two steps: a Profile Generator and Nearshore Waves and Erosion.  It is
   recommended to run the Profile Generator before the Nearshore Waves and
   Erosion model.

   Step 1) Profile Generator:  This tool helps the user generate a 1-dimensional
   bathymetric and topographic profile perpendicular to the shoreline at the
   user-defined location.  This model provides plenty of guidance for building
   backshore profiles for beaches, marshes and mangroves.  It will help users
   modify bathymetry profiles that they already have, or can generate profiles
   for sandy beaches if the user has not bathymetric data.  Also, the model
   estimates and maps the location of natural habitats present in front of the
   region of interest.  Finally, it provides sample wave and wind data that
   can be later used in the Nearshore Waves and Erosion model, based on
   computed fetch values and default Wave Watch III data.

   Step 2) Nearshore Waves and Erosion: This model estimates profiles of beach
   erosion or values of rates of consolidated bed scour at a site as a function
   of the type of habitats present in the area of interest.  The model takes
   into account the protective effects of vegetation, coral and oyster reefs,
   and sand dunes.  It also shows the difference of protection provided when
   those habitats are present, degraded, or gone.

4. Aesthetic Quality

   This model no longer requires users to provide a projection for Overlap
   Analysis.  Instead, it uses the projection from the user-specified Area of
   Interest (AOI) polygon.  Additionally, the population estimates for this
   model have been fixed.

**InVEST 3.0 Beta**

The 2.2.0 release includes a preliminary version of our InVEST 3.0 beta
platform.  It is included as a toolset named "InVEST 3.0 Beta" in the
InVEST220.tbx.  It is currently only supported with ArcGIS 10.  To launch
an InVEST 3.0 beta tool, double click on the desired tool in the InVEST 3.0
toolset then click "Ok" on the Arc toolbox screen that opens. The InVEST 3.0
tool panel has inputs very similar to the InVEST 2.2.0 versions of the tools
with the following modifications:

InVEST 3.0 Carbon:
  * Fixes a minor bug in the 2.2 version that ignored floating point values
    in carbon pool inputs.
  * Separation of carbon model into a biophysical and valuation model.
  * Calculates carbon storage and sequestration at the minimum resolution of
    the input maps.
  * Runtime efficiency improved by an order of magnitude.
  * User interface streamlined including dynamic activation of inputs based
    on user preference, direct link to documentation, and recall of inputs
    based on user's previous run.

InVEST 3.0 Timber:
  * User interface streamlined including dynamic activation of inputs based
    on user preference, direct link to documentation, and recall of inputs
    based on user's previous run.


2.1.1 (2011-10-17)
------------------
Changes in InVEST 2.1.1

General:

This is a minor release which fixes the following defects:

-A truncation error was fixed on nutrient retention and sedimentation model that involved division by the number of cells in a watershed.  Now correctly calculates floating point division.
-Minor typos were fixed across the user's guide.


2.1 Beta (2011-05-11)
---------------------
Updates to InVEST Beta

InVEST 2.1 . Beta

Changes in InVEST 2.1

General:

1. InVEST versioning
We have altered our versioning scheme.  Integer changes will reflect major changes (e.g. the addition of marine models warranted moving from 1.x to 2.0).  An increment in the digit after the primary decimal indicates major new features (e.g the addition of a new model) or major revisions.  For example, this release is numbered InVEST 2.1 because two new models are included).  We will add another decimal to reflect minor feature revisions or bug fixes.  For example, InVEST 2.1.1 will likely be out soon as we are continually working to improve our tool.
2. HTML guide
With this release, we have migrated the entire InVEST users. guide to an HTML format.  The HTML version will output a pdf version for use off-line, printing, etc.


**MARINE MODELS**

1.Marine Python Extension Check

-This tool has been updated to allow users to select the marine models they intend to run.  Based on this selection, it will provide a summary of which Python and ArcGIS extensions are necessary and if the Python extensions have been successfully installed on the user.s machine.

2.Grid the Seascape (GS)

-This tool has been created to allow marine model users to generate an seascape analysis grid within a specified area of interest (AOI).

-It only requires an AOI and cell size (in meters) as inputs, and produces a polygon grid which can be used as inputs for the Habitat Risk Assessment and Overlap Analysis models.

3. Coastal Protection

- This is now a two-part model for assessing Coastal Vulnerability.  The first part is a tool for calculating fetch and the second maps the value of a Vulnerability Index, which differentiates areas with relatively high or low exposure to erosion and inundation during storms.

- The model has been updated to now incorporate coastal relief and the protective influence of up to eight natural habitat input layers.

- A global Wave Watch 3 dataset is also provided to allow users to quickly generate rankings for wind and wave exposure worldwide.

4. Habitat Risk Assessment (HRA)

This new model allows users to assess the risk posed to coastal and marine habitats by human activities and the potential consequences of exposure for the delivery of ecosystem services and biodiversity.  The HRA model is suited to screening the risk of current and future human activities in order to prioritize management strategies that best mitigate risk.

5. Overlap Analysis

This new model maps current human uses in and around the seascape and summarizes the relative importance of various regions for particular activities.  The model was designed to produce maps that can be used to identify marine and coastal areas that are most important for human use, in particular recreation and fisheries, but also other activities.

**FRESHWATER MODELS**

All Freshwater models now support ArcMap 10.


Sample data:

1. Bug fix for error in Water_Tables.mdb Biophysical table where many field values were shifted over one column relative to the correct field name.

2. Bug fix for incorrect units in erosivity layer.


Hydropower:

1.In Water Yield, new output tables have been added containing mean biophysical outputs (precipitation, actual and potential evapotranspiration, water yield)  for each watershed and sub-watershed.


Water Purification:

1. The Water Purification Threshold table now allows users to specify separate thresholds for nitrogen and phosphorus.   Field names thresh_n and thresh_p replace the old ann_load.

2. The Nutrient Retention output tables nutrient_watershed.dbf and nutrient_subwatershed.dbf now include a column for nutrient retention per watershed/sub-watershed.

3. In Nutrient Retention, some output file names have changed.

4. The user's guide has been updated to explain more accurately the inclusion of thresholds in the biophysical service estimates.


Sedimentation:

1. The Soil Loss output tables sediment_watershed.dbf and sediment_subwatershed.dbf now include a column for sediment retention per watershed/sub-watershed.

2. In Soil Loss, some output file names have changed.

3. The default input value for Slope Threshold is now 75.

4. The user's guide has been updated to explain more accurately the inclusion of thresholds in the biophysical service estimates.

5. Valuation: Bug fix where the present value was not being applied correctly.





2.0 Beta (2011-02-14)
---------------------
Changes in InVEST 2.0

InVEST 1.005 is a minor release with the following modification:

1. Aesthetic Quality

    This new model allows users to determine the locations from which new nearshore or offshore features can be seen.  It generates viewshed maps that can be used to identify the visual footprint of new offshore development.


2. Coastal Vulnerability

    This new model produces maps of coastal human populations and a coastal exposure to erosion and inundation index map.  These outputs can be used to understand the relative contributions of different variables to coastal exposure and to highlight the protective services offered by natural habitats.


3. Aquaculture

    This new model is used to evaluate how human activities (e.g., addition or removal of farms, changes in harvest management practices) and climate change (e.g., change in sea surface temperature) may affect the production and economic value of aquacultured Atlantic salmon.


4. Wave Energy

    This new model provides spatially explicit information, showing potential areas for siting Wave Energy conversion (WEC) facilities with the greatest energy production and value.  This site- and device-specific information for the WEC facilities can then be used to identify and quantify potential trade-offs that may arise when siting WEC facilities.


5. Avoided Reservoir Sedimentation

    - The name of this model has been changed to the Sediment Retention model.

    - We have added a water quality valuation model for sediment retention. The user now has the option to select avoided dredge cost analysis, avoided water treatment cost analysis or both.  The water quality valuation approach is the same as that used in the Water Purification: Nutrient Retention model.

    - The threshold information for allowed sediment loads (TMDL, dead volume, etc.) are now input in a stand alone table instead of being included in the valuation table. This adjusts the biophysical service output for any social allowance of pollution. Previously, the adjustment was only done in the valuation model.

    - The watersheds and sub-watershed layers are now input as shapefiles instead of rasters.

    - Final outputs are now aggregated to the sub-basin scale. The user must input a sub-basin shapefile. We provide the Hydro 1K dataset as a starting option. See users guide for changes to many file output names.

    - Users are strongly advised not to interpret pixel-scale outputs for hydrological understanding or decision-making of any kind. Pixel outputs should only be used for calibration/validation or model checking.


6. Hydropower Production

    - The watersheds and sub-watershed layers are now input as shapefiles instead of rasters.

    - Final outputs are now aggregated to the sub-basin scale. The user must input a sub-basin shapefile. We provide the Hydro 1K dataset as a starting option. See users guide for changes to many file output names.

    - Users are strongly advised not to interpret pixel-scale outputs for hydrological understanding or decision-making of any kind. Pixel outputs should only be used for calibration/validation or model checking.

    - The calibration constant for each watershed is now input in a stand-alone table instead of being included in the valuation table. This makes running the water scarcity model simpler.


7. Water Purification: Nutrient Retention

    - The threshold information for allowed pollutant levels (TMDL, etc.) are now input in a stand alone table instead of being included in the valuation table. This adjusts the biophysical service output for any social allowance of pollution. Previously, the adjustment was only done in the valuation model.

    - The watersheds and sub-watershed layers are now input as shapefiles instead of rasters.

    - Final outputs are now aggregated to the sub-basin scale. The user must input a sub-basin shapefile. We provide the Hydro 1K dataset as a starting option. See users guide for changes to many file output names.

    - Users are strongly advised not to interpret pixel-scale outputs for hydrological understanding or decision-making of any kind. Pixel outputs should only be used for calibration/validation or model checking.


8. Carbon Storage and Sequestration

    The model now outputs an aggregate sum of the carbon storage.


9. Habitat Quality and Rarity

    This model had an error while running ReclassByACII if the land cover codes were not sorted alphabetically.  This has now been corrected and it sorts the reclass file before running the reclassification

    The model now outputs an aggregate sum of the habitat quality.

10. Pollination

    In this version, the pollination model accepts an additional parameter which indicated the proportion of a crops yield that is attributed to wild pollinators.
