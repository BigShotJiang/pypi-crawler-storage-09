"""Tests for navam-invest package."""
