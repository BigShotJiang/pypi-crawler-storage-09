"""Jupyter notebook content."""
