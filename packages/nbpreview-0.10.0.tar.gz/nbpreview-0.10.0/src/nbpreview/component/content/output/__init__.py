"""Jupyter notebook output data."""
