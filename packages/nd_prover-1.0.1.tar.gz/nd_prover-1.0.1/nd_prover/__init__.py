__version__ = '1.0.1'
__author__ = 'Daniyal Akif'
__email__ = 'daniyalakif@gmail.com'
__license__ = 'MIT'
__description__ = 'An interactive Fitch-style proof checker'
__url__ = 'https://github.com/daniyal1249/nd-prover'


from .cli import *
