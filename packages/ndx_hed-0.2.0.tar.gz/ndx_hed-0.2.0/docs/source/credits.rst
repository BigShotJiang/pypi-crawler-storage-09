*******
Credits
*******

.. note::
   The members of the HED Working Group and the NWB community provided valuable feedback during development.

Acknowledgments
===============
The members of the HED Working Group and the NWB community provided valuable feedback during development.

Authors
=======
Kay Robbins  
Ryan Ly  
Oliver Ruebel  

*****
Legal
*****

License
=======
BSD 3-Clause License