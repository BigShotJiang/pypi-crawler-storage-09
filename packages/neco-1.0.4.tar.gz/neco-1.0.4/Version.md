# 1.0.4
* 修复知识图谱的 Document Type 为 Graph

# 1.0.3
* 优化 Lats Agent 和 ChatflowAgent 图结构

# 1.0.2
* 优化 PlanAndExecute Agent 和 ReAct Agent 的 Graph 和输出