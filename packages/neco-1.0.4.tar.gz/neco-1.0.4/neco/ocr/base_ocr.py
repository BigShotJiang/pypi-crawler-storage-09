class BaseOCR:
    def predict(self, file_path: str) -> str:
        pass
