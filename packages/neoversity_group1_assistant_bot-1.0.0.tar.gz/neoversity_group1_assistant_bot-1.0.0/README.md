# assistant-bot

## Running the Application

Run the CLI application using Python's module syntax:

```bash
python3 -m src.presentation.cli.main
```