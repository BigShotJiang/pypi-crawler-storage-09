

class StorageException(Exception):
    """Base exception for storage-related errors."""
    pass