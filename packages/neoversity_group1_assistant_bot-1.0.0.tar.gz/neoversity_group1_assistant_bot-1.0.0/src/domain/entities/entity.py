class Entity:
    pass