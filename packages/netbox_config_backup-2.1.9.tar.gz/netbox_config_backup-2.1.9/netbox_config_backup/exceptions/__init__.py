class JobExit(Exception):
    pass
