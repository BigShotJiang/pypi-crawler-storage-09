# Experiment Results

### 1.1.1 Baseline: 8 Pi 3

- Run 1

- Run 2

- Run 3

- Run 4

- Run 5

### 1.1.2 Baseline: 8 Pi 4

- Run 1

- Run 2

- Run 3

- Run 4

- Run 5

### 2.1.1 Device Allocation and Data Heterogeneity: 8 Pi 3 with IID Data

- Run 1

- Run 2

- Run 3

- Run 4

- Run 5

### 2.1.2 Device Allocation and Data Heterogeneity: 16 Pi 3 with IID Data

- Run 1

- Run 2

- Run 3

- Run 4

- Run 5

### 2.1.3 Device Allocation and Data Heterogeneity: 32 Pi 3 with IID Data

- Run 1

- Run 2

- Run 3

- Run 4

- Run 5

### 2.1.4 Device Allocation and Data Heterogeneity: 64 Pi 3 with IID Data

- Run 1

- Run 2

- Run 3

- Run 4

- Run 5

### 2.2.1 Network Bandwidth: 32 Pi 3 with 25 Mbps

- Run 1

- Run 2

- Run 3

- Run 4

- Run 5

### 2.2.2 Network Bandwidth: 32 Pi 3 with 50 Mbps

- Run 1

- Run 2

- Run 3

- Run 4

- Run 5

### 2.2.3 Network Bandwidth: 32 Pi 3 with 100 Mbps

- Run 1

- Run 2

- Run 3

- Run 4

- Run 5

### 3.1.1 Device Heterogeneity: 4 Pi 3 and 4 Pi 4

- Run 1

- Run 2

- Run 3

- Run 4

- Run 5

### 3.1.2 Device Heterogeneity: 8 Pi 3 and 8 Pi 4

- Run 1

- Run 2

- Run 3

- Run 4

- Run 5

### 3.1.3 Device Heterogeneity: 16 Pi 3 and 16 Pi 4

- Run 1

- Run 2

- Run 3

- Run 4

- Run 5

### 3.2.1 Data Heterogeneity: 8 Pi 3 with Non-IID Data

- Run 1

- Run 2

- Run 3

- Run 4

- Run 5

### 3.2.2 Data Heterogeneity: 16 Pi 3 with Non-IID Data

- Run 1

- Run 2

- Run 3

- Run 4

- Run 5

### 3.2.3 Data Heterogeneity: 32 Pi 3 with Non-IID Data

- Run 1

- Run 2

- Run 3

- Run 4

- Run 5

### 3.2.4 Data Heterogeneity: 64 Pi 3 with Non-IID Data

- Run 1

- Run 2

- Run 3

- Run 4

- Run 5
