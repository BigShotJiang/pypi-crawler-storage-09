# Copyright (C) 2024  rasmunk
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

from network_manager_provider.defaults import BUNDLE
from network_manager_provider.storage.dictdatabase import DictDatabase


async def delete(bundle_id, directory=None):
    response = {}

    bundle_db = DictDatabase(BUNDLE, directory=directory)
    if not await bundle_db.exists():
        if not await bundle_db.touch():
            response["msg"] = (
                f"The Bundle database: {bundle_db.name} did not exist in directory: {directory}, and it could not be created."
            )
            return False, response

    if not await bundle_db.get(bundle_id):
        response["msg"] = f"The Bundle: {bundle_id} does not exist in the database."
        return True, response

    if not await bundle_db.remove(bundle_id):
        response["msg"] = f"Failed to remove the Bundle: {bundle_id}."
        return False, response

    response["msg"] = f"Removed Bundle: {bundle_id}."
    return True, response
