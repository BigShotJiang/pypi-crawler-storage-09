"""Image data interfaces."""

from .imageinterface import ImageInterface

__all__ = ["ImageInterface"]
