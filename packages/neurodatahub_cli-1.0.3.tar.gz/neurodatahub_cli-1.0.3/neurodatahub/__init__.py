"""NeuroDataHub CLI - A command-line interface for downloading neuroimaging datasets."""

__version__ = "0.1.0"
__author__ = "NeuroDataHub Team"
__email__ = "contact@neurodatahub.org"