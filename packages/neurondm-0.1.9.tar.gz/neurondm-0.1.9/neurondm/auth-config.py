{'config-search-paths': ['{:user-config-path}/neurondm/config.yaml',],
 'auth-variables':
 {'neurons-branch': {'environment-variables': 'NEURONS_BRANCH',
                     'default': 'neurons'}}}
