# Copyright 2019 OpenStack Foundation
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.
#

from alembic import op
import sqlalchemy as sa

from neutron.db import migration


"""subnet force network id

Revision ID: c613d0b82681
Revises: 63fd95af7dcd
Create Date: 2019-08-19 11:15:14.443244

"""

# revision identifiers, used by Alembic.
revision = 'c613d0b82681'
down_revision = '63fd95af7dcd'

# milestone identifier, used by neutron-db-manage
neutron_milestone = [migration.TRAIN]


def upgrade():
    op.alter_column('subnets', 'network_id', nullable=False,
                    existing_type=sa.String(36))
