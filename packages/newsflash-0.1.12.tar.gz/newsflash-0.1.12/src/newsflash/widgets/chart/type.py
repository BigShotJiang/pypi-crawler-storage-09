from ..base import Widget


class Chart(Widget): ...
