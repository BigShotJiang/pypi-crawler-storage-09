# Image generation module for MLX backend
