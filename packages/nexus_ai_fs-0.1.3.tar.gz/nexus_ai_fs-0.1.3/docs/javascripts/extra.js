// Custom JavaScript for Nexus documentation

document.addEventListener('DOMContentLoaded', function() {
  console.log('Nexus Documentation loaded');

  // Add custom functionality here
});
