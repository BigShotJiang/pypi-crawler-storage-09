'''
NFL machine learning models
'''

