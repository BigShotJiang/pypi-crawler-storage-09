ALTER TABLE segments ADD CHECK(records > 0);
