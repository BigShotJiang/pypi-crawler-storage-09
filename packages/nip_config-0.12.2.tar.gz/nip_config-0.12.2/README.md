# NIP

User guide can be found in [doc directory](https://github.com/spairet/nip/tree/main/doc)


Installation
--

``` sh
$ pip install nip-config
```

Contribution
--
Everything currently presented in nip and future plans are discussable. Feel free to suggest any ideas for future updates or PRs.

If you find any bugs or unexpected behaviour please report it with an attached config file.
