``nipoppy extract``
===================

.. note::
    This command calls the :py:class:`nipoppy.workflows.extractor.ExtractionRunner` class from the Python :term:`API` internally.

.. click:: nipoppy.cli.cli:extract
   :prog: nipoppy extract
