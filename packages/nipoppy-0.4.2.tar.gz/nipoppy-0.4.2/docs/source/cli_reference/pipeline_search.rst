``nipoppy pipeline search``
===========================

.. note::
   This command calls the :py:class:`nipoppy.workflows.pipeline_store.search.PipelineSearchWorkflow` class from the Python :term:`API` internally.

.. click:: nipoppy.cli.pipeline_catalog:pipeline_search
   :prog: nipoppy pipeline search
