``nipoppy pipeline validate``
=============================

.. note::
   This command calls the :py:class:`nipoppy.workflows.pipeline_store.validate.PipelineValidateWorkflow` class from the Python :term:`API` internally.

.. click:: nipoppy.cli.pipeline_catalog:pipeline_validate
   :prog: nipoppy pipeline validate
