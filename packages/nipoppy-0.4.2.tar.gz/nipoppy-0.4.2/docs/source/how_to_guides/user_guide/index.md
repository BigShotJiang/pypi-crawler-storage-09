```{attention}
This is the **legacy** user guide and may contain information that is out-of-date.
```

# User guide (legacy)

This guide covers the main steps in the Nipoppy protocol:

```{toctree}
---
includehidden:
titlesonly:
---
global_config
populating
organizing_imaging
bids_conversion
processing
tracking
extraction
```
