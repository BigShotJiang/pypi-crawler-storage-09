"""User/pipeline configurations."""
