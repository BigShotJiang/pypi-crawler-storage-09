"""Classes for tabular data representation/manipulation."""
