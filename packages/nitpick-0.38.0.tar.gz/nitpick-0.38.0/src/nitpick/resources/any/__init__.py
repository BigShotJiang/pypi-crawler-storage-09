"""Styles for any language."""
