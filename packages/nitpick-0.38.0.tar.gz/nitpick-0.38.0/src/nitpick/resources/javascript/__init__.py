"""Styles for JavaScript."""
