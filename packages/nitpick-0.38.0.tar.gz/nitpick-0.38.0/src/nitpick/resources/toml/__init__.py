"""Styles for TOML files."""
