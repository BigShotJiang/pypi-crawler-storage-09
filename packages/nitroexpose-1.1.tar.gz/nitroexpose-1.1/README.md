# NitroExpose

**Letest Version:** 1.1  
**Developer:** @Nactire  
**Git Repo:** [GitHub](https://github.com/yuvrajmodz/NitroExpose)

NitroExpose is a Python CLI tool to easily Expose Your Port to Domain.

## Installation & Usage

```bash
pip install NitroExpose --break-system-packages
NitroExpose
```

## Optional installation

```bash
sudo apt update -y
sudo apt install nginx -y
sudo apt install certbot -y
sudo apt install python3-certbot-nginx -y
```