# NitroExpose

**Letest Version:** 1.3  
**Developer:** @Nactire  
**Git Repo:** [GitHub](https://github.com/yuvrajmodz/NitroExpose)

• Easily Expose Your Local Port to Your Domain.  
• Automatic SSL installation.  
• Automatic Tests To Your Site.  
• Expose Within 4 Seconds.  
• Our Software Needs Root Environment.

## Installation

```bash
pip install NitroExpose --break-system-packages
```

## Usage

```bash
NitroExpose
```

## Optional installation

```bash
sudo apt update -y
sudo apt install nginx -y
sudo apt install certbot -y
sudo apt install python3-certbot-nginx -y
```