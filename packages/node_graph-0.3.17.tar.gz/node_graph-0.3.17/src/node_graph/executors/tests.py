def test_enum():
    """Test enum input."""
