def normalize_string_values(string: str) -> str:
    return string.strip().lower()
