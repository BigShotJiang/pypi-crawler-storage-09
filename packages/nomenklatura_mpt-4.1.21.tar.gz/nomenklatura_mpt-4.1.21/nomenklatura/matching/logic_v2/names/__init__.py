from nomenklatura.matching.logic_v2.names.match import name_match

__all__ = ["name_match"]
