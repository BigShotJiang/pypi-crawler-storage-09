# coding=utf-8
from .._impl import (
    connect_download_Platform as Platform,
)

__all__ = [
    'Platform',
]

