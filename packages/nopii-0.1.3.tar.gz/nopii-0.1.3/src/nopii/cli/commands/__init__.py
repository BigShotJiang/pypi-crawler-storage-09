"""
CLI commands for nopii.
"""
