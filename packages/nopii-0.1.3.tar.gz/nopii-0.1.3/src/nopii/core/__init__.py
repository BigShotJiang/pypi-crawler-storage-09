"""Core functionality for nopii."""
