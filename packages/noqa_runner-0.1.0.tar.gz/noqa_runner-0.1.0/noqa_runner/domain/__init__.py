"""Domain layer for runner package"""

from __future__ import annotations
