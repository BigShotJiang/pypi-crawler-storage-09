from .models import Comment

__all__ = [
    "Comment",
]
