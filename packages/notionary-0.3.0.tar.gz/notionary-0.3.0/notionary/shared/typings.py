from typing import Any

type JsonDict = dict[str, Any]
