from .query import WorkspaceQueryConfigBuilder
from .service import NotionWorkspace

__all__ = ["NotionWorkspace", "WorkspaceQueryConfigBuilder"]
