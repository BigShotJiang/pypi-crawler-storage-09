from .builder import WorkspaceQueryConfigBuilder

__all__ = ["WorkspaceQueryConfigBuilder"]
