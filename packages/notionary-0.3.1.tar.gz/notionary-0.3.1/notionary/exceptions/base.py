class NotionaryError(Exception):
    pass
