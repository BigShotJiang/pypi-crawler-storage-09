import platform
import subprocess
import os
import sys

class Notifier:
    def __init__(self, title="Notification", message="Hello!", icon=None, duration=5):
        self.title = title
        self.message = message
        self.icon = icon
        self.duration = duration
        self.os_name = platform.system().lower()

    def notify(self):
        if "windows" in self.os_name:
            self._notify_windows()
        elif "darwin" in self.os_name:  # macOS
            self._notify_macos()
        elif "linux" in self.os_name:
            self._notify_linux()
        else:
            print("❌ OS tidak didukung untuk notifikasi.")

    # --- Windows ---
    def _notify_windows(self):
        try:
            # Coba gunakan toast notification via powershell
            script = f'''
            [Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] > $null
            [Windows.Data.Xml.Dom.XmlDocument, Windows.Data.Xml.Dom.XmlDocument, ContentType = WindowsRuntime] > $null
            $template = @"
            <toast>
                <visual>
                    <binding template="ToastGeneric">
                        <text>{self.title}</text>
                        <text>{self.message}</text>
                    </binding>
                </visual>
            </toast>
            "@
            $xml = New-Object Windows.Data.Xml.Dom.XmlDocument
            $xml.LoadXml($template)
            $toast = [Windows.UI.Notifications.ToastNotification]::new($xml)
            $notifier = [Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier("Python")
            $notifier.Show($toast)
            '''
            subprocess.run(["powershell", "-Command", script], shell=True)
        except Exception as e:
            print("Gagal menampilkan notifikasi Windows:", e)

    # --- macOS ---
    def _notify_macos(self):
        try:
            command = f'''osascript -e 'display notification "{self.message}" with title "{self.title}"' '''
            os.system(command)
        except Exception as e:
            print("Gagal menampilkan notifikasi macOS:", e)

    # --- Linux ---
    def _notify_linux(self):
        try:
            subprocess.run(["notify-send", self.title, self.message])
        except FileNotFoundError:
            print("Perintah 'notify-send' tidak ditemukan. Instal dengan:")
            print("sudo apt install libnotify-bin")