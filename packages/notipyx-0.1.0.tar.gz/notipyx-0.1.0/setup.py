from setuptools import setup, find_packages

setup(
    name="notipyx",
    version="0.1.0",
    author="Athallah Rajendra Putra Juniarto",
    author_email="athallahwork50@gmail.com",
    url="https://github.com/Athallah1234/notifypy",
    description="Library notifikasi desktop sederhana lintas platform (Windows, macOS, Linux).",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    python_requires='>=3.13',
)
