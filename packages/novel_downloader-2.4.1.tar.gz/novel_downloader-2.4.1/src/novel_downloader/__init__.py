#!/usr/bin/env python3
"""
novel_downloader
----------------

Core package for the Novel Downloader project.
"""

__version__ = "2.4.1"

__author__ = "Saudade Z"
__email__ = "saudadez217@gmail.com"
__license__ = "MIT"
