#!/usr/bin/env python3
"""
novel_downloader.apps.cli
-------------------------

Command-line interface layer built on top of rich.
"""

__all__ = ["cli_main"]

from .main import cli_main
