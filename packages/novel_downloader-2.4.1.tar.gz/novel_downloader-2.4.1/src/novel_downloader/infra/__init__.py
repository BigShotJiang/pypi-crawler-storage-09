#!/usr/bin/env python3
"""
novel_downloader.infra
----------------------

Infrastructure layer. Provides integration with external systems.
"""
