#!/usr/bin/env python3
"""
novel_downloader.libs
---------------------

A collection of helper functions and classes.
"""
