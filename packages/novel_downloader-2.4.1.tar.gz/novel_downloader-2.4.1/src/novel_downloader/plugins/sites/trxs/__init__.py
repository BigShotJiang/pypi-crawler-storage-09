#!/usr/bin/env python3
"""
novel_downloader.plugins.sites.trxs
-----------------------------------
"""
