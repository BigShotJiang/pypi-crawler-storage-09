# npstat

🧮 Non-parametric and parametric statistical tests in one package.  
Built on top of `pandas` and `scipy`.

[![PyPI version](https://badge.fury.io/py/npstat.svg)](https://pypi.org/project/npstat/)

## 📦 Installation

```bash
pip install npstat