pip install /deploy/nrtk_explorer-0.6.0-py2.py3-none-any
