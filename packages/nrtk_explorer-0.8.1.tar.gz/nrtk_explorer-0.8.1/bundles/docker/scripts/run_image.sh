#!/usr/bin/env bash
docker run -it --rm -p 8080:80 nrtk_explorer