# Install app from local directory
pip install wheel # needed to install /local-app
pip install /local-app
