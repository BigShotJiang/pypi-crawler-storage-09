nrtk\_explorer.app.applet module
================================

.. automodule:: nrtk_explorer.app.applet
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
