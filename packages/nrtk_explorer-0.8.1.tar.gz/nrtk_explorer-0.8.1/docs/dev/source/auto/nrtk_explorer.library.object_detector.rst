nrtk\_explorer.library.object\_detector module
==============================================

.. automodule:: nrtk_explorer.library.object_detector
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
