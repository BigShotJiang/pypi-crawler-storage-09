from trame_client.utils.version import get_version

__version__ = get_version("nrtk_explorer")
