"""
Sphinx project configuration for the Django package documentation build.

This file exposes minimal settings used by the docs build pipeline and CI.
"""

project = "N-SIDE WeFa"
