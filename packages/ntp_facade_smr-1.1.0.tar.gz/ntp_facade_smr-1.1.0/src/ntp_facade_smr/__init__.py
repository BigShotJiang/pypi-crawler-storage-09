# src/ntp_client_facade/__init__.py

from .facade import TimeBrokerFacade