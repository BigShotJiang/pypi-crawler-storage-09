def example():
    print("Hello world")
