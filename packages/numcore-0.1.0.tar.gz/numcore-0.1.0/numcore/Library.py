def modulus(x):
    return x if x >= 0 else -x