"""
numcore - A mathematics library in active development with plans for 250+ functions.
"""

# Import all functions from your main file
from .Library import *  # Replace 'library' with your actual filename

# Package metadata
__version__ = "0.1.2"
__author__ = "ujwal mantri"