# `nv-one-logger.api`

This package is the **external** facing package interfaces.

**external** refers to the application code that use OneLogger to do job performance instrumentation.

If API and data models (classes) are not used, they should stay in `nv-one-logger.core`.