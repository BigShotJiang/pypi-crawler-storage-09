# SPDX-License-Identifier: Apache-2.0
"""Core abstractions and functionality for the one logger code."""
