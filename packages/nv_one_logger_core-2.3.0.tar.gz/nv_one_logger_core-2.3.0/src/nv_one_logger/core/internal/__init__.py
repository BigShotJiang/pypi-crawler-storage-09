# SPDX-License-Identifier: Apache-2.0
"""Internal utilities for the one logger code."""
