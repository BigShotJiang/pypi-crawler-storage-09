# SPDX-License-Identifier: Apache-2.0
"""This package contains an implementation of the OneLogger exporter for Open Telemetry (OTEL)."""
