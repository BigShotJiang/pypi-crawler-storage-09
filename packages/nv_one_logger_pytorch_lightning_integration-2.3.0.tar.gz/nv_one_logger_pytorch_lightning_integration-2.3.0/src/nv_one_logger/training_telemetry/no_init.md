# Warning

Do not add an **init.py** to this directorty. `nv_one_logger.training_telemetry` is a namespace package. This allows us to have more than one project to contain code for packages that start with `nv_one_logger.training_telemetry.`.
