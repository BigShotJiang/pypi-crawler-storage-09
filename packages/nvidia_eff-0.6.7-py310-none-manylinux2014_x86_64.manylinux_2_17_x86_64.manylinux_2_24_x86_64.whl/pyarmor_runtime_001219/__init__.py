# Pyarmor 8.5.8 (basic), 001219, 2025-10-17T00:31:33.551071
from .pyarmor_runtime import __pyarmor__
