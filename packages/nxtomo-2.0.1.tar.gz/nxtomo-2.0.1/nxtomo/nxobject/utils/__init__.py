"""module with some MixIn classes"""

from .concatenate import concatenate  # noqa F401
