"""paths of the different components in nxtomo application"""
