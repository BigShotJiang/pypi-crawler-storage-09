"""general utils along the project"""

from .utils import *  # noqa F401
