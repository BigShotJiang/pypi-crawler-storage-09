from AnyQt.QtWidgets import QMessageBox

from orangewidget import gui
from orangewidget.settings import Setting
from orangewidget.widget import Output

from oasys2.widget import gui as oasysgui
from oasys2.widget.util import congruence
from oasys2.widget.widget import OWWidget, OWAction
from oasys2.canvas.util.canvas_util import add_widget_parameters_to_module

from syned.storage_ring.light_source import LightSource
from syned.beamline.beamline import Beamline
from syned.util.json_tools import load_from_json_file, load_from_json_url

class FileReader(OWWidget):
    name = "Syned File Reader"
    description = "Utility: Syned File Reader"
    icon = "icons/file_reader.png"
    maintainer = "Manuel Sanchez del Rio"
    maintainer_email = "srio(@at@)esrf.eu"
    priority = 1
    category = "Utility"
    keywords = ["data", "file", "load", "read"]

    want_main_area = 0

    syned_file_name = Setting("")

    class Outputs:
        syned_beamline = Output(name="SynedBeamline",
                                type=Beamline,
                                id="SynedBeamline",
                                default=True, auto_summary=False)

    def __init__(self):
        super().__init__()

        self.runaction = OWAction("Read Syned File", self)
        self.runaction.triggered.connect(self.read_file)
        self.addAction(self.runaction)

        self.setFixedWidth(590)
        self.setFixedHeight(150)

        left_box_1 = oasysgui.widgetBox(self.controlArea, "Syned Local/Remote File Selection", addSpace=True,
                                        orientation="vertical",width=570, height=60)

        figure_box = oasysgui.widgetBox(left_box_1, "", addSpace=True, orientation="horizontal", width=550, height=50)

        self.le_syned_file_name = oasysgui.lineEdit(figure_box, self, "syned_file_name", "Syned File Name or File URL",
                                                    labelWidth=190, valueType=str, orientation="horizontal")
        self.le_syned_file_name.setFixedWidth(260)

        gui.button(figure_box, self, "...", callback=self.selectFile)

        gui.separator(left_box_1, height=20)

        button = gui.button(self.controlArea, self, "Read Syned File", callback=self.read_file)
        button.setFixedHeight(45)

        gui.rubber(self.controlArea)

    def selectFile(self):
        self.le_syned_file_name.setText(oasysgui.selectFileFromDialog(self, self.syned_file_name, "Open Syned File"))

    def read_file(self):
        self.setStatusMessage("")

        try:
            congruence.checkEmptyString(self.syned_file_name, "Syned File Name/Url")

            if len(self.syned_file_name) > 7 and self.syned_file_name[:7] == "http://":
                is_remote = True
            else:
                congruence.checkFile(self.syned_file_name)
                is_remote = False

            try:
                if is_remote:
                    content = load_from_json_url(self.syned_file_name)
                else:
                    content = load_from_json_file(self.syned_file_name)

                self.setStatusMessage("Read %s"%(self.syned_file_name))

                if isinstance(content, Beamline):
                    self.Outputs.syned_beamline.send(content)
                elif isinstance(content, LightSource):
                    self.Outputs.syned_beamline.send(Beamline(content))
                else:
                    raise Exception("json file must contain a SYNED LightSource")
            except Exception as e:
                raise Exception("Error reading SYNED LightSource from file: " + str(e))
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e.args[0]), QMessageBox.Ok)

add_widget_parameters_to_module(__name__)

