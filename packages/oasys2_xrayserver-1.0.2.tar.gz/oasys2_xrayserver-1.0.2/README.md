#XRayServer

This is the project for XRayServer (Sergey Stepanov's X-Ray Server) under OASYS 2
