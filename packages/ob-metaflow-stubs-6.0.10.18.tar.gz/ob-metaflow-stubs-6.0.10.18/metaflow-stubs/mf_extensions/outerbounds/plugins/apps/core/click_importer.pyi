######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.18.12.1+obcheckpoint(0.2.8);ob(v1)                                                   #
# Generated on 2025-10-20T19:13:33.256589                                                            #
######################################################################################################

from __future__ import annotations


from ......_vendor import click as metaflow_click
from ......_vendor import click as click

