# oceloscope-tools-grkmr

General tools and building blocks for working with [Object-Centric Event Logs (OCEL)](https://ocel-standard.org/) and writing plugins for the [OCELoscope](https://github.com/rwth-pads/ocelescope) framework.

---

## 📦 Installation

Install directly from Git:

```bash
pip install git+https://github.com/grkmr/ocelescope-tools.git

