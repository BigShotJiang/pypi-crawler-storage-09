from typing import Literal


OCELFileExtensions = Literal[".xmlocel", ".jsonocel", ".sqlite"]
