# SPDX-FileCopyrightText: 2022 James R. Barlow
# SPDX-License-Identifier: MPL-2.0

"""Plugins in this package are automatically loaded by ocrmypdf."""

from __future__ import annotations
