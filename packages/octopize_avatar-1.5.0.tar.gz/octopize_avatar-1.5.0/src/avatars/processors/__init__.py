from avatars.processors.expected_mean import ExpectedMeanProcessor
from avatars.processors.geolocation_normalization import (
    GeolocationNormalizationProcessor,
)
from avatars.processors.group_modalities import GroupModalitiesProcessor
from avatars.processors.inter_record_bounded_cumulated_difference import (
    InterRecordBoundedCumulatedDifferenceProcessor,
)
from avatars.processors.inter_record_bounded_range_difference import (
    InterRecordBoundedRangeDifferenceProcessor,
)
from avatars.processors.inter_record_cumulated_difference import (
    InterRecordCumulatedDifferenceProcessor,
)
from avatars.processors.inter_record_range_difference import (
    InterRecordRangeDifferenceProcessor,
)
from avatars.processors.perturbation import PerturbationProcessor
from avatars.processors.proportions import ProportionProcessor
from avatars.processors.relative_difference import RelativeDifferenceProcessor
from avatars.processors.to_categorical import ToCategoricalProcessor

__all__ = [
    "ExpectedMeanProcessor",
    "GeolocationNormalizationProcessor",
    "GroupModalitiesProcessor",
    "PerturbationProcessor",
    "ProportionProcessor",
    "RelativeDifferenceProcessor",
    "ToCategoricalProcessor",
    "InterRecordRangeDifferenceProcessor",
    "InterRecordCumulatedDifferenceProcessor",
    "InterRecordBoundedRangeDifferenceProcessor",
    "InterRecordBoundedCumulatedDifferenceProcessor",
]
