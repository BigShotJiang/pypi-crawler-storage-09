from . import test_mail_compose_message_wizard, test_mail_message
