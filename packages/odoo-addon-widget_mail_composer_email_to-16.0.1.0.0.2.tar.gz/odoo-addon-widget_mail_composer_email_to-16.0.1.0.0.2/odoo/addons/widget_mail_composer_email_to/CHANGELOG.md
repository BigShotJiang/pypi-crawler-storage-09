# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]
## [16.0.1.0.0] - 2025-10-16
### Added
- [#161](https://gitlab.com/somitcoop/erp-research/odoo-helpdesk/-/merge_requests/161) Add widget_mail_composer_email_to