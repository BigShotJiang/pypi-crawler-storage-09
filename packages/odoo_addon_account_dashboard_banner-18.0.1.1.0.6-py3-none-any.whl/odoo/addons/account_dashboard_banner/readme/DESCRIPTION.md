The development of this module started with a simple analysis: accountants
tend to forget to update the lock dates. Part of the problem lies in the
fact that the lock dates can be seen in the wizard to update the lock
dates, but accountants have no incentive to start this wizard regularly
to check the lock dates. The idea was to display the lock dates in a
banner at the top of the accounting dashboard, so that accountants
have the value of the lock dates in front of their eyes.

With such a banner in the accounting dashboard to display the lock
dates, there was a great temptation to display other interesting
information in that banner, such as some key figures of the accounting:
liquidity, turnover, customer overdue, etc. It gave birth to the idea to
have a configurable banner in the accounting dashboard!
