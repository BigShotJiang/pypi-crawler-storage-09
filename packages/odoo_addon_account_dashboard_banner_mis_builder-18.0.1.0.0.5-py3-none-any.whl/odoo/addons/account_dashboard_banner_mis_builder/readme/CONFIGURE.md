Go to the menu **Invoicing \> Configuration \> Dashboard \> Dashboard
Banner Cells** and create a new cell with type **MIS Builder KPI**. You will have to select:

- MIS Report
- MIS Report KPI
- MIS Report Period
