This module allows to display MIS Builder KPIs in the accounting dashboard banner. That way, accountants can display any figure they want in the accounting dashboard banner!
