This module implements a generic fiscal year closing system for those
countries where closing/opening moves or other kind of closing
operations are mandatory in accounting books.

It includes a template mechanism that can be used in localizations for
providing the possible configurations to be used by the closing engine.
