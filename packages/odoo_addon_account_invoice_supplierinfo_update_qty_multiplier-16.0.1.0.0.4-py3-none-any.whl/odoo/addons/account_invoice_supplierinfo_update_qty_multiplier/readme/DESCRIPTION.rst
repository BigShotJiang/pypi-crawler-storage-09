This module is a glue module installed if the following module are installed:

* ``account_invoice_supplierinfo_update`` (same repository)
* ``product_supplierinfo_qty_multiplier`` (purchase-workflow repository)

It allows to update 'Multiplier Qty' on supplierinfo, when updating supplierinfo
with the wizard.
