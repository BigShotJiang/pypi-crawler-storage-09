.. image:: https://img.shields.io/badge/licence-GPL--3-blue.svg
    :target: http://www.gnu.org/licenses/gpl-3.0-standalone.html
    :alt: License: GPL-3


========================
Account Reports Hide Ref
========================

Hide journal post ref in general ledger report.

For a detailed documentation have a look at https://www.odoo-wiki.org/account-reports-hide-ref.html

Configuration
~~~~~~~~~~~~~

* No additional configurations needed

Maintainer
~~~~~~~~~~

.. image:: https://raw.githubusercontent.com/Mint-System/Wiki/main/attachments/mint-system-logo.png
  :target: https://www.mint-system.ch

This module is maintained by Mint System GmbH.

For support and more information, please visit `our Website <https://www.mint-system.ch>`__.
