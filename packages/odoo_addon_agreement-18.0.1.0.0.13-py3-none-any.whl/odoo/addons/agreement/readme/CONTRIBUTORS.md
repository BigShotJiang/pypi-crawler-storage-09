- Alexis de Lattre \<<alexis.delattre@akretion.com>\>

- Yves Goldberg \<<yves@ygol.com>\>

- Alexandre Fayolle \<<alexandre.fayolle@camptocamp.com>\>

- [Tecnativa](https://www.tecnativa.com):

  > - Sergio Teruel

- Tharathip Chaweewongphan \<<tharathipc@ecosoft.co.th>\>

- [Acsone](https://www.acsone.eu/):

  - Maxime Franco
- [Trobz](https://www.trobz.com/):

  - Nhan Tran \<<nhant@trobz.com>\>
