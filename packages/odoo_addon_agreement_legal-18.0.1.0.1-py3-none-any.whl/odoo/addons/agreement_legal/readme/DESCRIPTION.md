This module allows you to manage agreements, letter of intent and
contract content. The module is meant to be used by the legal team of a
company and to allow them to define sections, clauses and templates with
their respective content that can be dynamic.

Based on the template, an agreement can be created and the pdf document
generated.

The agreement would go through a workflow to finally become a contract
with the customer signature.
