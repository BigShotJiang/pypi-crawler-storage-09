To use this module:

- Go to Agreement \> Agreements
- Create a new agreement
- Select a template
- Follow the process to get the required approval
- Send the invitation to the customer to review and sign the agreement
