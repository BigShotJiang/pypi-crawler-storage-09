Odoo Agreement App does not provide an easy way to access repair orders
related to an agreement. Some organizations needs to have a quick access
to repair orders to track the performance of an agreement.

This module allows you to link a repair order to an agreement and adds a
smart button on the agreement to look at the list of related repair
orders.
