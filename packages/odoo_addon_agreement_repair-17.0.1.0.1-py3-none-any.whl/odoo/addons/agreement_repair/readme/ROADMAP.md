The roadmap of the Agreement application is documented on
[Github](https://github.com/OCA/contract/issues).
