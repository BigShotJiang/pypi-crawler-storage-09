To use this module, you need to:

- Go to Repair \> Repair Orders
- Select or create a repair order and set the agreement
- Go to Agreement \> Agreements
- Open the previous agreement
- Click on the smart button "Repairs" to see the list of related repair
  orders
