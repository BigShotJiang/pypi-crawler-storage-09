This module adds *Agreement* field to Sales Orders
