Features to evaluate before implementation

- add module agreement_account: agreement_sale'll depends on it
