from . import autovacuum_mixin
from . import ir_attachment
from . import mail_message
from . import vacuum_rule
from . import base
