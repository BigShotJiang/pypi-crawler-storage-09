assign external mssql database

- install base_external_mssql
- open general settings
- open settings for external database
- insert data of known running MSSQL Database on MSSQL Server
- test database connection
