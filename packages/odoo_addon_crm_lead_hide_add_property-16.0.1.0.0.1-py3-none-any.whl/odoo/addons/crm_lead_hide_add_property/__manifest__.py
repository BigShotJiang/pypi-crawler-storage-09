# Copyright 2025 Ángel García de la Chica <angel.garcia@sygel.es>
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).

{
    "name": "CRM Lead Hide Add Property",
    "summary": "CRM Lead Hide Add Property",
    "version": "16.0.1.0.0",
    "category": "CRM",
    "website": "https://github.com/sygel-technology/sy-crm",
    "author": "Sygel, Odoo Community Association (OCA)",
    "license": "AGPL-3",
    "application": False,
    "installable": True,
    "depends": ["crm"],
    "data": [
        "views/crm_lead_views.xml",
    ],
}
