- Assign one or more teams to each stage in CRM \> Configuration \>
  Stages.
- Global stages (with no teams) are visible for all teams.
