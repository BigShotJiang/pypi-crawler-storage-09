- When creating or moving a lead/opportunity, the stage list will be
  filtered according to the team of the lead or the context
  `default_team_id`.
- In kanban view, only relevant stages will be shown.
