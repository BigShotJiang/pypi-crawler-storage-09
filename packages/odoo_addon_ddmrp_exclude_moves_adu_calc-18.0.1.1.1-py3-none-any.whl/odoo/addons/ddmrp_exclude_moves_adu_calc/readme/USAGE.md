You can exclude specific moves or all moves towards a specific location:

- Go to *Inventory \> Reports \> Stock Moves* and click on *Action \>
  Exclude from ADU* for a specific move or several.
- Go to *Inventory \> Configuration \> WH Management \> Locations* and
  check the flag *Exclude this location from ADU calculation* for the
  desired locations.
