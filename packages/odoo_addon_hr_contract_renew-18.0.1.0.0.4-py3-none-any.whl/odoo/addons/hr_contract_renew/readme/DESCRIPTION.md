This module allows extend a contract creating a new one as copy of the original contract.
