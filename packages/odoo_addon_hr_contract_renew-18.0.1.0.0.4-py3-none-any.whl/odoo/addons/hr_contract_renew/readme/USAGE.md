To use this module, you need to:

Go to Employees and select an employee with a contract.

Go to Employee Contracts and select one.

In the form view header, there is a button named Renew Contract. Click it.

In the wizard that opens, set the start date of the new contract and click Renew.

The new contract will be created with the same data as the original contract, but with the new start date and in Draft status. The original contract will be marked as Expired with the end date you set in the wizard, as the date preceding the start of the new contract.