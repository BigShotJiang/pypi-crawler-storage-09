Prepare Kubernetes:

- Start local cluster "kind-kind"

Test connection:

- Open kubectl app and kind-kind context
- Test the connection
- Enter "kubectl --help" as command and click run
- Check if output is given
