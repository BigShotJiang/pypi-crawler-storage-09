# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from . import res_partner
from . import product_product
from . import product_template
from . import mod592
from . import mod592_line_mixin
from . import mod592_acquirer
from . import mod592_manufacturer
from . import res_company
