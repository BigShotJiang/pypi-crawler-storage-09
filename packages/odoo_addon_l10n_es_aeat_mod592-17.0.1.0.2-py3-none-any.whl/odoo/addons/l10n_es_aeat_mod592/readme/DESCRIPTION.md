Módulo que calcula el impuesto al plástico Mod592.

Esto módulo introduce el menú "AEAT 592 Model" en Contabilidad -\>
Informe -\> Declaraciones AEAT -\> AEAT 592 Model.

Es posible visualizar e imprimir por separado:

- Registro de asientos con productos en impuestos al plástico de los
  asquirientes

Es posible exportar los registros a archivo con extensión csv para subir
a la web de la AEAT.
