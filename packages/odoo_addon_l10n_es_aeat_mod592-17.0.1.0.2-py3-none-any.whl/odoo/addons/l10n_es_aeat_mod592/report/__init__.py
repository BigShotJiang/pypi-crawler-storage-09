from . import l10n_es_aeat_mod592_csv
from . import l10n_es_aeat_mod592_xlsx
