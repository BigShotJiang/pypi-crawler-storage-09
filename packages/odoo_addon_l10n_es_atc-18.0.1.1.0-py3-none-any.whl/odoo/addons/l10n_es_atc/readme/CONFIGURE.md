## Configuración de Java
En caso de problemas de memoria durante el uso de `Java`, se pueden modificar los parámetros por defecto creando o ajustando el parámetro del sistema `l10n_es_atc.java_parameters`
