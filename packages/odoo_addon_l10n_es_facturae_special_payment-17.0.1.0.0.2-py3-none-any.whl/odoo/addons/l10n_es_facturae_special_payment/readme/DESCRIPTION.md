### Extensión de l10n_es_facturae — pagos especiales

Agrega casuísticas de pagos especiales en Facturae.

### Tipos especiales

1. Factoring

    - Se agrega la cuenta bancaria de factoring y las referencias.

    - Cuando el modo de pago sea especial (13), se usará la cuenta bancaria de factoring.
