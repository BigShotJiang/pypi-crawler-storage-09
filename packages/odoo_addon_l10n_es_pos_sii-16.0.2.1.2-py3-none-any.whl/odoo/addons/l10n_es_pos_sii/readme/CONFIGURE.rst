No se requieren pasos adicionales de configuración, ver configuración de los
módulos `l10n_es_pos`, `l10n_es_aeat_sii_oca` y `pos_default_partner`.
