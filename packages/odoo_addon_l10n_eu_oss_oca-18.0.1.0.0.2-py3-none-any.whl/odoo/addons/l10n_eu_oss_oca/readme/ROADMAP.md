1.  This module doesn't take into account if one or more products have
    different type of taxes in the destination contry.
2.  There are some countries (for example Spain) that have different
    taxes depending on the region (Canary islands). These use cases
    haven't been considered.
3.  There are some countries (for example Cyprus) that have uncommon
    reduced taxes, depending on the typology of the sold product. In
    Cyprus, it happens with *Supply of goods and services of a kind
    normally intended for use in agricultural production but excluding
    capital goods such as machinery or buildings* where an 8% of VAT has
    to be applied instead of the common reduced type. These use cases
    haven't been considered.
