from . import res_partner
from . import res_partner_operator_einvoice
from . import res_company
from . import res_config_settings
