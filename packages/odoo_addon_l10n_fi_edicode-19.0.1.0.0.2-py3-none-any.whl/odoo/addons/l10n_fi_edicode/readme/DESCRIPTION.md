This module allows users to configure Finnish eInvoicing settings on
your company and customers.

These settings include

-   Edicode: the indentifier used to identify a person or organization
    in eInvoicing services.
-   eInvoicing Operator: the organization that handles eInvoicing
    traffic for the person or organization. This module creates entries
    for most eInvoicing partners currently active in Finland.
