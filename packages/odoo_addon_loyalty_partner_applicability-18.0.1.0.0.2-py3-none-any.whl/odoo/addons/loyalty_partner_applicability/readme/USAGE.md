Restriction on partners can be expressed in the following ways:

- By selecting a list of specific partners
- By providing a domain to filter partners

If both are provided, the condition will be a logical OR.

When you define a domain the datetime object is available as a variable
datetime to allow for dynamic filtering based on the current datetime.
