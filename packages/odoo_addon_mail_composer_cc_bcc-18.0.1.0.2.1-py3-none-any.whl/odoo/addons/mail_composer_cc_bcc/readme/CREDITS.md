The creation and migration of this module from 16.0 to 17.0, and then 17.0 to 18.0 were financially supported by Camptocamp.
