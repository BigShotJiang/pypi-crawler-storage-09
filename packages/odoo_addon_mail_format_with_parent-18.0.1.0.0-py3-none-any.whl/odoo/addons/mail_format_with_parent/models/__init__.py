from . import mail_mail
from . import res_partner
