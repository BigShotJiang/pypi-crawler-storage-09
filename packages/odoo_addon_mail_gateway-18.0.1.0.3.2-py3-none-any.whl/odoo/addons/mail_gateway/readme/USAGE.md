When external messages are received, they will be directly sent to the
discuss menu. Answering to these messages will send the answer to the
external contact. We can assign this messages to any record using the
message actions. Also, we can assign the sender to a partner using the
followers menu and selecting the partner.

On a standard record associated to a partner with external chat, we can
send messages to the external contact directly selecting the methods of
the partner. To use this, we just need to use the

It is recomended to enable chatter notification to all users that will
receive messages from gateways.
