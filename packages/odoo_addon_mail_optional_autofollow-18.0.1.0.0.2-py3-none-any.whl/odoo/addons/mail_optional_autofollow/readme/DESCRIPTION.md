This module adds the possibility to choose if you want to automatically add new recipients as followers on mail.compose.message.
