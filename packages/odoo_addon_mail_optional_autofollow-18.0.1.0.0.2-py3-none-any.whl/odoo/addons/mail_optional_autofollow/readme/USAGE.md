To use this module, you need to use the autofollow recipients checkbox on mail.compose.message:

Technically, this field is initialized to true if there is a 'mail_post_autofollow' key in the current context

![autofollow.png](../static/description/autofollow.png)
