The migration from 16.0 to 17.0 of this module were financially supported by Camptocamp.
