This addon allow to reply on messages from odoo directly. It is useful
when replying to a message from a customer.
