On the messages from threads, a reply button is shown. Once it has been
pressed, a composer with the reply is shown.
