This module shows email notification tracking status for any messages in
mail thread (chatter). Each notified partner will have an intuitive icon
just right to his name.
