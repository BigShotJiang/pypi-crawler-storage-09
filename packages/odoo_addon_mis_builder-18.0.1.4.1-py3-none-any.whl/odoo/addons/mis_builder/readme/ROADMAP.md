The mis_builder
[roadmap](https://github.com/OCA/mis-builder/issues?q=is%3Aopen+is%3Aissue+label%3Aenhancement)
and [known
issues](https://github.com/OCA/mis-builder/issues?q=is%3Aopen+is%3Aissue+label%3Abug)
can be found on GitHub.
