This module allows to pass a reason to scrap with MRP component
operation (glue module).
