from . import mrp_component_operate
