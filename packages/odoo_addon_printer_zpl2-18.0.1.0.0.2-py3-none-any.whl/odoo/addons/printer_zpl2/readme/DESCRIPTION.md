This module extends the **Report to printer** (`base_report_to_printer`)
module to add a ZPL II label printing feature.

This module is meant to be used as a base for module development, and
does not provide a GUI on its own. See below for more details.
