To see this module working, you need to create a view to see the
purchase order lines.

You can do it by creating an action that open them and adding a menu
item to access.
