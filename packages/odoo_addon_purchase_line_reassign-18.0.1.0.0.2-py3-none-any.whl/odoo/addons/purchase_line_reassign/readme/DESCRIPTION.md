Reassign purchase lines between orders
