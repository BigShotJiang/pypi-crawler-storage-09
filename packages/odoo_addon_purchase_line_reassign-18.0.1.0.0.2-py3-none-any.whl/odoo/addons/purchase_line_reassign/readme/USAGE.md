To use this module, you need to:

1.  Go to the purchase order lines new view.
2.  Select the lines that we want to reassign.
3.  Press the action Reassign Lines to Other Purchase.
4.  Select the destination purchase order.
