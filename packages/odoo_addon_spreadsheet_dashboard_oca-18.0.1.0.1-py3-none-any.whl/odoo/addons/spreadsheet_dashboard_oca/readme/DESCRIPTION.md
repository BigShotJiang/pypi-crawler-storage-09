This module allows to edit spreadsheet dashboards using OCA Spreadsheet
editor.
