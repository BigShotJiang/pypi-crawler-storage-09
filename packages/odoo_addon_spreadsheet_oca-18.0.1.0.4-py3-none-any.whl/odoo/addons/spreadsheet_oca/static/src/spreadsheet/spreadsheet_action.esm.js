import {addSpreadsheetActionLazyLoader} from "@spreadsheet/assets_backend/spreadsheet_action_loader";

addSpreadsheetActionLazyLoader("action_spreadsheet_oca");
