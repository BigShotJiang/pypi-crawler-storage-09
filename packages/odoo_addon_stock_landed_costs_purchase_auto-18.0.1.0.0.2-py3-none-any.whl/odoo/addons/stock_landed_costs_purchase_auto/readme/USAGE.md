1.  Go to Purchase\> Orders \> Requests for Quotation.
2.  Create an order with any product.
3.  Confirm Order.
4.  Go to "Receipt" smart-button.
5.  Validate picking.
6.  Go to Inventory \> Operations \> Landed Costs.
7.  There will be a record related to the purchase order and the
    validated picking.
