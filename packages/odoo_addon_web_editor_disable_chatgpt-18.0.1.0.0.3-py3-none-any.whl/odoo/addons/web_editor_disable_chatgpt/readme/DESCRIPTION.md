Installing this module removes ChatGPT capabilities from the HTML editor.
