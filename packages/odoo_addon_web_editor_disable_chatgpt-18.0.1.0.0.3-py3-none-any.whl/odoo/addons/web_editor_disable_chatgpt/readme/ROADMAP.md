* Remove ChatGPT capabilities from WYSIWYG editor.
