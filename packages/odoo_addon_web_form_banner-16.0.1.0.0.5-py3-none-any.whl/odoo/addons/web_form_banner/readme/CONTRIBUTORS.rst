* `Quartile <https://www.quartile.co>`_:

  * Yoshi Tashiro
  * Aung Ko Ko Lin
