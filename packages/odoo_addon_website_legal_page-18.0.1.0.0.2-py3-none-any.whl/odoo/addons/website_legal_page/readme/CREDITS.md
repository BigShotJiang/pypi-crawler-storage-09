## Templates

Templates are based on legal templates publicy provided by
[termsfeed.com](https://termsfeed.com):

- [Privacy
  policy](https://media.termsfeed.com/pdf/privacy-policy-template.pdf)
- [Terms of
  use](https://media.termsfeed.com/pdf/terms-of-use-template.pdf)

## Icon

Icon based on `johnny-automatic-scales-of-justice.svg` from
[Openclipart](https://openclipart.org/detail/26849/scales-of-justice)

Thanks to
[johnny_automatic](https://openclipart.org/user-detail/johnny_automatic)
