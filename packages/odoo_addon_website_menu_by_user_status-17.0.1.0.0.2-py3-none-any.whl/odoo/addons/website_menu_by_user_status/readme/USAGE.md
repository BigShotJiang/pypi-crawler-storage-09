To use this module, you need to:

1.  Activate developer mode
2.  Go to Website \> Configuration \> Menus.
2.  Select the page for which you would like to hide the menu.
3.  In the Related Menu Items table, check whether the menu item is
    visible for logged/unlogged users.
4.  remove default filter to edit website menu line
