The module manages display website menu entries, depending if the user
is logged or not. The selection of the display status can be chosen
logged and/or not.
