Website \> Configuration \> Authorization required URLs: select a
website and enter a relative path, eg: /shop

When public user will try to access mywebsite.com/shop or any of its
child pages, they will be requested to login.
