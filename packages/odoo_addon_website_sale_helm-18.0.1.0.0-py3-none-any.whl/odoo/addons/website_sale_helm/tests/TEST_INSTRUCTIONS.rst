Setup:

- Install demo payment provider
- Enable additional checkout step
-
