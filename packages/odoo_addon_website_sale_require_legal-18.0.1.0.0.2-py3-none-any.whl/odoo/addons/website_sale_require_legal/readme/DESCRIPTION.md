This module extends your e-commerce legal compliance options:

1.  Require accepting legal terms before submitting a new address.
2.  Log a note in the partner when such terms are accepted.
3.  Log a note in the sale order when terms are accepted before payment
    (done for every online payment, it is an upstream feature).
