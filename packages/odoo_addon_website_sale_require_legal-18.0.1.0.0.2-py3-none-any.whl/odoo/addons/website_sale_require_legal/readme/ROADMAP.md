- Shopping terms and conditions are accepted only on user registration
  or address edition. So if those terms change after the user signed up,
  a notification should be made. An implicit acceptance could be printed
  in the payment screen to solve this. Maybe that could be a work to
  develop in another module.
- If you enable both acceptance views as explained in the configuration
  section, first-time buyers will have to accept the legal terms between
  2 and 3 times to buy.
