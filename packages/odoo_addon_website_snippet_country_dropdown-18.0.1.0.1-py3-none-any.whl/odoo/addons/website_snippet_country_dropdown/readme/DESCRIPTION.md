This module adds a snippet with a dropdown and an input text field, is a
base for be inherited by others modules into an HTML form.

This can be inserted into form elements.
