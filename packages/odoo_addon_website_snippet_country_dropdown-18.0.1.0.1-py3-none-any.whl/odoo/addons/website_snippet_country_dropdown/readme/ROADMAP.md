- Add tests.
- Snippet drag and drop [seems to be blocked by Odoo for some unknown
  reason.](https://github.com/OCA/website/pull/230#issuecomment-236681777).
  Given the main purpose of this module is to provide a reusable
  template for other modules to use, did not take the time to fix that
  use case.
