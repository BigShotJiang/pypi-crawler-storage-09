"""Odoo Index MCP - Lightweight MCP server for indexing Odoo code."""

__version__ = "0.1.0"
