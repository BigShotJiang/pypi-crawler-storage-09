"""Parsers for Odoo code elements."""
