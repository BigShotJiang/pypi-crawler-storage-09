"""Check if import of ext data works"""

from __future__ import annotations

import odsbox.proto.ods_external_data_pb2 as exd_data


def test_structure_creation():
    structure_request = exd_data.StructureRequest(handle=exd_data.Handle(uuid="abc-def"))
    assert structure_request is not None
