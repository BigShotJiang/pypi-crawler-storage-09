from .cli import task_menu

def main():
    task_menu()

if __name__ == "__main__":
    main()

