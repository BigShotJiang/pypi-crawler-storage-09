"""Shared default values for Optilogic Datastar library models."""

DEFAULT_DESCRIPTION = "Created by the Optilogic Datastar library"
