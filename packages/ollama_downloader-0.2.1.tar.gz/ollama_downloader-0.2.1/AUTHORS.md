The Ollama Downloader (ollama-downloader) project was created in August 2025 by Anirban Basu.

Core maintainers:
 - Anirban Basu

For a complete list of contributors, see:
https://github.com/anirbanbasu/ollama-downloader/graphs/contributors
