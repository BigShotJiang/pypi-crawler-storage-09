DEFAULT_TIME_FMT = '%Y-%m-%dT%H:%M:%SZ'
