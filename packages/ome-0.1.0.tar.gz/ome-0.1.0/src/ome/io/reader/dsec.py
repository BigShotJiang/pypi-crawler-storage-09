import hdf5plugin  # noqa
from pathlib import Path

import h5py
import numpy as np

from ome.io.reader.base import BaseReader


class DSECRReader(BaseReader):
    """Reader for the DSEC dataset. See https://dsec.ifi.uzh.ch/"""

    def __init__(
        self,
        file: str | Path,
    ):
        self.h5 = h5py.File(file, "r")

        self.x: h5py.Dataset = self.h5["/events/x"]  # uint16, width: 1280
        self.y: h5py.Dataset = self.h5["/events/y"]  # uint16, height: 720
        self.p: h5py.Dataset = self.h5["/events/p"]  # int8, polarity, 0 or 1
        self.t: h5py.Dataset = self.h5["/events/t"]  # int64, microseconds, start from 0
        self.ms_to_idx: np.ndarray = self.h5["/ms_to_idx"][:]  # uint64, (N,)
        self.t_offset: int = self.h5["/t_offset"][()]  # int64, microseconds, unix timestamp in world

        self.width = 640
        self.height = 480

        super().__post_init__()
