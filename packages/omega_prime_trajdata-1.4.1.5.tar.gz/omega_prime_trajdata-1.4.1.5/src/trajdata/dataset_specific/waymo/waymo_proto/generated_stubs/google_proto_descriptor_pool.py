from google.protobuf import descriptor_pool

default_google_proto_descriptor_pool = descriptor_pool.DescriptorPool()
