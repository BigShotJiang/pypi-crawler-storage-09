# OmegaScript Python Module

OmegaScript is a powerful multi-purpose Python framework designed by **Ibrahim Shahid**.  
Originally intended as a standalone programming language, it evolved into an all-in-one Python module that integrates:

- Operating System automation  
- Web utilities  
- Number systems and encryption  
- SQL database management  
- Media playback (image, audio, video)  
- GUI creation using Kivy  
- Networking (IP, FTP)  
- HTML, CSS, and JavaScript preview with Flask

---

## 🚀 Features

- **OS Operations:** File/folder creation, deletion, speech synthesis, and voice input  
- **Web Utilities:** Open websites, check connectivity, and fetch HTML content  
- **Security Suite:** Hashing, encoding, decoding, Caesar & XOR encryption  
- **SQL Database:** Create, select, update, and export data using SQLite and Pandas  
- **Networking:** IP info, DNS resolution, FTP operations with upload/download support  
- **GUI System:** Build modern GUI applications via Kivy components  
- **Media Control:** Play audio, view images and videos with playback controls  
- **HTML/CSS/JS Preview:** Flask-based live web preview  

---

## 🧠 Example Usage

```python
from omegascript import *

# OS Operations
sys = OS()
sys.create_file("example.txt", "Hello OmegaScript!")

# Web Operations
web = Web()
print(web.is_on_web())

# GUI Example
gui = omegaGUI()
gui.title("Demo App").bgcolor("#FFFFFF").run()
⚙️ Installation
bash
Copy code
pip install omegascript
Or manually:

bash
Copy code
python setup.py install
🧩 Requirements
Python ≥ 3.8

Kivy

Flask

OpenCV (cv2)

PyGame

SpeechRecognition

pyttsx3

pandas

requests

Install all dependencies:

bash
Copy code
pip install -r requirements.txt
🧑‍💻 Developer
Name: Ibrahim Shahid
Role: Software Engineer
Email: ibrahimshahid7767@gmail.com
Project: NeuraPython & OmegaScript

📄 License
This project is distributed under the MIT License.
You are free to modify and redistribute with attribution.