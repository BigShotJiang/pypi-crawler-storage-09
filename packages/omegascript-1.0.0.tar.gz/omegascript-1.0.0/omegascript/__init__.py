import os
import platform
import shutil
import pyttsx3 as pt
import subprocess
import speech_recognition as sr
from flask import *
#__________________________________Variables___________________________________________
class variable:
    def __init__(self,value="",type="string"):
        if type=="string":
            self.value=str(value)
        elif type=="integer":
            self.value=int(value)
        elif type == "char":
            self.value=chr(value)
        elif type=="real":
            self.value=float(value)
        elif type=="boolean":
            self.value=bool(value)
        else:
            print("Invalid Datatype")
        
        
    def char(self):
        try:
            self.value=chr(self.value)
        except Exception as e:
            raise e
    def integer(self):
        try:
            self.value=int(self.value)
        except Exception as e:
            raise e
    def string(self):
        try:
            self.value=str(self.value)
        except Exception as e:
            raise e
    def real(self):
        try:
            self.value=float(self.value)
        except Exception as e:
            raise e
    def boolean(self):
        try:
            self.value=bool(self.value)
        except Exception as e:
            raise e
        
    
#____________________________________________INFO_____________________________________________
def info():
    print("""
        This was first designed as a new programming language but didn't make its compiler/interpreter so this is made as a module in python . Its developer is Ibrahim Shahid
        """)
    
#_________________________________________from lopp______________________________________
def from_loop(start,end,step,statements):
    i=start
    if start < end:
        while (i<=end):
            exec(statements)
            start=start+step
    elif(start > end):
        while(i>=end):
            exec(statements)
            start=start+step
    else:
        print("Something went wrong")
        
#________________________________________________OS________________________________________
class OS:
    def __init__(self):
        print("Omega-Script Operating System initialized")
    def ShutDown(self):
        system_name = platform.system().lower()

        if "windows" in system_name:
            os.system("shutdown /s /t 0")
        elif "linux" in system_name or "darwin" in system_name:  # macOS is 'Darwin'
            os.system("shutdown now")
        else:
            print("Unsupported operating system")
            
    def delete_file(self, path):
        if os.path.isfile(path):
            os.remove(path)
            print(f"File deleted: {path}")
        else:
            print("File not found")

    def delete_folder(self, path):
        if os.path.isdir(path):
            shutil.rmtree(path)
            print(f"Folder deleted: {path}")
        else:
            print("Folder not found")

    def create_file(self, path, content=""):
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        print(f"File created: {path}")

    def create_folder(self, path):
        os.makedirs(path, exist_ok=True)
        print(f"Folder created: {path}")

    def pathExists(self, path):
        exists = os.path.exists(path)
        print(f"Path exists: {exists}")
        return exists
    
    def speak(self,text=""):
        engine=pt.init()
        engine.say(text)
        engine.runAndWait()
        engine.stop()
        
    def voice_input(self, message="Say something:"):
        recognizer = sr.Recognizer()
        with sr.Microphone() as source:
            print(message)
            audio = recognizer.listen(source)

        try:
            return recognizer.recognize_google(audio)
        except sr.UnknownValueError:
            print("Could not understand audio")
        except sr.RequestError:
            print("Speech recognition service unavailable")
            
            
    import os
    import subprocess

    def find_path(thing=""):
        result_paths = []

        if os.name == "nt":  # Windows
            try:
                cmd_output = subprocess.check_output(f'where /r C:\\ {thing}', shell=True, text=True, stderr=subprocess.DEVNULL)
                result_paths = [line.strip() for line in cmd_output.splitlines() if os.path.exists(line.strip())]
            except subprocess.CalledProcessError:
                result_paths = []
        else:  # Linux/Mac
            try:
                cmd_output = subprocess.check_output(f'find / -type f -name "{thing}" 2>/dev/null', shell=True, text=True)
                result_paths = [line.strip() for line in cmd_output.splitlines()]
            except subprocess.CalledProcessError:
                result_paths = []

        return result_paths

    
    def run_application(self, app_path):
        if not os.path.exists(app_path):
            print("Application not found")
            return
        try:
            if os.name == "nt":  # Windows
                os.startfile(app_path)
            else:  # Linux / macOS
                subprocess.Popen(["xdg-open", app_path])
        except Exception as e:
            print(f"Error running application: {e}")
            
            
            
#___________________________________________WEB________________________________________
import requests
import webbrowser

class Web:
    def __init__(self):
        print("Omega-Web Interface initialized")

    def is_on_web(self, url="https://www.google.com"):
        try:
            requests.get(url, timeout=5)
            return True
        except requests.RequestException:
            return False

    def fetch_html(self, url):
        try:
            response = requests.get(url, timeout=10)
            return response.text
        except requests.RequestException as e:
            print(f"Error fetching HTML: {e}")

    def open(self, url):
        try:
            webbrowser.open(url)
        except Exception as e:
            print(f"Error opening browser: {e}")

#_______________________________________Number System____________________________________________
class NumberSystem:
    def __init__(self):
        print("Number System Initialized")

    # Base conversions
    def bin_to_dec(self, binary):
        return int(binary, 2)

    def dec_to_bin(self, decimal):
        return bin(int(decimal))[2:]

    def bin_to_octal(self, binary):
        return oct(int(binary, 2))[2:]

    def octal_to_bin(self, octal):
        return bin(int(octal, 8))[2:]

    def dec_to_octal(self, decimal):
        return oct(int(decimal))[2:]

    def octal_to_dec(self, octal):
        return int(octal, 8)

    def dec_to_hex(self, decimal):
        return hex(int(decimal))[2:]

    def hex_to_dec(self, hexa):
        return int(hexa, 16)

    def bin_to_hex(self, binary):
        return hex(int(binary, 2))[2:]

    def hex_to_bin(self, hexa):
        return bin(int(hexa, 16))[2:]

    # Text conversions
    def text_to_binary(self, text):
        return ''.join(format(ord(char), '08b') for char in text)

    def binary_to_text(self, binary):
        return ''.join(chr(int(binary[i:i+8], 2)) for i in range(0, len(binary), 8))

    def text_to_hex(self, text):
        return ''.join(format(ord(c), 'x') for c in text)

    def hex_to_text(self, hexa):
        return bytes.fromhex(hexa).decode('utf-8')

#______________________________________Cipher/Encryption+Hashing+Encoding+Decoding+Decryption+Verify_Hashing______________________________
import hashlib, base64, codecs

class Security:
    def __init__(self):
        print("Security class activated")

    #----------------- Basic Encoding / Decoding -----------------
    def base64_encode(self, text):
        return base64.b64encode(text.encode()).decode()

    def base64_decode(self, encoded):
        return base64.b64decode(encoded).decode()

    def rot13_encode(self, text):
        return codecs.encode(text, 'rot_13')

    def rot13_decode(self, text):
        return codecs.decode(text, 'rot_13')

    #----------------- Hashing -----------------
    def hash_md5(self, text):
        return hashlib.md5(text.encode()).hexdigest()

    def hash_sha1(self, text):
        return hashlib.sha1(text.encode()).hexdigest()

    def hash_sha256(self, text):
        return hashlib.sha256(text.encode()).hexdigest()

    def hash_sha512(self, text):
        return hashlib.sha512(text.encode()).hexdigest()

    def verify_hash(self, text, given_hash, algo='sha256'):
        algorithms = {
            'md5': hashlib.md5,
            'sha1': hashlib.sha1,
            'sha256': hashlib.sha256,
            'sha512': hashlib.sha512
        }
        if algo not in algorithms:
            raise ValueError("Unsupported hash type")
        calc = algorithms[algo](text.encode()).hexdigest()
        return calc == given_hash

    #----------------- Simple Encryption / Decryption -----------------
    def caesar_encrypt(self, text, shift=3):
        result = ''
        for char in text:
            if char.isalpha():
                base = ord('A') if char.isupper() else ord('a')
                result += chr((ord(char) - base + shift) % 26 + base)
            else:
                result += char
        return result

    def caesar_decrypt(self, text, shift=3):
        return self.caesar_encrypt(text, -shift)

    def xor_encrypt(self, text, key):
        return ''.join(chr(ord(c) ^ ord(key[i % len(key)])) for i, c in enumerate(text))

    def xor_decrypt(self, cipher, key):
        return self.xor_encrypt(cipher, key)


#________________________________IP_________________________________
import socket

class IP:
    def __init__(self):
        print("IP module activated")

    def get_host_ip(self):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except Exception:
            return "Unable to determine IP"

    def get_host_name(self):
        try:
            return socket.gethostname()
        except Exception:
            return "Unable to determine host name"

    def resolve_domain(self, domain):
        try:
            return socket.gethostbyname(domain)
        except Exception:
            return "Unable to resolve domain"


#__________________________________FTP_____________________________
from ftplib import FTP as FTPClient

class FTP:
    def __init__(self, host=None, port=21, user=None, passwd=None):
        print("FTP module activated")
        self.connection = None
        self.host = host
        self.port = port
        self.user = user
        self.passwd = passwd
        if host:
            self.connect(host, port, user, passwd)

    def connect(self, host, port=21, user="", passwd=""):
        try:
            self.connection = FTPClient()
            self.connection.connect(host, port)
            self.connection.login(user=user, passwd=passwd)
            print(f"Connected to {host}:{port}")
        except Exception as e:
            print(f"Connection failed: {e}")

    def list_files(self):
        if self.connection:
            try:
                return self.connection.nlst()
            except Exception as e:
                return f"Error listing files: {e}"
        return "Not connected"

    def upload_file(self, local_file, remote_file):
        if self.connection:
            try:
                with open(local_file, "rb") as f:
                    self.connection.storbinary(f"STOR {remote_file}", f)
                print(f"Uploaded {local_file} to {remote_file}")
            except Exception as e:
                print(f"Upload failed: {e}")
        else:
            print("Not connected")

    def download_file(self, remote_file, local_file):
        if self.connection:
            try:
                with open(local_file, "wb") as f:
                    self.connection.retrbinary(f"RETR {remote_file}", f.write)
                print(f"Downloaded {remote_file} to {local_file}")
            except Exception as e:
                print(f"Download failed: {e}")
        else:
            print("Not connected")

    def change_directory(self, directory):
        if self.connection:
            try:
                self.connection.cwd(directory)
                print(f"Changed directory to {directory}")
            except Exception as e:
                print(f"Directory change failed: {e}")
        else:
            print("Not connected")

    def get_current_directory(self):
        if self.connection:
            try:
                return self.connection.pwd()
            except Exception as e:
                return f"Error getting current directory: {e}"
        return "Not connected"

    def close(self):
        if self.connection:
            try:
                self.connection.quit()
                print("FTP connection closed")
            except Exception as e:
                print(f"Error closing connection: {e}")

#__________________________________SQL_____________________________
import sqlite3
import pandas as pd
import json
import os
from datetime import datetime

class SQL:
    def __init__(self, db_name="database.db"):
        self.db_name = db_name
        self.connection = sqlite3.connect(self.db_name, check_same_thread=False)
        self.cursor = self.connection.cursor()
        print(f"SQL activated. Connected to {self.db_name}")

    def execute(self, query, params=(), fetch=True):
        try:
            self.cursor.execute(query, params)
            self.connection.commit()
            if fetch:
                return self.cursor.fetchall()
        except Exception as e:
            return f"Error: {e}"

    def create_table(self, table_name, columns, if_not_exists=True):
        condition = "IF NOT EXISTS " if if_not_exists else ""
        cols = ", ".join([f"{col} {dtype}" for col, dtype in columns.items()])
        query = f"CREATE TABLE {condition}{table_name} ({cols})"
        self.execute(query, fetch=False)

    def insert(self, table_name, data):
        if isinstance(data, dict):
            data = [data]
        for row in data:
            placeholders = ", ".join(["?" for _ in row])
            columns = ", ".join(row.keys())
            values = tuple(row.values())
            query = f"INSERT INTO {table_name} ({columns}) VALUES ({placeholders})"
            self.execute(query, values, fetch=False)

    def select(self, table_name, columns="*", condition=None, limit=None, order_by=None, to_dataframe=False):
        query = f"SELECT {columns} FROM {table_name}"
        if condition:
            query += f" WHERE {condition}"
        if order_by:
            query += f" ORDER BY {order_by}"
        if limit:
            query += f" LIMIT {limit}"
        result = self.execute(query)
        if to_dataframe:
            df = pd.DataFrame(result, columns=[desc[0] for desc in self.cursor.description])
            return df
        return result

    def update(self, table_name, updates, condition=None):
        set_clause = ", ".join([f"{col} = ?" for col in updates.keys()])
        values = list(updates.values())
        query = f"UPDATE {table_name} SET {set_clause}"
        if condition:
            query += f" WHERE {condition}"
        self.execute(query, values, fetch=False)

    def delete(self, table_name, condition=None):
        query = f"DELETE FROM {table_name}"
        if condition:
            query += f" WHERE {condition}"
        self.execute(query, fetch=False)

    def export_to_json(self, table_name, file_path=None):
        data = self.select(table_name)
        if not data:
            return "No data found."
        cols = [desc[0] for desc in self.cursor.description]
        records = [dict(zip(cols, row)) for row in data]
        file_path = file_path or f"{table_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(records, f, indent=4)
        return f"Exported to {file_path}"

    def import_from_json(self, table_name, file_path):
        if not os.path.exists(file_path):
            return "File not found."
        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        self.insert(table_name, data)
        return f"Imported data from {file_path}"

    def backup(self, backup_name=None):
        backup_name = backup_name or f"backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
        with sqlite3.connect(backup_name) as backup_conn:
            self.connection.backup(backup_conn)
        return f"Backup created: {backup_name}"

    def table_info(self, table_name):
        return self.execute(f"PRAGMA table_info({table_name})")

    def list_tables(self):
        return [x[0] for x in self.execute("SELECT name FROM sqlite_master WHERE type='table'")]

    def drop_table(self, table_name):
        self.execute(f"DROP TABLE IF EXISTS {table_name}", fetch=False)

    def close(self):
        self.connection.close()
        print("SQL connection closed")

        
        
#__________________________________GUI+Game_______________________________
# omegaGUI_final.py
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.textinput import TextInput
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.checkbox import CheckBox
from kivy.uix.popup import Popup
from kivy.uix.spinner import Spinner
from kivy.core.window import Window
from kivy.utils import get_color_from_hex
from kivy.clock import Clock
from datetime import datetime


#________________________________________Base Classes________________________________________
class UI:
    def __init__(self):
        print("User Interface activated")


class omegaComponent:
    """Base class for all UI components"""
    def __init__(self, label):
        self.label = label
        self.widget = None

    def style(self, css_text):
        css = self._parse_css(css_text)
        if hasattr(self.widget, "foreground_color") and "color" in css:
            self.widget.foreground_color = self._color_parse(css["color"])
        if hasattr(self.widget, "background_color") and "background-color" in css:
            self.widget.background_color = self._color_parse(css["background-color"])
        if hasattr(self.widget, "font_size") and "font-size" in css:
            self.widget.font_size = float(css["font-size"].replace("px", ""))
        return self

    def on_click(self, func):
        if hasattr(self.widget, "bind"):
            self.widget.bind(on_press=lambda instance: func())
        return self

    def on_change(self, func):
        if hasattr(self.widget, "bind"):
            self.widget.bind(text=lambda instance, value: func(value))
        return self

    def _parse_css(self, text):
        rules = {}
        for part in text.split(";"):
            if ":" in part:
                key, val = part.split(":")
                rules[key.strip()] = val.strip()
        return rules

    def _color_parse(self, color):
        if isinstance(color, str):
            return get_color_from_hex(color)
        if isinstance(color, tuple):
            if len(color) == 3:
                return (*[c / 255 if c > 1 else c for c in color], 1)
            return color
        return (1, 1, 1, 1)


#________________________________________Component Types________________________________________
class omegaLabel(omegaComponent):
    def __init__(self, label, text=""):
        super().__init__(label)
        self.widget = Label(text=text, halign="center")

class omegaButton(omegaComponent):
    def __init__(self, label, text="Button"):
        super().__init__(label)
        self.widget = Button(text=text)

class omegaTextField(omegaComponent):
    def __init__(self, label, placeholder=""):
        super().__init__(label)
        self.widget = TextInput(hint_text=placeholder, multiline=False)

class omegaNumberField(omegaComponent):
    def __init__(self, label, placeholder=""):
        super().__init__(label)
        self.widget = TextInput(hint_text=placeholder, input_filter="int")

class omegaPasswordField(omegaComponent):
    def __init__(self, label, placeholder=""):
        super().__init__(label)
        self.widget = TextInput(hint_text=placeholder, password=True)

class omegaEmailField(omegaComponent):
    def __init__(self, label, placeholder=""):
        super().__init__(label)
        self.widget = TextInput(hint_text=placeholder)

class omegaCheckbox(omegaComponent):
    def __init__(self, label, message):
        super().__init__(label)
        box = BoxLayout(orientation="horizontal", spacing=5)
        chk = CheckBox()
        lbl = Label(text=message)
        box.add_widget(chk)
        box.add_widget(lbl)
        self.widget = box
        self.chk = chk

    def on_change(self, func):
        self.chk.bind(active=lambda instance, value: func(value))
        return self

class omegaRadio(omegaComponent):
    def __init__(self, label, message, group="default"):
        super().__init__(label)
        box = BoxLayout(orientation="horizontal", spacing=5)
        radio = CheckBox(group=group)
        lbl = Label(text=message)
        box.add_widget(radio)
        box.add_widget(lbl)
        self.widget = box
        self.radio = radio

    def on_change(self, func):
        self.radio.bind(active=lambda instance, value: func(value))
        return self

class omegaDateField(omegaComponent):
    def __init__(self, label):
        super().__init__(label)
        self.widget = Spinner(
            text="Select Date",
            values=[(datetime.now().strftime("%Y-%m-%d"))],
            size_hint=(1, None),
            height=44,
        )


#________________________________________omegaGUI Main Class________________________________________
class omegaGUI:
    def __init__(self):
        self.title_text = "Omega GUI"
        self.bg_color = (1, 1, 1, 1)
        self.elements = []
        self.layout = BoxLayout(orientation="vertical", spacing=10, padding=10)
        self.window_size = (900, 600)
        self.key_bindings = {}
        self.mouse_bindings = {}

    def title(self, text):
        self.title_text = text
        return self

    def setDimension(self, x, y, z=None):
        self.window_size = (x, y)
        return self

    def bgcolor(self, color):
        self.bg_color = self._color_parse(color)
        Window.clearcolor = self.bg_color
        return self

    def add(self, component):
        if hasattr(component, "widget"):
            self.layout.add_widget(component.widget)
            self.elements.append(component)
        return self

    #________________________ALERTS & DIALOGS________________________
    def alert(self, message, alert_type="info"):
        color_map = {"info": "#3498db", "warning": "#f39c12", "error": "#e74c3c"}
        bg_color = color_map.get(alert_type, "#bdc3c7")
        popup = Popup(
            title=f"{alert_type.upper()}",
            content=Label(text=message),
            size_hint=(None, None),
            size=(400, 200),
            background_color=self._color_parse(bg_color),
        )
        popup.open()

    def dialog(self, title, message, button_text="OK"):
        btn = Button(text=button_text, size_hint=(1, 0.3))
        content = BoxLayout(orientation="vertical")
        content.add_widget(Label(text=message))
        content.add_widget(btn)
        popup = Popup(title=title, content=content, size_hint=(None, None), size=(400, 250))
        btn.bind(on_press=popup.dismiss)
        popup.open()

    #________________________EVENT BINDINGS________________________
    def bind_key(self, key, func):
        self.key_bindings[key] = func
        return self

    def bind_mouse(self, event_type, func):
        self.mouse_bindings[event_type] = func
        return self

    def _setup_bindings(self):
        Window.bind(on_key_down=self._on_key_down)
        Window.bind(on_mouse_down=self._on_mouse_down)

    def _on_key_down(self, window, key, scancode, codepoint, modifier):
        if key in self.key_bindings:
            self.key_bindings[key]()
        return True

    def _on_mouse_down(self, window, x, y, button, modifiers):
        if "click" in self.mouse_bindings:
            self.mouse_bindings["click"](x, y, button)
        return True

    #________________________RUN WINDOW________________________
    def run(self):
        self._setup_bindings()
        Window.size = self.window_size
        Window.clearcolor = self.bg_color

        class TempApp(App):
            def build(app_self):
                return self.layout

        TempApp().run()

    #________________________HELPERS________________________
    def _color_parse(self, color):
        if isinstance(color, tuple):
            if len(color) == 3:
                return (*[c / 255 if c > 1 else c for c in color], 1)
            return color
        if isinstance(color, str):
            return get_color_from_hex(color)
        return (1, 1, 1, 1)

        
#__________________________________Media_______________________________
import cv2
import pygame
import threading

class Media:
    def __init__(self):
        print("Media Initialized")

    def view_image(self, path, size=(640, 480)):
        img = cv2.imread(path)
        if img is None:
            print("Image not found")
            return
        resized = cv2.resize(img, size)
        cv2.imshow("Image Viewer", resized)
        cv2.waitKey(0)
        cv2.destroyAllWindows()

    def view_video(self, path, size=(640, 480), controls=True):
        cap = cv2.VideoCapture(path)
        if not cap.isOpened():
            print("Video not found")
            return
        paused = False
        while cap.isOpened():
            if not paused:
                ret, frame = cap.read()
                if not ret:
                    break
                frame = cv2.resize(frame, size)
                cv2.imshow("Video Player", frame)
            key = cv2.waitKey(30)
            if controls:
                if key == ord('q'):
                    break
                elif key == ord('p'):
                    paused = not paused
        cap.release()
        cv2.destroyAllWindows()

    def play_audio(self, path):
        def _play():
            pygame.mixer.init()
            pygame.mixer.music.load(path)
            pygame.mixer.music.play()
            while pygame.mixer.music.get_busy():
                pygame.time.Clock().tick(10)
        threading.Thread(target=_play, daemon=True).start()

#_________________________________HTML,CSS,JavaScript_______________________
class HTML_CSS_JS:
    def __init__(self,html_path,css_path,js_path):
        self.htmlf=html_path
        self.cssf=css_path
        self.jsf=js_path
        self.html_code=""
        self.css_code=""
        self.js_code=""
        self.full_web_code=""
        print("HTML CSS JavaScript initialized")
    def html(self):
        if os.path.exists(self.htmlf):
            with open(rf"{self.htmlf}","r") as html:
                self.html_code=html.read()
        self.full_web_code+self.html_code
        return self.html_code
    def css(self):
        if os.path.exists(self.cssf):
            with open(rf"{self.cssf}","r") as css:
                self.css_code=css.read()
        self.full_web_code+self.css_code
        return self.css_code
    def js(self):
        if os.path.exists(self.jsf):
            with open(rf"{self.jsf}","r") as js:
                self.js_code=js.read()
        self.full_web_code+self.js_code
        return self.js_code  
    def preview(self):
        app=Flask(__name__)
        @app.route('/')
        def main():
            return self.full_web_code
        app.run(debug=True,port=5500,host='0.0.0.0')