
from setuptools import setup, find_packages

setup(
    name="omegascript",
    version="1.0.0",
    author="Ibrahim Shahid",
    author_email="ibrahimshahid7767@gmail.com",
    description="A multifunctional Python module integrating OS, Web, GUI, SQL, Media, and Security capabilities.",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://pypi.org/project/omegascript/",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "flask",
        "requests",
        "pandas",
        "kivy",
        "pygame",
        "opencv-python",
        "speechrecognition",
        "pyttsx3",
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Software Development :: Libraries",
    ],
    python_requires=">=3.8",
)
