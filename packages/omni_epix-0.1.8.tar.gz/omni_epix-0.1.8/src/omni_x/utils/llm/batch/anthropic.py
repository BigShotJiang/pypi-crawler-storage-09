# TODO
# batch prlly makes a lot of sense:
#   No time pressure
#   Half the cost
#   Can run N tasks in parallel
#   Stacked cost savings because prompt caching actually works
# 
