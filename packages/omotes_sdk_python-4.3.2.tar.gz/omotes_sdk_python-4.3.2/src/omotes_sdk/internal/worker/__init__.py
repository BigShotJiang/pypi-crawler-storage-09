from omotes_sdk.internal.worker.worker import Worker, WORKER
