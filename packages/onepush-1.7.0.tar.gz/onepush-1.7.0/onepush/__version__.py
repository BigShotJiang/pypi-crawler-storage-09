"""
@Project   : onepush
@Author    : y1ndan
@Blog      : https://www.yindan.me
"""

__version__ = '1.7.0'
