from setuptools import setup, find_packages

setup(
    name="onflow-wms-shared-auth",
    version="0.1.5",
    packages=find_packages(),
)
