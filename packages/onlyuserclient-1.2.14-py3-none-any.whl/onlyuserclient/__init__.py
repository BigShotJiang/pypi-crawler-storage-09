'''onlyuser 客户端开发包
'''

__version__='1.2.14'

VERSION = __version__