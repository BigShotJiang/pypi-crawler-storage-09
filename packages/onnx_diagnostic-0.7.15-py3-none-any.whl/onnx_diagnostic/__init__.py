"""
Patches, Investigates onnx models.
Functions, classes to dig into a model when this one is right, slow, wrong...
"""

__version__ = "0.7.15"
__author__ = "Xavier Dupré"
