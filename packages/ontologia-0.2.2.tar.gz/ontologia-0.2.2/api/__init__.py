"""
api
---
Ontology Stack API - Implementação REST compatível com Foundry.
"""

__version__ = "0.1.0"
