"""API v2 - Foundry-compatible REST API."""
