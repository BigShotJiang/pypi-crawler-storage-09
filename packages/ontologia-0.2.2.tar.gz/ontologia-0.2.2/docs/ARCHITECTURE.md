# Architecture (Legacy Summary)

This page has moved to the curated documentation site.

- For the up-to-date component diagram, responsibilities table, and deployment notes, see
  [`platform/architecture.md`](platform/architecture.md).
- Historical details remain available in Git history if you need to reference the previous version
  of this document.
