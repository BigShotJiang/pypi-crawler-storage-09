# Documentation Index

The documentation set has moved to the MkDocs site hierarchy. See [`index.md`](./index.md) for the
curated landing page and navigation structure. The legacy table of contents previously maintained in
this file is now generated automatically by the documentation site.

The original markdown sources remain available alongside the new site pages, so any existing links
continue to work. If you are browsing the repository directly, open `docs/index.md` for the latest
overview.

