# Architecture Decisions (ADR)

This folder groups decisions, fix plans, and design notes that informed the system.

Examples:
- REGISTRO_FIX_PLAN.md
- PYDANTIC_V2_FINAL_FIXES.md
- QUICK_FIX_REGISTRO.md
- FINAL_SOLUTION_REGISTRO.md
