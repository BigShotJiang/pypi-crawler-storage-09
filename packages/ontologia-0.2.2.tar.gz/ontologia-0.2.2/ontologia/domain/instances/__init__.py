"""Instances bounded context."""

from __future__ import annotations

from . import events, repositories

__all__ = ["events", "repositories"]
