"""Infrastructure adapters for the ontologia project."""

__all__: list[str] = []
