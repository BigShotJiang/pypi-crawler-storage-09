"""Persistence adapters."""

__all__: list[str] = []
