"""Metamodel migration domain models."""
