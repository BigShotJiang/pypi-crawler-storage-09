from oop_es.exception import EventStoreException


class WrongEventVersionException(EventStoreException):
    ...
