from oop_bus import EventListener

Projector = EventListener

__all__ = ["Projector"]
