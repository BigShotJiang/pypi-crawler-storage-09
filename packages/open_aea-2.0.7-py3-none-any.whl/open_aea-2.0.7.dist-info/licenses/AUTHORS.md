# Authors

This is the official list of Fetch.ai and Valory authors for copyright purposes.

* Marco Favorito <marco.favorito@fetch.ai> [MarcoFavorito](https://github.com/MarcoFavorito)
* David Minarsch <david.minarsch@fetch.ai> [DavidMinarsch](https://github.com/DavidMinarsch)
* Ali Hosseini <ali.hosseini@fetch.ai> [5A11](https://github.com/5A11)
* Aristotelis Triantafyllidis <aristotelis.triantafyllidis@fetch.ai> [Totoual](https://github.com/Totoual)
* Diarmid Campbell <diarmid.campbell@fetch.ai> [dishmop](https://github.com/dishmop)
* Oleg Panasevych <oleg.panasevych@n-cube.co.uk> [Panasevychol](https://github.com/panasevychol)
* Kevin Chen <kevin.chen@fetch.ai> [Kevin-Chen0](https://github.com/Kevin-Chen0)
* Yuri Turchenkov <yuri.turchenkov@fetch.ai> [solarw](https://github.com/solarw)
* Lokman Rahmani <lokman.rahmani@fetch.ai> [lrahmani](https://github.com/lrahmani)
* Jiří Vestfál <jiri.vestfal@fetch.ai> [MissingNO57](https://github.com/MissingNO57)
* Ed Fitzgerald <ed.fitzgerald@fetch.ai> [ejfitzgerald](https://github.com/ejfitzgerald)
* James Riehl <james.riehl@fetch.ai> [jrriehl](https://github.com/jrriehl)
* 8baller <8ball030@gmail.com> [8ball030](https://github.com/8ball030)
* Adamantios <adamantios.zaras@valory.xyz> [Adamantios](https://github.com/Adamantios)
* David Vilela <dvilelaf@gmail.com> [dvilelaf](https://github.com/dvilelaf)
* M.A.P. Karrenbelt <m.a.p.karrenbelt@gmail.com> [Karrenbelt](https://github.com/Karrenbelt)
* Viraj Patel <vptl185@gmail.com> [angrybayblade](https://github.com/angrybayblade)
