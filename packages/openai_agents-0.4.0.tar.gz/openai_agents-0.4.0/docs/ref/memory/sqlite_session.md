# `Sqlite Session`

::: agents.memory.sqlite_session
