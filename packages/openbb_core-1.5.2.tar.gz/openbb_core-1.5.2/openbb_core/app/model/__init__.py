"""OpenBB Core App Model."""
