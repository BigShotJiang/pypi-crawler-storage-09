"""OpenBB Core App Model Results."""
