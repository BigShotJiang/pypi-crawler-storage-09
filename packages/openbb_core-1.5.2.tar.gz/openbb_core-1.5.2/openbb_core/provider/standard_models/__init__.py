"""Standard models for OpenBB Provider."""
