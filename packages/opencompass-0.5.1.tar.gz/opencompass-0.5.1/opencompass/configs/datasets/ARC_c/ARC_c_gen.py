from mmengine.config import read_base

with read_base():
    from .ARC_c_gen_1e0de5 import ARC_c_datasets  # noqa: F401, F403
