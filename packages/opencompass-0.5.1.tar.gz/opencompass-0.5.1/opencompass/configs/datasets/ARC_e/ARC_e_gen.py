from mmengine.config import read_base

with read_base():
    from .ARC_e_gen_1e0de5 import ARC_e_datasets  # noqa: F401, F403
