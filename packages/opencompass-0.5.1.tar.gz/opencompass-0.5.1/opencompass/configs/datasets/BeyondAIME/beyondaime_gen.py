from mmengine.config import read_base

with read_base():
    from .beyondaime_cascade_eval_gen_5e9f4f import beyondaime_datasets  # noqa: F401, F403