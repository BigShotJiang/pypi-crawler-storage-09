from mmengine.config import read_base

with read_base():
    from .charm_reason_gen_f8fca2 import charm_reason_datasets  # noqa: F401, F403
