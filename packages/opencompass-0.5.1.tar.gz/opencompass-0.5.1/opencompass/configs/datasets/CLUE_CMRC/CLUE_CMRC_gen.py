from mmengine.config import read_base

with read_base():
    from .CLUE_CMRC_gen_1bd3c8 import CMRC_datasets  # noqa: F401, F403
