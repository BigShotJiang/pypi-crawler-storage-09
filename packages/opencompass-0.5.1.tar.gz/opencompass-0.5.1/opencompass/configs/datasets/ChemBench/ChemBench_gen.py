from mmengine.config import read_base

with read_base():
    from .ChemBench_gen_a9f753 import chembench_datasets  # noqa: F401, F403