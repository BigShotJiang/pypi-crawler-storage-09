from mmengine.config import read_base

with read_base():
    from .ChemBench_llmjudge_gen_c584cf import chembench_datasets  # noqa: F401, F403