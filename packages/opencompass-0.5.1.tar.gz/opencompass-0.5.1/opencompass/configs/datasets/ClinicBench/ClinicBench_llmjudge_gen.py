from mmengine.config import read_base

with read_base():
    from .ClinicBench_llmjudge_gen_d09668 import ClinicBench_datasets