from mmengine.config import read_base

with read_base():
    from .FewCLUE_chid_ppl_8f2872 import chid_datasets  # noqa: F401, F403
