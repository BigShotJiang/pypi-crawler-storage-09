from mmengine.config import read_base

with read_base():
    from .FewCLUE_eprstmt_gen_740ea0 import eprstmt_datasets  # noqa: F401, F403
