from mmengine.config import read_base

with read_base():
    from .FinanceIQ_gen_e0e6b5 import financeIQ_datasets  # noqa: F401, F403
