from mmengine.config import read_base

with read_base():
    from .GaokaoBench_mixed_9af5ee import GaokaoBench_datasets  # noqa: F401, F403
