from mmengine.config import read_base

with read_base():
    from .IFEval_gen_353ae7 import ifeval_datasets  # noqa: F401, F403