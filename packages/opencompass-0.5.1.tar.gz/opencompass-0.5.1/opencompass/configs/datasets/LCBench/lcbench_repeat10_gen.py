from mmengine.config import read_base

with read_base():
    from .lcbench_repeat10_gen_5ff288 import LCBench_repeat10_datasets  # noqa: F401, F403
