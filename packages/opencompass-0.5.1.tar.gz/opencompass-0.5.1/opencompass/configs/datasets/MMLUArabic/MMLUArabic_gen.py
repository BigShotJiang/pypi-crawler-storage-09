from mmengine.config import read_base

with read_base():
    from .MMLUArabic_gen_326684 import MMLUArabic_datasets  # noqa: F401, F403
