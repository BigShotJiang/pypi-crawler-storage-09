from mmengine.config import read_base

with read_base():
    from .MMLUArabic_ppl_d2333a import MMLUArabic_datasets  # noqa: F401, F403
