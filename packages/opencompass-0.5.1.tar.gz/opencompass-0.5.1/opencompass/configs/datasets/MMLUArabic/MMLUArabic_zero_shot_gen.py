from mmengine.config import read_base

with read_base():
    from .MMLUArabic_zero_shot_gen_3523e0 import MMLUArabic_datasets  # noqa: F401, F403
