from mmengine.config import read_base

with read_base():
    from .medbench_gen_d44f24 import medbench_datasets  # noqa: F401, F403
