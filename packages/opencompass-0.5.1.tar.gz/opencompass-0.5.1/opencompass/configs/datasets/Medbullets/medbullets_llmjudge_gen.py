from mmengine.config import read_base

with read_base():
    from .medbullets_llmjudge_gen_60c8f5 import medbullets_datasets  # noqa: F401, F403