from mmengine.config import read_base

with read_base():
    from .NPHardEval_gen_22aac5 import NPHardEval_datasets  # noqa: F401, F403
