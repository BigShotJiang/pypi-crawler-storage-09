from mmengine.config import read_base

with read_base():
    from .OpenFinData_gen_46dedb import OpenFinData_datasets  # noqa: F401, F403
