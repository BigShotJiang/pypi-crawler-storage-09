from mmengine.config import read_base

with read_base():
    from .PHYSICS_llm_judge_gen_a133a2 import physics_datasets  # noqa: F401, F403