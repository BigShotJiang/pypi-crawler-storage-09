from mmengine.config import read_base

with read_base():
    from .flores_gen_2697d7 import PMMEval_flores_datasets
