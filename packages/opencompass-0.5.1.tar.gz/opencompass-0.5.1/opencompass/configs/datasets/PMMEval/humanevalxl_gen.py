from mmengine.config import read_base

with read_base():
    from .humanevalxl_gen_4dfef4 import PMMEval_HumanEvalXL_datasets
