from mmengine.config import read_base

with read_base():
    from .mgsm_gen_679720 import PMMEval_MGSM_datasets
