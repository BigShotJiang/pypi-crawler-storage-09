from mmengine.config import read_base

with read_base():
    from .mhellaswag_gen_1a6b73 import PMMEval_MHellaswag_datasets
