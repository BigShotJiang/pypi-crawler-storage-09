from mmengine.config import read_base

with read_base():
    from .mifeval_gen_79f8fb import PMMEval_MIFEval_datasets
