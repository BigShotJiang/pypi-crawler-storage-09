from mmengine.config import read_base

with read_base():
    from .mlogiqa_gen_36c4f9 import PMMEval_MLogiQA_datasets
