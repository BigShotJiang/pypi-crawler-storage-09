from mmengine.config import read_base

with read_base():
    from .mmmlu_gen_d5017d import PMMEval_MMMLU_datasets
