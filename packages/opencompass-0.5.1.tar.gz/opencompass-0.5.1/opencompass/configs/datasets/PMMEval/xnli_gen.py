from mmengine.config import read_base

with read_base():
    from .xnli_gen_973734 import PMMEval_XNLI_datasets
