from mmengine.config import read_base

with read_base():
    from .PubMedQA_llmjudge_gen_f00302 import PubMedQA_datasets