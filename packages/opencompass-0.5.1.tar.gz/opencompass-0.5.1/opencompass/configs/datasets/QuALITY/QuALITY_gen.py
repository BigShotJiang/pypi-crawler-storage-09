from mmengine.config import read_base

with read_base():
    from .QuALITY_gen_c407cb import QuALITY_datasets  # noqa: F401, F403
