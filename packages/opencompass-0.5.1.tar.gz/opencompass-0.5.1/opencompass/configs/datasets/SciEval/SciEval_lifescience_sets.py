SciEval_lifescience_subsets = [
    'biology',        # 大学生物学
    'physics',
    'chemistry'

]
