from mmengine.config import read_base

with read_base():
    from .ScienceQA_llmjudge_gen_f00302 import ScienceQA_datasets