# OpenCompass SimpleQA dataset config for evaluation

## 1. Introduction

SimpleQA is a benchmark that evaluates the ability of language models to answer short, fact-seeking questions by OpenAI.
The original site is https://github.com/openai/simple-evals.

## 2. How to use

Please refer to the demo evaluation script `/opencompass/configs/mine/simpleqa_eval.py`.
