from mmengine.config import read_base

with read_base():
    from .simpleqa_gen_0283c3 import simpleqa_datasets  # noqa: F401, F403
