from mmengine.config import read_base

with read_base():
    from .TabMWP_gen_2aef96 import TabMWP_datasets  # noqa: F401, F403
