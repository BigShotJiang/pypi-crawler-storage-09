from mmengine.config import read_base

with read_base():
    from .TheoremQA_5shot_gen_6f0af8 import TheoremQA_datasets  # noqa: F401, F403
