from mmengine.config import read_base

with read_base():
    from .XCOPA_ppl_54058d import XCOPA_datasets  # noqa: F401, F403
