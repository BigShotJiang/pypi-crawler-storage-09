from mmengine.config import read_base

with read_base():
    from .XLSum_gen_2bb71c import XLSum_datasets  # noqa: F401, F403
