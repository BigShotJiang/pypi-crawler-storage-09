from mmengine.config import read_base

with read_base():
    from .Xsum_gen_31397e import Xsum_datasets  # noqa: F401, F403
