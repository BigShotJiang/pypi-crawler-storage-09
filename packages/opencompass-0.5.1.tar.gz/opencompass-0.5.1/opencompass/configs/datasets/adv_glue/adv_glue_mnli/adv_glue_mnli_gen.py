from mmengine.config import read_base

with read_base():
    from .adv_glue_mnli_gen_bd8ef0 import adv_mnli_datasets  # noqa: F401, F403
