from mmengine.config import read_base

with read_base():
    from .adv_glue_qnli_gen_0b7326 import adv_qnli_datasets  # noqa: F401, F403
