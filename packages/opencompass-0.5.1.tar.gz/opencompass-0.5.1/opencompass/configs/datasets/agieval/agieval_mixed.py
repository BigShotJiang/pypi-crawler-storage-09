from mmengine.config import read_base

with read_base():
    from .agieval_mixed_0fa998 import agieval_datasets  # noqa: F401, F403
