from mmengine.config import read_base

with read_base():
    from .aime2024_gen_17d799 import aime2024_datasets  # noqa: F401, F403