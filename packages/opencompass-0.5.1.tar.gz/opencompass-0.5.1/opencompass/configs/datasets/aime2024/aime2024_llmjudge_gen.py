from mmengine.config import read_base

with read_base():
    from .aime2024_llmjudge_gen_5e9f4f import aime2024_datasets  # noqa: F401, F403