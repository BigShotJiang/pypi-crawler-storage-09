from mmengine.config import read_base

with read_base():
    from .anli_ppl_1d290e import anli_datasets  # noqa: F401, F403
