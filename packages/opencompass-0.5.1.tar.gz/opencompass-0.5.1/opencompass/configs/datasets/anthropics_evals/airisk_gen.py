from mmengine.config import read_base

with read_base():
    from .airisk_gen_ba66fc import airisk_datasets  # noqa: F401, F403
