from mmengine.config import read_base

with read_base():
    from .persona_gen_cc72e2 import persona_datasets  # noqa: F401, F403
