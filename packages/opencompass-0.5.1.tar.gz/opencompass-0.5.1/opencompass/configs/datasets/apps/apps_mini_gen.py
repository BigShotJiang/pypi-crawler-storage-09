from mmengine.config import read_base

with read_base():
    from .apps_mini_gen_c7893a import APPS_datasets  # noqa: F401, F403
