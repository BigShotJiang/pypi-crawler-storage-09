from mmengine.config import read_base

with read_base():
    from .bbh_gen_ee62e9 import bbh_datasets  # noqa: F401, F403