"""
Control curves data package.
"""
