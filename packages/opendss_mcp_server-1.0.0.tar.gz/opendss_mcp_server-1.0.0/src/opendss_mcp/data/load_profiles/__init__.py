"""
Load profiles data package.
"""
