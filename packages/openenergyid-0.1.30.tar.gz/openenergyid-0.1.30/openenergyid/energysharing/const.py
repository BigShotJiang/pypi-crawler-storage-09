"""Constants for the energysharing module."""

GROSS_INJECTION = "Gross Injection"
NET_INJECTION = "Net Injection"
GROSS_OFFTAKE = "Gross Offtake"
NET_OFFTAKE = "Net Offtake"
KEY = "Key"
SHARED_ENERGY = "Shared Energy"
