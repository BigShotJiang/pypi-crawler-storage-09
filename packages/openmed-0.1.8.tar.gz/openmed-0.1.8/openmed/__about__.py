"""Version information for OpenMed."""

__version__ = "0.1.8"
