#ifndef OPENMM_REFERENCEPOINTFUNCTIONS_H_
#define OPENMM_REFERENCEPOINTFUNCTIONS_H_

/* -------------------------------------------------------------------------- *
 *                                   OpenMM                                   *
 * -------------------------------------------------------------------------- *
 * This is part of the OpenMM molecular simulation toolkit.                   *
 * See https://openmm.org/development.                                        *
 *                                                                            *
 * Portions copyright (c) 2021 Stanford University and the Authors.           *
 * Authors: Peter Eastman                                                     *
 * Contributors:                                                              *
 *                                                                            *
 * Permission is hereby granted, free of charge, to any person obtaining a    *
 * copy of this software and associated documentation files (the "Software"), *
 * to deal in the Software without restriction, including without limitation  *
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,   *
 * and/or sell copies of the Software, and to permit persons to whom the      *
 * Software is furnished to do so, subject to the following conditions:       *
 *                                                                            *
 * The above copyright notice and this permission notice shall be included in *
 * all copies or substantial portions of the Software.                        *
 *                                                                            *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,   *
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL    *
 * THE AUTHORS, CONTRIBUTORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,    *
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR      *
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE  *
 * USE OR OTHER DEALINGS IN THE SOFTWARE.                                     *
 * -------------------------------------------------------------------------- */

#include "openmm/Vec3.h"
#include "openmm/internal/windowsExport.h"
#include "lepton/CustomFunction.h"

namespace OpenMM {

/**
 * This implements the pointdistance() function used in custom forces.
 */
class OPENMM_EXPORT ReferencePointDistanceFunction : public Lepton::CustomFunction {
public:
    ReferencePointDistanceFunction(bool periodic, Vec3** boxVectorHandle);
    int getNumArguments() const;
    double evaluate(const double* arguments) const;
    double evaluateDerivative(const double* arguments, const int* derivOrder) const;
    Lepton::CustomFunction* clone() const;
private:
    bool periodic;
    Vec3** boxVectorHandle;
};

/**
 * This implements the pointangle() function used in custom forces.
 */
class OPENMM_EXPORT ReferencePointAngleFunction : public Lepton::CustomFunction {
public:
    ReferencePointAngleFunction(bool periodic, Vec3** boxVectorHandle);
    int getNumArguments() const;
    double evaluate(const double* arguments) const;
    double evaluateDerivative(const double* arguments, const int* derivOrder) const;
    Lepton::CustomFunction* clone() const;
private:
    bool periodic;
    Vec3** boxVectorHandle;
};

/**
 * This implements the pointdihedral() function used in custom forces.
 */
class OPENMM_EXPORT ReferencePointDihedralFunction : public Lepton::CustomFunction {
public:
    ReferencePointDihedralFunction(bool periodic, Vec3** boxVectorHandle);
    int getNumArguments() const;
    double evaluate(const double* arguments) const;
    double evaluateDerivative(const double* arguments, const int* derivOrder) const;
    Lepton::CustomFunction* clone() const;
private:
    bool periodic;
    Vec3** boxVectorHandle;
};

} // namespace OpenMM

#endif /*OPENMM_REFERENCEPOINTFUNCTIONS_H_*/
