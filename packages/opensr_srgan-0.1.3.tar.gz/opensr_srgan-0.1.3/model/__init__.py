"""Model package exposing the SRGAN Lightning module."""

from .SRGAN import SRGAN_model

__all__ = ["SRGAN_model"]
