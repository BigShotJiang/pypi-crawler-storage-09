import opentechcalendartools.cli

if __name__ == "__main__":
    opentechcalendartools.cli.main()
