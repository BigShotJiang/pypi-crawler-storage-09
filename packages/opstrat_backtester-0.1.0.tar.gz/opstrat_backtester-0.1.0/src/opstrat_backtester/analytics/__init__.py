# analytics module init
