# core module init
