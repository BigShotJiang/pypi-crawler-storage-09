__all__ = ("ConversionError",)


class ConversionError(Exception):
    """Could not convert entry to format"""
