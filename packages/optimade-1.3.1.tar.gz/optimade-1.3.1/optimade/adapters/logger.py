"""Logger for optimade.adapters"""

import logging

LOGGER = logging.getLogger("optimade").getChild("adapters")
