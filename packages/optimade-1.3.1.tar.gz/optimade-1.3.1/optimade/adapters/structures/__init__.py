from .adapter import Structure

__all__ = ("Structure",)
