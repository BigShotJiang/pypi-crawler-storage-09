from .accelerator import GaudiAccelerator
