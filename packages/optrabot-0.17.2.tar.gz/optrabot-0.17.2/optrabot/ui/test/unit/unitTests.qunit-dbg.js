"use strict";

sap.ui.define(["./controller/Main.qunit"], function (___controller_Mainqunit) {
  "use strict";
});
//# sourceMappingURL=unitTests.qunit-dbg.js.map
