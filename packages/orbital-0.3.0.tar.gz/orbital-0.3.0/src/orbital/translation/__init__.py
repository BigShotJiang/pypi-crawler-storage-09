"""Translation from ParsedPipeline to Ibis expressions"""
