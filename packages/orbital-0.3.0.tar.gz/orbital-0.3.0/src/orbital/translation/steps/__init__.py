"""Translators for each ParsedPipeline step"""
