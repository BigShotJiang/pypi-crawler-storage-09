# import time
pass

# class SimpleTimer:
#     """
#     Timer for calculating time consume.
#     """
#
#     def __init__(self):
#         self.start_extract_time = 0
#
#     def tick(self):
#         self.start_extract_time = time.perf_counter()
#
#     def tock(self):
#         return time.perf_counter() - self.start_extract_time
