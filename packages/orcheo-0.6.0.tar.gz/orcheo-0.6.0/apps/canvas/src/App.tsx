import "./app.css";

export function App() {
  return (
    <main className="app">
      <h1>Orcheo Canvas</h1>
      <p>
        The visual workflow designer will live here. The current scaffold wires
        up React, Vite, ESLint, Prettier, and Vitest so that future features can
        iterate quickly.
      </p>
    </main>
  );
}
