..
   DO NOT REMOVE THIS FILE!
   Used to generate API documentation. It is hidden (not declared in any toctree) to remove an
   unnecessary intermediate page; index.rst instead points directly to the package page.

.. autosummary::
   :toctree: _autosummary
   :template: custom-module-template.rst
   :recursive:
   :caption: Submodules

   orrery
