"""
	A collection of OpenC2 Actuators built with the otupy framework.
"""
