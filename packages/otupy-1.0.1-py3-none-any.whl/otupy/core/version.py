from otupy.types.data import Version

_OPENC2_VERSION = Version(1,0)
""" OpenC2 version supported by the library """

