from otupy.types.base import Enumerated

class Encoding(Enumerated):

	json=1

