""" SLPF additional data types

	This modules defines additional data types specific for the SLPF profile.
"""

from otupy.profiles.ctxd.targets.context import Context

