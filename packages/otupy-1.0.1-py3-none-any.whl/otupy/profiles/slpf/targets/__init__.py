""" SLPF additional data types

	This modules defines additional data types specific for the SLPF profile.
"""

from otupy.profiles.slpf.profile import Profile
from otupy.profiles.slpf.targets.rule_id import RuleID

