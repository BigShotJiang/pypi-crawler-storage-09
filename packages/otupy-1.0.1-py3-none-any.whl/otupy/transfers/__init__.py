# NOTE: This file is only provided for including all subfolders in the documentation.

""" OpenC2 Transfer protocols

	This folder collects the implementation of Transfer protocols provided with otupy.
"""
