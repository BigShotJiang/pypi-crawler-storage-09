
class Openc2Type():
	""" OpenC2 Language Element
		
		This class is currently unused and is only provided to have a common ancestor for all
		OpenC2 basic types. It may be used in the future to implement common methods or arguments.
	"""
	pass

