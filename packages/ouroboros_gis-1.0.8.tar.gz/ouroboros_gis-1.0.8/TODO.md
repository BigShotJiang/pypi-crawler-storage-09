# TODO

- Write a utility function for saving a raster to a geodatabase ([GDAL OpenFileGDB](https://gdal.org/en/stable/drivers/raster/openfilegdb.html) does not support writing rasters)
- Prebuild GDAL binaries for OpenFileGDB drivers and include with package
- Add full support for zipped geodatabases
