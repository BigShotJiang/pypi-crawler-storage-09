"""
Allow running overflow as a module: python -m overflow
"""

from overflow.cli import main

if __name__ == "__main__":
    main()
