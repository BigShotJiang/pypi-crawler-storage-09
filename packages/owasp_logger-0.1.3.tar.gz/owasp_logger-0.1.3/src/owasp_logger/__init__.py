from .logger import OWASPLogger

__all__ = ["OWASPLogger"]
