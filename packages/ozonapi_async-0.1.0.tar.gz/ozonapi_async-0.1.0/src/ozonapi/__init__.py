"""
Асинхронный интерфейс для взаимодействия с API маркетплейса Ozon.
"""

__version__ = "0.1.0"
__author__ = "Alexander Ulianov"
__all__ = ["SellerAPI", ]

from .seller import SellerAPI
