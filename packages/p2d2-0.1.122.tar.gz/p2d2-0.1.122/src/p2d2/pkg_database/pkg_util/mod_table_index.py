class TableIndex(dict):
    list: list = []

    def __init__(self):
        super().__init__()
