.. image:: https://github.com/pex-tool/p537/workflows/CI/badge.svg?branch=main
    :target: https://github.com/pex-tool/p537/actions?query=branch%3Amain+workflow%3ACI
.. image:: https://img.shields.io/pypi/l/p537.svg
    :target: https://pypi.org/project/p537/
.. image:: https://img.shields.io/pypi/v/p537.svg
    :target: https://pypi.org/project/p537/
.. image:: https://img.shields.io/pypi/pyversions/p537.svg
    :target: https://pypi.org/project/p537/
.. image:: https://img.shields.io/pypi/wheel/p537.svg
    :target: https://pypi.org/project/p537/#files

A tiny platform-specific distribution with a console script.

This distribution serves as a test-case for
`PEX Issue #537 <https://github.com/pex-tool/pex/issues/537>`_.

