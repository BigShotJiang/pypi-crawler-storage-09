# paddle

A minimal, utility subroutines for canoe

## Install

```bash
pip install paddle
