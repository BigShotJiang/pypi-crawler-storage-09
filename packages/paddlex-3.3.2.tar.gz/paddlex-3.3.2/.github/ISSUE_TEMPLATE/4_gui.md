---
name: 4. 星河零代码产线使用问题
about: 星河零代码产线使用问题
title: ''
labels: ''
assignees: ''

---

## Checklist:

- [ ] 查找[历史相关issue](https://github.com/PaddlePaddle/PaddleX/issues)寻求解答
- [ ] 翻阅[FAQ](https://paddlepaddle.github.io/PaddleX/main/FAQ.html)
- [ ] 翻阅[PaddleX 文档](https://paddlepaddle.github.io/PaddleX/main/index.html)
- [ ] 如果是数据校验问题，请确保在开源PaddleX中可以通过数据校验

## 描述问题

## 复现

1. 请提供您出现的报错信息及相关log

2. 请提供您的星河uid和产线id
