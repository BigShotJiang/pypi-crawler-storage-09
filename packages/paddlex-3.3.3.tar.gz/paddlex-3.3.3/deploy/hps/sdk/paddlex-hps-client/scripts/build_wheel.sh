#!/usr/bin/env bash

python -m pip wheel -w wheels --no-deps .
