# Copyright (c) 2024 PaddlePaddle Authors. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from .GOT_ocr_2_0 import GOTImageProcessor, PPChart2TableProcessor
from .paddleocr_vl import PaddleOCRVLProcessor, SiglipImageProcessor
from .qwen2_5_vl import PPDocBee2Processor, Qwen2_5_VLImageProcessor
from .qwen2_vl import PPDocBeeProcessor, Qwen2VLImageProcessor
