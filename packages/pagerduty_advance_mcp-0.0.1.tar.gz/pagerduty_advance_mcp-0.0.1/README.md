# PagerDuty Advance Official MCP Server

The official MCP server for interacting with PagerDuty Advance's `/chat` functionality

[![Install MCP Server](https://cursor.com/deeplink/mcp-install-dark.svg)](https://cursor.com/install-mcp?name=pagerduty-advance-mcp&config=ewogICAgICAidHlwZSI6ICJzdGRpbyIsCiAgICAgICJjb21tYW5kIjogInV2eCIsCiAgICAgICJhcmdzIjogWwogICAgICAgICJwYWdlcmR1dHktbWNwIiwKICAgICAgICAiLS1lbmFibGUtd3JpdGUtdG9vbHMiCiAgICAgIF0sCiAgICAgICJlbnYiOiB7CiAgICAgICAgIlBBR0VSRFVUWV9VU0VSX0FQSV9LRVkiOiAiIiwKICAgICAgICAiUEFHRVJEVVRZX0FQSV9IT1NUIjogImh0dHBzOi8vYXBpLnBhZ2VyZHV0eS5jb20iCiAgICAgIH0KICAgIH0=)

PagerDuty's local MCP (Model Context Protocol) server which provides tools to interact with PagerDuty AI Agent.

## Prerequisites

- [asdf-vm](https://asdf-vm.com/) installed.
- [uv](https://github.com/astral-sh/uv) installed globally.
- A PagerDuty **User API Token**.
  To obtain a PagerDuty User API Token, follow these steps:

  1. **Navigate to User Settings.** Click on your user profile icon, then select **My Profile** and then **User Settings**.
  2. In your user settings, locate the **API Access** section.
  3. Click the **Create API User Token** button and follow the prompts to generate a new token.
  4. **Copy the generated token and store it securely**. You will need this token to configure the MCP server.

  > Use of the PagerDuty User API Token is subject to the [PagerDuty Developer Agreement](https://developer.pagerduty.com/docs/pagerduty-developer-agreement).

## Using with MCP Clients

### VS Code Integration

You can configure this MCP server directly within Visual Studio Code's `settings.json` file, allowing VS Code to manage the server lifecycle.

1.  Open VS Code settings (File > Preferences > Settings, or `Cmd+,` on Mac, or `Ctrl+,` on Windows/Linux).
2.  Search for "mcp" and ensure "Mcp: Enabled" is checked under Features > Chat.
3.  Click "Edit in settings.json" under "Mcp > Discovery: Servers".
4.  Add the following configuration:

    ```json
    {
      "mcp": {
        "inputs": [
          {
            "type": "promptString",
            "id": "pagerduty-api-key",
            "description": "PagerDuty API Key",
            "password": true
          }
        ],
        "servers": {
          "pagerduty-advance-mcp": {
            "type": "stdio",
            "command": "uvx",
            "args": ["pagerduty-advance-mcp"],
            "env": {
              "PAGERDUTY_USER_API_KEY": "${input:pagerduty-api-key}",
              "PAGERDUTY_API_HOST": "https://api.pagerduty.com"
              // If your PagerDuty account is located in EU update your API host to https://api.eu.pagerduty.com
            }
          }
        }
      }
    }
    ```

#### Trying it in VS Code Chat (Agent)

1.  Ensure MCP is enabled in VS Code settings (Features > Chat > "Mcp: Enabled").
2.  Configure the server as described above.
3.  Open the Chat view in VS Code (`View` > `Chat`).
4.  Make sure `Agent` mode is selected. In the Chat view, you can enable or disable specific tools by clicking the 🛠️ icon.
5.  Enter a command such as `Show me the latest incident` to interact with your PagerDuty account through the MCP server.
6.  You can start, stop, and manage your MCP servers using the command palette (`Cmd+Shift+P`/`Ctrl+Shift+P`) and searching for `MCP: List Servers`. Ensure the server is running before sending commands. You can also try to restart the server if you encounter any issues.

### Claude Desktop Integration

You can configure this MCP server to work with Claude Desktop by adding it to Claude's configuration file.

1.  **Locate your Claude Desktop configuration file:**

    - **macOS:** `~/Library/Application Support/Claude/claude_desktop_config.json`
    - **Windows:** `%APPDATA%\Claude\claude_desktop_config.json`

2.  **Create or edit the configuration file** and add the following configuration:

    ```json
    {
      "mcpServers": {
        "pagerduty-advance-mcp": {
          "command": "uvx",
          "args": ["pagerduty-advance-mcp"],
          "env": {
            "PAGERDUTY_USER_API_KEY": "your-pagerduty-api-key-here",
            "PAGERDUTY_API_HOST": "https://api.pagerduty.com"
          }
        }
      }
    }
    ```

3.  **Replace the placeholder values:**

    - Replace `/path/to/your/mcp-server-directory` with the full path to the directory where you cloned the MCP server (e.g., `/Users/yourname/code/pagerduty-advance-mcp`)
    - Replace `your-pagerduty-api-key-here` with your actual PagerDuty User API Token
    - If your PagerDuty account is located in the EU, update the API host to `https://api.eu.pagerduty.com`

4.  **Restart Claude Desktop** completely for the changes to take effect.

5.  **Test the integration** by starting a conversation with Claude and asking something like "Show me my latest PagerDuty incidents" to verify the MCP server is working.

    > **Security Note:** Unlike VS Code's secure input prompts, Claude Desktop requires you to store your API key directly in the configuration file. Ensure this file has appropriate permissions (readable only by your user account) and consider the security implications of storing credentials in plain text.

## Set up locally

1.  **Clone the repository**

2.  **Install `asdf` plugins**

    ```shell
    asdf plugin add python
    asdf plugin add nodejs https://github.com/asdf-vm/asdf-nodejs.git
    asdf plugin add uv
    ```

3.  **Install tool versions** using `asdf`:

    ```shell
    asdf install
    ```

4.  **Create a virtual environment and install dependencies** using `uv` (now that `asdf` has set the correct Python and `uv` versions):

    ```shell
    uv sync
    ```

5.  **Ensure `uv` is available globally.**

    The MCP server can be run from different places so you need `uv` to be available globally. To do so, follow the [official documentation](https://docs.astral.sh/uv/getting-started/installation/).

    > **Tip:** You may need to restart your terminal and/or VS Code for the changes to take effect.

6.  Run it locally

    To run your cloned PagerDuty Advance MCP Server you need to update your configuration to use `uv` instead of `uvx`.

    ```json
    "pagerduty-advance-mcp": {
        "type": "stdio",
        "command": "uv",
        "args": [
            "run",
            "--directory",
            "/path/to/your/mcp-server-directory",
            // Replace with the full path to the directory where you cloned the MCP server, e.g. "/Users/yourname/code/mcp-server",
            "python",
            "-m",
            "pagerduty_advance_mcp",
        ],
        "env": {
            "PAGERDUTY_USER_API_KEY": "${input:pagerduty-api-key}",
            "PAGERDUTY_API_HOST": "https://api.pagerduty.com"
            // If your PagerDuty account is located in EU update your API host to https://api.eu.pagerduty.com
        }
    }
    ```

## Available Tools and Resources

This section describes the tools provided by the PagerDuty Advance MCP server.

| Tool                           | Area       | Description                                      |
| -----------------------------  | ---------- | ------------------------------------             |
| chat_assistant_service_request | PD Advance | Creates a new message to the PD Advance AI Agent |

## Support

PagerDuty's MCP server is an open-source project, and as such, we offer only community-based support. If assistance is required, please open an issue in [GitHub](https://github.com/PagerDuty/pagerduty-advance-mcp-server) or [PagerDuty's community forum](https://community.pagerduty.com/).

## Contributing

If you are interested in contributing to this project, please refer to our [Contributing Guidelines](https://github.com/PagerDuty/pagerduty-advance-mcp-server/blob/main/CONTRIBUTING.md).
