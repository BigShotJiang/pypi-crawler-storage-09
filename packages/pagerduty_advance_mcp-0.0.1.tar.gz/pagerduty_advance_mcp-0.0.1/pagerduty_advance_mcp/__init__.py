DIST_NAME = "pagerduty-advance-mcp"
