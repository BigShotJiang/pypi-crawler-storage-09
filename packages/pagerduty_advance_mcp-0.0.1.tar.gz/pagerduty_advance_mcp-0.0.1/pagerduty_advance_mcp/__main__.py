from pagerduty_advance_mcp.server import app


def main():
    """Main entry point for the pagerduty-advance-mcp command."""
    app()


if __name__ == "__main__":
    main()
