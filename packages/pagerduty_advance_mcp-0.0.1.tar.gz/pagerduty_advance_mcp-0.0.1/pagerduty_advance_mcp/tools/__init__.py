from .chat_assistant_service_request import chat_assistant_service_request

tools = [chat_assistant_service_request]
