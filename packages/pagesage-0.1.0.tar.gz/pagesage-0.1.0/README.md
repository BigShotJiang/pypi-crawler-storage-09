
pagesage
==================================================

Serve markdown pages and files as static website.

## Usage

Change into the root directory of your documentation project and run pagesage on a specific port (e.g. 8000):

```
pagesage run 8000
```

Directories containing `index.md` file will render the index markdown file. If index is not present, it will list other directories and files.


