"""
pagesage - Serve markdown pages and files as static website.
"""
__version__ = "0.1.0"
__license__ = "BSD"
__year__ = "2024"
__author__ = "Predrag Mandic"
__author_email__ = "predrag@nul.one"
__copyright__ = f"Copyright {__year__} {__author__} <{__author_email__}>"
