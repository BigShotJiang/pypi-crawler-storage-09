File Types
==========

.. autoclass:: pancad.filetypes.PartFile
    :members:

Enumerations
------------

.. autoclass:: pancad.constants.SoftwareName
    :show-inheritance:
    :members:

.. autoclass:: pancad.constants.ConfigCategory
    :show-inheritance:
    :members:
