from pancad.utils.initialize import PANCAD_CONFIG_DIR, check_config

check_config()

from pancad.filetypes import PartFile