from os.path import dirname

from tests import sample_freecad

SAMPLE_FREECAD = dirname(sample_freecad.__file__)