void qemu_log_close(void);
void qemu_set_log(unsigned int log_flags);
int qemu_log(const char *fmt, ...);