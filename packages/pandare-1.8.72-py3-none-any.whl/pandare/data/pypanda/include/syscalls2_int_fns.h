
// returns the system call return value, hiding arch-specific details
target_long get_syscall_retval(CPUState *cpu);

