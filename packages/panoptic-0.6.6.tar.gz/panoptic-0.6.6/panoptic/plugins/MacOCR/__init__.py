from .mac_ocr import MacOCR

plugin_class = MacOCR
