"""
Test suite for parakeet-stream
"""
