from __future__ import annotations

from .__version import __version__

__all__ = ("__version__",)
