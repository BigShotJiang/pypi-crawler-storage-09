from .cli import cli  # noqa: F401
from .colors import ColorBy  # noqa: F401
from .core import Viewer  # noqa: F401
from .file import OpenFileDialog, OpenFileToggle  # noqa: F401
from .hover import HoverPoint  # noqa: F401
from .palette import PalettePicker  # noqa: F401
from .pipeline import PipelineBrowser  # noqa: F401
from .representation import RepresentBy  # noqa: F401
from .reset_camera_button import ResetCameraButtons  # noqa: F401
from .utils import PARAVIEW_EXAMPLES, PARAVIEW_ROOT  # noqa: F401
from .vcr import TimeControl  # noqa: F401
from .views.table import ViewTable  # noqa: F401
from .vuetify import *  # noqa: F403
from trame.widgets.html import *  # noqa: F403
from .multiblock import MultiBlockInspector  # noqa: F401
from .proxy_editor import ProxyEditor  # noqa: F401
from .toolbar import VerticalToolbar  # noqa: F401
from .filters import AddFilterDialog  # noqa: F401

try:
    from .dockable_views import MultiView  # noqa: F401
except ImportError:
    print("MultiView is not available without installing trame-dockview.")

__version__ = "0.15.0"
