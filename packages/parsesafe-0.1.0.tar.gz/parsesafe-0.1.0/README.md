# parsesafe
PrarseSafe is a pure-Python parsing-combinator library designed to be type safe;
to wit, modern Python type hints are used to allow static type checkers to validate
the correctness of function/method usage and to empower LSPs to give useful hints.
