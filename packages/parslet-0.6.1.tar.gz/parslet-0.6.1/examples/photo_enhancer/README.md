# Edge-AI Photo Enhancer

Enhances a local photo using Pillow. If battery is low the DAG waits briefly before proceeding.

```bash
parslet run examples/photo_enhancer.py
```
