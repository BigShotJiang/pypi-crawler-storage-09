Parslet Documentation
=====================

This directory contains the Sphinx sources for the Parslet project.
Build the HTML docs with ``make html`` and view the output in ``_build/html``.
