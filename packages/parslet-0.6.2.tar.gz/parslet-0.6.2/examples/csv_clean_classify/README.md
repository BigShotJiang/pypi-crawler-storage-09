# Offline CSV Cleaner and Classifier

This example loads a local CSV file, drops empty rows, classifies them by a simple length rule, and saves a new CSV with the labels.

Run it with:

```bash
parslet run examples/csv_clean_classify.py
```
