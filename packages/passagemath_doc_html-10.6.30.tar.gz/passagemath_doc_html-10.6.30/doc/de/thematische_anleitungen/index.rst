.. Sage documentation master file, created by sphinx-quickstart on Thu Aug 21 20:15:55 2008.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Sage thematische Anleitungen
=============================
Die folgenden Dokumente sind thematische Anleitungen, welche sich mit
speziellen Einsatzgebieten von Sage befassen.

Die Anleitungen sind unter einer  `Creative Commons Attribution-Share Alike
3.0 Lizenz`__ lizenziert.

__ http://creativecommons.org/licenses/by-sa/3.0/

.. toctree::
   :maxdepth: 1

   sage_gymnasium

