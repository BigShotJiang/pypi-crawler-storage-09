
Educational Versions of Groebner Basis Related Algorithms
=========================================================

.. toctree::
   :maxdepth: 1

   sage/rings/polynomial/toy_buchberger
   sage/rings/polynomial/toy_variety
   sage/rings/polynomial/toy_d_basis

