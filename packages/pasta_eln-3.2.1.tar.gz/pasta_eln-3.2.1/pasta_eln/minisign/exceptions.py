# pylint: skip-file
class Error(ValueError):
    pass


class ParseError(Error):
    pass


class VerifyError(Error):
    pass
