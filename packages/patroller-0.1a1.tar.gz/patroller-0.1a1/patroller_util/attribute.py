# coding:utf-8

__project__ = "patroller"
__version__ = "0.1.alpha.1"
__urlhome__ = "https://github.com/bondbox/patroller/"
__description__ = "System Inspection Kits"

# author
__author__ = "Mingzhe Zou"
__author_email__ = "zoumingzhe@outlook.com"
