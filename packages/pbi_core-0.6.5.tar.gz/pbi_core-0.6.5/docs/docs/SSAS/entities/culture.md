# Culture


::: pbi_core.ssas.model_tables.culture.Culture