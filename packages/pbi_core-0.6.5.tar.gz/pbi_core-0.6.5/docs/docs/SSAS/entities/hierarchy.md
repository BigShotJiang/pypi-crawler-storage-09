# Hierarchy


::: pbi_core.ssas.model_tables.hierarchy.Hierarchy