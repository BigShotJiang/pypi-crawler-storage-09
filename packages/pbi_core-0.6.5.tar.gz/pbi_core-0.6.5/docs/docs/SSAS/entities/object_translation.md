# Object Translation


::: pbi_core.ssas.model_tables.object_translation.ObjectTranslation