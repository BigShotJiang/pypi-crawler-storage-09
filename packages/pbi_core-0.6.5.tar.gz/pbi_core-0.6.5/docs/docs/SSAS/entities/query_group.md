# Query Group


::: pbi_core.ssas.model_tables.query_group.QueryGroup