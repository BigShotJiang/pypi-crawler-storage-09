# Role


::: pbi_core.ssas.model_tables.role.Role