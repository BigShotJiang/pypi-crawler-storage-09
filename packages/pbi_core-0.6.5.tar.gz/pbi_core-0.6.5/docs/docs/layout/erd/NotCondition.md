```mermaid
---
title: NotCondition
---
graph 
NotCondition[<a href='/layout/erd/NotCondition'>NotCondition</a>]
NotConditionHelper[NotConditionHelper]
NotCondition --->|Not| NotConditionHelper
```