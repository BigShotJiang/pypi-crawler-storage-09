from enum import Enum


class DefaultDataView(Enum):
    FULL = 0
    SAMPLE = 1
    DEFAULT = 3
