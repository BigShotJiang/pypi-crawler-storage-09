from enum import Enum


class MemberType(Enum):
    AUTO = 1
    USER = 2
    GROUP = 3
