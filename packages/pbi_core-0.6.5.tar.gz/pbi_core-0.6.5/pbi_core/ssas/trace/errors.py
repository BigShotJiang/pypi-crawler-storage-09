class NoQueryError(BaseException):
    """Raised when no query is provided to the performance trace."""
