# Calculation Item


::: pbi_core.ssas.model_tables.calculation_item.CalculationItem