# Group By Column


::: pbi_core.ssas.model_tables.group_by_column.GroupByColumn