# Perspective Hierarchy


::: pbi_core.ssas.model_tables.perspective_hierarchy.PerspectiveHierarchy