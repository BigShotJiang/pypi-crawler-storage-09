# Perspective Measure


::: pbi_core.ssas.model_tables.perspective_measure.PerspectiveMeasure