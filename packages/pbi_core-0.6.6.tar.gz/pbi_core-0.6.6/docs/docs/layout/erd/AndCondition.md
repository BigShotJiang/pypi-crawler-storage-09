```mermaid
---
title: AndCondition
---
graph 
AndCondition[<a href='/layout/erd/AndCondition'>AndCondition</a>]
CompositeConditionHelper[CompositeConditionHelper]
AndCondition --->|And| CompositeConditionHelper
```