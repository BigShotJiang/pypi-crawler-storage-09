from pbi_core.attrs import define
from pbi_core.ssas.model_tables.base.base_ssas_table import SsasTable


@define()
class GroupByColumn(SsasTable):
    """TBD.

    SSAS spec:
    """
