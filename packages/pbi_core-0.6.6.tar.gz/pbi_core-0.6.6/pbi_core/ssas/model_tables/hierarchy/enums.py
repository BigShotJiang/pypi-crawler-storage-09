from enum import Enum


class HideMembers(Enum):
    DEFAULT = 0
    HIDE_BLANK_MEMBERS = 1
