from enum import Enum


class ProgressReportBeginColumns(Enum):
    pass


class ProgressReportEndColumns(Enum):
    pass


class ProgressReportCurrentColumns(Enum):
    pass


class ProgressReportErrorColumns(Enum):
    pass
