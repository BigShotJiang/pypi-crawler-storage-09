from pbi_core.attrs import BaseValidation


class BaseFileModel(BaseValidation):
    pass
