from .main import LEGEND_TEMPLATE, MERMAID_TEMPLATE, render_html

__all__ = ["render_html", "MERMAID_TEMPLATE", "LEGEND_TEMPLATE"]
