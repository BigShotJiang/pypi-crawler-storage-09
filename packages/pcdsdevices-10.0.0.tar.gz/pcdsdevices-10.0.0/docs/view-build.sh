#!/bin/bash
xdg-open build/html/index.html
