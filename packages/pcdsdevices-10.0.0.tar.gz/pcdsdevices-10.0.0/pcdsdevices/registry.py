from ophyd.ophydobj import register_instances_keyed_on_name

device_registry = register_instances_keyed_on_name()
