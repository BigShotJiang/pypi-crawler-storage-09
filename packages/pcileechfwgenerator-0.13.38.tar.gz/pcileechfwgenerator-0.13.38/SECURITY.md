# Security Policy

## Supported Versions

Use the latest version. This tool is as secure as it can be but please read and evaluate the source code yourself

## Reporting a Vulnerability

Add an issue pls.
