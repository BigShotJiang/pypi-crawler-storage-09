"""pdfbaker - Create PDF documents from YAML-configured SVG templates."""

__version__ = "0.11.1"
__all__ = ["__version__"]
