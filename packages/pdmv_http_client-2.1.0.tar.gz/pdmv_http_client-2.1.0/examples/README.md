# Examples

This folder has some examples of how to query requests in McM (using the client included in this folder) and how to modify its attributes. You can use them as a guideline to develop your scripts.