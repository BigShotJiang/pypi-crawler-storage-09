import json
import os
import tempfile
from pathlib import Path

import pytest


def create_empty_file(permissions) -> Path:
    """
    Creates an empty writable file.

    Returns:
        Path: Temporal file path
    """
    temp_file = tempfile.NamedTemporaryFile(delete=False)
    temp_file_name = Path(temp_file.name)
    temp_file.close()
    os.chmod(temp_file_name, permissions)
    return temp_file_name


@pytest.fixture
def writable_file():
    """
    Creates a writable file and disposes it when
    the execution finishes.
    """
    file = create_empty_file(0o700)
    yield file
    try:
        os.remove(file)
    except FileNotFoundError:
        pass


@pytest.fixture
def empty_json_file() -> Path:
    """
    Creates a temporal file with an empty JSON object.

    Returns:
        Path: Temporal file path
    """
    temp_file_name = create_empty_file(0o700)
    with open(file=temp_file_name, mode="w") as f:
        json.dump(obj={}, fp=f)
    return temp_file_name
