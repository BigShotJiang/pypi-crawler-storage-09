"""
Tests for the base library that can find issues before the integration tests
"""
pass
