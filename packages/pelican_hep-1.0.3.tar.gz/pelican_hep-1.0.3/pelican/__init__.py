from .nets import PELICAN

from importlib.metadata import version as _pkg_version

__version__ = _pkg_version("pelican-hep")
