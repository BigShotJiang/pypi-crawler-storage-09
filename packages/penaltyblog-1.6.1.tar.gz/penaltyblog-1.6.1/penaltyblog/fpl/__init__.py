"""
Fantasy Premier League module

Used to scrape and process data from the Fantasy Premier League API.
"""

from .fpl import *  # noqa
