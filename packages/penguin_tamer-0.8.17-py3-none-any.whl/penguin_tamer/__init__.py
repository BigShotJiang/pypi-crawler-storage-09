"""Penguin Tamer - AI-powered terminal assistant."""

from penguin_tamer.llm_client import debug_print_messages

__all__ = ["debug_print_messages"]

# TODO: добавить возможность сохранения 10 последних сессий и их возобновления
