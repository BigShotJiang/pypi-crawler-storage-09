"""Utility modules for Penguin Tamer."""
