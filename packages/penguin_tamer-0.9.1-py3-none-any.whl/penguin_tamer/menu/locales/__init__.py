"""
Menu localization package.
"""
