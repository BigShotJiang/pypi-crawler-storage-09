# Locales package for penguin-tamer internationalization
