"""Version information for perceptra-zero-shot."""

__version__ = "0.1.0"
__author__ = "Tannous Geagea"
__email__ = "tannousgeagea@hotmail.com"
