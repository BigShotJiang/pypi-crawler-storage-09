"""REST API for perceptra-zero-shot."""

from perceptra_zero_shot.api.main import app

__all__ = ["app"]