"""Command-line interface for perceptra-zero-shot."""

from perceptra_zero_shot.cli.main import cli

__all__ = ["cli"]