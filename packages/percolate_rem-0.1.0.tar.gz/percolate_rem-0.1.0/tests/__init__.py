"""Test suite for percolate."""
