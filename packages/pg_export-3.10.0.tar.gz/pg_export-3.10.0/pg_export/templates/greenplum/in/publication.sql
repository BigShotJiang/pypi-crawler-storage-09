select
 where false
