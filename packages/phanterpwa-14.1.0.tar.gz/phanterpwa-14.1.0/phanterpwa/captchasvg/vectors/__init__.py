__all__ = ['animal', 'arrow', 'letter', 'mean_of_transport', 'number']
