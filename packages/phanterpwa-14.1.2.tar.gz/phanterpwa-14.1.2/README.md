# Phanterpwa
    Tools for the phanterpwadeveloper framework

## Dependencies installed on setup

    psutil
    tornado
    libsass
    transcrypt
    pillow
    itsdangerous
    pydal
    passlib
    requests-oauthlib

## Requeriments
    Python 3.6+
    Python 3.7 Recommended

## Browser Compatibility
#### The browser needs compatibility with:
    HTML5
    ES6 (Javascript6)

## Web Tecnologies
    jQuery
    Font Awesome
