"""Photoshop adapter module."""
