"""MCP resources module."""
