class TransactionError(Exception):
    pass
