from django.apps import AppConfig


class PickerConfig(AppConfig):
    name = "picker"
    verbose_name = "Django Picker"
