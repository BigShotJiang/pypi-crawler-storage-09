class PickerException(Exception):
    pass


class PickerResultException(PickerException):
    pass


class PickerConfigurationError(PickerException):
    pass
