class PageSizeError(ValueError):
    pass


class MarginError(ValueError):
    pass


class LayoutError(ValueError):
    pass


class RGBColorError(ValueError):
    pass
