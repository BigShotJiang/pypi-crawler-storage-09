API
---

.. automodule:: pigreads
