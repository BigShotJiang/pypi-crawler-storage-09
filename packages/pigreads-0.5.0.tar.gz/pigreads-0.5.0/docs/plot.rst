Plotting
--------

.. automodule:: pigreads.plot
