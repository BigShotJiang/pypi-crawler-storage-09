\page md_doc_a-features_h-frames Operational frames

TODO: as frames are not necessary to understand the previous sections, it could
be a good idea to treat them
separately. Introduce them here together with the related algorithms.
