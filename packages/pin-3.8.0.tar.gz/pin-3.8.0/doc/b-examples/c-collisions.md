# Collision detection and distances

## Python
\include collisions.py

## C++
\include collisions.cpp
