# Display a model using Meshcat

\include meshcat-viewer.py
