# Update model after loading its URDF

This example shows how to update a robot model after loading it from a URDF description.

## Python

\include update-model-after-urdf.py
