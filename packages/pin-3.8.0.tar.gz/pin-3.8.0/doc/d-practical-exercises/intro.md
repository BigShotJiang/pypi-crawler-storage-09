# Practical Exercises

This section contains complete exercices to understand Pinocchio.
