//
// Copyright (c) 2025 INRIA
//
#include "pinocchio/container/boost-container-limits.hpp"
#include <eigenpy/eigenpy.hpp>
#include <boost/python.hpp>
#include <boost/variant.hpp>
#include <Eigen/Core>
#include <Eigen/Sparse>
#include <Eigen/Geometry>
#include <unsupported/Eigen/CXX11/Tensor>
