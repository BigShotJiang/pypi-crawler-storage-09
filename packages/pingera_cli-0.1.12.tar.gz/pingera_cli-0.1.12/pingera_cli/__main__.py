
"""
Main module entry point for python -m pingera_cli execution
"""

from .main import cli_entry_point

if __name__ == "__main__":
    cli_entry_point()
