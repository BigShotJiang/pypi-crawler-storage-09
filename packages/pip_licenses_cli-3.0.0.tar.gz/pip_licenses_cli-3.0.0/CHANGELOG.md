# Development Version

# Version 3.0.0 - 2025-10-20

* Fix notice file headers being emitted after the actual notice text instead of before (like for the license texts).
* Add support for the `License-File` field for specifying additional licensing-related files (PEP 639).
* Add support for emitting multiple files in the JSON and *plain-vertical* mode.
* Drop support for Python 3.9.
* Migrate tests to plain *unittest* functionality.

# Version 2.0.0 - 2025-07-30

* Fix partial matching for empty entries in the given license list.
* Improve modularization by replacing the single file module with appropriate submodules.

# Version 1.4.0 - 2025-07-02

* Add new flag `--collect-all-failures` to collect all failures before exiting.

# Version 1.3.0 - 2025-06-28

* Make `pyproject.toml` configuration section name backwards-compatible

# Version 1.2.0 - 2025-06-03

* Add optional support for parsing SPDX expressions. For now, this is limited to simple OR expressions.

# Version 1.1.0 - 2025-05-26

* Do some more cleanup, including moving the usage docs into a dedicated file.
* Drop `tomli` dependency for Python >= 3.11.

# Version 1.0.0 - 2025-05-16

* First forked version, based upon *pip-licenses* 5.0.
