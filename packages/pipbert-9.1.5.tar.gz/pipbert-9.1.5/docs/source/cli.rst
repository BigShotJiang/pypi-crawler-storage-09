==================================
``.cli`` - Command line interface.
==================================

.. automodule:: pybert.cli
   :members:
