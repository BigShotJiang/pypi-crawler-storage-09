===========================================================
``.common`` - Common miscellaneous definitions and aliases.
===========================================================

.. automodule:: pybert.common
   :members: Real,Comp,Rvec,Cvec,Rmat,Cmat
   :member-order: bysource
