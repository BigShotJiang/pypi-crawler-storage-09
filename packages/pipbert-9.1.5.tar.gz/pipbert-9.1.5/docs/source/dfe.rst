====================
``.dfe`` - DFE Model
====================

.. automodule:: pybert.models.dfe
   :members:
