==========================================================
``.results`` - Data structure for saving *PyBERT* results.
==========================================================

.. automodule:: pybert.results
   :members:
