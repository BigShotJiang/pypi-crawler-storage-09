================================
``.sim`` - BERT Simulator Thread
================================

.. automodule:: pybert.threads.sim
   :members:
