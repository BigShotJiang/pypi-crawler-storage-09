# pipeMT
Pipeline training framework for multiple large pytorch models on multiple devices
