# -*- coding: utf-8 -*-
from .piper_protocol_v2 import C_PiperParserV2

__all__ = [
    "C_PiperParserV2"
]
