!!! example "base_path"
    The path prefix for datasets, models, checkpoints, and results.

    Default value: `./`

!!! example "debug"
    When `debug` is turned off, the server will try to recover from a failed client by using client processes that are still alive for training. If it's turned on, the server will terminate itself immediately when a client fails.

    Valid values: `true` or `false`

    Default value: `false`
