"""Example configurations and utilities for Plato.

This package marker allows example modules to be imported when needed.
"""
