::: platypus.DTFGraph
    :docstring:
    :members:

