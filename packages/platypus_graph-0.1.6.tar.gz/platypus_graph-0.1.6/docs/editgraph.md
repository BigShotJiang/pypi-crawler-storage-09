::: platypus.EditGraph
    :docstring:
    :members:

