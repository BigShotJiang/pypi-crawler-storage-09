::: platypus.VMap
    :docstring:
    :members:

