# Enumerations

```{eval-rst}
.. automodule:: plexosdb.enums
    :members:
    :undoc-members:
    :show-inheritance:
```
