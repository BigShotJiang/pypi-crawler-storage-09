# Exceptions

```{eval-rst}
.. automodule:: plexosdb.exceptions
    :members:
    :undoc-members:
    :show-inheritance:
```
