# SQLite Manager

```{eval-rst}
.. automodule:: plexosdb.db_manager
    :members:
    :undoc-members:
    :show-inheritance:
```
