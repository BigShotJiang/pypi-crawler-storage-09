# This file containts the version  # noqa: D100
__version__ = "v1.1.2"
