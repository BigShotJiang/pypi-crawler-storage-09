This project creates plots for machine learning similar to yellowbricks https://www.scikit-yb.org/en/latest/.

It uses plotly to generate interactive visualizations and employs a dataframe interface using polars. Just pass you dataframe and specify the columns:
we use the following libraries: plotly, polars
