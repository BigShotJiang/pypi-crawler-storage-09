"""
plotly_ml: Interactive ML Visualizations with Plotly
"""

from . import regression as regression
from . import univariant as univariant
