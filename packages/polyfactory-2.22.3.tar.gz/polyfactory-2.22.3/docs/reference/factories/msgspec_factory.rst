msgspec_factory
================

.. automodule:: polyfactory.factories.msgspec_factory
    :members:
