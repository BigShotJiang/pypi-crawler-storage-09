#include "Logging.h"

namespace polyhedralGravity {

    const PolyhedralGravityLogger PolyhedralGravityLogger::DEFAULT_LOGGER{};

}