# Ramer-Douglas-Peucker
