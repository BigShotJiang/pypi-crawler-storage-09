# Version number of this package (pomme)
__version__ = "0.2.0"

import torch
torch.set_default_dtype(torch.float64)