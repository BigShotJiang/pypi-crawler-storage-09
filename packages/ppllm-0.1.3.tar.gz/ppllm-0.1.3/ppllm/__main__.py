from .ppl import cli

if __name__ == "__main__":
    cli()
