"""User interface (UI) modules for interactive consoles and TUI components."""


