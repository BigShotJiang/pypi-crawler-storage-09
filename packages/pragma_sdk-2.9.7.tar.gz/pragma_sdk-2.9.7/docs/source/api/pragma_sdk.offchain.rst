pragma_sdk.offchain
=======================



PragmaAPIClient
-----------------------------

.. automodule:: pragma_sdk.offchain.client
   :members:
   :undoc-members:
   :show-inheritance:

OffchainSigner
-----------------------------

.. automodule:: pragma_sdk.offchain.signer
   :members:
   :undoc-members:
   :show-inheritance:

Interval
----------------------------

.. automodule:: pragma_sdk.offchain.types
   :members:
   :undoc-members:
   :show-inheritance:
