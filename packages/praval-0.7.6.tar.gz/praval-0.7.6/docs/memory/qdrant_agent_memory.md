# Qdrant Agent Memory System Design

## Overview

This document outlines the design for a Qdrant-based long-term memory system for Praval agents. The system will provide semantic memory capabilities while maintaining Praval's philosophy of simplicity and sensible defaults.

## Design Philosophy Alignment

Following Praval's core principles:

- **Zero Configuration Required**: Agents with memory should work out-of-the-box with sensible defaults
- **Progressive Enhancement**: Basic memory works immediately, advanced features available when needed  
- **Composable Architecture**: Memory system integrates cleanly with existing Agent class
- **Provider Agnostic**: Support multiple embedding providers with automatic detection
- **State Management**: Seamless integration with existing persistence mechanisms

## Architecture

### Core Components

#### 1. VectorMemory Class
Handles all vector database operations and embedding management.

**Key Responsibilities:**
- Embedding generation and caching
- Qdrant collection management
- Semantic similarity search
- Memory consolidation and cleanup

#### 2. MemoryManager Class  
Orchestrates memory operations and integrates with Agent lifecycle.

**Key Responsibilities:**
- Memory storage decisions (what to remember)
- Context injection during conversations
- Memory retrieval strategies
- Background memory consolidation

#### 3. Agent Integration
Extends existing Agent class with minimal API surface area.

**Integration Points:**
- Constructor parameter: `memory_enabled=True`
- Automatic memory querying before response generation
- Post-conversation memory storage
- Memory-aware conversation history

## Embedding Model Strategy

### Default Model Selection
The system will automatically select embedding models based on available resources:

1. **Primary Default**: `sentence-transformers/all-MiniLM-L6-v2`
   - Lightweight (22MB)
   - Good general performance
   - Fast inference
   - Works offline

2. **Fallback Options**:
   - `sentence-transformers/all-mpnet-base-v2` (higher quality, larger)
   - OpenAI `text-embedding-3-small` (if API key available)
   - Cohere embeddings (if API key available)

### Model Selection Logic
```python
# Automatic detection based on environment
if os.getenv("OPENAI_API_KEY"):
    default_model = "openai/text-embedding-3-small"
elif os.getenv("COHERE_API_KEY"):
    default_model = "cohere/embed-english-v3.0"
else:
    default_model = "sentence-transformers/all-MiniLM-L6-v2"
```

### Custom Model Configuration
Users can specify custom embedding models:

```python
# Local sentence-transformers model
agent = Agent("assistant", memory_enabled=True, 
              memory_config={"embedding_model": "sentence-transformers/all-mpnet-base-v2"})

# API-based model
agent = Agent("assistant", memory_enabled=True,
              memory_config={"embedding_model": "openai/text-embedding-3-large"})

# Custom model with parameters
agent = Agent("assistant", memory_enabled=True,
              memory_config={
                  "embedding_model": "custom/model-name",
                  "embedding_params": {"max_length": 512}
              })
```

### Supported Embedding Providers

#### Local Models (sentence-transformers)
- `sentence-transformers/all-MiniLM-L6-v2` (default)
- `sentence-transformers/all-mpnet-base-v2`
- `sentence-transformers/multi-qa-mpnet-base-dot-v1`
- Any Hugging Face sentence-transformers model

#### API-based Models
- **OpenAI**: `text-embedding-3-small`, `text-embedding-3-large`, `text-embedding-ada-002`
- **Cohere**: `embed-english-v3.0`, `embed-multilingual-v3.0`
- **Anthropic**: Future support when embedding API is available

## Memory Configuration

### Default Configuration
The system works with zero configuration:

```python
# This just works - uses all defaults
agent = Agent("assistant", memory_enabled=True)
```

### Advanced Configuration
For users who need customization:

```python
memory_config = {
    # Qdrant settings
    "qdrant_url": "localhost:6333",  # Default
    "qdrant_api_key": None,          # Optional
    "collection_name": None,         # Auto-generated: f"agent_{agent_name}"
    
    # Embedding settings  
    "embedding_model": "sentence-transformers/all-MiniLM-L6-v2",
    "embedding_params": {},
    "embedding_cache": True,         # Cache embeddings locally
    
    # Memory behavior
    "similarity_threshold": 0.7,     # Minimum similarity for retrieval
    "max_memories_per_query": 10,    # Max memories to inject per conversation
    "memory_importance_threshold": 0.5,  # Minimum importance to store
    "consolidation_interval": "daily",   # When to consolidate memories
    
    # Storage settings
    "memory_ttl": None,              # Time-to-live for memories (None = forever)
    "max_memory_size": 1000,         # Max memories per agent
    "compression_enabled": True      # Compress older memories
}

agent = Agent("assistant", memory_enabled=True, memory_config=memory_config)
```

## Memory Types and Storage

### Memory Categories

#### 1. Episodic Memory
- Conversation summaries and key interactions
- User preferences and patterns
- Important decisions and outcomes
- Temporal context and sequencing

#### 2. Semantic Memory  
- Factual knowledge learned from conversations
- Concepts and relationships
- Domain-specific expertise
- General knowledge updates

#### 3. Procedural Memory
- Successful problem-solving patterns
- Tool usage effectiveness
- Response strategies that worked
- Error patterns to avoid

### Memory Metadata Structure
```python
{
    "content": "Memory content text",
    "embedding": [0.1, 0.2, ...],
    "type": "episodic|semantic|procedural",
    "importance": 0.8,           # 0-1 scale
    "timestamp": "2024-01-01T00:00:00Z",
    "tags": ["conversation", "user_preference"],
    "agent_name": "assistant",
    "session_id": "unique_session_id",
    "related_memories": ["memory_id_1", "memory_id_2"]
}
```

## Implementation Strategy

### Phase 1: Core Infrastructure
- VectorMemory class with Qdrant integration
- Basic embedding model support (sentence-transformers)
- Simple memory storage and retrieval
- Agent class integration

### Phase 2: Enhanced Features  
- Multiple embedding provider support
- Memory consolidation algorithms
- Advanced similarity search
- Memory importance scoring

### Phase 3: Advanced Capabilities
- Cross-agent memory sharing
- Memory graph relationships  
- Automatic memory organization
- Performance optimizations

## Integration with Existing Systems

### StateStorage Compatibility
The memory system will work alongside existing JSON-based conversation storage:

- **Short-term**: JSON files for recent conversation history
- **Long-term**: Qdrant for semantic memory and insights
- **Unified API**: MemoryManager presents single interface to Agent

### Provider Integration
Memory system will use existing provider detection logic:

- Automatically use available API keys for embedding models
- Fallback to local models when APIs unavailable
- Consistent with current provider selection strategy

### Error Handling
Following Praval's robust error handling:

- Graceful degradation when Qdrant unavailable
- Automatic fallback to conversation-only mode  
- Clear error messages with resolution suggestions
- No memory failures should break core Agent functionality

## Performance Considerations

### Embedding Caching
- Local cache for frequently accessed embeddings
- Configurable cache size and TTL
- Background cache warming for active memories

### Query Optimization
- Batch embedding generation
- Qdrant index optimization
- Async memory operations where possible
- Connection pooling and reuse

### Memory Efficiency
- Automatic memory cleanup and archival
- Compression for older memories
- Configurable memory limits per agent
- Efficient vector storage formats

## Privacy and Security

### Data Isolation
- Agent memories isolated by collection
- Optional memory encryption at rest
- Configurable data retention policies
- Memory deletion and cleanup APIs

### Sensitive Information
- Automatic detection of sensitive data patterns
- Configurable filtering of memory content
- Option to disable memory for sensitive agents
- Clear data lineage and audit trails

## Migration Strategy

### Existing Agent Compatibility
- Memory system is opt-in via `memory_enabled` parameter
- Existing agents continue working unchanged
- No breaking changes to current API
- Progressive migration path for existing deployments

### Configuration Migration
- Automatic detection of existing Qdrant instances
- Migration tools for existing vector data
- Backup and restore capabilities
- Version compatibility matrix

This design ensures that Praval's memory system maintains the framework's core philosophy of simplicity while providing powerful semantic memory capabilities for advanced use cases.