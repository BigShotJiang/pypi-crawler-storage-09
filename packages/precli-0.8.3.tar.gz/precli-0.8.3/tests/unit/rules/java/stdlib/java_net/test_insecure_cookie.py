# Copyright 2024 Secure Sauce LLC
# SPDX-License-Identifier: BUSL-1.1
import os

import pytest

from precli.core.level import Level
from precli.parsers import java
from precli.rules import Rule
from tests.unit.rules import test_case


class TestInsecureCookie(test_case.TestCase):
    @classmethod
    def setup_class(cls):
        cls.rule_id = "JAV006"
        cls.parser = java.Java()
        cls.base_path = os.path.join(
            "tests",
            "unit",
            "rules",
            "java",
            "stdlib",
            "java_net",
            "examples",
        )

    def test_rule_meta(self):
        rule = Rule.get_by_id(self.rule_id)
        assert rule.id == self.rule_id
        assert rule.name == "insecure_cookie"
        assert (
            rule.help_url
            == f"https://docs.securesauce.dev/rules/{self.rule_id}"
        )
        assert rule.config.enabled is True
        assert rule.config.level == Level.WARNING
        assert rule.config.rank == -1.0
        assert rule.cwe.id == 614

    @pytest.mark.parametrize(
        "filename",
        [
            "HttpCookieSecureFalse.java",
            "HttpCookieSecureTrue.java",
        ],
    )
    def test(self, filename):
        self.check(filename)
