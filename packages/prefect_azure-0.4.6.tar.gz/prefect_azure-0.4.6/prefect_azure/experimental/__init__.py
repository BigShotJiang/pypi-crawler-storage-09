from .decorators import azure_container_instance

__all__ = ["azure_container_instance"]
