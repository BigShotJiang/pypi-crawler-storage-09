"""Tests for Prefect MCP Server."""
