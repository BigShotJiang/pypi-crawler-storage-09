# Security Policy

## Reporting a Vulnerability

To report a vulnerability in prek, [open a private vulnerability report](https://github.com/j178/prek/security/advisories/new) and you can create a patch on a private fork or, after reporting the problem, our maintainers will fix it as soon as possible.
