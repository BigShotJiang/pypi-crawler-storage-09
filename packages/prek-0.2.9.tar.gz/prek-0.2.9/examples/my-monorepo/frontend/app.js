// Frontend application
console.log("Hello from frontend!");

function init() {
  console.log("App initialized");
}

document.addEventListener("DOMContentLoaded", init);
