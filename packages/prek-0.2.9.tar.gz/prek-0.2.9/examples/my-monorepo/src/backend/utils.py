"""Backend utility functions."""


def helper_function():
    """Backend specific helper."""
    return "backend helper result"
