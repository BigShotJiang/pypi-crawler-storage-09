# __init__.py
from Privacify.main import anonymize_text