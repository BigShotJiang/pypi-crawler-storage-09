# __init__.py
from .main import anonymize_text