from setuptools import setup, find_packages

setup(
    name="prompt-debugger",
    version="0.1.1",  # Changed from 0.1.0
    author="Mohamed Imthiyas",  # Added
    packages=find_packages(),
    python_requires=">=3.8",
)
