# uv run mcp dev src/obsidian_sdk/mcp.py
# TODO 开发mcp 的stdio 格式, 使得MCP 更加好用
# Create an MCP server


