"""Version information for z3adapter package."""

__version__ = "1.0.0"
