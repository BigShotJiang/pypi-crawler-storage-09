"""Quantification modules in proteobench."""
