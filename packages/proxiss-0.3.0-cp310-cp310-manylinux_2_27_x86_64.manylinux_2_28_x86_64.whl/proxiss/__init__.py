from .ProxiFlat import ProxiFlat
from .ProxiKNN import ProxiKNN
