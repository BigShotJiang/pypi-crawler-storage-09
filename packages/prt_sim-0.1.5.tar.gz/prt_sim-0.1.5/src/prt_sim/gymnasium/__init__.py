"""Custom Gymnasium API environments
"""