..
   Note: Items in this toctree form the top-level navigation. See `api.rst` for the `autosummary` directive, and for why `api.rst` isn't called directly.

.. include:: source/home-page.md
   :parser: myst_parser.sphinx_

.. toctree::
   :hidden:
   :caption: API Reference

    prt_sim <_autosummary/prt_sim>

