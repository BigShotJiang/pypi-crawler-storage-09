"""
Common utilities shared across all simulation modules.
"""