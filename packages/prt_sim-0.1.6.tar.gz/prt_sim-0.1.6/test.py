import prt_sim.jhu as jhu

env = jhu.make("PRT-SIM/RobotGame-v0")
print(env)