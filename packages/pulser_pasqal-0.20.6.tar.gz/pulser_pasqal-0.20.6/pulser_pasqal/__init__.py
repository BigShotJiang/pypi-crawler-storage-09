# Copyright 2022 Pulser Development Team
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Classes for interfacing with Pasqal backends."""

from pasqal_cloud import BaseConfig, EmulatorType, Endpoints  # noqa: F401

from pulser_pasqal._version import __version__ as __version__

from pulser_pasqal.backends import (
    EmuFreeBackend,
    EmuFreeBackendV2,
    EmuMPSBackend,
    EmuTNBackend,
)

from pulser_pasqal.ovh import OVHConnection
from pulser_pasqal.pasqal_cloud import PasqalCloud

__all__ = [
    "EmuFreeBackend",
    "EmuFreeBackendV2",
    "EmuTNBackend",
    "PasqalCloud",
    "EmuMPSBackend",
    "OVHConnection",
]
