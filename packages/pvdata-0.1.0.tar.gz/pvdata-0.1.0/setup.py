"""Setup script for pvdata package."""
from setuptools import setup

# All configuration is in pyproject.toml
setup()
