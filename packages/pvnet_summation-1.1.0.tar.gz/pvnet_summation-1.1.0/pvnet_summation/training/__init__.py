"""Training submodule"""
from .lightning_module import PVNetSummationLightningModule
from .train import train
