"""配置模块 - 提供框架默认配置和配置基类"""

from .config_base import Config, settings

__all__ = ["Config", "settings"]