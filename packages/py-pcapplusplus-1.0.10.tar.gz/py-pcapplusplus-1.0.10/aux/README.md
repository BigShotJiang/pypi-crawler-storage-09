These are the docker files used to build the builder images of this package

The built images can be found here:
- x86_64: https://hub.docker.com/r/galr2103/py_pcap_builder_x86_64
- aarch64: https://hub.docker.com/r/galr2103/py_pcap_builder_aarch64
