from py2appsigner._version import __version__
