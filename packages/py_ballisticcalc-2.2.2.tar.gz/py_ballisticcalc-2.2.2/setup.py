#!/usr/bin/env python

"""setup.py script for py_ballisticcalc library"""

from setuptools import setup

setup()
