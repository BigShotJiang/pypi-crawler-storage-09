# -*- encoding: utf-8 -*-
"""
 Created by Ênio Viana at 03/09/2021 at 17:17:38
 Project: py_dss_toolkit [set, 2021]
"""
