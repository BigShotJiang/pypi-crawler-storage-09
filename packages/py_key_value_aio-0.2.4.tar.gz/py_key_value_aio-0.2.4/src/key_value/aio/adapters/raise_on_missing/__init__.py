from key_value.aio.adapters.raise_on_missing.adapter import RaiseOnMissingAdapter

__all__ = ["RaiseOnMissingAdapter"]
