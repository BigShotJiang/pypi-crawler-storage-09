"""DynamoDB key-value store."""

from key_value.aio.stores.dynamodb.store import DynamoDBStore

__all__ = ["DynamoDBStore"]
