from key_value.aio.stores.vault.store import VaultStore

__all__ = ["VaultStore"]
