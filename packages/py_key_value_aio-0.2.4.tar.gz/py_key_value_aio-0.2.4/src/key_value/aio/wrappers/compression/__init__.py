from key_value.aio.wrappers.compression.wrapper import CompressionWrapper

__all__ = ["CompressionWrapper"]
