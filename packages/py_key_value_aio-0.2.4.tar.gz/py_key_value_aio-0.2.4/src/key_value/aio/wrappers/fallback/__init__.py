from key_value.aio.wrappers.fallback.wrapper import FallbackWrapper

__all__ = ["FallbackWrapper"]
