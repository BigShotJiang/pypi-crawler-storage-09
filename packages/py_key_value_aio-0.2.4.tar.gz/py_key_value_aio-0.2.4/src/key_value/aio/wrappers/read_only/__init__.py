from key_value.aio.wrappers.read_only.wrapper import ReadOnlyWrapper

__all__ = ["ReadOnlyWrapper"]
