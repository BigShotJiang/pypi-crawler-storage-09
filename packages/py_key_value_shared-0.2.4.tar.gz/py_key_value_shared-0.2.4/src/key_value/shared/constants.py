DEFAULT_COLLECTION_NAME = "default_collection"
