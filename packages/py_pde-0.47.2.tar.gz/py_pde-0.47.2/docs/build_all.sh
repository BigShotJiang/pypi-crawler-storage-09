#!/bin/sh

make html
make latexpdf
make linkcheck