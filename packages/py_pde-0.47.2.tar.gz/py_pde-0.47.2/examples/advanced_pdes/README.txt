Advanced PDEs
-------------

These examples demonstrate more advanced usage of the package.