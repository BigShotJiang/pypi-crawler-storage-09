Simple PDEs
-----------

These examples demonstrate basic usage of the package to solve PDEs.