#!/usr/bin/env bash

./run_tests.py --types 
