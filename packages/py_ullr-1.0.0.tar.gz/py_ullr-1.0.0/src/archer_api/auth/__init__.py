"""Authentication module."""

from .authenticator import Authenticator

__all__ = ["Authenticator"]