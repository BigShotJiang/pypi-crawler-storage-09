"""Data models for Archer API."""

# Add Pydantic models here as needed

__all__ = []