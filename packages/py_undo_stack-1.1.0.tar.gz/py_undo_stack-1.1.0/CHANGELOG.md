# CHANGELOG


## v1.0.0 (2025-04-14)

### Features

- First working implementation
  ([`4348c1e`](https://github.com/KitwareMedical/py-undo-stack/commit/4348c1e7d0e7296e1c53a54275b1e4e3e093dcb6))
