"""Init file for airstage_api"""

name = "pyairstage"
