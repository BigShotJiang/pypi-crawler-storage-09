from .core import Device

__all__ = ['Device']  # Optional but recommended for clarity