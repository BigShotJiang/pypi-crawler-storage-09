"""
ArguMint - Completion Script Generator
======================================
File ini menghasilkan skrip auto-completion untuk:
  - Bash
  - Zsh
  - Fish

Tujuan: mempermudah pengguna CLI agar dapat menekan TAB
untuk melengkapi argumen atau subcommand.
"""

def generate_completion(spec: dict, shell: str = "bash", prog: str = "program"):
    """
    Generate skrip auto-completion untuk shell yang dipilih.

    Parameters
    ----------
    spec : dict
        Struktur berisi daftar opsi dan subcommand.
    shell : str
        Jenis shell: "bash", "zsh", atau "fish".
    prog : str
        Nama program CLI utama.
    """
    if shell == "bash":
        return _bash(spec, prog)
    elif shell == "zsh":
        return _zsh(spec, prog)
    elif shell == "fish":
        return _fish(spec, prog)
    else:
        raise ValueError("Shell tidak didukung (gunakan: bash, zsh, atau fish)")


def _bash(spec, prog):
    options = " ".join(spec.get("options", []))
    subcommands = " ".join(spec.get("subcommands", {}).keys())

    return f"""# bash completion for {prog}
_{prog}_complete() {{
    local cur prev words cword
    _init_completion -n : || return

    case ${{COMP_WORDS[1]}} in
{sub_block(spec)}
    esac
}}

complete -F _{prog}_complete {prog}
"""

def sub_block(spec):
    lines = []
    for sub, opts in spec.get("subcommands", {}).items():
        joined = " ".join(opts)
        lines.append(f"""  {sub})
      COMPREPLY=( $(compgen -W "{joined}" -- "$cur") )
      return 0;;
""")
    opts = " ".join(spec.get("options", []))
    subs = " ".join(spec.get("subcommands", {}).keys())
    lines.append(f"""  *)
      COMPREPLY=( $(compgen -W "{opts} {subs}" -- "$cur") )
      return 0;;
""")
    return "".join(lines)


def _zsh(spec, prog):
    opts = " ".join([f'"{opt}[option]":' for opt in spec.get("options", [])])
    subcmds = " ".join(spec.get("subcommands", {}).keys())

    return f"""#compdef {prog}
_arguments -s \\
  {opts} \\
  "1: :({subcmds})"
"""


def _fish(spec, prog):
    lines = [f"# fish completion for {prog}"]
    for opt in spec.get("options", []):
        if opt.startswith("--"):
            lines.append(f"complete -c {prog} -l {opt[2:]} -d 'Argumen opsional'")
        elif opt.startswith("-"):
            lines.append(f"complete -c {prog} -s {opt[1:]} -d 'Argumen singkat'")
    for sub in spec.get("subcommands", {}).keys():
        lines.append(f"complete -c {prog} -a {sub} -d 'Subcommand {sub}'")
    return "\n".join(lines)
