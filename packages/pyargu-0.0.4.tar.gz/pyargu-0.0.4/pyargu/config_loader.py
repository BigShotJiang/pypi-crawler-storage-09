import os
import json
from configparser import ConfigParser

try:
    import yaml
except ImportError:
    yaml = None

try:
    import tomllib  # Python 3.11+
except ImportError:
    tomllib = None


class ConfigLoader:
    """
    Loader file konfigurasi universal untuk ArguMint.
    Mendukung: JSON, YAML, TOML, dan INI.
    """

    @staticmethod
    def load(path: str) -> dict:
        """Membaca file konfigurasi dan mengembalikan hasil sebagai dictionary."""
        if not os.path.exists(path):
            raise FileNotFoundError(f"File konfigurasi '{path}' tidak ditemukan")

        ext = os.path.splitext(path)[1].lower()

        with open(path, "rb") as f:
            data = f.read()

        if ext == ".json":
            return json.loads(data.decode("utf-8"))

        elif ext in (".yml", ".yaml"):
            if not yaml:
                raise ImportError("PyYAML belum terpasang. Install dengan: pip install pyyaml")
            return yaml.safe_load(data.decode("utf-8"))

        elif ext == ".toml":
            if not tomllib:
                raise ImportError("TOML tidak didukung. Gunakan Python 3.11+ atau install tomli.")
            return tomllib.loads(data.decode("utf-8"))

        elif ext == ".ini":
            parser = ConfigParser()
            parser.read_string(data.decode("utf-8"))
            config = {}
            for section in parser.sections():
                config[section] = dict(parser.items(section))
            return config

        else:
            raise ValueError(f"Format file konfigurasi '{ext}' tidak dikenali")
