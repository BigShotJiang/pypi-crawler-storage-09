from datetime import datetime
from .colors import Colors as C


class ParseError(SystemExit):
    """
    Error utama untuk ArguMint CLI.
    Menampilkan pesan berwarna, mencatat waktu kejadian,
    dan menampilkan mini dashboard error di terminal.
    """

    def __init__(self, message, code=2):
        self.timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.message = message
        self.code = code
        self._display()
        super().__init__(code)

    def _display(self):
        line = "=" * (len(self.message) + 10)
        print()
        print(C.c(line, C.RED))
        print(C.c("===   CLI ERROR   ===", C.BOLD))
        print(C.c(line, C.RED))
        print(C.c(f"• Waktu   :", C.YELLOW), self.timestamp)
        print(C.c(f"• Pesan   :", C.YELLOW), self.message)
        print(C.c(f"• Kode    :", C.YELLOW), self.code)
        print(C.c(line, C.RED))
        print()
