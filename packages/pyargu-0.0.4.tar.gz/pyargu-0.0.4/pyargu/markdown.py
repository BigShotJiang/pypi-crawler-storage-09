from datetime import datetime


def export_markdown(parser, filename: str = "HELP.md"):
    """
    Mengekspor dokumentasi CLI ke file Markdown berdasarkan struktur parser.

    Parameters
    ----------
    parser : ArgumentParser
        Instance parser utama yang berisi semua argumen dan subcommand.
    filename : str
        Nama file output Markdown (default: HELP.md)
    """
    with open(filename, "w", encoding="utf-8") as f:
        f.write(f"# {parser.__class__.__name__} Help\n\n")
        f.write(f"**Generated on:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")

        if parser.description:
            f.write(f"## Deskripsi\n\n{parser.description}\n\n")

        if parser.arguments:
            f.write("## Opsi Utama\n\n")
            for name, arg in parser.arguments.items():
                f.write(f"- **--{name}**\n")
                if arg.help:
                    f.write(f"  - Deskripsi: {arg.help}\n")
                f.write(f"  - Jenis: `{arg.arg_type.__name__}`\n")
                if arg.default is not None:
                    f.write(f"  - Default: `{arg.default}`\n")
                if arg.choices:
                    f.write(f"  - Pilihan: {', '.join(map(str, arg.choices))}\n")
                f.write("\n")

        if parser.subcommands:
            f.write("## Subcommands\n\n")
            for name, sub in parser.subcommands.items():
                f.write(f"### `{name}` — {sub.description}\n\n")
                if sub.arguments:
                    for aname, a in sub.arguments.items():
                        f.write(f"- **--{aname}**\n")
                        if a.help:
                            f.write(f"  - Deskripsi: {a.help}\n")
                        f.write(f"  - Jenis: `{a.arg_type.__name__}`\n")
                        if a.default is not None:
                            f.write(f"  - Default: `{a.default}`\n")
                        if a.choices:
                            f.write(f"  - Pilihan: {', '.join(map(str, a.choices))}\n")
                        f.write("\n")

    return filename