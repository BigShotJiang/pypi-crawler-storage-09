import os
import sys
import json
import asyncio
from datetime import datetime
from .colors import Colors as C
from .errors import ParseError
from .config_loader import ConfigLoader
from .schema import SchemaGenerator
from .ui import UI
from .plugins import load_all_plugins


class Argument:
    """Mendefinisikan satu argumen CLI (flag, opsi, atau nilai)."""

    def __init__(
        self,
        name,
        short=None,
        help="",
        takes_value=True,
        required=False,
        default=None,
        arg_type=str,
        interactive=False,
        choices=None,
        validators=None,
    ):
        self.name = name
        self.short = short
        self.help = help
        self.takes_value = takes_value
        self.required = required
        self.default = default() if callable(default) else default
        self.arg_type = arg_type
        self.interactive = interactive
        self.choices = choices
        self.validators = validators or []

    def convert(self, raw):
        """Konversi string CLI ke tipe yang diinginkan dan validasi nilai."""
        try:
            value = self.arg_type(raw)
        except Exception as e:
            raise ValueError(f"gagal mengonversi '{raw}' ke {self.arg_type.__name__}: {e}")

        if self.choices and value not in self.choices:
            raise ValueError(f"'{value}' bukan salah satu dari {self.choices}")

        for validator in self.validators:
            value = validator(value)

        return value


class PluginManager:
    """Mengelola hook plugin (before_parse, after_parse, on_error)."""

    def __init__(self):
        self.hooks = {"before_parse": [], "after_parse": [], "on_error": []}

    def register(self, hook, func):
        if hook not in self.hooks:
            raise ValueError(f"Hook '{hook}' tidak dikenali")
        self.hooks[hook].append(func)

    def run(self, hook, *args, **kwargs):
        for func in self.hooks.get(hook, []):
            try:
                func(*args, **kwargs)
            except Exception as e:
                print(f"[Plugin Error] {hook}: {e}")


class ArgumentParser:
    """Parser utama ArguMint CLI."""

    def __init__(self, description=""):
        self.description = description
        self.arguments = {}
        self.subcommands = {}
        self.handlers = {}
        self.plugins = PluginManager()
        self.env_prefix = "ARGU"

        # Autoload semua plugin di folder argumint/plugins
        load_all_plugins(self)

    # ----------------------------------------------------
    # =============== ARGUMENT MANAGEMENT ================
    # ----------------------------------------------------

    def add_argument(self, *args, **kwargs):
        """Tambahkan argumen ke parser utama."""
        arg = Argument(*args, **kwargs)
        self.arguments[arg.name] = arg
        return arg

    def add_subcommand(self, name, description="", handler=None):
        """Tambahkan subcommand dengan handler opsional."""
        sub = ArgumentParser(description)
        self.subcommands[name] = sub
        if handler:
            self.handlers[name] = handler
        return sub

    # ----------------------------------------------------
    # ================= CORE PARSING =====================
    # ----------------------------------------------------

    def parse_args(self, argv=None):
        """Parse argumen CLI."""
        if argv is None:
            argv = sys.argv[1:]

        self.plugins.run("before_parse", self)

        if not argv or argv[0] in ("--help", "-h"):
            self.print_help()
            sys.exit(0)

        try:
            if argv[0] in self.subcommands:
                sub = self.subcommands[argv[0]]
                args = sub._parse_level(argv[1:], sub.arguments)
                self.plugins.run("after_parse", sub, args)
                handler = self.handlers.get(argv[0])
                if handler:
                    res = handler(args)
                    if asyncio.iscoroutine(res):
                        asyncio.run(res)
                return args
            else:
                args = self._parse_level(argv, self.arguments)
                self.plugins.run("after_parse", self, args)
                return args
        except Exception as e:
            self.plugins.run("on_error", self, str(e))
            UI.error_dashboard(str(e))
            raise ParseError(str(e))

    def _parse_level(self, argv, space):
        """Fungsi parsing inti untuk level argumen tertentu (utama / subcommand)."""
        values = {n: a.default for n, a in space.items()}
        i = 0
        while i < len(argv):
            token = argv[i]
            if token.startswith("--"):
                key = token[2:]
                if key not in space:
                    raise ParseError(f"Argumen '{token}' tidak dikenali.")
                arg = space[key]
                if not arg.takes_value:
                    values[arg.name] = True
                    i += 1
                    continue
                if i + 1 >= len(argv):
                    raise ParseError(f"Argumen '{token}' memerlukan nilai.")
                raw = argv[i + 1]
                values[arg.name] = arg.convert(raw)
                i += 2

            elif token == "--config":
                if i + 1 >= len(argv):
                    raise ParseError("--config memerlukan file konfigurasi.")
                cfg_path = argv[i + 1]
                config_data = ConfigLoader.load(cfg_path)
                for k, v in config_data.items():
                    if k in space:
                        arg = space[k]
                        values[k] = arg.convert(v)
                i += 2

            elif token == "--schema":
                SchemaGenerator.generate(space)
                print(C.c("Schema JSON berhasil dibuat: schema.json", C.GREEN))
                sys.exit(0)

            else:
                i += 1

        # Validasi required & interactive
        for n, a in space.items():
            if a.required and not values.get(n):
                if a.interactive:
                    values[n] = a.convert(input(C.c(f"Masukkan nilai untuk --{n}: ", C.YELLOW)))
                else:
                    raise ParseError(f"Argumen --{n} wajib diisi.")

        return values

    # ----------------------------------------------------
    # ==================== HELP SYSTEM ===================
    # ----------------------------------------------------

    def print_help(self):
        """Menampilkan bantuan CLI penuh warna."""
        print(C.c("Usage:", C.CYAN), "program [options] [subcommand]")
        print()
        if self.description:
            print(self.description)
            print()
        if self.arguments:
            print(C.c("Options:", C.YELLOW))
            for n, a in self.arguments.items():
                line = f"  --{n:<12} {a.help or ''}"
                if a.default is not None:
                    line += f" (default: {a.default})"
                if a.choices:
                    line += f" [choices: {', '.join(map(str, a.choices))}]"
                print(line)
            print()
        if self.subcommands:
            print(C.c("Subcommands:", C.MAGENTA))
            for n, s in self.subcommands.items():
                print(f"  {n:<12} {s.description}")
            print()

    # ----------------------------------------------------
    # ==================== UTILITIES =====================
    # ----------------------------------------------------

    def export_schema(self, output="schema.json"):
        """Ekspor JSON Schema dari argumen CLI."""
        return SchemaGenerator.generate(self.arguments, output)

    def export_help_markdown(self, output="HELP.md"):
        """Ekspor dokumentasi CLI ke file Markdown."""
        from .markdown import export_markdown

        export_markdown(self, output)
        print(C.c(f"Dokumentasi CLI berhasil diekspor ke {output}", C.GREEN))

    def build_completion(self, shell="bash"):
        """Generate skrip completion (bash/zsh/fish)."""
        from .completion import generate_completion

        spec = {
            "options": [f"--{n}" for n in self.arguments],
            "subcommands": {k: [f"--{a}" for a in s.arguments] for k, s in self.subcommands.items()},
        }
        result = generate_completion(spec, shell=shell, prog=os.path.basename(sys.argv[0]))
        filename = f"{os.path.basename(sys.argv[0])}.{shell}"
        with open(filename, "w", encoding="utf-8") as f:
            f.write(result)
        print(C.c(f"Skrip auto-completion disimpan ke {filename}", C.GREEN))
