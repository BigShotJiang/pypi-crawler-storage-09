"""
ArguMint Plugin System
======================
Setiap file Python di dalam folder ini merupakan plugin
yang dapat diinisialisasi secara otomatis oleh parser utama.

Plugin standar bawaan:
- logging_plugin.py   → Pencatatan log otomatis
- telemetry_plugin.py → Pencatatan data statistik penggunaan CLI
"""

import importlib
import pkgutil


def load_all_plugins(parser):
    """
    Memuat semua plugin yang tersedia di direktori argumint/plugins/.
    Tiap plugin wajib memiliki fungsi `init(parser)`.
    """
    package = __name__
    for _, name, ispkg in pkgutil.iter_modules(__path__, package + "."):
        if not ispkg:
            module = importlib.import_module(name)
            if hasattr(module, "init"):
                try:
                    module.init(parser)
                except Exception as e:
                    print(f"[Plugin Error] Gagal memuat {name}: {e}")