"""
ArguMint Plugin — Logging System
================================
Plugin ini mencatat semua aktivitas CLI ke dalam file log harian.
Log disimpan di direktori:
    ~/.argumint/logs/YYYY-MM-DD.log
"""

import os
import json
from datetime import datetime
from pathlib import Path

LOG_DIR = os.path.expanduser("~/.argumint/logs")


def init(parser):
    """Inisialisasi plugin logging dan daftarkan ke sistem hook parser."""

    os.makedirs(LOG_DIR, exist_ok=True)
    log_file = Path(LOG_DIR) / (datetime.now().strftime("%Y-%m-%d") + ".log")

    def before(_, __=None):
        with open(log_file, "a", encoding="utf-8") as f:
            f.write(f"[{datetime.now().strftime('%H:%M:%S')}] Start CLI session\n")

    def after(_, args):
        with open(log_file, "a", encoding="utf-8") as f:
            f.write(f"[{datetime.now().strftime('%H:%M:%S')}] Args: {json.dumps(args, ensure_ascii=False)}\n")
            f.write(f"[{datetime.now().strftime('%H:%M:%S')}] Session Ended\n\n")

    def on_error(_, err):
        with open(log_file, "a", encoding="utf-8") as f:
            f.write(f"[{datetime.now().strftime('%H:%M:%S')}] ERROR: {err}\n")

    # Registrasi hook
    parser.plugins.register("before_parse", before)
    parser.plugins.register("after_parse", after)
    parser.plugins.register("on_error", on_error)
