"""
ArguMint Plugin — Telemetry System
==================================
Plugin ini merekam data statistik CLI (telemetri ringan) secara lokal.
Semua data disimpan dalam file JSON di:
    ~/.argumint/telemetry.json

Format data:
[
  {
    "timestamp": "2025-10-19T21:11:30",
    "args": {"mode": "fast", "verbose": true},
    "duration": 0.0134
  }
]
"""

import os
import json
import time
from datetime import datetime

TELEMETRY_FILE = os.path.expanduser("~/.argumint/telemetry.json")


def init(parser):
    """Inisialisasi plugin telemetry dan daftarkan ke hook after_parse."""

    def after(_, args):
        start_time = time.process_time()
        entry = {
            "timestamp": datetime.now().isoformat(),
            "args": args,
            "duration": round(time.process_time() - start_time, 5),
        }

        # Baca data lama (maksimal 100 entri)
        data = []
        if os.path.exists(TELEMETRY_FILE):
            try:
                with open(TELEMETRY_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
            except Exception:
                data = []

        # Tambahkan data baru
        data.append(entry)
        data = data[-100:]  # Simpan hanya 100 entri terakhir

        # Tulis ulang file telemetry
        os.makedirs(os.path.dirname(TELEMETRY_FILE), exist_ok=True)
        with open(TELEMETRY_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

    parser.plugins.register("after_parse", after)
