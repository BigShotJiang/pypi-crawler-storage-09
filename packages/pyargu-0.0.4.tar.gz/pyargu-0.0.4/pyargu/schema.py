import json
from datetime import datetime


class SchemaGenerator:
    """
    Menghasilkan JSON Schema dari definisi argumen CLI.
    Dapat digunakan untuk validasi file konfigurasi.
    """

    @staticmethod
    def generate(arguments: dict, output: str = "schema.json") -> str:
        """
        Menghasilkan file JSON Schema dari dictionary `arguments`.

        Parameters:
        ----------
        arguments : dict
            Dictionary berisi daftar argumen dari parser.
        output : str
            Nama file output schema. Default = "schema.json"

        Returns:
        -------
        str
            Path ke file schema yang dihasilkan.
        """

        schema = {
            "$schema": "https://json-schema.org/draft/2020-12/schema",
            "title": "ArguMint CLI Schema",
            "description": "Schema hasil generate otomatis dari ArguMint CLI",
            "generated_at": datetime.now().isoformat(),
            "type": "object",
            "properties": {},
            "required": [],
        }

        for name, arg in arguments.items():
            prop = {
                "description": arg.help or "",
                "type": SchemaGenerator._map_type(arg.arg_type),
            }

            if arg.default is not None:
                prop["default"] = arg.default

            if arg.choices:
                prop["enum"] = list(arg.choices)

            schema["properties"][name] = prop

            if arg.required:
                schema["required"].append(name)

        with open(output, "w", encoding="utf-8") as f:
            json.dump(schema, f, indent=2, ensure_ascii=False)

        return output

    @staticmethod
    def _map_type(py_type) -> str:
        """Konversi tipe Python ke JSON Schema type."""
        if py_type in (int, float):
            return "number"
        elif py_type is bool:
            return "boolean"
        elif py_type is list:
            return "array"
        elif py_type.__name__.lower() == "path":
            return "string"
        return "string"
