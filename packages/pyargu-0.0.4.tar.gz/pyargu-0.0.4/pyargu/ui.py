import sys
import time
from .colors import Colors as C


class UI:
    """
    Text-based User Interface (TUI) untuk ArguMint CLI.
    Semua komponen menggunakan ANSI murni agar tetap ringan dan kompatibel lintas platform.
    """

    @staticmethod
    def banner(title: str):
        """Menampilkan banner besar berwarna cyan."""
        line = "=" * (len(title) + 8)
        print(C.c(line, C.CYAN))
        print(C.c(f"===  {title}  ===", C.BOLD))
        print(C.c(line, C.CYAN))

    @staticmethod
    def status(message: str, color=C.GREEN):
        """Menampilkan status dengan bullet berwarna."""
        print(C.c("•", color), message)

    @staticmethod
    def progress(task: str, total: int, delay: float = 0.05):
        """Menampilkan progress bar horizontal dengan persentase."""
        print(C.c(f"[{task}]", C.YELLOW))
        for i in range(total + 1):
            bar = "#" * (i * 40 // total)
            sys.stdout.write(f"\r{C.c('Progress:', C.CYAN)} [{bar:<40}] {i*100//total}%")
            sys.stdout.flush()
            time.sleep(delay)
        print("\n" + C.c("✓ Selesai!", C.GREEN))

    @staticmethod
    def table(headers, rows):
        """
        Menampilkan tabel berwarna dengan header.
        headers: list kolom
        rows: list of list isi tabel
        """
        widths = [max(len(str(col)) for col in column) for column in zip(headers, *rows)]
        line = "+".join("-" * (w + 2) for w in widths)
        print(C.c(line, C.CYAN))
        print("| " + " | ".join(f"{headers[i]:<{widths[i]}}" for i in range(len(headers))) + " |")
        print(C.c(line, C.CYAN))
        for row in rows:
            print("| " + " | ".join(f"{str(row[i]):<{widths[i]}}" for i in range(len(row))) + " |")
        print(C.c(line, C.CYAN))

    @staticmethod
    def spinner(task: str, duration: float = 2):
        """Menampilkan animasi spinner sederhana selama `duration` detik."""
        import itertools
        spinner = itertools.cycle(["-", "\\", "|", "/"])
        sys.stdout.write(C.c(f"{task} ", C.YELLOW))
        sys.stdout.flush()
        for _ in range(int(duration * 10)):
            sys.stdout.write(next(spinner))
            sys.stdout.flush()
            time.sleep(0.1)
            sys.stdout.write("\b")
        print(C.c("✓", C.GREEN))

    @staticmethod
    def error_dashboard(message: str):
        """Menampilkan dashboard error penuh warna."""
        line = "=" * (len(message) + 10)
        print(C.c(line, C.RED))
        print(C.c("===     CLI ERROR     ===", C.BOLD))
        print(C.c(line, C.RED))
        print(C.c("• Pesan:", C.YELLOW), message)
        print(C.c(line, C.RED))
        print()
