import difflib
import json
from datetime import datetime


def levenshtein_suggestion(word, candidates):
    """
    Berikan saran otomatis (suggestion) jika pengguna salah ketik argumen CLI.
    Menggunakan algoritma fuzzy matching bawaan difflib.
    """
    matches = difflib.get_close_matches(word, candidates, n=1, cutoff=0.6)
    return matches[0] if matches else None


def now_default():
    """Menghasilkan nilai waktu sekarang untuk default argumen dinamis."""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def pretty_json(data):
    """Format dictionary atau list ke JSON yang mudah dibaca."""
    return json.dumps(data, indent=2, ensure_ascii=False)


def pad(text, width=20):
    """Merapikan kolom teks agar rata saat ditampilkan dalam tabel CLI."""
    return str(text).ljust(width)


def safe_call(func, *args, **kwargs):
    """
    Jalankan fungsi dengan aman tanpa memunculkan exception fatal.
    Mengembalikan None jika terjadi error.
    """
    try:
        return func(*args, **kwargs)
    except Exception:
        return None


def human_size(num, suffix="B"):
    """Ubah ukuran byte menjadi format manusia (KB, MB, GB, dst)."""
    for unit in ["", "K", "M", "G", "T", "P", "E", "Z"]:
        if abs(num) < 1024.0:
            return f"{num:3.1f}{unit}{suffix}"
        num /= 1024.0
    return f"{num:.1f}Y{suffix}"
