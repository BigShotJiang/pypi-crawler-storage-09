from pathlib import Path


class Range:
    """Validator untuk memastikan nilai numerik berada dalam rentang tertentu."""

    def __init__(self, min=None, max=None):
        self.min = min
        self.max = max

    def __call__(self, value):
        if self.min is not None and value < self.min:
            raise ValueError(f"Nilai harus >= {self.min}")
        if self.max is not None and value > self.max:
            raise ValueError(f"Nilai harus <= {self.max}")
        return value


class OneOf:
    """Validator untuk memastikan nilai termasuk dalam daftar tertentu."""

    def __init__(self, choices):
        self.choices = list(choices)

    def __call__(self, value):
        if value not in self.choices:
            raise ValueError(f"Nilai harus salah satu dari {self.choices}")
        return value


class Exists:
    """Validator untuk memastikan path file atau direktori ada."""

    def __call__(self, value):
        p = Path(value)
        if not p.exists():
            raise ValueError(f"File atau direktori '{value}' tidak ditemukan")
        return p


class IsFile:
    """Validator untuk memastikan path mengarah ke file."""

    def __call__(self, value):
        p = Path(value)
        if not p.is_file():
            raise ValueError(f"'{value}' bukan file yang valid")
        return p


class IsDir:
    """Validator untuk memastikan path mengarah ke direktori."""

    def __call__(self, value):
        p = Path(value)
        if not p.is_dir():
            raise ValueError(f"'{value}' bukan direktori yang valid")
        return p
