from setuptools import setup, find_packages

setup(
    name="pyargu",
    version="0.0.4",
    author="Athallah Rajendra Putra Juniarto",
    author_email="athallahwork50@gmail.com",
    description="Parser CLI Python buatan sendiri dengan fitur lengkap: UI, Logging, Telemetry, Config, Schema, dan Plugin.",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/athallah-rp/ArguMint",
    packages=find_packages(),
    python_requires=">=3.13",
    include_package_data=True,
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries",
        "Topic :: Utilities",
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    keywords="cli parser argument command terminal ui logging telemetry python argparse click typer",
)
