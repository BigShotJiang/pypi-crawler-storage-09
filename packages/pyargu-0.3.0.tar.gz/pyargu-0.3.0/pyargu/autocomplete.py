import os

def enable_autocomplete(script_name):
    """
    Mengaktifkan auto-completion untuk bash/zsh.
    Menulis script completion ke ~/.myargparser_autocomplete.sh
    """
    completion_script = f"""
# Auto-completion untuk {script_name}
_{script_name}_completion()
{{
    COMPREPLY=()
    local curr_word prev_word
    curr_word="${{COMP_WORDS[COMP_CWORD]}}"
    prev_word="${{COMP_WORDS[COMP_CWORD-1]}}"
    local options=$(python3 {script_name} --_complete ${{COMP_WORDS[@]}})
    COMPREPLY=( $(compgen -W "$options" -- $curr_word) )
}}
complete -F _{script_name}_completion {script_name}
"""

    path = os.path.expanduser("~/.myargparser_autocomplete.sh")
    with open(path, "w", encoding="utf-8") as f:
        f.write(completion_script)
    print(f"✅ Auto-completion ditulis ke {path}")
    print("➡️  Tambahkan ini ke ~/.bashrc atau ~/.zshrc:")
    print(f"   source {path}")
