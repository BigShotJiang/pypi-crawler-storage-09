from .errors import CommandError

class Command:
    """Representasi subcommand, seperti 'git commit'."""

    def __init__(self, name, description="", handler=None):
        self.name = name
        self.description = description
        self.handler = handler
        self.parser = None
        self.subcommands = {}

    def set_parser(self, parser):
        """Kaitkan parser ke command ini."""
        self.parser = parser

    def add_subcommand(self, name, description="", handler=None):
        """Tambahkan subcommand bertingkat (misal: git remote add)."""
        cmd = Command(name, description, handler)
        self.subcommands[name] = cmd
        return cmd

    def execute(self, args):
        """Jalankan command."""
        if "subcommand" in args and args["subcommand"] in self.subcommands:
            sub = self.subcommands[args["subcommand"]]
            if sub.parser:
                sub_args = sub.parser.parse_args(args.get("_extra_args", []))
                return sub.execute(sub_args)
            else:
                return sub.execute({})
        if self.handler is None:
            raise CommandError(f"Tidak ada handler untuk subcommand '{self.name}'")
        return self.handler(args)
