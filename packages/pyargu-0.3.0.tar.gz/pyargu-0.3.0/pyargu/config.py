import os
import json
from .utils import safe_read_file, safe_write_file

class ConfigManager:
    """Mengelola file konfigurasi .myargparserrc"""

    def __init__(self, filename=".myargparserrc"):
        self.path = os.path.expanduser(f"~/{filename}")
        self.data = {}
        self.load()

    def load(self):
        """Membaca file konfigurasi dari home user."""
        content = safe_read_file(self.path)
        if not content:
            self.data = {}
            return
        try:
            self.data = json.loads(content)
        except Exception:
            self.data = {}

    def save(self):
        """Simpan konfigurasi ke file JSON."""
        safe_write_file(self.path, json.dumps(self.data, indent=4))

    def get(self, key, default=None):
        return self.data.get(key, default)

    def set(self, key, value):
        self.data[key] = value
        self.save()
