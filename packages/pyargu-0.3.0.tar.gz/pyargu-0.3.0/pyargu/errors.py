class ParseError(Exception):
    """Kesalahan umum saat parsing argumen."""
    pass

class CommandError(Exception):
    """Kesalahan saat menjalankan subcommand."""
    pass
