import sys
from .errors import ParseError
from .command import Command
from .utils import print_colored

class Argument:
    def __init__(self, name, short=None, help="", required=False, default=None,
                 takes_value=False, arg_type=str, choices=None, multiple=False):
        self.name = name
        self.short = short
        self.help = help
        self.required = required
        self.default = default
        self.takes_value = takes_value
        self.arg_type = arg_type
        self.choices = choices
        self.multiple = multiple

class ArgumentParser:
    def __init__(self, description=""):
        self.description = description
        self.arguments = []
        self.commands = {}
        self.parsed_args = {}

    def add_argument(self, name, short=None, help="", required=False, default=None,
                     takes_value=False, arg_type=str, choices=None, multiple=False):
        arg = Argument(name, short, help, required, default, takes_value, arg_type, choices, multiple)
        self.arguments.append(arg)

    def add_command(self, name, description="", handler=None):
        cmd = Command(name, description, handler)
        self.commands[name] = cmd
        return cmd

    def parse_args(self, args=None):
        if args is None:
            args = sys.argv[1:]

        # Mode auto-completion
        if "--_complete" in args:
            print(" ".join(self._autocomplete(args)))
            sys.exit(0)

        if len(args) > 0 and args[0] in self.commands:
            cmd_name = args[0]
            cmd = self.commands[cmd_name]
            sub_args = args[1:]
            if cmd.parser:
                parsed = cmd.parser.parse_args(sub_args)
                return cmd.execute(parsed)
            else:
                return cmd.execute({})
        
        parsed = {}
        i = 0
        while i < len(args):
            token = args[i]

            if token.startswith("--"):
                name = token[2:]
                arg = self._find_argument(name=name)
                if arg is None:
                    raise ParseError(f"Tidak dikenal: --{name}")
                if arg.takes_value:
                    if i + 1 >= len(args):
                        raise ParseError(f"Argumen --{name} membutuhkan nilai.")
                    value = args[i + 1]
                    parsed[arg.name] = self._convert_value(arg, value)
                    i += 2
                else:
                    parsed[arg.name] = True
                    i += 1

            elif token.startswith("-"):
                short = token[1:]
                arg = self._find_argument(short=short)
                if arg is None:
                    raise ParseError(f"Tidak dikenal: -{short}")
                if arg.takes_value:
                    if i + 1 >= len(args):
                        raise ParseError(f"Argumen -{short} membutuhkan nilai.")
                    value = args[i + 1]
                    parsed[arg.name] = self._convert_value(arg, value)
                    i += 2
                else:
                    parsed[arg.name] = True
                    i += 1
            else:
                raise ParseError(f"Argumen tidak valid: {token}")

        for arg in self.arguments:
            if arg.name not in parsed:
                if arg.required:
                    raise ParseError(f"Argumen wajib belum diberikan: --{arg.name}")
                parsed[arg.name] = arg.default

        self.parsed_args = parsed
        return parsed

    def _find_argument(self, name=None, short=None):
        for arg in self.arguments:
            if name and arg.name == name:
                return arg
            if short and arg.short == short:
                return arg
        return None

    def _convert_value(self, arg, value):
        try:
            if arg.multiple:
                return [arg.arg_type(v) for v in value.split(",")]
            val = arg.arg_type(value)
            if arg.choices and val not in arg.choices:
                raise ParseError(f"Nilai '{val}' tidak valid untuk --{arg.name}. Pilihan: {arg.choices}")
            return val
        except Exception as e:
            raise ParseError(f"Kesalahan konversi pada --{arg.name}: {e}")

    def print_help(self):
        print_colored(f"\n{self.description}\n", "cyan")
        print_colored("Argumen:", "yellow")
        for arg in self.arguments:
            short = f"-{arg.short}, " if arg.short else ""
            required = "(wajib)" if arg.required else ""
            takes_value = "=VALUE" if arg.takes_value else ""
            default = f"(default: {arg.default})" if arg.default is not None else ""
            print(f"  {short}--{arg.name}{takes_value}\t{arg.help} {required} {default}")
        if self.commands:
            print_colored("\nSubcommands:", "yellow")
            for cmd_name, cmd in self.commands.items():
                print(f"  {cmd_name}\t{cmd.description}")
        print()

    def _autocomplete(self, args):
        completions = [f"--{arg.name}" for arg in self.arguments]
        completions.extend(self.commands.keys())
        return completions
