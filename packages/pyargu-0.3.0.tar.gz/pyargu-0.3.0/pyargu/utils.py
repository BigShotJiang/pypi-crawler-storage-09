import sys
import os

def color_text(text, color="reset"):
    """Warna ANSI sederhana untuk teks terminal."""
    colors = {
        "reset": "\033[0m",
        "red": "\033[91m",
        "green": "\033[92m",
        "yellow": "\033[93m",
        "blue": "\033[94m",
        "cyan": "\033[96m",
        "magenta": "\033[95m",
        "bold": "\033[1m",
    }
    return f"{colors.get(color, colors['reset'])}{text}{colors['reset']}"

def print_colored(msg, color="reset", end="\n"):
    sys.stdout.write(color_text(msg, color) + end)

def safe_read_file(path):
    if not os.path.exists(path):
        return None
    with open(path, "r", encoding="utf-8") as f:
        return f.read()

def safe_write_file(path, content):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
