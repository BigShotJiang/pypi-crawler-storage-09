from setuptools import setup, find_packages

setup(
    name="pyargu",
    version="0.3.0",
    description="Custom argument parser buatan tangan lengkap dengan subcommand dan validasi tipe.",
    author="ATHALLAH RAJENDRA PUTRA JUNIARTO",
    packages=find_packages(),
    python_requires=">=3.7",
    license="MIT",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
        "Topic :: Software Development :: Libraries",
    ],
)
