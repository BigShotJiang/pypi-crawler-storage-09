from setuptools import setup

# This is the magic that tells setuptools to read its configuration
# from pyproject.toml and setup.cfg.
setup()
