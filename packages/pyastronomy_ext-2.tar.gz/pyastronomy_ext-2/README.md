# PyAstronomy

What is it?
-----------

    Extension for PyAstronomy

Installation
------------

  To install the latest release via pip from PyPI use
  
    pip install PyAstronomy-ext
    
  or
  
    pip install git+https://github.com/sczesla/PyAstronomy-ext.git
    

Documentation and further information
-------------------------------------

  View the latest documentation for PyAstronomy on [Read the
  Docs](https://pyastronomy.readthedocs.org/en/latest/)

  Visit the documentation of the latest release:
  
  http://www.hs.uni-hamburg.de/DE/Ins/Per/Czesla/PyA/PyA/index.html

Licensing
---------

  Where not stated otherwise, PyAstronomy is released under the
  MIT license (see also documentation).

