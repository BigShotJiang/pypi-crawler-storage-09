# BADS subpackage developing notes

These notes are used for keeping track of ToDos and porting information.

* Support for periodic variables
* Benchmark PyBADS on cognitive and neural science models ([neurobench](https://github.com/lacerbi/neurobench))
