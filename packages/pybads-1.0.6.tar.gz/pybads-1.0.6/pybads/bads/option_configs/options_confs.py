import os

def get_pybads_option_dir_path():
    return os.path.dirname(os.path.realpath(__file__))