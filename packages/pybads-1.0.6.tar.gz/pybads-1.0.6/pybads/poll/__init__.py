from .poll_mads_2n import poll_mads_2n
