from testing.bads import test_init_conf as b_conf_t
from testing.decorators import test_handle_0D_1D_input_decorator as dt
from testing.variable_transformer import test_variable_transformer as vtt

dt.test_0D_kwarg()
vtt.test_init_type_3()
