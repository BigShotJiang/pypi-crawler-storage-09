# __init__.py
from .timer import Timer
