# pybenjarvis

![GitHub License](https://img.shields.io/github/license/DarkFlameBEN/pybenjarvis)
[![PyPI - Version](https://img.shields.io/pypi/v/pybenjarvis)](https://pypi.org/project/pybenjarvis/)
![python suggested version](https://img.shields.io/badge/python-3.12.5-red.svg)
![python minimum version](https://img.shields.io/badge/python(min)-3.10+-red.svg)
![platforms](https://img.shields.io/badge/Platforms-Linux%20|%20Windows%20|%20Mac%20-purple.svg)

## Introduction
PyBEN jarvis is a getter for Akamai auto_etp local repo. Also adds the 'jarvis' module to site-package

## Installation
> python -m pip install pybenjarvis

## Use

### auto_etp repository installation
> python -m pybenjarvis.install

### Jarvis module activation
> python -m pybenjarvis
