"""
pybirdsreynolds init
"""

from pybirdsreynolds.args import compute_args
from pybirdsreynolds.app import app


def pybirdsreynolds():
    """
    pybirdsreynolds entry point
    """

    app()
