# Authors

## Project Manager

- [Kyle Godbey](https://github.com/kylegodbey)

## Lead Developers

- [Troy Dasher](https://github.com/dashertr)
- [turtuledunnad](https://github.com/turtuledunnad)

## Acknowledgments

- We thank the developers of the following libraries that make pyBMC possible:
  - NumPy
  - SciPy
  - pandas
  - h5py
  - scikit-learn
- Special thanks to the nuclear physics community for their valuable feedback
