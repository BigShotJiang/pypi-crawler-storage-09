# register the completion scripts since they are not required to be registered anywhere else
from . import bash_gte_42, powershell_completion  # noqa: F401
