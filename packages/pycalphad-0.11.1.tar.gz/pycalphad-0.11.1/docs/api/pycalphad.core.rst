pycalphad.core package
======================

Submodules
----------

pycalphad.core.cache module
---------------------------

.. automodule:: pycalphad.core.cache
   :members:
   :undoc-members:
   :show-inheritance:

pycalphad.core.calculate module
-------------------------------

.. automodule:: pycalphad.core.calculate
   :members:
   :undoc-members:
   :show-inheritance:

pycalphad.core.composition\_set module
--------------------------------------

.. automodule:: pycalphad.core.composition_set
   :members:
   :undoc-members:
   :show-inheritance:

pycalphad.core.conditions module
--------------------------------

.. automodule:: pycalphad.core.conditions
   :members:
   :undoc-members:
   :show-inheritance:

pycalphad.core.constants module
-------------------------------

.. automodule:: pycalphad.core.constants
   :members:
   :undoc-members:
   :show-inheritance:

pycalphad.core.constraints module
---------------------------------

.. automodule:: pycalphad.core.constraints
   :members:
   :undoc-members:
   :show-inheritance:

pycalphad.core.eqsolver module
------------------------------

.. automodule:: pycalphad.core.eqsolver
   :members:
   :undoc-members:
   :show-inheritance:

pycalphad.core.equilibrium module
---------------------------------

.. automodule:: pycalphad.core.equilibrium
   :members:
   :undoc-members:
   :show-inheritance:

pycalphad.core.errors module
----------------------------

.. automodule:: pycalphad.core.errors
   :members:
   :undoc-members:
   :show-inheritance:

pycalphad.core.halton module
----------------------------

.. automodule:: pycalphad.core.halton
   :members:
   :undoc-members:
   :show-inheritance:

pycalphad.core.hyperplane module
--------------------------------

.. automodule:: pycalphad.core.hyperplane
   :members:
   :undoc-members:
   :show-inheritance:

pycalphad.core.light\_dataset module
------------------------------------

.. automodule:: pycalphad.core.light_dataset
   :members:
   :undoc-members:
   :show-inheritance:

pycalphad.core.lower\_convex\_hull module
-----------------------------------------

.. automodule:: pycalphad.core.lower_convex_hull
   :members:
   :undoc-members:
   :show-inheritance:

pycalphad.core.minimizer module
-------------------------------

.. automodule:: pycalphad.core.minimizer
   :members:
   :undoc-members:
   :show-inheritance:

pycalphad.core.phase\_rec module
--------------------------------

.. automodule:: pycalphad.core.phase_rec
   :members:
   :undoc-members:
   :show-inheritance:

pycalphad.core.polytope module
------------------------------

.. automodule:: pycalphad.core.polytope
   :members:
   :undoc-members:
   :show-inheritance:

pycalphad.core.solver module
----------------------------

.. automodule:: pycalphad.core.solver
   :members:
   :undoc-members:
   :show-inheritance:

pycalphad.core.starting\_point module
-------------------------------------

.. automodule:: pycalphad.core.starting_point
   :members:
   :undoc-members:
   :show-inheritance:

pycalphad.core.utils module
---------------------------

.. automodule:: pycalphad.core.utils
   :members:
   :undoc-members:
   :show-inheritance:

pycalphad.core.workspace module
-------------------------------

.. automodule:: pycalphad.core.workspace
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: pycalphad.core
   :members:
   :undoc-members:
   :show-inheritance:
