# PyCanarytoken

A Python library to generate Canarytokens.

## Installation

```bash
pip install pycanarytoken
```

