"""
XML Utilities for PyCheval
"""

URN_MINIMUM_PROFILE = "urn:factur-x.eu:1p0:minimum"
URN_BASIC_WL_PROFILE = "urn:factur-x.eu:1p0:basicwl"
URN_BASIC_PROFILE = (
    "urn:cen.eu:en16931:2017#compliant#urn:factur-x.eu:1p0:basic"
)
URN_EN16931_PROFILE = "urn:cen.eu:en16931:2017"
URN_EXTENDED_PROFILE = (
    "urn:cen.eu:en16931:2017#conformant#urn:factur-x.eu:1p0:extended"
)
URN_XRECHNUNG_PROFILE = "urn:cen.eu:en16931:2017#compliant#urn:xoev-de:kosit:standard:xrechnung_2.1"  # noqa: E501

NS_CII = "urn:un:unece:uncefact:data:standard:CrossIndustryInvoice:100"
NS_RAM = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:100"  # noqa: E501
NS_UDT = "urn:un:unece:uncefact:data:standard:UnqualifiedDataType:100"

ALLOWED_ATTACHMENT_MIME_TYPES = (
    "application/pdf",
    "image/png",
    "image/jpeg",
    "text/csv",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "application/vnd.oasis.opendocument.spreadsheet",
)
