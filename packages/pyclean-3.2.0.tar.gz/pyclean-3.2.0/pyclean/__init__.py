# SPDX-FileCopyrightText: 2019 Peter Bittner <django@bittner.it>
#
# SPDX-License-Identifier: GPL-3.0-or-later

"""
Pure Python cross-platform pyclean. Clean up your Python bytecode.
"""

__version__ = '3.2.0'
