__version__ = "1.0.1"
__author__ = 'Ruthvik Koppala'
__credits__ = 'Institute for Computational Genomics'

import pycrosstalker.tools as tl
import pycrosstalker.plots as pl


#Atfan helped to translate some of the code