import os
from . import SwarmL2_F107_Read, SwarmL2_MIO_SHA_Read_v2
from .getSQfield import getSQfield

__version__ = "7.2.0"