from .dnevnik import AsyncDiaryAPI

__all__ = ["AsyncDiaryAPI"]
