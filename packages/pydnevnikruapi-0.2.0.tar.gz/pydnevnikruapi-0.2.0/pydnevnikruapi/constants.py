BASE_URL = "https://api.dnevnik.ru/v2/"
LOGIN_URL = "https://login.dnevnik.ru/login/"
RETURN_URL = (
    "https://login.dnevnik.ru/oauth2?response_type="
    "token&client_id=b8006d75-70a9-4291-885c-13d8511bb2ae&scope=CommonInfo,EducationalInfo"
)
