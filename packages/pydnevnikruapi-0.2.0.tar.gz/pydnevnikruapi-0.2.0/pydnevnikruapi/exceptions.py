class AsyncDiaryError(Exception):
    pass
