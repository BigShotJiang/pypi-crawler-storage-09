"""
This package contains object_action-specific functions for processing Egeria Markdown
"""