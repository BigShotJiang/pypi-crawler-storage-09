# pyenv-inspect

An auxiliary library for the [virtualenv-pyenv][virtualenv-pyenv] and [tox-pyenv-redux][tox-pyenv-redux] plugins

## Limitations

Only CPython is supported at the moment.


[virtualenv-pyenv]: https://github.com/un-def/virtualenv-pyenv
[tox-pyenv-redux]: https://github.com/un-def/tox-pyenv-redux
