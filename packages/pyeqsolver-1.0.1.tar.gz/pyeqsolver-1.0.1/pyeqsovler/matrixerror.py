class InvalidMatrixError(Exception):
    """
    Custom exception raised when an invalid matrix is provided.
    """
    pass