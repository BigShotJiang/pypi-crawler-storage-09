import tomlkit


if __name__ == "__main__":
    with open("pyproject.toml", "r") as f:
        data = tomlkit.load(f)

    lst = list(data['build-system']['requires'])
    data["project"]["dependencies"] += [el for el in set(lst) if not el.startswith("pyauthenticator")]

    with open("pyproject.toml", "w") as f:
        f.writelines(tomlkit.dumps(data))