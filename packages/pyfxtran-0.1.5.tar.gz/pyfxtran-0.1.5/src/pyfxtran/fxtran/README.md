
![](./Images/tronconneuse3.png)

# fxtran
Parse Fortran source code. Decorate source code with XML tags. The result is an XML file which you can search with XPath, modify with the DOM API. 
Round tripping is supported : get back your original or modified source code just by stripping XML tags.

Provided under the terms of the GNU GPL license.

[Short presentation of fxtran](share/doc/fxtran/fxtran.pdf)

[Parsing and refactoring FORTRAN code with XML](share/doc/fxtran/ARTICLE.md)
