#ifndef _FXTRAN_RUN
#define _FXTRAN_RUN
int FXTRAN_RUN (int, char *[], char *, char **, char **);
#endif

