/*
 * FXTRAN -- Philippe Marguinaud -- pmarguinaud@hotmail.com
 * Distributed under the GNU General Public License
 */
#ifndef _FXTRAN_FIXED_H
#define _FXTRAN_FIXED_H

#include "FXTRAN_XML.h"

void FXTRAN_FIXED_decode (FXTRAN_xmlctx *);

#endif
