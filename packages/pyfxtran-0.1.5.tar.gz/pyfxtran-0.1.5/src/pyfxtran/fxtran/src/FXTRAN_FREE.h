/*
 * FXTRAN -- Philippe Marguinaud -- pmarguinaud@hotmail.com
 * Distributed under the GNU General Public License
 */
#ifndef _FXTRAN_FREE_H
#define _FXTRAN_FREE_H

#include "FXTRAN_XML.h"

void FXTRAN_FREE_decode (FXTRAN_xmlctx *);

#endif
