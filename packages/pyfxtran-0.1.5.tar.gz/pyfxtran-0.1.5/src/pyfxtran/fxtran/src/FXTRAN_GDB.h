/*
 * FXTRAN -- Philippe Marguinaud -- pmarguinaud@hotmail.com
 * Distributed under the GNU General Public License
 */
#ifndef _FXTRAN_GDB_H
#define _FXTRAN_GDB_H


void FXTRAN_save_args (int, char * []);
void FXTRAN_save_where (const char *, int);


#endif
