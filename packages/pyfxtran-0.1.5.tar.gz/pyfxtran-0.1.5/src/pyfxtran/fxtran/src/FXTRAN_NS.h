#ifndef _FXTRAN_NS_H
#define FXT_NS_SYN "http://fxtran.net/#syntax"
#define FXT_NS_NAM "http://fxtran.net/#namelist"
#endif

