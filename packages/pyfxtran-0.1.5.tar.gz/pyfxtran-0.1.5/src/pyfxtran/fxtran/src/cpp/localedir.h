#define LOCALEDIR "/usr/local/share/locale"
