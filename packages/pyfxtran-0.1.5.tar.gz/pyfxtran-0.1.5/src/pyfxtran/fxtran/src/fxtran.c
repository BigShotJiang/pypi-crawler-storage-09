/*
 * FXTRAN -- Philippe Marguinaud -- pmarguinaud@hotmail.com
 * Distributed under the GNU General Public License
 */

#include <stdlib.h>
#include <stdio.h>

#include "FXTRAN/RUN.h"

int main (int argc, char * argv[])
{
  return FXTRAN_RUN (argc, argv, NULL, NULL, NULL);
}
