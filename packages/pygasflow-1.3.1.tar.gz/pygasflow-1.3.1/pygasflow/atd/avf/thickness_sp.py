# import numpy as np

# eq (7.132) and (7.133)
