Installation
============

You can install PyHPKE with pip:

.. code-block:: console

    $ pip install pyhpke
