from inventory.admin.item import ItemModelAdmin  # noqa
from inventory.admin.location import LocationModelAdmin  # noqa
from inventory.admin.memo import MemoModelAdmin  # noqa
