import inventory


# Just the same version as the real project:
__version__ = inventory.__version__
