#pragma once

namespace pyitt
{
namespace pyext
{
namespace error
{

inline constexpr const char* invalid_argument_type_tmpl = "The passed %s is not a valid instance of %s type.";

}
}
}