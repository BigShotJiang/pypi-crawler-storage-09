"""
Compatibility layers.

This module provides a compatibility layers that allows to use pyitt as a backend for other ITT API Python bindings.
"""
