__version__ = "1.1.0"
__author__ = "diodemusic"
__title__ = "pyke"
