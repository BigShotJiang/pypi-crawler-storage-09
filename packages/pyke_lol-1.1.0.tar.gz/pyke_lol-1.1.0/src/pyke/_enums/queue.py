from enum import Enum


class Queue(Enum):
    """# Ranked queue type"""

    SOLO_DUO = "RANKED_SOLO_5x5"
    FLEX = "RANKED_FLEX_SR"
