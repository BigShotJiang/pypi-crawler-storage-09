from .solver import LapSolver


__version__ = "1.1.0"
