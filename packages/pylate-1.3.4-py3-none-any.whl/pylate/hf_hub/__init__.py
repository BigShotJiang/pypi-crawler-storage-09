from __future__ import annotations

from .model_card import PylateModelCardData

__all__ = ["PylateModelCardData"]
