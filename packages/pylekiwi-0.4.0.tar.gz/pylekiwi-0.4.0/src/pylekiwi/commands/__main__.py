from pylekiwi.commands.cli import app


def main() -> None:
    app(prog_name="pylekiwi")


if __name__ == "__main__":
    main()
