			 Disclaimer and Copyright

The programs, library and source code of the LinearFold Package are free software. They are distributed in the hope that they will be useful but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

Permission is granted for research, educational, and commercial use and modification so long as 1) the package and any derived works are not redistributed for any fee, other than media costs, 2) proper credit is given to the authors. Please cite the following paper:


Liang Huang, He Zhang, Dezhong Deng, Kai Zhao, Kaibo Liu, David Hendrix, and David Mathews (2019). LinearFold: Linear-Time Approximate RNA Folding by 5'-to-3' Dynamic Programming and Beam Search. Bioinformatics, Vol. 35, July 2019, Special Issue of ISMB 2019 Proceedings.

corresponding author: Liang Huang <liang.huang.sh@gmail.com>

If you want to include this software in a commercial product, please contact the corresponding author.
