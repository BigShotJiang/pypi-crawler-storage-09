def foo():
    """Docstring."""
    return
