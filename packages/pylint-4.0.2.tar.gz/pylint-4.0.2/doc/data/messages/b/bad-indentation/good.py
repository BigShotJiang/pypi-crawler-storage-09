if input():
    print("yes")
