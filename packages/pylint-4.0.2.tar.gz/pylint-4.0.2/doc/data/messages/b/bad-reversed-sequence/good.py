reversed([1, 2, 3, 4])
