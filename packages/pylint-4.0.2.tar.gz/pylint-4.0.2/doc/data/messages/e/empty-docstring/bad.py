def foo():  # [empty-docstring]
    """"""
