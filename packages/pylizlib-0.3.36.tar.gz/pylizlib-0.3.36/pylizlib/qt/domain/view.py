import enum


class UiWidgetMode(enum.Enum):
    DISPLAYING = "displaying"
    UPDATING = "updating"