name = 'pylizlib'
version = '0.3.27'
description = 'Add your description here'
requires_python = '>=3.12'
authors = [('Gabliz', 'gabliz.dev@gmail.com')]
