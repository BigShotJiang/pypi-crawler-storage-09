"""IO interface for FHI-aims."""

from __future__ import annotations

from pymatgen.io.aims.sets.base import AimsInputSet  # noqa: F401
