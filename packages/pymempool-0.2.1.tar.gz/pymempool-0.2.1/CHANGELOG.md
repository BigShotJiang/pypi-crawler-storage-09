# 0.0.2 / 2022-06-03

- Fix requirements

# 0.0.1 / 2022-06-03

- initial releaase
