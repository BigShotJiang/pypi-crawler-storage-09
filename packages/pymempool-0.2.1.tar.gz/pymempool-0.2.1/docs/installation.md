# Installation

## PyPI

```bash
pip install pymempool
```

## From source

```bash
git clone https://github.com/holgern/pymempool.git
cd pymempool
python3 setup.py install
```
