from pymeshup.gui.main import QApplication, Gui

app = QApplication()
gui = Gui()
app.exec()
