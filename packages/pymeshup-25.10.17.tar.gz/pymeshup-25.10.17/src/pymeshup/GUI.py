from pymeshup.gui.main import QApplication, Gui

print("Loading GUI...")


app = QApplication()
gui = Gui()
app.exec()
