# from pymeshup import *
#
# h = Hull(r"C:\Users\beneden\Jottacloud\RdBr\Projects\HEBO HL-10\hull\ordinates_tab.txt")
# grid = h.regrid(pct=2)
# grid2 = grid.merge_close_vertices(pct=50)
