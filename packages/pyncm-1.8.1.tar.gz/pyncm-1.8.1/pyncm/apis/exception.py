class LoginRequiredException(Exception):
    pass


class LoginFailedException(Exception):
    pass
