# pypl2api.py - High level functions for accessing
# .pl2 files. Mimics Plexon's Matlab PL2 SDK
#
# (c) 2016 Plexon, Inc., Dallas, Texas
# www.plexon.com
#
# This software is provided as-is, without any warranty.
# You are free to modify or share this file, provided that the above
# copyright notice is kept intact.

from collections import namedtuple
from .pypl2lib import *

try:
    import numpy as np
    use_numpy = True
except ImportError as e:
    use_numpy = False

def disable_numpy():
    use_numpy = False

def get_last_error_message(pypl2_file_reader_instance):
    error_message = (c_char * 256)()
    res = pypl2_file_reader_instance.pl2_get_last_error(error_message, 256)
    if (res == 1):
        return error_message.value
    else:
        return "Error getting last error message."

def print_error(pypl2_file_reader_instance):
    error_message = get_last_error_message(pypl2_file_reader_instance)
    print(error_message)
    

def pl2_ad(filename, channel, return_volts = True):

    """
    Reads continuous data from specific file and channel.
    
    Usage:
        >>>adfrequency, n, timestamps, fragmentcounts, ad = pl2_ad(filename, channel)
        >>>res = pl2_ad(filename, channel)
    
    Args:
        filename - full path and filename of .pl2 file
        channel - zero-based channel index, or channel name
        return_volts - If True (the default) the 'ad' field is in Volts, if False the 'ad' field is in ADC units
    
    Returns (named tuple fields):
        adfrequency - digitization frequency for the channel
        n - total number of data points
        timestamps - tuple of fragment timestamps (one timestamp per fragment, in seconds)
        fragmentcounts - tuple of fragment counts
        ad - tuple of raw a/d values in volts
        
        The returned data is in a named tuple object, so it can be accessed as a normal tuple: 
            >>>res = pl2_ad('data/file.pl2', 0)
            >>>res[0]
            40000
        or as a named tuple:
            >>>res.adfrequency
            40000
    
        If any error is detected, an error message is printed and the function returns 0
    """
    
    #Create an instance of PyPL2FileReader.
    p = PyPL2FileReader()
    
    #Verify that the file passed exists first.
    #Open the file.
    handle = p.pl2_open_file(filename)
    
    #If the handle is 0, print error message and return 0.
    if (handle == 0):
        print_error(p)
        return 0
        
    #Create instance of PL2FileInfo.
    file_info = PL2FileInfo()
    
    res = p.pl2_get_file_info(handle, file_info)
    
    #If res is 0, print error message and return 0.
    if (res == 0):
        print_error(p)
        return 0  
    
    #Create instance of PL2AnalogChannelInfo.
    achannel_info = PL2AnalogChannelInfo()    

    #Check if channel is an integer or string, and call appropriate function
    if type(channel) is int:
        res = p.pl2_get_analog_channel_info(handle, channel, achannel_info)
    if type(channel) is str:
        res = p.pl2_get_analog_channel_info_by_name(handle, channel, achannel_info)
        
    #If res is 0, print error message and return 0.
    if (res == 0):
        print_error(p)
        return 0
    
    #Set up instances of ctypes classes needed by pl2_get_analog_channel_data().
    #These will be filled in by the function.
    num_fragments_returned = c_ulonglong(0)
    num_data_points_returned = c_ulonglong(0)
    fragment_timestamps = (c_longlong * achannel_info.m_MaximumNumberOfFragments)()
    fragment_counts = (c_ulonglong * achannel_info.m_MaximumNumberOfFragments)()
    values = (c_short * achannel_info.m_NumberOfValues)()
    
    #Check if channel is an integer or string, and call appropriate function
    if type(channel) is int:
        res = p.pl2_get_analog_channel_data(handle,
                                            channel,
                                            num_fragments_returned,
                                            num_data_points_returned,
                                            fragment_timestamps,
                                            fragment_counts,
                                            values)
    if type(channel) is str:
        res = p.pl2_get_analog_channel_data_by_name(handle,
                                                    channel,
                                                    num_fragments_returned,
                                                    num_data_points_returned,
                                                    fragment_timestamps,
                                                    fragment_counts,
                                                    values)

    # Close the file
    p.pl2_close_file(handle)
    
    #If res is 0, print error message and return 0.
    if (res == 0):
        print_error(p)
        return 0
    
    #Convert some array data into numpy arrays if necessary
    if use_numpy:
        fragment_timestamps = np.array(fragment_timestamps)
        fragment_counts = np.array(fragment_counts)
        values = np.array(values)

    #Create a named tuple called PL2Ad.
    PL2Ad = namedtuple('PL2Ad', 'adfrequency n timestamps fragmentcounts ad')

    #Fill in and return named tuple.
    if use_numpy:
        return PL2Ad(achannel_info.m_SamplesPerSecond, 
                    num_data_points_returned.value,
                    tuple(fragment_timestamps / file_info.m_TimestampFrequency),
                    tuple(fragment_counts[fragment_counts != 0]),
                    tuple(values * (achannel_info.m_CoeffToConvertToUnits if return_volts else 1)))
    else:
        tmp_fragment_timestamps = []
        for i in range(num_fragments_returned.value):
            tmp_fragment_timestamps.append(fragment_timestamps[i] / file_info.m_TimestampFrequency)
        
        return PL2Ad(achannel_info.m_SamplesPerSecond, 
                    num_data_points_returned.value,
                    tuple(tmp_fragment_timestamps),
                    tuple([x for x in fragment_counts if x]),
                    tuple([x * (achannel_info.m_CoeffToConvertToUnits if return_volts else 1) for x in values]))


def pl2_ad_subset(filename, channel, subset_start, subset_length, return_volts = True):

    """
    Reads continuous data from specific file and channel.
    
    Usage:
        >>>adfrequency, n, timestamps, fragmentcounts, ad = pl2_ad(filename, channel)
        >>>res = pl2_ad(filename, channel)
    
    Args:
        filename - full path and filename of .pl2 file
        channel - zero-based channel index
        subset_start - zero-based sample index of the start of the subset
        subset_length - length of subset, in samples
        return_volts - If True (the default) the 'ad' field is in Volts, if False the 'ad' field is in ADC units
    
    Returns (named tuple fields):
        adfrequency - digitization frequency for the channel
        n - total number of data points
        timestamps - tuple of fragment timestamps (one timestamp per fragment, in seconds)
        fragmentcounts - tuple of fragment counts
        ad - tuple of raw a/d values in volts
        
        The returned data is in a named tuple object, so it can be accessed as a normal tuple: 
            >>>res = pl2_ad('data/file.pl2', 0)
            >>>res[0]
            40000
        or as a named tuple:
            >>>res.adfrequency
            40000
    
        If any error is detected, an error message is printed and the function returns 0
    """
    
    #Create an instance of PyPL2FileReader.
    p = PyPL2FileReader()
    
    #Verify that the file passed exists first.
    #Open the file.
    handle = p.pl2_open_file(filename)
    
    #If the handle is 0, print error message and return 0.
    if (handle == 0):
        print_error(p)
        return 0
        
    #Create instance of PL2FileInfo.
    file_info = PL2FileInfo()
    
    res = p.pl2_get_file_info(handle, file_info)
    
    #If res is 0, print error message and return 0.
    if (res == 0):
        print_error(p)
        return 0  
    
    #Create instance of PL2AnalogChannelInfo.
    achannel_info = PL2AnalogChannelInfo()    

    #Check if channel is an integer or string, and call appropriate function
    if type(channel) is int:
        res = p.pl2_get_analog_channel_info(handle, channel, achannel_info)
    if type(channel) is str:
        print("Channel name as string is not supported.")
        return 0
        
    #If res is 0, print error message and return 0.
    if (res == 0):
        print_error(p)
        return 0
    
    #Set up instances of ctypes classes needed by pl2_get_analog_channel_data().
    #These will be filled in by the function.
    num_fragments_returned = c_ulonglong(0)
    num_data_points_returned = c_ulonglong(0)
    fragment_timestamps = (c_longlong * achannel_info.m_MaximumNumberOfFragments)()
    fragment_counts = (c_ulonglong * achannel_info.m_MaximumNumberOfFragments)()
    values = (c_short * subset_length)()
    
    #Check if channel is an integer or string, and call appropriate function
    if type(channel) is int:
        res = p.pl2_get_analog_channel_data_subset(handle,
                                                channel,
                                                subset_start,
                                                subset_length,
                                                num_fragments_returned,
                                                num_data_points_returned,
                                                fragment_timestamps,
                                                fragment_counts,
                                                values)


    # Close the file
    p.pl2_close_file(handle)
    
    #If res is 0, print error message and return 0.
    if (res == 0):
        print_error(p)
        return 0
    
    #Convert some array data into numpy arrays if necessary
    if use_numpy:
        fragment_timestamps = np.array(fragment_timestamps)
        fragment_counts = np.array(fragment_counts)
        values = np.array(values)

    #Create a named tuple called PL2Ad.
    PL2Ad = namedtuple('PL2Ad', 'adfrequency n timestamps fragmentcounts ad')

    #Fill in and return named tuple.
    if use_numpy:
        return PL2Ad(achannel_info.m_SamplesPerSecond, 
                    num_data_points_returned.value,
                    tuple(fragment_timestamps / file_info.m_TimestampFrequency),
                    tuple(fragment_counts[fragment_counts != 0]),
                    tuple(values * (achannel_info.m_CoeffToConvertToUnits if return_volts else 1)))
    else:
        tmp_fragment_timestamps = []
        for i in range(num_fragments_returned.value):
            tmp_fragment_timestamps.append(fragment_timestamps[i] / file_info.m_TimestampFrequency)
        
        return PL2Ad(achannel_info.m_SamplesPerSecond, 
                    num_data_points_returned.value,
                    tuple(tmp_fragment_timestamps),
                    tuple([x for x in fragment_counts if x]),
                    tuple([x * (achannel_info.m_CoeffToConvertToUnits if return_volts else 1) for x in values]))

def pl2_spikes(filename, channel, return_volts = True):
    """
    Reads spike data from a specific file and channel.
    
    Usage:
        >>>n, timestamps, units, waveforms = pl2_spikes(filename, channel)
        >>>res = pl2_spikes(filename, channel)
    
    Args:
        filename - full path and filename of .pl2 file
        channel - zero-based channel index, or channel name
        return_volts - If True (the default) the 'waveforms' field is in Volts, if False the 'waveforms' field is in ADC units
    
    Returns (named tuple fields):
        n - number of spike waveforms
        timestamps - tuple of spike waveform timestamps in seconds
        units - tuple of spike waveform unit assignments (0 = unsorted, 1 = Unit A, 2 = Unit B, etc)
        waveforms - tuple of tuples with raw waveform a/d values in volts
        
        The returned data is in a named tuple object, so it can be accessed as a normal tuple: 
            >>>res = pl2_spikes('data/file.pl2', 0)
            >>>res[0]
            6589
        or as a named tuple:
            >>>res.n
            6589
        
        To access individual waveform values, address res.waveforms with the index of the waveform.
        Result shortened for example:
            >>>res.waveforms[49]
            (0.000345643, 0.000546342, ... , -0.03320040)
    
        If any error is detected, an error message is printed and the function returns 0
    """
    
    #Create an instance of PyPL2FileReader.
    p = PyPL2FileReader()
    
    #Verify that the file passed exists first.
    #Open the file.
    handle = p.pl2_open_file(filename)

    #If the handle is 0, print error message and return 0.
    if (handle == 0):
        print_error(p)
        return 0
        
    #Create instance of PL2FileInfo.
    file_info = PL2FileInfo()
    
    res = p.pl2_get_file_info(handle, file_info)
    
    #If res is 0, print error message and return 0.
    if (res == 0):
        print_error(p)
        return 0        

    #Create instance of PL2SpikeChannelInfo.
    schannel_info = PL2SpikeChannelInfo()
    
    #Check if channel is an integer or string, and call appropriate function
    if type(channel) is int:
        res = p.pl2_get_spike_channel_info(handle, channel, schannel_info)
    if type(channel) is str:
        res = p.pl2_get_spike_channel_info_by_name(handle, channel, schannel_info)

    #If res is 0, print error message and return 0.
    if (res == 0):
        print_error(p)
        return 0    
        
    #Set up instances of ctypes classes needed by pl2_get_spike_channel_data().
    #These will be filled in by the function.
    num_spikes_returned = c_ulonglong()
    spike_timestamps = (c_ulonglong * schannel_info.m_NumberOfSpikes)()
    units = (c_ushort * schannel_info.m_NumberOfSpikes)()
    values = (c_short * (schannel_info.m_NumberOfSpikes * schannel_info.m_SamplesPerSpike))()
    
    if type(channel) is int:
        res = p.pl2_get_spike_channel_data(handle, 
                                           channel,
                                           num_spikes_returned,
                                           spike_timestamps,
                                           units,
                                           values)
    if type(channel) is str:
        res = p.pl2_get_spike_channel_data_by_name(handle,
                                                   channel,
                                                   num_spikes_returned,
                                                   spike_timestamps,
                                                   units,
                                                   values)
        
    # Close the file
    p.pl2_close_file(handle)
    
    #If res is 0, print error message and return 0.
    if (res == 0):
        print_error(p)
        return 0    
        
    #Convert array data into numpy arrays if necessary
    if use_numpy:
        spike_timestamps = np.array(spike_timestamps)
        units = np.array(units)
        values = np.array(values)

    #Convert ad units to voltage if necessary
    if return_volts:
        if use_numpy:
            values = values * schannel_info.m_CoeffToConvertToUnits
        else:
            values = [x*schannel_info.m_CoeffToConvertToUnits for x in values]
    else:
        pass
    
    #Then, extract the waveforms from 'values' into a multi-dimensional
    #Python tuple. 
    if use_numpy:
        #Split up the values array into individual waveform arrays
        split_values = np.split(values, schannel_info.m_SamplesPerSpike)
        #Convert the arrays into tuples
        waveforms = tuple([tuple(n) for n in split_values])
    else:
        waveforms = []
        current_location = 0
        breadth = schannel_info.m_SamplesPerSpike
        for i in range(num_spikes_returned.value):
            temp = values[current_location:current_location+breadth]
            waveforms.append(temp)
            current_location += breadth
        waveforms = tuple(waveforms)
    
    #Convert timestamps into seconds
    if use_numpy:
        spike_timestamps = spike_timestamps / file_info.m_TimestampFrequency
    else:
        spike_timestamps = [x/file_info.m_TimestampFrequency for x in spike_timestamps]

    #Create a named tuple called PL2Spikes
    PL2Spikes = namedtuple('PL2Spikes', 'n timestamps units waveforms')
    
    return PL2Spikes(num_spikes_returned.value,
                     tuple(spike_timestamps),
                     tuple(x for x in units),
                     waveforms)

 
def pl2_events(filename, channel):
    """
    Reads event channel data from a specific file and event channel
    
    Usage:
        >>>n, timestamps, values = pl2_events(filename, channel)
        >>>res = pl2_events(filename, channel)
    Args:
        filename - full path of the file
        channel - 1-based event channel index, or event channel name;
        
    Returns (named tuple fields):
        n - number of events
        timestamps - array of timestamps (in seconds)
        values - array of event values (when event is a strobed word)
        
    The returned data is in a named tuple object, so it can be accessed as a normal tuple:
        >>>res = pl2_events('data/file.pl2', 1)
        >>>res[0]
        784
    or as a named tuple:
        >>>res.n
        784
    """
    
    #Create an instance of PyPL2FileReader.
    p = PyPL2FileReader()
    
    #Verify that the file passed exists first.
    #Open the file.
    handle = p.pl2_open_file(filename)

    #If the handle is 0, print error message and return 0.
    if (handle == 0):
        print_error(p)
        return 0
        
    #Create instance of PL2FileInfo.
    file_info = PL2FileInfo()
    
    res = p.pl2_get_file_info(handle, file_info)
    
    #If res is 0, print error message and return 0.
    if (res == 0):
        print_error(p)
        return 0   
    
    #Create an instance of PL2DigitalChannelInfo.
    echannel_info = PL2DigitalChannelInfo()

    #Check if channel is an integer or string, and call appropriate function
    if type(channel) is int:
        res = p.pl2_get_digital_channel_info(handle, channel, echannel_info)
    if type(channel) is str:
        res = p.pl2_get_digital_channel_info_by_name(handle, channel, echannel_info)
    
    #If res is 0, print error message and return 0.
    if (res == 0):
        print_error(p)
        return 0
    
    #Set up instances of ctypes classes needed by pl2_get_digital_channel_data().
    #These will be filled in by the function.    
    num_events_returned = c_ulonglong()
    event_timestamps = (c_longlong * echannel_info.m_NumberOfEvents)()
    event_values = (c_ushort * echannel_info.m_NumberOfEvents)()
    
    if type(channel) is int:
        res = p.pl2_get_digital_channel_data(handle,
                                             channel,
                                             num_events_returned,
                                             event_timestamps,
                                             event_values)
    if type(channel) is str:
        res = p.pl2_get_digital_channel_data_by_name(handle,
                                                     channel,
                                                     num_events_returned,
                                                     event_timestamps,
                                                     event_values)
    
    # Close the file
    p.pl2_close_file(handle)
    
    #Create a named tuple called PL2DigitalEvents
    PL2DigitalEvents = namedtuple('PL2DigitalEvents', 'n timestamps values')
    
    return PL2DigitalEvents(num_events_returned.value,
                            tuple(x/file_info.m_TimestampFrequency for x in event_timestamps),
                            tuple(x for x in event_values))

def pl2_info(filename):
    """
    Reads a PL2 file and returns information about the file.
    
    Usage:
        >>>spkcounts, evtcounts, adcounts = pl2_info(filename)
        >>>res = pl2_info(filename)
    
    Args:
        filename - Full path of the file
    
    Returns (named tuple fields):
        spikes - tuple the length of enabled spike channels with tuples
                 consisting of the spike channel number, name, and tuple of 
                 unit counts. The returned named tuple fields are:
                    channel - channel number
                    name - channel name
                    units - tuple with number of waveforms assigned to units
                            0 (unsorted) through 255
        events - tuple the length of event channels that contain data with tuples
                 consisting of the event channel number, name, and number of events.
                 The returned named tuple fields are:
                    channel - channel number
                    name - channel name
                    n - number of events in the channel
        ad - tuple the length of enabled ad channels with tuples consisting of the ad
             channel number, name, and number of samples. The returned named tuple fields
             are:
                channel - channels name
                name - channel name
                n - number of samples in the channel
             
    The returned data is in a named tuple object, and it's filled with more named tuple objects.
    There are several ways to access returned data.
        >>>spikecounts, eventcounts, adcounts = pl2_info('data/file.pl2')
        >>>len(spikecounts)
        >>>4
        
    pl2_info returns a named tuple object, but in the above example the three elements have been
    unpacked already into tuples called spikecounts, eventcounts, and adcounts. The length of
    these tuples indicate how many channels were enabled, or had values in them in the case of 
    event channels (since events are always enabled).
        >>>spikecounts[2].name
        >>>'SPK03'
        
    Continuing the example, the third element returned in spikecounts (2 is the third element
    because tuple indexing starts from 0) has a field called name, which contains the channel's
    name, SPK03. Because you can treat named tuples like normal tuples, you could also get that 
    information by the index (because you read the documentation and know that the name field is
    the second element of the tuple).
        >>>spikecounts[2][1]
        >>>'SPK03'
        
    If you don't unpack the returned tuple, it's still easy to get the information. The unpacked
    named tuple has the fields spikes, events, and ad.
        >>>res = pl2_info('data/file.pl2')
        >>>res.spikes[2].name
        >>>'SPK03'
    """
    #Create an instance of PyPL2FileReader.
    p = PyPL2FileReader()
    
    #Verify that the file passed exists first.
    #Open the file.
    handle = p.pl2_open_file(filename)

    #If the handle is 0, print error message and return 0.
    if (handle == 0):
        print_error(p)
        return 0
        
    #Create instance of PL2FileInfo.
    file_info = PL2FileInfo()
    
    res = p.pl2_get_file_info(handle, file_info)
    #If res is 0, print error message and return 0.
    
    if (res == 0):
        print_error(p)
        return 0
        
    #Lists that will be filled with tuples
    spike_counts = []
    event_counts = []
    ad_counts = []
    
    #Named tuples that will be appended into lists
    spike_info = namedtuple('spike_info', 'channel name units')
    event_info = namedtuple('event_info', 'channel name n')
    ad_info = namedtuple('ad_info', 'channel name n')
    
    #Get channel numbers, names, and unit counts for all enabled spike channels
    for i in range(file_info.m_TotalNumberOfSpikeChannels):
        schannel_info = PL2SpikeChannelInfo()
        res = p.pl2_get_spike_channel_info(handle, i, schannel_info)
        #If res is 0, print error message and return 0.
        if (res == 0):
            print_error(p)
            return 0       

        if schannel_info.m_ChannelEnabled:
            spike_counts.append(spike_info(schannel_info.m_Channel, schannel_info.m_Name.decode('ascii'), tuple(schannel_info.m_UnitCounts)))
    
    #Get channel numbers, names, and counts for all event channels with data
    for i in range(file_info.m_NumberOfDigitalChannels):
        echannel_info = PL2DigitalChannelInfo()
        res = p.pl2_get_digital_channel_info(handle, i, echannel_info)
        #If res is 0, print error message and return 0.
        if (res == 0):
            print_error(p)
            return 0        

        if echannel_info.m_NumberOfEvents:
            event_counts.append(event_info(echannel_info.m_Channel, echannel_info.m_Name.decode('ascii'), echannel_info.m_NumberOfEvents))

    #Get channel numbers, names, and counts for all enabled spike channels
    for i in range(file_info.m_TotalNumberOfAnalogChannels):
        achannel_info = PL2AnalogChannelInfo()
        res = p.pl2_get_analog_channel_info(handle, i, achannel_info)
        #If res is 0, print error message and return 0.
        if (res == 0):
            print_error(p)
            return 0
        
        if achannel_info.m_ChannelEnabled:
            ad_counts.append(ad_info(achannel_info.m_Channel, achannel_info.m_Name.decode('ascii'), achannel_info.m_NumberOfValues))
    
    
    # Close the file
    p.pl2_close_file(handle)
    
    PL2Info = namedtuple('PL2Info', 'spikes events ad')
    
    return PL2Info(tuple(spike_counts), tuple(event_counts), tuple(ad_counts))

def pl2_comments(filename):
    """
    Reads a PL2 file and returns comments made during the recording
    
    Usage:
        >>>timestamps, comments = pl2_comments(filename)
    
    Args:
        filename - Full path of the file
    
    Returns:
        timestamps - tuple of comment timestamps
        comments - tuple of comments
    """
    #Create an instance of PyPL2FileReader.
    p = PyPL2FileReader()

    #Verify that the file passed exists first.
    #Open the file.
    handle = p.pl2_open_file(filename)

    #If the handle is 0, print error message and return 0.
    if (handle == 0):
        print_error(p)
        return 0

    #Create instance of PL2FileInfo.
    file_info = PL2FileInfo()
    
    res = p.pl2_get_file_info(handle, file_info)
    
    #If res is 0, print error message and return 0.
    if (res == 0):
        print_error(p)
        return 0        

    #Get information about the comments in the file
    num_comments = c_ulonglong()
    total_number_of_comments_bytes = c_ulonglong()

    p.pl2_get_comments_info(handle, num_comments, total_number_of_comments_bytes)

    if num_comments.value == 0:
        return (0,), (0,)

    timestamps = (c_longlong * num_comments.value)()
    comment_lengths = (c_ulonglong * num_comments.value)()
    comments = (c_char * total_number_of_comments_bytes.value)()

    p.pl2_get_comments(handle, timestamps, comment_lengths, comments)

    timestamps_list = []
    comments_list = []
    offset = 0

    for n in range(num_comments.value):
        timestamps_list.append(timestamps[n] / file_info.m_TimestampFrequency)
        tmp_comment = comments[offset:offset + (comment_lengths[n] - 1)]
        comments_list.append(tmp_comment.decode('ascii'))
        offset += comment_lengths[n]

    # Close the file
    p.pl2_close_file(handle)

    return tuple(timestamps_list), tuple(comments_list)

def pl2_ad_info(filename, channel):
    """
    Retrieves information about an analog channel.

    Usage:
        analog_channel_info = pl2_ad_info(filename, 'WB01')
        analog_channel_info = pl2_ad_info(filename, 31)

    Args:
        filename - Full path of the file
        channel - Zero-based channel index, or channel name

    Returns (Named tuple fields):
        Name - channel name
        Source - 1-based source number
        Channel - 1-based channel number within source
        ChannelEnabled - 1 for enabled, 0 for disabled
        ChannelRecordingEnabled - 1 for recording enabled, 0 for recording disabled
        Units - "Volts" by default
        SamplesPerSecond - digitization frequency in Hz
        CoeffToConvertToUnits - coefficient to convert raw a/d values to units
        SourceTrodality - number of channels in one trode
        OneBasedTrode - 1-based trode number; if SourceTrodality is 1, OneBasedTrode is the same as Channel
        OneBasedChannelInTrode - 1-based channel inside trode; possible values are from 1 to SourceTrodality inclusive
        NumberOfValues - number of analog values for this channel
        MaximumNumberOfFragments - maximum number of fragments for this channel

        Tuple values will be '' or 0s if the channel is not found in the file.
    """
    #Create an instance of PyPL2FileReader.
    p = PyPL2FileReader()

    #Verify that the file passed exists first.
    #Open the file.
    handle = p.pl2_open_file(filename)

    #If the handle is 0, print error message and return 0.
    if (handle == 0):
        print_error(p)
        return 0

    #Create an instance of PL2DigitalChannelInfo.
    achannel_info = PL2AnalogChannelInfo()

    #Check if channel is an integer or string, and call appropriate function
    if type(channel) is int:
        res = p.pl2_get_analog_channel_info(handle, channel, achannel_info)
    if type(channel) is str:
        res = p.pl2_get_analog_channel_info_by_name(handle, channel, achannel_info)

    AnalogChannelInfo = namedtuple('AnalogChannelInfo', 'Name Source Channel ChannelEnabled ChannelRecordingEnabled Units SamplesPerSecond CoeffToConvertToUnits SourceTrodality OneBasedTrode OneBasedChannelInTrode NumberOfValues MaximumNumberOfFragments')

    return AnalogChannelInfo(achannel_info.m_Name.decode(), achannel_info.m_Source, achannel_info.m_Channel, achannel_info.m_ChannelEnabled,
                             achannel_info.m_ChannelRecordingEnabled, achannel_info.m_Units.decode(), achannel_info.m_SamplesPerSecond,
                             achannel_info.m_CoeffToConvertToUnits, achannel_info.m_SourceTrodality, achannel_info.m_OneBasedTrode,
                             achannel_info.m_OneBasedChannelInTrode, achannel_info.m_NumberOfValues, achannel_info.m_MaximumNumberOfFragments)

def pl2_spikes_info(filename, channel):
    """
    Retrieves information about a spike channel.

    Usage:
        spike_channel_info = pl2_spikes_info(filename, 'SPK01')
        spike_channel_info = pl2_spikes_info(filename, 31)

    Args:
        filename - Full path of the file
        channel - Zero-based channel index, or channel name

    Returns (Named tuple fields):
        Name - channel name
        Source - 1-based source number
        Channel - 1-based channel number within source
        ChannelEnabled - 1 for enabled, 0 for disabled
        ChannelRecordingEnabled - 1 for recording enabled, 0 for recording disabled
        Units - "Volts" by default
        SamplesPerSecond - digitization frequency in Hz
        CoeffToConvertToUnits - coefficient to convert raw a/d values to units
        SamplesPerSpike - number of values in one waveform
        Threshold - raw a/d value of threshold
        PreThresholdSamples - number of values before threshold
        SortEnabled - 1 for sorting enabled, 0 for disabled
        SortMethod - 
        NumberOfUnits - number of sorted units
        SortRangeStart - sort range start
        SortRangeEnd - sort range end
        UnitCounts - tuple of unit counts, index 0 is unsorted, 1 is unit 1, 2 is unit 2, etc
        SourceTrodality - number of channels in one trode
        OneBasedTrode - 1-based trode number; if SourceTrodality is 1, OneBasedTrode is the same as Channel
        OneBasedChannelInTrode - 1-based channel inside trode; possible values are from 1 to SourceTrodality inclusive
        NumberOfSpikes - number of spikes for this channel

        Tuple values will be '' or 0s if the channel is not found in the file.
    """
    #Create an instance of PyPL2FileReader.
    p = PyPL2FileReader()

    #Verify that the file passed exists first.
    #Open the file.
    handle = p.pl2_open_file(filename)

    #If the handle is 0, print error message and return 0.
    if (handle == 0):
        print_error(p)
        return 0

    #Create an instance of PL2DigitalChannelInfo.
    schannel_info = PL2SpikeChannelInfo()

    #Check if channel is an integer or string, and call appropriate function
    if type(channel) is int:
        res = p.pl2_get_spike_channel_info(handle, channel, schannel_info)
    if type(channel) is str:
        res = p.pl2_get_spike_channel_info_by_name(handle, channel, schannel_info)

    SpikeChannelInfo = namedtuple('SpikeChannelInfo', 'Name Source Channel ChannelEnabled ChannelRecordingEnabled Units SamplesPerSecond CoeffToConvertToUnits SamplesPerSpike Threshold PreThresholdSamples SortEnabled SortMethod NumberOfUnits SortRangeStart SortRangeEnd UnitCounts SourceTrodality OneBasedTrode OneBasedChannelInTrode NumberOfSpikes')

    return SpikeChannelInfo(schannel_info.m_Name.decode(), schannel_info.m_Source, schannel_info.m_Channel, schannel_info.m_ChannelEnabled,
                             schannel_info.m_ChannelRecordingEnabled, schannel_info.m_Units.decode(), schannel_info.m_SamplesPerSecond,
                             schannel_info.m_CoeffToConvertToUnits, schannel_info.m_SamplesPerSpike, schannel_info.m_Threshold, schannel_info.m_PreThresholdSamples,
                             schannel_info.m_SortEnabled, schannel_info.m_SortMethod, schannel_info.m_NumberOfUnits, schannel_info.m_SortRangeStart,
                             schannel_info.m_SortRangeEnd, tuple(schannel_info.m_UnitCounts), schannel_info.m_SourceTrodality, schannel_info.m_OneBasedTrode,
                             schannel_info.m_OneBasedChannelInTrode, schannel_info.m_NumberOfSpikes)

def pl2_events_info(filename, channel):
    """
    Retrieves information about an event channel.

    Usage:
        event_channel_info = pl2_events_info(filename, 'EVT01')
        event_channel_info = pl2_events_info(filename, 5)

    Args:
        filename - Full path of the file
        channel - Zero-based channel index, or channel name

    Returns (Named tuple fields):
        Name - channel name
        Source - 1-based source number
        Channel - 1-based channel number within source
        ChannelEnabled - 1 for enabled, 0 for disabled
        ChannelRecordingEnabled - 1 for recording enabled, 0 for recording disabled
        NumberOfEvents - number of events for this channel

        Tuple values will be '' or 0s if the channel is not found in the file.
    """
    #Create an instance of PyPL2FileReader.
    p = PyPL2FileReader()

    #Verify that the file passed exists first.
    #Open the file.
    handle = p.pl2_open_file(filename)

    #If the handle is 0, print error message and return 0.
    if (handle == 0):
        print_error(p)
        return 0

    #Create an instance of PL2DigitalChannelInfo.
    echannel_info = PL2DigitalChannelInfo()

    #Check if channel is an integer or string, and call appropriate function
    if type(channel) is int:
        res = p.pl2_get_digital_channel_info(handle, channel, echannel_info)
    if type(channel) is str:
        res = p.pl2_get_digital_channel_info_by_name(handle, channel, echannel_info)

    EventChannelInfo = namedtuple('EventChannelInfo', 'Name Source Channel ChannelEnabled ChannelRecordingEnabled NumberOfEvents')

    return EventChannelInfo(echannel_info.m_Name.decode(), echannel_info.m_Source, echannel_info.m_Channel, echannel_info.m_ChannelEnabled,
                             echannel_info.m_ChannelRecordingEnabled, echannel_info.m_NumberOfEvents)
