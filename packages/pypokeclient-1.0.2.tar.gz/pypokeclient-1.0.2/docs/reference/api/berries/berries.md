---
hide:
    - toc
---

```console
https://pokeapi.co/api/v2/berry/{id or name}/
```

::: pypokeclient._api.berries.berries
    options:
        separate_signature: false
