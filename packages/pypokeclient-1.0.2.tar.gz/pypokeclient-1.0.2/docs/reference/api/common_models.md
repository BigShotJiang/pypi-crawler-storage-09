---
hide:
    - toc
---

::: pypokeclient._api.common_models
    options:
        separate_signature: false
