---
hide:
    - toc
---

```console
https://pokeapi.co/api/v2/encounter-condition/{id or name}/
```

::: pypokeclient._api.encounters.encounter_conditions
    options:
        separate_signature: false
