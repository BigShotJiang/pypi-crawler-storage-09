---
hide:
    - toc
---

```console
https://pokeapi.co/api/v2/evolution-trigger/{id or name}/
```

::: pypokeclient._api.evolution.evolution_triggers
    options:
        separate_signature: false
