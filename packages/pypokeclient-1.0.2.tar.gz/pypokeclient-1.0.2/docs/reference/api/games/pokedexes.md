---
hide:
    - toc
---

```console
https://pokeapi.co/api/v2/pokedex/{id or name}/
```

::: pypokeclient._api.games.pokedexes
    options:
        separate_signature: false
