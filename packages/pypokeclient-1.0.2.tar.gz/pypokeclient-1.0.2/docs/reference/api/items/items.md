---
hide:
    - toc
---

```console
https://pokeapi.co/api/v2/item/{id or name}/
```

::: pypokeclient._api.items.items
    options:
        separate_signature: false
