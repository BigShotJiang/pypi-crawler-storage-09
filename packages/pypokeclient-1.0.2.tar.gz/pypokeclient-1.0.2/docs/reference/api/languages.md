---
hide:
    - toc
---

```console
https://pokeapi.co/api/v2/language/{id or name}/
```

::: pypokeclient._api.languages
    options:
        separate_signature: false
