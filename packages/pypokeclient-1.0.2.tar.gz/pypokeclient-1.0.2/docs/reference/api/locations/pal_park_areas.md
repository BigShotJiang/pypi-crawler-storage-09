---
hide:
    - toc
---

```console
https://pokeapi.co/api/v2/pal-park-area/{id or name}/
```

::: pypokeclient._api.locations.pal_park_areas
    options:
        separate_signature: false
