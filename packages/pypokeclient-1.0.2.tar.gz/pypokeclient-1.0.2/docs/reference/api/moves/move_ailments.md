---
hide:
    - toc
---

```console
https://pokeapi.co/api/v2/move-ailment/{id or name}/
```

::: pypokeclient._api.moves.move_ailments
    options:
        separate_signature: false
