---
hide:
    - toc
---

```console
https://pokeapi.co/api/v2/move-damage-class/{id or name}/
```

::: pypokeclient._api.moves.move_damage_classes
    options:
        separate_signature: false
