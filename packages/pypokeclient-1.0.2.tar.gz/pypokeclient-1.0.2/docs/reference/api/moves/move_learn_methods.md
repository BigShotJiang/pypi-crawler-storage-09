---
hide:
    - toc
---

```console
https://pokeapi.co/api/v2/move-learn-method/{id or name}/
```

::: pypokeclient._api.moves.move_learn_methods
    options:
        separate_signature: false
