---
hide:
    - toc
---

```console
https://pokeapi.co/api/v2/move/{id or name}/
```

::: pypokeclient._api.moves.moves
    options:
        separate_signature: false
