---
hide:
    - toc
---

```console
https://pokeapi.co/api/v2/gender/{id or name}/
```

::: pypokeclient._api.pokemon.genders
    options:
        separate_signature: false
