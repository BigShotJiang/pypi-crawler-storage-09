---
hide:
    - toc
---

```console
https://pokeapi.co/api/v2/pokeathlon-stat/{id or name}/
```

::: pypokeclient._api.pokemon.pokeathlon_stats
    options:
        separate_signature: false
