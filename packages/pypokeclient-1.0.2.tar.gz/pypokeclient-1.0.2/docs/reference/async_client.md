# `AsyncClient` class

Here's the reference information for the `AsyncClient` class.

You can import the `AsyncClient` class directly from `pypokeclient`:
```python
from pypokeclient import AsyncClient
```

---

::: pypokeclient.async_client.AsyncClient
