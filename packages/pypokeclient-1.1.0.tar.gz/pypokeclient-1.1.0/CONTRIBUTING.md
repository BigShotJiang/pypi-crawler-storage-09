Please refer to the [Contributing section](https://ristoale97.github.io/pokeapi-python-wrapper/contributing/) in the documentation.
