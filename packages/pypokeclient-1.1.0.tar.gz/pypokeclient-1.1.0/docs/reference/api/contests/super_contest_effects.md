---
hide:
    - toc
---

```console
https://pokeapi.co/api/v2/super-contest-effect/{id}/
```

::: pypokeclient._api.contests.super_contest_effects
    options:
        separate_signature: false
