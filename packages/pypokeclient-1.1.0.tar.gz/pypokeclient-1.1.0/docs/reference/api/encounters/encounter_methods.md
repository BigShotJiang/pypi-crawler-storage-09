---
hide:
    - toc
---

```console
https://pokeapi.co/api/v2/encounter-method/{id or name}/
```

::: pypokeclient._api.encounters.encounter_methods
    options:
        separate_signature: false
