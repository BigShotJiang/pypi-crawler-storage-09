---
hide:
    - toc
---

```console
https://pokeapi.co/api/v2/version/{id or name}/
```

::: pypokeclient._api.games.version
    options:
        separate_signature: false
