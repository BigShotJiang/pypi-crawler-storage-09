---
hide:
    - toc
---

```console
https://pokeapi.co/api/v2/item-attribute/{id or name}/
```

::: pypokeclient._api.items.item_attributes
    options:
        separate_signature: false
