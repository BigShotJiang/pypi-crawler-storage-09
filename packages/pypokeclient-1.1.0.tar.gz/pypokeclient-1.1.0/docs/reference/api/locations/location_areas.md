---
hide:
    - toc
---

```console
https://pokeapi.co/api/v2/location-area/{id or name}/
```

::: pypokeclient._api.locations.location_areas
    options:
        separate_signature: false
