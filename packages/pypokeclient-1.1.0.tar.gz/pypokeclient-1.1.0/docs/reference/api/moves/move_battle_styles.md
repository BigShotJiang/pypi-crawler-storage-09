---
hide:
    - toc
---

```console
https://pokeapi.co/api/v2/move-battle-style/{id or name}/
```

::: pypokeclient._api.moves.move_battle_styles
    options:
        separate_signature: false
