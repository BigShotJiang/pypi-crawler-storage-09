---
hide:
    - toc
---

```console
https://pokeapi.co/api/v2/move-category/{id or name}/
```

::: pypokeclient._api.moves.move_categories
    options:
        separate_signature: false
