---
hide:
    - toc
---

```console
https://pokeapi.co/api/v2/nature/{id or name}/
```

::: pypokeclient._api.pokemon.natures
    options:
        separate_signature: false
