---
hide:
    - toc
---

```console
https://pokeapi.co/api/v2/type/{id or name}/
```

::: pypokeclient._api.pokemon.types
    options:
        separate_signature: false
