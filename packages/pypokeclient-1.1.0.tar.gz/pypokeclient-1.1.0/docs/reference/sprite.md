# `Sprite` class

Here's the reference information for the `Sprite` dataclass.

---

::: pypokeclient.sprite.Sprite
