"""Module that represents the Machines group."""

from .machines import Machine

__all__ = ["Machine"]
