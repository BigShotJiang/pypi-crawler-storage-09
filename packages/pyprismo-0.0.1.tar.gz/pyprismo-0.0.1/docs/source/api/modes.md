# Mode Solver API

## ModeSolver

```{eval-rst}
.. autoclass:: prismo.modes.solver.ModeSolver
   :members:
   :undoc-members:
```

## WaveguideMode

```{eval-rst}
.. autoclass:: prismo.modes.solver.WaveguideMode
   :members:
   :undoc-members:
```
