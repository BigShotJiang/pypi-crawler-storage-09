# Optimization API

## Parameter Sweep

```{eval-rst}
.. autoclass:: prismo.optimization.sweep.ParameterSweep
   :members:
   :undoc-members:
```

```{eval-rst}
.. autoclass:: prismo.optimization.sweep.SweepParameter
   :members:
   :undoc-members:
```
