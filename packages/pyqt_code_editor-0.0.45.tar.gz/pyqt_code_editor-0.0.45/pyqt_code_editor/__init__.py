"""Fully featured code-editor widgets for PyQt"""

from ._settings import settings

__version__ = '0.0.45'
