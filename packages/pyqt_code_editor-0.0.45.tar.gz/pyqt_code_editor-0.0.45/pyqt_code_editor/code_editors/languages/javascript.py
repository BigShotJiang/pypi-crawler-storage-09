from .generic import Editor as GenericEditor


class Editor(GenericEditor):    
    code_editor_comment_string = '// '
