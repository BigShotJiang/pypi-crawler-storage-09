from .quick_open_dialog import QuickOpenDialog
from .quick_open_file_dialog import QuickOpenFileDialog
from .quick_symbol_dialog import QuickSymbolDialog
from .tabbed_editor import TabbedEditor
from .tab_splitter import TabSplitter
from .dock import Dock