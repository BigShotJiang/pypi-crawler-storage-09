# prompt-toolkit

```{autofile} ../../src/*/prompt_toolkit/*.py
---
module:
---
```

```{autofile} ../../src/*/prompt_toolkit/utils/*.py
---
module:
---
```

```{autofile} ../../src/*/prompt_toolkit/plugins/*.py
---
module:
---
```
