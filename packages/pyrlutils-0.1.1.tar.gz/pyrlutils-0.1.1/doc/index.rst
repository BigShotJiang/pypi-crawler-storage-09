.. PyRLUtils documentation master file, created by
   sphinx-quickstart on Thu Jan  9 14:29:02 2025.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

PyRLUtils documentation
=======================

This is a Python package facilitating the
study of reinforcement learning.


.. toctree::
   :maxdepth: 2
   :caption: Contents:

