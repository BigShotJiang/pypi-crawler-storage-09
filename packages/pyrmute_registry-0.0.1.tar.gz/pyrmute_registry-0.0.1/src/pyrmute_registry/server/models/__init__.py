"""Database models."""

from .schema import SchemaRecord

__all__ = ["SchemaRecord"]
