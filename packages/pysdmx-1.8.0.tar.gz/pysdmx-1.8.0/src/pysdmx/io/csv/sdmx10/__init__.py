"""SDMX CSV 1.0 reader and writer."""
