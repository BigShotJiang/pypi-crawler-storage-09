"""SDMX 2.0 CSV reader and writer."""
