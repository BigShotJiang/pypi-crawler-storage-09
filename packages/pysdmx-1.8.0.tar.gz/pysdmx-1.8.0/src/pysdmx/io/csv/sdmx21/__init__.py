"""SDMX 2.1 CSV reader and writer."""
