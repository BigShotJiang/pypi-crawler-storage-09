# pyshare/main.py

from .ui import main_loop

def main():
    """Main function to run the application."""
    main_loop()

if __name__ == '__main__':
    main()