# This is a legacy file for compatibility with older tools.
# The main configuration is now in pyproject.toml.
from setuptools import setup

if __name__ == "__main__":
    setup()