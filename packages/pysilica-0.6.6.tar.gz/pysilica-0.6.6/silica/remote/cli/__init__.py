"""CLI package for silica."""

__version__ = "0.1.0"
