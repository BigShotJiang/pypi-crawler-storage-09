from .geometry_base import (GeometryModel, SimultanLayer, SimultanVertex, SimultanEdge, SimultanEdgeLoop,
                            SimultanFace, SimultanVolume)

from SIMULTAN.Data.Geometry import Layer, Vertex, Edge, Face, Volume, EdgeLoop
