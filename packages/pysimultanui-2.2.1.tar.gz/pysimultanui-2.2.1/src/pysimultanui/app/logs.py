
def content():
    pass


def static_content():
    pass
