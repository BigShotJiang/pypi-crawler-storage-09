from nicegui import ui


def menu() -> None:
    ui.link('Home', '/')
    ui.link('Project', '/project')
