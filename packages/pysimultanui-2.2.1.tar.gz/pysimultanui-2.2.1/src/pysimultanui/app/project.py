from typing import Optional

from .. import core
from ..core.method_mapper import method_mapper
from nicegui import Client, app, ui, events
from PySimultan2.simultan_object import SimultanObject

from ..views import view_manager


def content():
    pass


def static_content():
    pass
