from PySimultanUI.src.pysimultanui.cli import run_ui

run_ui()
