from PySimultan2 import Content

contents = {}

contents['param_a'] = Content(text_or_key='param_a',
                              property_name='param_a',
                              type=None,
                              unit=None,
                              documentation='param_a')

contents['param_b'] = Content(text_or_key='param_b',
                              property_name='param_b',
                              type=None,
                              unit=None,
                              documentation='param_b')

contents['param_c'] = Content(text_or_key='param_c',
                              property_name='param_c',
                              type=None,
                              unit=None,
                              documentation='param_c')
