"""Tests for pyslingshot package."""
