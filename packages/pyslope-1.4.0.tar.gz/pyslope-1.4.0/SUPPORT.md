## Support for IndeterminateBeam

If you find a bug or have a feature suggestion, please open an issue or contact me at *jessebonanno@gmail.com*.
