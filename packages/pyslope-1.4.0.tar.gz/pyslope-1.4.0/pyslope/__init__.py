from pyslope.pyslope import (
    Material,
    Udl,
    LineLoad,
    Slope,
)
from . import _version

__version__ = _version.get_versions()["version"]
