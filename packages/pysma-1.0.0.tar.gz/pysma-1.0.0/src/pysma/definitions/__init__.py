"""Sensor definitions."""
