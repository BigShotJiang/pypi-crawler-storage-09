# PySynClient
Automatically detects the location of the synology drive client folders and returns its parent location
