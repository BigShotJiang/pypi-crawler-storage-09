from pysynclient.client.server_paths import get_server_paths
