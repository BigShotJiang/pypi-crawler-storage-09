"""Tests for pysz package."""
