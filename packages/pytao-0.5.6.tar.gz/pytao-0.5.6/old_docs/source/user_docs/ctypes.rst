ctypes
======

A ctypes based python module for interfacing *Tao* to Python is provided via
`pytao.tao_ctypes`.

.. autoclass:: pytao.tao_ctypes.core.Tao
   :members:
   :undoc-members:
   :noindex:
