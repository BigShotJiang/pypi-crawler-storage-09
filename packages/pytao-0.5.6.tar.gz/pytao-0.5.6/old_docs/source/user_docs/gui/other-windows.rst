Other Windows
=============

Global Variable Window
----------------------

Global variables in *Tao* can be viewed and modified from the global variables
window as shown in Figure \ref{fig:gui.global.variables}.
Once you have edited the global variables, clicking the "Set Global Variables"
button will set the variables in *Tao* as appropriate.


.. figure:: /_static/gui/figures/globals_1.png
   :align: center
   :alt: View and edit global variables with the Global Parameters window.

.. figure:: /_static/gui/figures/globals_2.png
   :align: center
   :alt: View and edit global variables with the Global Parameters window.
