def test_imports():
    import pytao.gui

    pytao.gui.tao_root_window
