Licenses
========

This directory holds license and credit information for works this plugin is derived from or distributes, and/or datasets.

The license file for this package itself is placed in the root directory of this repository.
