### pytest-embedded

A pytest plugin for embedded systems. Could activate different services for extra functionalities.
