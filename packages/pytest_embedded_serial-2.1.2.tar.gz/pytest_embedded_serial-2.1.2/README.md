### pytest-embedded-serial

pytest embedded service for testing via serial ports

Extra Functionalities:

- `serial`: enable the fixture
- `dut`: duplicate the `serial` output to `pexpect_proc`.
