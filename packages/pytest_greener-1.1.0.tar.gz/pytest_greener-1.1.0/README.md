# Greener Pytest Plugin 
> Main project repo: [Greener](https://github.com/cephei8/greener)

Pytest plugin for [Greener](https://github.com/cephei8/greener).

## Contributing
See [CONTRIBUTING.md](./CONTRIBUTING.md).

## License
This project is licensed under the terms of the [Apache License 2.0](./LICENSE).
