import logging

logging.getLogger("urllib3").setLevel(logging.CRITICAL)
