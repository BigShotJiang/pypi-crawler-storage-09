# pytest-no-problem

[![PyPI - Version](https://img.shields.io/pypi/v/pytest-no-problem.svg)](https://pypi.python.org/pypi/pytest-no-problem)
[![PyPI - License](https://img.shields.io/pypi/l/pytest-no-problem.svg)](https://codeberg.org/benba/pytest-no-problem/src/branch/main/LICENSE)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/pytest-no-problem.svg)](https://pypi.python.org/pypi/pytest-no-problem)

Pytest plugin to tell you when there's no problem
