from pytest_no_problem.plugin import pytest_terminal_summary

__all__ = ("pytest_terminal_summary",)
