# https://python.useinstructor.com/modes-comparison/#best-practices
