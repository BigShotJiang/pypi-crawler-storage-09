# Changelog

## Unreleased

## 0.1.1 - 2025-10-18
- Minor improvements of examples, documentation, settings.

## 0.1.0 - 2025-10-17
- Initial release: simple Calculator API (Operation, Registry, utils) with good practices for coding project such as testing, documentation, type checking, CI/CD for tests and documentation…
