from ..child_type_register import ChildTypeRegister

characterized_definition_register = ChildTypeRegister('CHARACTERIZED_DEFINITION')
unit_register = ChildTypeRegister('UNIT')
color_register = ChildTypeRegister('COLOUR')
surface_style_register = ChildTypeRegister('SURFACE_STYLE')
representation_register = ChildTypeRegister('REPRESENTATION')