from .factory import WialonObjectFactory
