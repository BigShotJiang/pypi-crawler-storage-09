from .functions_pass import func_proc

__all__ = ["func_proc"]
