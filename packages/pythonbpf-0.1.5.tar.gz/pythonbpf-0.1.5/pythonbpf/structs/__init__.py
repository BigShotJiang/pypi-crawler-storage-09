from .structs_pass import structs_proc

__all__ = ["structs_proc"]
