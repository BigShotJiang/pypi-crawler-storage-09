from .import_detector import vmlinux_proc

__all__ = ["vmlinux_proc"]
