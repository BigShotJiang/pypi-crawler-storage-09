from .ir_generation import IRGenerator

__all__ = ["IRGenerator"]
