---
name: "\U0001F4DA Documentation"
about: Report an issue, comment or suggestion related to project's docs
labels: "docs"
---

## 📚 Documentation

<!-- Describe your issue, comment or suggestion related to Ignite's docs: https://pytorch.org/ignite/, CONTRIBUTING.md and other documentations. Thank you! -->
