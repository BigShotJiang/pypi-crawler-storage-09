---
name: "\U0001F44D User feedback"
about: Say thanks or why you don't like
title: ""
labels: ""
assignees: ""
---

> This is a place to leave any feedback on this package.
> If you like the work, feel free to say thanks here
> If you do not like something, please, share it with us and we can see how to improve
> Thank you !
