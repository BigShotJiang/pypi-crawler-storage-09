ignite.contrib.handlers
=======================

Contribution module of handlers


Parameter scheduler [deprecated]
--------------------------------

.. deprecated:: 0.4.4
   Use :class:`~ignite.handlers.param_scheduler.ParamScheduler` instead, will be removed in version 0.6.0.

   Was moved to :ref:`param-scheduler-label`.

LR finder [deprecated]
----------------------

.. deprecated:: 0.4.4
    Use :class:`~ignite.handlers.lr_finder.FastaiLRFinder` instead, will be removed in version 0.6.0.

Time profilers [deprecated]
---------------------------

.. deprecated:: 0.4.6
    Use :class:`~ignite.handlers.time_profilers.BasicTimeProfiler` instead, will be removed in version 0.6.0.
    Use :class:`~ignite.handlers.time_profilers.HandlersTimeProfiler` instead, will be removed in version 0.6.0.

Loggers [deprecated]
--------------------

.. deprecated:: 0.5.0
    Loggers moved to :ref:`Loggers`.
