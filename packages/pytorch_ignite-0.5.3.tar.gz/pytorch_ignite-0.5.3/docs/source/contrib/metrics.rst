ignite.contrib.metrics
=======================

Contrib module metrics [deprecated]
-----------------------------------

.. deprecated:: 0.5.0
    All metrics moved to :ref:`Complete list of metrics`.


Regression metrics [deprecated]
--------------------------------

.. deprecated:: 0.5.0
    All metrics moved to :ref:`Complete list of metrics`.
