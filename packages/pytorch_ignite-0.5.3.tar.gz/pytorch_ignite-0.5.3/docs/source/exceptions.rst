ignite.exceptions
=================

.. currentmodule:: ignite.exceptions

.. autosummary::
    :nosignatures:
    :autolist:

.. autoclass:: NotComputableError
