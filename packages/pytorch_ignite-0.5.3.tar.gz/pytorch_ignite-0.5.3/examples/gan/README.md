# Deep Convolution Generative Adversarial Networks with Ignite

ported from [pytorch-examples](https://github.com/pytorch/examples/tree/master/dcgan)

Usage:

For example, run on CIFAR10 dataset:

```
python dcgan.py --dataset cifar10 --dataroot /tmp/cifar10 --output-dir /tmp/outputs-dcgan
```
