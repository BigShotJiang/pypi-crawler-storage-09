# Reinforcement learning training examples with Ignite

ported from [pytorch-examples](https://github.com/pytorch/examples/tree/master/reinforcement_learning)

```bash
pip install gymnasium
# For REINFORCE:
python reinforce.py
# For actor critic:
python actor_critic.py
```
