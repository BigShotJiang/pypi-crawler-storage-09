# Siamese Network example on MNIST dataset

This example is ported over from [pytorch/examples/siamese_network](https://github.com/pytorch/examples/tree/main/siamese_network)

Usage:

```
pip install -r requirements.txt
python siamese_network.py
```
