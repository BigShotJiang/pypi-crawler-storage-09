# makre sure to detach the tensor and disable the gradient computation
# https://stackoverflow.com/questions/63582590/why-do-we-call-detach-before-calling-numpy-on-a-pytorch-tensor/63869655#63869655

# dont use torch.tensor, it always copies data
