ANONYMOUS = 'anonymous'
BASIC = 'ivo://ivoa.net/sso#BasicAA'
CLIENT_CERTIFICATE = 'ivo://ivoa.net/sso#tls-with-certificate'
COOKIE = 'ivo://ivoa.net/sso#cookie'
