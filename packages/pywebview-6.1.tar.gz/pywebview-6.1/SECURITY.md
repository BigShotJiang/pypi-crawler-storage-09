# Security Policy

## Supported Versions

Versions lower than 3.0 are not supported.

| Version | Supported          |
| ------- | ------------------ |
| 3.x   | :white_check_mark: |
| < 3.0    | :x:                |

## Reporting a Vulnerability

If you find a vulnerability in the pywebview code, please get in touch via [roman@flowrl.com](mailto:roman@flowrl.com).
Please do not report any vulnerabilities in the node_modules dependencies of the pywebview website.
