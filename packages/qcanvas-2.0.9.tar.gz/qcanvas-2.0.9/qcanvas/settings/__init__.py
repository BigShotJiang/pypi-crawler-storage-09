from ._client_settings import _ClientSettings
from ._ui_settings import _UISettings
from ._course_settings import course_configs

client = _ClientSettings()
ui = _UISettings()
