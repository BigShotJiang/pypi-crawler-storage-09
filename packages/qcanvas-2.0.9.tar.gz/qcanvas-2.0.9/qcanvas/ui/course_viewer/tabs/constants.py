date_strftime_format = "%A, %Y-%m-%d, %H:%M:%S"
