"""QCC - Quick Claude Config Manager"""

__version__ = "0.5.0"
__author__ = "QCC Team"
__description__ = "🚀 现代化 Claude Code 配置管理神器 - 多 endpoint 代理服务，智能负载均衡，自动故障转移"