"""
QCC Web UI 后端模块
提供 FastAPI Web 服务,支持所有 CLI 功能的 REST API 接口
"""

__version__ = "1.0.0"
