"""RIKEN native shared protocol buffer definitions and schemas."""
