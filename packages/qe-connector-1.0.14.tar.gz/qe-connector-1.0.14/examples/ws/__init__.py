"""
WebSocket示例模块
"""
