#ifndef EIGEN_MOREVECTORIZATION_MODULE_H
#error "Please include unsupported/Eigen/MoreVectorization instead of including headers inside the src directory directly."
#endif
