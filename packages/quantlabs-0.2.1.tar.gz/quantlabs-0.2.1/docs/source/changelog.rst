Changelog
=========

See `GitHub Releases <https://github.com/nittygritty-zzy/quantlab/releases>`_ for detailed changelog.
