Contributing
============

Contributions are welcome! Please see the `GitHub repository <https://github.com/nittygritty-zzy/quantlab>`_ for details.
