Data Management Guide
=====================

Detailed data management documentation coming soon.

See :doc:`../installation` for data setup.
