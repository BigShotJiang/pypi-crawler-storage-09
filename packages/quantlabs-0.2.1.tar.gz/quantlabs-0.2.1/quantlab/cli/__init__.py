"""
Command-line interface for QuantLab
"""

from .main import cli

__all__ = ["cli"]
