Custom Factors
==============

Documentation coming soon.
