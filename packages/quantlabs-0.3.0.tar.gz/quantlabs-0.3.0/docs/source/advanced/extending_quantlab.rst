Extending QuantLab
==================

Documentation coming soon.
