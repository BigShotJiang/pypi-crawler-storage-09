Data API
========

.. automodule:: quantlab.data.data_manager
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: quantlab.data.api_clients
   :members:
   :undoc-members:
   :show-inheritance:
