Backtesting Guide
=================

Detailed backtesting documentation coming soon.

See :doc:`../quickstart` for basic backtest examples.
