"""
CLI Test Suite
"""
