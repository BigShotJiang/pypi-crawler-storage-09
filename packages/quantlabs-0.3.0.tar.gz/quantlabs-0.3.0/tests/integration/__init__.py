"""
Integration Test Suite

Tests CLI commands with real components (no mocking).
"""
