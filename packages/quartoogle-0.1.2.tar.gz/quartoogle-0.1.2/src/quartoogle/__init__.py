"""Quartoogle - Compile quarto docs directly to Google Drive."""

from quartoogle.api import publish

__version__ = "0.1.0"

__all__ = ["publish"]
