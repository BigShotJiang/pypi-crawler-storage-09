## QuartzBio Login for Dash Apps

This module is based off the [dash_auth](https://github.com/plotly/dash-auth/) package and provides OAuth2-based login support for Dash apps.

About Dash: [https://plot.ly/dash/](https://plot.ly/dash/)

License: MIT
