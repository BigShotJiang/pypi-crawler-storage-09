# Note that this file is multi-lingual and can be used in both Python
# and POSIX shell.

# This file should define a variable VERSION which we use as the
# debugger version number.
VERSION = "1.2.0"
