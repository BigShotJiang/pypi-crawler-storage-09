# quaxed.numpy

::: quaxed.numpy
