"""Test `quaxed.lax`."""
