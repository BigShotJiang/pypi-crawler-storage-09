"""Test `quaxed.numpy`."""
