"""Test `quaxed.scipy`."""
