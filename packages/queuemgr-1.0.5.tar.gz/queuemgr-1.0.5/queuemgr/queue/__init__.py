"""
Queue implementation for the queue manager system.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""
