"""QuickScale meta package

This package is intentionally empty; it only exists to group the quickscale-core
and quickscale-cli packages so a single install pulls both.
"""

__all__ = []
