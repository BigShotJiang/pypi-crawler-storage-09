# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from ractorlabs import Ractorlabs, AsyncRactorlabs
from tests.utils import assert_matches_type
from ractorlabs.types import LoginResponse, AuthRetrieveCurrentPrincipalResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestAuth:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_create_token(self, client: Ractorlabs) -> None:
        auth = client.auth.create_token(
            principal="principal",
            type="User",
        )
        assert_matches_type(LoginResponse, auth, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_create_token_with_all_params(self, client: Ractorlabs) -> None:
        auth = client.auth.create_token(
            principal="principal",
            type="User",
            ttl_hours=0,
        )
        assert_matches_type(LoginResponse, auth, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_create_token(self, client: Ractorlabs) -> None:
        response = client.auth.with_raw_response.create_token(
            principal="principal",
            type="User",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        auth = response.parse()
        assert_matches_type(LoginResponse, auth, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_create_token(self, client: Ractorlabs) -> None:
        with client.auth.with_streaming_response.create_token(
            principal="principal",
            type="User",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            auth = response.parse()
            assert_matches_type(LoginResponse, auth, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_retrieve_current_principal(self, client: Ractorlabs) -> None:
        auth = client.auth.retrieve_current_principal()
        assert_matches_type(AuthRetrieveCurrentPrincipalResponse, auth, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_retrieve_current_principal(self, client: Ractorlabs) -> None:
        response = client.auth.with_raw_response.retrieve_current_principal()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        auth = response.parse()
        assert_matches_type(AuthRetrieveCurrentPrincipalResponse, auth, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_retrieve_current_principal(self, client: Ractorlabs) -> None:
        with client.auth.with_streaming_response.retrieve_current_principal() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            auth = response.parse()
            assert_matches_type(AuthRetrieveCurrentPrincipalResponse, auth, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncAuth:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_create_token(self, async_client: AsyncRactorlabs) -> None:
        auth = await async_client.auth.create_token(
            principal="principal",
            type="User",
        )
        assert_matches_type(LoginResponse, auth, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_create_token_with_all_params(self, async_client: AsyncRactorlabs) -> None:
        auth = await async_client.auth.create_token(
            principal="principal",
            type="User",
            ttl_hours=0,
        )
        assert_matches_type(LoginResponse, auth, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_create_token(self, async_client: AsyncRactorlabs) -> None:
        response = await async_client.auth.with_raw_response.create_token(
            principal="principal",
            type="User",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        auth = await response.parse()
        assert_matches_type(LoginResponse, auth, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_create_token(self, async_client: AsyncRactorlabs) -> None:
        async with async_client.auth.with_streaming_response.create_token(
            principal="principal",
            type="User",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            auth = await response.parse()
            assert_matches_type(LoginResponse, auth, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_retrieve_current_principal(self, async_client: AsyncRactorlabs) -> None:
        auth = await async_client.auth.retrieve_current_principal()
        assert_matches_type(AuthRetrieveCurrentPrincipalResponse, auth, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_retrieve_current_principal(self, async_client: AsyncRactorlabs) -> None:
        response = await async_client.auth.with_raw_response.retrieve_current_principal()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        auth = await response.parse()
        assert_matches_type(AuthRetrieveCurrentPrincipalResponse, auth, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_retrieve_current_principal(self, async_client: AsyncRactorlabs) -> None:
        async with async_client.auth.with_streaming_response.retrieve_current_principal() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            auth = await response.parse()
            assert_matches_type(AuthRetrieveCurrentPrincipalResponse, auth, path=["response"])

        assert cast(Any, response.is_closed) is True
