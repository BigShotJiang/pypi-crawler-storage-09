// SPDX-License-Identifier: LGPL-3.0-only

#define BOOST_TEST_MODULE radler_algorithms

#include <boost/test/unit_test.hpp>