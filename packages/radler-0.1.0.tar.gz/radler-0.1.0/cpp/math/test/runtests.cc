// SPDX-License-Identifier: LGPL-3.0-only

#define BOOST_TEST_MODULE radler_math

#include <boost/test/unit_test.hpp>