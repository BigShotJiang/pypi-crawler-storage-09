// SPDX-License-Identifier: LGPL-3.0-only

#define BOOST_TEST_MODULE radler_main

#include <boost/test/unit_test.hpp>