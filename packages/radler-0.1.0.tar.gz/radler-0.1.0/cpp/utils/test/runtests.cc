// SPDX-License-Identifier: LGPL-3.0-only

#define BOOST_TEST_MODULE radler_utils

#include <boost/test/unit_test.hpp>
