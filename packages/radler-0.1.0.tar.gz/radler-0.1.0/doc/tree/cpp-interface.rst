C++ interface
=============

The following sections describe the most important parts of the Radler C++ API.

.. toctree::
   :maxdepth: 1

   cpp/algorithms
   cpp/settings
