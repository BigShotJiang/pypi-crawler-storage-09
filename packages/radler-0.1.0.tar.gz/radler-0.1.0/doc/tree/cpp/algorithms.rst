.. _radler::algorithms:

Algorithms
====================

.. doxygenenum:: AlgorithmType
