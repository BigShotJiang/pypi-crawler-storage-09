.. _radler::settings:

Settings
====================

.. doxygenstruct:: radler::Settings
   :members:
