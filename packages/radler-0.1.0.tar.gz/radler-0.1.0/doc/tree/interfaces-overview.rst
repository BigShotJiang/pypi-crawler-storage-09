Interface overview
======================

Radler is primarily written in ``C++``. If Radler was compiled with ``BUILD_PYTHON_BINDINGS=ON``
Python bindings are generated to interface the Radler API from within Python. The next sections describe the
``C++`` and the ``Python`` interface.
