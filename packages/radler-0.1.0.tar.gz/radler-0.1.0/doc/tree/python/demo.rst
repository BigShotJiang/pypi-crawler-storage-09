.. _python-demo-label:

Python demo
===========

.. literalinclude:: ../../../python/demo/simple-interface.py
