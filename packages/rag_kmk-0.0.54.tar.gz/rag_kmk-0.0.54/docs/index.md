# Welcome to rag_kmk


[![image](https://img.shields.io/pypi/v/rag_kmk.svg)](https://pypi.python.org/pypi/rag_kmk)


**A simple RAG implementation for educational purposes implemented by Murat Karakaya Akademi**


-   Free software: MIT License
-   Documentation: <https://kmkarakaya.github.io/rag-kmk>
    

## Features

-   TODO

## Requirements
# Retrieve GOOGLE_API_KEY from system environment variables
-  Needs a GOOGLE API KEY stored in the system environment variables as GOOGLE_API_KEY or you can enter your key when requested.
