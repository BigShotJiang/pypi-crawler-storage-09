"""Tests for raincloudpy package."""
