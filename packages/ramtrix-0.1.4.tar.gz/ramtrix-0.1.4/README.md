# my-matrix-lib

A Python library for manipulating matrices while boiling your RAM.(I promise the core functions are actually optimized and WONT boil your RAM...you still have the option though)

## Installation

```bash
pip Ramtrix