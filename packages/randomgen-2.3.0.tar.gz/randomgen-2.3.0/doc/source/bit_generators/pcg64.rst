Permuted Congruential Generator (64-bit, PCG64)
-----------------------------------------------

.. module:: randomgen.pcg64

.. currentmodule:: randomgen.pcg64

.. autoclass:: PCG64

Seeding and State
=================

.. autosummary::
   :toctree: generated/

   ~PCG64.seed
   ~PCG64.state

Parallel generation
===================
.. autosummary::
   :toctree: generated/

   ~PCG64.advance
   ~PCG64.jump
   ~PCG64.jumped

Extending
=========
.. autosummary::
   :toctree: generated/

   ~PCG64.cffi
   ~PCG64.ctypes

Testing
=======
.. autosummary::
   :toctree: generated/

   ~PCG64.random_raw
