from abc import ABCMeta, abstractmethod
from collections.abc import Sequence
from typing import Any

from numpy import unsignedinteger

DEFAULT_POOL_SIZE: int

class ISeedSequence(metaclass=ABCMeta):
    @abstractmethod
    def generate_state(
        self,
        n_words: int,
        dtype: type[unsignedinteger[Any]] = ...,
    ) -> Sequence[int]: ...

class ISpawnableSeedSequence(ISeedSequence, metaclass=ABCMeta):
    @abstractmethod
    def spawn(self, n_children: int) -> list[SeedSequence]: ...

class SeedSequence(ISpawnableSeedSequence):
    def __init__(
        self,
        entropy: int | Sequence[int] | None = ...,
        *,
        spawn_key: Sequence[int] = ...,
        pool_size: int = ...,
        n_children_spawned: int = ...,
    ) -> None: ...
    @property
    def state(self) -> dict[str, int | Sequence[int]]: ...
    def generate_state(
        self,
        n_words: int,
        dtype: type[unsignedinteger[Any]] = ...,
    ) -> Sequence[int]: ...
    def spawn(self, n_children: int) -> list[SeedSequence]: ...

class SeedlessSeedSequence(ISeedSequence):
    def generate_state(
        self,
        n_words: int,
        dtype: type[unsignedinteger[Any]] = ...,
    ) -> Sequence[int]: ...
    def spawn(self, n_children: int) -> list[SeedlessSeedSequence]: ...
