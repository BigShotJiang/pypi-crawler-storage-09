import numpy as np

from randomgen.common import BitGenerator
from randomgen.typing import IntegerSequenceSeed

class LXM(BitGenerator):
    def __init__(
        self,
        seed: IntegerSequenceSeed | None = ...,
        *,
        b: int = ...,
    ) -> None: ...
    def seed(self, seed: IntegerSequenceSeed | None = ...) -> None: ...
    def jump(self, iter: int = ...) -> LXM: ...
    def jumped(self, iter: int = ...) -> LXM: ...
    @property
    def state(
        self,
    ) -> dict[str, str | int | dict[str, int | np.ndarray]]: ...
    @state.setter
    def state(
        self,
        value: dict[str, str | int | dict[str, int | np.ndarray]],
    ) -> None: ...
