from typing import Literal

from randomgen.common import BitGenerator
from randomgen.typing import IntegerSequenceSeed, SeedMode

DEFAULT_MULTIPLIER: int
DEFAULT_DXSM_MULTIPLIER: int

class PCG64(BitGenerator):
    def __init__(
        self,
        seed: IntegerSequenceSeed | None = ...,
        inc: int | None = ...,
        *,
        variant: Literal[
            "xsl-rr",
            "1.0",
            1,
            "dxsm",
            "cm-dxsm",
            2,
            "2.0",
            "dxsm-128",
        ] = ...,
        mode: SeedMode | None = ...,
    ) -> None: ...
    def seed(
        self,
        seed: IntegerSequenceSeed | None = ...,
        inc: int | None = ...,
    ) -> None: ...
    @property
    def state(self) -> dict[str, str | int | dict[str, int]]: ...
    @state.setter
    def state(self, value: dict[str, str | int | dict[str, int]]) -> None: ...
    def advance(self, delta: int) -> PCG64: ...
    def jump(self, iter: int = ...) -> PCG64: ...
    def jumped(self, iter: int = ...) -> PCG64: ...

class LCG128Mix(BitGenerator):
    def __init__(
        self,
        seed: IntegerSequenceSeed | None = ...,
        inc: int | None = ...,
        *,
        multiplier: int = ...,
        output: str | int = ...,
        dxsm_multiplier: int = ...,
        post: bool = ...,
    ) -> None: ...
    def seed(
        self,
        seed: IntegerSequenceSeed | None = ...,
        inc: int | None = ...,
    ) -> None: ...
    @property
    def state(self) -> dict[str, str | int | dict[str, bool | int | str]]: ...
    @state.setter
    def state(
        self,
        value: dict[str, str | int | dict[str, bool | int | str]],
    ) -> None: ...
    def advance(self, delta: int) -> LCG128Mix: ...
    def jumped(self, iter: int = ...) -> LCG128Mix: ...

class PCG64DXSM(PCG64):
    def __init__(
        self,
        seed: IntegerSequenceSeed | None = ...,
        inc: int | None = ...,
    ) -> None: ...
    @property
    def state(self) -> dict[str, str | int | dict[str, int]]: ...
    @state.setter
    def state(self, value: dict[str, str | int | dict[str, int]]) -> None: ...
    def jumped(self, iter: int = ...) -> PCG64DXSM: ...
    def jump(self, iter: int = ...) -> PCG64DXSM: ...
