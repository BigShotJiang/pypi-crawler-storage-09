import numpy as np

from randomgen.common import BitGenerator
from randomgen.typing import IntegerSequenceSeed, SeedMode

class Xoroshiro128(BitGenerator):
    def __init__(
        self,
        seed: IntegerSequenceSeed | None = ...,
        *,
        mode: SeedMode = ...,
        plusplus: bool = ...,
    ) -> None: ...
    def seed(self, seed: IntegerSequenceSeed | None = ...) -> None: ...
    def jump(self, iter: int = ...) -> Xoroshiro128: ...
    def jumped(self, iter: int = ...) -> Xoroshiro128: ...
    @property
    def state(self) -> dict[str, str | np.ndarray | bool | int]: ...
    @state.setter
    def state(self, value: dict[str, str | np.ndarray | bool | int]) -> None: ...
