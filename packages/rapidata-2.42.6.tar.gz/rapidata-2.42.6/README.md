# Rapidata Python Client

Python client to interface with the Rapidata API.

Docs: https://docs.rapidata.ai/
