# -*- encoding: utf-8 -*-
# @Author: SWHL
# @Contact: levsion@163.com
from .rapid_ocr_api import RapidOCR
from .utils import LoadImageError
