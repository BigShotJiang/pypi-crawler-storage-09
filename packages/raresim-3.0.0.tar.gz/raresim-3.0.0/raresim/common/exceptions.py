class IllegalArgumentException(Exception):
    pass

class RaresimException(Exception):
    pass
