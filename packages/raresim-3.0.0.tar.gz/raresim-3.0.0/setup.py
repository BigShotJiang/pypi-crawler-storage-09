from setuptools import setup

# This file is maintained for backward compatibility
# The main configuration is in pyproject.toml

if __name__ == "__main__":
    setup()
