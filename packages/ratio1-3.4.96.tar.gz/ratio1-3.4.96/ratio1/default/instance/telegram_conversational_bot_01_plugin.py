from ...base import Instance
from ...const import PLUGIN_SIGNATURES

class TelegramConversationalBot01(Instance):
  signature = PLUGIN_SIGNATURES.TELEGRAM_CONVERSATIONAL_BOT_01


