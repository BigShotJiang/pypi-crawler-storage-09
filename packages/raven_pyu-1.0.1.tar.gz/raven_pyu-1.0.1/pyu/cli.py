def main():
    print("Raven Profiler CLI")
