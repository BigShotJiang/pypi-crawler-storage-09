from textual.widgets import RichLog


class RichLogBox(RichLog, can_focus=False):
    pass
