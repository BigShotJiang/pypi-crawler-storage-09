
from rcsb_embedding_model.dataset.untils.utils import get_structure_location

__all__ = ["get_structure_location"]
