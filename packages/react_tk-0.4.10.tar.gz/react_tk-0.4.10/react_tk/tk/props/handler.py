from typing import Callable


type CommandHandler = Callable[[], None]
