"""Tests for realtimex package."""
