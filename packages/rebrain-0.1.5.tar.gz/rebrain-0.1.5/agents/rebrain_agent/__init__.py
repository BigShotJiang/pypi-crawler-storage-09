"""
Rebrain Google ADK Agent.

Agent for testing and UI interaction with rebrain memory system.
"""

from agents.rebrain_agent.agent import create_rebrain_agent

__all__ = ["create_rebrain_agent"]

