"""Core utilities for the rebrain package."""

from rebrain.core.genai_client import GenAIClient

__all__ = ["GenAIClient"]

