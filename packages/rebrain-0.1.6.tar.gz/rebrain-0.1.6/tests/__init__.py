"""Test suite for rebrain."""

