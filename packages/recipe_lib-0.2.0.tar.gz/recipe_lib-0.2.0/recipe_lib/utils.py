# Utility functions placeholder
