*********
LLM Cache
*********

SemanticCache
=============

.. _semantic_cache_api:

.. currentmodule:: redisvl.extensions.cache.llm

.. autoclass:: SemanticCache
   :show-inheritance:
   :members:
   :inherited-members:


****************
Embeddings Cache
****************

EmbeddingsCache
===============

.. _embeddings_cache_api:

.. currentmodule:: redisvl.extensions.cache.embeddings

.. autoclass:: EmbeddingsCache
   :show-inheritance:
   :members:
   :inherited-members:
