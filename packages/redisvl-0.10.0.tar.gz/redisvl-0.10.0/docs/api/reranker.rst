***********
Rerankers
***********

CohereReranker
==============

.. _coherereranker_api:

.. currentmodule:: redisvl.utils.rerank.cohere

.. autoclass:: CohereReranker
   :show-inheritance:
   :members:


HFCrossEncoderReranker
======================

.. _hfcrossencoderreranker_api:

.. currentmodule:: redisvl.utils.rerank.hf_cross_encoder

.. autoclass:: HFCrossEncoderReranker
   :show-inheritance:
   :members:


VoyageAIReranker
================

.. _voyageaireranker_api:

.. currentmodule:: redisvl.utils.rerank.voyageai

.. autoclass:: VoyageAIReranker
   :show-inheritance:
   :members:
