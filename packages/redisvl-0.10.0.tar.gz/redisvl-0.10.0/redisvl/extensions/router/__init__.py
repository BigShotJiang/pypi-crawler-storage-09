from redisvl.extensions.router.schema import Route, RoutingConfig
from redisvl.extensions.router.semantic import SemanticRouter

__all__ = ["SemanticRouter", "Route", "RoutingConfig"]
