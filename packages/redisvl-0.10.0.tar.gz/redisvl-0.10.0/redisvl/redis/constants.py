# required modules
DEFAULT_REQUIRED_MODULES = [
    {"name": "search", "ver": 20600},
    {"name": "searchlight", "ver": 20600},
]

# default tag separator
REDIS_TAG_SEPARATOR = ","


REDIS_URL_ENV_VAR = "REDIS_URL"
