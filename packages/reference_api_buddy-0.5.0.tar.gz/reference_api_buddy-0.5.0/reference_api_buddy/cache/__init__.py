"""Cache module initializer."""
