"""Core module initializer."""
