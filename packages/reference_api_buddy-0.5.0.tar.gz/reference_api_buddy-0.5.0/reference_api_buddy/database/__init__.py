"""Database module initializer."""
