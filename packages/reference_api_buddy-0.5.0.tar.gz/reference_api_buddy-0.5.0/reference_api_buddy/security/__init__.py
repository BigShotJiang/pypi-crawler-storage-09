"""Security module initializer."""
