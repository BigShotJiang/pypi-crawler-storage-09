"""Utils module initializer."""
