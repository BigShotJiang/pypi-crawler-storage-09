"""Lucide Icon Component."""

from .icon import Icon

icon = Icon.create
