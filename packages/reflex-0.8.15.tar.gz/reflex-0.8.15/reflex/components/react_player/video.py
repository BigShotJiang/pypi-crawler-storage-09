"""A video component."""

from reflex.components.react_player.react_player import ReactPlayer


class Video(ReactPlayer):
    """Video component share with audio component."""
