
import sympy as sp
from itertools import product
import numpy

