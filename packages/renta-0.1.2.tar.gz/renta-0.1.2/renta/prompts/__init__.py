"""
Prompt templates for RENTA AI analysis system.

This package contains Jinja2 templates for generating AI prompts
for property investment analysis.
"""
