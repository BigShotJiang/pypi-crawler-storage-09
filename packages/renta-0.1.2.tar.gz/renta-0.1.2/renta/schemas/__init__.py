"""JSON schemas package for RENTA."""
