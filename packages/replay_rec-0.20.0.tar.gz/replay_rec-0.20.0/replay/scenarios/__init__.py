"""
Scenarios are a series of actions for recommendations
"""

from .fallback import Fallback
