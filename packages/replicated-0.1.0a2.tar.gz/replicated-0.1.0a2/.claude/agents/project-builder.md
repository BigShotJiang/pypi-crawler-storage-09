---
name: project-builder
description: MUST USE THIS AGENT PROACTIVELY when attempting to build, test, or run the project
model: sonnet
---

