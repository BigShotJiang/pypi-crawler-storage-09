"""Languages package for replink.

This package contains implementations of different language support for REPLs.
Currently only Python is supported.
"""
