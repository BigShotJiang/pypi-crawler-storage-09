"""Target package for replink.

This package contains implementations of different targets that replink can send to.
Supported targets: tmux, zellij
"""
