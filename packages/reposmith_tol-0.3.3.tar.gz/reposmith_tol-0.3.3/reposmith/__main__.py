"""
Entry point for `python -m reposmith`
"""

from . import main

if __name__ == "__main__":
    main.main()
