*************************
Non-celestial images/data
*************************

Non-celestial images/data are not currently supported but will be added in future releases.
