function(keys, values) {
  return values.every(function (element, index, array) {return element})
}