# StatusInput

Custom enum for the analysis status

## Enum

* `UPLOADED` (value: `'Uploaded'`)

* `QUEUED` (value: `'Queued'`)

* `COMPLETE` (value: `'Complete'`)

* `ERROR` (value: `'Error'`)

* `PROCESSING` (value: `'Processing'`)

* `ALL` (value: `'All'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


