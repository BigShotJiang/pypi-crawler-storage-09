"""Mock objects for testing"""
