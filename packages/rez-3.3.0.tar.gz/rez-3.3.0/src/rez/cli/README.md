
To add a new command:

* Add relevant file here (eg foo.py), impl setup_parser/command functions.
* Add to _entry_points.py
* Update _util.py: subcommands
