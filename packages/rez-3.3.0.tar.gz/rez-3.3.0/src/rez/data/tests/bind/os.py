"""
Custom bind module override
"""
