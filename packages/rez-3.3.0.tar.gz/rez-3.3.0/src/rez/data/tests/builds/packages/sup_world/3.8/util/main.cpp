#include <iostream>
#include "spanish_greet.h"

using namespace supworld;


int main(int argc, char** argv)
{
	std::cout << spanish_greet() << std::endl;
	return 0;
}
