def hello():
    return "This shirt was $150 out the door and the pattern's not that complicated"
