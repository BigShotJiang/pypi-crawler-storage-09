release_hooks = ["foo"]

plugins = {
    "release_hook": {
        "emailer": {
            "recipients": ["joe@here.com"]
        }
    }
}
