def add_eek_var(env):
    env.EEK = "2"
