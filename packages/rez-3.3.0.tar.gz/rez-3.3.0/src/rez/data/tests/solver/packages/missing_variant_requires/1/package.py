name = "missing_variant_requires"
version = "1"

def commands():
    pass

variants = [
    ["noexist"],
    ["nada"]
]
