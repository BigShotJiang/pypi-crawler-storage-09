name = "nopy"
version = "2.1"

requires = ["!python-2.5"]
