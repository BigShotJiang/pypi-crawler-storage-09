name = "pybah"
version = "4"

requires = ["python-2.6", ".eek-1"]
