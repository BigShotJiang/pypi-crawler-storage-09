name = "pybah"
version = "5"

requires = ["python-2.5"]
