name = "pydad"
version = "2"

requires = ["pyson-2"]
