name = "pydad"
version = "3"

requires = ["pymum-3"]
