name = "pyfoo"
version = "3.0.0"

requires = ["python-2.5", ".eek-3+"]
