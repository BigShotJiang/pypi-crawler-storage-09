name = "pyfoo"
version = "3.1.0"

requires = ["python-2.6"]
