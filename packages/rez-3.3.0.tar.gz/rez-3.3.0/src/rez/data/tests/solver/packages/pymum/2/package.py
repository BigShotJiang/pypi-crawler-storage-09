name = "pymum"
version = "2"

requires = ["pydad-2"]
