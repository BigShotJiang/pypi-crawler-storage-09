name = "pyodd"
version = "2"

requires = ["pybah"]
