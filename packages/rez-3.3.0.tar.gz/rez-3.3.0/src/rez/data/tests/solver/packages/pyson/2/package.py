name = "pyson"
version = "2"

requires = ["pymum-3"]
