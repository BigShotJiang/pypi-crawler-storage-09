name = "pysplit"
version = "5"
