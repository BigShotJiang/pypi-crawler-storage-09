name = "python"
version = "2.6.0"
