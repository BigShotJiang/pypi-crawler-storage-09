name = "test_variant_split_end"
version = "1.0"

variants = [["!test_variant_split_mid2"], ["!test_variant_split_start-2"]]
