name = "test_variant_split_mid1"
version = "2.0"

variants = [["test_variant_split_end-2"], ["test_variant_split_end-4"]]
