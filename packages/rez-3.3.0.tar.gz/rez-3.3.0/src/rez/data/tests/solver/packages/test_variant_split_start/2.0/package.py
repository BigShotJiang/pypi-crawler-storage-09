name = "test_variant_split_start"
version = "2.0"

variants = [["test_variant_split_mid1-2"], ["test_variant_split_mid2-2"]]
