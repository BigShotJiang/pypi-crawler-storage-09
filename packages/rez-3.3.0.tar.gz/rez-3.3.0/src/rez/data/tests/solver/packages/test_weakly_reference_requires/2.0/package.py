name = "test_weakly_reference_requires"
version = "2.0"

requires = ["~test_variant_split_mid1", "~test_variant_split_mid2"]
