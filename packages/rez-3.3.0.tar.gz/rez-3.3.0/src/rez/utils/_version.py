# SPDX-License-Identifier: Apache-2.0
# Copyright Contributors to the Rez Project


# Update this value to version up Rez. Do not place anything else in this file.
# Using .devN allows us to run becnmarks and create proper benchmark reports on PRs.
_rez_version = "3.3.0"
