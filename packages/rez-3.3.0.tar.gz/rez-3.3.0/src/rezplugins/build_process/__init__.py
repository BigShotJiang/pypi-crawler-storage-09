# SPDX-License-Identifier: Apache-2.0
# Copyright Contributors to the Rez Project


from rez.plugin_managers import extend_path
__path__ = extend_path(__path__, __name__)
