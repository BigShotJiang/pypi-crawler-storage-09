"""
Test suite for mini_trainer package.

This package contains comprehensive unit tests for all critical components
of the distributed training pipeline.
"""
