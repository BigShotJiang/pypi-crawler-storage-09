# riddhulib/__init__.py
# This file makes riddhulib a Python package.

from .addcode import add_numbers
