"""
Base tools library.
"""