"""
R integration assets.
Contains R scripts and assets needed for:
- Package installation
- R environment setup
- Statistical computation resources
"""
