# roboid

## Overview
Part of the ROBOID project - http://hamster.school
Copyright (C) 2016 Kwang-Hyun Park (akaii@kw.ac.kr)

## Installation
``pip install -U roboid`` should work for most users.
