# src/DialogsPlus/__init__.py

from .dialogsplus import DialogsPlus

__all__ = ["DialogsPlus"]  
