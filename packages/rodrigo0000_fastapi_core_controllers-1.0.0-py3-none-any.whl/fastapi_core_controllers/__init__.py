"""
Controllers module - Generic SaaS controllers
"""

from .support_controller import router as support_router

__all__ = ["support_router"]
