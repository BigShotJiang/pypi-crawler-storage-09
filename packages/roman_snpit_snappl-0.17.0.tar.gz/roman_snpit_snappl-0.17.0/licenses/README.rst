Licenses
========

This directory holds license and credit information for the package,
works the package is derived from, and/or datasets.

Ensure that you pick a package licence which is in this folder and it matches
the one mentioned in the top level README.rst file. If you are using the
pre-rendered version of this template check for the word 'Other' in the README.
