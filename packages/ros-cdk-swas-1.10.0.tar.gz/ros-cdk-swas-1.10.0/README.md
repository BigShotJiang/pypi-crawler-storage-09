## Aliyun ROS SWAS Construct Library

This module is part of the AliCloud ROS Cloud Development Kit (ROS CDK) project.

```python
import * as SWAS from '@alicloud/ros-cdk-swas';
```
