## Aliyun ROS VS Construct Library

This module is part of the AliCloud ROS Cloud Development Kit (ROS CDK) project.

```python
import * as VS from '@alicloud/ros-cdk-vs';
```
