.. _changes:

Changes
=======

0.10.1 - 2025-10-16
-------------------

- Advertise Python 3.14 compatibility
- Switch to uv


0.10.0 - 2024-05-25
-------------------

- Increase minimum required Python version to 3.10
- Improve type hints


0.9.1 - 2024-02-29
------------------

- Update for rosbags 0.9.20


0.9.0 - 2022-04-11
------------------

- Initial Release
