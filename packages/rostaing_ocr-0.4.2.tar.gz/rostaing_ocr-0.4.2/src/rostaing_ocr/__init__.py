# Fichier : src/rostaing_ocr/__init__.py

from .rostaing_ocr import RostaingOCR

# Optionnel: définir ce qui est exporté quand on fait 'from rostaing_ocr import *'
__all__ = ['RostaingOCR']