# flake8: noqa

# import apis into api package
from royal_mail_click_and_drop.api.labels_api import LabelsApi
from royal_mail_click_and_drop.api.manifests_api import ManifestsApi
from royal_mail_click_and_drop.api.orders_api import OrdersApi
from royal_mail_click_and_drop.api.version_api import VersionApi

