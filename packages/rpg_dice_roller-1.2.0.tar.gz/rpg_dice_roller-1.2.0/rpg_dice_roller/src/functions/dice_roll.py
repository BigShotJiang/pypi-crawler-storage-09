from ..models.dice_controller import _DiceController

roll_dice = _DiceController.roll