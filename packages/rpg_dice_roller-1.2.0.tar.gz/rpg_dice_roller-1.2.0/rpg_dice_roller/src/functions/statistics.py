from ..models.dice_controller import _DiceController

get_dice_range = _DiceController.get_dice_range
get_dice_rolled = _DiceController.get_dice_rolled