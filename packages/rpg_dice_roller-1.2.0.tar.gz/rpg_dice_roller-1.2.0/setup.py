from setuptools import setup, find_packages

with open('rpg_dice_roller/README.md', 'r', encoding='utf-8') as f:
    description = f.read()

setup(
    name='rpg-dice-roller',
    version='1.2.0',
    author='Milton Ávila',
    python_requires=">=3.9.4",
    requirements=[
    ],
    license='MIT License',
    packages=find_packages(),
    long_description=description,
    long_description_content_type='text/markdown',
)