"""See the class docstring."""

from typing import Callable

from . import InstrumentOptions as Options
from .ArgSingle import ArgSingle
from .ArgSingleList import ArgSingleList
from .Conversions import BinFloatFormat, BinIntFormat
from .Instrument import Instrument
from .InstrumentSettings import InstrViClearMode, InstrumentSettings, WaitForOpcMode, OpcSyncQueryMechanism
from .ScpiLogger import LoggingMode
from .InstrumentErrors import RsInstrException
from .Properties import Properties


class Core(object):
	"""Main driver component. Provides: \n
		- Main core constructor
		- 'io' interface for all the write / query operations
		- Command parameters string composer for single arguments
		- Link handlers adding / changing / deleting

		Version history:

		1.110.0 (15.10.2025)
		- Added optional parameter mixed_mode to the method go_to_local().

		1.105.1 (16.07.2025)
		- Fixed VisaSession's clear_before_read().

		1.105.0 (02.06.2025)
		- Corrected duplicate time-statistics methods from logger.
		- Improved help texts.

		1.104.0 (20.05.2025)
		- Added settings profile 'RadEsT' for R&S Automotive Radar Tester.
		- Added settings 'EachCmdSuffix' settings option - use it for instruments that require CRLF at the end of each command.
		- Added settings 'StripStringTrailingWhitespaces' - use it to strip white spaces from string query responses.
		- added check_status_always().

		1.103.0 (09.04.2025)
		- Fixes for Pycharm 2024.3 checks.

		1.102.0 (20.01.2025)
		- Fixes for backend pyvisa-py.

		1.101.0 (13.01.2025)
		- Changed the minimum Python requirement to 3.8 to assure pyvisa version > 1.13.
		- Fixed Logger end time in relative mode.
		- Fixed bug with InstrErrorSuppressor for checking errors flag after the context has finished.
		- Extended InstrErrorSuppressor to catch queries Timeout as StatusException.
		- Added Options to skip certain command headers - used in the auto-generated drivers in Instrument._replace_global_repcaps().
		- ScpiEnums - now the enums can contain also double-quotes. Enums with quotes recognition by reading allows for either single, or double quotes.

		1.100.0 (07.10.2024)
		- Changed the minimum Python requirement to 3.7 to avoid SCPI Logger Regex error.
		- Fixed VISA Timeout Error generations for NRP sessions.
		- Added Instrument Options methods: has_instr_option(), has_instr_option_regex(), has_instr_option_k0(), add_instr_option(), remove_instr_option()

		1.91.1 (13.06.2024)
			- Fixed failing 'import visa' statement for python > 3.10

		1.91.0 (10.06.2024)
			- In SCPI Logger:
				- info(), error() - changed the last parameter 'cmd' to optional
				- info_bin(), info_list() - changed the order of the last two parameters. 'cmd' moved to the end and made optional, to be compatible with 1.70.0
				- ContextManager VisaTimeoutSuppressor made more robust in case of exceptions inside the other exceptions.

		1.90.0 (27.05.2024)
			- Visa Session private method _flush_junk_data() tolerates timeout error and remembers to tolerate it for the future.

		1.80.0 (17.05.2024)
			- Loosened checking of list parameters - all the List params can also be scalar values.

		1.71.0 (25.04.2024)
			- To all query_str_list_xxx() methods, added non-mandatory parameter 'remove_blank_response'
			- Added Context Managers for ignoring errors and ignoring VISA Timeouts.
			- Logger: added new variable to the format string: %SCPI_COMMAND%, where you can only log SCPI commands to your log data.
			- Added to Utilities interface: query_str_list(), query_str_list_with_opc(), query_bool_list(), query_bool_list_with_opc()
			- Added Utility functions: value_to_si_string(), size_to_kb_mb_gb_string().
			- Changed behaviour of the Conversion functions to list:
				- str_to_float_list()
				- str_to_float_or_bool_list()
				- str_to_int_list()
				- str_to_int_or_bool_list()
				- str_to_bool_list()
				These functions previously returned a list of one element if the input value was whitespace-only string.
				Now, in such case they return empty list.

		1.70.0 (27.02.2024)
			- Added settings profile 'XK41' for R&S Software Defined Radios.
			- Added settings 'FirstCmds' where you can send the defined commands right after the init. Send more commands in a row with ';;' separator.
			- Added settings 'EachCmdPrefix' - this prefix is added to each command sent to the instrument. Supported values are also 'lf', 'cr', 'tab'

		1.60.0 (31.01.2024)
			- Added Properties script for global properties.
			- Added Properties.scpi_quotes, string option settings token: 'ScpiQuotes'. Example: ScpiQuotes=double. Default: Single
			- Fixed VisaPluginSocketIo read() method for cases where the session is lost. The method now generates exception in that case.
			- Added settings 'OpcSyncQueryMechanism' with values: Standard, AlsoCheckMav, ClsOnlyCheckMavErrQueue, OnlyCheckMavErrQueue.

		1.54.0 (27.06.2023)
			- Added new options profile for ATS chambers.
			- Added settings boolean token EachCmdAsQuery. Example: EachCmdAsQuery=True. Default: False.

		1.53.0 (18.10.2022)
			- Improved mode where the instrument works with a session from another object.
			- Silently ignoring invalid *IDN? string.
			- Added new options profile 'Minimal' for non-SCPI-99 instruments.

		1.52.0 (28.09.2022)
			- Fixed DisableOpcQuery=True settings effect.
			- Improved robustness of the TerminationCharacter option value entry.
			- Added new options profile for CMQ500.

		1.51.0 (08.09.2022)
			- Changed the accepted IDN? response to more permissive.
			- added methods go_to_remote() and go_to_local().
			- added methods file_exists() and get_file_size().

		1.50.0 (23.06.2022)
			- Added relative timestamp to the logger.
			- ScpiLogger can read GlobalData class variables making it possible to define common target and reference timestamp for all instances.
			- Logger stream entries are by default immediately flushed, making sure that the log is complete.
			- Added time statistic methods get_total_execution_time(), get_total_time(), reset_time_statistics().

		1.24.0 (03.06.2022)
			- Changed parsing of SYST:ERR? response to tolerate +0,"No Error" response.
			- Added settings integer token OpenTimeout. Example: OpenTimeout=5000. Default: 0.
			- Added settings boolean token ExclusiveLock. Example: ExclusiveLock=True. Default: False.

		1.23.0 (24.05.2022)
			- Added stripping of trailing commas when parsing the *IDN? response.
			- If the Resource Manager does not find any default VISA implementation, it falls back to R&S VISA - relevant for LINUX or macOS.
			- Other typos and formatting corrections.

		1.22.0 (20.04.2022)
			- Added optional parameter timeout to reset().
			- Added query list methods:  query_bool_list, query_bool_list_with_opc.

		1.21.0 (07.01.2022)
			- Added logging to UDP port (49200) to integrate with new R&S Instrument Control plugin for Pycharm.

		1.20.0 (19.11.2021)
			- Fixed logging strings when device name was a substring of the resource name.

		1.18.0 (build 64) 05.11.2021
			- Added setting profile for non-standard instruments. Example of the options string: options='Profile=hm8123'.

		1.17.0 (build 63) 15.10.2021
			- Added correct conversion of strings with SI suffixes (e.g.: MHz, KHz, THz, GHz, ms, us) to float and integer.

		1.16.0 (build 62) 31.08.2021
			- Changed default encoding of string<=>bin from utf-8 to charmap.
			- Added settable encoding for the session. Property: 'RsInstrument.encoding'

		1.15.0 (build 61) 17.08.2021
			- Added support for EnumExt and EnumExtList.
			- Added support for custom scpi enums.
			- Improved exception handling in cases where the instrument session is closed.
			- Fixed warning in Instrument.py.
			- Fixed Instrument.query_bin_block() for timeout errors.
			- Repeated capabilities are now allowed to be integer numbers as well.

		1.14.0 (build 53) 12.07.2021
			- Scpi logger time entries now support not only datetime tuples, but also float timestamps.
			- Changed handling of the syst:err? responses - now they are always Tuple (code, message).
			- StatusException has new field errors_list: List[ Tuple[code, message] ].
			- Added logger.log_status_check_ok property. This allows for skipping lines with 'Status check: OK'.

		1.12.0 (build 50) 26.06.2021
			- Added SCPI Logger.
			- Simplified constructor's options string format - removed DriverSetup=() syntax:
			Instead of "DriverSetup=(TerminationCharacter='\n')", you use "TerminationCharacter='\n'".
			The original format is still supported.

			- Fixed calling SYST:ERR? even if *STB? returned 0.
			- Replaced @ni backend with @ivi for resource manager - this is necessary for the future pyvisa version 1.12+.

		1.11.0 (build 49) 09.06.2021
			- Added is_connection_active() + reconnect().

		1.10.1 (build 47) 01.06.2021
			- Fixed bug with error checking when events are defined.

		1.10.0 (build 46) 03.05.2021
			- Added methods to Instrument: query_struct_with_opc(), query_str_suppressed_with_opc().

		1.9.0 (build 45) 13.04.2021
			- Added option to set callbacks before_write and before_query.
			- When a RepCap has a member with integer number 0 defined, the command string interpretation of such member is '0', not empty string.

		1.8.0 (build 43) 19.01.2021
			- Added matching of Enum instrument responses also in short/long form.

		1.7.7 (build 42) 26.11.2020
			- Extended ArgSingleList.compose_cmd_string() to 9 arguments.

		1.7.6 (build 41) 23.11.2020
			- Extended data types for IntegerExt, FloatExt, IntegerExtArray, FloatExtArray.

		1.7.5 (build 40) 12.11.2020
			- Extended 'Conversions' method str_to_str_list() by parameter 'clear_one_empty_item' with default value False.

		1.7.4 (build 39) 11.09.2020
			- Fixed parsing of the instrument errors when an error message contains two double quotes.

		1.7.3 (build 38) 21.10.2020
			- Added 'UND' to the list of float numbers that are represented as NaN.

		1.7.2 (build 37) 10.10.2020
			- SCPI response string conversion to scalar enum: if the string contains ',', the content after it inclusive the comma is ignored.

		1.7.1 (build 36) 08.10.2020
			- Fixed Python 3.8.5+ warnings.

		1.7.0 (build 34) 30.09.2020
			- Added option to set the termination characters for reading and writing. Until now, it was fixed to '\n' (Linefeed).
			- Replaced 'import visa' with 'import pyvisa' to remove Python 3.8 pyvisa warnings.

		Version History:
		1.6.0 (build 33) 17.09.2020
			- Added special characters encoding/decoding in enums.

		1.4.0 (build 32) 17.09.2020
			- Added recognition of RsVisa library location for linux when using options string 'SelectVisa=rs'.
			- Fixed bug in reading binary data 16 bit.

		1.3.0 (build 31) 04.09.2020
			- added DRIVERSETUP_QUERYOPT to the driver's option string.
			- *OPT? is no longer performed at the init, but only at the first access to the options string.
				In addition, the *OPT? query is executed with 1000 ms timeout, and the errors are suppressed.

		1.2.0 (build 30), 03.08.2020
			- Fixed NRP-Z session parameters: vxi_capable = False, io_segment_size = 1000000.

		1.1.0 (build 29), 20.06.2020
			- Added RepeatedCapability and base class CommandsGroup.
			- Fixed simulation mode switching.

		0.9.3 (build 25), 23.04.2020
			- Fixed composition of optional arguments in ArgSingleList and ArgSingle.

		0.9.2 (build 24), 13.11.2019
			- Added recognition of special values for enum return strings.

		0.9.1
			- Added read / write to file, refactored internals to work with streams.

		0.9.0
			- First Version created."""

	driver_version: str = ''
	"""Placeholder for the driver version string."""

	def __init__(
			self,
			resource_name: str,
			id_query: bool = True,
			reset: bool = False,
			driver_options: str = None,
			user_options: str = None,
			direct_session: object = None,
			called_from_driver: bool = True):
		"""Initializes new driver session. For cleaner code, use the class methods: \n
		- Core.from_existing_session() - initializes a new Core with an existing pyvisa session."""

		self.core_version = '1.106.0'
		self.resource_name = resource_name
		self.called_from_driver = called_from_driver

		# Typical settings for the Core
		self._instrumentSettings = InstrumentSettings(
			InstrViClearMode.execute_on_all,  # Instrument viClear mode
			False,  # Full model name. True: SMW200A, False: SMW
			0,  # Delay by each write
			0,  # Delay by each read
			1000000,  # Max chunk read / write size in bytes
			WaitForOpcMode.stb_poll,  # Waiting for OPC Mode: Status byte polling
			30000,  # OPC timeout
			10000,  # VISA timeout
			60000,  # Self-test timeout
			Options.ParseMode.Auto,  # *OPT? response parsing mode
			BinFloatFormat.Single_4bytes,  # Format for parsing of binary float numbers
			BinIntFormat.Integer32_4bytes,  # Format for parsing of binary integer numbers
			False,  # OPC query after each setting
			LoggingMode.Off,
			OpcSyncQueryMechanism.only_check_mav_err_queue
			# Logging mode
		)

		self._instrumentSettings.apply_option_settings(driver_options)
		self._instrumentSettings.apply_option_settings(user_options)

		self.simulating = self._instrumentSettings.simulating
		self.supported_idn_patterns = self._instrumentSettings.supported_idn_patterns
		self.supported_instr_models = self._instrumentSettings.supported_instr_models

		self._args_single_list = ArgSingleList()
		handle = self._resolve_direct_session(direct_session)
		self.io = Instrument(self.resource_name, self.simulating, self._instrumentSettings, handle)
		self.io.query_instr_status = True
		self.io.called_from_driver = self.called_from_driver
		# Update the resource name if it changed, for example because of the direct session
		self.resource_name = self.io.resource_name
		self.allow_reconnect = self.io.allow_reconnect

		self._apply_settings_to_instrument(self._instrumentSettings)
		self._apply_global_properties(self._instrumentSettings)
		self.io.set_simulating_cmds()

		if id_query:
			self.io.fits_idn_pattern(self.supported_idn_patterns, self.supported_instr_models)

		if reset:
			self.io.reset()
		else:
			self.io.check_status()

	@classmethod
	def from_existing_session(cls, session: object, driver_options: str = None) -> 'Core':
		"""Creates a new Core object with the entered 'session' reused."""
		# noinspection PyTypeChecker
		return cls(resource_name=None, id_query=False, reset=False, driver_options=driver_options, user_options=None, direct_session=session)

	def __str__(self):
		return f"Core session '{self.io.resource_name}'"

	def _resolve_direct_session(self, direct_session):
		# Resolve the direct_session to handle. Options for direct_session type:
		# - VisaSession object, retrieved from the driver's RsInstrument.get_session_handle() method
		# - string in case of a simulation session
		handle = direct_session
		if not direct_session:
			return None
		# Check if the entered 'direct_session' is either the driver object or the Visa session
		if hasattr(direct_session, 'get_session_handle'):
			if not hasattr(direct_session, '_core'):
				raise RsInstrException('Direct session is a class type. It must be an instance of the top-level driver class.')
			handle = direct_session.get_session_handle()
		# If the handle is a simulating session, change the session to simulating and set disable the 'from existing session' feature
		if isinstance(handle, str):
			mand_string = 'Simulating session, resource name '
			if mand_string in handle:
				self.resource_name = handle[len(mand_string):].strip().strip("'").strip()
				self.simulating = True
				handle = None
		return handle

	def set_link_handler(self, link_name: str, handler: Callable) -> Callable:
		"""Adds / Updates link handler for the entered link_name.
		Handler API: handler(event_args: ArgLinkedEventArgs)
		Returns the previous registered handler, or None if no handler was registered before."""
		return self.io.set_link_handler(link_name, handler)

	def del_link_handler(self, link_name: str) -> Callable:
		"""Deletes link handler for the link_name.
		Returns the deleted handler, or None if none existed."""
		return self.io.del_link_handler(link_name)

	def del_all_link_handlers(self) -> int:
		"""Deletes all the link handlers.
		Returns number of deleted links."""
		return self.io.del_all_link_handlers()

	def _apply_settings_to_instrument(self, settings: InstrumentSettings) -> None:
		"""Applies settings relevant for the Instrument from the InstrumentSettings structure."""
		if settings.instrument_status_check is not None:
			self.io.query_instr_status = settings.instrument_status_check
		if self.simulating and settings.instrument_simulation_idn_string is not None:
			self.io.idn_string = settings.instrument_simulation_idn_string

	@staticmethod
	def _apply_global_properties(settings: InstrumentSettings) -> None:
		"""Applies settings valid for the entire module. All are available in the module 'Properties'."""
		if settings.scpi_quotes is not None:
			Properties.scpi_quotes = settings.scpi_quotes

	def compose_cmd_arg_param(
			self, arg1: ArgSingle, arg2: ArgSingle = None, arg3: ArgSingle = None, arg4: ArgSingle = None, arg5: ArgSingle = None, arg6: ArgSingle = None) -> str:
		"""Composes command parameter string based on the single argument definition."""
		return self._args_single_list.compose_cmd_string(arg1, arg2, arg3, arg4, arg5, arg6)

	def get_last_sent_cmd(self) -> str:
		"""Returns the last commands sent to the instrument. Only works in simulation mode"""
		return self.io.get_last_sent_cmd()

	def get_session_handle(self):
		"""Returns the underlying pyvisa session."""
		return self.io.get_session_handle()

	def close(self):
		"""Closes the Core session."""
		self.io.close()
		self.io = None
