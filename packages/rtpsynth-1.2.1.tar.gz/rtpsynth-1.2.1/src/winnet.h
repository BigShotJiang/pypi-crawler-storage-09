#pragma once

#include <winsock.h>
#define LITTLE_ENDIAN 1234
#define BIG_ENDIAN 4321
#define BYTE_ORDER LITTLE_ENDIAN

#pragma comment(lib, "Ws2_32.lib")
