from src.rubric.core import Criterion, Rubric

__version__ = "1.1.1"
__all__ = ["Criterion", "Rubric"]
__name__ = "rubric"
__author__ = "The LLM Data Company"
