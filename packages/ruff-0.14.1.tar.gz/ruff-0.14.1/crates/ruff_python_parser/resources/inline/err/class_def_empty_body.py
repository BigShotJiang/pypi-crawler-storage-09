class Foo:
class Foo():
x = 42
