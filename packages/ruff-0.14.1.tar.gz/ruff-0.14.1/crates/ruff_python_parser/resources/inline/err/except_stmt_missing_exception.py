try:
    pass
except as exc:
    pass
# If a '*' is present then exception type is required
try:
    pass
except*:
    pass
except*
    pass
except* as exc:
    pass
