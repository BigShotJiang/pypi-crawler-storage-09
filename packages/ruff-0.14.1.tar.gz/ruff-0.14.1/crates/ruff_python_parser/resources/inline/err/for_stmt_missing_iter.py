for x in:
    a = 1
