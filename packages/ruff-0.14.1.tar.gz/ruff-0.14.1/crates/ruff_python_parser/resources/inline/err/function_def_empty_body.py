def foo():
def foo() -> int:
x = 42
