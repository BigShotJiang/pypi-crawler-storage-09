(
    'hello'
    f'world {x}
)
1 + 1
(
    'first'
    'second
    f'third'
)
2 + 2
