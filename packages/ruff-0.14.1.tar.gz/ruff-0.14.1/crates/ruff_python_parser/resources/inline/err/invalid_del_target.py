del x + 1
del {'x': 1}
del {'x', 'y'}
del None, True, False, 1, 1.0, "abc"
