match x:
    x = 1
match x:
    match y:
        case _: ...
