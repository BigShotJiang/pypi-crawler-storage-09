def _():
    nonlocal x + 1
