raise x,
raise x, y
raise x, y from z
