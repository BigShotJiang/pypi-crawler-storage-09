def f(): yield *x
