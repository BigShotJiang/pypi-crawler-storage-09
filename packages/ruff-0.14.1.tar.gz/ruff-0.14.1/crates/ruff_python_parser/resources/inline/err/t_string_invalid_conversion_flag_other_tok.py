# parse_options: {"target-version": "3.14"}
t"{x!123}"
t"{x!'a'}"
