try:
    pass
exept:  # spellchecker:disable-line
    pass
finally:
    pass
a = 1
try:
    pass
except:
    pass
exept:  # spellchecker:disable-line
    pass
b = 1
