def foo[]():
    pass
type ListOrSet[] = list | set
