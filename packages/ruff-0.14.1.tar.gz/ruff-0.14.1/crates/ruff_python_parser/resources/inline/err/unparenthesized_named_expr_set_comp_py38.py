# parse_options: {"target-version": "3.8"}
{last := x for x in range(3)}
