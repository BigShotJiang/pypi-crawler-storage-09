f"hello
1 + 1
f"hello {x
2 + 2
f"hello {x:
3 + 3
f"hello {x}
4 + 4
