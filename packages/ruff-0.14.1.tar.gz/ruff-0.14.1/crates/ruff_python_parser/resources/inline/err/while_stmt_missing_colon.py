while (
    a < 30 # comment
)
    pass
