# `)` followed by a newline
with (item1, item2)
    pass
