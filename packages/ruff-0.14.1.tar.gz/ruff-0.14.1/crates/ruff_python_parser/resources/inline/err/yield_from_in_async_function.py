async def f(): yield from x
