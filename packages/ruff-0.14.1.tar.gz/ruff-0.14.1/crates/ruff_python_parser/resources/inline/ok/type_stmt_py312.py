# parse_options: {"target-version": "3.12"}
type x = int
