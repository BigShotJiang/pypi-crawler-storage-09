# parse_options: {"target-version": "3.9"}
lst[x:=1]
