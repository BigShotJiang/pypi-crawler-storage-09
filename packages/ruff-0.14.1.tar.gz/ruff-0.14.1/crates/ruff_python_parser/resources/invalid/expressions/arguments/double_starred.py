call(**yield x)
call(** *x)
call(***x)

call(**x := 1)
