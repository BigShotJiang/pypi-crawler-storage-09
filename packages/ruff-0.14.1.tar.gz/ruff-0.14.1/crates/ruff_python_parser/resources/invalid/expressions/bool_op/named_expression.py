x and a := b
x or a := b