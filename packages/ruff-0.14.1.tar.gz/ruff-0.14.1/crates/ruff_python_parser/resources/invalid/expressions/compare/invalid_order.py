x in not y

# `=>` instead of `>=`
x => y

# Same here as well, `not` without `in` is considered to be a unary operator
x not is y
