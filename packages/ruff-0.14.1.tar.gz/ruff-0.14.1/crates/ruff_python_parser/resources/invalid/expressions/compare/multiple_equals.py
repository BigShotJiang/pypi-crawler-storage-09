# This is not JavaScript
x === y
x !== y
