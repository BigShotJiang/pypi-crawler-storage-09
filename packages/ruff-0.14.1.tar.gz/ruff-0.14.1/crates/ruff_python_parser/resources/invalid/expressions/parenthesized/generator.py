(*x for x in y)
(x := 1, for x in y)