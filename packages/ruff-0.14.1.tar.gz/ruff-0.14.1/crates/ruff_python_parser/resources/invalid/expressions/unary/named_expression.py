-x := 1
not x := 1