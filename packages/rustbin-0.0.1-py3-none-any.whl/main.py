def main():
    print("Hello from rustbin!")


if __name__ == "__main__":
    main()
