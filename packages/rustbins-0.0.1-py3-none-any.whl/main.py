def main():
    print("Hello from rustbins!")


if __name__ == "__main__":
    main()
