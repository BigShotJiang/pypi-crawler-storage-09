[![crates.io](https://img.shields.io/crates/v/rustsat-tools?style=for-the-badge&logo=rust)](https://crates.io/crates/rustsat-tools)
[![docs.rs](https://img.shields.io/docsrs/rustsat-tools?style=for-the-badge&logo=docsdotrs)](https://docs.rs/rustsat-tools)
[![License](https://img.shields.io/crates/l/rustsat-tools?style=for-the-badge)](../LICENSE)

<!-- cargo-rdme start -->

# rustsat-tools - Tools for and with the RustSAT Library

This crate contains tools for and built on the RustSAT library.

<!-- cargo-rdme end -->
