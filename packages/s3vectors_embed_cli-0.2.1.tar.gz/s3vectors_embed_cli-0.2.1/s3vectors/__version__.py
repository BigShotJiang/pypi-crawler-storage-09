"""Version information for S3 Vectors CLI."""

__version__ = "0.2.1"
__version_info__ = tuple(int(i) for i in __version__.split('.'))
