# Quick Deployment Commands

## 📦 Deploy to PyPI - Quick Reference

### Step 1: Install build tools
```bash
cd /Users/aryanrajpurkar/Projects/safellm/backend
uv pip install build twine
```

### Step 2: Run the deployment script
```bash
./deploy-to-pypi.sh
```

### OR Manual Steps:

#### Clean & Build
```bash
rm -rf dist/ build/ *.egg-info
python -m build
```

#### Upload to Test PyPI (Recommended first)
```bash
python -m twine upload --repository testpypi dist/*
```

#### Upload to Production PyPI
```bash
python -m twine upload dist/*
```

### Step 3: Test Installation

#### From Test PyPI:
```bash
pip install --index-url https://test.pypi.org/simple/ safellm
```

#### From Production PyPI:
```bash
pip install safellm
```

---

## 📝 Before Publishing Checklist

- [ ] Update version in `pyproject.toml`
- [ ] Update your email in `pyproject.toml`
- [ ] Test package builds: `python -m build`
- [ ] Create PyPI account: https://pypi.org/account/register/
- [ ] Generate API token: https://pypi.org/manage/account/token/
- [ ] Test on Test PyPI first
- [ ] Tag release in git: `git tag v0.1.0 && git push --tags`

---

## 🔑 Authentication

Use one of these methods:

**Method 1: Enter credentials when prompted**
- Username: `__token__`
- Password: `<your-pypi-token>`

**Method 2: Create ~/.pypirc**
```ini
[pypi]
username = __token__
password = pypi-YOUR-TOKEN-HERE
```

---

## 📚 Full Documentation

See `PYPI_DEPLOYMENT.md` for complete guide.
