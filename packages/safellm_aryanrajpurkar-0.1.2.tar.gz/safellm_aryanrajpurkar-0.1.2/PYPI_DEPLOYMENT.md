# safellm PyPI Deployment Guide

This guide walks you through publishing the safellm SDK to PyPI.

## Prerequisites

1. **PyPI Account**: Create accounts on both:
   - Test PyPI: https://test.pypi.org/account/register/
   - Production PyPI: https://pypi.org/account/register/

2. **API Tokens**: Generate API tokens for uploading:
   - Test PyPI: https://test.pypi.org/manage/account/token/
   - Production PyPI: https://pypi.org/manage/account/token/

3. **Install Build Tools**:
   ```bash
   uv pip install build twine
   ```

## Step 1: Update Version

Edit `pyproject.toml` and increment the version:
```toml
version = "0.1.0"  # Change to 0.1.1, 0.2.0, etc.
```

## Step 2: Clean Previous Builds

```bash
cd /Users/aryanrajpurkar/Projects/safellm/backend
rm -rf dist/ build/ *.egg-info
```

## Step 3: Build the Package

```bash
python -m build
```

This creates:
- `dist/safellm-0.1.0-py3-none-any.whl` (wheel)
- `dist/safellm-0.1.0.tar.gz` (source distribution)

## Step 4: Test the Build Locally

```bash
# Install in a test environment
uv pip install dist/safellm-0.1.0-py3-none-any.whl

# Test import
python -c "from safellm_sdk import safellm; print('Success!')"
```

## Step 5: Upload to Test PyPI (Recommended First)

```bash
# Upload to Test PyPI
python -m twine upload --repository testpypi dist/*

# You'll be prompted for:
# Username: __token__
# Password: <your-test-pypi-token>
```

## Step 6: Test Installation from Test PyPI

```bash
# Create a new environment and test install
uv venv test-env
source test-env/bin/activate
pip install --index-url https://test.pypi.org/simple/ safellm

# Test it works
python -c "from safellm_sdk import safellm; print('Success!')"
```

## Step 7: Upload to Production PyPI

Once testing is successful:

```bash
python -m twine upload dist/*

# You'll be prompted for:
# Username: __token__
# Password: <your-production-pypi-token>
```

## Step 8: Verify on PyPI

Visit: https://pypi.org/project/safellm/

## Step 9: Install from PyPI

Now anyone can install:

```bash
pip install safellm
```

## Automated Publishing with GitHub Actions (Optional)

Create `.github/workflows/publish.yml`:

```yaml
name: Publish to PyPI

on:
  release:
    types: [published]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v3
    
    - name: Set up Python
      uses: actions/setup-python@v4
      with:
        python-version: '3.11'
    
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install build twine
    
    - name: Build package
      run: python -m build
      working-directory: backend
    
    - name: Publish to PyPI
      env:
        TWINE_USERNAME: __token__
        TWINE_PASSWORD: ${{ secrets.PYPI_API_TOKEN }}
      run: |
        python -m twine upload dist/*
      working-directory: backend
```

Then add your PyPI token as a GitHub secret named `PYPI_API_TOKEN`.

## Using .pypirc for Credentials (Alternative)

Create `~/.pypirc`:

```ini
[distutils]
index-servers =
    pypi
    testpypi

[pypi]
username = __token__
password = pypi-YOUR-PRODUCTION-TOKEN-HERE

[testpypi]
repository = https://test.pypi.org/legacy/
username = __token__
password = pypi-YOUR-TEST-TOKEN-HERE
```

Then you can upload without entering credentials:

```bash
twine upload dist/*
twine upload --repository testpypi dist/*
```

## Best Practices

1. **Always test on Test PyPI first**
2. **Use semantic versioning**: MAJOR.MINOR.PATCH (e.g., 1.0.0)
3. **Update CHANGELOG.md** with each release
4. **Tag releases in Git**: `git tag v0.1.0 && git push --tags`
5. **Test installation** before announcing
6. **Keep credentials secure**: Never commit tokens to Git

## Troubleshooting

### Issue: "File already exists"
- You can't overwrite existing versions on PyPI
- Increment the version number in `pyproject.toml`

### Issue: "Invalid package name"
- Package name must be unique on PyPI
- Check if "safellm" is available: https://pypi.org/project/safellm/

### Issue: "Missing dependencies"
- Ensure all dependencies are listed in `pyproject.toml`
- Test in a clean environment

## Version History

- **0.1.0** (2025-10-21): Initial release
  - safellm SDK with OpenAI integration
  - Guardian backend API
  - Toxicity, bias, jailbreak detection
  - Custom classifiers and policy engine

## Support

For issues, visit: https://github.com/aryan4codes/safellm/issues
