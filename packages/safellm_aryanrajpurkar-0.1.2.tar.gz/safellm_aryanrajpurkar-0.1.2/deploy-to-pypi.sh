#!/bin/bash
# safellm PyPI Deployment Script

set -e  # Exit on error

echo "========================================"
echo "safellm PyPI Deployment"
echo "========================================"

# Check if we're in the right directory
if [ ! -f "pyproject.toml" ]; then
    echo "Error: pyproject.toml not found. Run this from the backend directory."
    exit 1
fi

# Check if build and twine are installed
echo ""
echo "Checking dependencies..."
if ! python3 -c "import build" 2>/dev/null; then
    echo "Installing build..."
    uv pip install build
fi

if ! python3 -c "import twine" 2>/dev/null; then
    echo "Installing twine..."
    uv pip install twine
fi
echo "✓ Dependencies ready"

# Clean previous builds
echo ""
echo "Step 1: Cleaning previous builds..."
rm -rf dist/ build/ *.egg-info
echo "✓ Cleaned"

# Build the package
echo ""
echo "Step 2: Building package..."
python3 -m build
echo "✓ Built"

# Show what was created
echo ""
echo "Step 3: Package contents:"
ls -lh dist/
echo ""

# Ask which repository to upload to
echo "Step 4: Choose repository:"
echo "  1) Test PyPI (recommended first)"
echo "  2) Production PyPI"
echo "  3) Skip upload (just build)"
echo ""
read -p "Enter choice (1-3): " choice

case $choice in
    1)
        echo ""
        echo "Uploading to Test PyPI..."
        python3 -m twine upload --repository testpypi dist/*
        echo ""
        echo "✓ Uploaded to Test PyPI!"
        echo ""
        echo "Test installation with:"
        echo "  pip install --index-url https://test.pypi.org/simple/ safellm"
        ;;
    2)
        echo ""
        read -p "Are you sure you want to upload to PRODUCTION PyPI? (yes/no): " confirm
        if [ "$confirm" = "yes" ]; then
            echo "Uploading to Production PyPI..."
            python -m twine upload dist/*
            echo ""
            echo "✓ Uploaded to Production PyPI!"
            echo ""
            echo "Install with:"
            echo "  pip install safellm"
        else
            echo "Upload cancelled."
        fi
        ;;
    3)
        echo "Upload skipped. Package built successfully."
        ;;
    *)
        echo "Invalid choice. Upload skipped."
        ;;
esac

echo ""
echo "========================================"
echo "Deployment complete!"
echo "========================================"
