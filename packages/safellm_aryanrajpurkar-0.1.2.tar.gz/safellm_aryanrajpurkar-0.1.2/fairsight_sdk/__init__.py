"""
safellm SDK - Client library for safety-enhanced OpenAI API calls.

This SDK wraps OpenAI's API to provide:
- Automatic safety checks (toxicity, bias, jailbreaks)
- Real-time logging and observability
- Automatic remediation of unsafe content
- Multi-tenant support
"""

from .client import safellm
from .models import SafeCompletionResponse, SafetyConfig, SafetyScores
from .exceptions import (
    safellmException,
    SafetyViolationException,
    RemediationFailedException,
)

__version__ = "0.1.0"

__all__ = [
    "safellm",
    "SafeCompletionResponse",
    "SafetyConfig",
    "SafetyScores",
    "safellmException",
    "SafetyViolationException",
    "RemediationFailedException",
]
