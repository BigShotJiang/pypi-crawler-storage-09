"""
Custom exceptions for safellm SDK.
"""


class safellmException(Exception):
    """Base exception for safellm SDK."""
    pass


class SafetyViolationException(safellmException):
    """Raised when safety violation is detected and on_flag='strict'."""
    pass


class RemediationFailedException(safellmException):
    """Raised when automatic remediation fails."""
    pass


class GuardianAPIException(safellmException):
    """Raised when Guardian backend API call fails."""
    pass
