"""Guardian core package."""
