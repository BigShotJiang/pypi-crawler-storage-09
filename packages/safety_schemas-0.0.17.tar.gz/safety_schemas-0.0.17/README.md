# safety_schemas
Models and schemas used by Safety.
