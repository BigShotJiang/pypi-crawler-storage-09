export const packageName = '@amzn/maxdome-data-visualization-widget';
export const majorVersion = 1;

export const MIME_TYPES = [
  'application/sagemaker-display', // legacy MIME type
  'application/vnd.sagemaker.display.v2+json',
];