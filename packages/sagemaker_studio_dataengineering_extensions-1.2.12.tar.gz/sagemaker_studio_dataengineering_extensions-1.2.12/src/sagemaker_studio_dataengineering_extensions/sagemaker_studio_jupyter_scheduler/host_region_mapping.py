import os
import json
import subprocess


def host_region_mapping():
    print("please update the host region mapping file from SMUnoSchedulerJupyterLabExtension")

if __name__ == "__main__":
    host_region_mapping()
