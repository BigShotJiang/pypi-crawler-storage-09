mod vector_wsd;
