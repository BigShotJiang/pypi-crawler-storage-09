============
Installation
============

At the command line::

    python -m pip install SAMPIClyser
