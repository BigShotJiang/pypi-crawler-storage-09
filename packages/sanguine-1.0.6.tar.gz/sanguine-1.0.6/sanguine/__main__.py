if __name__ == "__main__":
    from sanguine.cli import main

    main()
