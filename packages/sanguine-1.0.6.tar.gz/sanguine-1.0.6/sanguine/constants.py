ENTITY_VARIABLE = "variable"
ENTITY_FUNCTION = "function"
ENTITY_CLASS = "class"

FLD_FUNCTIONS = "functions"
FLD_CLASSES = "classes"
