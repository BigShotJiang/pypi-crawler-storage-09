from autogen_agentchat.base import ChatAgent


class ChatAgent(ChatAgent):
    """Protocol for a chat agent."""
    pass




