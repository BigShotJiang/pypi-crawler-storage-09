from autogen_core.tools import BaseToolWithState, BaseTool, Tool


class Tool(Tool):
    pass


class BaseTool(BaseTool):
    pass


class BaseToolWithState(BaseToolWithState):
    pass

