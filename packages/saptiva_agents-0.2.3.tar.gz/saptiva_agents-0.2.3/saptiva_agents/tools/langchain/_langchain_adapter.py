from autogen_ext.tools.langchain import LangChainToolAdapter


class LangChainToolAdapter(LangChainToolAdapter):
    pass