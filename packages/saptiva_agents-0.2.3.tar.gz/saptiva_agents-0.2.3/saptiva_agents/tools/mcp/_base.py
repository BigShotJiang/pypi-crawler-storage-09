from autogen_ext.tools.mcp._base import McpToolAdapter


class McpToolAdapter(McpToolAdapter):
    """
    Base adapter class for MCP tools to make them compatible with AutoGen.
    """
    pass

