"""
Sarmat.
"""
VERSION = "4.5.0"

__version__ = VERSION
