from sayer.core.client import run

if __name__ == "__main__":
    run()
