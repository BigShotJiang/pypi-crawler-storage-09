# sbxcloudpython

This is the first version of Python Library for SbxCloud. The min Python version require is 3.5, this library depends on courutines with asyncio in order to use concurrent task, and uses aiohttp to do the request. You can test using the test.py file, before execute it, configuring your credentials in the environment.


