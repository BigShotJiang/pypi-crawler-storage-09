# Summary

Simple AES (Rijndael) IP Core.

# Source

Downloaded from https://opencores.org/projects/aes_core on 8/8/2019.

# Modifications

- Added SDC timing constraints.
- Updated verilog to use standard verilog attributes.
- Added LICENSE file from [here](http://asics.ws/v6/free-ip-cores).
