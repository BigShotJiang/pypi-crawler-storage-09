# Summary

`black_parrot_2019_03_28` Full 64-bit RISC-V Core with Cache Coherence Directory.

# Source

Cloned from README (`commit a6b8be03ed88467269efabeaf168459d14199c69`).

# Modifications

- Generated memory using [`bsg_fakeram` for `nangate45`](https://github.com/bespoke-silicon-group/bsg_fakeram).
- Hardened memory blocks.
- Added timing constraints.
