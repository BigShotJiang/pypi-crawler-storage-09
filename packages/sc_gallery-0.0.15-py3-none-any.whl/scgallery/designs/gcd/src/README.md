# Summary

Simple GCD (greatest common denominator) core. This is an extremely small
design mostly used to test the sanity of the flow.

Originally generated using [PyMTL](https://github.com/cornell-brg/pymtl).

This design has about 250 cells.

# Source

Reused code derived from http://opencelerity.org/ project.
