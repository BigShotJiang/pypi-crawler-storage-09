# Summary

JPEG Encoder core from the Video Compression Systems Project.  The 'Video
Compression Systems Project' was started with the idea to provide readily
available blocks for compression systems.  It has about 417,000 cells.

# Source

Downloaded from https://opencores.org/projects/video_systems on 8/8/2019.

# Modifications

- Added SDC timing constraints.
- Updated verilog to use standard verilog attributes.
- Added LICENSE file from [here](http://asics.ws/v6/free-ip-cores).
