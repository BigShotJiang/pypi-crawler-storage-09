# Summary

Simple RISCV 32I core.

# Source

Created for an OSU undergraduate course in July 2019.
