# Summary

Basic Universal Asynchronous Receiver Transmitter, communications application

# Source

# Modifications

- Added sdc timing constraints.
- Added LICENSE file.
