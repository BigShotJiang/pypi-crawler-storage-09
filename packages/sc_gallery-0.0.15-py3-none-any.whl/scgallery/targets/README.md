# Library targets

Targets to provide `sc-gallery` to change the default main library
