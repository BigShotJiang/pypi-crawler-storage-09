from siliconcompiler import ASIC
from siliconcompiler.targets import asap7_demo


def asap7sc7p5t_rvt(proj: ASIC):
    asap7_demo(proj)
