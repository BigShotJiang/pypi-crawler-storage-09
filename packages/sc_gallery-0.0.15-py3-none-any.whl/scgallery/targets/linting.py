from siliconcompiler import Lint


####################################################
# Target Setup
####################################################
def lint(proj: Lint):
    '''
    Dummy target to use for linting
    '''
