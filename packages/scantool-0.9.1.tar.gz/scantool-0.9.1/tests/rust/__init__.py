"""Rust scanner tests."""
