lsky_user_info_tag_bind = {
    "姓名": "nickname",
    "邮箱": "email",
    "注册时间": "register_time",
    "注册 IP": "register_ip",
    "组名": "group",
    "最大文件大小": "max_file_size",
    "并发上传数量": "concurrent_upload_num",
    "每分钟上传限制": "upload_limit_per_minute",
    "每小时上传限制": "upload_limit_per_hour",
    "每天上传限制": "upload_limit_per_day",
    "每周上传限制": "upload_limit_per_week",
    "每月上传限制": "upload_limit_per_month",
}