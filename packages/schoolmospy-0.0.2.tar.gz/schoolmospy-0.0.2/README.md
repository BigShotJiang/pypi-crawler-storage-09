# 📕 SchoolMosPy

SchoolMosPy - a lightweight Python wrapper for school.mos.py APIs.


