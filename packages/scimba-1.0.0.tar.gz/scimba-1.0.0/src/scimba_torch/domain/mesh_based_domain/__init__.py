"""Mesh-based domains."""

from .cuboid import Cuboid as Cuboid
