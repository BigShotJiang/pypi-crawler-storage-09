"""Structure preserving neural networks."""
