"""Time-discrete numerical solvers for temporal PDEs."""
