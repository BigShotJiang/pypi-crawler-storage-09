"""Models for temporal partial differential equations."""
