from . import methods
from ._sclab import SCLabDashboard

__all__ = [
    "methods",
    "SCLabDashboard",
]

__version__ = "0.3.3"
