# Score.dev Python loader

Python implementation of the [score.dev](https://docs.score.dev/docs/) specification, allowing to load workload definition and applying a first pass of evaluation for `${metadata...}` placeholders.

`${resources...}` placeholders must be evaluated after provisioning of the resources, cannot be done while loading the workload definition.

## Unit tests

`uv run pytest`


