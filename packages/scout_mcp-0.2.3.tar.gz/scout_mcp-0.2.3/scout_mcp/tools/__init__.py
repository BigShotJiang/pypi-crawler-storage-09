"""MCP tools for ceregrep."""
