LOG_LEVEL_BASE_KEY = "log-level"
