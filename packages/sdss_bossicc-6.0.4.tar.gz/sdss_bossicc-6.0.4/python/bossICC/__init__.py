from sdsstools import get_package_version


NAME = "sdss-bossICC"

__version__ = get_package_version(path=__file__, package_name=NAME)
