from .labels import DEFAULT_LABELS
from .dummy_values import DEFAULT_DUMMY_VALUES

__all__ = ["DEFAULT_LABELS", "DEFAULT_DUMMY_VALUES"]
