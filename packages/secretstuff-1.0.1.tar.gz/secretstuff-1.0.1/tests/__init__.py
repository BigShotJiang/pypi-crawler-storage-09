"""Test suite for SecretStuff package."""
