from secuamir import fa_to_qwerty, qwerty_to_fa

def test_roundtrip():
    fa = "سلام"
    enc = fa_to_qwerty(fa)
    assert enc == "sghl"
    assert qwerty_to_fa(enc) == fa
