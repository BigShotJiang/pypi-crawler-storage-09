# 🔐 secuamir
### Innovative Persian-English Keyboard Cryptography Library  
کتابخانه رمزنگاری مبتکرانه برای تبدیل متن فارسی به کد معادل کیبوردی انگلیسی و برعکس.

---

## 📦 نصب | Installation
```bash
pip install secuamir

import secuamir

text = "سلام"
encrypted = secuamir.encrypt(text)
print(encrypted)  # sghl


decoded = secuamir.decrypt("sghl")
print(decoded)  # سلام


