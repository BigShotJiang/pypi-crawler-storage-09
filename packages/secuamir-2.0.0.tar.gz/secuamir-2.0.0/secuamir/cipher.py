# secuamir/cipher.py
# secuamir 🔐
# Persian-English Keyboard Mapping Cipher + Optional Secure Fernet Layer
# نسخهٔ بهبود یافته: شامل نگاشت صفحه‌کلید و رمزنگاری امن (Fernet)

from typing import Optional

# ---------------------------
# Mapping Persian letters to English keyboard equivalents
# نگاشت حروف فارسی به معادل کیبورد انگلیسی
# ---------------------------
mapping = {
    'ض': 'q', 'ص': 'w', 'ث': 'e', 'ق': 'r', 'ف': 't', 'غ': 'y', 'ع': 'u', 'ه': 'i',
    'خ': 'o', 'ح': 'p', 'ج': '[', 'چ': ']', 'ش': 'a', 'س': 's', 'ی': 'd', 'ب': 'f',
    'ل': 'g', 'ا': 'h', 'ت': 'j', 'ن': 'k', 'م': 'l', 'ک': ';', 'گ': "'", 'ظ': 'z',
    'ط': 'x', 'ز': 'c', 'ر': 'v', 'ذ': 'b', 'د': 'n', 'پ': 'm', 'و': ',', '؟': '?',
    '،': ',', '؛': ';', '٫': '.', '.': '.', '!': '!', ' ': ' '
}

# Reverse mapping: English-key → Persian
reverse_mapping = {v: k for k, v in mapping.items()}

# ---------------------------
# Simple keyboard-based transliteration
# توابع سادهٔ نگاشتِ صفحه‌کلید
# ---------------------------

def keyboard_encrypt(text: str) -> str:
    """
    تبدیل متن فارسی به معادل کیبوردی انگلیسی (قابل بازگردانی).
    Example: "سلام" -> "sghl"
    """
    return ''.join(mapping.get(ch, ch) for ch in text)


def keyboard_decrypt(text: str) -> str:
    """
    تبدیل معادل کیبوردی انگلیسی به متن فارسی.
    Example: "sghl" -> "سلام"
    """
    return ''.join(reverse_mapping.get(ch, ch) for ch in text)


# Aliases: old API compatibility
encrypt = keyboard_encrypt
decrypt = keyboard_decrypt

# ---------------------------
# Optional secure layer (Fernet symmetric encryption)
# لایهٔ امنِ اختیاری با استفاده از Fernet از کتابخانه cryptography
# ---------------------------

# Try importing Fernet; provide helpful error if not installed.
try:
    from cryptography.fernet import Fernet, InvalidToken  # type: ignore
    _CRYPTO_AVAILABLE = True
except Exception:
    Fernet = None  # type: ignore
    InvalidToken = Exception  # type: ignore
    _CRYPTO_AVAILABLE = False


def crypto_available() -> bool:
    """Returns True if 'cryptography' library (Fernet) is available."""
    return _CRYPTO_AVAILABLE


def generate_key() -> bytes:
    """
    Generate a new Fernet key.
    ذخیرهٔ امن این کلید بسیار مهم است — هر کسی که این را داشته باشد می‌تواند پیام‌ها را باز کند.
    """
    if not _CRYPTO_AVAILABLE:
        raise RuntimeError("cryptography is not installed. pip install cryptography")
    return Fernet.generate_key()


def encrypt_secure(plaintext: str, key: bytes, use_keyboard_step: bool = True) -> bytes:
    """
    Securely encrypt a plaintext string using Fernet.
    If use_keyboard_step=True the function first applies keyboard_encrypt (مثلاً "سلام" -> "sghl")
    and then encrypts the intermediate string. Returns a Fernet token (bytes).
    """
    if not _CRYPTO_AVAILABLE:
        raise RuntimeError("cryptography is not installed. pip install cryptography")

    intermediate = keyboard_encrypt(plaintext) if use_keyboard_step else plaintext
    f = Fernet(key)
    token = f.encrypt(intermediate.encode('utf-8'))
    return token


def decrypt_secure(token: bytes, key: bytes, use_keyboard_step: bool = True) -> str:
    """
    Decrypt a Fernet token (bytes) back to plaintext.
    If use_keyboard_step=True, after decryption the function applies keyboard_decrypt
    to return Persian text.
    """
    if not _CRYPTO_AVAILABLE:
        raise RuntimeError("cryptography is not installed. pip install cryptography")

    f = Fernet(key)
    try:
        decoded = f.decrypt(token).decode('utf-8')
    except InvalidToken as e:
        raise ValueError("Invalid token or wrong key") from e

    return keyboard_decrypt(decoded) if use_keyboard_step else decoded

