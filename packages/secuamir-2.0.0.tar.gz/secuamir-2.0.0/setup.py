from setuptools import setup, find_packages

setup(
    name="secuamir",
    version="2.0.0",
    packages=find_packages(),
    description="Innovative cryptography library for Persian-English keyboard mapping.",
    author="Amir Hossein",
    author_email="your@email.com",
    license="MIT",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://pypi.org/project/secuamir/",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Topic :: Security :: Cryptography",
        "Natural Language :: Persian",
    ],
    python_requires=">=3.6",
)
