# seeQlite

A simple and interactive terminal viewer for SQLite databases.

Installation

```
pip install seeqlite
```

Usage

Run the tool from your terminal by providing the path to an SQLite database file.

```
seeqlite ./db.sqlite3
```

You will be presented with a menu of tables to inspect.
