# Data Project Scaffolder

A Python package to provide build helpers for sefrone backend projects.

## Installation

```bash
pip install sefrone_build