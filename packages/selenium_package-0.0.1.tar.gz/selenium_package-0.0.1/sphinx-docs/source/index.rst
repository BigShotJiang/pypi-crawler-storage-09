.. selenium_package documentation master file, created by
   sphinx-quickstart on Tue Oct 21 11:41:18 2025.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

selenium_package documentation
==============================

Add your content using ``reStructuredText`` syntax. See the
`reStructuredText <https://www.sphinx-doc.org/en/master/usage/restructuredtext/index.html>`_
documentation for details.

Check out the :doc:`usage` section for further information.


.. toctree::
   
   introduction/
   interfaces/
   pre-built-objects/


   :maxdepth: 2

   :caption: Contents:


