# selenium-yaml-core
Selenium bots using YAML

## Documentation

For in-depth documentation, head over to our [GH-Pages site](https://wigeria.github.io/selenium-yaml-core/).

## Installation

```
pip install selenium-yaml
```

## Running the CLI

The CLI can be run directly by using:

```run_sally.py --yaml-file=path/to/bot/yaml```

<sub><sup>Use the `--help` argument for details on the CLI!</sup></sub>
