# seleniumbase package
__version__ = "4.43.0"
