from setuptools import setup

if __name__ == "__main__":
    setup(include_package_data=True)
