#!/usr/bin/env python
"""Setup script for package-metadata-extractor."""

from setuptools import setup

if __name__ == "__main__":
    setup()