"""License detection module using OSLiLi."""

from .unified_detector import UnifiedLicenseDetector

__all__ = [
    'UnifiedLicenseDetector'
]