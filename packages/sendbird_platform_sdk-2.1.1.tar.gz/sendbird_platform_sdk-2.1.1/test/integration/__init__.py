"""
Integration tests for Sendbird Platform SDK

These tests require actual Sendbird API credentials and will make real API calls.
"""

