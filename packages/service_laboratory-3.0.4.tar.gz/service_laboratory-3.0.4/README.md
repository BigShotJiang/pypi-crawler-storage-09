# service laboratory package

- auth module
- send email module