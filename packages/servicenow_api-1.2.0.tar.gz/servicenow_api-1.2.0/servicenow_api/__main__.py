#!/usr/bin/python
# coding: utf-8

from servicenow_api.servicenow_api_mcp import servicenow_api_mcp

if __name__ == "__main__":
    servicenow_api_mcp()
