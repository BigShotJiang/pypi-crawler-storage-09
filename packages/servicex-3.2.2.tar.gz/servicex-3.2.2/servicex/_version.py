import importlib.metadata  # type: ignore

__version__ = importlib.metadata.version("servicex")
