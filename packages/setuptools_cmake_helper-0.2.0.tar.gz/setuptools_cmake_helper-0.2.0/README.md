# setuptools-cmake-helper
Simpler helper to build a Python C/C++ Extension using CMake
