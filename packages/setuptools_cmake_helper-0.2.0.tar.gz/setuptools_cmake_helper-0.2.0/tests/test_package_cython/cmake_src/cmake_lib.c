#include "cmake_lib.h"

PyObject * my_func(PyObject * obj) {
    return obj;
}