from __future__ import annotations

from ._native import echo

__all__ = ["echo"]
