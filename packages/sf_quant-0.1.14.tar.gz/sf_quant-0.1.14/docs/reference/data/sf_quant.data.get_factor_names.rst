﻿sf\_quant.data.get\_factor\_names
=================================

.. currentmodule:: sf_quant.data

.. autofunction:: get_factor_names