﻿sf\_quant.performance.generate\_returns\_chart
==============================================

.. currentmodule:: sf_quant.performance

.. autofunction:: generate_returns_chart