﻿sf\_quant.performance.generate\_summary\_table
==============================================

.. currentmodule:: sf_quant.performance

.. autofunction:: generate_summary_table