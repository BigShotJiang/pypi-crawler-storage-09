"""
Contains utility functions.
"""
