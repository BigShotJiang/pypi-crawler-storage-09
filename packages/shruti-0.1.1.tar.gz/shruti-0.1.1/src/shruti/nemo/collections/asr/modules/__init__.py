# Copyright (c) 2020, NVIDIA CORPORATION.  All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from shruti.nemo.collections.asr.modules.audio_modules import (
    MaskBasedBeamformer,
    MaskEstimatorFlexChannels,
    MaskEstimatorRNN,
    MaskReferenceChannel,
)
from shruti.nemo.collections.asr.modules.audio_preprocessing import (
    AudioToMelSpectrogramPreprocessor,
    AudioToMFCCPreprocessor,
    AudioToSpectrogram,
    CropOrPadSpectrogramAugmentation,
    MaskedPatchAugmentation,
    SpectrogramAugmentation,
    SpectrogramToAudio,
)
from shruti.nemo.collections.asr.modules.beam_search_decoder import BeamSearchDecoderWithLM
from shruti.nemo.collections.asr.modules.conformer_encoder import ConformerEncoder, ConformerEncoderAdapter
from shruti.nemo.collections.asr.modules.conv_asr import (
    ConvASRDecoder,
    ConvASRDecoderClassification,
    ConvASRDecoderReconstruction,
    ConvASREncoder,
    ConvASREncoderAdapter,
    ECAPAEncoder,
    ParallelConvASREncoder,
    SpeakerDecoder,
)
from shruti.nemo.collections.asr.modules.graph_decoder import ViterbiDecoderWithGraph
from shruti.nemo.collections.asr.modules.hybrid_autoregressive_transducer import HATJoint
from shruti.nemo.collections.asr.modules.lstm_decoder import LSTMDecoder
from shruti.nemo.collections.asr.modules.msdd_diarizer import MSDD_module
from shruti.nemo.collections.asr.modules.rnn_encoder import RNNEncoder
from shruti.nemo.collections.asr.modules.rnnt import (
    RNNTDecoder,
    RNNTDecoderJointSSL,
    RNNTJoint,
    SampledRNNTJoint,
    StatelessTransducerDecoder,
)
from shruti.nemo.collections.asr.modules.squeezeformer_encoder import SqueezeformerEncoder, SqueezeformerEncoderAdapter
