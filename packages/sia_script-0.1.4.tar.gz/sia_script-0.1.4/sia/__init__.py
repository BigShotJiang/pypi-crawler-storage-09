from .ntt import ntt
