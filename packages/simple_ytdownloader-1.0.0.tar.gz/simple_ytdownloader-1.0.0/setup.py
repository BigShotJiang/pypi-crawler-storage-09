from setuptools import setup, find_packages

setup(
    name="simple_ytdownloader",
    version="1.0.0",
    author="Your Name",
    description="Library sederhana untuk mendownload video YouTube",
    packages=find_packages(),
    install_requires=[],
    python_requires=">=3.7",
)
