import urllib.request
import urllib.parse
import os
import re
from .utils import extract_video_info

class YouTubeDownloader:
    def __init__(self, url):
        self.url = url
        self.video_info = None
        self.streams = []

    def fetch_info(self):
        """
        Mengambil data JSON dari halaman YouTube.
        """
        print("[INFO] Mengambil data video...")
        response = urllib.request.urlopen(self.url)
        html = response.read().decode('utf-8')
        data = extract_video_info(html)
        self.video_info = data

        # Ambil judul
        self.title = data["videoDetails"]["title"]

        # Ambil format video
        streaming_data = data.get("streamingData", {})
        formats = streaming_data.get("formats", [])
        adaptive_formats = streaming_data.get("adaptiveFormats", [])
        self.streams = formats + adaptive_formats

        print(f"[INFO] Video ditemukan: {self.title}")
        return self.video_info

    def list_streams(self):
        """
        Menampilkan daftar format video yang tersedia.
        """
        if not self.streams:
            raise ValueError("Panggil fetch_info() terlebih dahulu.")
        
        print("\n[DAFTAR FORMAT TERSEDIA]:")
        for i, fmt in enumerate(self.streams):
            quality = fmt.get("qualityLabel", "Audio Only")
            mime = fmt.get("mimeType", "Unknown").split(";")[0]
            print(f"{i+1}. {quality} | {mime}")
        return self.streams

    def download(self, index=1, output_path=None):
        """
        Mendownload video berdasarkan index stream.
        """
        if not self.streams:
            raise ValueError("Tidak ada stream yang tersedia. Jalankan fetch_info() dulu.")

        stream = self.streams[index - 1]
        url = stream.get("url")

        if not url:
            # Kadang URL terenkripsi, tapi untuk versi dasar kita lewati
            raise ValueError("URL stream tidak langsung tersedia (dienkripsi).")

        filename = re.sub(r'[\\/*?:"<>|]', "", self.title) + ".mp4"
        if output_path:
            filepath = os.path.join(output_path, filename)
        else:
            filepath = filename

        print(f"[INFO] Mendownload {self.title}...")
        urllib.request.urlretrieve(url, filepath)
        print(f"[DONE] Video tersimpan di: {filepath}")
        return filepath
