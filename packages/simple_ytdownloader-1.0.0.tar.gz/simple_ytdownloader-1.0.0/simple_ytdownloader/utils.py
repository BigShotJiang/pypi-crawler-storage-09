import re
import json

def extract_video_info(html):
    """
    Ekstrak data JSON dari halaman YouTube.
    """
    pattern = r"ytInitialPlayerResponse\s*=\s*({.*?});"
    match = re.search(pattern, html)
    if not match:
        raise ValueError("Tidak dapat menemukan informasi video.")
    data = json.loads(match.group(1))
    return data
