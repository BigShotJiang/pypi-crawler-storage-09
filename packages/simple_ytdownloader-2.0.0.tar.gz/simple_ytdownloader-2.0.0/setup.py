from setuptools import setup, find_packages

setup(
    name="simple_ytdownloader",
    version="2.0.0",
    author="Your Name",
    description="YouTube Downloader dengan dukungan cipher dan progress bar.",
    packages=find_packages(),
    install_requires=["tqdm"],
    python_requires=">=3.7",
)
