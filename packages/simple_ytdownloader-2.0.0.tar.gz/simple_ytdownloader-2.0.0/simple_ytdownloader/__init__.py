from .core import YouTubeDownloader
from .exceptions import YouTubeError

__version__ = "2.0.0"
__author__ = "Your Name"
__all__ = ["YouTubeDownloader", "YouTubeError"]
