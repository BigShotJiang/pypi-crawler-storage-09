import re
import urllib.request

class Cipher:
    def __init__(self, js_url):
        self.js_url = js_url
        self.transform_plan = None
        self.func_map = None
        self._load()

    def _load(self):
        js_code = urllib.request.urlopen(self.js_url).read().decode('utf-8')

        # Temukan fungsi utama dekripsi
        name_match = re.search(r'(\w+)=function\(a\)\{a=a\.split\(""\);(.*?)return a\.join', js_code)
        if not name_match:
            raise ValueError("Tidak dapat menemukan fungsi cipher utama.")
        func_body = name_match.group(2)

        # Temukan fungsi transform
        obj_name = re.search(r'(\w+)\.\w+\(', func_body).group(1)
        obj_pattern = r'var %s=\{(.*?)\};' % re.escape(obj_name)
        obj_body = re.search(obj_pattern, js_code, re.S).group(1)

        # Buat peta transform
        self.func_map = {}
        for key, value in re.findall(r'(\w+):function\(a(,b)?\)\{([^}]+)\}', obj_body):
            if 'reverse' in value:
                self.func_map[key] = lambda s: s[::-1]
            elif 'splice' in value:
                self.func_map[key] = lambda s, b: s[b:]
            elif 'var c=a\[0\];a\[0\]=a\[b%b\.length\];a\[b\]=c' in value:
                self.func_map[key] = lambda s, b: Cipher.swap(s, b)

        # Buat rencana transform
        self.transform_plan = []
        for key, arg in re.findall(r'%s\.(\w+)\(a,(\d+)\)' % obj_name, func_body):
            self.transform_plan.append((key, int(arg)))

    @staticmethod
    def swap(a, b):
        s = list(a)
        s[0], s[b % len(s)] = s[b % len(s)], s[0]
        return ''.join(s)

    def decrypt(self, cipher_signature):
        s = cipher_signature
        for func_name, arg in self.transform_plan:
            f = self.func_map[func_name]
            if "b" in f.__code__.co_varnames:
                s = f(s, arg)
            else:
                s = f(s)
        return s
