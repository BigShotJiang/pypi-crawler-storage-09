import urllib.parse
import urllib.request
import os
import re
from .utils import fetch_html, extract_json, extract_player_js_url
from .cipher import Cipher
from .exceptions import YouTubeError
from tqdm import tqdm

class YouTubeDownloader:
    def __init__(self, url):
        self.url = url
        self.html = None
        self.info = None
        self.streams = []
        self.title = None

    def fetch_info(self):
        print("[INFO] Mengambil info video...")
        self.html = fetch_html(self.url)
        self.info = extract_json(self.html)
        self.title = re.sub(r'[\\/*?:"<>|]', "", self.info["videoDetails"]["title"])

        # Ambil daftar stream
        data = self.info.get("streamingData", {})
        self.streams = (data.get("formats", []) + data.get("adaptiveFormats", []))
        print(f"[INFO] Ditemukan {len(self.streams)} stream untuk {self.title}")

    def list_streams(self):
        for i, s in enumerate(self.streams):
            q = s.get("qualityLabel", "Audio")
            mime = s.get("mimeType", "").split(";")[0]
            cipher = "cipher" in s or "signatureCipher" in s
            print(f"{i+1}. {q} | {mime} | {'Encrypted' if cipher else 'Direct'}")
        return self.streams

    def _resolve_url(self, stream):
        """
        Mendekripsi URL terenkripsi jika perlu.
        """
        if "url" in stream:
            return stream["url"]

        cipher_data = stream.get("cipher") or stream.get("signatureCipher")
        if not cipher_data:
            raise YouTubeError("Stream tidak memiliki URL atau cipher.")

        parts = urllib.parse.parse_qs(cipher_data)
        url = parts["url"][0]
        s = parts["s"][0]
        sp = parts.get("sp", ["signature"])[0]

        js_url = extract_player_js_url(self.html)
        cipher = Cipher(js_url)
        decrypted_sig = cipher.decrypt(s)

        return f"{url}&{sp}={decrypted_sig}"

    def download(self, index=1, output_dir="."):
        if not self.streams:
            raise YouTubeError("Jalankan fetch_info() terlebih dahulu.")

        stream = self.streams[index - 1]
        url = self._resolve_url(stream)
        filename = f"{self.title}.mp4"
        filepath = os.path.join(output_dir, filename)

        # Unduh dengan progress bar
        print(f"[INFO] Mengunduh: {self.title}")
        with urllib.request.urlopen(url) as response, open(filepath, "wb") as out_file:
            total = int(response.info().get("Content-Length", -1))
            with tqdm(total=total, unit='B', unit_scale=True, desc="Downloading") as pbar:
                while True:
                    chunk = response.read(1024 * 64)
                    if not chunk:
                        break
                    out_file.write(chunk)
                    pbar.update(len(chunk))

        print(f"[DONE] File tersimpan di {filepath}")
        return filepath
