class YouTubeError(Exception):
    """Kesalahan umum YouTube downloader."""
    pass
