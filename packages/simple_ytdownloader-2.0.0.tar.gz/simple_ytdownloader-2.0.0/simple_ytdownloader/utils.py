import re
import json
import urllib.request

def fetch_html(url):
    headers = {"User-Agent": "Mozilla/5.0"}
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req) as response:
        return response.read().decode("utf-8")

def extract_json(html):
    pattern = r"ytInitialPlayerResponse\s*=\s*({.*?});"
    match = re.search(pattern, html)
    if not match:
        raise ValueError("Tidak dapat menemukan player response.")
    data = json.loads(match.group(1))
    return data

def extract_player_js_url(html):
    pattern = r'"jsUrl":"([^"]+)"'
    match = re.search(pattern, html)
    if not match:
        raise ValueError("Tidak dapat menemukan player.js URL.")
    return "https://www.youtube.com" + match.group(1).replace("\\/", "/")
