from setuptools import setup, find_packages

setup(
    name="simple_ytdownloader",
    version="2.1.0",
    author="ATHALLAH RAJENDRA PUTRA JUNIARTO",
    description="Library YouTube downloader sederhana dengan dukungan cipher dekripsi otomatis.",
    packages=find_packages(),
    install_requires=["tqdm"],
    python_requires=">=3.8",
)
