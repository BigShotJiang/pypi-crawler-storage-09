from .core import YouTubeDownloader
from .exceptions import YouTubeError

__version__ = "2.1.0"
__author__ = "ATHALLAH RAJENDRA PUTRA JUNIARTO"
__all__ = ["YouTubeDownloader", "YouTubeError"]
