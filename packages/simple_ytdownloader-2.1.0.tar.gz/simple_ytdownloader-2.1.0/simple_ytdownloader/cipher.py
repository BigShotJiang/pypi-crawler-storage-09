import re
import urllib.request

class Cipher:
    def __init__(self, js_url):
        self.js_url = js_url
        self.js_code = self._get_js_code()
        self.transform_plan, self.func_map = self._parse_functions()

    def _get_js_code(self):
        headers = {"User-Agent": "Mozilla/5.0"}
        req = urllib.request.Request(self.js_url, headers=headers)
        with urllib.request.urlopen(req) as res:
            return res.read().decode("utf-8")

    def _parse_functions(self):
        # Temukan fungsi utama cipher
        main_func = re.search(r'(\w+)=function\(a\)\{a=a\.split\(""\);(.*?)return a\.join', self.js_code)
        if not main_func:
            raise ValueError("Tidak dapat menemukan fungsi cipher utama.")
        func_body = main_func.group(2)

        # Temukan objek transform
        obj_name = re.search(r'(\w+)\.\w+\(', func_body).group(1)
        obj_body = re.search(r'var %s=\{(.*?)\};' % re.escape(obj_name), self.js_code, re.S).group(1)

        func_map = {}
        for key, _, body in re.findall(r'(\w+):function\(a(,b)?\)\{([^}]+)\}', obj_body):
            if 'reverse' in body:
                func_map[key] = lambda s: s[::-1]
            elif 'splice' in body:
                func_map[key] = lambda s, b: s[b:]
            elif 'var c=a\[0\];a\[0\]=a\[b%b\.length\];a\[b\]=c' in body:
                func_map[key] = lambda s, b: Cipher.swap(s, b)

        transform_plan = []
        for key, arg in re.findall(r'%s\.(\w+)\(a,(\d+)\)' % obj_name, func_body):
            transform_plan.append((key, int(arg)))

        return transform_plan, func_map

    @staticmethod
    def swap(a, b):
        s = list(a)
        s[0], s[b % len(s)] = s[b % len(s)], s[0]
        return ''.join(s)

    def decrypt(self, signature):
        s = signature
        for func_name, arg in self.transform_plan:
            f = self.func_map.get(func_name)
            if f:
                if 'b' in f.__code__.co_varnames:
                    s = f(s, arg)
                else:
                    s = f(s)
        return s
