import urllib.parse
import urllib.request
import os
import re
from tqdm import tqdm
from .utils import fetch_html, extract_json, extract_player_js_url
from .cipher import Cipher
from .exceptions import YouTubeError

class YouTubeDownloader:
    def __init__(self, url):
        self.url = url
        self.html = None
        self.info = None
        self.title = None
        self.streams = []

    def fetch_info(self):
        print("[INFO] Mengambil data video...")
        self.html = fetch_html(self.url)
        self.info = extract_json(self.html)

        self.title = re.sub(r'[\\/*?:"<>|]', "", self.info["videoDetails"]["title"])
        self.streams = (
            self.info.get("streamingData", {}).get("formats", []) +
            self.info.get("streamingData", {}).get("adaptiveFormats", [])
        )

        if not self.streams:
            raise YouTubeError("Tidak ada stream ditemukan.")
        print(f"[INFO] Video: {self.title}")
        return self.streams

    def list_streams(self):
        print("\n[DAFTAR FORMAT TERSEDIA]:")
        for i, s in enumerate(self.streams, start=1):
            q = s.get("qualityLabel", "Audio")
            mime = s.get("mimeType", "").split(";")[0]
            ciphered = "signatureCipher" in s
            print(f"{i}. {q:<6} | {mime:<20} | {'Encrypted' if ciphered else 'Direct'}")
        return self.streams

    def _resolve_stream_url(self, stream):
        """Menangani stream terenkripsi (cipher) otomatis."""
        if "url" in stream:
            return stream["url"]

        cipher_data = stream.get("cipher") or stream.get("signatureCipher")
        if not cipher_data:
            raise YouTubeError("Stream tidak memiliki URL maupun cipher data.")

        parts = urllib.parse.parse_qs(cipher_data)
        base_url = parts["url"][0]
        s = parts.get("s", [None])[0]
        sp = parts.get("sp", ["signature"])[0]

        if s:
            print("[INFO] Dekripsi signature terenkripsi...")
            js_url = extract_player_js_url(self.html)
            cipher = Cipher(js_url)
            decrypted = cipher.decrypt(s)
            base_url = f"{base_url}&{sp}={decrypted}"

        return base_url

    def download(self, index=1, output_dir="."):
        if not self.streams:
            raise YouTubeError("Jalankan fetch_info() terlebih dahulu.")

        try:
            stream = self.streams[index - 1]
        except IndexError:
            raise YouTubeError(f"Index {index} tidak valid.")

        url = self._resolve_stream_url(stream)
        filename = f"{self.title}.mp4"
        filepath = os.path.join(output_dir, filename)

        print(f"[INFO] Mulai mengunduh: {self.title}")
        try:
            with urllib.request.urlopen(url) as response, open(filepath, "wb") as out_file:
                total = int(response.info().get("Content-Length", -1))
                with tqdm(total=total, unit="B", unit_scale=True, desc="Downloading") as pbar:
                    while True:
                        chunk = response.read(1024 * 64)
                        if not chunk:
                            break
                        out_file.write(chunk)
                        pbar.update(len(chunk))
            print(f"[DONE] Video tersimpan di: {filepath}")
        except Exception as e:
            raise YouTubeError(f"Gagal mengunduh: {e}")

        return filepath
