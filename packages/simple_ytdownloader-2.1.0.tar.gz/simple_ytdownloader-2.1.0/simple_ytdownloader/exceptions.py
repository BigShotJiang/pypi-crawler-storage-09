class YouTubeError(Exception):
    """Kesalahan umum pada YouTube downloader."""
    pass
