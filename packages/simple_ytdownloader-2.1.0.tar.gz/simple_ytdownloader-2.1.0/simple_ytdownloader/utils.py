import re
import json
import urllib.request

def fetch_html(url):
    headers = {"User-Agent": "Mozilla/5.0"}
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req) as res:
        return res.read().decode("utf-8")

def extract_json(html):
    match = re.search(r"ytInitialPlayerResponse\s*=\s*({.*?});", html)
    if not match:
        raise ValueError("Gagal menemukan ytInitialPlayerResponse.")
    return json.loads(match.group(1))

def extract_player_js_url(html):
    match = re.search(r'"jsUrl":"([^"]+)"', html)
    if not match:
        raise ValueError("Tidak dapat menemukan player.js URL.")
    return "https://www.youtube.com" + match.group(1).replace("\\/", "/")
