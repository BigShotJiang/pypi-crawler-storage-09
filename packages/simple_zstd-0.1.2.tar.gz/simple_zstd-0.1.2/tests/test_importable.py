def test_importable():
    import simple_zstd  # noqa: F401
    import zstd  # noqa: F401
