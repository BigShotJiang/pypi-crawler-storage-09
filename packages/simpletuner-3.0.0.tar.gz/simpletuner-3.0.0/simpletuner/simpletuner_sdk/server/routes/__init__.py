"""Routes for SimpleTuner server."""
