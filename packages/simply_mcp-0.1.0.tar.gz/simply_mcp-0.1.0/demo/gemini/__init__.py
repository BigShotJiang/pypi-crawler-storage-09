"""Gemini MCP Server - Google Gemini API wrapper for MCP."""

__version__ = "1.0.0"
__author__ = "Simply-MCP Contributors"
__description__ = "MCP server for Google Gemini API with file upload and chat capabilities"

__all__ = ["server"]
