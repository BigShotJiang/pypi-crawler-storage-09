# Builder API

Functional builder API with method chaining for programmatic server construction.

::: simply_mcp.api.builder
    options:
      show_root_heading: true
      show_source: true
      heading_level: 2
