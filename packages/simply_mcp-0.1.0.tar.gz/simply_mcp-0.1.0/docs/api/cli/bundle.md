# CLI Bundle

Bundling command for creating standalone executables with PyInstaller.

::: simply_mcp.cli.bundle
    options:
      show_root_heading: true
      show_source: true
      heading_level: 2
