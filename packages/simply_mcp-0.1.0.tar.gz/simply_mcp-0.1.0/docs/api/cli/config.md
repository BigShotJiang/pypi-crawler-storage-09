# CLI Config

Configuration management commands for initializing and managing server configurations.

::: simply_mcp.cli.config
    options:
      show_root_heading: true
      show_source: true
      heading_level: 2
