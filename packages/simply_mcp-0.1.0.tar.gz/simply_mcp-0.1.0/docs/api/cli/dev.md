# CLI Dev

Development mode command with auto-reload capabilities.

::: simply_mcp.cli.dev
    options:
      show_root_heading: true
      show_source: true
      heading_level: 2
