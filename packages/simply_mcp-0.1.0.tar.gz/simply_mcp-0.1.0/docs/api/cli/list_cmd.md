# CLI List

List command for displaying registered tools, resources, and prompts.

::: simply_mcp.cli.list_cmd
    options:
      show_root_heading: true
      show_source: true
      heading_level: 2
