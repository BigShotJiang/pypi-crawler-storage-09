# CLI Main

Main CLI entry point and command group definitions using Click framework.

::: simply_mcp.cli.main
    options:
      show_root_heading: true
      show_source: true
      heading_level: 2
