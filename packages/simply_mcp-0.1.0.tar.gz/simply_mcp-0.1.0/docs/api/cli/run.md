# CLI Run

Run command implementation for starting MCP servers.

::: simply_mcp.cli.run
    options:
      show_root_heading: true
      show_source: true
      heading_level: 2
