# CLI Utils

Utility functions for CLI operations including API auto-detection.

::: simply_mcp.cli.utils
    options:
      show_root_heading: true
      show_source: true
      heading_level: 2
