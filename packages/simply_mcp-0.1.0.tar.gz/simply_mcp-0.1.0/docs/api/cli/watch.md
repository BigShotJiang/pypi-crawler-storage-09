# CLI Watch

File watching utilities for development mode.

::: simply_mcp.cli.watch
    options:
      show_root_heading: true
      show_source: true
      heading_level: 2
