# Config

Server configuration management with Pydantic settings for environment variables and TOML files.

::: simply_mcp.core.config
    options:
      show_root_heading: true
      show_source: true
      heading_level: 2
