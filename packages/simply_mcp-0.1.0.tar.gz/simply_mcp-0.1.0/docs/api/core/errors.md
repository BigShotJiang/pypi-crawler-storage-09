# Errors

Custom exception classes for error handling in MCP servers.

::: simply_mcp.core.errors
    options:
      show_root_heading: true
      show_source: true
      heading_level: 2
