# Logger

Structured JSON logging utilities for production-grade observability.

::: simply_mcp.core.logger
    options:
      show_root_heading: true
      show_source: true
      heading_level: 2
