# Registry

Central registry for managing tools, resources, and prompts in MCP servers.

::: simply_mcp.core.registry
    options:
      show_root_heading: true
      show_source: true
      heading_level: 2
