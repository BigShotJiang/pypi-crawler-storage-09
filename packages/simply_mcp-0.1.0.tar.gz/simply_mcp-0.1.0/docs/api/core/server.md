# Server

The core MCP server implementation providing the main interface for building Model Context Protocol servers.

::: simply_mcp.core.server
    options:
      show_root_heading: true
      show_source: true
      heading_level: 2
