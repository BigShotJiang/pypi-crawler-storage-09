# Types

Core type definitions and Pydantic models used throughout the framework.

::: simply_mcp.core.types
    options:
      show_root_heading: true
      show_source: true
      heading_level: 2
