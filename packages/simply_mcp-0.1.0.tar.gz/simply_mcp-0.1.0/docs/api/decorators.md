# Decorators API

Decorator-based API for defining MCP tools, resources, and prompts with automatic schema generation.

::: simply_mcp.api.decorators
    options:
      show_root_heading: true
      show_source: true
      heading_level: 2
