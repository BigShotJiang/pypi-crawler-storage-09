# Binary Resources

Support for serving binary data resources (images, files, etc.) through MCP.

::: simply_mcp.features.binary
    options:
      show_root_heading: true
      show_source: true
      heading_level: 2
