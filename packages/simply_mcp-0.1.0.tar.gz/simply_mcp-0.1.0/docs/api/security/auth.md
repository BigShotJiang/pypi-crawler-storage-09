# Authentication

Authentication and authorization middleware for securing MCP servers.

::: simply_mcp.security.auth
    options:
      show_root_heading: true
      show_source: true
      heading_level: 2
