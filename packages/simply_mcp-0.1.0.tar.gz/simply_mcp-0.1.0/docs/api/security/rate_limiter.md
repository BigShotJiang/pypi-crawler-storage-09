# Rate Limiter

Rate limiting middleware to protect servers from excessive requests.

::: simply_mcp.security.rate_limiter
    options:
      show_root_heading: true
      show_source: true
      heading_level: 2
