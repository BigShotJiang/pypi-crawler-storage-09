# Transport Factory

Factory for creating and configuring transport instances.

::: simply_mcp.transports.factory
    options:
      show_root_heading: true
      show_source: true
      heading_level: 2
