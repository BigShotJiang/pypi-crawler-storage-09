# Middleware

CORS middleware and other request processing utilities for HTTP transports.

::: simply_mcp.transports.middleware
    options:
      show_root_heading: true
      show_source: true
      heading_level: 2
