# SSE Transport

Server-Sent Events (SSE) transport for real-time communication with MCP clients.

::: simply_mcp.transports.sse
    options:
      show_root_heading: true
      show_source: true
      heading_level: 2
