# STDIO Transport

Standard input/output transport for local MCP server communication.

::: simply_mcp.transports.stdio
    options:
      show_root_heading: true
      show_source: true
      heading_level: 2
