# Schema Validation

JSON Schema validation utilities for MCP protocol compliance.

::: simply_mcp.validation.schema
    options:
      show_root_heading: true
      show_source: true
      heading_level: 2
