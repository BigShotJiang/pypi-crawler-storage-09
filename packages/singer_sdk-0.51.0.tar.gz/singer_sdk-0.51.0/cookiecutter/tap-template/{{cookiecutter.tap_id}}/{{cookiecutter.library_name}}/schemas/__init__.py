"""JSON schema files for the REST API."""
