﻿singer_sdk.authenticators.BearerTokenAuthenticator
==================================================

.. currentmodule:: singer_sdk.authenticators

.. autoclass:: BearerTokenAuthenticator
    :members:
    :special-members: __init__, __call__