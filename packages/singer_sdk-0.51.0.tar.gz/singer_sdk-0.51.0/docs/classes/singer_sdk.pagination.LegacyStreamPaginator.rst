﻿singer_sdk.pagination.LegacyStreamPaginator
===========================================

.. currentmodule:: singer_sdk.pagination

.. autoclass:: LegacyStreamPaginator
    :members:
    :special-members: __init__, __call__