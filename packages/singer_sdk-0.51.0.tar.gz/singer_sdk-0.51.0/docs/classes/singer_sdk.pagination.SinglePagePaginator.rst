﻿singer_sdk.pagination.SinglePagePaginator
=========================================

.. currentmodule:: singer_sdk.pagination

.. autoclass:: SinglePagePaginator
    :members:
    :special-members: __init__, __call__