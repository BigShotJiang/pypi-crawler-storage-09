﻿singer_sdk.typing.DurationType
==============================

.. currentmodule:: singer_sdk.typing

.. autoclass:: DurationType
    :members:
    :special-members: __init__, __call__