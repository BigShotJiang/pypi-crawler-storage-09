﻿singer_sdk.typing.HostnameType
==============================

.. currentmodule:: singer_sdk.typing

.. autoclass:: HostnameType
    :members:
    :special-members: __init__, __call__