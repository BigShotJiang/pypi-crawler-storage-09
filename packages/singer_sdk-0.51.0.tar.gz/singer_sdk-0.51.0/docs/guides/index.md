# In-depth Guides

The following pages contain useful information for developers building on top of the Singer SDK.

```{toctree}
:maxdepth: 2

porting
pagination-classes
schema-sources
custom-clis
config-schema
performance
sql-tap
sql-target

migrate-to-uv
```
