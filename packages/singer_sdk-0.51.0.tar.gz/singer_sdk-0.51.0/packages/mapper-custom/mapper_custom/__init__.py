"""Stream maps transformer."""

from __future__ import annotations
