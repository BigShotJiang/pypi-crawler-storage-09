"""SDK tests."""

from __future__ import annotations
