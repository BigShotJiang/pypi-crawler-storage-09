"""Tap for DummyJSON."""
