"""Custom SQL adapter."""
