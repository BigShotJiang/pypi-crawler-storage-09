from .client import SingTownAIClient

__all__ = ["SingTownAIClient"]
