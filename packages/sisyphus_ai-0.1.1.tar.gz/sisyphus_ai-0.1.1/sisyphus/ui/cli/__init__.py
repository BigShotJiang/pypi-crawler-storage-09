from sisyphus.ui.cli.console import CLI

__all__ = ["CLI"]
