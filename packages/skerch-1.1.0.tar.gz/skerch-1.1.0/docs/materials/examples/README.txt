:github_url: https://github.com/andres-fr/skerch

Examples
========
