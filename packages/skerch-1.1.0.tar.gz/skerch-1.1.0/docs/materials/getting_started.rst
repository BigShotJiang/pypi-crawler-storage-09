Getting Started
===============

Installation
------------

.. code:: bash

  pip install skerch

Developers see the :ref:`For Developers section <For Developers>` for comprehensive installation.


Basic usage
---------------

See the :ref:`Examples section<Examples>`.
