"""Skill Management MCP Server."""

__version__ = "0.1.0"
__author__ = "Your Name"

from skill_mcp.server import app, main

__all__ = ["app", "main"]
