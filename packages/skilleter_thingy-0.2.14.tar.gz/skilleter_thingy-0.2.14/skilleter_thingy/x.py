import subprocess

subprocess.check_call(['ls'])
