"""SkySpark client and type conversion utilities"""

