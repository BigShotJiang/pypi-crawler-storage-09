from pathlib import Path


async def run_code(path: Path) -> None:
    # initialize the SkyvernPage object

    # initialize workflow run context

    # load the python file and do validation

    # run the preloaded workflow
    return
