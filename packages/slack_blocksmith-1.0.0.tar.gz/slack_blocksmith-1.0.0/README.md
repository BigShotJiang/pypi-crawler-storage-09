# Slack Block Kit Builder

> **Package Type**: Python Library  
> **Primary Use**: Slack Block Kit JSON Generation  
> **Pattern**: Builder Pattern with Method Chaining  
> **Validation**: Pydantic-based Type Safety  
> **Target**: Slack API Integration  

A comprehensive Python package for building Slack Block Kit structures with dedicated classes using the builder pattern. Provides a type-safe, intuitive API for creating Slack messages, modals, and home tabs without the complexity of raw JSON construction.

## 📋 Quick Reference

**Main Classes:**
- `Message` - Build Slack messages with blocks
- `Modal` - Build interactive modals  
- `HomeTab` - Build home tab interfaces
- `Section`, `Actions`, `Context` - Block containers
- `Button`, `SelectMenu`, `Input` - Interactive elements
- `PlainText`, `MrkdwnText` - Text objects

**Key Methods:**
- `.create()` - Initialize objects
- `.build()` - Generate JSON output
- `.add_*()` - Add blocks/elements (Message builder)
- `.set_*()` - Configure properties (Builder pattern)

### 🤖 AI Agent Decision Tree

**Need to create a Slack message?**
```
Start with Message.create()
├── Add text content? → .add_section(text)
├── Add interactive buttons? → .add_actions([Button.create(text, action_id)])
├── Add form inputs? → .add_input(label, InputElement.create(action_id))
├── Add images? → .add_image(url, alt_text)
└── Add context info? → .add_context([text_or_elements])
```

**Need interactive elements?**
```
Button → Button.create(text, action_id)
Dropdown → StaticSelect.create(action_id, placeholder, options)
Text Input → PlainTextInput.create(action_id)
Date Picker → DatePicker.create(action_id)
Multi-select → MultiStaticSelect.create(action_id, placeholder, options)
```

**Need text formatting?**
```
Plain text → PlainText.create(text)
Markdown → MrkdwnText.create(text)
```

**Need a modal?**
```
Start with Modal.create(title)
├── Add inputs → .add_input(label, element)
├── Set buttons → .submit(text).close(text)
└── Add metadata → .callback_id(id).private_metadata(data)
```

## 🚀 Features

- **🏗️ Builder Pattern**: Fluent method chaining for intuitive API design
- **🔒 Type Safety**: Full pydantic validation with comprehensive type hints
- **📦 Complete Coverage**: All Slack Block Kit blocks, elements, and composition objects
- **🔄 Easy Migration**: Clear 1:1 mapping to Slack Block Kit JSON structure
- **✨ Code Quality**: Ruff linting, mypy type checking, comprehensive test coverage
- **📚 Rich Documentation**: Extensive examples, API reference, and migration guides
- **⚡ Performance**: Optimized for both development and production use

## 📦 Installation

### Using pip
```bash
pip install slack-block-kit-builder
```

### Using uv (recommended)
```bash
uv add slack-block-kit-builder
```

### Development Installation
```bash
git clone https://github.com/your-org/slack-block-kit-builder.git
cd slack-block-kit-builder
uv pip install -e ".[dev]"
```

## 🎯 Why Use slack-block-kit-builder?

### Before: Raw JSON Construction
```python
# Complex, error-prone, hard to maintain
message = {
    "blocks": [
        {
            "type": "section",
            "text": {
                "type": "mrkdwn",
                "text": "Hello *World*! 👋"
            },
            "accessory": {
                "type": "button",
                "text": {
                    "type": "plain_text",
                    "text": "Click Me"
                },
                "action_id": "btn_click",
                "style": "primary"
            }
        },
        {
            "type": "divider"
        },
        {
            "type": "context",
            "elements": [
                {
                    "type": "mrkdwn",
                    "text": "Built with slack-block-kit-builder"
                }
            ]
        }
    ]
}
```

### After: Builder Pattern
```python
# Clean, type-safe, maintainable
from slack_blocksmith import Message, Section, Button, MrkdwnText

message = (
    Message.create()
    .add_section(
        text=MrkdwnText.create("Hello *World*! 👋"),
        accessory=Button.create("Click Me", "btn_click").style("primary")
    )
    .add_divider()
    .add_context(["Built with slack-block-kit-builder"])
    .build()
)
```

## 🤖 AI Agent Usage Patterns

### Common Import Patterns
```python
# Basic imports for most use cases
from slack_blocksmith import Message, Section, Button, PlainText

# Full imports for complex applications
from slack_blocksmith import (
    Message, Modal, HomeTab,
    Section, Actions, Context, Input, Header,
    Button, StaticSelect, PlainTextInput, DatePicker,
    PlainText, MrkdwnText, Option
)
```

### Standard Message Creation Pattern
```python
# Pattern: Create -> Configure -> Build
message = (
    Message.create()
    .add_section("Text content")
    .add_actions([Button.create("Action", "action_id")])
    .build()
)
```

### Element Configuration Pattern
```python
# Pattern: Create -> Set Properties -> Build
button = (
    Button.create("Click Me", "btn_1")
    .style("primary")
    .confirm(confirmation_dialog)
    .build()
)
```

### Common Error Patterns
```python
# ❌ Wrong: Missing action_id
Button.create("Text")  # ValidationError

# ✅ Correct: Include action_id
Button.create("Text", "action_id")

# ❌ Wrong: Invalid style
Button.create("Text", "btn").style("invalid")  # ValidationError

# ✅ Correct: Valid styles
Button.create("Text", "btn").style("primary")  # or "danger"
```

## 🚀 Quick Start

### Basic Message

```python
from slack_blocksmith import Message, Section, Button, PlainText

message = (
    Message.create()
    .add_section("Hello World! 👋")
    .add_divider()
    .add_section(
        text="This is a *markdown* message with a button:",
        accessory=Button.create("Click Me!", "btn_click")
    )
    .add_context(["Built with slack-block-kit-builder"])
    .build()
)
```

### Interactive Message

```python
from slack_blocksmith import Message, Button, StaticSelect, Option

message = (
    Message.create()
    .add_header("Task Management")
    .add_section("Choose an action:")
    .add_actions([
        Button.create("Approve", "btn_approve").style("primary"),
        Button.create("Reject", "btn_reject").style("danger"),
        StaticSelect.create("priority", "Priority", [
            Option.create("High", "high"),
            Option.create("Medium", "medium"),
            Option.create("Low", "low")
        ])
    ])
    .build()
)
```

### Modal

```python
from slack_blocksmith import Modal, PlainTextInput, DatePicker, StaticSelect, Option

modal = (
    Modal.create("User Registration")
    .add_header("New User Registration")
    .add_input("Full Name", PlainTextInput.create("full_name").placeholder("Enter name"))
    .add_input("Start Date", DatePicker.create("start_date").placeholder("Select date"))
    .add_input("Department", StaticSelect.create("dept", "Select department", [
        Option.create("Engineering", "eng"),
        Option.create("Marketing", "marketing")
    ]))
    .submit("Register")
    .close("Cancel")
    .build()
)
```

## 📚 API Reference for AI Agents

### Class Hierarchy
```
Base Classes:
├── BaseModel (pydantic)
├── Element (interactive elements)
├── Block (container blocks)
└── TextObject (text formatting)

Message Builders:
├── Message
├── Modal  
└── HomeTab

Blocks:
├── Section (text + optional accessory)
├── Actions (interactive elements container)
├── Context (small text/images)
├── Input (form input with label)
├── Header (large text)
├── Divider (separator)
├── Image (image display)
├── File (file display)
├── Video (video display)
└── RichText (rich formatting)

Elements:
├── Button (interactive button)
├── StaticSelect (dropdown menu)
├── MultiStaticSelect (multi-select dropdown)
├── PlainTextInput (text input field)
├── EmailInput (email input field)
├── NumberInput (number input field)
├── URLInput (URL input field)
├── DatePicker (date selection)
├── TimePicker (time selection)
├── DatetimePicker (date+time selection)
├── Checkboxes (multiple checkboxes)
├── RadioButtons (radio button group)
├── OverflowMenu (overflow menu)
├── FileInput (file upload)
├── RichTextInput (rich text input)
└── Image (image element)

Composition Objects:
├── PlainText (plain text object)
├── MrkdwnText (markdown text object)
├── Option (select menu option)
├── OptionGroup (grouped options)
├── ConfirmationDialog (confirmation dialog)
├── Filter (conversation filter)
└── ConversationFilter (conversation filter)
```

### Method Patterns by Class Type

**Message Builders:**
- `.create()` - Initialize
- `.add_section(text, fields, accessory)` - Add text section
- `.add_actions(elements)` - Add interactive elements
- `.add_context(elements)` - Add context elements
- `.add_input(label, element)` - Add form input
- `.add_header(text)` - Add header
- `.add_divider()` - Add separator
- `.add_image(url, alt_text)` - Add image
- `.add_file(url)` - Add file
- `.add_video(url, alt_text)` - Add video
- `.add_rich_text(elements)` - Add rich text
- `.add_block(block)` - Add custom block
- `.build()` - Generate JSON

**Interactive Elements:**
- `.create(text, action_id)` - Initialize with required params
- `.style("primary"|"danger")` - Set button style
- `.confirm(dialog)` - Set confirmation dialog
- `.placeholder(text)` - Set placeholder text
- `.initial_value(value)` - Set initial value
- `.build()` - Generate JSON

**Text Objects:**
- `.create(text)` - Initialize with text
- `.emoji(True|False)` - Enable/disable emoji
- `.verbatim(True|False)` - Enable/disable verbatim (MrkdwnText)
- `.build()` - Generate JSON

## 📚 Comprehensive API Reference

### 🏗️ Message Builders

#### `Message`
The primary class for building Slack messages with blocks.

```python
from slack_blocksmith import Message

message = (
    Message.create()
    .add_section("Hello World!")
    .add_divider()
    .add_actions([...])
    .build()
)
```

**Key Methods:**
- `.add_section()` - Add text sections with optional fields and accessories
- `.add_divider()` - Add visual separators
- `.add_actions()` - Add interactive elements container
- `.add_context()` - Add small text/images at bottom
- `.add_input()` - Add form inputs with labels
- `.add_header()` - Add large header text
- `.add_image()` - Add image blocks
- `.add_file()` - Add file display blocks
- `.add_video()` - Add video display blocks
- `.add_rich_text()` - Add rich text formatting
- `.add_block()` - Add any custom block
- `.build()` - Return complete message dictionary

#### `Modal`
Build interactive modals for user input.

```python
from slack_blocksmith import Modal, PlainTextInput, DatePicker

modal = (
    Modal.create("User Registration")
    .add_header("New User Registration")
    .add_input("Name", PlainTextInput.create("name"))
    .add_input("Date", DatePicker.create("date"))
    .submit("Register")
    .close("Cancel")
    .build()
)
```

**Key Methods:**
- `.add_header()` - Add modal title
- `.add_input()` - Add form inputs
- `.submit()` - Set submit button text
- `.close()` - Set close button text
- `.callback_id()` - Set callback identifier
- `.private_metadata()` - Set private metadata

#### `HomeTab`
Build home tab interfaces for Slack apps.

```python
from slack_blocksmith import HomeTab

home_tab = (
    HomeTab.create()
    .add_header("Welcome to My App")
    .add_section("Dashboard content here")
    .build()
)
```

### 🧱 Blocks

#### `Section`
Text blocks with optional fields and accessories.

```python
from slack_blocksmith import Section, Button, MrkdwnText

section = (
    Section.create()
    .text("Main text content")
    .fields(["Field 1", "Field 2"])
    .accessory(Button.create("Action", "btn_1"))
    .build()
)
```

#### `Actions`
Container for interactive elements (buttons, selects, etc.).

```python
from slack_blocksmith import Actions, Button, StaticSelect

actions = (
    Actions.create()
    .add_element(Button.create("Approve", "btn_approve"))
    .add_element(StaticSelect.create("priority", "Priority", options))
    .build()
)
```

#### `Context`
Small text/images at the bottom of messages.

```python
from slack_blocksmith import Context, PlainText, Image

context = (
    Context.create()
    .add_element(PlainText.create("Status: Active"))
    .add_element(Image.create("https://example.com/icon.png", "Icon"))
    .build()
)
```

#### `Input`
Form input blocks with labels and validation.

```python
from slack_blocksmith import Input, PlainTextInput

input_block = (
    Input.create("Full Name")
    .element(PlainTextInput.create("name").placeholder("Enter your name"))
    .optional(False)
    .hint("This will be displayed publicly")
    .build()
)
```

#### `Header`
Large header text blocks.

```python
from slack_blocksmith import Header

header = (
    Header.create("Important Announcement")
    .build()
)
```

#### `Image`
Display image blocks.

```python
from slack_blocksmith import Image

image = (
    Image.create("https://example.com/image.jpg", "Image description")
    .title("Image Title")
    .build()
)
```

#### `Video`
Display video blocks.

```python
from slack_blocksmith import Video

video = (
    Video.create("https://example.com/video.mp4", "Video description")
    .title("Video Title")
    .thumbnail_url("https://example.com/thumb.jpg")
    .build()
)
```

#### `File`
Display file blocks.

```python
from slack_blocksmith import File

file = (
    File.create("https://example.com/document.pdf")
    .title("Important Document")
    .description("Quarterly report")
    .build()
)
```

#### `RichText`
Rich text formatting blocks.

```python
from slack_blocksmith import RichText

rich_text = (
    RichText.create()
    .add_section("Bold text", style="bold")
    .add_list(["Item 1", "Item 2"])
    .build()
)
```

### 🎛️ Elements

#### Buttons
Interactive buttons with various styles and confirmations.

```python
from slack_blocksmith import Button, ConfirmationDialog

# Basic button
button = Button.create("Click Me", "btn_1").build()

# Styled button
button = (
    Button.create("Delete", "btn_delete")
    .style("danger")
    .confirm(ConfirmationDialog.create(
        "Delete Item",
        "Are you sure?",
        "Delete",
        "Cancel"
    ))
    .build()
)
```

#### Input Fields
Various input field types for forms.

```python
from slack_blocksmith import (
    PlainTextInput, EmailInput, NumberInput, 
    URLInput, DatePicker, TimePicker, DatetimePicker
)

# Text input
text_input = (
    PlainTextInput.create("name")
    .placeholder("Enter your name")
    .multiline(True)
    .max_length(100)
    .build()
)

# Email input
email_input = (
    EmailInput.create("email")
    .placeholder("user@example.com")
    .build()
)

# Number input
number_input = (
    NumberInput.create("age")
    .min_value(0)
    .max_value(120)
    .is_decimal_allowed(False)
    .build()
)

# Date picker
date_picker = (
    DatePicker.create("start_date")
    .placeholder("Select date")
    .initial_date("2024-01-01")
    .build()
)
```

#### Select Menus
Various select menu types for user choices.

```python
from slack_blocksmith import (
    StaticSelect, ExternalSelect, UsersSelect, 
    ConversationsSelect, ChannelsSelect, Option, OptionGroup
)

# Static select
static_select = (
    StaticSelect.create("priority", "Choose Priority", [
        Option.create("High", "high"),
        Option.create("Medium", "medium"),
        Option.create("Low", "low")
    ])
    .placeholder("Select priority")
    .build()
)

# Multi-select
multi_select = (
    MultiStaticSelect.create("tags", "Choose Tags", [
        Option.create("Bug", "bug"),
        Option.create("Feature", "feature"),
        Option.create("Enhancement", "enhancement")
    ])
    .placeholder("Select tags")
    .max_selected_items(3)
    .build()
)

# User select
user_select = (
    UsersSelect.create("assignee", "Assign to")
    .placeholder("Select user")
    .initial_user("U123456")
    .build()
)
```

#### Other Elements

```python
from slack_blocksmith import (
    Checkboxes, RadioButtons, OverflowMenu, 
    FileInput, RichTextInput
)

# Checkboxes
checkboxes = (
    Checkboxes.create("notifications", [
        Option.create("Email", "email"),
        Option.create("SMS", "sms"),
        Option.create("Push", "push")
    ])
    .build()
)

# Radio buttons
radio_buttons = (
    RadioButtons.create("preference", [
        Option.create("Option 1", "opt1"),
        Option.create("Option 2", "opt2")
    ])
    .build()
)

# Overflow menu
overflow = (
    OverflowMenu.create("actions", [
        Option.create("Edit", "edit"),
        Option.create("Delete", "delete"),
        Option.create("Share", "share")
    ])
    .build()
)

# File input
file_input = (
    FileInput.create("upload")
    .filetypes(["pdf", "doc", "docx"])
    .max_files(5)
    .build()
)
```

### 🧩 Composition Objects

#### Text Objects
Text formatting and display objects.

```python
from slack_blocksmith import PlainText, MrkdwnText

# Plain text
plain_text = (
    PlainText.create("Hello World")
    .emoji(True)
    .build()
)

# Markdown text
markdown_text = (
    MrkdwnText.create("Hello *World*! :wave:")
    .verbatim(False)
    .build()
)
```

#### Options and Option Groups
Selection options for menus and selects.

```python
from slack_blocksmith import Option, OptionGroup

# Single option
option = (
    Option.create("High Priority", "high")
    .description("Urgent tasks")
    .build()
)

# Option group
option_group = (
    OptionGroup.create("Priority Levels", [
        Option.create("High", "high"),
        Option.create("Medium", "medium"),
        Option.create("Low", "low")
    ])
    .build()
)
```

#### Confirmation Dialogs
Confirmation dialogs for destructive actions.

```python
from slack_blocksmith import ConfirmationDialog

confirm_dialog = (
    ConfirmationDialog.create(
        "Delete Item",
        "Are you sure you want to delete this item? This action cannot be undone.",
        "Delete",
        "Cancel"
    )
    .style("danger")
    .build()
)
```

#### Filters
Filters for conversation and user selection.

```python
from slack_blocksmith import Filter, ConversationFilter

# Basic filter
filter_obj = (
    Filter.create()
    .include(["public", "private"])
    .exclude_external_shared_channels(True)
    .exclude_bot_users(True)
    .build()
)

# Conversation filter
conv_filter = (
    ConversationFilter.create()
    .include(["public", "private"])
    .exclude_external_shared_channels(True)
    .build()
)
```

## 🎯 Real-World Examples

### 📝 Form Message
Complete form with various input types and validation.

```python
from slack_blocksmith import (
    Message, PlainTextInput, EmailInput, NumberInput, 
    DatePicker, StaticSelect, Option, Checkboxes
)

message = (
    Message.create()
    .add_header("Employee Registration Form")
    .add_section("Please complete the following information:")
    .add_input("Full Name", 
        PlainTextInput.create("full_name")
        .placeholder("Enter your full name")
        .max_length(100)
    )
    .add_input("Email Address", 
        EmailInput.create("email")
        .placeholder("user@company.com")
    )
    .add_input("Age", 
        NumberInput.create("age")
        .min_value(18)
        .max_value(65)
        .is_decimal_allowed(False)
    )
    .add_input("Start Date", 
        DatePicker.create("start_date")
        .placeholder("Select your start date")
    )
    .add_input("Department", 
        StaticSelect.create("department", "Choose Department", [
            Option.create("Engineering", "eng"),
            Option.create("Marketing", "marketing"),
            Option.create("Sales", "sales"),
            Option.create("HR", "hr")
        ])
        .placeholder("Select department")
    )
    .add_input("Notifications", 
        Checkboxes.create("notifications", [
            Option.create("Email Updates", "email"),
            Option.create("SMS Alerts", "sms"),
            Option.create("Push Notifications", "push")
        ])
    )
    .add_context(["All fields are required for processing"])
    .build()
)
```

### ✅ Approval Workflow
Complex approval system with confirmation dialogs and status tracking.

```python
from slack_blocksmith import (
    Message, Button, ConfirmationDialog, 
    StaticSelect, Option, Context
)

# Approval confirmation dialog
approve_confirm = (
    ConfirmationDialog.create(
        "Approve Purchase Request",
        "Are you sure you want to approve this purchase request for $2,499.00?",
        "Yes, Approve",
        "Cancel"
    )
    .style("primary")
)

# Rejection confirmation dialog
reject_confirm = (
    ConfirmationDialog.create(
        "Reject Purchase Request",
        "Please provide a reason for rejection:",
        "Reject",
        "Cancel"
    )
    .style("danger")
)

message = (
    Message.create()
    .add_header("Purchase Request Approval")
    .add_section(
        text="**Request Details:**\n"
             "• Item: MacBook Pro 16-inch\n"
             "• Amount: $2,499.00\n"
             "• Requested by: John Doe\n"
             "• Department: Engineering\n"
             "• Justification: Development workstation upgrade"
    )
    .add_section(
        text="**Budget Impact:**\n"
             "• Remaining Q4 budget: $15,000\n"
             "• This purchase: $2,499 (16.7% of remaining budget)"
    )
    .add_input("Priority Level", 
        StaticSelect.create("priority", "Set Priority", [
            Option.create("High - Approve Immediately", "high"),
            Option.create("Medium - Standard Review", "medium"),
            Option.create("Low - Budget Review Required", "low")
        ])
        .placeholder("Select priority level")
    )
    .add_actions([
        Button.create("✅ Approve", "btn_approve")
        .style("primary")
        .confirm(approve_confirm),
        Button.create("❌ Reject", "btn_reject")
        .style("danger")
        .confirm(reject_confirm),
        Button.create("📋 Request More Info", "btn_info")
        .style("secondary")
    ])
    .add_context([
        "Request ID: PR-2024-001",
        "Submitted: 2024-01-15",
        "Status: Pending Approval"
    ])
    .build()
)
```

### 🏠 Home Tab Dashboard
Comprehensive home tab with multiple sections and interactive elements.

```python
from slack_blocksmith import (
    HomeTab, Section, Actions, Button, 
    StaticSelect, Option, Context, Image
)

home_tab = (
    HomeTab.create()
    .add_header("Welcome to Project Management Dashboard")
    .add_section(
        text="**Today's Overview**\n"
             "• 5 tasks due today\n"
             "• 3 pending approvals\n"
             "• 2 team meetings scheduled"
    )
    .add_section(
        text="**Quick Actions**",
        accessory=StaticSelect.create("quick_action", "Choose Action", [
            Option.create("Create New Task", "create_task"),
            Option.create("Schedule Meeting", "schedule_meeting"),
            Option.create("Review Reports", "review_reports"),
            Option.create("Team Status", "team_status")
        ])
        .placeholder("Select action")
    )
    .add_section(
        text="**Recent Activity**\n"
             "• Task 'Update documentation' completed by Alice\n"
             "• Meeting 'Sprint Planning' scheduled for 2:00 PM\n"
             "• Report 'Q4 Metrics' generated"
    )
    .add_actions([
        Button.create("📊 View Reports", "btn_reports"),
        Button.create("👥 Team Status", "btn_team"),
        Button.create("📅 Calendar", "btn_calendar"),
        Button.create("⚙️ Settings", "btn_settings")
    ])
    .add_context([
        "Last updated: 2024-01-15 10:30 AM",
        "Next sync: 2024-01-15 11:00 AM"
    ])
    .build()
)
```

### 🎛️ Interactive Modal
Complex modal with multiple input types and validation.

```python
from slack_blocksmith import (
    Modal, PlainTextInput, EmailInput, NumberInput,
    DatePicker, TimePicker, StaticSelect, MultiStaticSelect,
    Checkboxes, RadioButtons, Option, OptionGroup
)

modal = (
    Modal.create("Event Registration")
    .add_header("Conference Registration Form")
    .add_section("Please provide your information to complete registration.")
    .add_input("Full Name", 
        PlainTextInput.create("full_name")
        .placeholder("Enter your full name")
        .max_length(100)
    )
    .add_input("Email", 
        EmailInput.create("email")
        .placeholder("your.email@company.com")
    )
    .add_input("Phone Number", 
        PlainTextInput.create("phone")
        .placeholder("+1 (555) 123-4567")
    )
    .add_input("Company", 
        PlainTextInput.create("company")
        .placeholder("Your company name")
    )
    .add_input("Job Title", 
        PlainTextInput.create("job_title")
        .placeholder("Your current job title")
    )
    .add_input("Registration Date", 
        DatePicker.create("reg_date")
        .placeholder("Select registration date")
        .initial_date("2024-03-15")
    )
    .add_input("Preferred Time", 
        TimePicker.create("pref_time")
        .placeholder("Select preferred time")
        .initial_time("09:00")
    )
    .add_input("Experience Level", 
        StaticSelect.create("experience", "Select Experience Level", [
            Option.create("Beginner (0-2 years)", "beginner"),
            Option.create("Intermediate (3-5 years)", "intermediate"),
            Option.create("Advanced (6+ years)", "advanced"),
            Option.create("Expert (10+ years)", "expert")
        ])
        .placeholder("Choose your experience level")
    )
    .add_input("Interested Topics", 
        MultiStaticSelect.create("topics", "Select Topics of Interest", [
            Option.create("Machine Learning", "ml"),
            Option.create("Web Development", "web"),
            Option.create("Data Science", "data"),
            Option.create("DevOps", "devops"),
            Option.create("Mobile Development", "mobile"),
            Option.create("Cloud Computing", "cloud")
        ])
        .placeholder("Select multiple topics")
        .max_selected_items(4)
    )
    .add_input("Dietary Restrictions", 
        Checkboxes.create("dietary", [
            Option.create("Vegetarian", "vegetarian"),
            Option.create("Vegan", "vegan"),
            Option.create("Gluten-Free", "gluten_free"),
            Option.create("Kosher", "kosher"),
            Option.create("Halal", "halal")
        ])
    )
    .add_input("T-Shirt Size", 
        RadioButtons.create("tshirt_size", [
            Option.create("Small", "S"),
            Option.create("Medium", "M"),
            Option.create("Large", "L"),
            Option.create("Extra Large", "XL"),
            Option.create("2X Large", "2XL")
        ])
    )
    .add_section("**Terms and Conditions**\n"
                 "By submitting this form, you agree to our terms of service and privacy policy.")
    .submit("Complete Registration")
    .close("Cancel")
    .callback_id("event_registration")
    .private_metadata("conference_2024")
    .build()
)
```

### 📊 Data Visualization Message
Message with rich formatting and data presentation.

```python
from slack_blocksmith import (
    Message, Section, Context, Image, 
    Button, StaticSelect, Option
)

message = (
    Message.create()
    .add_header("Q4 2023 Sales Report")
    .add_section(
        text="**Sales Performance Summary**\n"
             "• Total Revenue: $2,450,000 (+15% vs Q3)\n"
             "• New Customers: 342 (+23% vs Q3)\n"
             "• Customer Satisfaction: 4.8/5.0 (+0.3 vs Q3)\n"
             "• Team Performance: 98% of goals met"
    )
    .add_section(
        text="**Top Performing Products**\n"
             "1. 🚀 Product A: $850,000 (34.7%)\n"
             "2. 💼 Product B: $620,000 (25.3%)\n"
             "3. 🎯 Product C: $480,000 (19.6%)\n"
             "4. 📱 Product D: $500,000 (20.4%)"
    )
    .add_section(
        text="**Regional Breakdown**",
        accessory=StaticSelect.create("region", "View by Region", [
            Option.create("North America", "na"),
            Option.create("Europe", "eu"),
            Option.create("Asia Pacific", "apac"),
            Option.create("Latin America", "latam")
        ])
        .placeholder("Select region")
    )
    .add_image(
        "https://example.com/sales-chart.png",
        "Q4 2023 Sales Performance Chart"
    )
    .add_actions([
        Button.create("📈 Detailed Report", "btn_detailed_report"),
        Button.create("📊 Export Data", "btn_export"),
        Button.create("📅 Schedule Review", "btn_schedule")
    ])
    .add_context([
        "Report generated: 2024-01-15 09:00 AM",
        "Next report: 2024-02-15",
        "Data source: Salesforce CRM"
    ])
    .build()
)
```

## 🔄 Migration from Raw JSON

### Before: Complex JSON Construction
```python
# Error-prone, hard to maintain, no validation
message = {
    "blocks": [
        {
            "type": "section",
            "text": {
                "type": "mrkdwn",
                "text": "Hello *World*! 👋"
            },
            "accessory": {
                "type": "button",
                "text": {
                    "type": "plain_text",
                    "text": "Click Me"
                },
                "action_id": "btn_1",
                "style": "primary"
            }
        },
        {
            "type": "divider"
        },
        {
            "type": "context",
            "elements": [
                {
                    "type": "mrkdwn",
                    "text": "Built with slack-block-kit-builder"
                }
            ]
        }
    ]
}
```

### After: Clean Builder Pattern
```python
# Type-safe, maintainable, validated
from slack_blocksmith import Message, MrkdwnText, Button

message = (
    Message.create()
    .add_section(
        text=MrkdwnText.create("Hello *World*! 👋"),
        accessory=Button.create("Click Me", "btn_1").style("primary")
    )
    .add_divider()
    .add_context(["Built with slack-block-kit-builder"])
    .build()
)
```

### Migration Benefits

| Aspect | Raw JSON | slack-block-kit-builder |
|--------|----------|-------------------------|
| **Type Safety** | ❌ No validation | ✅ Full pydantic validation |
| **IDE Support** | ❌ No autocomplete | ✅ Full autocomplete & hints |
| **Error Prevention** | ❌ Runtime errors | ✅ Compile-time validation |
| **Maintainability** | ❌ Hard to modify | ✅ Easy to refactor |
| **Readability** | ❌ Nested dictionaries | ✅ Fluent method chaining |
| **Documentation** | ❌ No inline help | ✅ Rich docstrings |

## 🔧 Troubleshooting for AI Agents

### Common Validation Errors
```python
# Error: "action_id is required"
# Solution: Always provide action_id for interactive elements
Button.create("Text", "action_id")  # ✅ Correct
Button.create("Text")  # ❌ Missing action_id

# Error: "Invalid style value"
# Solution: Use only 'primary' or 'danger' for button styles
Button.create("Text", "btn").style("primary")  # ✅ Correct
Button.create("Text", "btn").style("invalid")  # ❌ Invalid style

# Error: "Text cannot exceed 2000 characters"
# Solution: Keep text under 2000 characters
PlainText.create("Short text")  # ✅ Correct
PlainText.create("Very long text...")  # ❌ Too long if > 2000 chars
```

### Method Chaining Patterns
```python
# ✅ Correct: Chain methods before calling build()
element = (
    Button.create("Text", "action_id")
    .style("primary")
    .confirm(dialog)
    .build()
)

# ❌ Wrong: Calling build() too early
element = Button.create("Text", "action_id").build()
element.style("primary")  # This won't work
```

### Import Resolution
```python
# ✅ Correct: Import from main package
from slack_blocksmith import Message, Button

# ✅ Correct: Import specific classes
from slack_blocksmith import Message
from slack_blocksmith import Button

# ❌ Wrong: Import from submodules (not recommended)
from slack_blocksmith.message import Message
```

### JSON Output Format
```python
# All .build() methods return standard Python dictionaries
message_dict = Message.create().add_section("Hello").build()
# Returns: {"blocks": [{"type": "section", "text": {"type": "mrkdwn", "text": "Hello"}}]}

# Use with Slack API
slack_client.chat_postMessage(
    channel="#general",
    blocks=message_dict["blocks"]
)
```

## 🛠️ Advanced Usage

### Custom Validation
```python
from slack_blocksmith import Message, PlainTextInput, validator
from pydantic import BaseModel

class CustomInput(PlainTextInput):
    @validator('value')
    def validate_email(cls, v):
        if '@' not in v:
            raise ValueError('Must be a valid email')
        return v

message = (
    Message.create()
    .add_input("Email", CustomInput.create("email"))
    .build()
)
```

### Dynamic Content Generation
```python
from slack_blocksmith import Message, Section, Button, Option, StaticSelect

def create_task_message(tasks):
    message = Message.create().add_header("Task Dashboard")
    
    for task in tasks:
        message.add_section(
            text=f"**{task['title']}**\n{task['description']}",
            accessory=StaticSelect.create(
                f"status_{task['id']}", 
                "Status", 
                [Option.create(status, status) for status in task['statuses']]
            )
        )
    
    return message.build()
```

### Error Handling
```python
from slack_blocksmith import Message, Button
from pydantic import ValidationError

try:
    message = (
        Message.create()
        .add_section("Hello World")
        .add_actions([
            Button.create("Click Me", "btn_1")
            .style("invalid_style")  # This will raise ValidationError
        ])
        .build()
    )
except ValidationError as e:
    print(f"Validation error: {e}")
```

## 🧪 Testing

### Unit Testing
```python
import pytest
from slack_blocksmith import Message, Button

def test_message_creation():
    message = (
        Message.create()
        .add_section("Test message")
        .add_actions([Button.create("Test", "btn_test")])
        .build()
    )
    
    assert len(message["blocks"]) == 2
    assert message["blocks"][0]["type"] == "section"
    assert message["blocks"][1]["type"] == "actions"

def test_button_validation():
    with pytest.raises(ValidationError):
        Button.create("", "btn_1")  # Empty text should fail
```

### Integration Testing
```python
def test_slack_api_integration():
    message = Message.create().add_section("Test").build()
    
    # Test with actual Slack API
    response = slack_client.chat_postMessage(
        channel="#test",
        blocks=message["blocks"]
    )
    
    assert response["ok"] is True
```

## 📊 Performance

### Benchmarks
- **Message Creation**: ~0.1ms per message
- **Validation**: ~0.05ms per block
- **Memory Usage**: ~2KB per message
- **Serialization**: ~0.02ms per message

### Optimization Tips
```python
# Reuse common elements
approve_button = Button.create("Approve", "btn_approve").style("primary")

# Use list comprehensions for dynamic content
options = [Option.create(f"Option {i}", f"opt_{i}") for i in range(10)]

# Cache frequently used messages
@lru_cache(maxsize=100)
def get_welcome_message(user_id):
    return Message.create().add_section(f"Welcome {user_id}").build()
```

## 🔧 Development

### Setup Development Environment
```bash
# Clone the repository
git clone https://github.com/your-org/slack-block-kit-builder.git
cd slack-block-kit-builder

# Install with development dependencies
uv pip install -e ".[dev]"

# Install pre-commit hooks
pre-commit install
```

### Code Quality Tools
```bash
# Run linting
ruff check .

# Run type checking
mypy slack_blocksmith/

# Run tests
pytest

# Run tests with coverage
pytest --cov=slack_blocksmith --cov-report=html

# Format code
ruff format .
```

### Project Structure
```
slack-block-kit-builder/
├── slack_blocksmith/          # Main package
│   ├── __init__.py                   # Package exports
│   ├── composition.py               # Text, Option, Dialog objects
│   ├── elements.py                  # Interactive elements
│   ├── blocks.py                    # Block containers
│   ├── message.py                   # Message builders
│   └── validators.py                # Custom validation
├── examples/                        # Usage examples
│   ├── basic_message.py
│   ├── interactive_message.py
│   └── modal_example.py
├── tests/                          # Test suite
│   ├── test_composition.py
│   ├── test_elements.py
│   ├── test_blocks.py
│   └── test_message.py
├── docs/                           # Documentation
├── README.md
└── pyproject.toml
```

## 🤝 Contributing

We welcome contributions! Here's how to get started:

### 1. Fork and Clone
```bash
git clone https://github.com/your-username/slack-block-kit-builder.git
cd slack-block-kit-builder
```

### 2. Create Feature Branch
```bash
git checkout -b feature/amazing-feature
```

### 3. Make Changes
- Follow the existing code style
- Add tests for new functionality
- Update documentation as needed

### 4. Run Quality Checks
```bash
ruff check .
mypy slack_blocksmith/
pytest
```

### 5. Submit Pull Request
- Provide a clear description of changes
- Include tests for new functionality
- Ensure all checks pass

### Contribution Guidelines
- **Code Style**: Follow PEP 8, use ruff for formatting
- **Type Hints**: All functions must have type hints
- **Tests**: Maintain 100% test coverage
- **Documentation**: Update docstrings and README
- **Commits**: Use conventional commit messages


## 🙏 Acknowledgments

- **Slack Team** for the amazing Block Kit framework
- **Pydantic Team** for the excellent validation library
- **Python Community** for the rich ecosystem of tools



---
