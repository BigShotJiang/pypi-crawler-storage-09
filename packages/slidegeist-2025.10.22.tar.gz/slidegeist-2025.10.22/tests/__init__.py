"""Tests for Slidegeist."""
