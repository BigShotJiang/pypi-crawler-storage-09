# DO NOT EDIT
# Generated from .copier-answers.yml

from slidgnal import main

main()
