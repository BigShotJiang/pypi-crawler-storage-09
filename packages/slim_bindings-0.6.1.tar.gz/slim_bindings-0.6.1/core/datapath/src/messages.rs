// Copyright AGNTCY Contributors (https://github.com/agntcy)
// SPDX-License-Identifier: Apache-2.0

pub mod encoder;
pub mod utils;

pub use encoder::Name;
