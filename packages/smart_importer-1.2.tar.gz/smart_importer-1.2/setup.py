#!/usr/bin/env python3
"""Setup script for smart_importer.

The configuration is in setup.cfg.
"""

from setuptools import setup

setup()
