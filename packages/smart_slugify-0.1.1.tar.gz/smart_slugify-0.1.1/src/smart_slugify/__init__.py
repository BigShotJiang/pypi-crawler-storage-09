# smart_slugify/__init__.py

from .slugify import slugify

__all__ = ["slugify"]