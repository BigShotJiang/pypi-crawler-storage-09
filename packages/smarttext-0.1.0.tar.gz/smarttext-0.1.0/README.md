﻿# SmartText ??

SmartText - Python üçün agilli m?tn analiz kitabxanasidir.

## ?? Qurasdirma
pip install smarttext

## ?? Istifad?
from smarttext import analyze

text = "Python is a powerful programming language. It is easy to learn!"
analyze(text)

