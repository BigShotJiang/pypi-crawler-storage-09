class InvalidInputException(Exception):
    pass


class AccessDeniedException(Exception):
    pass
