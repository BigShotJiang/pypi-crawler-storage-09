# This script makes it possible to invoke snakemake with 'python3 -m snakemake'
from snakemake.cli import main

main()
