#!/usr/bin/env python3

import sys
import time

print("Hello World!", file=sys.stderr)
time.sleep(1)
