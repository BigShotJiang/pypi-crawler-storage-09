import SnakeScan

and use module to scan port 

 --l  need internet connection
 --h help
 --t threading port search
 --d dos
 --s single port search
 --i information about host
 Port or Host:--h to watch help
 Added class Watcher:
     for SnakeScan import Watcher
     Watcher(host:str,port:int)
 SnakeScan now run for command and import SnakeScan not run him
 import SnakeScan
 SnakeScan.run()
 