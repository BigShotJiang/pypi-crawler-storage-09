#SnakeScan
    ![PyPI version](https://badge.fury.io/py/your_package_name.svg)
        ![License](https://img.shields.io/badge/License-MIT-blue.svg)
 Scanner to scan devices or watch if you server down or up in time work
 ```
import SnakeScan
SnakeScan.run()
```
##Attrinutes
- --l  need internet to view public ip you device
- --t threading port search
- --d dos
- --s single port search
- --i information about host
- --h in host /--h port in host
##Added class Watcher:
     ```
     for SnakeScan import Watcher
     Watcher(host:str,port:int)
     ``` 