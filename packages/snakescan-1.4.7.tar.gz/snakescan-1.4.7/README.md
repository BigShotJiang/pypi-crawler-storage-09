# SnakeScan
 Scanner to scan devices or watch if you server down or up in time work
 
 ![PyPI version](https://badge.fury.io/py/SnakeScan.svg)
 ![Requires-python](https://img.shields.io/badge/requires--python-3.6+-red)
 ![License](https://img.shields.io/badge/License-MIT-blue.svg)
 ```
import SnakeScan
SnakeScan.run()
```
## Help

- --l  need internet to view public ip you device
- --t threading port search
- --d dos
- --s single port search
- --i information about host
- --h in host /--h port in host

## Added class Watcher:
     ```
     for SnakeScan import Watcher
     Watcher(host:str,port:int)
     ``` 