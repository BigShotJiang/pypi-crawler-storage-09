class CacheAdapter:
    def set(self, key, value):
        pass
