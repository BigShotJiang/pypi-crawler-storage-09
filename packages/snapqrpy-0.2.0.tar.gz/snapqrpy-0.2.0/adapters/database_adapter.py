class DatabaseAdapter:
    def connect(self):
        pass
