class QueueAdapter:
    def push(self, item):
        pass
