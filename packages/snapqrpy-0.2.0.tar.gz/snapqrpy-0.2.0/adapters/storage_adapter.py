class StorageAdapter:
    def save(self, data):
        pass
