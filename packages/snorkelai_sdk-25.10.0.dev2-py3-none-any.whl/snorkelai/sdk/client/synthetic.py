"""Synthetic data related functions for generating synthetic data."""

from snorkelai.sdk.client_v3.synthetic import (  # noqa: F401
    augment_data,
    augment_dataset,
)
