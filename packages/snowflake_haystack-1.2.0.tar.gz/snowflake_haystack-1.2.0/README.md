# snowflake-haystack

[![PyPI - Version](https://img.shields.io/pypi/v/snowflake-haystack.svg)](https://pypi.org/project/snowflake-haystack)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/snowflake-haystack.svg)](https://pypi.org/project/snowflake-haystack)

- [Integration page](https://haystack.deepset.ai/integrations/snowflake)
- [Changelog](https://github.com/deepset-ai/haystack-core-integrations/blob/main/integrations/snowflake/CHANGELOG.md)

---

## Contributing

Refer to the general [Contribution Guidelines](https://github.com/deepset-ai/haystack-core-integrations/blob/main/CONTRIBUTING.md).