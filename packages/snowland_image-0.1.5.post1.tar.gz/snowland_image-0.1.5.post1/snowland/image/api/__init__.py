#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author  : 河北雪域网络科技有限公司 A.Star
# @contact: astar@snowland.ltd
# @site: 
# @file: __init__.py.py
# @time: 2018/7/26 10:32
# @Software: PyCharm


from snowland.image.api.digital_screening import *
# from pencildraw import pencil_drawing
# from pencildraw.pencils import pencil0, pencil1,pencil2, pencil3, pencil4


import warnings
warnings.warn('package will remove to style_migration in v1.0.0')