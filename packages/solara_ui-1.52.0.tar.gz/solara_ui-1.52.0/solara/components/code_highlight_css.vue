<template>
</template>

<style id="solara-code-highlight">

.solara-code-highlight__box {
  border: var(--jp-border-width, 1px) solid var(--jp-cell-editor-border-color, #e0e0e0);
  border-radius: 0;
  background: var(--jp-cell-editor-background, #f5f5f5);
  padding: 5px;
}

div.output_area .solara-code-highlight pre {
  padding: 0;
}

.solara-code-highlight .highlight .hll { background-color: var(--jp-cell-editor-active-background) }
.solara-code-highlight .highlight {
  color: var(--jp-mirror-editor-variable-color);
  background: var(--jp-cell-editor-background);
  -webkit-font-smoothing: initial;
}
.solara-code-highlight .highlight .c { color: var(--jp-mirror-editor-comment-color, #408080FF); font-style: italic } /* Comment */
.solara-code-highlight .highlight .err { color: var(--jp-mirror-editor-error-color, #FF0000FF) } /* Error */
.solara-code-highlight .highlight .k { color: var(--jp-mirror-editor-keyword-color, #008000FF); font-weight: bold } /* Keyword */
.solara-code-highlight .highlight .o { color: var(--jp-mirror-editor-operator-color, #AA22FFFF); font-weight: bold } /* Operator */
.solara-code-highlight .highlight .p { color: var(--jp-mirror-editor-punctuation-color, #0055AAFF) } /* Punctuation */
.solara-code-highlight .highlight .ch { color: var(--jp-mirror-editor-comment-color, #408080FF); font-style: italic } /* Comment.Hashbang */
.solara-code-highlight .highlight .cm { color: var(--jp-mirror-editor-comment-color, #408080FF); font-style: italic } /* Comment.Multiline */
.solara-code-highlight .highlight .cp { color: var(--jp-mirror-editor-comment-color, #408080FF); font-style: italic } /* Comment.Preproc */
.solara-code-highlight .highlight .cpf { color: var(--jp-mirror-editor-comment-color, #408080FF); font-style: italic } /* Comment.PreprocFile */
.solara-code-highlight .highlight .c1 { color: var(--jp-mirror-editor-comment-color, #408080FF); font-style: italic } /* Comment.Single */
.solara-code-highlight .highlight .cs { color: var(--jp-mirror-editor-comment-color, #408080FF); font-style: italic } /* Comment.Special */
.solara-code-highlight .highlight .kc { color: var(--jp-mirror-editor-keyword-color, #008000FF); font-weight: bold } /* Keyword.Constant */
.solara-code-highlight .highlight .kd { color: var(--jp-mirror-editor-keyword-color, #008000FF); font-weight: bold } /* Keyword.Declaration */
.solara-code-highlight .highlight .kn { color: var(--jp-mirror-editor-keyword-color, #008000FF); font-weight: bold } /* Keyword.Namespace */
.solara-code-highlight .highlight .kp { color: var(--jp-mirror-editor-keyword-color, #008000FF); font-weight: bold } /* Keyword.Pseudo */
.solara-code-highlight .highlight .kr { color: var(--jp-mirror-editor-keyword-color, #008000FF); font-weight: bold } /* Keyword.Reserved */
.solara-code-highlight .highlight .kt { color: var(--jp-mirror-editor-keyword-color, #008000FF); font-weight: bold } /* Keyword.Type */
.solara-code-highlight .highlight .m { color: var(--jp-mirror-editor-number-color, #008000FF) } /* Literal.Number */
.solara-code-highlight .highlight .s { color: var(--jp-mirror-editor-string-color, #008000FF) } /* Literal.String */
.solara-code-highlight .highlight .ow { color: var(--jp-mirror-editor-operator-color, #AA22FFFF); font-weight: bold } /* Operator.Word */
.solara-code-highlight .highlight .w { color: var(--jp-mirror-editor-variable-color) } /* Text.Whitespace */
.solara-code-highlight .highlight .mb { color: var(--jp-mirror-editor-number-color, #008000FF) } /* Literal.Number.Bin */
.solara-code-highlight .highlight .mf { color: var(--jp-mirror-editor-number-color, #008000FF) } /* Literal.Number.Float */
.solara-code-highlight .highlight .mh { color: var(--jp-mirror-editor-number-color, #008000FF) } /* Literal.Number.Hex */
.solara-code-highlight .highlight .mi { color: var(--jp-mirror-editor-number-color, #008000FF) } /* Literal.Number.Integer */
.solara-code-highlight .highlight .mo { color: var(--jp-mirror-editor-number-color, #008000FF) } /* Literal.Number.Oct */
.solara-code-highlight .highlight .sa { color: var(--jp-mirror-editor-string-color, #BA2121FF) } /* Literal.String.Affix */
.solara-code-highlight .highlight .sb { color: var(--jp-mirror-editor-string-color, #BA2121FF) } /* Literal.String.Backtick */
.solara-code-highlight .highlight .sc { color: var(--jp-mirror-editor-string-color, #BA2121FF) } /* Literal.String.Char */
.solara-code-highlight .highlight .dl { color: var(--jp-mirror-editor-string-color, #BA2121FF) } /* Literal.String.Delimiter */
.solara-code-highlight .highlight .sd { color: var(--jp-mirror-editor-string-color, #BA2121FF) } /* Literal.String.Doc */
.solara-code-highlight .highlight .s2 { color: var(--jp-mirror-editor-string-color, #BA2121FF) } /* Literal.String.Double */
.solara-code-highlight .highlight .se { color: var(--jp-mirror-editor-string-color, #BA2121FF) } /* Literal.String.Escape */
.solara-code-highlight .highlight .sh { color: var(--jp-mirror-editor-string-color, #BA2121FF) } /* Literal.String.Heredoc */
.solara-code-highlight .highlight .si { color: var(--jp-mirror-editor-string-color, #BA2121FF) } /* Literal.String.Interpol */
.solara-code-highlight .highlight .sx { color: var(--jp-mirror-editor-string-color, #BA2121FF) } /* Literal.String.Other */
.solara-code-highlight .highlight .sr { color: var(--jp-mirror-editor-string-color, #BA2121FF) } /* Literal.String.Regex */
.solara-code-highlight .highlight .s1 { color: var(--jp-mirror-editor-string-color, #BA2121FF) } /* Literal.String.Single */
.solara-code-highlight .highlight .ss { color: var(--jp-mirror-editor-string-color, #BA2121FF) } /* Literal.String.Symbol */
.solara-code-highlight .highlight .il { color: var(--jp-mirror-editor-number-color, #008000FF) } /* Literal.Number.Integer.Long */
</style>
