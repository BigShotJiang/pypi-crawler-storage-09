# Solara enterprise

Solara enterprise is a not Open Source, but the source code is visible, is free for non-commercial use and installable from pypi.

For commercial use, you require a license. Please see [pricing](/pricing) for more information.

Solara-enterprise will stay free for non-commercial use and features that are in solara will **not be moved to solara-enterprise**.
