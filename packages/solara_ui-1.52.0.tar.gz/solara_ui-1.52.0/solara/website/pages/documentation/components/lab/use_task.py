"""# use_task"""

import solara
import solara.autorouting
import solara.lab
from solara.website.components import NoPage
from solara.website.utils import apidoc

title = "use_task"
Page = NoPage
__doc__ += apidoc(solara.lab.use_task)  # type: ignore
