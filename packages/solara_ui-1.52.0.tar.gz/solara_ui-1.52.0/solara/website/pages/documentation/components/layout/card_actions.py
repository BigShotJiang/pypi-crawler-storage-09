"""
# CardActions

"""

import solara
import solara.lab
from solara.website.components import NoPage
from solara.website.utils import apidoc

title = "CardActions"

Page = NoPage


__doc__ += apidoc(solara.CardActions.f)  # type: ignore
