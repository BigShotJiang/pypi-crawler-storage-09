redirect = "/apps/tutorial-streamlit"

Page = True
