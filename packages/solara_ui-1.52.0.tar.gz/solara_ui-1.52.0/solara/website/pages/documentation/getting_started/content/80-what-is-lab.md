---
title: What is Solara.lab?
description: Solara lab is a subpackage in solara containing Components, hooks and parts of Solara that are slightly experimental.
---
# What is Solara lab?

Solara lab is a subpackage in solara containing Components, hooks and parts of Solara that are slightly experimental.
