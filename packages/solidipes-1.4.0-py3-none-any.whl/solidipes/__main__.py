from .scripts.main import main_PYTHON_ARGCOMPLETE_OK

if __name__ == "__main__":
    main_PYTHON_ARGCOMPLETE_OK()
