from setuptools import setup, find_packages

setup(
    name='somali_stopwords',
    version='0.1.0',
    packages=find_packages(),
    description='A library to handle Somali stopwords',
    author='R&D',
    author_email='abdoldevtra@gmail.com',
    install_requires=[],
)
