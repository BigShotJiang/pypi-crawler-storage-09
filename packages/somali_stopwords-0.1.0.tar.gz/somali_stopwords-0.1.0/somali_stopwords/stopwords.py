# stopwords.py

STOPWORDS = [
    'iyo', 'aan', 'la', 'ku', 'si', 'in', 'wax', 'taas', 'mid', 'ka', 'ma', 'waa', 'u', 
    'haday', 'ba', 'sida', 'laga', 'door', 'tahay', 'aan', 'marka', 'iyo', 'bal', 'haddii'
]


# iyo (and)
# ama (or)
# in (that)
# ka (from)
# waxaa (there is)
# la (with)
# aan (not)
# ku (at)
# aheyd
# ah