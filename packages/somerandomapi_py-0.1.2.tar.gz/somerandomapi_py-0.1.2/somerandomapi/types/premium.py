from typing import Literal

Endpoints = Literal[
    "amogus",
    "petpet",
    "rankcard",
    "welcome",
]
