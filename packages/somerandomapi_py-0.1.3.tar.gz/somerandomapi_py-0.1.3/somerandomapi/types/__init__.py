"""
somerandomapi.types
~~~~~~~~~~~~~~
"""
