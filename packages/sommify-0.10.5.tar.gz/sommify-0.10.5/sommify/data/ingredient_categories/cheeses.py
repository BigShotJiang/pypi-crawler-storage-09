CHEESE = [
    r"parmesan",
    r"cheddar",
    r"gouda",
    r"feta",
    r"blue cheese",
    r"goat cheese",
    r"ricotta",
    r"cream cheese",
    r"cottage cheese",
    r"gruyere",
    r"pecorino",
    r"mozzarella",
    r"pepper jack",
    r"monterey jack",
    r"mexican cheese",
]

CHEESE_NON_DESSERT = []
