class SlicerException(Exception):
    """Custom exception for slicing errors"""


class SlicerArgumentException(Exception):
    """Custom exception for argument parsing error"""

    pass
