"""
SonicWall API Python Client
"""

__version__ = "1.0.4"

from .sonicwall_api_client import SonicWallClient