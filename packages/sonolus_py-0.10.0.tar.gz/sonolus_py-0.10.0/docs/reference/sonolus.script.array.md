# sonolus.script.array
For usage details, see the corresponding [concepts page](../concepts/types.md#array).

::: sonolus.script.array
    options:
        inherited_members: true
