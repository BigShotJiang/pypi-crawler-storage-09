# Concepts
This section provides a reference for the concepts and features of Sonolus.py.

It is not intended to serve as a tutorial or introduction, and assumes familiarity with Python and Sonolus.py.

For information on how to get started with Sonolus.py, see the [home page](../index.md).
