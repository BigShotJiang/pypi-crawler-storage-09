# sopy_fem
A simple Python program for finite elements analysis of 2D solids and structures.


This program has been developed to be used as an academic tool in the Simulation and Optimization subject of the Master's degree in Interdisciplinary & Innovative Engineering of Polytechnic University of Catalonia (UPC).
