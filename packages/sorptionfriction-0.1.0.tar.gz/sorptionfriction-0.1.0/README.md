# sorptionfriction
This is for calculating the sorption-friction model
