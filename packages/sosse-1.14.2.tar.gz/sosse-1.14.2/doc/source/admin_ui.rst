Administration interface
========================

To reach administration user interface, you first need to authenticate, by clicking the |user_menu_button| button, then
selecting ``Log in``.

.. |user_menu_button| image:: ../../tests/robotframework/screenshots/user_menu_button.png
   :class: sosse-inline-screenshot

The default user name and password are both ``admin``. After submitting, the administration interface can be reached
from the |conf_menu_button| menu, by selecting ``Administration``.

.. |conf_menu_button| image:: ../../tests/robotframework/screenshots/conf_menu_button.png
   :class: sosse-inline-screenshot

.. image:: ../../tests/robotframework/screenshots/admin_ui.png
   :class: sosse-screenshot
