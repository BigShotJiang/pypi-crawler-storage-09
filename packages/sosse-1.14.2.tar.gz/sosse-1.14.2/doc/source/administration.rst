Administration
==============

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   admin_ui.rst
   crawl/new_url.rst
   crawl/queue.rst
   crawl/crawlers.rst
   crawl/analytics.rst
   crawl/collections.rst
   crawl/feeds.rst
   documents.rst
   tags.rst
   domains.rst
   cookies.rst
   webhooks.rst
   mime_plugins.rst
   excluded_urls.rst
   search_engines.rst
   permissions.rst
