📊 Analytics
============

.. image:: ../../../tests/robotframework/screenshots/analytics.png
   :class: sosse-screenshot

The analytics page shows global information about indexed pages, it can be reached by clicking ``📊 Analytics`` from
the |conf_menu_button| menu, or in the :doc:`../admin_ui`.

.. |conf_menu_button| image:: ../../../tests/robotframework/screenshots/conf_menu_button.png
   :class: sosse-inline-screenshot
