🕷 Crawlers
===========

The crawlers page displays real-time information on crawlers processes. It can be accessed from
the :doc:`../admin_ui`, by selecting ``🕷 Crawlers``.

.. image:: ../../../tests/robotframework/screenshots/crawlers.png
   :class: sosse-screenshot
