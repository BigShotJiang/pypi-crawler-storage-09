✔ Crawl queue
=============

The crawl queue page displays real-time information on documents being crawled. It can be accessed from
the |conf_menu_button| menu, or from the :doc:`../admin_ui`, by selecting ``✔ Crawl queue``.

.. |conf_menu_button| image:: ../../../tests/robotframework/screenshots/conf_menu_button.png
   :class: sosse-inline-screenshot

.. image:: ../../../tests/robotframework/screenshots/crawl_queue.png
   :class: sosse-screenshot
