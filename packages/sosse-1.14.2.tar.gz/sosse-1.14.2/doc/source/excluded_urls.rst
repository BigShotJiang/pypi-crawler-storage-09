🔗 Excluded URLs
================

The excluded URLs list can be reached from the :doc:`../admin_ui`, by clicking on ``Excluded URLs``.

.. image:: ../../tests/robotframework/screenshots/excluded_url.png
   :class: sosse-screenshot

This stores URLs that will always be skipped by the crawlers.
