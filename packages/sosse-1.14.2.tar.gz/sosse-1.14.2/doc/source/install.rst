Installation
============

Sosse can be installed in a few different ways 🦨:

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   install/debian.rst
   install/debian_upgrades.rst
   install/pip.rst
   install/pip_upgrades.rst
   install/docker.rst
   install/docker_upgrades.rst
   install/docker_compose.rst
   install/docker_compose_upgrades.rst
