Debian upgrades
===============

The Debian package installed following the :doc:`debian` documentation can be upgraded by running a regular:

.. code-block:: shell

   apt-get upgrade

It is recommended to make a backup of the database before upgrading.
