Docker upgrades
===============

The Docker version installed following the :doc:`docker` documentation can be upgraded by running:

.. code-block:: shell

   docker pull biolds/sosse:latest

It is recommended to make a backup of the database before upgrading.
