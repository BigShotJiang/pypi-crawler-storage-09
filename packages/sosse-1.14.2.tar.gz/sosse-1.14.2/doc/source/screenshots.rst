Screenshots
===========

.. figure:: ../../tests/robotframework/screenshots/search.png
   :class: sosse-screenshot

   :doc:`Search results <user/search>`

.. raw:: html

   <br/>
   <br/>

.. figure:: ../../tests/robotframework/screenshots/guide_download_archive_html.png
   :class: sosse-screenshot

   :doc:`Offline browsing <user/archive>`

.. raw:: html

   <br/>
   <br/>

.. figure:: ../../tests/robotframework/screenshots/archive_download.png
   :class: sosse-screenshot

   :doc:`File scraping <user/archive>`

.. raw:: html

   <br/>
   <br/>

.. figure:: ../../tests/robotframework/screenshots/analytics.png
   :class: sosse-screenshot

   :doc:`Index analytics <crawl/analytics>`

.. raw:: html

   <br/>
   <br/>

.. figure:: ../../tests/robotframework/screenshots/tags_filter.png
   :class: sosse-screenshot

   :doc:`Tagging <tags>`

.. raw:: html

   <br/>
   <br/>

.. figure:: ../../tests/robotframework/screenshots/crawl_queue.png
   :class: sosse-screenshot

   :doc:`Real-time crawling status <crawl/queue>`

.. raw:: html

   <br/>
   <br/>

.. figure:: ../../tests/robotframework/screenshots/collection_detail.png
   :class: sosse-screenshot

   :doc:`Collections setup <crawl/collections>`

.. raw:: html

   <br/>
   <br/>

.. figure:: ../../tests/robotframework/screenshots/browsable_home.png
   :class: sosse-screenshot

   :doc:`Archive browsing <guides/archive>`
