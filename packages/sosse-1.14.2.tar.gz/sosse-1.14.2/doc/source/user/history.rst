History
=======

The history page shows the search history of the logged in user.

.. image:: ../../../tests/robotframework/screenshots/history.png
   :class: sosse-screenshot

Clicking the |delete_button| button deletes the search entry.

.. |delete_button| image:: ../../../tests/robotframework/screenshots/history_delete.png
   :class: sosse-inline-screenshot

Clicking |delete_all_button| button deletes the whole search history of the user.

.. |delete_all_button| image:: ../../../tests/robotframework/screenshots/history_delete_all.png
   :class: sosse-inline-screenshot
