Rest API
========

.. image:: ../../../tests/robotframework/screenshots/swagger.png
   :class: sosse-screenshot

A rest API is available, it can be explored with a `Swagger <https://swagger.io/>`_ user interface. It's reachable from the :doc:`../admin_ui`, by selecting ``Rest API``.

.. image:: ../../../tests/robotframework/screenshots/admin_ui.png
   :class: sosse-screenshot
