Search Engine shortcut defaults
===============================

You can find below the list of :doc:`shortcuts` defined by default. You can add new ones by following the
:doc:`../search_engines` documentation.

.. include:: shortcut_list_generated.rst
