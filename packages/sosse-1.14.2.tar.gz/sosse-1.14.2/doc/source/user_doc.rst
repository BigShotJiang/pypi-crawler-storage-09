User documentation
==================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   user/search.rst
   user/shortcuts.rst
   user/shortcut_list.rst
   user/profile.rst
   user/history.rst
   user/archive.rst
   user/rest_api.rst
