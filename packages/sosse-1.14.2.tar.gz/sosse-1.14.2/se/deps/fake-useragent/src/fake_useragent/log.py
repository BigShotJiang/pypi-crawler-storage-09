"""Defines a common logger for the library."""

import logging

logger = logging.getLogger(__package__)
