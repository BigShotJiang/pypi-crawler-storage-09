### Setup

Install / run https://github.com/Visual-Regression-Tracker/Visual-Regression-Tracker

### Running

```
make vrt
```
