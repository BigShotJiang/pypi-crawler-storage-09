from .sound_rs import *

__doc__ = sound_rs.__doc__
if hasattr(sound_rs, "__all__"):
    __all__ = sound_rs.__all__