SPINAL_NAMESPACE = "spinal"
SPINAL_BILLING_SPAN_NAME = "spinal.billing_span"
