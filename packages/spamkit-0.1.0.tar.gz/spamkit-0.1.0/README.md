# SpamKit

هذه مكتبة أدوات لإرسال رسائل البريد الإلكتروني 

## Installation

```bash
pip install SpamKit
```

## Usage

```python
from SpamKit import spam_email_JACK
email = input("Enter Email : ")
result = spam_email_JACK(email)
print(result)
```

## Disclaimer


هذه المكتبة مُصممة لأغراض تعليمية



