# SpamKit

هذه مكتبة أدوات لإرسال رسائل البريد الإلكتروني 

## Installation

```bash
pip install SpamKit
```

## Usage

```python
from SpamKit import spam_email_JACK
ss = input("Enter Email : ")
spam_email_JACK(ss)
```

## Disclaimer


هذه المكتبة مُصممة لأغراض تعليمية



