from .spamkit import spam_email_JACK
