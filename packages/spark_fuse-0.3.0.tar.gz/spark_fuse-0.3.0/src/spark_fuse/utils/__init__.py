# Utility helpers
