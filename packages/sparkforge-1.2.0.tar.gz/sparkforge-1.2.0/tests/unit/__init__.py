"""
Unit tests for SparkForge components.
"""
