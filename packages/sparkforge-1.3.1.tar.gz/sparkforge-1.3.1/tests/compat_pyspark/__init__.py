"""
PySpark compatibility tests.

These tests verify that sparkforge works correctly with real PySpark.
They are marked with @pytest.mark.pyspark_compat and will be skipped
if PySpark is not installed.
"""

