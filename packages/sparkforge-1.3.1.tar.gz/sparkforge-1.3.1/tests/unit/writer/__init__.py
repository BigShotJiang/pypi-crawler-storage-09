"""Unit tests for the writer module."""
