See something that you would like to see supported? [Open an issue](https://github.com/flypipe/sparkleframe/issues/new)!

{%
    include-markdown "supported_api_doc.md"
%}
