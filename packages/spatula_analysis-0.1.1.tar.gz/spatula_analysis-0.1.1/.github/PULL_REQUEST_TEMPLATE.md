<!-- Provide a general summary of your changes in the Title above. -->

## Description
<!-- Describe your changes in detail. -->

## Motivation and Context
<!-- Why is this change required? What problem does it solve? -->
<!-- Replace ??? with the issue number that this pull request resolves, if applicable. -->
Resolves: #???

## How Has This Been Tested?
<!-- Please describe in detail how you tested your changes. -->
<!-- Include details of your testing environment, and the tests you ran to
     see how your changes affect other areas of the code, etc. -->

## Checklist:
- [ ] I have reviewed the [**Contributor Guidelines**](https://github.com/glotzerlab/spatula/blob/main/CONTRIBUTING.rst).
- [ ] I agree with the terms of the [**spatula Contributor Agreement**](https://github.com/glotzerlab/spatula/blob/main/ContributorAgreement.md).
- [ ] My name is on the [list of contributors](https://github.com/glotzerlab/spatula/blob/main/AUTHORS.rst) in the pull request source branch.
- [ ] I have updated the [Change log](https://github.com/glotzerlab/spatula/blob/main/changelog.rst).
