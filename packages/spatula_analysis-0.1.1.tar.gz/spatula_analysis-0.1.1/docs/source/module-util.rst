spatula.util
------------

.. rubric:: Overview

.. py:currentmodule:: spatula.util

.. autosummary::
    get_num_threads
    set_num_threads
    sph_to_cart

.. rubric:: Details

.. automodule:: spatula.util
   :members:
    get_num_threads,
    set_num_threads,
    sph_to_cart
