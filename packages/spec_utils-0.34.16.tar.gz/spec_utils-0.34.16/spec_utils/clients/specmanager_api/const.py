__specmanager__ = "5.0.0r17013"


class EmployeeType:
    OWN: str = "own"
    ENCAE: str = "encae"
    CONTRACTOR: str = "contractor"
