from typing import Union
import datetime as dt


TimeStampType = Union[str, dt.date, dt.datetime]
