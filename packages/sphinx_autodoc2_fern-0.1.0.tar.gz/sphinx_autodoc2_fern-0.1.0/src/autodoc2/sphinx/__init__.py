"""Module for Sphinx integration."""
