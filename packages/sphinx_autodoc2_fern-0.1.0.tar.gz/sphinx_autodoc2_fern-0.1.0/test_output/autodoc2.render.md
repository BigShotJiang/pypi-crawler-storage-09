`autodoc2.render`


