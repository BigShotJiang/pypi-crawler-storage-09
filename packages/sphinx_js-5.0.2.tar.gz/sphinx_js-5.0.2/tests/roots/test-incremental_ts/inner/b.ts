export class ClassB {
  constructor() {}

  /**
   * Here.
   */
  methodB() {}
}
