export const config = {
  shouldDestructureArg: (param) => param.name === "destructureThisPlease",
};
