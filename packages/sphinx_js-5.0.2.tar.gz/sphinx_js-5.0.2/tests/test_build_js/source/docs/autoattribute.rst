.. js:autoattribute:: ContainingClass#someVar
