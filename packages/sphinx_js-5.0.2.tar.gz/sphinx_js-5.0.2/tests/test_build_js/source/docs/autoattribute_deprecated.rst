.. js:autoattribute:: DeprecatedAttribute

.. js:autoattribute:: DeprecatedExplanatoryAttribute
