.. js:autoclass:: ContainingClass
