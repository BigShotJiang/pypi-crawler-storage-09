.. js:autoclass:: DeprecatedClass

.. js:autoclass:: DeprecatedExplanatoryClass
