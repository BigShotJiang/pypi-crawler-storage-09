.. js:autoclass:: ExampleClass
