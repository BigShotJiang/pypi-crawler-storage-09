.. js:autoclass:: ContainingClass
   :members:
