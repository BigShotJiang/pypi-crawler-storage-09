.. js:autoclass:: ClosedClass
   :members: publical3, publical
