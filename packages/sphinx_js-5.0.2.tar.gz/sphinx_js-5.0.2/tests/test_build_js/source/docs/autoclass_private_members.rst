.. js:autoclass:: ContainingClass
   :members:
   :private-members:
