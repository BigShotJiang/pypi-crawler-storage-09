.. js:autofunction:: defaultsDocumentedInDoclet
