.. js:autofunction:: deprecatedFunction

.. js:autofunction:: deprecatedExplanatoryFunction
