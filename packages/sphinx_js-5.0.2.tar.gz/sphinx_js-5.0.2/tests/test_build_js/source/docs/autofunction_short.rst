.. js:autofunction:: ContainingClass#someMethod
   :short-name:
