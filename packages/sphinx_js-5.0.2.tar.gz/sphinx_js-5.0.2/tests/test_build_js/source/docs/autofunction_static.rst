.. js:autoclass:: SimpleClass
    :members:
