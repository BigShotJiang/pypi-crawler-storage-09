.. js:autofunction:: TypeDefinition
