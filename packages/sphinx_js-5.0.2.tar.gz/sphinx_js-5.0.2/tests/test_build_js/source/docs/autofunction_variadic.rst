.. js:autofunction:: variadicParameter
