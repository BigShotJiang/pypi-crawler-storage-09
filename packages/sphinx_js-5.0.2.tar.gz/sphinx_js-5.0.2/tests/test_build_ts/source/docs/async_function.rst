.. js:autofunction:: asyncFunction
