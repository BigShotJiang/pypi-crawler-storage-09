.. js:autoclass:: ClassWithSupersAndInterfacesAndAbstract
