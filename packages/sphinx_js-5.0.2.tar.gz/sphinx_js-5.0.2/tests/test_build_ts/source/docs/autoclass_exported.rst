.. js:autoclass:: ExportedClass
