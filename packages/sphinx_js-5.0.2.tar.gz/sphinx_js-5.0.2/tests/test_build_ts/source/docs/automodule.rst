.. js:automodule:: module
