.. js:autoclass:: GetSetDocs
   :members:
