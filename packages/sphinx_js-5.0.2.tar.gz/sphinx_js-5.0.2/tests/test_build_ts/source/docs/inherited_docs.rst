.. js:autoclass:: Base
   :members:

.. js:autoclass:: Extension
   :members:
