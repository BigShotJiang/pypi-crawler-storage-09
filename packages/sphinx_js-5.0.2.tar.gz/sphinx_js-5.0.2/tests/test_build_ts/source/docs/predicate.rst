.. js:autofunction:: predicate
