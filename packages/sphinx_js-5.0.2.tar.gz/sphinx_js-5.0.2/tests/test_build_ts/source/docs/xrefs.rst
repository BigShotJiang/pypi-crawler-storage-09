.. js:autofunction:: blah

   blah

.. js:autofunction:: thunk

   Xrefs in the function type of the argument
