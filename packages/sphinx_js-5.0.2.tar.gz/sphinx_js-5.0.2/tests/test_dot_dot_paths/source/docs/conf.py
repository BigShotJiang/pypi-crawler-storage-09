extensions = ["sphinx_js"]

# Minimal stuff needed for Sphinx to work:
source_suffix = ".rst"
master_doc = "index"
author = "Erik Rose"
exclude_patterns = ["_build", "Thumbs.db", ".DS_Store"]
root_for_relative_js_paths = "./"
