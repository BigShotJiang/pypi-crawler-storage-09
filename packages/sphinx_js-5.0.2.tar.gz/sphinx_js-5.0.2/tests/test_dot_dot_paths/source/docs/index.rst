.. js:autofunction:: bar
