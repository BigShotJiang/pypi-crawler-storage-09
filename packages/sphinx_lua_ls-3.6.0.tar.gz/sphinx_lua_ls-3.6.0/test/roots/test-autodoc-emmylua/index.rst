Test autodoc
============

.. toctree::

   src/annotations.rst
   src/autoindex.rst
   src/globals.rst
   src/global_tables.rst
   src/incongruent_export.rst
   src/member_ordering.rst
   src/module_title.rst
   src/nested_modules.rst
   src/nesting_recursive.rst
   src/nesting.rst
   src/object_types.rst
   src/relative_resolve.rst
   src/require.rst
   src/signatures.rst
   src/using.rst
