--- @meta

--- Description
local doctype = {}

--- Description
--- @doctype const
doctype.x = 10

--- Description
function doctype.foo(x, y, z) end

return doctype
