--- @meta

--- Description
local global_tables = {}

--- Description
function global_tables.foo() end

--- Description
GLOBAL_TABLE = {
    --- Description
    --- @type integer
    foo = 1
}

return global_tables
