--- @meta

--- Description
local globals_2 = {}

--- Description
function globals_2.foo() end

--- Description
--- @type integer
GLOBAL_BAR = 1

return globals_2
