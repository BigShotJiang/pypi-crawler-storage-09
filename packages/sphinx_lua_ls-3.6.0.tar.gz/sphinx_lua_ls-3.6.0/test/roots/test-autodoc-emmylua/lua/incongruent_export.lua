--- Description
---
--- @class incongruent_export_2
local incongruent_export = {}

--- Description
function incongruent_export.foo() end

return incongruent_export
