--- @using using_2

--- Reference to :lua:obj:`Bar`
---
--- @class using.Foo

--- Description
---
--- @class using_2.Bar

return {}
