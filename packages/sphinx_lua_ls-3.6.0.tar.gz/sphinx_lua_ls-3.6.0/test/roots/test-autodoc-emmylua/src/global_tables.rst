Global tables
=============

.. container:: regression

   .. lua:autoobject:: global_tables
      :members:
      :recursive:
      :globals:
