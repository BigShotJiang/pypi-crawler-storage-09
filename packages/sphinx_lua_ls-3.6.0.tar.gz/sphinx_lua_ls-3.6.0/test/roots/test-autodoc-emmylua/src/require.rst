Using
=====

.. container:: regression

   .. lua:autoobject:: foo.x
      :members:
      :recursive:
      :annotate-require: always
