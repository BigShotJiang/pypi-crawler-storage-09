Test autodoc
============

.. container:: regression

   .. lua:autoobject:: autodoc
