--- @namespace autodoc

--- Description
local autodoc = {}

--- Description.
--- @class meep
autodoc.meep = {}

--- Description.
function autodoc.meep.meow() end

return autodoc
