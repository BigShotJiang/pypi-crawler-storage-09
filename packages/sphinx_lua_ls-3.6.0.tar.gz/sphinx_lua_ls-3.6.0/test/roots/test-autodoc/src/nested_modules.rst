Nested modules
==============

.. container:: regression

   .. lua:autoobject:: nested_modules
      :members:
      :recursive:
