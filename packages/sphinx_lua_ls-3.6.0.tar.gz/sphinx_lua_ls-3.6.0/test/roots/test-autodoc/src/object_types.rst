Object types
============

.. container:: regression

   .. lua:autoobject:: object_types
      :members:
      :recursive:
