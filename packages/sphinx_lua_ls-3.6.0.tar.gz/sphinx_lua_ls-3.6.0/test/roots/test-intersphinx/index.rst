Test intersphinx
================

.. container:: regression

   Link to :lua:obj:`debug` module.
