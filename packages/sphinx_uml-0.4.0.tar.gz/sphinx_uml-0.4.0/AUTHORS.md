## Development Lead

* [Marc-Olivier Buob](https://www.bell-labs.com/about/researcher-profiles/marc-olivier-buob/) <[marc-olivier.buob@nokia-bell-labs.com](mailto:marc-olivier.buob@nokia-bell-labs.com)>

## Acknowledgements

Many thanks to the authors of the following packages:

* [`sphinx_pyreverse`](https://github.com/sphinx-pyreverse/sphinx-pyreverse/)
* [`sphinx.ext.graphviz`](https://www.sphinx-doc.org/en/master/usage/extensions/graphviz.html)
* [`pylint`](https://github.com/pylint-dev/pylint)
* [`docutils`](https://github.com/pylint-dev/pylint)
