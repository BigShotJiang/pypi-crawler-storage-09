"""Spinal Tap module, the SPINE event display."""
