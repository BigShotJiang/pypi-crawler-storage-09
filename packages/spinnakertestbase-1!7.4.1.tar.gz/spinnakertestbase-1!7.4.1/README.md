[![Python Actions](https://github.com/SpiNNakerManchester/TestBase/actions/workflows/python_actions.yml/badge.svg?branch=main)](https://github.com/SpiNNakerManchester/TestBase/actions/workflows/python_actions.yml) [![Coverage Status](https://coveralls.io/repos/github/SpiNNakerManchester/TestBase/badge.svg)](https://coveralls.io/github/SpiNNakerManchester/TestBase)

This Repository hold classes and script used for unit and integration tests

There is need to use this repository unless you want to run some or all tests locally

Documentation
-------------
[TestBase documentation](https://spinnakertestbase.readthedocs.io/en/7.4.1)

[Combined python documentation (Excluding TestBase)](http://spinnakermanchester.readthedocs.io/en/7.4.1)

