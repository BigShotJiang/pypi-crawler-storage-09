# License Agreement

Up to date information for the whole [SpiNNakerManchester Projects](https://github.com/SpiNNakerManchester) can be found [here](https://spinnakermanchester.github.io/latest/LicenseAgreement.html)

As shown there the software is currently being released under the Apache License 2.0 listed [here](https://www.apache.org/licenses/LICENSE-2.0)


# Paper Authorship

See: [here](https://spinnakermanchester.github.io/latest/LicenseAgreement.html#paper-authorship)

# Modifications

See: [here](https://spinnakermanchester.github.io/latest/LicenseAgreement.html#modifications)

# Contributors

For up to date information on Contributors see the graphs/contributors pages on each project.

For example [https://github.com/SpiNNakerManchester/SpiNNMan/graphs/contributors](https://github.com/SpiNNakerManchester/SpiNNMan/graphs/contributors)

[Combined list](https://spinnakermanchester.github.io/latest/LicenseAgreement.html#contributors)

