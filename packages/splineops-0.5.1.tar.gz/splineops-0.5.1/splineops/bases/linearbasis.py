# splineops/src/splineops/bases/linearbasis.py

from splineops.bases.bspline1basis import BSpline1Basis

LinearBasis = BSpline1Basis
