# splineops/src/splineops/bases/nearestneighborbasis.py

from splineops.bases.bspline0basis import BSpline0Basis, BSpline0SymBasis

NearestNeighborBasis = BSpline0Basis
NearestNeighborSymBasis = BSpline0SymBasis
