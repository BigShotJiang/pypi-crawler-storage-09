# splineops/src/splineops/bases/omoms0basis.py

from splineops.bases.bspline0basis import BSpline0Basis, BSpline0SymBasis

OMOMS0Basis = BSpline0Basis
OMOMS0SymBasis = BSpline0SymBasis
