# splineops/src/splineops/bases/omoms1basis.py

from splineops.bases.bspline1basis import BSpline1Basis

OMOMS1Basis = BSpline1Basis
