"""
Utilities package for splurge-sql-runner.

Contains shared utility functions and helpers that can be used
by both the main application and test suites.
"""
