"""The laliga data sportsball module."""

from .combined.laliga_combined_league_model import \
    LaLigaCombinedLeagueModel as LaLigaLeagueModel

__all__ = ("LaLigaLeagueModel",)
