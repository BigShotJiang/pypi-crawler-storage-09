from spraycharles.commands import parse, gen, analyze, spray, modules

all = [
    parse,
    gen,
    analyze,
    spray,
    modules
]