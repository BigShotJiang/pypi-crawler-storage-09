from .dependency_marker import DependencyMarker, Depends
from .scope import Scope

__all__ = ["DependencyMarker", "Depends", "Scope"]
