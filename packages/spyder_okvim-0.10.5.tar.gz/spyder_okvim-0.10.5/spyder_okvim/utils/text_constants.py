"""Constants used for text processing."""

BRACKET_PAIR = {"(": ")", ")": "(", "[": "]", "]": "[", "{": "}", "}": "{"}
