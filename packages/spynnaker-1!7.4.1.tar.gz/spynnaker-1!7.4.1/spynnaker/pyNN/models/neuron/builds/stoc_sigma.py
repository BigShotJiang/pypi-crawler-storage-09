# Copyright (c) 2024 The University of Manchester
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from typing import Optional

from spynnaker.pyNN.models.neuron import AbstractPyNNNeuronModel
from spynnaker.pyNN.models.defaults import default_parameters
from spynnaker.pyNN.models.neuron.implementations import (
    ModelParameter, NeuronImplStocSigma)


class StocSigma(AbstractPyNNNeuronModel):
    """ Stochastic model with sigma threshold and instantaneous synapses.
    """

    @default_parameters({"tau_refrac", "alpha", "bias"})
    def __init__(self, tau_refrac: ModelParameter = 1,
                 alpha: ModelParameter = 1.0, bias: ModelParameter = 0,
                 refract_init: ModelParameter = 0,
                 seed: Optional[int] = None):
        """
        :param tau_refrac:
        :param alpha:
        :param bias:
        :param refract_init:
        :param seed: Seed for the random distribution
        """
        super().__init__(NeuronImplStocSigma(tau_refrac, alpha, bias,
                                             refract_init, seed))
