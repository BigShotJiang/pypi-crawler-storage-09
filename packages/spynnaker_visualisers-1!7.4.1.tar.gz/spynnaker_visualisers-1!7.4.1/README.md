[![Check Status](https://github.com/SpiNNakerManchester/sPyNNakerVisualisers/workflows/Check/badge.svg?branch=master)](https://github.com/SpiNNakerManchester/sPyNNakerVisualisers/actions?query=workflow%3A%22Check%22+branch%3Amaster)

Visualisers for Particular sPyNNaker Networks and Other SpiNNaker Applications
==============================================================================

1. Sudoku solver
2. Raytracer viewer
