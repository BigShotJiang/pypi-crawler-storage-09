# dbt plugin for SQLFluff

This plugin works with [SQLFluff](https://pypi.org/project/sqlfluff/), the
SQL linter for humans, to correctly parse and compile SQL projects using
[dbt](https://pypi.org/project/dbt/).

For more details on how to use this plugin,
[see the documentation](https://docs.sqlfluff.com/en/stable/perma/dbt.html).
