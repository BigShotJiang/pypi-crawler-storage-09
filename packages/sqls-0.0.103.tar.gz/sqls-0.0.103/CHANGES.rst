.. _changes:

Changes
=======

0.0.103 - 2025-10-16
--------------------
- Support Python 3.14
- Support more on delete actions
- Support json extraction operators


0.0.102 - 2024-11-18
--------------------
- Support Python 3.13
- Update tooling


0.0.101 - 2024-06-20
--------------------
- Support Python >= 3.12.4


0.0.100 - 2023-07-05
--------------------
- Initial release
