sqls.queries
============

.. automodule:: sqls.queries
   :members:
   :inherited-members:
   :show-inheritance:
