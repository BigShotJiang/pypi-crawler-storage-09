"""Stochastic Quasi-Newton Methods"""
