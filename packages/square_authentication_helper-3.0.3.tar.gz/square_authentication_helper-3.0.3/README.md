# square_authentication_helper

> 📌 versioning: see [CHANGELOG.md](./CHANGELOG.md).

## about

helper to access the authentication layer for my personal server.

## installation

```shell
pip install square_authentication_helper
```

## usage

[reference python file](./example.py)

## env

- python>=3.12.0

> feedback is appreciated. thank you!
