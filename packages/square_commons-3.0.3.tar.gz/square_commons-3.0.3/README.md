# square_commons

> 📌 versioning: see [CHANGELOG.md](./CHANGELOG.md).

## about

helper module containing common functions for all my python modules.

## installation

```shell
pip install square_commons
```

## usage

[reference](./usage)

## env

- python>=3.12.0

> feedback is appreciated. thank you!