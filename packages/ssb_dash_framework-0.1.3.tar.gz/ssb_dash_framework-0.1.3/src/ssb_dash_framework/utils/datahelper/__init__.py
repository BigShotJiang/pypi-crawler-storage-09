"""Helper functionality to simplify creation of data for use in editing."""

from .eimerdb_helper import DatabaseBuilderAltinnEimerdb

__all__ = ["DatabaseBuilderAltinnEimerdb"]
