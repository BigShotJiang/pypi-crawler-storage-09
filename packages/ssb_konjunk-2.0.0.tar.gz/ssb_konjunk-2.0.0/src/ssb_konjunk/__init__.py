"""SSB Konjunk."""
