# ssie
## Simple SpreadSheet Importer Exporter
A simple library to handle importing or exporting .csv .xls .xlsx with the same interface.
