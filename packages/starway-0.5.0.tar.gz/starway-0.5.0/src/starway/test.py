def hello():
    pass
