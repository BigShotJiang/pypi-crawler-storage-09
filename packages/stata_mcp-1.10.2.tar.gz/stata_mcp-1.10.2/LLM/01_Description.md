# Stata-MCP LLM file 01 Description

> This file contains the description of the Stata-MCP, for the LLM 更快了解这个项目的结构以帮助用户进行编码和了解使用。
