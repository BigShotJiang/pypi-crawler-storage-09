from statefun_tasks.builtin import builtin


@builtin('__builtins.run_pipeline')
def run_pipeline():
    pass


@builtin('__builtins.flatten_results')
def flatten_results():
    pass
