# stepup.reprep.bibsane

::: stepup.reprep.bibsane
      options:
        docstring_style: numpy
        show_root_heading: false
        members:
          - BibsaneConfig
