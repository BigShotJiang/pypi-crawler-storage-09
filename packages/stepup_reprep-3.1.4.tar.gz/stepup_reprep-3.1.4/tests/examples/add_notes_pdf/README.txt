It is sometimes convenient to insert pages for notes into an existing PDF.
This example shows how this can be done with `add_notes_pdf`.
