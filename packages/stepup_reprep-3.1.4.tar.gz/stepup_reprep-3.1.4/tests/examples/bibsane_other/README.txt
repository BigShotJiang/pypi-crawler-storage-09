This is standalone example of bibsane, where the cleaned bibtex file is written to a different file.
