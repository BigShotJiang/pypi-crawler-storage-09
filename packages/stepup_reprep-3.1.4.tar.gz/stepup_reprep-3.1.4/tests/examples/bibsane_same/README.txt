This is standalone example of bibsane, where the bibtex file is rewritten in place.
This will drain the scheduler, so follow-up steps are not executed.
