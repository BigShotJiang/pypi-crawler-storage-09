Concatenation of multiple PDFs is implemented in `cat_pdf`.
