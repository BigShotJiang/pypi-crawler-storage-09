RepRep can check hyper references in Markdown files with the `check_hrefs` function.
