A working local link: [README.txt](README.txt).
A broken local link: [BROKEN.md](BROKEN.md)
A working https link: [example.com](https://www.iana.org/help/example-domains).
A https link that is not allowed: [speedtest.net](https://www.speedtest.net/).
An allowed rewritten https link: [plan.py](https://users.ugent.be/~tovrstra/plan.py).
Repeating the last link: [plan.py](https://users.ugent.be/~tovrstra/plan.py).
A link to a directory that is already a supplier: [./](https://users.ugent.be/~tovrstra/).
