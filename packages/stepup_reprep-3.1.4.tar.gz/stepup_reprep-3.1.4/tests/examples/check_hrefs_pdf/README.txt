RepRep can check hyper references in PDF files with the `check_hrefs` function.
