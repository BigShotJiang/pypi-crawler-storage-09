A basic example of a LuaLaTeX compilation.
