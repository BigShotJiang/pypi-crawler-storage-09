A simple example of a PDFLaTeX document with references in a bbl file.
