A simple example of a PDFLaTeX document with dependencies on ohter steps.
