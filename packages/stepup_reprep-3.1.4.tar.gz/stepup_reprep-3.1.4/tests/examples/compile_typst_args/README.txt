This is an example of compiling a typst document with additional arguments.
