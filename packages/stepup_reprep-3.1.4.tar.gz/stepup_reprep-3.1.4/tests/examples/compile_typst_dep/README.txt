A simple example showing how to build a typst document with a dependency on a Python script.
For the test, the dependency file is kept, but in production settings,
the default is to write it to a temporary directory and delete it after processing.
