An example showing what happens when building a typst document with a syntax error.
