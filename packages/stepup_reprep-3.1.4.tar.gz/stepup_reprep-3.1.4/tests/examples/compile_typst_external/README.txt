This example compiles a typst document outside STEPUP_ROOT and uses dependencies.
