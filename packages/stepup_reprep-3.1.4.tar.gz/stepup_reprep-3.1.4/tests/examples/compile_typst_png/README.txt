This is an example of a single-page pngg created with typst.
