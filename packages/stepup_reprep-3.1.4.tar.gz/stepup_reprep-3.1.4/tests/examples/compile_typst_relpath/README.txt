This is an example of a typst compilation with dependencies in different directories.
