A simple example showing how to compile a typst document with RepRep.
