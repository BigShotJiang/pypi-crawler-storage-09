This is an example of a single-page svg created with typst.
