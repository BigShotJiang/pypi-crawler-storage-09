This is an example of a PDF built with typst, which includes an SVG file that itself references a PNG file.
The challenge is to get the right dependencies in the workflow.
(Typst seems to ignore the bitmap.)
