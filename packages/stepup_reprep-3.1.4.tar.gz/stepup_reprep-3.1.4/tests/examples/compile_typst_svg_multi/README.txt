This is an example of a multi-page svg created with typst.
At the time of writing, there is still a bug in the typst dep file that breaks multi-page png support in StepUp RepRep.
