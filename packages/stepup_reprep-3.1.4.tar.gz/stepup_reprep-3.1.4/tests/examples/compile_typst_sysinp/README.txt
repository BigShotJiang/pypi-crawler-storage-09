An example of a typst document with inputs.
