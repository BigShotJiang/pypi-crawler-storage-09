A simple example of a XeLaTeX document with dependencies on ohter steps.
