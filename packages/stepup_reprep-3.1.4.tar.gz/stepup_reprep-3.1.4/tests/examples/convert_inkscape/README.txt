Conversion from SVG to PDF with inkscape is convenient prior to including figures into the paper.
The API `convert_inkscape_pdf` implements this step.
