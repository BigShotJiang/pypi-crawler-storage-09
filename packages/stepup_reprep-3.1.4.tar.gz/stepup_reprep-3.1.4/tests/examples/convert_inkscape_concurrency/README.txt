This example demonstrates concurrent conversion of SVG to PDF,
using the workaround for the inkscape bug discussed here:
https://gitlab.com/inkscape/inkscape/-/issues/4716
