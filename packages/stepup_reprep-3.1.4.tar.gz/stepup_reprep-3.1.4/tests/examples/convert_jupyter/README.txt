A simple example of a Jupyter notebook conversion.
