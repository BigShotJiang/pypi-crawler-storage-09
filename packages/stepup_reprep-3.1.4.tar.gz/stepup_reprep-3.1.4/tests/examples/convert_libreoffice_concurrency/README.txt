A simple example of a conversion from ODT to PDF, with concurrency.

PDF files created with libreoffice are not reproducible yet. See:
See https://bugs.documentfoundation.org/show_bug.cgi?id=160033
