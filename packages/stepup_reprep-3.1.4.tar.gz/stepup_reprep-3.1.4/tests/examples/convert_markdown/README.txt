StepUp supports conversion from Markdown to HTML with KaTeX support.
This is simple example.
