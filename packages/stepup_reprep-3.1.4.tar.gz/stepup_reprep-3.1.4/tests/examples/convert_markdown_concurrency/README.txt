This example generates several random markdown files with LaTeX equations,
and converts them to HTML concurrently.
