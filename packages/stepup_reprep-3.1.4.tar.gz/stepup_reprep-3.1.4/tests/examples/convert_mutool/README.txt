Example of a conversion from PDF to PNG with mutool.
