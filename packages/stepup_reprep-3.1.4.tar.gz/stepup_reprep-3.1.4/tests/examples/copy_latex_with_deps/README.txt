An example of a plan copying (part of) LaTeX sources.
This tests the amend feature of scan_latex_deps to update the plan if the tex files have changed.
