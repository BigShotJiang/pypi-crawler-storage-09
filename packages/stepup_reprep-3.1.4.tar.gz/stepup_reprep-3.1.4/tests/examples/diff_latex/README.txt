Diffs between LaTeX source can be generated with latexdiff.
The API function `latex_diff` creates a step calling latexdiff.
