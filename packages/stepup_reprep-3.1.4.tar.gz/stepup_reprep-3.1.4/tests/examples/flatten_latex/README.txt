Structured LaTeX sources distributed over multiple tex files can be convenient,
but sometimes, they need to be converted to a single flat LaTeX file.
For example, some publishers require this and also some tools, like latex-diff, require it.

This example shows how to add a step to turn a structured LaTeX source into a flat one.
