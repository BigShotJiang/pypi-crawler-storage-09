Simple example showing how to make a inventory.txt file from scratch.
