This example shows how to put multiple pages per sheet, e.g. to create handouts.
