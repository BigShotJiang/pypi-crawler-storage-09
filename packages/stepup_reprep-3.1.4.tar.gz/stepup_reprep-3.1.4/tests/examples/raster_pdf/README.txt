Rastering PDFs is sometimes useful to discourage printing of copyrighted materials.
It is a bit silly but better than nothing.
