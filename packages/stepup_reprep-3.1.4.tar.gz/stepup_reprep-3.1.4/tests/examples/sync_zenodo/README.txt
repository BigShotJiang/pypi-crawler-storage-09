This test does not actually upload data to Zenodo, due to the missing token.
It just loads the config file and then exits, which validates the required fields.
