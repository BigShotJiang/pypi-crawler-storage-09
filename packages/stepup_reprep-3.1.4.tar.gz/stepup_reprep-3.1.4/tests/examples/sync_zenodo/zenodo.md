# Data descriptor

This Markdown file will be converted to **HTML**,
which is then used as description of the Zenodo record.
