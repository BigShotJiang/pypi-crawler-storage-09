This example shows how to make PDF figures with panels taken from other PDF files.
