This is a simple example of "unplot", using a plot taken from Wikipedia:
https://en.m.wikipedia.org/wiki/File:Negative_allosteric_modulator_plot.svg
