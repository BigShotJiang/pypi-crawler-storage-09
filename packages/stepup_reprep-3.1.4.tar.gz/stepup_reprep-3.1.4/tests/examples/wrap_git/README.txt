A simple example of running git log to write commit info to a file.
