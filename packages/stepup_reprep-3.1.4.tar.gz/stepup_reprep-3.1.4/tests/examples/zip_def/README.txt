This example shows how to zip a directory tree, selecting only output files in the tree.
