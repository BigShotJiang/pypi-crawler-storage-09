"""Strands Valkey Session Manager.

A high-performance session manager for Strands Agents that uses Valkey/Redis
for persistent storage.
"""