"""Strangeworks VQE SDK Extension."""
import importlib.metadata

__version__ = importlib.metadata.version("strangeworks-vqe")
