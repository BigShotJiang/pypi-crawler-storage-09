# 17.09.24

from .tmdb import tmdb
from .obj_tmbd import Json_film

__all__ = [
    "tmdb",
    "Json_film"
]