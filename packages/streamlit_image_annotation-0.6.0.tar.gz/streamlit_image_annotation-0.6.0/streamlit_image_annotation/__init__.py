IS_RELEASE = True

from .Classification import classification
from .Detection import detection
from .Point import pointdet