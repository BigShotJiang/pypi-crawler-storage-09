"""Constants module for streamlit-lightweight-charts-pro."""

# This module is reserved for future constants
__all__ = []
