/**
 * @fileoverview React App Environment Type Declarations
 *
 * TypeScript reference to react-scripts type definitions.
 * Auto-generated file that should not be modified manually.
 */

/// <reference types="react-scripts" />
