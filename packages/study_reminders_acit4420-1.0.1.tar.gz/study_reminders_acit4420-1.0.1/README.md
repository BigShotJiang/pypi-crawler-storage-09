# Acit4420 Assignment2

## Description & Usage

This package uses 5 of the provided modules, which have been slightly modified where deemed necessary.

The methods of most of the modules are accessible via main.py, the directions of how to do so is as follows.

After installation, the package can be started with 
```python
from study_reminders_ACIT4420 import main
```
This will present a menu, like so:
```
Enter the number of the option to continue
1. Start Daily Scheduler
2. Add Student
3. Remove Student
4. List Students
5. Simulate Schedule Sending
6. Quit
```

Simply enter the desired number, for example '1', then follow the instructions as provided.

Two things to note, once the daily scheduler is started, it can only be stopped by stopping the whole script.
Additionally, adding a student also adds a reminder. A reminder and a student is essentially one and the same within this script.

## Installation

As can be seen within [here](https://packaging.python.org/en/latest/discussions/setup-py-deprecated/), using setup.py is no longer considered best practice. 

Therefore, instead a package was uploaded to PyPi, using the tutorial provided [here](https://packaging.python.org/en/latest/tutorials/packaging-projects/
).
This does mean that installation is incredibly simple.

If using a Windows machine, the package can be installed via the command prompt with this command:
```
py -m pip install study-reminders-ACIT4420
```
Alternatively, if using a Unix or macOS, this command should work, though this has not been verified:
```
python -m pip install study-reminders-ACIT4420
```

Afterwards, simply follow the usage instructions as provided above.

If uninstallation is desired, there may be a command for that, yet the currently known way is to simply go to your version of:
```C:\Users\{YourUsernameHere}\AppData\Local\Programs\Python\Python313\Lib\site-packages``` or wherever your python installation may be.
Then delete the two study reminders folders.