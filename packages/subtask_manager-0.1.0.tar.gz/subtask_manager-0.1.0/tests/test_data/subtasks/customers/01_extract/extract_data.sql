select *
from public.customers;