insert into target_db.public.transactions
select * from transactions;