select *
from transactions;
