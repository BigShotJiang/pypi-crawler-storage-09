// src/core/boolean_algebra/ast/mod.rs
pub mod node;
pub use node::Node;
