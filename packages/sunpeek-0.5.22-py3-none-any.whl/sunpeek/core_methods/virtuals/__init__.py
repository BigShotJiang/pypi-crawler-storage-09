from sunpeek.core_methods.virtuals.main import config_virtuals, calculate_virtuals
from sunpeek.core_methods.common.main import CoreAlgorithm, CoreStrategy, AlgoResult
