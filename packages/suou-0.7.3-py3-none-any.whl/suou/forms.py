"""
Form validation, done right.

Why this? Why not, let's say, WTForms or Marshmallow? Well, I have my reasons.

TODO
"""

