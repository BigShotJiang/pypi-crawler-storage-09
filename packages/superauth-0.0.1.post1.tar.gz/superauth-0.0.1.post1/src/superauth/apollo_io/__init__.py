from superauth.apollo_io.apollo import Apollo

# import requests
# from superauth.config import config


# url = "https://api.apollo.io/api/v1/opportunities/search"

# headers = {
#     "accept": "application/json",
#     "Cache-Control": "no-cache",
#     "Content-Type": "application/json",
#     "x-api-key": config.apollo_api_key.get_secret_value()
# }

# response = requests.get(url, headers=headers)

# print(response.text)
