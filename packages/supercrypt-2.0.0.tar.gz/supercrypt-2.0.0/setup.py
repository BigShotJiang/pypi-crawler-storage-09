from setuptools import setup, find_packages

setup(
    name='supercrypt',
    version='2.0.0',
    author='ATHALLAH RAJENDRA PUTRA JUNIARTO',
    description='Ultra-secure custom mathematical encryption library with file encryption support',
    packages=find_packages(),
    python_requires='>=3.8',
)
