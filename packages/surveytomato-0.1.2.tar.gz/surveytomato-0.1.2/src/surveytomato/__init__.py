from .formHandler import form, Form

def main():
    print("🍅")