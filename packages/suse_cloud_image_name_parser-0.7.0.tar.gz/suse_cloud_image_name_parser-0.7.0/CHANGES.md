v0.7.0 (2025-10-16)
======

- Removes extra '|' in regex
- Update regex to handle 5.1 MLM image name
- Add MLM 5.2 to distro matrix for testing

v0.6.0 (2025-10-2)
======

- Adds the new segments for php, MariaDB and PostgreSQL images

v0.5.0 (2025-09-30)
======

- Adds the new tomcat segment for tomcat images

v0.3.0 (2025-08-26)
======

- For an openSUSE Leap fragment return False for both payg and byos options
- Use period for product version of SLES >= 16.0

v0.2.2 (2025-08-07)
======

- Fixes short_name for MLM 5.1

v0.2.1 (2025-06-26)
======

- Fixes distro_version for MLM 5.0 and 5.1

v0.2.0 (2025-05-16)
======

- Build for only one version of python

v0.1.0 (2025-04-08)
======

- Drop cloud specifics from parser.
- Only drop generation id if it exists.
- Fix generation id regex pattern

v0.0.3 (2025-04-02)
======

- Fix bug in import name

v0.0.2 (2025-04-02)
======

- Merge code and add packaging artifacts

v0.0.1 (2024-12-20)
======

- Initial release
