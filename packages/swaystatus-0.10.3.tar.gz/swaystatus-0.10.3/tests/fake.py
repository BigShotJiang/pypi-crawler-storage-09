from swaystatus import ClickEvent

click_event = ClickEvent(
    x=0,
    y=0,
    button=0,
    event=0,
    relative_x=0,
    relative_y=0,
    width=0,
    height=0,
    scale=0.0,
)
