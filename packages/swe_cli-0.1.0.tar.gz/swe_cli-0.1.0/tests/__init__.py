"""Tests for SWE-CLI."""
