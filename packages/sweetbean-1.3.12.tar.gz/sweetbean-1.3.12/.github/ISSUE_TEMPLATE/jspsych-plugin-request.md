---
name: jsPsych Plugin Request
about: Request the implementation of a jsPsych plugin
title: Feat - JsPsych <PLUGIN-NAME>
labels: enhancement, stimulus request
assignees: ''

---

# jsPsych plugin name

Please, enter the name of the plugin. This should be in the same format as it appears in the [jsPsych](https://github.com/jspsych/jsPsych) or [jsPsych](https://github.com/jspsych/jsPsych-contrib) repository.

# jsPsych link:

Please, add a link to the specific [jsPsych](https://github.com/jspsych/jsPsych/tree/main/packages) or [jsPsych-contrib](https://github.com/jspsych/jspsych-contrib/tree/main/packages) plugin
