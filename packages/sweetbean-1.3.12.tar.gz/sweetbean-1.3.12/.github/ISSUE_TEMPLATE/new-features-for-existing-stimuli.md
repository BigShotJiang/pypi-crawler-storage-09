---
name: New Features for existing Stimuli
about: Request the implementation of a feature to an existing stimulus
title: ''
labels: stimulus feature
assignees: ''

---

## Stimulus

Name the stimulus you requesting the feature for (for example, `Text`, `Image`, ...)

## Feature

Describe the feature you want to be implemented. Here, you might also want to refer to arguments of plugins in [jsPsych](https://www.jspsych.org/latest/plugins/list-of-plugins/) if applicable.
