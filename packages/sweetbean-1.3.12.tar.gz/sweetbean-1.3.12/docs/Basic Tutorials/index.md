# Basic Tutorials

From Zero to Hero in seven tutorials.

In seven lessons, you learn everything that you need to know to create a behavioral experiment with SweetBean. At the end you
will know how different variable types in SweetBean work and how to use them to create a task switching experiment with
Stroop stimuli.
