# Psychophysics

In this example, we use SweetBean to generate an experimental a Psychophysics experiment.