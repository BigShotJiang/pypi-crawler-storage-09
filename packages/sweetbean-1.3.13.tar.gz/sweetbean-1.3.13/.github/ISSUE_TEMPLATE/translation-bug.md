---
name: Translation Bug
about: Issues with the translation
title: ''
labels: bug, priority 1 - needed
assignees: ''

---

## SweetBean Code

```
Please paste in the SweetBean code that lead to the error
```

## JavaScript/HTML Code

```
Please paste in the translation with the error
```
