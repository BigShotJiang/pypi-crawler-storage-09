# Touchscreen

Instead of key presses in, with this extension, touch buttons can be used to get the response.

## Prerequisite

Make sure to include (or install) the extension from here:

https://github.com/jspsych/jspsych-contrib/tree/main/packages/extension-touchscreen-buttons

***Note:***
To use predefined buttons (left, right, ...) also make sure to include the css file in your html or js file.


