# TextSurvey

Present one or more free-text questions with text input fields. Participants type their answers; each response is recorded per question. Useful for short answers, open-ended prompts, and typed recall.

## When To Use

- Open-ended responses or brief written answers
- Typed recall, explanations, or comments
- Optional text capture after another stimulus