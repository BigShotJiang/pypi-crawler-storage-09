# Piloting Experiments with LLMs

Since SweetBean can be run both online and with language models, it can serve as a way to pilot experiments on synthetic participants. For example, this makes it possible to simulate reward sequences in bandit tasks and filter the ones that give a specified average reward.