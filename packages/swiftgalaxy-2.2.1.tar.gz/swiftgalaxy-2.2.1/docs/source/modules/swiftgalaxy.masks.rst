swiftgalaxy.masks module
========================

.. automodule:: swiftgalaxy.masks
   :members:
   :show-inheritance:
