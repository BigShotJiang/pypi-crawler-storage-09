swiftgalaxy.reader module
=========================

.. automodule:: swiftgalaxy.reader
   :members:
   :show-inheritance:
   :inherited-members:
   :private-members: _SWIFTGroupDatasetHelper, _SWIFTNamedColumnDatasetHelper, _CoordinateHelper
