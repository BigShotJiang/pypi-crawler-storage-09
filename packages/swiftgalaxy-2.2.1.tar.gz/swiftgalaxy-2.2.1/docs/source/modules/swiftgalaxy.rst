swiftgalaxy package
===================

.. automodule:: swiftgalaxy
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:

Submodules
----------

.. toctree::
   :maxdepth: 0

   swiftgalaxy.halo_catalogues
   swiftgalaxy.masks
   swiftgalaxy.reader
   swiftgalaxy.iterator
   swiftgalaxy.demo_data
