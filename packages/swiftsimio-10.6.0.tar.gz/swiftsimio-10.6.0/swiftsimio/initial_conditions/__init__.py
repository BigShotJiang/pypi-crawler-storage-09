"""
Initial conditions generation.
"""
