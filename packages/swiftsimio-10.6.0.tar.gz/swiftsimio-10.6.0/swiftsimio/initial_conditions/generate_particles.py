"""
Particle generation code.

TBD
"""
