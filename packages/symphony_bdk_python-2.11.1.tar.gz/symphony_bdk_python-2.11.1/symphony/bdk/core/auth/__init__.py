"""Package containing all modules related to authentication"""
