"""Package containing configuration-related modules"""
