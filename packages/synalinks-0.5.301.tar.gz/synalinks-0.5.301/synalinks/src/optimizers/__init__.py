from synalinks.src.optimizers.optimizer import Optimizer
