MAX_FILE_HANDLE_PER_COPY_REQUEST = (
    100  # The maximum number of FilesHandles that can be copied in a single request
)
