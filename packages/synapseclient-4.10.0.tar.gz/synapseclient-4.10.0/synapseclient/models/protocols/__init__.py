# These are all of the protocols that are used by the Synapse client.
