"""Script used to store an entity to Synapse."""

from typing import TYPE_CHECKING, Dict, Optional, Union

from opentelemetry import trace

from synapseclient import Synapse
from synapseclient.api import (
    create_access_requirements_if_none,
    post_entity,
    put_entity,
)
from synapseclient.core.utils import get_properties

if TYPE_CHECKING:
    from synapseclient.models import File, Folder, Link, Project


async def store_entity(
    resource: Union["File", "Folder", "Project", "Link"],
    entity: Dict[str, Union[str, bool, int, float]],
    *,
    synapse_client: Optional[Synapse] = None,
) -> bool:
    """
    Function to store an entity to synapse.

    TODO: This function is not complete and is a work in progress.


    Arguments:
        resource: The root dataclass instance we are storing data for.
        entity: The entity to store.
        synapse_client: If not passed in and caching was not disabled by
                `Synapse.allow_client_caching(False)` this will use the last created
                instance from the Synapse class constructor.

    Returns:
        If a read from Synapse is required to retireve the current state of the entity.
    """
    query_params = {}
    increment_version = False
    # Create or update Entity in Synapse
    if resource.id:
        trace.get_current_span().set_attributes({"synapse.id": resource.id})
        if hasattr(resource, "version_number"):
            if (
                resource.version_label
                and resource.version_label
                != resource._last_persistent_instance.version_label
            ):
                # a versionLabel implicitly implies incrementing
                increment_version = True
            elif resource.force_version and resource.version_number:
                increment_version = True
                entity["versionLabel"] = str(resource.version_number + 1)

            if increment_version:
                query_params["newVersion"] = "true"

        updated_entity = await put_entity(
            entity_id=resource.id,
            request=get_properties(entity),
            new_version=increment_version,
            synapse_client=synapse_client,
        )
    else:
        updated_entity = await post_entity(
            request=get_properties(entity),
            synapse_client=synapse_client,
        )

    if hasattr(resource, "is_restricted") and resource.is_restricted:
        await create_access_requirements_if_none(entity_id=updated_entity.get("id"))

    trace.get_current_span().set_attributes(
        {
            "synapse.id": updated_entity.get("id"),
            "synapse.concrete_type": updated_entity.get("concreteType", ""),
        }
    )
    return updated_entity
