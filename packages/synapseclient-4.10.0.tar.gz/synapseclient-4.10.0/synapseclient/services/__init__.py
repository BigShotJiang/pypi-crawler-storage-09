# These are exposed functions and objects from the `synapseclient.services` package.

from .json_schema import JsonSchemaService

__all__ = ["JsonSchemaService"]
