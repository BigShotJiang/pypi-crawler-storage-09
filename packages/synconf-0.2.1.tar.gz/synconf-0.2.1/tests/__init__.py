"""Tests package for SynConf."""

# Import data submodule to make it accessible via tests.data
from . import data
