from pathlib import Path

PROJECT_DIR = Path(__file__).parent.parent.parent.absolute()
DATA_FOLDER = PROJECT_DIR / "DATA"
