"""GRPO Synth Envs Hosted Service."""

from .hosted_app import TaskApp, create_app

__all__ = ["create_app", "TaskApp"]
