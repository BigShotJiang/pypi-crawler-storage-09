"""Storage module for Modal Volume operations."""

from .volume import VolumeStorage, storage

__all__ = ["VolumeStorage", "storage"]
