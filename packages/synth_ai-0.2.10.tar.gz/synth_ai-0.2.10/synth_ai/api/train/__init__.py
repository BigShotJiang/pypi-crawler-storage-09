from __future__ import annotations

from .cli import register, train_command

__all__ = ["register", "train_command"]
