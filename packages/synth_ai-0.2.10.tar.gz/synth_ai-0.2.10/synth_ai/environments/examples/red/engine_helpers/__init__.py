# Engine helpers for Pokemon Red
