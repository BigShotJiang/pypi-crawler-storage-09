"""Stateful environment components."""
