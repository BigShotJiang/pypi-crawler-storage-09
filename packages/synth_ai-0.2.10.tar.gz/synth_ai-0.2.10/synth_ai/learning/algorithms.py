# class LearningModality(str, enum.Enum):
#     """Modality of learning."""

#     online_on_policy = "online_on_policy"
#     online_off_policy = "online_off_policy"
#     offline = "offline"


# class LearningAlgorithm(str, enum.Enum):
#     """Algorithm of learning."""

#     gspo = "gspo"
#     reinforce = "reinforce"
#     sft = "sft"
