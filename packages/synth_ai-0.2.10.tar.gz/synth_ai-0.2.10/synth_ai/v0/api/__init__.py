from __future__ import annotations

# Legacy shim package to preserve old import paths like `synth_ai.v0.api.*`.
# New code should import from `synth_ai.api.*` directly.

__all__: list[str] = []


