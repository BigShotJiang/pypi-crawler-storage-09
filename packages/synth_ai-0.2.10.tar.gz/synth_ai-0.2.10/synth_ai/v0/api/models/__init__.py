from __future__ import annotations

try:
    from synth_ai.api.models.supported import *  # type: ignore  # re-export
except Exception:  # pragma: no cover
    pass


