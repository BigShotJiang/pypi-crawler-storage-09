from __future__ import annotations

# Backward-compat shim: old path `synth_ai.v0.api.models.supported`
# now maps to the canonical module `synth_ai.api.models.supported`.

from synth_ai.api.models.supported import *  # type: ignore[F401,F403]


