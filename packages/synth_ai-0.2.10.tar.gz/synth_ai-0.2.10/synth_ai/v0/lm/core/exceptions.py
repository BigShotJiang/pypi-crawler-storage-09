class StructuredOutputCoercionFailureException(Exception):
    pass


# ... rest of imports ...
