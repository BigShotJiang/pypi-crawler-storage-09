# Engine helpers for Sokoban
