======================
t-nextgen
======================

A Python library providing seamless methods to interact with NextGen application, enabling automation and integration for enhanced workflow efficiency


For detailed documentation, please visit our Notion page:
`t-nextgen Documentation <https://www.notion.so/thoughtfulautomation/T-NextGen-Library-Documentation-15ef43a78fa48014bae8c0a5185d5b7c>`_

