"""NextGen Document Manager package."""
