"""NextGen Practice Management Windows package."""
