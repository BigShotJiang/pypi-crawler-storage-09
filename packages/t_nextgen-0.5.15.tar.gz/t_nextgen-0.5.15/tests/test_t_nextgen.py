#!/usr/bin/env python
"""Tests for `t_nextgen` package."""


class TestTNextgen:
    """Smoke tests of the package."""

    def test_example(self) -> None:
        """Smoke test."""
        assert True
