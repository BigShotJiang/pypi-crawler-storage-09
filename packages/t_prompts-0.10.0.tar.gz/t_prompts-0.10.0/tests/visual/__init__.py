"""Visual tests for widget rendering using Playwright."""
