Miscellaneous scripts for manipulating table files (files that have a columnar
format and a header line with column names).

# Installation guide
```
pip install tabletools
```
