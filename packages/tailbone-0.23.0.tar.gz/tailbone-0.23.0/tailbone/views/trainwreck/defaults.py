# -*- coding: utf-8; -*-
################################################################################
#
#  Rattail -- Retail Software Framework
#  Copyright © 2010-2022 Lance Edgar
#
#  This file is part of Rattail.
#
#  Rattail is free software: you can redistribute it and/or modify it under the
#  terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  Rattail is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
#  FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
#  details.
#
#  You should have received a copy of the GNU General Public License along with
#  Rattail.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
Trainwreck "default" views (i.e. assuming "default" schema)
"""

from __future__ import unicode_literals, absolute_import

from rattail.trainwreck.db.model import defaults as trainwreck

from tailbone.views.trainwreck import base


class TransactionView(base.TransactionView):
    """
    Master view for Trainwreck transactions
    """
    model_class = trainwreck.Transaction
    model_row_class = trainwreck.TransactionItem


def defaults(config, **kwargs):
    base = globals()

    TransactionView = kwargs.get('TransactionView', base['TransactionView'])
    TransactionView.defaults(config)


def includeme(config):
    defaults(config)
