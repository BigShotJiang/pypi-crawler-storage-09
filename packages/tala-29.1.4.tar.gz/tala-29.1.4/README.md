This is a command line SDK for managing TDM-based dialogue domain descriptions (DDDs). For further information, see [talkamatic.se](http://talkamatic.se).

# Installation

Install the latest version of Tala with pip:

```bash
pip3 install tala
```
