class DomainError(Exception):
    pass


class OntologyError(Exception):
    pass
