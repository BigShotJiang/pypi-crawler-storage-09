"""Target for StarRocks."""
