# Proyecto FastAPI
Este es un proyecto FastAPI con Docker y PostgreSQL.

## Estructura del Proyecto
- app: Contiene la lógica de la aplicación.
- config: Configuraciones del proyecto.
- database: Configuraciones de la base de datos y migraciones.
