=======
History
=======

0.0.1 (2025-04-03)
------------------

* First release on PyPI.
