Command Line Interface
======================

.. click:: tcdo_pg_tools.cli:cli
   :prog: tcdo_pg_tools
   :nested: full


