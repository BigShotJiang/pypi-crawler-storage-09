"""Top-level package for tcdo-pg-tools."""

__author__ = """Asher Preska Steinberg"""
__email__ = 'preskaa@mskcc.org'
__version__ = '0.0.4'
