#!/usr/bin/env python

"""Tests for `tcdo_pg_tools` package."""


import unittest

from tcdo_pg_tools import tcdo_pg_tools


class TestTcdo_pg_tools(unittest.TestCase):
    """Tests for `tcdo_pg_tools` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
