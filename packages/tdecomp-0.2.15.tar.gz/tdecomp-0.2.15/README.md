# tensor-decompositions

Here some resume for sketches, projections and randomized algorithms:
https://docs.google.com/presentation/d/16Q8ZOH-01Z03sX1zv08AlPEzTnZ574DcktqmSQ4VfWA/edit?slide=id.g371a24abfab_0_11#slide=id.g371a24abfab_0_11
