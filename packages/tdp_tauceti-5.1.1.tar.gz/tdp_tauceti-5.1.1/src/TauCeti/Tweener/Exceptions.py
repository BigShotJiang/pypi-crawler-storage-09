





'''Info Header Start
Name : tweener_exceptions
Author : Wieland PlusPlusOne@AMB-ZEPH15
Saveorigin : TauCeti_PresetSystem.toe
Saveversion : 2023.12000
Info Header End'''
class TargetIsNotParameter(Exception):
	pass
	
class InvalidParMode(Exception):
	pass