from . import PresetManager
from . import Tweener


# Futureprrofing for automated search of toxfiles and imports.
_ToxFiles = {
    "PresetManager" : PresetManager.ToxFile,
    "Tweener" : Tweener.ToxFile
}