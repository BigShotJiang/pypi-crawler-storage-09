from .bot import Template as Template
