from telegram_bot_discussion import Discussion


class Template(Discussion): ...
