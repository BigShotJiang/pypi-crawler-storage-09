from .config import Config as Config
