from .replicas import Phrase as Phrase, Polemic as Polemic
from .dialogue import Dialogue as Dialogue
