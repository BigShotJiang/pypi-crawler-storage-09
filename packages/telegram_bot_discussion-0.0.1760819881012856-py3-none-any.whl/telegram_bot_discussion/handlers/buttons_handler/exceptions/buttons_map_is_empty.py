class ButtonsMapIsEmpty(Exception):
    def __str__(self) -> str:
        return f"Buttons-map is empty."
