from .android import Android
from .manual import Manual

class Types(
    Android,
    Manual
): pass
