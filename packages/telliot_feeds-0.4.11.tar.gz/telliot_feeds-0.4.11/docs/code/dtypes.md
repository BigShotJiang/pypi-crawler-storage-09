::: telliot_feeds.dtypes.value_type.ValueType

::: telliot_feeds.dtypes.float_type.UnsignedFloatType
