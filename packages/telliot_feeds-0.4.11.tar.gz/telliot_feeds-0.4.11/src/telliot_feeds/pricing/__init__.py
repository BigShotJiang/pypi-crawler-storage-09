"""Provide interface for retrieving off-chain prices."""
