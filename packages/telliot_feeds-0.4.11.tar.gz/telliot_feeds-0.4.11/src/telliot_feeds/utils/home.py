from pathlib import Path


TELLIOT_FEEDS_ROOT = Path(__file__).parent.parent
