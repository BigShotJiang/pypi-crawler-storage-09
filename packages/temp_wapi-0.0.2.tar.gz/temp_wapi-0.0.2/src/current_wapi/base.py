from abc import abstractmethod , ABC

class Abcweaatherapi:
    def __init__(self,latitude, longitude,**kwargs):
        pass
    @abstractmethod
    def __init__(self,latitude, longitude,**kwargs):
        pass