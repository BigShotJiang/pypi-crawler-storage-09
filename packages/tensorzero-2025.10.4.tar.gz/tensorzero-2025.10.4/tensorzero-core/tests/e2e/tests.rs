#![expect(
    clippy::expect_used,
    clippy::panic,
    clippy::print_stdout,
    clippy::unwrap_used
)]
mod batch;
mod best_of_n;
mod cache;
mod clickhouse;
mod common;
mod config;
mod datasets;
mod db;
mod dicl;
mod dynamic_evaluations;
mod dynamic_variants;
mod experimentation;
mod fallback;
mod feedback;
mod health;
mod howdy;
mod human_feedback;
mod human_static_evaluation_feedback;
mod inference;
mod list_inferences;
mod mixture_of_n;
mod object_storage;
mod openai_compatible;
mod optimization;
mod otel;
mod otel_config_headers;
mod otel_export;
mod prometheus;
mod providers;
mod proxy;
mod rate_limiting;
mod rate_limiting_startup;
mod render_inferences;
mod retries;
mod streaming_errors;
mod template;
mod timeouts;
