
"""
TermiGPT - AI-Powered Terminal Assistant
Version: 1.0.0
By: TheNooB
"""

__version__ = "1.0.0"
__author__ = "TheNooB"
__description__ = "AI-powered terminal assistant for code generation, security scanning, and interactive AI chat"

