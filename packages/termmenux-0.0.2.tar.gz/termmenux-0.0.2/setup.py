from setuptools import setup, find_packages

setup(
    name="termmenux",
    version="0.0.2",
    author="ATHALLAH RAJENDRA PUTRA JUNIARTO",
    author_email="athallahwork50@gmail.com",
    description="A simple CLI Menu Builder for Python",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/Athallah1234/termmenux",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
        "Topic :: Software Development :: User Interfaces",
    ],
    python_requires=">=3.13",
)