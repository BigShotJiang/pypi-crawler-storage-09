import sys, time
from .color import Color

class Animation:
    """Provides terminal animations (typing, loading, etc.)"""

    @staticmethod
    def typing(text, delay=0.03, color="cyan"):
        """Simulate typing animation."""
        for char in text:
            sys.stdout.write(Color.colorize(char, color=color))
            sys.stdout.flush()
            time.sleep(delay)
        print()

    @staticmethod
    def loading(message="Loading", dots=3, delay=0.4, color="yellow"):
        """Simple loading animation."""
        for _ in range(dots):
            sys.stdout.write(Color.colorize(f"\r{message}{'.' * (_ + 1)}", color=color))
            sys.stdout.flush()
            time.sleep(delay)
        sys.stdout.write("\r" + " " * (len(message) + dots) + "\r")
