class Color:
    """ANSI color and style utility for terminal text."""

    RESET = "\033[0m"
    BOLD = "\033[1m"
    UNDERLINE = "\033[4m"

    COLORS = {
        "black": "\033[30m",
        "red": "\033[31m",
        "green": "\033[32m",
        "yellow": "\033[33m",
        "blue": "\033[34m",
        "magenta": "\033[35m",
        "cyan": "\033[36m",
        "white": "\033[37m",
    }

    @staticmethod
    def colorize(text, color=None, bold=False, underline=False):
        style = ""
        if color and color.lower() in Color.COLORS:
            style += Color.COLORS[color.lower()]
        if bold:
            style += Color.BOLD
        if underline:
            style += Color.UNDERLINE
        return f"{style}{text}{Color.RESET}"
