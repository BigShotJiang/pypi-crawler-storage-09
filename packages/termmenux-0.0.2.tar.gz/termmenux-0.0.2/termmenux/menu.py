import asyncio
from .color import Color
from .utils import clear_screen, pause, maybe_await
from .animation import Animation


class MenuItem:
    """Represent a single selectable option."""

    def __init__(self, key, description, action):
        self.key = str(key)
        self.description = description
        self.action = action

    def __str__(self):
        return f"[{self.key}] {self.description}"


class SubMenu:
    """A menu that can be opened from another menu."""

    def __init__(self, title, items=None, exit_option=True):
        self.menu = Menu(title, exit_option=exit_option)
        if items:
            for key, desc, action in items:
                self.menu.add_item(key, desc, action)

    def open(self):
        self.menu.show()


class Menu:
    """Interactive CLI Menu Builder (supports colors, submenus, async, etc.)."""

    def __init__(self, title="Main Menu", exit_option=True, clear_on_show=True):
        self.title = title
        self.items = []
        self.exit_option = exit_option
        self.clear_on_show = clear_on_show

    def add_item(self, key, description, action):
        self.items.append(MenuItem(key, description, action))

    def add_submenu(self, key, description, submenu):
        """Add a submenu that can be opened."""
        if not isinstance(submenu, (Menu, SubMenu)):
            raise TypeError("submenu must be a Menu or SubMenu instance")
        self.add_item(key, description, submenu.show if isinstance(submenu, Menu) else submenu.open)

    def show(self):
        """Display menu and handle user interaction."""
        while True:
            if self.clear_on_show:
                clear_screen()

            Animation.typing(f"=== {self.title} ===\n", delay=0.02, color="green")

            for item in self.items:
                print(Color.colorize(str(item), color="yellow"))
            if self.exit_option:
                print(Color.colorize("[0] Exit", color="red"))

            choice = input(Color.colorize("\nSelect option: ", color="cyan")).strip()

            if choice == "0" and self.exit_option:
                print()
                Animation.typing("Exiting menu...", color="magenta", delay=0.05)
                pause()
                break

            matched = next((i for i in self.items if i.key == choice), None)
            if matched:
                try:
                    asyncio.run(maybe_await(matched.action))
                except Exception as e:
                    print(Color.colorize(f"⚠ Error: {e}", color="red", bold=True))
                    pause()
            else:
                print(Color.colorize("Invalid choice!", color="red"))
                pause()
