import os, asyncio

def clear_screen():
    """Clear terminal screen."""
    os.system("cls" if os.name == "nt" else "clear")

def pause(msg="Press Enter to continue..."):
    """Pause until Enter key pressed."""
    input(msg)

async def maybe_await(func):
    """Handle async or sync functions."""
    if asyncio.iscoroutinefunction(func):
        await func()
    else:
        func()
