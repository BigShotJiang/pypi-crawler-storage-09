"""Data models for terraform-ingest."""

from typing import List, Optional, Any, Literal
from pydantic import BaseModel, Field


class TerraformVariable(BaseModel):
    """Model for a Terraform variable."""

    name: str
    type: Optional[str] = None
    description: Optional[str] = None
    default: Optional[Any] = None
    required: bool = True


class TerraformOutput(BaseModel):
    """Model for a Terraform output."""

    name: str
    description: Optional[str] = None
    value: Optional[str] = None
    sensitive: bool = False


class TerraformProvider(BaseModel):
    """Model for a Terraform provider."""

    name: str
    source: Optional[str] = None
    version: Optional[str] = None


class TerraformModule(BaseModel):
    """Model for a Terraform module."""

    name: str
    source: str
    version: Optional[str] = None


class TerraformModuleSummary(BaseModel):
    """Summary of a Terraform module."""

    repository: str
    ref: str  # branch or tag
    path: str = "."
    description: Optional[str] = None
    variables: List[TerraformVariable] = Field(default_factory=list)
    outputs: List[TerraformOutput] = Field(default_factory=list)
    providers: List[TerraformProvider] = Field(default_factory=list)
    modules: List[TerraformModule] = Field(default_factory=list)
    readme_content: Optional[str] = None


class RepositoryConfig(BaseModel):
    """Configuration for a repository to ingest."""

    url: str
    name: Optional[str] = None
    branches: List[str] = Field(default_factory=lambda: ["main"])
    include_tags: bool = True
    max_tags: Optional[int] = 10
    path: str = "."
    recursive: bool = False


class McpConfig(BaseModel):
    """Configuration for the MCP (Model Context Protocol) service."""

    auto_ingest: bool = False
    ingest_on_startup: bool = False
    refresh_interval_hours: Optional[int] = None


class EmbeddingConfig(BaseModel):
    """Configuration for vector database embeddings."""

    enabled: bool = False
    strategy: Literal[
        "openai", "claude", "sentence-transformers", "chromadb-default"
    ] = "chromadb-default"

    # API keys for cloud embeddings
    openai_api_key: Optional[str] = None
    anthropic_api_key: Optional[str] = None

    # Model selection
    openai_model: str = "text-embedding-3-small"
    anthropic_model: str = "claude-3-haiku-20240307"
    sentence_transformers_model: str = "all-MiniLM-L6-v2"

    # ChromaDB configuration
    chromadb_host: Optional[str] = None  # For client/server mode
    chromadb_port: int = 8000
    chromadb_path: str = "./chromadb"  # For persistent mode
    collection_name: str = "terraform_modules"

    # Embedding content configuration
    include_description: bool = True
    include_readme: bool = True
    include_variables: bool = True
    include_outputs: bool = True
    include_resource_types: bool = True

    # Hybrid search configuration
    enable_hybrid_search: bool = True
    keyword_weight: float = 0.3  # Weight for keyword search (0.0 to 1.0)
    vector_weight: float = 0.7  # Weight for vector search (0.0 to 1.0)


class IngestConfig(BaseModel):
    """Configuration for the ingestion process."""

    repositories: List[RepositoryConfig]
    output_dir: str = "./output"
    clone_dir: str = "./repos"
    mcp: Optional[McpConfig] = None
    embedding: Optional[EmbeddingConfig] = None
