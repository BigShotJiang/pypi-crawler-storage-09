def main():
    print('foo')
