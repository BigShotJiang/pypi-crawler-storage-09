import{c}from"./index-CIKZHYu_.js";/**
 * @license lucide-react v0.545.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const o=[["path",{d:"M12 6v6l4 2",key:"mmk7yg"}],["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}]],r=c("clock",o);export{r as C};
//# sourceMappingURL=clock-ChxKOB9y.js.map
