# Test Tracer

Auditors on your back? Tedious red tape making you "follow medical device regulations"?

Look no further than the Dxcover Test Tracer™️

A command line tool that pulls your test cases from source code and traces to Software Requirements.

## Instructions
