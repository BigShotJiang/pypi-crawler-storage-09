"""
testmcpy - MCP Testing Framework

A comprehensive testing framework for validating LLM tool calling
capabilities with MCP (Model Context Protocol) services.
"""

__version__ = "0.1.0"
__author__ = "Preset"
__email__ = "amin@preset.io"
