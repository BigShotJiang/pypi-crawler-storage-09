"""
Web server for testmcpy UI.
"""

__all__ = ["api", "websocket", "serve"]
