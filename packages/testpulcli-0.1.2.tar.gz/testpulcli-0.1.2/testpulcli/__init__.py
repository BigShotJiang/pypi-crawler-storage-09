"""testpulcli: A CLI for managing Bittensor subnet pool operations."""

__version__ = "0.1.0"

from testpulcli.main import cli

__all__ = ["cli"]
