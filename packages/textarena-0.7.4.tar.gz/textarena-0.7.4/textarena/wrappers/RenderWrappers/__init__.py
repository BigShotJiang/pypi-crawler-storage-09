from textarena.wrappers.RenderWrappers.SimpleRenderWrapper.render import SimpleRenderWrapper
__all__ = ["SimpleRenderWrapper"]