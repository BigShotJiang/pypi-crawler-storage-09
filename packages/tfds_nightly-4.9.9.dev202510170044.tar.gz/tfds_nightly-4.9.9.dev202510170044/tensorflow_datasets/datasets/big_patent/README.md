BIGPATENT, consisting of 1.3 million records of U.S. patent documents along with
human written abstractive summaries. Each US patent application is filed under a
Cooperative Patent Classification (CPC) code. There are nine such classification
categories:

 - A (Human Necessities),
 - B (Performing Operations; Transporting),
 - C (Chemistry; Metallurgy),
 - D (Textiles; Paper),
 - E (Fixed Constructions),
 - F (Mechanical Engineering; Lightning; Heating; Weapons; Blasting),
 - G (Physics),
 - H (Electricity), and
 - Y (General tagging of new or cross-sectional technology)

There are two features:

 - description: detailed description of patent.
 - summary: Patent abstract.
