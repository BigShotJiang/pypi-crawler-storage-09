# type:ignore
import asyncio
from . import main


def smain():
    asyncio.run(main())


if __name__ == "__main__":
    smain()
