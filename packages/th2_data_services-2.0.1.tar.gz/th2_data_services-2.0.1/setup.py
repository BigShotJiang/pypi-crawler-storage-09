import json
from typing import Dict, List

from setuptools import setup, find_namespace_packages

with open("package_info.json", "r") as file:
    package_info = json.load(file)

package_name = package_info["package_name"].replace("-", "_")
package_version = package_info["package_version"]

with open("README.md", "r") as file:
    long_description = file.read()

with open("requirements.txt", "r") as file:
    requirements = [
        line.strip() for line in file.readlines() if not line.startswith("#") and line != "\n"
    ]

CORE_EXTRAS_DEPENDENCIES: Dict[str, List[str]] = {
    "rdp": [
        "th2-data-services-rdp",
    ],
    "rdp5": [
        "th2-data-services-rdp>=5,<6",
    ],
    "rdp6": [
        "th2-data-services-rdp>=6,<7",
    ],
    "lwdp": [
        "th2-data-services-lwdp",
    ],
    "lwdp1": [
        "th2-data-services-lwdp>=1,<2",
    ],
    "lwdp2": [
        "th2-data-services-lwdp>=2,<3",
    ],
    "lwdp3": [
        "th2-data-services-lwdp>=3,<4",
    ],
    "lwdp-dev": [
        "th2-data-services-lwdp>=2.0.2.0.dev,<3",
    ],
    "utils-rpt-viewer": [
        "th2-data-services-utils-rpt-viewer",
    ],
    "utils-rpt-viewer5": [
        "th2-data-services-utils-rpt-viewer>=5,<6",
    ],
    "utils-advanced": [
        "th2-data-services-utils",
    ],
}

setup(
    name=package_name,
    version=package_version,
    description=package_name,
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="TH2-devs",
    author_email="th2-devs@exactprosystems.com",
    url="https://github.com/th2-net/th2-data-services",
    license="Apache License 2.0",
    python_requires=">=3.8",
    install_requires=requirements,
    packages=find_namespace_packages(include=["th2_data_services", "th2_data_services.*"]),
    extras_require=CORE_EXTRAS_DEPENDENCIES,
    include_package_data=True,
)

