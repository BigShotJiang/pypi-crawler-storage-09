#  Copyright 2024 Exactpro (Exactpro Systems Limited)
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.
import warnings


def retry_warning(retry_state):
    """Warns about a retry attempt.

    Args:
        retry_state: An object containing information about the retry attempt,
                     including the attempt number and outcome exception.
    """
    warnings.warn(
        f"Retry attempt {retry_state.attempt_number} after {retry_state.outcome.exception()}"
    )
