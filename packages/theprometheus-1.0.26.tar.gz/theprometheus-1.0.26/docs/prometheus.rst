prometheus package
==================

Submodules
----------

prometheus.allfit module
------------------------

.. automodule:: prometheus.allfit
   :members:
   :undoc-members:
   :show-inheritance:

prometheus.aperture module
--------------------------

.. automodule:: prometheus.aperture
   :members:
   :undoc-members:
   :show-inheritance:

prometheus.ccddata module
-------------------------

.. automodule:: prometheus.ccddata
   :members:
   :undoc-members:
   :show-inheritance:

prometheus.detection module
---------------------------

.. automodule:: prometheus.detection
   :members:
   :undoc-members:
   :show-inheritance:

prometheus.getpsf module
------------------------

.. automodule:: prometheus.getpsf
   :members:
   :undoc-members:
   :show-inheritance:

prometheus.groupfit module
--------------------------

.. automodule:: prometheus.groupfit
   :members:
   :undoc-members:
   :show-inheritance:

prometheus.leastsquares module
------------------------------

.. automodule:: prometheus.leastsquares
   :members:
   :undoc-members:
   :show-inheritance:

prometheus.models module
------------------------

.. automodule:: prometheus.models
   :members:
   :undoc-members:
   :show-inheritance:

prometheus.prometheus module
----------------------------

.. automodule:: prometheus.prometheus
   :members:
   :undoc-members:
   :show-inheritance:

prometheus.sky module
---------------------

.. automodule:: prometheus.sky
   :members:
   :undoc-members:
   :show-inheritance:

prometheus.synth module
-----------------------

.. automodule:: prometheus.synth
   :members:
   :undoc-members:
   :show-inheritance:

prometheus.utils module
-----------------------

.. automodule:: prometheus.utils
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: prometheus
   :members:
   :undoc-members:
   :show-inheritance:
