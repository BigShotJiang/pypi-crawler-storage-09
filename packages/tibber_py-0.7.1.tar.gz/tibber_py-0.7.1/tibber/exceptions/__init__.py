from tibber.exceptions.api import APIException, UnauthenticatedException

__all__ = ["APIException", "UnauthenticatedException"]
