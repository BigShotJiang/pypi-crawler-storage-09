class APIException(Exception):
    pass


class UnauthenticatedException(APIException):
    pass
