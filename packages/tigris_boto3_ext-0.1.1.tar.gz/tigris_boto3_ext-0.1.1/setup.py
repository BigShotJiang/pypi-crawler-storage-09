"""Setup configuration for tigris-boto3-ext."""

from setuptools import setup

# Configuration is in pyproject.toml
setup()
