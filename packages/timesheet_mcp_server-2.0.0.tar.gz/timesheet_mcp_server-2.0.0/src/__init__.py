"""Timesheet MCP Server V2."""

__version__ = "2.0.0"
