"""Tint - add color and style to your terminal output."""

from .core import red, green, blue, bold, reset

__version__ = "0.0.1a"
__all__ = ["red", "green", "blue", "bold", "reset"]
