# pytest plugin

::: tinyvdiff.pytest_plugin
    options:
      members:
        - TinyVDiff
        - tinyvdiff
        - pytest_addoption
      show_root_heading: true
      show_source: false
