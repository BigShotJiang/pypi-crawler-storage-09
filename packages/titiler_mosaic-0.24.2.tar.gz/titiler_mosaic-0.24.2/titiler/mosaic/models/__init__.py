"""titiler.mosaic.models"""
