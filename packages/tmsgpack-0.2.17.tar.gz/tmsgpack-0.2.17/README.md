## tmsgpack: Typed MessagePack serializer (inspired by but different from msgpack)

In addition to primitives (numbers, strings, and a handful of constants),
the tmsgpack format expresses **typed objects**: typed lists/dicts and typed byte-arrays.
