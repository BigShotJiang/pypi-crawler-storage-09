from ._core import get_config
from ._loader import ConfigLoader

__version__ = "1.3.1"

__all__ = ["ConfigLoader", "get_config"]
