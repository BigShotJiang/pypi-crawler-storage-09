# 2.0.3 (2025 - 10 - 17)

Initial public release.

### Features

* **QUBOEstimator:** Class to define scikit-learn compatible estimators that rely on solving QUBO problems.
* **get_default_solver_config_if_none:** Defines default QUBO solver for our machine learning applications.
