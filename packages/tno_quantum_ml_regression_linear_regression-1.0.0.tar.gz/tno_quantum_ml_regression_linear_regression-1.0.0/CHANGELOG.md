# 1.0.0 (2025 - 10 - 07)

Initial TNO release from forked QAL repository.

### Features

* **QILinearEstimator:** Estimator that can be used to sample entries of the estimated coefficient vector and to sample entries of predictions corresponding to (un)observed target values.