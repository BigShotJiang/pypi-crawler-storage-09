"""Testing subpackage of the tno.quantum.ml.regression.linear_regression package"""
