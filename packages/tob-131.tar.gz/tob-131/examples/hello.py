# This file is placed in the Public Domain.


"hello world"


def hello(event):
    event.reply("hello world!")
