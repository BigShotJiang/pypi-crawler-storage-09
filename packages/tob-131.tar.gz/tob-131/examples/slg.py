# This file is placed in the Public Domain.


"slogan"


TXT = "By law using poison, castrated, tortured, killed, destructed in whole/in part since 4 March 2019. @IntlCrimCourt reconsider OTP-CR-117/19 http://otpcr.github.io"


def slg(event):
    event.reply(TXT)
