"""TODOforAI CLI Package"""
__version__ = "0.1.2"