These test cases are copied from
https://github.com/pyrmont/toml-specs/tree/989fdfb02f6ca0a9e3b0a09b5e5f5283e02f1fa7

There is an open PR (https://github.com/toml-lang/compliance/pull/8) to merge the tests into
https://github.com/toml-lang/compliance
after which we should sync the tests with that repository.
