from .version import version as __version

__version__ = __version
