from enum import Enum


class REDUCER_TARGET(Enum):
    """
    type of frame to reduce
    """

    DARKS = "darks"
    FLATS = "flats"
