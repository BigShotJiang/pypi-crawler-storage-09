"""deprecated module. Use nxtomo.path instead"""
