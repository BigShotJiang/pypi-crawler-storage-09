from enum import Enum


class CalculationMode(Enum):
    MEAN = "mean"
    MEDIAN = "median"
