Reports Module
==============

.. currentmodule:: toolscore.reports

The reports module generates evaluation reports in various formats.

JSON Reports
------------

.. autofunction:: generate_json_report

HTML Reports
------------

.. autofunction:: generate_html_report
