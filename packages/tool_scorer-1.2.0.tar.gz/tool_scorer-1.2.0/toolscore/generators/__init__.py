"""Synthetic test generation for Toolscore."""

from toolscore.generators.synthetic import generate_from_openai_schema

__all__ = ["generate_from_openai_schema"]
