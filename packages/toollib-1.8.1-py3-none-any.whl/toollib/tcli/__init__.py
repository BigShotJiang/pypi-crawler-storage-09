"""
@author axiner
@version v1.0.0
@created 2022/2/27 11:15
@abstract
@description
@history
"""
from pathlib import Path

here = Path(__file__).absolute().parent
