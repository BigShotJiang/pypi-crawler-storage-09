"""Top-level package for tools_collections_python.
This file makes the directory a regular Python package for setuptools discovery.
"""

__all__ = [
    # subpackages are discovered automatically
]

__version__ = "0.0.6"

