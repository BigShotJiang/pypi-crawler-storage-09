"""Tests for perms."""
