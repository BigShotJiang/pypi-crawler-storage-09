"""Tests for random."""
