from ..common import BaseStruct


class Act1VHalfIdleEnemyPreloadMeta(BaseStruct):
    enemyId: str
    level: int
