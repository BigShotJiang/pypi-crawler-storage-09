from enum import StrEnum


class Act1VHalfIdleEquipType(StrEnum):
    WEAPON = "WEAPON"
    ARMOR = "ARMOR"
    ACCESSORY = "ACCESSORY"
    NUM = "NUM"
