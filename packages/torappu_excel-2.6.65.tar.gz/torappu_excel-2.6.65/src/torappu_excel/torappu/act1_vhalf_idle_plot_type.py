from enum import StrEnum


class Act1VHalfIdlePlotType(StrEnum):
    NONE = "NONE"
    LANDSCAPE = "LANDSCAPE"
    ROAD = "ROAD"
    ROADSIDE = "ROADSIDE"
    SPECIAL = "SPECIAL"
