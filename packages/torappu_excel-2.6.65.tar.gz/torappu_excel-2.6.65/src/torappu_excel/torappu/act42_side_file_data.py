from ..common import BaseStruct


class Act42SideFileData(BaseStruct):
    contentId: str
    sortId: int
