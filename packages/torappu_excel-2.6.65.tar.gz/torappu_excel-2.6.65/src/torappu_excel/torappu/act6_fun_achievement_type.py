from ..common import CustomIntEnum


class Act6FunAchievementType(CustomIntEnum):
    NORMAL = "NORMAL", 0
    EX = "EX", 1
