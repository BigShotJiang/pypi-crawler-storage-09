from ..common import BaseStruct


class Act4funCmtInfo(BaseStruct):
    iconId: str | None
    name: str | None
    cmtTxt: str
