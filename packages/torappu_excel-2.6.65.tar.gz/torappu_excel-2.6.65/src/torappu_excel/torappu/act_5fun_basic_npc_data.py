from ..common import BaseStruct


class Act5FunBasicNpcData(BaseStruct):
    npcId: str
    avatarId: str
    name: str
