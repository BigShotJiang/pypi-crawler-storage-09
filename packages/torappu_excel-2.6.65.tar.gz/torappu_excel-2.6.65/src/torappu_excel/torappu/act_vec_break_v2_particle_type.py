from enum import StrEnum


class ActVecBreakV2ParticleType(StrEnum):
    NONE = "NONE"
    HARD = "HARD"
