from ..common import BaseStruct


class ActivityEnemyDuelExtraScoreData(BaseStruct):
    rankMin: int
    rankMax: int
    tokenNum: int
