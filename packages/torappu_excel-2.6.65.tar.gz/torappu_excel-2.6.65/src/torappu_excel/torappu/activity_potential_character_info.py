from ..common import BaseStruct


class ActivityPotentialCharacterInfo(BaseStruct):
    charId: str
