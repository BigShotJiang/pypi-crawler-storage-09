from enum import StrEnum


class AlchemyPoolRarityType(StrEnum):
    NONE = "NONE"
    NORMAL = "NORMAL"
    RARE = "RARE"
    SUPER_RARE = "SUPER_RARE"
