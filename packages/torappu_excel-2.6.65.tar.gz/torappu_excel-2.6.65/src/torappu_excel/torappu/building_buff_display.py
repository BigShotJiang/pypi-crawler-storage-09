from ..common import BaseStruct


class BuildingBuffDisplay(BaseStruct):
    base: int
    buff: int
