from ..common import BaseStruct


class CharSkinKvImgInfo(BaseStruct):
    kvImgId: str
    linkedSkinGroupId: str
