from ..common import BaseStruct


class CharUnlockParam(BaseStruct):
    charId: str
