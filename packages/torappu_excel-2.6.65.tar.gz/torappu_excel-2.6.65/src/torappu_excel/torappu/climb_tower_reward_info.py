from ..common import BaseStruct


class ClimbTowerRewardInfo(BaseStruct):
    stageSort: int
    lowerItemCount: int
    higherItemCount: int
