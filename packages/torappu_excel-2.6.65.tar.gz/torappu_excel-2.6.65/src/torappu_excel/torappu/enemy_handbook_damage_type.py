from enum import StrEnum


class EnemyHandBookDamageType(StrEnum):
    PHYSIC = "PHYSIC"
    MAGIC = "MAGIC"
    HEAL = "HEAL"
    NO_DAMAGE = "NO_DAMAGE"
