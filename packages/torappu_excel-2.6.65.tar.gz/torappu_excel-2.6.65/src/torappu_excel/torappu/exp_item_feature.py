from ..common import BaseStruct


class ExpItemFeature(BaseStruct):
    id: str
    gainExp: int
