from ..common import BaseStruct


class GachaTag(BaseStruct):
    tagId: int
    tagName: str
    tagGroup: int
