from ..common import BaseStruct


class GridPosition(BaseStruct):
    row: int
    col: int
