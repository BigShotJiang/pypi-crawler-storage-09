from ..common import CustomIntEnum


class Act1VAutoChessCommentReportCountType(CustomIntEnum):
    ONCE = "ONCE", 0
    ALWAYS = "ALWAYS", 1
