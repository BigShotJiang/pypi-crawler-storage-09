from ..common import BaseStruct


class Act1VHalfIdleEnemyDropBundle(BaseStruct):
    exp: int
    mileStoneCnt: int
    battleItemDropPool: str
    resourceItemDropPool: str
