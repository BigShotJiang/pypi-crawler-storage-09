from ..common import BaseStruct


class Act4funPerformGroupInfo(BaseStruct):
    performGroupId: str
    performIds: list[str]
