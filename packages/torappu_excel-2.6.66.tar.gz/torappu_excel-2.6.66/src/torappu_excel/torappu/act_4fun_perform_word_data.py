from ..common import BaseStruct


class Act4funPerformWordData(BaseStruct):
    text: str
    picId: str
    backgroundId: str
