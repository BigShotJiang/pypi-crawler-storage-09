from ..common import BaseStruct


class Act5FunNpcSelectorData(BaseStruct):
    npcId: str
    enemyId: str
    score: float
