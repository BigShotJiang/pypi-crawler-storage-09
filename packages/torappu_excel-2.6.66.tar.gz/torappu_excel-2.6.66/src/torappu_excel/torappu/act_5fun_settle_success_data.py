from ..common import BaseStruct


class Act5FunSettleSuccessData(BaseStruct):
    count: int
    desc: str
