from ..common import BaseStruct


class ActArchiveCopperGildData(BaseStruct):
    gildTypeId: str
    gildName: str
    gildDesc: str
