from ..common import BaseStruct


class ActArchiveLandmarkItemData(BaseStruct):
    landmarkId: str
    landmarkSortId: int
