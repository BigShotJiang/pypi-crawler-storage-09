from ..common import BaseStruct


class ActArchiveMusicItemData(BaseStruct):
    musicId: str
    musicSortId: int
