from ..common import BaseStruct


class ActArchivePicItemData(BaseStruct):
    picId: str
    picSortId: int
