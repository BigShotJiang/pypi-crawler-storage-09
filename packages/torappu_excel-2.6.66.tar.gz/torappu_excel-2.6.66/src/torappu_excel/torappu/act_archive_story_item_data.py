from ..common import BaseStruct


class ActArchiveStoryItemData(BaseStruct):
    storyId: str
    storySortId: int
