from enum import StrEnum


class ActMultiV3BlockDirType(StrEnum):
    NONE = "NONE"
    UP = "UP"
    RIGHT = "RIGHT"
    DOWN = "DOWN"
    LEFT = "LEFT"
