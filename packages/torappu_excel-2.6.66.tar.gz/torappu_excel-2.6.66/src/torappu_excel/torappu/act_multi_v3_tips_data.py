from ..common import BaseStruct


class ActMultiV3TipsData(BaseStruct):
    id: str
    txt: str
    weight: int
