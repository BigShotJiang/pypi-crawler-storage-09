from ..common import BaseStruct


class ActVecBreakV2DefenseDetailData(BaseStruct):
    stageId: str
    buffId: str
    defenseCharLimit: int
    bossIconId: str
