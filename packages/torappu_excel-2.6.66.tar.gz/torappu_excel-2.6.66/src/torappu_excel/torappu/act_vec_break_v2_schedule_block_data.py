from ..common import BaseStruct


class ActVecBreakV2ScheduleBlockData(BaseStruct):
    startTs: int
    endTs: int
