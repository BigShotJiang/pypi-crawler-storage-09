from ..common import BaseStruct


class ActVecBreakV2ZoneData(BaseStruct):
    zoneId: str
    stageLockHint: str | None
