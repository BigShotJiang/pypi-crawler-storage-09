from ..common import BaseStruct


class ActivityEnemyDuelEnemyData(BaseStruct):
    enemyId: str
    originalEnemyId: str
