from enum import IntEnum


class CharStarMarkState(IntEnum):
    NONE = 0
    STARED = 1
