from ..common import BaseStruct


class CharWordUnlockParam(BaseStruct):
    valueStr: str | None
    valueInt: int
