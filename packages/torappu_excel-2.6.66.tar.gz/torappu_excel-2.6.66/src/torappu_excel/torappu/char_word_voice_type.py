from enum import StrEnum


class CharWordVoiceType(StrEnum):
    ONLY_TEXT = "ONLY_TEXT"
    HAVE_CV = "HAVE_CV"
    ENUM = "ENUM"
