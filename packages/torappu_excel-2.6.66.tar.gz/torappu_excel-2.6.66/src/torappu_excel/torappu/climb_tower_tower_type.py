from enum import StrEnum


class ClimbTowerTowerType(StrEnum):
    TRAINING = "TRAINING"
    NORMAL = "NORMAL"
