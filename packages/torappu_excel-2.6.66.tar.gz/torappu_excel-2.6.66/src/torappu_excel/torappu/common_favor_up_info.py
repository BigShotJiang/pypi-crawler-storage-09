from ..common import BaseStruct


class CommonFavorUpInfo(BaseStruct):
    charId: str
    displayStartTime: int
    displayEndTime: int
