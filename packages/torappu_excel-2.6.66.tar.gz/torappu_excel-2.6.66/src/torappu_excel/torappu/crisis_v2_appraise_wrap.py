from ..common import BaseStruct


class CrisisV2AppraiseWrap(BaseStruct):
    appraiseType: str
