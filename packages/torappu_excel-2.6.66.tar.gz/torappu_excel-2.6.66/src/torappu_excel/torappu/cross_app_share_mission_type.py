from enum import StrEnum


class CrossAppShareMissionType(StrEnum):
    NORMAL = "NORMAL"
    ACTIVITY = "ACTIVITY"
