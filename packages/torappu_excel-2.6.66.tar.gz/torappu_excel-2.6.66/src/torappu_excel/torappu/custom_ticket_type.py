from enum import StrEnum


class CustomTicketType(StrEnum):
    NONE = "NONE"
    PURIFY = "PURIFY"
    GET_CANDLE = "GET_CANDLE"
