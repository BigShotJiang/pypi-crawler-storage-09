from .attribute_modifier_data import AttributeModifierData
from ..common import BaseStruct


class ExternalBuff(BaseStruct):
    attributes: AttributeModifierData
