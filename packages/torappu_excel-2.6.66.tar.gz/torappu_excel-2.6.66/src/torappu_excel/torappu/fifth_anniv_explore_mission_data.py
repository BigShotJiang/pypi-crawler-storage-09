from .mission_data import MissionData


class FifthAnnivExploreMissionData(MissionData):
    progressUpLimit: int
