from ..common import BaseStruct


class FullPotentialCharacterInfo(BaseStruct):
    itemId: str
    ts: int
