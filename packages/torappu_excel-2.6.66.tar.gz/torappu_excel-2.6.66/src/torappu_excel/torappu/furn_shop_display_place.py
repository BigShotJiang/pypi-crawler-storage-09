from enum import IntEnum


class FurnShopDisplayPlace(IntEnum):
    BUILDING = 0
    ALL = 1
