__version__ = "2.9.0"
__cuda_version__ = "13.0"
__tensorrt_version__ = "10.13.3"
__tensorrt_rtx_version__ = "1.0.0"
