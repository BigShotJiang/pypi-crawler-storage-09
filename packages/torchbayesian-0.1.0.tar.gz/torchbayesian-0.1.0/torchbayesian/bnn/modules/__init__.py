from torchbayesian.bnn.modules.bayesian_module import BayesianModule
