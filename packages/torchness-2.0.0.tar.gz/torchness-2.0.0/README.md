'<!--SKIP_FIX-->'
# torchness

PyTorch tools, layers, encoders, MOTorch framework for NN model management

-----------------

#### torchness dictionary & acronyms

`acc` - accuracy<br>
`cLR` - current LR<br>
`gn` - gradient norm<br>
`LR` - learning rate<br>
`mav` - moving average<br>
`TB` - tensor board<br>