initial pypo setyp
