#!/usr/bin/env python
# -*- coding: utf-8 -*-

from torchwrench.extras.safetensors import (  # noqa: F401
    dump_safetensors,
    load_safetensors,
)
