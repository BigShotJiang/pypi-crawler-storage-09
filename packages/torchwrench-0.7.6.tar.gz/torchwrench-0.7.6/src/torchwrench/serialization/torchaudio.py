#!/usr/bin/env python
# -*- coding: utf-8 -*-

from torchwrench.extras.torchaudio import (  # noqa: F401
    dump_with_torchaudio,
    load_with_torchaudio,
)
