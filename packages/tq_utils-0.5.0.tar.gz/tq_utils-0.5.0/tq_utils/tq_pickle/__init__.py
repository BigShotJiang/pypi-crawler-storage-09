from .tq_pickle import dump, load

__all__ = ['dump', 'load']
