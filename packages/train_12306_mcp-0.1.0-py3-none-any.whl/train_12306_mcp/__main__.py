
from train_12306_mcp import main
main()