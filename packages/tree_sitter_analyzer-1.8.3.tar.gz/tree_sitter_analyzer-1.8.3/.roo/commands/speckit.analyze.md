# analyze

コードベース分析とスケール評価 - 詳細は [.roo/docs/speckit.analyze.md](.roo/docs/speckit.analyze.md) を参照