# plan

プロジェクト計画と設計 - 詳細は [.roo/docs/speckit.plan.md](.roo/docs/speckit.plan.md) を参照