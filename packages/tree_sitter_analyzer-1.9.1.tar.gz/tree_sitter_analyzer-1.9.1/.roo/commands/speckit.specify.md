# specify

仕様書作成と要件定義 - 詳細は [.roo/docs/speckit.specify.md](.roo/docs/speckit.specify.md) を参照