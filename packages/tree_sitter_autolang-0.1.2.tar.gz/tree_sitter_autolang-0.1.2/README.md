# tree-sitter-autolang

[![crates][crates]](https://crates.io/crates/tree-sitter-autolang)
[![npm][npm]](https://www.npmjs.com/package/tree-sitter-autolang)
[![pypi][pypi]](https://pypi.org/project/tree-sitter-autolang)

基于 [tree-sitter](https://github.com/tree-sitter/tree-sitter) 的 AutoLang 语法。

AutoLang grammar for [tree-sitter](https://github.com/tree-sitter/tree-sitter).

[npm]: https://img.shields.io/npm/v/tree-sitter-autolang?logo=npm
[crates]: https://img.shields.io/crates/v/tree-sitter-autolang?logo=rust
[pypi]: https://img.shields.io/pypi/v/tree-sitter-autolang?logo=python
