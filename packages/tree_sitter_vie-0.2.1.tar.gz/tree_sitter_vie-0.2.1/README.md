# tree-sitter-vie

[![crates][crates]](https://crates.io/crates/tree-sitter-vie)
[![npm][npm]](https://www.npmjs.com/package/tree-sitter-vie)
[![pypi][pypi]](https://pypi.org/project/tree-sitter-vie)

Vie grammar for [tree-sitter](https://tree-sitter.github.io/tree-sitter/index.html).

<img width="500" alt="1760093620_screenshot" src="https://github.com/user-attachments/assets/b557b160-7b08-4ee1-b3d7-ec0dd9e6a235" />
