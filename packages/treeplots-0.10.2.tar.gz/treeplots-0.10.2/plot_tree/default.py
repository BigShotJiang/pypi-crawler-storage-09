class COL:
    CHILD_ID = 'child_id'
    PARENT_ID = 'parent_id'
    CHILD_NAME = 'eng_name'
    AS_OF = 'year'


CSV_FILE_NAME = 'child_parent.csv'
OUTPUT_DIR_NAME = 'output'
