# This file deliberately has several statements on a line, so
# so please spare me the lecture on standard Python style.
x = 1; y  = 2
z = lambda x, y: x + y
a = z(x, y); b = 6
print(a, b)
