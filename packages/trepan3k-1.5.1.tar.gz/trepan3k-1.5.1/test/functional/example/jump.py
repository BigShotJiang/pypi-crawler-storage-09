# This code fragment what is embedded inside ../test_jump.py
# We have it here to make it easy to test things when things go wrong.


# commands are:
#   step
#   jump 13 # 6 + 7
#   continue
##############################  # 3...
x = 4
x = 5
x = 6
z = 7  # NOQA
