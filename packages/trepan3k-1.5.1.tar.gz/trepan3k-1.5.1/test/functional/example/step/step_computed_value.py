# See that we can step with a computed count value
# cmds = ["step 5-3", "continue"]
#
##############################
x = 5
y = 6
z = 7
