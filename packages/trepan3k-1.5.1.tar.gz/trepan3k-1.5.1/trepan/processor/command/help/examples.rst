Command examples
================

::

	# This line does nothing. It is a comment. Useful in debugger command files.
	    # This line also does nothing.
	s    # by default, this is an alias for the "step" command
	info program;;list # error no command 'program;;list'
	info program ;; list # Runs two commands "info program" and "list"
