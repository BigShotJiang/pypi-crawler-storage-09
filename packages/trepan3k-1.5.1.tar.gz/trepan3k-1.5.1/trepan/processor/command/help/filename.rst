Syntax for Indicating a Filename
================================

Filename Examples:
------------------

    file.py       => file.py
    /tmp/file.py  =>  /tmp/file.py
    C\:file.py    =>  C:file.py  # For Microsoft OS's
    C\:\file.py   =>  C:\file.py # For Microsoft OS's
    C\:\\file.py  =>  C:\file.py  # Note: double slash not needed
    \\new.py    =>  \new.py     # Note: double slash, or filename has newline
    my\ file.py  =>  my file.py
