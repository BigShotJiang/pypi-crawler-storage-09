# Trollmoves developpers

The following people have made contributions to this project:

<!--- Use your GitHub account or any other personal reference URL --->
<!--- If you wish to not use your real name, please use your github username --->
<!--- The list should be alphabetical by last name if possible, with github usernames at the bottom --->
<!--- See https://gist.github.com/djhoese/52220272ec73b12eb8f4a29709be110d for auto-generating parts of this list --->

- [Trygve Aspenes (TAlonglong)](https://github.com/TAlonglong)
- [Adam Dybbroe (adybbroe)](https://github.com/adybbroe)
- [Panu Lahtinen (pnuu)](https://github.com/pnuu)
- [Lars Ørum Rasmussen (loerum)](https://github.com/loerum)
- [Martin Raspaud (mraspaud)](https://github.com/mraspaud)
