"""The Trollmoves package."""


from . import version

__version__ = version.get_versions()["version"]
