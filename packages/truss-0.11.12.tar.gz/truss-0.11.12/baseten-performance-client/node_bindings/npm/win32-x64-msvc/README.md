# `@basetenlabs/performance-client-win32-x64-msvc`

This is the **x86_64-pc-windows-msvc** binary for `@basetenlabs/performance-client`
