# `@basetenlabs/performance-client-android-arm-eabi`

This is the **armv7-linux-androideabi** binary for `@basetenlabs/performance-client`
