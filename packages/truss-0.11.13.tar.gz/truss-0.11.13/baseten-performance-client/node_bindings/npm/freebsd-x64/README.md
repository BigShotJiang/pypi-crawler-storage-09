# `@basetenlabs/performance-client-freebsd-x64`

This is the **x86_64-unknown-freebsd** binary for `@basetenlabs/performance-client`
