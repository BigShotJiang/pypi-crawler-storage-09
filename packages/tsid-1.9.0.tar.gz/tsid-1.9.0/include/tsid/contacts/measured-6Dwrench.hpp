#ifndef TSID_CONTACTS_MEASURED_6DWRENCH_HPP
#define TSID_CONTACTS_MEASURED_6DWRENCH_HPP

#include "tsid/contacts/measured-6d-wrench.hpp"

#ifdef _MSC_VER
#pragma message( \
    "TSID DEPRECATED: Please update your includes from 'measured-6Dwrench.hpp' to 'measured-6d-wrench.hpp'")
#else
#warning \
    "TSID DEPRECATED: Please update your includes from 'measured-6Dwrench.hpp' to 'measured-6d-wrench.hpp'"
#endif

#endif  // TSID_CONTACTS_MEASURED_6DWRENCH_HPP
