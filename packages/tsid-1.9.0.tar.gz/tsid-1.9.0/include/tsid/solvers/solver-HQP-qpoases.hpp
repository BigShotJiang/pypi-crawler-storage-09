//
// Copyright (c) 2017 CNRS
//

#ifndef __invdyn_solvers_fwd_hpp__
#define __invdyn_solvers_fwd_hpp__

namespace tsid {
namespace solvers {}
}  // namespace tsid

#endif  // ifndef __invdyn_solvers_fwd_hpp__
