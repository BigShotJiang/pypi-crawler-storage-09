import tsinfer.cli as cli


def main():
    cli.tsinfer_main()


if __name__ == "__main__":
    main()
