# setup.py
# This file is kept minimal; metadata and options live in setup.cfg.
# Having an explicit script ensures editable installs continue to work across build backends.
from setuptools import setup


if __name__ == "__main__":
    setup()
