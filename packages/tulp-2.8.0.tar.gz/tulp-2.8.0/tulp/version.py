# version.py
# Keep this simple, just the version string.
VERSION = "2.8.0" # Increment version after refactor
