class Azeri:
    pass
