## Summary

(Please describe your feature here)

## Implementation checklist

<!-- please don't remove this as the TuxSuite team will use this checklist to
drive the implementation work -->

- [ ] Add support in tuxmake
- [ ] Trigger container image mirroring
- [ ] Make tuxmake release
- [ ] Add server-side support in tuxbuild-backend
- [ ] Add corresponding builds into integration tests
- [ ] Mention new toolchain/architecture in tuxsuite CLI documentation/CLI help
- [ ] Tuxsuite CLI release
