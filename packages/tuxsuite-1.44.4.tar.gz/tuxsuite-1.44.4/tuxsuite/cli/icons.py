# -*- coding: utf-8 -*-

WAITING = "⏳"
PROVISIONING = "⚙️ "
RUNNING = "🚀"
PASS = "🎉"
WARNING = "👾"
FAIL = "👹"
ERROR = "🔧"
CANCELED = "⚠️ "
UNKNOWN = "🧐"
