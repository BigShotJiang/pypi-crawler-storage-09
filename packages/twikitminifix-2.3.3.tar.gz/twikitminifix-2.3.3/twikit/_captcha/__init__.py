from .base import CaptchaSolver
from .capsolver import Capsolver
