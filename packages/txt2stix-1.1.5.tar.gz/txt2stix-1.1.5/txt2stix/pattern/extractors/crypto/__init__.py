from .btc_extractor import CryptoBTCWalletExtractor

CRYPTO_EXTRACTORS = [CryptoBTCWalletExtractor]
