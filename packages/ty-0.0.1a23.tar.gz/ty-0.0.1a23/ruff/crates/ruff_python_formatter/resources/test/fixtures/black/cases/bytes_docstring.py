def bitey():
    b" not a docstring"

def bitey2():
    b' also not a docstring'

def triple_quoted_bytes():
    b""" not a docstring"""

def triple_quoted_bytes2():
    b''' also not a docstring'''

def capitalized_bytes():
    B" NOT A DOCSTRING"
