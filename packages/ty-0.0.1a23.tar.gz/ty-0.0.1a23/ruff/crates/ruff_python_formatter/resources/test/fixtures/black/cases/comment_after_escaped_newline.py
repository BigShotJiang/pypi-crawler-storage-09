def bob(): \
         # pylint: disable=W9016
    pass


def bobtwo(): \
    \
  # some comment here
    pass
