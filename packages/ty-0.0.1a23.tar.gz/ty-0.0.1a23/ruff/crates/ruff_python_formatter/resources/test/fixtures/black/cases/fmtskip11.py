def foo():
    pass


# comment 1  # fmt: skip
# comment 2
