a: string

b: string = "test"

b: list[
    string,
    int
] = [1, 2]

b: list[
    string,
    int,
] = [1, 2]
