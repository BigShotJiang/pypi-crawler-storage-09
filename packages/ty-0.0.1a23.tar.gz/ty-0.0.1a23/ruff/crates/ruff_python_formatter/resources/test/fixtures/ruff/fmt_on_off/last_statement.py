def test():
    # fmt: off

    a  + b



        # suppressed comments

a   + b # formatted
