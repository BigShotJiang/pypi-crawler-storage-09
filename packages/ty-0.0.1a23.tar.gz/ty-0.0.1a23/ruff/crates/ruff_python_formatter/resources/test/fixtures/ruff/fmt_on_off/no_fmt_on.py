def test():
    # fmt: off
    not   formatted

    if unformatted +  a:
        pass

# Gets formatted again
a   + b
