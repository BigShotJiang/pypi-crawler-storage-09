def  test():
    <RANGE_START><RANGE_END>print( "test" )
