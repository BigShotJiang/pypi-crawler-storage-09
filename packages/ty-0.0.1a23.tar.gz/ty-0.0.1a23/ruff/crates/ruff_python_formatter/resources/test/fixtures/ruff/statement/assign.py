# break left hand side
a1akjdshflkjahdslkfjlasfdahjlfds = bakjdshflkjahdslkfjlasfdahjlfds = cakjdshflkjahdslkfjlasfdahjlfds = kjaödkjaföjfahlfdalfhaöfaöfhaöfha = fkjaödkjaföjfahlfdalfhaöfaöfhaöfha = g = 3

# join left hand side
a2 = (
    b2
) = 2

# Break the last element
a = asdf = fjhalsdljfalflaflapamsakjsdhflakjdslfjhalsdljfalflaflapamsakjsdhflakjdslfjhalsdljfal = 1

aa = [
    bakjdshflkjahdslkfjlasfdahjlfds
] = dddd = ddd = fkjaödkjaföjfahlfdalfhaöfaöfhaöfha = g = [3]

aa = [

] = dddd = ddd = fkjaödkjaföjfahlfdalfhaöfaöfhaöfha = g = [3]

aa = [
    # foo
] = dddd = ddd = fkjaödkjaföjfahlfdalfhaöfaöfhaöfha = g = [3]

aa = ([
]) = dddd = ddd = fkjaödkjaföjfahlfdalfhaöfaöfhaöfha = g = [3]

aaaa = ( # trailing
    # comment
    bbbbb) = cccccccccccccccc = 3

x = (  # comment
    [  # comment
        a,
        b,
        c,
    ]
) = 1


x = (
    # comment
    [
        a,
        b,
        c,
    ]
) = 1


x = (
    [  # comment
        a,
        b,
        c,
    ]
) = 1

def main() -> None:
    if True:
        some_very_long_variable_name_abcdefghijk = some_very_long_variable_name_abcdefghijk[
            some_very_long_variable_name_abcdefghijk.some_very_long_attribute_name
            == "This is a very long string abcdefghijk"
        ]

        organization_application = (
            organization_service.get_organization_applications_by_name(
                db_request.POST["name"]
            )
        )[0]


c = b[dddddd, aaaaaa] =  (
    a[
        aaaaaaa,
        bbbbbbbbbbbbbbbbbbb
    ]
    # comment
) = xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
