raise a from aksjdhflsakhdflkjsadlfajkslhf
raise a from (aksjdhflsakhdflkjsadlfajkslhf,)
raise (aaaaa.aaa(a).a) from (aksjdhflsakhdflkjsadlfajkslhf)

raise a from (aksjdhflsakhdflkjsadlfajkslhfdkjsaldajlahflashdfljahlfksajlhfajfjfsaahflakjslhdfkjalhdskjfa,)
raise a from OsError("aksjdhflsakhdflkjsadlfajkslhfdkjsaldajlahflashdfljahlfksajlhfajfjfsaahflakjslhdfkjalhdskjfa")

# some comment
raise a from aksjdhflsakhdflkjsadlfajkslhfdkjsaldajlahflashdfljahlfksajlhfajfjfsaahflakjslhdfkjalhdskjfa # some comment
# some comment

raise OsError("aksjdhflsakhdflkjsadlfajkslhfdkjsaldajlahflashdfljahlfksajlhfajfjfsaahflakjslhdfkjalhdskjfa") from e


raise OsError(
    # should i stay
    "aksjdhflsakhdflkjsadlfajkslhfdkjsaldajlahflashdfljahlfksajlhfajfjfsaahflakjslhdfkjalhdskjfa" # mhhh very long
    # or should i go
) from e # here is e

raise OsError("aksjdhflsakhdflkjsadlfajkslhfdkjsaldajlahflashdfljahlfksajlhfajfjfsaahflakjslhdfkjalhdskjfa") from OsError("aksjdhflsakhdflkjsadlfajkslhfdkjsaldajlahflashdfljahlfksajlhfajfjfsaahflakjslhdfkjalhdskjfa")

raise OsError(
    "aksjdhflsakhdflkjsadlfajkslhfdkjsaldajlahflashdfljahlfksajlhfajfjfsaahflakjslhdfkjalhdskjfa"
) from a.aaaaa(
    aaa
).a(aaaa)

raise OsError(
    "aksjdhflsakhdflkjsadlfajkslhfdkjsaldajlahflashdfljahlfksajlhfajfjfsaahflakjslhdfkjalhdskjfa"
) from a.aaaaa(aksjdhflsakhdflkjsadlfajkslhfdkjsaldajlahflashdfljahlfksajlhfajfjfsaahflakjslhdfkjalhdskjfa).a(aaaa)

raise aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa + bbbbbbbbbbbbbbbbbbbbbbbbbb + cccccccccccccccccccccc + ddddddddddddddddddddddddd
raise aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa + bbbbbbbbbbbbbbbbbbbbbbbbbb + (cccccccccccccccccccccc + ddddddddddddddddddddddddd)
raise (aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa + bbbbbbbbbbbbbbbbbbbbbbbbbb + cccccccccccccccccccccc + ddddddddddddddddddddddddd)


raise ( # hey
    aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
    # Holala
    + bbbbbbbbbbbbbbbbbbbbbbbbbb # stay
    + cccccccccccccccccccccc + ddddddddddddddddddddddddd # where I'm going
    # I don't know
) # whaaaaat
# the end

raise ( # hey 2
    "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
    # Holala
    "bbbbbbbbbbbbbbbbbbbbbbbb" # stay
    "ccccccccccccccccccccccc"  "dddddddddddddddddddddddd" # where I'm going
    # I don't know
) # whaaaaat

# some comment
raise aksjdhflsakhdflkjsadlfajkslhfdkjsaldajlahflashdfljahlfksajlhfajfjfsaahflakjslhdfkjalhdskjfa[aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa:bbbbbbbbbbbbbbbbbbbbbbbbbb]

raise aksjdhflsakhdflkjsadlfajkslhfdkjsaldajlahflashdfljahlfksajlhfajfjfsaahflakjslhdfkjalhdskjfa < aksjdhflsakhdflkjsadlfajkslhfdkjsaldajlahflashdfljahlfksajlhfajfjfsaahflakjslhdfkjalhdskjfa <aksjdhflsakhdflkjsadlfajkslhfdkjsaldajlahflashdfljahlfksajlhfajfjfsaahflakjslhdfkjalhdskjfa

raise aksjdhflsakhdflkjsadlfajkslhfdkjsaldajlahflashdfljahlfk < (aksjdhflsakhdflkjsadlfajkslhfdkjsaldajlahflashdfljahlfksajl < aksjdhflsakhdflkjsadlfajkslhfdkjsaldajlahflashd) # the other end
# sneaky comment

raise ( # another comment
)
    
raise (
) # what now

raise ( # should I stay here
    # just a comment here
) # trailing comment

raise hello( # should I stay here
    # just a comment here
) # trailing comment

raise ( # should I stay here
    test,
    # just a comment here
) # trailing comment

raise hello( # should I stay here
    # just a comment here
    "hey"
) # trailing comment
