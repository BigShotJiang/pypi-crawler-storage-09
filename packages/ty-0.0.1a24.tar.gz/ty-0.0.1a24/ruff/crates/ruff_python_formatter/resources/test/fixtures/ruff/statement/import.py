from a import aksjdhflsakhdflkjsadlfajkslhfdkjsaldajlahflashdfljahlfksajlhfajfjfsaahflakjslhdfkjalhdskjfa
from a import aksjdhflsakhdflkjsadlfajkslhfdkjsaldajlahflashdfljahlfksajlhfajfjfsaahflakjslhdfkjalhdskjfa, aksjdhflsakhdflkjsadlfajkslhfdkjsaldajlahflashdfljahlfksajlhfajfjfsaahflakjslhdfkjalhdskjfa
from a import aksjdhflsakhdflkjsadlfajkslhfdkjsaldajlahflashdfljahlfksajlhfajfjfsaahflakjslhdfkjalhdskjfa as dfgsdfgsd, aksjdhflsakhdflkjsadlfajkslhfdkjsaldajlahflashdfljahlfksajlhfajfjfsaahflakjslhdfkjalhdskjfa as sdkjflsdjlahlfd

# Continuations.
import foo\
    .bar

from foo\
    .bar import baz

import tqdm  . tqdm

# At the top-level, force one empty line after an import, but allow up to two empty
# lines.
import os
import sys
x = 1

import os
import sys

x = 1

import os
import sys


x = 1

import os
import sys



x = 1


# In a nested scope, force one empty line after an import.
def func():
    import os
    import sys
    x = 1


def func():
    import os
    import sys

    x = 1


def func():
    import os
    import sys


    x = 1


def func():
    import os
    import sys



    x = 1

# Regression test for: https://github.com/astral-sh/ruff/issues/7604
import os

# Defaults for arguments are defined here
# args.threshold = None;


logger = logging.getLogger("FastProject")

# Regression test for: https://github.com/astral-sh/ruff/issues/7604
import os
# comment

# comment


# comment
x = 1

