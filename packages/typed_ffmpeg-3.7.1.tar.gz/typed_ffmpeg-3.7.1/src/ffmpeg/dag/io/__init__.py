"""Input/output utilities for FFmpeg DAG operations."""
