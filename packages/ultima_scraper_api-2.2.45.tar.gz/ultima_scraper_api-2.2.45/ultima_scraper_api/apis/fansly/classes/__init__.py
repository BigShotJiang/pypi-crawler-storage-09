# type:ignore
from ultima_scraper_api.apis.fansly.classes import (
    auth_model,
    extras,
    message_model,
    post_model,
    story_model,
    subscription_model,
)
from ultima_scraper_api.apis.fansly.classes import user_model as user_model
