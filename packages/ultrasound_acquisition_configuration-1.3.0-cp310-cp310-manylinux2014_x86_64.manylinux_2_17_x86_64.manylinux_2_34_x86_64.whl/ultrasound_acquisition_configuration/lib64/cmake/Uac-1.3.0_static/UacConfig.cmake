
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was UacConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../builds/common/sw/uac/build/lib.linux-x86_64-cpython-310/ultrasound_acquisition_configuration" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

include(CMakeFindDependencyMacro)

find_dependency(Urx CONFIG REQUIRED)

set(UAC_MATLAB_INSTALL_DATADIR "/builds/common/sw/uac/build/lib.linux-x86_64-cpython-310/ultrasound_acquisition_configuration/share/Uac-1.3.0_static/matlab")

include("${CMAKE_CURRENT_LIST_DIR}/UacTargets.cmake")

check_required_components(Uac)
