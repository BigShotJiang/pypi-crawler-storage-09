"""UMICP Python bindings examples."""

