"""数据模型"""

from .message import Message, Response

__all__ = ["Message", "Response"]
