from django.apps import AppConfig


class UniCMSTemplateItaliaConfig(AppConfig):
    name = 'unicms_template_italia'
