from unicorn_eval.adaptors.segmentation.baseline_segmentation_upsampling.main import (
    SegmentationUpsampling,
)

__all__ = [
    "SegmentationUpsampling",
]
