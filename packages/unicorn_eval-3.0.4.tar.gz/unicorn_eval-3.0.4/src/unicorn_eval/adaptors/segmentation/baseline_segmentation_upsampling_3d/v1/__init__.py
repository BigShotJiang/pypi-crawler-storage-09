from unicorn_eval.adaptors.segmentation.baseline_segmentation_upsampling_3d.v1.main import (
    SegmentationUpsampling3D,
)

__all__ = [
    "SegmentationUpsampling3D",
]
