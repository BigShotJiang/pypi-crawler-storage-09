from unicorn_eval.adaptors.segmentation.baseline_segmentation_upsampling_3d.v2.main import (
    SegmentationUpsampling3D_V2,
)

__all__ = [
    "SegmentationUpsampling3D_V2",
]
