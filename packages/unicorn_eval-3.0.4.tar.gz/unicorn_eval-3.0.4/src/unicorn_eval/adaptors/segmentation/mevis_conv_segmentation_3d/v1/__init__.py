from unicorn_eval.adaptors.segmentation.mevis_conv_segmentation_3d.v1.main import (
    ConvSegmentation3D,
)

__all__ = [
    "ConvSegmentation3D",
]
