# Changelog

## [Unreleased]
### Added
- Initial scaffolding aligned with Unified SDK rules

## [1.0.0] - 2025-10-09
### Added
- Initial release with Cerebras and Bedrock adapters (stubs)
- OpenAI-compatible interface (chat.completions.create)
- Comparison mode scaffolding and telemetry hooks
