# Integration Tests

Record real provider interactions with pytest-vcr and replay in CI.
