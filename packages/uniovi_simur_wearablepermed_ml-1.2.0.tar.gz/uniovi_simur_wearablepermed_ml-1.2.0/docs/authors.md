```{include} ../AUTHORS.md
:relative-docs: docs/
:relative-images:
```
