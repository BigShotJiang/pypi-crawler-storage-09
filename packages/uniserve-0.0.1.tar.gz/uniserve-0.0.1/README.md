# model-sering
Model serving system with LitServe


## Run example
uv run uniserve --api-list example.simple_api.api_list --port 8000
