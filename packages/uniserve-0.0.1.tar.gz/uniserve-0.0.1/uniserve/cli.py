import argparse
import importlib
import sys
from typing import List

from uniserve.run import run_serve
def parse_fully_qualified_name(fqn: str):
    """
    Parse a fully qualified name (module.ClassName) and return module and class names.
    
    Args:
        fqn: A string in the format "module.submodule.ClassName" or "module.ClassName"
        
    Returns:
        tuple: (module_path, class_name)
    """
    if '.' not in fqn:
        raise ValueError(f"Invalid fully qualified name: {fqn}. Expected format: module.ClassName")
    
    parts = fqn.split('.')
    module_path = '.'.join(parts[:-1])
    class_name = parts[-1]
    
    return module_path, class_name

def load_api_module(fully_qualified_name: str):
    """
    Load an API class from a fully qualified name.
    
    Args:
        fully_qualified_name: A string in the format "module.submodule.ClassName"
        
    Returns:
        The class object
    """
    module_path, object_name = parse_fully_qualified_name(fully_qualified_name)
    
    try:
        # First try direct import
        module = importlib.import_module(module_path)
        api_object = getattr(module, object_name)
        return api_object
    except ImportError as e:
        # If that fails, try adding the current working directory to sys.path
        try:
            import os
            import sys
            sys.path.insert(0, os.getcwd())
            module = importlib.import_module(module_path)
            api_object = getattr(module, object_name)
            return api_object
        except ImportError:
            # If that also fails, try with uniserve prefix
            import os
            import sys
            sys.path.insert(0, os.getcwd())
            try:
                module = importlib.import_module(f"uniserve.{module_path}")
                api_object = getattr(module, object_name)
                return api_object
            except ImportError:
                raise ImportError(f"Could not import module {module_path}: {e}")
    except AttributeError:
        raise AttributeError(f"Module {module_path} does not have an object named {object_name}")

def main() -> None:
    parser = argparse.ArgumentParser(description="UniServe - Model Serving Framework")
    parser.add_argument(
        "--api-list", 
        type=str, 
        required=True,
        help="Fully qualified name of the API list object to serve"
    )
    parser.add_argument(
        "--port", 
        type=int, 
        default=8000,
        help="Port to run the server on (default: 8000)"
    )
    parser.add_argument(
        "--host",
        type=str,
        default="127.0.0.1",
        help="Host to run the server on (default: 127.0.0.1)"
    )
    parser.add_argument(
        "--accelerator",
        type=str,
        default="auto",
        help="Accelerator to use (e.g., 'cuda', 'cpu', 'auto') (default: auto)"
    )
    parser.add_argument(
        "--devices",
        type=str,
        default="auto",
        help="Devices to use (e.g., 'auto', '[0]', '[0,1]') (default: auto)"
    )
    parser.add_argument(
        "--api-path",
        type=str,
        default=None,
        help="API endpoint path (default: None)"
    )

    
    # Parse known args to separate custom args from standard args
    args, unknown = parser.parse_known_args()
    
    # Handle devices argument parsing
    try:
        if args.devices == "auto":
            devices = "auto"
        else:
            # Try to parse as a list
            devices = eval(args.devices) if not isinstance(args.devices, list) else args.devices
    except:
        devices = "auto"
    
    # Load the API class
    try:
        api_object = load_api_module(args.api_list)
        # Check if it's a class and instantiate it, otherwise use as is
        if isinstance(api_object, type):
            api_instance = api_object()
        else:
            api_instance = api_object
    except Exception as e:
        print(f"Error loading API class: {e}")
        sys.exit(1)
    
    # Run the server
    run_serve(
        api_list=api_instance,
        port=args.port,
        accelerator=args.accelerator,
        devices=devices,
        api_path=args.api_path
    )
if __name__ == "__main__":
    main()