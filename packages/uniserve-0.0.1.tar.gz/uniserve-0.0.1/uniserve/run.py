# -*- coding: utf-8 -*-
# Copyright (c) 2025 yaqiang.sun.
# This source code is licensed under the license found in the LICENSE file
# in the root directory of this source tree.
#########################################################################
# Author: yaqiangsun
# Created Time: 2025/10/21 20:17:42
########################################################################


from typing import TYPE_CHECKING, Callable, Literal, Optional, Union
import litserve as ls



def run_serve(api_list:list, port=8000, accelerator="auto", devices="auto", api_path: Optional[str] = None):
    """
    Run a LitServe server with the provided API.
    
    Args:
        api: An instance of a LitAPI subclass
        port: Port to run the server on
        accelerator: Accelerator to use ('cpu', 'cuda', 'auto', etc.)
        devices: Devices to use ('auto', [0], [0,1], etc.)
        max_batch_size: Maximum batch size for batching requests
        api_path: The path for the API endpoint
    """
    # Create LitServer instance with advanced features (batching, GPUs, etc...)
    server = ls.LitServer(
        api_list, 
        accelerator=accelerator,
        devices=devices, 
        api_path=api_path
    )
    server.run(port=port)