# -*- coding: utf-8 -*-
# Copyright (c) 2025 yaqiang.sun.
# This source code is licensed under the license found in the LICENSE file
# in the root directory of this source tree.
#########################################################################
# Author: yaqiangsun
# Created Time: 2025/10/21 19:34:34
########################################################################

import litserve as ls
from abc import ABC, abstractmethod





# DEFINE THE API ("inference" pipeline)
class BaseLitAPI(ls.LitAPI):
    def __init__(self, model_path:str = None,api_path: str = "/predict",*args, **kwargs):
        super().__init__(api_path=api_path,*args, **kwargs)
        self.model_path = model_path
    def setup(self, device):
        # setup is called once at startup. Defines elements of the pipeline: models, connect DBs, load data, etc...
        self.device = device
        self.model = self.load_model()
        # judege model has eval() function
        if hasattr(self.model, "eval"):
            self.model.eval()
        else:
            pass
        pass
    @abstractmethod
    def load_model(self):
        pass
    @abstractmethod
    def decode_request(self, request):
        pass
        
    @abstractmethod
    def predict(self, batch_info):
        pass
        
    @abstractmethod
    def encode_response(self, predictions_info):
        pass

