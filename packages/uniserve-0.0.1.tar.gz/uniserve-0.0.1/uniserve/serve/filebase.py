# -*- coding: utf-8 -*-
# Copyright (c) 2025 yaqiang.sun.
# This source code is licensed under the license found in the LICENSE file
# in the root directory of this source tree.
#########################################################################
# Author: yaqiangsun
# Created Time: 2025/10/21 19:34:34
########################################################################

import io
from abc import ABC, abstractmethod
from fastapi import UploadFile, Form,Body,Request
from .base import BaseLitAPI

class MultiFileLitAPI(BaseLitAPI):
    def __init__(self, model_path:str,api_path: str = "/predict",file_key:str="request",*args, **kwargs):
        super().__init__(model_path=model_path,api_path=api_path,*args, **kwargs)
        self.file_key = file_key
    def decode_request(self, request: Request):
        form_data = request # not same as fastapi, in fastapi, request is a Request object, but here is a FormData object.

        defined_keys_list = list(form_data.keys())
        params_dict = {}
        for key in defined_keys_list:
            if key != self.file_key:
                params_dict[key] = form_data.get(key)
            else:
                pass

        # self.file_key: the key used when upload files in client
        # 前端/客户端上传文件时使用的字段名
        req_files = form_data.getlist(self.file_key)

        bytestream_list = []
        file_name_list  = []
        for request in req_files:
            filename = request.filename
            file_name_list.append(filename)
            # large file
            contents = b""
            for chunk in request.file:
                contents += chunk
            # small file 
            # contents = await request.read()
            byte_stream = io.BytesIO(contents)
            bytestream_list.append(byte_stream)
        return {
                    "bytestream_list":bytestream_list,
                    "params_dict":params_dict
                }
    @abstractmethod
    def predict(self, batch_info):
        bytestream_list = batch_info.get("bytestream_list")
        params_dict = batch_info.get("params_dict")
        return {
                    "params_dict":params_dict
                }
        pass