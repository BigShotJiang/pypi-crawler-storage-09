.. automodule:: unistat.contingency
   :members:
   :undoc-members:
   :show-inheritance: