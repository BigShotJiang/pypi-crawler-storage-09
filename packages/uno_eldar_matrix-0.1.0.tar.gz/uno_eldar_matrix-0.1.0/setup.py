from setuptools import setup, find_packages

setup(
    name="Uno-eldar-matrix",
    version="0.1.0",
    packages=find_packages(),
    description="Uno card game package",
    author="Eldar",
    license="MIT",
)
