from cyclopts import App

tools_app = App(
    help="List and debug MCP tools",
)
