from unpage.plugins.aptible.nodes.base import AptibleNode


class AptibleCustomResource(AptibleNode):
    pass
