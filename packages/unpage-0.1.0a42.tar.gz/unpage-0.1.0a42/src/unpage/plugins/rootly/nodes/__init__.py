# Node classes for Rootly plugin
from .rootly_incident import RootlyIncident

__all__ = ["RootlyIncident"]
