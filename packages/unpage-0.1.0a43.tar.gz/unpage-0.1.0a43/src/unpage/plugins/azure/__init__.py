from .plugin import AzurePlugin

__all__ = ["AzurePlugin"]
