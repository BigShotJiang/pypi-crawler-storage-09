#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""upcat - 图片文件夹可视化工具"""

__version__ = "0.1.0"
__author__ = "upcat Authors"