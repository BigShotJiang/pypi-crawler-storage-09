#!/usr/bin/env python3
"""upcat命令行入口"""

from upcat.main import main

if __name__ == "__main__":
    main()