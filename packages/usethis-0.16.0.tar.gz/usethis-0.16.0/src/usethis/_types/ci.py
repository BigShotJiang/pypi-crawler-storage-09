from enum import Enum


class CIServiceEnum(Enum):
    bitbucket = "bitbucket"
