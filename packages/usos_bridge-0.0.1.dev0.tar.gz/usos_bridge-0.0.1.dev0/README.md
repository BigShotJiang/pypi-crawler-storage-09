# USOS Bridge

Use your web usos credentials to interact with the USOS API

## Development

1. Clone this repository
2. Install development dependencies:

```bash
pip install -e .
pip install -r ./requirements/dev.txt
pre-commit install
```

## License

This project is licensed under the MIT License - see the LICENSE file for details.
