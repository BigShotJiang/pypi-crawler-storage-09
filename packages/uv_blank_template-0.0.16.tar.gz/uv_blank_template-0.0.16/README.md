some blank template for creating a python project with uv and published as a library with a CLI

# Features

1. uv
2. typer for CLI
3. pytest for tests
4. Makefile for useful commands like `make fix`
5. pre-commit config
6. a CLI command `uv-blank-template`

