from blank_template import app

app()
