"""Allow uvrs to be run as a module: python -m uvrs."""

from uvrs import main

if __name__ == "__main__":
    main()
