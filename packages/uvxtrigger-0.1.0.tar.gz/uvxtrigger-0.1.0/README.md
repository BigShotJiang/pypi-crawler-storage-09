# uvxtrigger

A Python library that can execution command  gracefully

## Usage

You can run this library directly using uvx without installing it:
# Run default command
uvx uvxtrigger --default

# Run custom command
uvx uvxtrigger echo "Hello from uvx!"
uvx uvxtrigger ls -l
## Features

- Includes a default command that shows system information
- Handles command output and errors gracefully
