"""
uvxtrigger - A library that triggers command execution when run via uvx
"""

__version__ = "0.1.0"
