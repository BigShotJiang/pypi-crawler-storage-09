"""
Django app for Uzbekistan administrative divisions.
"""

__version__ = "2.8.1"
