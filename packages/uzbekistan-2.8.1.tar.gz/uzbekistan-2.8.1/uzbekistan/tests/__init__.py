"""
Test package for uzbekistan app models and views.
"""
