"""
Pytest configuration for uzbekistan app.
"""

import pytest

pytest_plugins = ["pytest_django"]
