"""Auto-generated package."""
