Constants
---------

.. automodule:: vblf.constants
