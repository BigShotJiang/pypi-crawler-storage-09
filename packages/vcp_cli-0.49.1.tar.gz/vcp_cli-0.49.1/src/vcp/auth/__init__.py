"""VCP CLI authentication package."""
