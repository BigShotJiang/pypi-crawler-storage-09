(changes)=
(changelog)=
(history)=

```{currentmodule} libtmux

```

```{include} ../CHANGES

```
