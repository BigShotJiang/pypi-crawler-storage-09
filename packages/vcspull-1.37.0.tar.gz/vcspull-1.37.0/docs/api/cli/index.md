(api_cli)=

(api_commands)=

# CLI

```{toctree}
:caption: General commands
:maxdepth: 1

sync
import
fmt
```

## vcspull CLI - `vcspull.cli`

```{eval-rst}
.. automodule:: vcspull.cli
   :members:
   :show-inheritance:
   :undoc-members:
```
