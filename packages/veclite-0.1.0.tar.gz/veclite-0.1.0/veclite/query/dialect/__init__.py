"""SQL dialects."""
