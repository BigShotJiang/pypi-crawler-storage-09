from importlib.metadata import version

app_name = "vectome"
__author__ = "Eachan Johnson"
__version__ = version(app_name)
