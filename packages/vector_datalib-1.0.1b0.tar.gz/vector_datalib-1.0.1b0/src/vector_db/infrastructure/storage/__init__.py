"""Storage infrastructure module."""

from .file_storage import VectorFileStorage

__all__ = ['VectorFileStorage']
