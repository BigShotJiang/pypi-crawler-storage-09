"""A script to define common metadata details of the Vector Database Library."""

__version__ = "1.1.0-beta"
