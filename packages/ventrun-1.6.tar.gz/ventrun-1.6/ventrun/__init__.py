from .events import Main
from .cli import main

__all__ = ["Main", "main"]
