from moduvent import Event


class Ventrun(Event):
    """Base event for all pyvent events."""


class Main(Ventrun):
    """Main event for the pyvent application."""
