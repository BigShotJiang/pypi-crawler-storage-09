from .__main__ import main
from .events import Main

__all__ = ["Main", "main"]
