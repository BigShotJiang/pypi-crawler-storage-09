# CHANGELOG

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## v0.1.1 (2025-04-17)

### Features

- Updates to package for publishing ([#1](https://github.com/veris-ai/veris-python-sdk/pull/1),
  [`c6f460e`](https://github.com/veris-ai/veris-python-sdk/commit/c6f460ea6e2f8472c120370a14f67f1d8c28626c))
