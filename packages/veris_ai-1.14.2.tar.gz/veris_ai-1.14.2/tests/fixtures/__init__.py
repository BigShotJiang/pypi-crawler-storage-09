"""Test fixtures for veris-ai."""
