class VerNumError(Exception):
    pass
