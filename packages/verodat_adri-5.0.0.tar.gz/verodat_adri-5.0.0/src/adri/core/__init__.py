"""Core ADRI framework components.

This module contains the fundamental interfaces, protocols, and base classes
that define the architecture of the ADRI framework.
"""
