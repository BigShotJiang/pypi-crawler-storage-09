"""Tests for ADRI event system."""
