"""Unit tests for core ADRI framework components."""
