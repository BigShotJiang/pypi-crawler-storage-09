"""Utilities for Vibe Reader backend services."""
