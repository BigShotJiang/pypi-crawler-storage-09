"""
API Models and Request/Response schemas for VibeSurf Backend
"""