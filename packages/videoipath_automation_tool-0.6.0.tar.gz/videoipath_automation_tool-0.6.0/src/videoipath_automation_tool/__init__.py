from videoipath_automation_tool.apps.videoipath_app import VideoIPathApp  # noqa: F401
