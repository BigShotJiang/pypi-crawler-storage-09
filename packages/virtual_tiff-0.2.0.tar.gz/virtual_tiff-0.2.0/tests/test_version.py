def test_version():
    from virtual_tiff import __version__

    assert __version__
