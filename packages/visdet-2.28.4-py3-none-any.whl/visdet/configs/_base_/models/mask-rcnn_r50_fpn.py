# ruff: noqa
# type: ignore
# model settings
model = {
    "type": "MaskRCNN",
    "data_preprocessor": {
        "type": "DetDataPreprocessor",
        "mean": [123.675, 116.28, 103.53],
        "std": [58.395, 57.12, 57.375],
        "bgr_to_rgb": True,
        "pad_mask": True,
        "pad_size_divisor": 32,
    },
    "backbone": {
        "type": "ResNet",
        "depth": 50,
        "num_stages": 4,
        "out_indices": (0, 1, 2, 3),
        "frozen_stages": 1,
        "norm_cfg": {"type": "BN", "requires_grad": True},
        "norm_eval": True,
        "style": "pytorch",
        "init_cfg": {"type": "Pretrained", "checkpoint": "torchvision://resnet50"},
    },
    "neck": {
        "type": "FPN",
        "in_channels": [256, 512, 1024, 2048],
        "out_channels": 256,
        "num_outs": 5,
    },
    "rpn_head": {
        "type": "RPNHead",
        "in_channels": 256,
        "feat_channels": 256,
        "anchor_generator": {
            "type": "AnchorGenerator",
            "scales": [8],
            "ratios": [0.5, 1.0, 2.0],
            "strides": [4, 8, 16, 32, 64],
        },
        "bbox_coder": {
            "type": "DeltaXYWHBBoxCoder",
            "target_means": [0.0, 0.0, 0.0, 0.0],
            "target_stds": [1.0, 1.0, 1.0, 1.0],
        },
        "loss_cls": {
            "type": "CrossEntropyLoss",
            "use_sigmoid": True,
            "loss_weight": 1.0,
        },
        "loss_bbox": {"type": "L1Loss", "loss_weight": 1.0},
    },
    "roi_head": {
        "type": "StandardRoIHead",
        "bbox_roi_extractor": {
            "type": "SingleRoIExtractor",
            "roi_layer": {"type": "RoIAlign", "output_size": 7, "sampling_ratio": 0},
            "out_channels": 256,
            "featmap_strides": [4, 8, 16, 32],
        },
        "bbox_head": {
            "type": "Shared2FCBBoxHead",
            "in_channels": 256,
            "fc_out_channels": 1024,
            "roi_feat_size": 7,
            "num_classes": 80,
            "bbox_coder": {
                "type": "DeltaXYWHBBoxCoder",
                "target_means": [0.0, 0.0, 0.0, 0.0],
                "target_stds": [0.1, 0.1, 0.2, 0.2],
            },
            "reg_class_agnostic": False,
            "loss_cls": {
                "type": "CrossEntropyLoss",
                "use_sigmoid": False,
                "loss_weight": 1.0,
            },
            "loss_bbox": {"type": "L1Loss", "loss_weight": 1.0},
        },
        "mask_roi_extractor": {
            "type": "SingleRoIExtractor",
            "roi_layer": {"type": "RoIAlign", "output_size": 14, "sampling_ratio": 0},
            "out_channels": 256,
            "featmap_strides": [4, 8, 16, 32],
        },
        "mask_head": {
            "type": "FCNMaskHead",
            "num_convs": 4,
            "in_channels": 256,
            "conv_out_channels": 256,
            "num_classes": 80,
            "loss_mask": {
                "type": "CrossEntropyLoss",
                "use_mask": True,
                "loss_weight": 1.0,
            },
        },
    },
    # model training and testing settings
    "train_cfg": {
        "rpn": {
            "assigner": {
                "type": "MaxIoUAssigner",
                "pos_iou_thr": 0.7,
                "neg_iou_thr": 0.3,
                "min_pos_iou": 0.3,
                "match_low_quality": True,
                "ignore_iof_thr": -1,
            },
            "sampler": {
                "type": "RandomSampler",
                "num": 256,
                "pos_fraction": 0.5,
                "neg_pos_ub": -1,
                "add_gt_as_proposals": False,
            },
            "allowed_border": -1,
            "pos_weight": -1,
            "debug": False,
        },
        "rpn_proposal": {
            "nms_pre": 2000,
            "max_per_img": 1000,
            "nms": {"type": "nms", "iou_threshold": 0.7},
            "min_bbox_size": 0,
        },
        "rcnn": {
            "assigner": {
                "type": "MaxIoUAssigner",
                "pos_iou_thr": 0.5,
                "neg_iou_thr": 0.5,
                "min_pos_iou": 0.5,
                "match_low_quality": True,
                "ignore_iof_thr": -1,
            },
            "sampler": {
                "type": "RandomSampler",
                "num": 512,
                "pos_fraction": 0.25,
                "neg_pos_ub": -1,
                "add_gt_as_proposals": True,
            },
            "mask_size": 28,
            "pos_weight": -1,
            "debug": False,
        },
    },
    "test_cfg": {
        "rpn": {
            "nms_pre": 1000,
            "max_per_img": 1000,
            "nms": {"type": "nms", "iou_threshold": 0.7},
            "min_bbox_size": 0,
        },
        "rcnn": {
            "score_thr": 0.05,
            "nms": {"type": "nms", "iou_threshold": 0.5},
            "max_per_img": 100,
            "mask_thr_binary": 0.5,
        },
    },
}
