# 🧰 FastAPI utils by vishwa-labs 
This is a thin wrapper around FastAPI to centralize telemetry, logs, config management and other items

This also maintains the reusable utilities and hooks that can be shared across projects
### How to install?
```shell
pip install vishwa-fastapi-utils
```
