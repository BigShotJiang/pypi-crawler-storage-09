

class PostgreSQLCacheNamespace:
    pass

