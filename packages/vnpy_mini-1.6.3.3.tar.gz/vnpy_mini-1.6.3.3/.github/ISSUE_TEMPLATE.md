## 环境

* 操作系统: 如Windows 11或者Ubuntu 22.04
* Python版本: 如VeighNa Studio-4.0.0
* VeighNa版本: 如v4.0.0发行版或者dev branch 20250320（下载日期）

## Issue类型
三选一：Bug/Enhancement/Question

## 预期程序行为


## 实际程序行为


## 重现步骤

针对Bug类型Issue，请提供具体重现步骤以及报错截图

