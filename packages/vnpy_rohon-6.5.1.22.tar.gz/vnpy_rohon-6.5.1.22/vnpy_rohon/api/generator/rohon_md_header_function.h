int reqUserLogin(const dict &req, int reqid);

int reqUserLogout(const dict &req, int reqid);

int reqQryMulticastInstrument(const dict &req, int reqid);

