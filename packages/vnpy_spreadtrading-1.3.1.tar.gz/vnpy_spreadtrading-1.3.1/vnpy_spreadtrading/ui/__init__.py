from .widget import SpreadManager


__all__ = ["SpreadManager"]
