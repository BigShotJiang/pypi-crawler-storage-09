"""VAD module for voice activity detection."""

from .voice_detector import VoiceDetector

__all__ = ['VoiceDetector'] 