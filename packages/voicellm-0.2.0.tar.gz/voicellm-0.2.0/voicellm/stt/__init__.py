"""STT module for speech recognition using Whisper."""

from .transcriber import Transcriber

__all__ = ['Transcriber'] 