from voicevox.app_voicevox import *
from voicevox.config import *
