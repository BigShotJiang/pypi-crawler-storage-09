"""Package resources: ABIs, bytecodes, and contracts."""
