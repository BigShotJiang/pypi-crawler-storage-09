"""CCIP utilities for gas estimation and simulation."""
