"""votuderep - A CLI tool for dereplicating and filtering viral contigs."""

__version__ = "0.4.0"
__author__ = "Andrea Telatin"
__license__ = "MIT"

__all__ = ["__version__", "__author__", "__license__"]
