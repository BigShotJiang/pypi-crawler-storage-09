"""Entry point for running votuderep as a module (python -m votuderep)."""

from .cli import main

if __name__ == "__main__":
    main()
