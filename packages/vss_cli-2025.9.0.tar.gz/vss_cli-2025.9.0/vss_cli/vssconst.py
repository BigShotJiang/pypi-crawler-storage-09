"""VSS Constants for the vss-cli."""
CONTENT_TYPE_JSON = 'application/json'
CONTENT_TYPE_MULTIPART = 'multipart/x-mixed-replace; boundary={}'
CONTENT_TYPE_TEXT_PLAIN = 'text/plain'

STATUS_PAGE_ID = 'ftgqfszqxm8y'
STATUS_PAGE_SERVICE = 'Virtual Server'

HEALTHCHECK_IO = '5e581364-2df8-44f5-a92d-32fa7e90d39e/RmnEVCvr.json'

VSS_VPN_ENDPOINT = 'https://eis.utoronto.ca/~vss/status/vskey-gw.json'
