class RemovedInWagtailMedia015Warning(PendingDeprecationWarning):
    pass


class RemovedInWagtailMedia016Warning(DeprecationWarning):
    pass
