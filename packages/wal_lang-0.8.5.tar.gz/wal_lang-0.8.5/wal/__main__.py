'''WAL'''

if __name__ == "__main__":
    from wal.wal import run
    run()
