'''contains the current version of WAL'''
__version__ = '0.8.5'
