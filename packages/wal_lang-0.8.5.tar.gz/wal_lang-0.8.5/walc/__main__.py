'''WALC'''

if __name__ == "__main__":
    from wal.walc import run
    run()
