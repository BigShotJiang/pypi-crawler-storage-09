# NOTICE

Copyright 2024 - 2025 Waldiez and contributors.

This Work includes Software developed by Waldiez (<https://waldiez.io/>).

## Trademarks

You may use our Mark, but not the Project's logos, to truthfully describe the relationship between your software and ours. Our Mark should be used after a verb or preposition that describes the relationship between your software and ours. So you may say, for example, "Bob's software for the Waldiez platform" but may not say "Bob's Waldiez software." Some other examples that may work for you are:

- *[Your software]* uses software developed by Waldiez  
- *[Your software]* is powered by Waldiez software  
- *[Your software]* runs using software developed by Waldiez  
- *[Your software]* for use with software developed by Waldiez
