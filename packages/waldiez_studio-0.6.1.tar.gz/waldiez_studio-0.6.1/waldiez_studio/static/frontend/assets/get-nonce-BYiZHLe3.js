var _=function(){if("undefined"!=typeof __webpack_nonce__)return __webpack_nonce__};export{_ as g};
