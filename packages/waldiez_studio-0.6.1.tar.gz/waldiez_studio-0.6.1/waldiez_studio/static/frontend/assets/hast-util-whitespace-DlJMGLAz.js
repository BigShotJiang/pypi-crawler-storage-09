const t=/[ \t\n\f\r]/g;function e(t){return"object"==typeof t?"text"===t.type&&n(t.value):n(t)}function n(e){return""===e.replace(t,"")}export{e as w};
