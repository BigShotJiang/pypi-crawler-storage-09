"""Polling-processing module."""
