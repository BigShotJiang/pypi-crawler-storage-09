"""Tests for OKD plugin."""
