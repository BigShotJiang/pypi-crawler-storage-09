from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar

from attrs import (
    define as _attrs_define,
    field as _attrs_field,
)

if TYPE_CHECKING:
    from ..models.assays_get_assay_by_id_response_200_baseline_type_1_static import (
        AssaysGetAssayByIdResponse200BaselineType1Static,
    )


T = TypeVar("T", bound="AssaysGetAssayByIdResponse200BaselineType1")


@_attrs_define
class AssaysGetAssayByIdResponse200BaselineType1:
    """
    Attributes:
        static (AssaysGetAssayByIdResponse200BaselineType1Static):  Result from summarizing one sample collection.
    """

    static: "AssaysGetAssayByIdResponse200BaselineType1Static"
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        static = self.static.to_dict()

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "static": static,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.assays_get_assay_by_id_response_200_baseline_type_1_static import (
            AssaysGetAssayByIdResponse200BaselineType1Static,
        )

        d = src_dict.copy()
        static = AssaysGetAssayByIdResponse200BaselineType1Static.from_dict(
            d.pop("static")
        )

        assays_get_assay_by_id_response_200_baseline_type_1 = cls(
            static=static,
        )

        assays_get_assay_by_id_response_200_baseline_type_1.additional_properties = d
        return assays_get_assay_by_id_response_200_baseline_type_1

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
