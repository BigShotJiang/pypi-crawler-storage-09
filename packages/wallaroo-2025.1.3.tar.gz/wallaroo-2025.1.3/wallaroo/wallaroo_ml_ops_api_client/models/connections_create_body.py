from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union, cast

from attrs import (
    define as _attrs_define,
    field as _attrs_field,
)

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.connections_create_body_details_type_0 import (
        ConnectionsCreateBodyDetailsType0,
    )


T = TypeVar("T", bound="ConnectionsCreateBody")


@_attrs_define
class ConnectionsCreateBody:
    """Request to create a new Connection

    Attributes:
        name (str):  Descriptive name for the new connection
        type (str):  The type of connection that can be made
        details (Union['ConnectionsCreateBodyDetailsType0', None, Unset]):  The info needed to make a connection
    """

    name: str
    type: str
    details: Union["ConnectionsCreateBodyDetailsType0", None, Unset] = UNSET
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        from ..models.connections_create_body_details_type_0 import (
            ConnectionsCreateBodyDetailsType0,
        )

        name = self.name

        type = self.type

        details: Union[Dict[str, Any], None, Unset]
        if isinstance(self.details, Unset):
            details = UNSET
        elif isinstance(self.details, ConnectionsCreateBodyDetailsType0):
            details = self.details.to_dict()
        else:
            details = self.details

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "type": type,
            }
        )
        if details is not UNSET:
            field_dict["details"] = details

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.connections_create_body_details_type_0 import (
            ConnectionsCreateBodyDetailsType0,
        )

        d = src_dict.copy()
        name = d.pop("name")

        type = d.pop("type")

        def _parse_details(
            data: object,
        ) -> Union["ConnectionsCreateBodyDetailsType0", None, Unset]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                details_type_0 = ConnectionsCreateBodyDetailsType0.from_dict(data)

                return details_type_0
            except:  # noqa: E722
                pass
            return cast(Union["ConnectionsCreateBodyDetailsType0", None, Unset], data)

        details = _parse_details(d.pop("details", UNSET))

        connections_create_body = cls(
            name=name,
            type=type,
            details=details,
        )

        connections_create_body.additional_properties = d
        return connections_create_body

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
