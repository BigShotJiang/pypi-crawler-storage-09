# Changelog #

## Version 0.2.3 ##
* pipeline_network bug fix
* Introduction of notebook build command for CI/CD environments

## Version 0.2.2 ##
* allow for building and pushing containers in an environment without access to GCP  

## Version 0.2.1 ##
* Initial OSS release