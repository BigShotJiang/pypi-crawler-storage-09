"""The Wanting package."""

from wanting.wanting import (
    FieldInfoEx,
    IncExMapping,
    Json,
    Unavailable,
    Unmapped,
    Wanting,
    WantingValues,
    wanting_fields,
    wanting_incex,
    wanting_values,
)

__author__ = "Narvin Singh"
__version__ = "0.8.1"

__all__ = [
    "FieldInfoEx",
    "IncExMapping",
    "Json",
    "Unavailable",
    "Unmapped",
    "Wanting",
    "WantingValues",
    "__version__",
    "wanting_fields",
    "wanting_incex",
    "wanting_values",
]
