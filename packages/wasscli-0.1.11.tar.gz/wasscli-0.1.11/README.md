# wasscli
---

wasscli is an interactive Command Line Tool (CLI) to simplify the usage of the [WASS](https://sites.google.com/unive.it/wass) pipeline.

## Usage

Run:

```
$ wasscli
```

at the command prompt and follow the instructions. Tipically, you execute in order: Prepare -> Match -> Autocalibrate -> Stereo.

