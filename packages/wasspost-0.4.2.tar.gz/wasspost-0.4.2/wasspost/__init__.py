from .wasspost import wasspost_main, VERSION
