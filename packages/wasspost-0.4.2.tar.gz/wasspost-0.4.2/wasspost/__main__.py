from .wasspost import wasspost_main

if __name__ == "__main__":
    wasspost_main()
