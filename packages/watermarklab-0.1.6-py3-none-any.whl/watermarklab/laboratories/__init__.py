from .func import evaluate, WLab
from .utils import lightweight_json_result
