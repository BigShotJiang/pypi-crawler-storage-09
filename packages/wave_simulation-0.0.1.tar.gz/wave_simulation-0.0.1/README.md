# wave simulation
