class ADB:
    pass
