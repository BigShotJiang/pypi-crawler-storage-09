class Frida:
    pass
