from wbcore.metadata.configs.display.configs import preset_config

from .configs import (
    markdown_config,
    menu_calendar_config,
    menu_config,
    release_note_config,
    share_config,
    beta_button,
    frontend_version,
    user_preferences
)
