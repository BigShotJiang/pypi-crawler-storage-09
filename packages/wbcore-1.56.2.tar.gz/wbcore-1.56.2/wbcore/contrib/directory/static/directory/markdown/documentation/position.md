# Company Positions
This is a list of every company position in the database where you can modify, delete and add new company positions. Typing in the search field or the column filter accessible from the three lines at the end of the column title filters the company positions by name. Click on the column title to order it.
