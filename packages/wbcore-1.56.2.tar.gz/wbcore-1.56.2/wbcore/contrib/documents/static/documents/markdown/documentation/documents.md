# Documents:
A list of documents uploaded to the workbench.


## Columns:
Each column title has three lines on the right if you hover over it. Click on them to show options for that column. The second tab of the options menu will allow you to filter the column, the third to completely hide entire columns. Click on anywhere else on the column to order it, cycling between ascending, descending and no ordering. Hold shift while clicking to order multiple columns with individual weights.

### Name:
The name of the document.
### Type:
The document's type. Types can be added and edited under DMS > Document Types.

## Buttons:
### Download:
Download this document on your computer.

## Search Field:
Typing in the search field allows to filter the documents by name.
