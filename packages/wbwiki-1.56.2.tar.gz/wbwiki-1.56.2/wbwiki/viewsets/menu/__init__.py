from .wikis import WIKI_MENU, WIKI_MENU_ITEM
