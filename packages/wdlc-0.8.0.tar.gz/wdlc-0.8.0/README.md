What will we need to do?

Implement the major layers in pytorch:
- Linear
- Conv2D
- FC
- ReLU
- Pool
- RNN
- LSTM
- Batch Norm
... etc

----------------------------

- Support `nn.Sequential`

- Support hugging face models

- Support saved model.

- Optimization Phase:
