from .tracing import get_notdiamond_patcher  # noqa: F401
