"""WebQuiz Stress Test - Performance testing tool for WebQuiz servers"""

__version__ = "0.1.2"
__author__ = "Oleksandr Liabakh"
__email__ = "oduvan@gmail.com"
