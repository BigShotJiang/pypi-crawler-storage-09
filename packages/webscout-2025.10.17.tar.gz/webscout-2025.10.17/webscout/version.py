__version__ = "2025.10.17"
__prog__ = "webscout"
