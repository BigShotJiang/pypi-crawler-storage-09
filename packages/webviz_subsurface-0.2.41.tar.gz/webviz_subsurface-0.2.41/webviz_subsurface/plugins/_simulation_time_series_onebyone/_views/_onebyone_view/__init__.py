from ._view import OneByOneView
