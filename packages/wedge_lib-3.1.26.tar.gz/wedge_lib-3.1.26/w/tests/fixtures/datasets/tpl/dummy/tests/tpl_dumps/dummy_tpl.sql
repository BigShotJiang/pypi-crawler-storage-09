CREATE TABLE IF NOT EXISTS dummy_table (id SERIAL PRIMARY KEY, name VARCHAR(50));
INSERT INTO dummy_table (name) VALUES ('test_name');
