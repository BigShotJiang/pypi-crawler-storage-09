"""
Setup script for the WeChat Work API SDK.
This file is needed for proper packaging and distribution.
"""

from setuptools import setup

# This file is intentionally minimal as the main configuration is in pyproject.toml
setup()