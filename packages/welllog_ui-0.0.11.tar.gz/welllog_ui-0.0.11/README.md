# WellLog UI

一个基于 PySide6 和深度学习管道的测井数据可视化分析工具。

## 功能特性

- 测井数据可视化
- 深度学习模型训练和预测
- 数据预处理和过滤
- 交互式图表显示
- 数据库项目管理

## 系统要求

- Python 3.9.21
- Windows 操作系统
- 支持 CUDA 的 GPU（可选，用于深度学习加速）

## 安装

```bash
pip install welllog-ui
```

## 使用方法

### 命令行启动

```bash
welllog-ui
```

### Python 代码中使用

```python
from welllog_ui import run_main

if __name__ == "__main__":
    run_main()
```

## 依赖项

- PySide6 >= 6.5, < 7
- numpy >= 1.24, < 2
- torch >= 2.2, < 3
- pytorch-lightning >= 2.1, < 3
- scikit-learn >= 1.2, < 2
- pyqtgraph >= 0.13, < 1
- PyWavelets >= 1.5, < 2
- chardet >= 5, < 6

## 许可证

专有软件许可证

## 联系方式

如有问题，请联系：you@example.com
