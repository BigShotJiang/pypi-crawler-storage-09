from django.apps import AppConfig


class WeniFeatureFlagsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "weni_feature_flags"
