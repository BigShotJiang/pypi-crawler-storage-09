default_app_config = "weni.auth.apps.AuthConfig"
