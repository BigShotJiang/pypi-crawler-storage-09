default_app_config = "weni.grpc.channel.apps.ChannelGrpcConfig"
