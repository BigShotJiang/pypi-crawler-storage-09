from django.apps import AppConfig


class ChannelGrpcConfig(AppConfig):
    name = "weni.grpc.channel"
