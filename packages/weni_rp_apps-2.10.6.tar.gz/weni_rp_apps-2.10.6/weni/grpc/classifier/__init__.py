default_app_config = "weni.grpc.classifier.apps.ClassifierGrpcConfig"
