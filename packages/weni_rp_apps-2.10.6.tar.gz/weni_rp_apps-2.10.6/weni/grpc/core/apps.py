from django.apps import AppConfig


class GrpcCentralConfig(AppConfig):
    name = "weni.grpc.core"
