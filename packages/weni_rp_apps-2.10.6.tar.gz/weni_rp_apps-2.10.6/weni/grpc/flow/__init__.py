default_app_config = "weni.grpc.flow.apps.FlowGrpcConfig"
