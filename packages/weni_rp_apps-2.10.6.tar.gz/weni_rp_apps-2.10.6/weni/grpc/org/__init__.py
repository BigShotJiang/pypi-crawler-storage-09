default_app_config = "weni.grpc.org.apps.OrgGrpcConfig"
