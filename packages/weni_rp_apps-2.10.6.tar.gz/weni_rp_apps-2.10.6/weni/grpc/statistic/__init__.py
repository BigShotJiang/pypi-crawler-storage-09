default_app_config = "weni.grpc.statistic.apps.StatisticGrpcConfig"
