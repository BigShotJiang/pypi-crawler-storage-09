from django.apps import AppConfig


class StatisticGrpcConfig(AppConfig):
    name = "weni.grpc.statistic"
