from weni.internal.clients.connect import ConnectInternalClient  # noqa: F401

__all__ = "ConnectInternalClient"
