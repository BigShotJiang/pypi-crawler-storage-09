default_app_config = "weni.template_message.apps.TemplateMessageConfig"
