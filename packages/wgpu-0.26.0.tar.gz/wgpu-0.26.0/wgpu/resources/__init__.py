"""This module exists to have importlib.resources and setuptools recognize the folder as a module."""
