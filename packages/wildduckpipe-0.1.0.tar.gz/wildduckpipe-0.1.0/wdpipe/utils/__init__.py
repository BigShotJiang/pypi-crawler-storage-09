"""Utilitary routines"""
