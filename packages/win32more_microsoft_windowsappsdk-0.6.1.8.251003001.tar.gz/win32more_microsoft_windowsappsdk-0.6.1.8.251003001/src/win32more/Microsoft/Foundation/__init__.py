from __future__ import annotations
from win32more.winrt.prelude import *
import win32more.Microsoft.Foundation
WindowsAppSDKContract: UInt32 = 65544


make_ready(__name__)
