```xml
<output>
    <evaluate>{evaluate}</evaluate>
    <thought>{thought}</thought>
    <action_name>{action_name}</action_name>
    <action_input>{action_input}</action_input>
</output>
```