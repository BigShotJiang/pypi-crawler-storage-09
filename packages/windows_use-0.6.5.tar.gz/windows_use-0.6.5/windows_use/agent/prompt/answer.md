```xml
<output>
    <evaluate>{evaluate}</evaluate>
    <thought>{thought}</thought>
    <final_answer>{final_answer}</final_answer>
</output>
```