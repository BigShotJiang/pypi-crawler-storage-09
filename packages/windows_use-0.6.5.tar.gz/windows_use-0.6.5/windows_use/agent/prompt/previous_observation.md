```xml
<input>
    <agent_state>
        Steps: {steps}/{max_steps}
                                          
        Action Response: {observation}
    </agent_state>
</input>
```