#ifndef UVLOOP_DEBUG
#define UVLOOP_DEBUG 0
#endif
