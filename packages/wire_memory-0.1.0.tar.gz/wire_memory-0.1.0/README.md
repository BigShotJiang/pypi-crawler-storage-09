# Wire for communicating over memory
