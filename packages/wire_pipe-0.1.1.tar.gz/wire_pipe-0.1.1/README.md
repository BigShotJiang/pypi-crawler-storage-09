# Wire for communicating over pipes
