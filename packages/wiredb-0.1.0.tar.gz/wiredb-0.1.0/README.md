# WireDB

[![Build Status](https://github.com/davidbrochart/wiredb/workflows/test/badge.svg)](https://github.com/davidbrochart/wiredb/actions)

At its core, WireDB uses [Yrs](https://github.com/y-crdt/y-crdt/tree/main/yrs) (pronounce *wires*).
WireDB is a distributed database built on top of CRDTs, that you can connect any way you want.
