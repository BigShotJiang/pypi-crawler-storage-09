WMStats.namespace("RequestModel");
//TODO: specify tableConfig and filterConfig for T0.
WMStats.RequestModel =  new WMStats._RequestModelBase();
