### Build and Deploy Workbench Training/Inference Images

```
cd scripts
./build_deploy.sh pytorch_training 0.1 --deploy --overwrite
```
