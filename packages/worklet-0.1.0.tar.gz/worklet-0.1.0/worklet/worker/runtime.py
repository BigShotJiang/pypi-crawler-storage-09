IS_WORKER_RUNNING: bool = False
PORTAL: str | None = None
