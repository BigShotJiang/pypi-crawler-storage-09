"""Workstack development CLI."""

from workstack_dev.__main__ import cli

__all__ = ["cli"]
