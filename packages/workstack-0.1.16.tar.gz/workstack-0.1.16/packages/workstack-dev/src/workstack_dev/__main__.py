"""Development CLI entry point."""

from workstack_dev.cli import cli

if __name__ == "__main__":
    cli()
