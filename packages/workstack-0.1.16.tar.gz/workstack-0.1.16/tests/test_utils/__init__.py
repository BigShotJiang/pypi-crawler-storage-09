"""Shared test utilities and helpers."""
