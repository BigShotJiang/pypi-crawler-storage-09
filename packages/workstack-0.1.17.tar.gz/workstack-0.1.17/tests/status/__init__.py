"""Tests for status command and components."""
