# WriftAI Python Client

[![CI](https://github.com/wriftai/wriftai-python/actions/workflows/ci.yml/badge.svg)](https://github.com/wriftai/wriftai-python/actions/workflows/ci.yml)
![PyPI - Version](https://img.shields.io/pypi/v/wriftai)
[![License](https://img.shields.io/github/license/wriftai/wriftai-python)](https://img.shields.io/github/license/wriftai/wriftai-python)

Python client for WriftAI

## Documentation
Coming Soon

## Installation
Coming Soon

## Contributing
Contributions are very welcome. To learn more, see the [Contributor Guide](./CONTRIBUTING.md).

## License
Copyright (c) Sych Inc. All rights reserved.

Distributed under the terms of the [Apache 2.0 license](./LICENSE).
