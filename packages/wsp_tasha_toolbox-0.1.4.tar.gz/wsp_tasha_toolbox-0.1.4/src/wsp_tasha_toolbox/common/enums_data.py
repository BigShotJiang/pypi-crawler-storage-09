__all__ = [
    "TimeFormat",
]

from enum import StrEnum


class TimeFormat(StrEnum):
    MINUTE_DELTA = "minute_delta"
    COLON_SEP = "colon_separated"
