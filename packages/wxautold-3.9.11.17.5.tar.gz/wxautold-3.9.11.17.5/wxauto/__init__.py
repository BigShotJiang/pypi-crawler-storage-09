from .wxauto import WeChat
from .utils import *

__version__ = VERSION

__all__ = [
    'WeChat', 
    'VERSION',
]
