from wyrmx_core.db.base_schema import DatabaseSchema
from wyrmx_core.db.base_model import Model