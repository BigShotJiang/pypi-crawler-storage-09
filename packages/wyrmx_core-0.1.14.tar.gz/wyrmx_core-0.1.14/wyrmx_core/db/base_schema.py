from sqlalchemy.orm import DeclarativeBase

class DatabaseSchema(DeclarativeBase): pass