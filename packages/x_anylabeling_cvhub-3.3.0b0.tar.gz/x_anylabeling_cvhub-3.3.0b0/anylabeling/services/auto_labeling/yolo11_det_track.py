from .__base__.yolo import YOLO


class YOLO11_Det_Tracker(YOLO):
    pass
