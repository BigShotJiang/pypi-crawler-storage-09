from .__base__.yolo import YOLO


class YOLO11_Pose(YOLO):
    pass
