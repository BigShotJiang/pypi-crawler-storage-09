from .__base__.yolo import YOLO


class YOLO11_Seg_Tracker(YOLO):
    pass
