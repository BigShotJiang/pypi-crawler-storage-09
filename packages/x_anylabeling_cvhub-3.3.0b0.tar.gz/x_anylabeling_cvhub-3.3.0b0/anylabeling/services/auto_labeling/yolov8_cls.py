from .yolov5_cls import YOLOv5_CLS


class YOLOv8_CLS(YOLOv5_CLS):
    pass
