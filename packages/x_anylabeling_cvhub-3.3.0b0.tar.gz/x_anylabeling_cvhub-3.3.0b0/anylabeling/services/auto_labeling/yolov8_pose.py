from .__base__.yolo import YOLO


class YOLOv8_Pose(YOLO):
    pass
