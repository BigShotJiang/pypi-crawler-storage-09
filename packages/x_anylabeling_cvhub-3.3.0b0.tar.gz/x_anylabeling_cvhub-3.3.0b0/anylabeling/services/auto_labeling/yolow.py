from .__base__.yolo import YOLO


class YOLOW(YOLO):
    pass
