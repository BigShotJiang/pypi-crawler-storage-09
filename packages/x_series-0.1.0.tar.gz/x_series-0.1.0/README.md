# x-series

![PyPI version](https://img.shields.io/pypi/v/x-series.svg)
[![Documentation Status](https://readthedocs.org/projects/x-series/badge/?version=latest)](https://x-series.readthedocs.io/en/latest/?version=latest)

Modular Python utilities for entity extraction, validation, and graph-ready data pipelines — built for LLM and data engineering workflows.

* PyPI package: https://pypi.org/project/x-series/
* Free software: MIT License
* Documentation: https://x-series.readthedocs.io.

## Features

* TODO

## Credits

This package was created with [Cookiecutter](https://github.com/audreyfeldroy/cookiecutter) and the [audreyfeldroy/cookiecutter-pypackage](https://github.com/audreyfeldroy/cookiecutter-pypackage) project template.
