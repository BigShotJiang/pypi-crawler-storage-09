from xspacedl.__main__ import *  # noqa: F401,F403
