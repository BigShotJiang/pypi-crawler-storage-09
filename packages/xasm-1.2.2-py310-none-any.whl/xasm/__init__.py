"""
  Copyright (c) 2020 by Rocky Bernstein
"""

__docformat__ = "restructuredtext"

# This ensures VERSION will appear in pydoc
from xdis.version import __version__  # noqa
