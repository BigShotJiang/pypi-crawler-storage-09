#!/usr/bin/env python

"""Setup script for the 'xasm' distribution."""

from setuptools import setup

setup()
