def five() -> int:
    return 5


print(five())
