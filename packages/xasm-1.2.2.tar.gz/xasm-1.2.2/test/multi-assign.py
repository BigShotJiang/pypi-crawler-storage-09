#!/usr/bin/env py
x = 1; y = 2; z = 3;
print(x + y + z)
