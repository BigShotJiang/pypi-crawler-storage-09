#!/usr/bin/env
x = 1; y = 2; z = 3/0;
print(x + y + z);
