x = 1
y = x * 2
if y < 2:
    print('nope')
print('done')
