This directory contains administrative tools for testing and making packages.

Since this project uses python over a wide variety of release, some versions
of projects that should be used for specific Python versions

for 3.2.6:
   pytest==2.9.2

for 3.1.5
   pytset==2.1.0
   py=1.8.0 and comment out line 10 of _builtin.py # callable = callable
   six==1.10.0
