# History of bytecode changes.

## Magic 3000, Python 3.0

* Bytecode is bytes not char.

## Magic 3200, Python 3.3

* size modulo 2**32 to the pyc header

## 3.6.x

* code is no longer in 8-bit units (bytes) but 16-but units
