# An example of Python 3.1 funkiness
# Disassembling this gives the "EXTENDED_ARG" op

def open(file, mode = "r", buffering = None,
         encoding = None, errors = None,
         newline = None, closefd = True) -> "IOBase":
    return text
