# Tests relative imports
from . import bogus
