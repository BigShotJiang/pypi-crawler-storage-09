# Python 1.4 uses & for bit and
1 & 0111
