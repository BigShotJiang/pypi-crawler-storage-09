"""
Copyright Hagen Fritsch, 2012, License: GPL-2.0
_marshal.py adapted from pypy (MIT License)

Some small modifications and adaption to xdis by Rocky Bernstein
"""

__docformat__ = "restructuredtext"
