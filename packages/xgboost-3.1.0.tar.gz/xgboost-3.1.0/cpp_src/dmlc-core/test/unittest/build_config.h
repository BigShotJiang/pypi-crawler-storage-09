#define CMAKE_CURRENT_SOURCE_DIR "/workspace/dmlc-core/test/unittest"
