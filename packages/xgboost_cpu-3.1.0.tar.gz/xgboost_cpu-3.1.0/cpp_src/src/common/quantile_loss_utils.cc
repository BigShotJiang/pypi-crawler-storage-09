/**
 * Copyright 2023-2025, XGBoost contributors
 */
#include "quantile_loss_utils.h"

namespace xgboost::common {
DMLC_REGISTER_PARAMETER(QuantileLossParam);
}  // namespace xgboost::common
