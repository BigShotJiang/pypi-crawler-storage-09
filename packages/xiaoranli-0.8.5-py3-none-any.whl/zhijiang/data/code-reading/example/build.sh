#!/bin/bash

# debug or release