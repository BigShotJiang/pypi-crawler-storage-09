sudo apt install -y peco bat lolcat expect twine \
    strace ltrace sysstat tree bc net-tools tig \
    jq htop iftop nload glances vnstat \
    nmap tcpdump mtr traceroute iperf3 \
