Development
===========

Build for Windows
-----------------

.. code-block:: bash

    $ pyinstaller xiRESCORE.spec

.. hint::

    Windows 8 has binaries incompatible with pyarrow 16 and above. Use Python 3.10 to be able to pip install
    pre-compiled pyarrow versions.
