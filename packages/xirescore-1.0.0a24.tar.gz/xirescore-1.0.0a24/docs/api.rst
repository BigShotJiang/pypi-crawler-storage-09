===
API
===
..
  .. autosummary::
      xirescore.XiRescore
      xirescore.readers
      xirescore.writers
      xirescore.DBConnector

.. autoclass:: xirescore.XiRescore::XiRescore
    :members:
    :undoc-members:
    :special-members: __init__

..
  .. automodule:: xirescore.readers
      :members:
      :undoc-members:

  .. automodule:: xirescore.writers
      :members:
      :undoc-members:

  .. automodule:: xirescore.DBConnector
      :members:
      :undoc-members:
