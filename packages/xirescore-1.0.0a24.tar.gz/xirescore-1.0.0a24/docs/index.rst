xiRESCORE Documentation
======================================

xiRESCORE is a cross-link mass spectrometry rescoring tool developed by Rappsilber Laboratory.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   introduction
   installation
   usage
   large-data
   options
   api
   license
