.. _options:

=======
Options
=======

The following are the available options and their default values:

.. literalinclude:: ../xirescore/_default_options.py
   :language: python
