from xirescore import cli


def main():
    cli.main()


if __name__ == "__main__":
    main()
