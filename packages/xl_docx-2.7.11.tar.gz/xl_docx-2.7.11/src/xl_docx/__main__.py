from xl_docx.tool import WordTemplateEditor


editor = WordTemplateEditor()
editor.run()