from .relation import RelationMixin

__all__ = ['RelationMixin']
