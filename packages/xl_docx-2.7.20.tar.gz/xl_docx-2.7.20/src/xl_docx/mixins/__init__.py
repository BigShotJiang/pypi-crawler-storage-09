from .component import ComponentMixin
from .relation import RelationMixin

__all__ = ['ComponentMixin', 'RelationMixin']
