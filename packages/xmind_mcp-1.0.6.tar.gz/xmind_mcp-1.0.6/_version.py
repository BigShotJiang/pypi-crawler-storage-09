__version__ = version = '1.0.6'
