from .core import compare_xml

__all__ = ['compare_xml']