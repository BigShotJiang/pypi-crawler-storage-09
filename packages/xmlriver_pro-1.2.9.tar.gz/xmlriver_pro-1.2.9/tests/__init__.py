"""
Тесты для XMLRiver Pro API
"""
