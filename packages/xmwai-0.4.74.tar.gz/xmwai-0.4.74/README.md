# XMWAI

## 简介
XMWAI 是一个小码王开源的第三方 Python 库，支持生文、生图、生诗句等多场景的内容。需要学员提供对应的api秘钥才能使用。

## 安装
使用 pip 安装：
```bash
pip install XMWAI
或
pip install -i https://pypi.tuna.tsinghua.edu.cn/simple XMWAI
```