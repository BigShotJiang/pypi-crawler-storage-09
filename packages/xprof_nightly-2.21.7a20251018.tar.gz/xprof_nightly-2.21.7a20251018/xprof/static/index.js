export async function render() {
  document.location.href = 'index.html';
}
