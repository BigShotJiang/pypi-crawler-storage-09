.. include:: ../templates/readme.rst
