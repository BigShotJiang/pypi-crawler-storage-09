class APIAttr(object):
    """A generic class for API Attributes, just holds values"""

    def __repr__(self):
        return str(self.__dict__)
