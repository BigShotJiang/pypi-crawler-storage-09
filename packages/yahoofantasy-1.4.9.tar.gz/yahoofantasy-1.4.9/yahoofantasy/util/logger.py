import logging

logger = logging.getLogger("yahoofantasy")
