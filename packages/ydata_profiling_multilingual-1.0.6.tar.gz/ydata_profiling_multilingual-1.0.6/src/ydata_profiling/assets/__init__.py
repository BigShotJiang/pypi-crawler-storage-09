"""
Assets module for ydata-profiling
"""