==========
Change Log
==========

`0.0.6`_
--------

* Environments now installed from package lists pre-tested via CI
