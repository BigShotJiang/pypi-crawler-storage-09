Command Line
============

.. click:: ymp.cli:main
   :prog: ymp
   :show-nested:
