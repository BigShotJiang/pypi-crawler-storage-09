YMP - a Flexible Omics Pipeline
===============================

Welcome to the YMP documentation!

.. include:: ../README.rst
   :start-after: begin intro
   :end-before: end intro

.. include:: ../README.rst
   :start-after: begin features
   :end-before: end features

.. include:: ../README.rst
   :start-after: begin background
   :end-before: end background
