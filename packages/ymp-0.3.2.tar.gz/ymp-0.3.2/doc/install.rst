Installing and Updating YMP
===========================

.. include:: ../README.rst
   :start-after: begin developer info
   :end-before: end developer info

