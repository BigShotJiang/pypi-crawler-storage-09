Stages
======

Listing of stages implemented in YMP

.. autosnake:: ../src/ymp/rules/Snakefile


