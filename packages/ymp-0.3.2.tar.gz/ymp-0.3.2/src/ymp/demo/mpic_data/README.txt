This test dataset is based on the qiime moving pictures tutorial dataset.
It contains only four of the samples, with two subjects and two sample
types. The sequences have been randomly downsampled at 1:20.