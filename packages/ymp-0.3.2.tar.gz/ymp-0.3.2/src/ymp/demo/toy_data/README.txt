This is the "toy" dataset from the Spades Assembler.
