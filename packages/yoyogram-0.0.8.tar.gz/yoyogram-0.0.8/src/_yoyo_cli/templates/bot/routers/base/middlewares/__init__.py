from aiogram import Router


def register_middlewares(router: Router):
	"""
	Strict order
	router.message.middleware.register(YourMiddleware())
	"""
	...
