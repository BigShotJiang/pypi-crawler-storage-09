from aiogram import Bot, Dispatcher

from tgbot.bots.{bot_name}.scripts import bot, dp

bot: Bot = bot
dp: Dispatcher = dp
