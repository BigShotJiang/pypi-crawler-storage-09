
MY_WEB_APP = "https://example.com/"  # Name a variable with the url to web app, and then use it
