from typing import Set

SUBTITLE_EXTENSIONS: Set[str] = {"srt", "vtt", "ass", "lrc"}
