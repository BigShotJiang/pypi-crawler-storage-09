def main():
    print("Hello from yyc-print-hello!")


if __name__ == "__main__":
    main()
