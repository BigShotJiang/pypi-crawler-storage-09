def main() -> None:
    print("Hello from yyc-print-hi!")
