"""zytome"""

__version__ = "0.0.53"
__author__ = "Marko Zolo Gozano Untalan"
