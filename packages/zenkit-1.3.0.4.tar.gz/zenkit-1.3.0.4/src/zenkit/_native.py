__all__ = ["ZkPointer", "ZkString", "load"]

from ctypes import c_char_p
from ctypes import c_void_p
from typing import Any

from zenkit._core import DLL
from zenkit._core import PathOrFileLike
from zenkit.stream import Read
from zenkit.vfs import VfsNode


class ZkString(c_char_p):
    @property
    def value(self) -> str:
        value = super().value

        if value is None:
            error = "Failed to load native string"
            raise ValueError(error)

        return value.decode("windows-1252")


class ZkPointer(c_void_p):
    @property
    def value(self) -> c_void_p:
        return c_void_p(super().value)


def load(load: str, src: PathOrFileLike, *args: Any) -> c_void_p:
    if src is None:
        return c_void_p(None)

    rd: Read
    if isinstance(src, VfsNode):
        rd = src.open()
    elif isinstance(src, Read):
        rd = src
    else:
        rd = Read(src)

    fn = getattr(DLL, load)
    fn.restype = c_void_p
    return c_void_p(fn(rd.handle, *args))
