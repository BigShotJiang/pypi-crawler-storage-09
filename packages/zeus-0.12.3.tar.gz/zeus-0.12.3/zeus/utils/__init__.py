"""Utility functions and classes."""
