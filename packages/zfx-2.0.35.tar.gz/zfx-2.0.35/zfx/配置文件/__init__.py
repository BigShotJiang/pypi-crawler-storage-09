from .写配置项_ANSI import 写配置项_ANSI
from .写配置项_UTF8 import 写配置项_UTF8
from .读配置项_ANSI import 读配置项_ANSI
from .读配置项_UTF8 import 读配置项_UTF8
