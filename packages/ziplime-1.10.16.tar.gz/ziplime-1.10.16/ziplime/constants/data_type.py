import enum


class DataType(enum.Enum):
    MARKET_DATA = "MARKET_DATA"
    CUSTOM = "CUSTOM"
