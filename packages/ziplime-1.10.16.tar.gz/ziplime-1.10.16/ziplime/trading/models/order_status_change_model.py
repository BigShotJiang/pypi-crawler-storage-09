


class OrderStatusChange:
    def __init__(self, order_id, status, timestamp):
        self.order_id = order_id
        self.status = status
        self.timestamp = timestamp