class TradingPair:
    pass
