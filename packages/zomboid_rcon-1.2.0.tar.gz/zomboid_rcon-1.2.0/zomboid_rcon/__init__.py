"""
Zomboid RCON: https://github.com/jmwhitworth/zomboid_rcon
    :copyright: (c) 2025 by JW: https://jackwhitworth.com
    :license: GPL-3.0, see LICENSE for more details.
"""

from .zomboid_rcon import ZomboidRCON

__title__ = "zomboid_rcon"
__version__ = "1.2.0"
