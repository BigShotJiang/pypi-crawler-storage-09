def func():
    return "hello"